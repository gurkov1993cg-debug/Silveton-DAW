#include "silvetonlive/PanicEngine.h"

namespace silvetonlive {

std::vector<MidiPacket> PanicEngine::build(const ModelProfile& profile, bool allChannels, int channel) {
    std::vector<MidiPacket> out;
    const int first = allChannels ? 0 : clampChannel(channel);
    const int last = allChannels ? 15 : clampChannel(channel);
    out.reserve(static_cast<std::size_t>((last - first + 1) * 3));
    for (int ch = first; ch <= last; ++ch) {
        out.push_back(controlChange(ch, profile.allSoundOffCc, 0));
        out.push_back(controlChange(ch, profile.resetControllersCc, 0));
        out.push_back(controlChange(ch, profile.allNotesOffCc, 0));
    }
    return out;
}

} // namespace silvetonlive
