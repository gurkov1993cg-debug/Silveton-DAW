#include "silvetonlive/IntervalEngine.h"
#include <algorithm>
#include <stdexcept>

namespace silvetonlive {

void IntervalEngine::setVoice(int index, const IntervalVoice& voice) {
    if (index < 0 || index >= kMaxVoices) throw std::out_of_range("interval voice index");
    voices_[static_cast<std::size_t>(index)] = voice;
}

const IntervalVoice& IntervalEngine::voice(int index) const {
    if (index < 0 || index >= kMaxVoices) throw std::out_of_range("interval voice index");
    return voices_[static_cast<std::size_t>(index)];
}

void IntervalEngine::releaseInputKey(int key, int velocity, std::int64_t ts, std::vector<MidiPacket>& out) {
    const auto it = activeGenerated_.find(key);
    if (it == activeGenerated_.end()) return;
    for (const int packed : it->second) {
        const auto rcIt = outputRefCount_.find(packed);
        if (rcIt == outputRefCount_.end()) continue;
        if (--rcIt->second <= 0) {
            out.push_back(noteOff((packed >> 8) & 0x0F, packed & 0x7F, velocity, ts));
            outputRefCount_.erase(rcIt);
        }
    }
    activeGenerated_.erase(it);
}

std::vector<MidiPacket> IntervalEngine::processNoteOn(int channel, int note, int velocity, std::int64_t ts) {
    std::vector<MidiPacket> out;
    const int key = (clampChannel(channel) << 8) | clamp7(note);
    releaseInputKey(key, 0, ts, out);

    std::vector<int> generated;
    for (const auto& v : voices_) {
        if (!v.enabled) continue;
        const int targetNote = note + v.semitones;
        if (targetNote < 0 || targetNote > 127) continue;
        const int ch = v.outputChannel < 0 ? clampChannel(channel) : clampChannel(v.outputChannel);
        const int vel = std::clamp(velocity + v.velocityOffset, 1, 127);
        const int packed = (ch << 8) | targetNote;
        int& refs = outputRefCount_[packed];
        if (refs == 0) out.push_back(noteOn(ch, targetNote, vel, ts));
        ++refs;
        generated.push_back(packed);
    }
    if (!generated.empty()) activeGenerated_[key] = std::move(generated);
    return out;
}

std::vector<MidiPacket> IntervalEngine::processNoteOff(int channel, int note, int velocity, std::int64_t ts) {
    std::vector<MidiPacket> out;
    const int key = (clampChannel(channel) << 8) | clamp7(note);
    releaseInputKey(key, velocity, ts, out);
    return out;
}

std::vector<MidiPacket> IntervalEngine::flush(std::int64_t ts, int velocity) {
    std::vector<MidiPacket> out;
    out.reserve(outputRefCount_.size());
    for (const auto& entry : outputRefCount_) {
        const int packed = entry.first;
        out.push_back(noteOff((packed >> 8) & 0x0F, packed & 0x7F, velocity, ts));
    }
    activeGenerated_.clear();
    outputRefCount_.clear();
    return out;
}

void IntervalEngine::clear() {
    activeGenerated_.clear();
    outputRefCount_.clear();
}

} // namespace silvetonlive
