#include "silvetonlive/PadEngine.h"
#include <stdexcept>

namespace silvetonlive {

void PadEngine::setPad(int index, const PadAction& action) {
    if (index < 0 || index >= kPadCount) throw std::out_of_range("pad index");
    pads_[static_cast<std::size_t>(index)] = action;
    active_[static_cast<std::size_t>(index)] = false;
}

const PadAction& PadEngine::pad(int index) const {
    if (index < 0 || index >= kPadCount) throw std::out_of_range("pad index");
    return pads_[static_cast<std::size_t>(index)];
}

MidiPacket PadEngine::makeOn(const PadAction& p, std::int64_t ts) const {
    switch (p.type) {
        case PadActionType::Note: return noteOn(p.channel, p.number, p.onValue, ts);
        case PadActionType::ControlChange: return controlChange(p.channel, p.number, p.onValue, ts);
        case PadActionType::ProgramChange: return programChange(p.channel, p.number, ts);
    }
    return {};
}

std::vector<MidiPacket> PadEngine::makeOff(const PadAction& p, std::int64_t ts) const {
    switch (p.type) {
        case PadActionType::Note: return {noteOff(p.channel, p.number, p.offValue, ts)};
        case PadActionType::ControlChange: return {controlChange(p.channel, p.number, p.offValue, ts)};
        case PadActionType::ProgramChange: return {};
    }
    return {};
}

std::vector<MidiPacket> PadEngine::press(int index, std::int64_t ts) {
    const auto& p = pad(index);
    auto& active = active_[static_cast<std::size_t>(index)];
    if (p.momentary || p.type == PadActionType::ProgramChange) {
        // Program Change is inherently a one-shot action even when a stored pad
        // was accidentally marked as non-momentary.
        if (p.type != PadActionType::ProgramChange) active = true;
        return {makeOn(p, ts)};
    }

    if (active) {
        active = false;
        return makeOff(p, ts);
    }
    active = true;
    return {makeOn(p, ts)};
}

std::vector<MidiPacket> PadEngine::release(int index, std::int64_t ts) {
    const auto& p = pad(index);
    auto& active = active_[static_cast<std::size_t>(index)];
    if (!p.momentary || p.type == PadActionType::ProgramChange) return {};
    if (!active) return {};
    active = false;
    return makeOff(p, ts);
}

std::vector<MidiPacket> PadEngine::flush(std::int64_t ts) {
    std::vector<MidiPacket> out;
    for (int i = 0; i < kPadCount; ++i) {
        auto& active = active_[static_cast<std::size_t>(i)];
        if (!active) continue;
        const auto& p = pads_[static_cast<std::size_t>(i)];
        auto off = makeOff(p, ts);
        out.insert(out.end(), off.begin(), off.end());
        active = false;
    }
    return out;
}

bool PadEngine::latched(int index) const {
    if (index < 0 || index >= kPadCount) throw std::out_of_range("pad index");
    return active_[static_cast<std::size_t>(index)];
}

} // namespace silvetonlive
