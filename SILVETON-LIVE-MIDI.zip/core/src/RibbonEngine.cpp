#include "silvetonlive/RibbonEngine.h"
#include <algorithm>
#include <cmath>

namespace silvetonlive {

void RibbonEngine::setConfig(const RibbonConfig& cfg) {
    cfg_ = cfg;
    cfg_.channel = clampChannel(cfg_.channel);
    cfg_.cc = std::clamp(cfg_.cc, 0, 127);
    cfg_.smoothing = std::clamp(cfg_.smoothing, 0.0, 0.95);
}

MidiPacket RibbonEngine::process(double normalizedPosition, std::int64_t ts) {
    const double x = std::clamp(normalizedPosition, 0.0, 1.0);
    if (!initialized_) {
        filtered_ = x;
        initialized_ = true;
    } else {
        filtered_ = cfg_.smoothing * filtered_ + (1.0 - cfg_.smoothing) * x;
    }

    if (cfg_.output == RibbonOutput::PitchBend) {
        const int bend = static_cast<int>(std::lround(filtered_ * 16383.0));
        return pitchBend14(cfg_.channel, bend, ts);
    }
    const int value = static_cast<int>(std::lround(filtered_ * 127.0));
    return controlChange(cfg_.channel, cfg_.cc, value, ts);
}

MidiPacket RibbonEngine::center(std::int64_t ts) {
    filtered_ = 0.5;
    initialized_ = true;
    return cfg_.output == RibbonOutput::PitchBend
        ? pitchBend14(cfg_.channel, 8192, ts)
        : controlChange(cfg_.channel, cfg_.cc, 64, ts);
}

MidiPacket RibbonEngine::release(std::int64_t ts) {
    switch (cfg_.release) {
        case RibbonRelease::Hold:
            return process(filtered_, ts);
        case RibbonRelease::Minimum:
            filtered_ = 0.0; initialized_ = true; return process(0.0, ts);
        case RibbonRelease::Maximum:
            filtered_ = 1.0; initialized_ = true; return process(1.0, ts);
        case RibbonRelease::Center:
        default:
            return center(ts);
    }
}

} // namespace silvetonlive
