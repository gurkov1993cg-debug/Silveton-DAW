#include "silvetonlive/MidiParser.h"
#include <utility>

namespace silvetonlive {

int MidiParser::dataBytesForStatus(std::uint8_t status) {
    if (status < 0x80) return -1;
    if (status < 0xF0) {
        const auto hi = static_cast<std::uint8_t>(status & 0xF0);
        return (hi == 0xC0 || hi == 0xD0) ? 1 : 2;
    }
    switch (status) {
        case 0xF1: return 1; // MTC quarter frame
        case 0xF2: return 2; // song position
        case 0xF3: return 1; // song select
        case 0xF6: return 0; // tune request
        case 0xF7: return 0; // EOX outside SysEx
        default:   return 0; // realtime/undefined
    }
}

ParsedMidiMessage MidiParser::classify(std::vector<std::uint8_t> bytes, std::int64_t ts) {
    ParsedMidiMessage m;
    m.timestampNanos = ts;
    m.bytes = std::move(bytes);
    if (m.bytes.empty()) return m;
    const std::uint8_t status = m.bytes[0];
    if (status < 0xF0) {
        m.channel = status & 0x0F;
        switch (status & 0xF0) {
            case 0x80: m.kind = MidiMessageKind::NoteOff; break;
            case 0x90:
                m.kind = (m.bytes.size() >= 3 && m.bytes[2] == 0)
                    ? MidiMessageKind::NoteOff : MidiMessageKind::NoteOn;
                break;
            case 0xA0: m.kind = MidiMessageKind::PolyPressure; break;
            case 0xB0: m.kind = MidiMessageKind::ControlChange; break;
            case 0xC0: m.kind = MidiMessageKind::ProgramChange; break;
            case 0xD0: m.kind = MidiMessageKind::ChannelPressure; break;
            case 0xE0: m.kind = MidiMessageKind::PitchBend; break;
            default: break;
        }
    } else if (status == 0xF0) {
        m.kind = MidiMessageKind::SystemExclusive;
    } else if (status >= 0xF8) {
        m.kind = MidiMessageKind::SystemRealtime;
    } else {
        m.kind = MidiMessageKind::SystemCommon;
    }
    return m;
}

std::vector<ParsedMidiMessage> MidiParser::push(const std::uint8_t* data, std::size_t size,
                                                std::int64_t ts) {
    std::vector<ParsedMidiMessage> out;
    if (!data || size == 0) return out;

    for (std::size_t i = 0; i < size; ++i) {
        const std::uint8_t b = data[i];

        // Realtime can occur anywhere, including inside SysEx.
        if (b >= 0xF8) {
            out.push_back(classify({b}, ts));
            continue;
        }

        if (inSysEx_) {
            sysex_.push_back(b);
            if (b == 0xF7) {
                out.push_back(classify(std::move(sysex_), ts));
                sysex_.clear();
                inSysEx_ = false;
            } else if ((b & 0x80) != 0) {
                // Illegal non-realtime status inside SysEx: terminate corrupted packet
                // and continue parsing that status normally.
                sysex_.clear();
                inSysEx_ = false;
                --i;
            }
            continue;
        }

        if ((b & 0x80) != 0) {
            current_.clear();
            expectedData_ = 0;
            currentStatus_ = 0;

            if (b == 0xF0) {
                inSysEx_ = true;
                sysex_.clear();
                sysex_.push_back(b);
                runningStatus_ = 0;
                continue;
            }

            currentStatus_ = b;
            current_.push_back(b);
            expectedData_ = dataBytesForStatus(b);
            if (b < 0xF0) runningStatus_ = b;
            else runningStatus_ = 0;

            if (expectedData_ == 0) {
                out.push_back(classify(std::move(current_), ts));
                current_.clear();
                currentStatus_ = 0;
            }
            continue;
        }

        // Data byte. Start from running status when no explicit message is active.
        if (currentStatus_ == 0) {
            if (runningStatus_ == 0) continue; // stray data byte
            currentStatus_ = runningStatus_;
            current_.clear();
            current_.push_back(currentStatus_);
            expectedData_ = dataBytesForStatus(currentStatus_);
        }

        current_.push_back(b & 0x7F);
        if (static_cast<int>(current_.size()) == expectedData_ + 1) {
            out.push_back(classify(std::move(current_), ts));
            current_.clear();
            currentStatus_ = 0;
            expectedData_ = 0;
        }
    }
    return out;
}

void MidiParser::reset() {
    runningStatus_ = 0;
    currentStatus_ = 0;
    expectedData_ = 0;
    current_.clear();
    inSysEx_ = false;
    sysex_.clear();
}

} // namespace silvetonlive
