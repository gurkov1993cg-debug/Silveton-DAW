#pragma once
#include "MidiTypes.h"
#include <cstdint>
#include <string>
#include <vector>

namespace silvetonlive {

struct MidiIdentity {
    bool valid{false};
    std::vector<std::uint8_t> manufacturerId;
    std::vector<std::uint8_t> familyCode;
    std::vector<std::uint8_t> modelNumber;
    std::vector<std::uint8_t> version;
    std::string manufacturerName;
};

class MidiIdentityCodec {
public:
    static MidiPacket request(std::uint8_t deviceId = 0x7F, std::int64_t ts = 0);
    static MidiIdentity parseReply(const std::vector<std::uint8_t>& sysex);
};

} // namespace silvetonlive
