#pragma once
#include "MidiTypes.h"
#include "PortamentoEngine.h"
#include <cstdint>
#include <vector>

namespace silvetonlive {

struct GlideScheduleConfig {
    int channel{0};
    int bendRangeSemitones{12};
    bool resetAtEnd{true};
};

// Builds timestamped pitch-bend packets for an application-side glide.
// start/end are MIDI notes; the destination note is assumed to sound while pitch
// bend starts at the source offset and approaches center.
class GlideScheduler {
public:
    static std::vector<MidiPacket> build(const PortamentoEngine& engine,
                                         int startNote, int endNote,
                                         std::int64_t startTimeNanos,
                                         const GlideScheduleConfig& cfg = {});
};

} // namespace silvetonlive
