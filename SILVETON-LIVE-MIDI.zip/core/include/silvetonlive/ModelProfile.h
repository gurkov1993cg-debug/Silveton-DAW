#pragma once
#include "Capabilities.h"
#include "PortamentoCalibration.h"
#include <optional>
#include <string>
#include <vector>

namespace silvetonlive {

struct ModelProfile {
    std::string id;
    std::string displayName;
    int defaultMidiChannel{0};
    ModelCapabilities capabilities;

    // MIDI Identity Reply fragments may be filled only after verified captures/docs.
    std::vector<std::uint8_t> identityPrefix;

    // Generic MIDI defaults. A model may override only when validated.
    int portamentoSwitchCc{65};
    int portamentoTimeCc{5};
    int allSoundOffCc{120};
    int resetControllersCc{121};
    int allNotesOffCc{123};

    // Empty until physical measurements for this exact model are available.
    std::vector<PortamentoCalibrationPoint> portamentoCalibration;
};

class ModelRegistry {
public:
    static const std::vector<ModelProfile>& all();
    static const ModelProfile* byId(const std::string& id);
};

} // namespace silvetonlive
