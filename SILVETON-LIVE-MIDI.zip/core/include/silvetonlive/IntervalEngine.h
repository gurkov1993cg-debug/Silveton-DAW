#pragma once
#include "MidiTypes.h"
#include <array>
#include <cstdint>
#include <unordered_map>
#include <vector>

namespace silvetonlive {

struct IntervalVoice {
    bool enabled{false};
    int semitones{0};
    int velocityOffset{0};
    int outputChannel{-1}; // -1 = same as input
};

class IntervalEngine {
public:
    static constexpr int kMaxVoices = 4;
    void setVoice(int index, const IntervalVoice& voice);
    const IntervalVoice& voice(int index) const;

    std::vector<MidiPacket> processNoteOn(int channel, int note, int velocity, std::int64_t ts = 0);
    std::vector<MidiPacket> processNoteOff(int channel, int note, int velocity = 0, std::int64_t ts = 0);
    std::vector<MidiPacket> flush(std::int64_t ts = 0, int velocity = 0);
    void clear();

private:
    std::array<IntervalVoice, kMaxVoices> voices_{};
    // key = (channel << 8) | note, value = generated (channel,note) ids.
    std::unordered_map<int, std::vector<int>> activeGenerated_;
    std::unordered_map<int, int> outputRefCount_;
    void releaseInputKey(int key, int velocity, std::int64_t ts, std::vector<MidiPacket>& out);
};

} // namespace silvetonlive
