#pragma once
#include "MidiTypes.h"

namespace silvetonlive {

enum class RibbonOutput { PitchBend, ControlChange };
enum class RibbonRelease { Hold, Center, Minimum, Maximum };

struct RibbonConfig {
    RibbonOutput output{RibbonOutput::PitchBend};
    int channel{0};
    int cc{16};
    bool bipolar{true};
    double smoothing{0.15};
    RibbonRelease release{RibbonRelease::Center};
};

class RibbonEngine {
public:
    void setConfig(const RibbonConfig& cfg);
    const RibbonConfig& config() const noexcept { return cfg_; }
    MidiPacket process(double normalizedPosition, std::int64_t timestampNanos = 0);
    MidiPacket center(std::int64_t timestampNanos = 0);
    MidiPacket release(std::int64_t timestampNanos = 0);

private:
    RibbonConfig cfg_{};
    bool initialized_{false};
    double filtered_{0.5};
};

} // namespace silvetonlive
