#pragma once
#include "MidiTypes.h"
#include "ModelProfile.h"
#include <vector>

namespace silvetonlive {

class PanicEngine {
public:
    static std::vector<MidiPacket> build(const ModelProfile& profile, bool allChannels = true, int channel = 0);
};

} // namespace silvetonlive
