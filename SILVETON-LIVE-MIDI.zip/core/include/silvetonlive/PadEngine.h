#pragma once
#include "MidiTypes.h"
#include <array>
#include <vector>

namespace silvetonlive {

enum class PadActionType { Note, ControlChange, ProgramChange };

struct PadAction {
    PadActionType type{PadActionType::Note};
    int channel{0};
    int number{36};
    int onValue{127};
    int offValue{0};
    bool momentary{true};
};

class PadEngine {
public:
    static constexpr int kPadCount = 16;
    void setPad(int index, const PadAction& action);
    const PadAction& pad(int index) const;
    std::vector<MidiPacket> press(int index, std::int64_t ts = 0);
    std::vector<MidiPacket> release(int index, std::int64_t ts = 0);
    // Emits the required OFF state for active note/CC pads and resets all latch state.
    std::vector<MidiPacket> flush(std::int64_t ts = 0);
    bool latched(int index) const;

private:
    std::array<PadAction, kPadCount> pads_{};
    std::array<bool, kPadCount> active_{};
    MidiPacket makeOn(const PadAction& p, std::int64_t ts) const;
    std::vector<MidiPacket> makeOff(const PadAction& p, std::int64_t ts) const;
};

} // namespace silvetonlive
