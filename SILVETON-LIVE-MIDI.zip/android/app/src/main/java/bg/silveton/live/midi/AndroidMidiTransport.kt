package bg.silveton.live.midi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import java.io.Closeable
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Android MIDI transport. Device INPUT ports are opened for app -> keyboard data;
 * device OUTPUT ports are opened for keyboard -> app data.
 */
class AndroidMidiTransport(context: Context) : Closeable {
    data class Port(
        val number: Int,
        val type: Int,
        val name: String
    )

    data class Device(val info: MidiDeviceInfo) {
        val label: String = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME)
            ?: info.properties.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
            ?: "MIDI device #${info.id}"
        val manufacturer: String = info.properties.getString(MidiDeviceInfo.PROPERTY_MANUFACTURER) ?: ""
        val product: String = info.properties.getString(MidiDeviceInfo.PROPERTY_PRODUCT) ?: ""
        val version: String = info.properties.getString(MidiDeviceInfo.PROPERTY_VERSION) ?: ""
        val stableKey: String = listOf(manufacturer, product, label, version, info.type.toString()).joinToString("|")
        val ports: List<Port> = info.ports.map {
            Port(it.portNumber, it.type, it.name ?: "Port ${it.portNumber}")
        }
        val inputPorts: List<Port> get() = ports.filter { it.type == MidiDeviceInfo.PortInfo.TYPE_INPUT }
        val outputPorts: List<Port> get() = ports.filter { it.type == MidiDeviceInfo.PortInfo.TYPE_OUTPUT }
    }

    interface Listener {
        fun onDevicesChanged(devices: List<Device>) {}
        fun onConnectionChanged(connected: Boolean, label: String?) {}
        fun onMidiReceived(bytes: ByteArray, timestampNanos: Long) {}
        fun onError(message: String) {}
    }

    private val midiManager = context.getSystemService(MidiManager::class.java)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()
    private var device: MidiDevice? = null
    private var outputToKeyboard: MidiInputPort? = null
    private var inputFromKeyboard: MidiOutputPort? = null
    private var connectedKey: String? = null
    private var requestedKey: String? = null
    private var requestedInputPort: Int = 0
    private var requestedOutputPort: Int = -1
    private var autoReconnect: Boolean = true
    private var connectionGeneration: Long = 0L

    private val receiver = object : MidiReceiver() {
        override fun onSend(data: ByteArray, offset: Int, count: Int, timestamp: Long) {
            if (count <= 0) return
            val copy = data.copyOfRange(offset, offset + count)
            listeners.forEach { it.onMidiReceived(copy, timestamp) }
        }
    }

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) {
            publishDevices()
            val key = requestedKey
            if (autoReconnect && key != null && device == null) {
                val d = Device(info)
                if (d.stableKey == key) connect(info, requestedInputPort, requestedOutputPort)
            }
        }

        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            if (device?.info?.id == info.id) disconnect(clearReconnectTarget = false)
            publishDevices()
        }
    }

    init {
        midiManager.registerDeviceCallback(deviceCallback, mainHandler)
        publishDevices()
    }

    fun addListener(listener: Listener) { listeners += listener; publishDevices() }
    fun removeListener(listener: Listener) { listeners -= listener }

    fun devices(): List<Device> = midiManager.devices.map(::Device)
    fun isConnected(): Boolean = device != null && outputToKeyboard != null
    fun connectedStableKey(): String? = connectedKey

    fun setAutoReconnect(enabled: Boolean) { autoReconnect = enabled }

    fun reconnect(stableKey: String, inputPortNumber: Int = 0, outputPortNumber: Int = -1) {
        requestedKey = stableKey
        requestedInputPort = inputPortNumber
        requestedOutputPort = outputPortNumber
        val match = devices().firstOrNull { it.stableKey == stableKey }
        if (match != null) connect(match.info, inputPortNumber, outputPortNumber)
    }

    /**
     * inputPortNumber: keyboard device INPUT port used for app -> keyboard.
     * outputPortNumber: keyboard device OUTPUT port used for keyboard -> app.
     */
    fun connect(info: MidiDeviceInfo, inputPortNumber: Int = 0, outputPortNumber: Int = -1) {
        disconnect(clearReconnectTarget = false)
        val generation = ++connectionGeneration
        val descriptor = Device(info)
        requestedKey = descriptor.stableKey
        requestedInputPort = inputPortNumber
        requestedOutputPort = outputPortNumber

        midiManager.openDevice(info, { opened ->
            if (generation != connectionGeneration) {
                runCatching { opened?.close() }
                return@openDevice
            }
            if (opened == null) {
                listeners.forEach { it.onError("Could not open MIDI device") }
                return@openDevice
            }

            val tx = opened.openInputPort(inputPortNumber)
            if (tx == null) {
                opened.close()
                listeners.forEach { it.onError("Could not open MIDI input port $inputPortNumber") }
                return@openDevice
            }

            // Receiving is optional. -1 explicitly means transmit-only device.
            val rx = if (outputPortNumber >= 0)
                runCatching { opened.openOutputPort(outputPortNumber) }.getOrNull()
            else null
            rx?.connect(receiver)

            device = opened
            outputToKeyboard = tx
            inputFromKeyboard = rx
            connectedKey = descriptor.stableKey
            listeners.forEach { it.onConnectionChanged(true, descriptor.label) }
        }, mainHandler)
    }

    @Synchronized
    fun send(bytes: ByteArray, timestampNanos: Long = 0L) {
        val port = outputToKeyboard ?: throw IllegalStateException("MIDI device is not connected")
        if (bytes.isEmpty()) return
        port.send(bytes, 0, bytes.size, timestampNanos)
    }

    fun sendAll(messages: Array<ByteArray>) {
        messages.forEach { send(it) }
    }

    fun sendAll(messages: List<ByteArray>) {
        messages.forEach { send(it) }
    }

    fun disconnect(clearReconnectTarget: Boolean = true) {
        connectionGeneration++
        runCatching { inputFromKeyboard?.disconnect(receiver) }
        runCatching { inputFromKeyboard?.close() }
        runCatching { outputToKeyboard?.close() }
        runCatching { device?.close() }
        inputFromKeyboard = null
        outputToKeyboard = null
        device = null
        connectedKey = null
        if (clearReconnectTarget) requestedKey = null
        listeners.forEach { it.onConnectionChanged(false, null) }
    }

    private fun publishDevices() {
        val snapshot = devices()
        listeners.forEach { it.onDevicesChanged(snapshot) }
    }

    override fun close() {
        disconnect(clearReconnectTarget = true)
        midiManager.unregisterDeviceCallback(deviceCallback)
    }
}
