package bg.silveton.live.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

class RibbonView(context: Context) : View(context) {
    interface Listener {
        fun onPosition(position: Double)
        fun onRelease()
    }

    var listener: Listener? = null
    private var position = 0.5f
    private var touched = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val track = RectF()

    init {
        minimumHeight = dp(150)
        isClickable = true
        background = SilvetonTheme.panelDrawable(dpF(18), SilvetonTheme.border)
        setPadding(dp(16), dp(16), dp(16), dp(16))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val inset = dp(28).toFloat()
        track.set(inset, height * 0.37f, width - inset, height * 0.63f)

        paint.style = Paint.Style.FILL
        paint.color = SilvetonTheme.bg
        canvas.drawRoundRect(track, dpF(14), dpF(14), paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dpF(2)
        paint.color = SilvetonTheme.border
        canvas.drawRoundRect(track, dpF(14), dpF(14), paint)

        // Reference ticks and centre detent.
        paint.strokeWidth = dpF(1)
        paint.color = SilvetonTheme.borderSoft
        for (i in 1 until 10) {
            val x = track.left + track.width() * i / 10f
            val h = if (i == 5) dpF(16) else dpF(8)
            canvas.drawLine(x, track.centerY() - h, x, track.centerY() + h, paint)
        }

        val x = track.left + track.width() * position
        val fillLeft = if (position >= 0.5f) track.centerX() else x
        val fillRight = if (position >= 0.5f) x else track.centerX()
        paint.style = Paint.Style.FILL
        paint.color = SilvetonTheme.blend(SilvetonTheme.blue, SilvetonTheme.cyan, 0.45f)
        canvas.drawRoundRect(RectF(fillLeft, track.top + dpF(4), fillRight, track.bottom - dpF(4)), dpF(10), dpF(10), paint)

        paint.color = if (touched) SilvetonTheme.cyan else SilvetonTheme.blue
        canvas.drawCircle(x, track.centerY(), dpF(20), paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dpF(3)
        paint.color = SilvetonTheme.text
        canvas.drawCircle(x, track.centerY(), dpF(20), paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                touched = true
                position = ((event.x - track.left) / max(1f, track.width())).coerceIn(0f, 1f)
                listener?.onPosition(position.toDouble())
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touched = false
                listener?.onRelease()
                invalidate()
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpF(v: Int): Float = v * resources.displayMetrics.density
}
