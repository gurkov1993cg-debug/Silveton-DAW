package bg.silveton.live.model

import android.content.Context
import bg.silveton.live.midi.PadType

data class PadConfig(
    val label: String,
    val type: PadType,
    val channel: Int,
    val number: Int,
    val onValue: Int,
    val offValue: Int,
    val momentary: Boolean
)

/** Persistent user pad mappings. No model-specific KORG command is invented here. */
class PadConfigurationStore(context: Context) {
    private val prefs = context.getSharedPreferences("silveton_live_pads", Context.MODE_PRIVATE)

    fun loadBank(bank: Int): List<PadConfig> = (0 until 16).map { index -> load(bank, index) }

    fun load(bank: Int, index: Int): PadConfig {
        val b = bank.coerceIn(0, 2)
        val i = index.coerceIn(0, 15)
        val raw = prefs.getString(key(b, i), null) ?: return default(i)
        val f = raw.split('\u001F')
        if (f.size != 7) return default(i)
        return runCatching {
            PadConfig(
                label = decodeLabel(f[0]).ifBlank { "PAD ${i + 1}" },
                type = PadType.valueOf(f[1]),
                channel = f[2].toInt().coerceIn(0, 15),
                number = f[3].toInt().coerceIn(0, 127),
                onValue = f[4].toInt().coerceIn(0, 127),
                offValue = f[5].toInt().coerceIn(0, 127),
                momentary = f[6].toBooleanStrict()
            )
        }.getOrElse { default(i) }
    }

    fun save(bank: Int, index: Int, config: PadConfig) {
        val b = bank.coerceIn(0, 2)
        val i = index.coerceIn(0, 15)
        val c = sanitize(config, i)
        val raw = listOf(
            encodeLabel(c.label), c.type.name, c.channel.toString(), c.number.toString(),
            c.onValue.toString(), c.offValue.toString(), c.momentary.toString()
        ).joinToString("\u001F")
        prefs.edit().putString(key(b, i), raw).apply()
    }

    fun resetBank(bank: Int) {
        val e = prefs.edit()
        val b = bank.coerceIn(0, 2)
        for (i in 0 until 16) e.remove(key(b, i))
        e.apply()
    }

    fun default(index: Int): PadConfig = PadConfig(
        label = "PAD ${index.coerceIn(0, 15) + 1}",
        type = PadType.NOTE,
        channel = 9,
        number = 36 + index.coerceIn(0, 15),
        onValue = 110,
        offValue = 0,
        momentary = true
    )

    private fun sanitize(c: PadConfig, index: Int) = c.copy(
        label = c.label.trim().take(24).ifBlank { "PAD ${index + 1}" },
        channel = c.channel.coerceIn(0, 15),
        number = c.number.coerceIn(0, 127),
        onValue = c.onValue.coerceIn(0, 127),
        offValue = c.offValue.coerceIn(0, 127)
    )

    private fun key(bank: Int, index: Int) = "b${bank}_p${index}"
    private fun encodeLabel(s: String) = s.replace("%", "%25").replace("\u001F", "%1F")
    private fun decodeLabel(s: String) = s.replace("%1F", "\u001F").replace("%25", "%")
}
