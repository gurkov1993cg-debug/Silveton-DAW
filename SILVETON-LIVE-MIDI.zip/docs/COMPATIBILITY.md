# Compatibility target

Mandatory product target: KORG PA600 through PA5X.

| Model | Profile | CC65 Portamento switch | CC5 Portamento time | CC16 ribbon | Physical Android validation |
|---|---:|---:|---:|---:|---:|
| PA600 | yes | documented | documented | not claimed | pending |
| PA700 | yes | documented | documented | documented | pending |
| PA900 | yes | documented | documented | documented | pending |
| PA1000 | yes | documented | documented | documented | pending |
| PA4X | yes | documented | documented | documented | pending |
| PA5X | yes | documented | documented | documented | pending |

The documented entries come from KORG MIDI implementation/user documentation. `Documented` is deliberately distinct from `Verified`: the latter requires testing on the actual model or an equivalent captured MIDI trace.

Exact milliseconds for hardware portamento remain a calibration problem because the instruments expose Portamento Time as a 0..127 parameter. The core therefore supports model-specific measured calibration tables rather than inventing one universal CC5-to-ms law.
