# Silveton LIVE MIDI — architecture

Primary data path:

`Android UI -> controller -> native C++17 control core -> model profile -> Android MIDI transport -> KORG PA`

Return path:

`KORG PA -> Android MIDI receiver -> stream decoder -> monitor / performance router -> generated MIDI -> KORG PA`

## Native core

- `ModelRegistry` / capability matrix for PA600, PA700, PA900, PA1000, PA4X and PA5X.
- `PortamentoEngine` with FIX / LIN / FIB / REAL / CUSTOM curve and duration laws.
- `PortamentoCalibration` for future per-model measured CC5 -> milliseconds tables. No measurements are invented.
- `GlideScheduler` producing timestamped 14-bit pitch-bend trajectories.
- `MonophonicPortaProcessor` with last-note priority and held-note resume.
- Independent app-side portamento state per MIDI output channel.
- `HarmonyEngine` with scale-aware diatonic voices, overlapping-note reference counts and tracked NoteOff lifecycle.
- `IntervalEngine` for chromatic interval voices with overlapping-note reference counts.
- `RibbonEngine` with 14-bit pitch bend / CC mode, smoothing and release modes.
- `PadEngine` with momentary/toggle semantics, safety flush, plus three in-core banks backed by persistent Android pad mappings.
- `PanicEngine`, `MidiParser`, `MidiIdentityCodec`, `LatencyTracker`.
- Safety flush paths for generated harmony and bridge notes.

## Android layer

- Android MIDI discovery, explicit port selection, send/receive and automatic reconnect target.
- App-side cancellable monotonic MIDI scheduler: a new live glide invalidates stale future pitch-bend events before they can reach Android MIDI.
- Connection-generation guard prevents stale asynchronous open callbacks from replacing a newer connection.
- Stateful MIDI stream decoding including running status, SysEx and realtime messages.
- IN and OUT MIDI monitor.
- Device-name based PA model hinting; this does not pretend to be an Identity Reply mapping.
- Universal MIDI Identity Reply parsing is surfaced in the live connection status/monitor for hardware diagnostics without inventing PA model-number mappings.
- Persistent model, portamento, harmony, ribbon, target-part and connection settings.
- Per-model editable CC5→milliseconds calibration tables are exposed in Android settings and stored separately for every PA target.
- Performance input channel filter prevents arranger/style MIDI from accidentally feeding interval/portamento processors.
- App-side portamento keeps its C++ curve engine separate from the keyboard hardware CC65 switch, preventing double portamento.
- Sustain/breath/expression/aftertouch are channel-routed with app-side bridged notes; generated pitch bend remains owned by the glide engine.
- Physical MIDI timestamps are preserved; zero timestamps are normalized to `System.nanoTime()` before scheduled processing.

## Validation policy

No model-specific KORG command is marked `Verified` until it is tested against physical hardware or a captured trace. Official KORG manuals can mark a command `Documented`. Standard but unverified assumptions remain `GenericMidi`.

The displayed millisecond values are not assumed to equal raw KORG CC5 values. Exact hardware timing can be supplied by a measured per-model calibration table. The application-side bridge can provide deterministic wall-clock FIX timing when the performance routing setup permits it.
