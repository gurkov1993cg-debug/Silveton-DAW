# Silveton DAW 0.8.0 — routing/PDC execution status

## Milestone closed locally

`ProcessorGraph` now executes inside the real `AudioEngine::processAudio()` callback.

Signal path with a graph attached before engine prepare:

`timeline Track N -> graph node N -> processor chain -> routed buses/PDC -> graph master -> Master Fader -> device`

## Implemented

- Track N feeds graph node N through preallocated planar Float32 source buffers.
- Bus/master nodes can remain source-less and receive routed graph audio.
- Existing `ProcessorGraph` sidechain alignment, multi-output routing and latency compensation now affect real engine playback.
- Graph output feeds the existing compensated transparent master bus before Master Fader processing.
- Low-latency input monitoring remains a deliberate direct path and is not forced through the plug-in graph.
- ProcessorGraph runs every callback even with stopped transport, enabling instrument/tail processing.
- `ProcessorContext` receives engine sample rate, current project sample, frames, session tempo, play state and record state.
- Graph node capacity is 1024, sufficient for the 256-track session plus bus/master headroom.
- No heap allocation occurs in the measured graph callback path.
- No-graph sessions retain the previous transparent direct-mix behavior.

## New regression coverage

`silveton_routing_execution_tests` proves:

- real AudioEngine playback enters ProcessorGraph;
- two paths with different processor latency arrive sample-aligned at the graph master;
- 256 measured graph callbacks allocate zero heap memory;
- zero-input instrument processing reaches the master while transport is stopped;
- session tempo and project sample position reach `ProcessorContext`;
- a 257-node graph (256 track nodes + master) configures/prepares successfully.

Portable Release: **12/12 PASS**.

Portable ASan + UBSan (`detect_leaks=0`, `-fno-sanitize=vptr`): **12/12 PASS**.

## 0.8.0 live publication extension

Runtime graph replacement is now implemented through triple-buffered immutable graph plans. Routing/plugin topology changes can be built off the realtime thread and adopted at the next callback boundary. The predecessor graph is retired but not destroyed by the audio thread; control-thread reclamation provides the safe lifetime boundary for retired VST3 instances.

See `LIVE_GRAPH_STATUS.md` for the publication/reclamation contract and concurrent stress coverage.

GitHub Actions Run #19 SUCCESS confirms the later 0.9.0 baseline, which includes the 0.8.0 live graph publication and lifecycle protection described here. The new 0.10.0 automation changes require their own fresh GitHub run before target validation is extended again.
