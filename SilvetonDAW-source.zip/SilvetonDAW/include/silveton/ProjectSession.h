#pragma once
#include "silveton/DawCore.h"
#include "silveton/ProjectHistory.h"
#include "silveton/ProjectRecovery.h"
#include <cstdint>
#include <functional>
#include <string>

namespace silveton {

struct ProjectSessionLoadResult {
    ProjectRecoverySource source {ProjectRecoverySource::Primary};
    std::string loadedPath;
    bool recovered {false};
};

// Application-level project state coordinator. It deliberately remains UI and
// platform independent: AppKit menus/buttons call this layer, while tests can
// verify save/recovery/undo/autosave behavior without a graphical environment.
class ProjectSession final {
public:
    explicit ProjectSession(double sampleRate = 48000.0, std::size_t historyCapacity = 128U);

    [[nodiscard]] Project& project() noexcept { return project_; }
    [[nodiscard]] const Project& project() const noexcept { return project_; }
    [[nodiscard]] ProjectHistory& history() noexcept { return history_; }
    [[nodiscard]] const ProjectHistory& history() const noexcept { return history_; }

    [[nodiscard]] const std::string& projectPath() const noexcept { return projectPath_; }
    [[nodiscard]] bool dirty() const noexcept { return dirty_; }
    [[nodiscard]] bool hasProjectPath() const noexcept { return !projectPath_.empty(); }

    void setBeforeSaveCallback(std::function<void()> callback) { beforeSave_ = std::move(callback); }
    void setRuntimeRebuildCallback(std::function<void()> callback) { runtimeRebuild_ = std::move(callback); }

    void newProject(double sampleRate = 48000.0);
    ProjectSessionLoadResult open(const std::string& path);
    void save();
    void saveAs(const std::string& path);
    void autosave();

    void beginEdit(std::string label);
    void commitEdit();
    void cancelEdit();
    bool undo();
    bool redo();
    void markDirty() noexcept { dirty_ = true; }

    // Timer-driven control-thread service. Autosave is attempted only for dirty
    // named projects and never overwrites the primary project file.
    void setAutosaveIntervalSeconds(double seconds);
    [[nodiscard]] double autosaveIntervalSeconds() const noexcept { return autosaveIntervalSeconds_; }
    bool serviceAutosave(double monotonicSeconds);
    [[nodiscard]] const std::string& lastAutosaveError() const noexcept { return lastAutosaveError_; }

private:
    static Project makeEmptyProject(double sampleRate);
    void rebuildRuntime();

    Project project_;
    ProjectHistory history_;
    std::string projectPath_;
    bool dirty_ {false};
    double autosaveIntervalSeconds_ {120.0};
    double nextAutosaveAt_ {0.0};
    std::string lastAutosaveError_;
    std::function<void()> beforeSave_;
    std::function<void()> runtimeRebuild_;
};

} // namespace silveton
