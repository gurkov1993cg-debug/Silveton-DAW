#pragma once
#include <atomic>
#include <cstdint>

namespace silveton {

class Transport {
public:
    enum class State : std::uint8_t { Stopped = 0, Playing = 1 };

    void setSampleRate(double sampleRate);
    [[nodiscard]] double sampleRate() const noexcept { return sampleRate_.load(std::memory_order_relaxed); }

    void play() noexcept { state_.store(State::Playing, std::memory_order_release); }
    void stop() noexcept { state_.store(State::Stopped, std::memory_order_release); }
    [[nodiscard]] bool isPlaying() const noexcept { return state_.load(std::memory_order_acquire) == State::Playing; }

    void seekSamples(std::int64_t samplePosition) noexcept;
    void seekSeconds(double seconds) noexcept;
    [[nodiscard]] std::int64_t positionSamples() const noexcept { return positionSamples_.load(std::memory_order_acquire); }
    [[nodiscard]] double positionSeconds() const noexcept;

    void setCycleRange(bool enabled, std::int64_t startSample, std::int64_t endSample);
    [[nodiscard]] bool cycleEnabled() const noexcept { return cycleEnabled_.load(std::memory_order_acquire); }
    [[nodiscard]] std::int64_t cycleStartSample() const noexcept { return cycleStartSample_.load(std::memory_order_acquire); }
    [[nodiscard]] std::int64_t cycleEndSample() const noexcept { return cycleEndSample_.load(std::memory_order_acquire); }
    [[nodiscard]] std::uint64_t cyclePass() const noexcept { return cyclePass_.load(std::memory_order_acquire); }

    void advance(std::uint32_t frames) noexcept;

private:
    std::atomic<State> state_ {State::Stopped};
    std::atomic<std::int64_t> positionSamples_ {0};
    std::atomic<double> sampleRate_ {48000.0};
    std::atomic<bool> cycleEnabled_ {false};
    std::atomic<std::int64_t> cycleStartSample_ {0};
    std::atomic<std::int64_t> cycleEndSample_ {0};
    std::atomic<std::uint64_t> cyclePass_ {0U};
};

} // namespace silveton
