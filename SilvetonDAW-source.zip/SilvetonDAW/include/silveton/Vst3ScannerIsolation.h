#pragma once
#include "silveton/Vst3Blacklist.h"
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

struct Vst3ScanRecord {
    std::string modulePath;
    std::string classId;
    std::string name;
    std::string vendor;
    std::string version;
};

struct Vst3IsolatedScanResult {
    bool skippedBlacklisted {false};
    bool timedOut {false};
    bool crashedOrFailed {false};
    int exitCode {0};
    std::string error;
    std::vector<Vst3ScanRecord> plugins;
};

// Runs one module in an external scanner process. The scanner protocol is a temp
// file, not a pipe, so a verbose/crashed child cannot deadlock the DAW parent.
Vst3IsolatedScanResult scanVst3ModuleIsolated(const std::string& scannerExecutable,
                                              const std::string& modulePath,
                                              std::uint32_t timeoutMs,
                                              Vst3Blacklist& blacklist);

// Shared scanner file protocol helpers.
std::string encodeVst3ScanField(const std::string& value);
bool decodeVst3ScanField(const std::string& value, std::string& out);

} // namespace silveton
