#pragma once
#include "silveton/TempoMap.h"
#include <cstddef>
#include <cstdint>

namespace silveton {

struct MetronomeBeatEvent {
    std::int32_t frameOffset {0};
    std::int64_t bar {1};
    std::uint16_t beat {1U};
    bool accent {false};
};

class MetronomeClock {
public:
    // Realtime-safe beat scheduler. No allocation, locks, or file I/O.
    [[nodiscard]] static std::size_t eventsForBlock(const TempoMap& tempoMap,
                                                    std::int64_t blockStartSample,
                                                    std::uint32_t frames,
                                                    MetronomeBeatEvent* output,
                                                    std::size_t capacity) noexcept;
};

class CountInPlanner {
public:
    // Returns a position `bars` complete musical bars before recordStartSample,
    // preserving the record point's offset inside its bar when possible.
    [[nodiscard]] static std::int64_t startSample(const TempoMap& tempoMap,
                                                  std::int64_t recordStartSample,
                                                  std::uint32_t bars) noexcept;
};

} // namespace silveton
