#pragma once
#include "silveton/DawCore.h"
#include "silveton/MidiInput.h"
#include "silveton/MidiTimeline.h"
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton {
class Vst3RuntimeRack;

// Triple-buffered immutable project-MIDI publication. Compilation of parts,
// loops and tempo-map positions happens on the control thread. The audio thread
// only swaps a prepared snapshot and queues already-timestamped events.
class MidiPlaybackScheduler final {
public:
    MidiPlaybackScheduler();
    std::uint64_t publish(const Project& project);
    [[nodiscard]] bool publicationPending() const noexcept;
    [[nodiscard]] std::uint64_t liveGeneration() const noexcept { return liveGeneration_.load(std::memory_order_acquire); }
    std::size_t queueBlock(Vst3RuntimeRack& rack,
                           MidiInputCapture* liveInput,
                           std::int64_t blockStartSample,
                           std::uint32_t frames) noexcept;

private:
    enum class State : std::uint8_t { Free=0U, Writing=1U, Pending=2U, Live=3U };
    struct PortPlan { int port {-1}; MidiRenderPlan plan; };
    struct Slot { std::vector<PortPlan> plans; std::uint64_t generation {0U}; };
    std::size_t acquireFree();
    void adoptPending() noexcept;
    std::array<Slot,3U> slots_ {};
    std::array<std::atomic<State>,3U> states_ {};
    std::atomic<int> pending_ {-1};
    std::atomic<int> live_ {0};
    std::atomic<std::uint64_t> liveGeneration_ {0U};
    std::uint64_t nextGeneration_ {1U};
};

} // namespace silveton
