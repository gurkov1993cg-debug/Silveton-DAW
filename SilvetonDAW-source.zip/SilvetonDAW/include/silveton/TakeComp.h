#pragma once
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

class TakeLaneBuilder {
public:
    // Converts the realtime-safe recording span journal into nondestructive take
    // lanes. The WAV is not copied; every take clip references a source range in
    // the one recorded file.
    [[nodiscard]] static std::vector<ProjectTakeLane> fromRecordedTimelineSpans(
        const std::string& audioPath,
        std::uint64_t sourceFrames,
        const std::vector<RecordedTimelineSpan>& spans,
        bool spanLogOverflowed = false,
        std::uint32_t sourceChannels = 0U,
        std::uint32_t sourceSampleRate = 0U);
};

class CompEditor {
public:
    static constexpr std::size_t kMaxUndoSteps = 128U;

    CompEditor(Project& project, std::size_t trackIndex);

    // Overwrites the requested timeline range with material from one take clip.
    // Existing comp sections outside the range are preserved. crossfadeSamples
    // applies at the new left boundary and at the preserved right boundary.
    [[nodiscard]] std::uint64_t selectRange(std::uint64_t takeLaneId,
                                            std::uint64_t takeClipId,
                                            std::int64_t timelineStartSample,
                                            std::int64_t timelineEndSample,
                                            std::uint64_t crossfadeSamples = 0U);
    void clearRange(std::int64_t timelineStartSample,
                    std::int64_t timelineEndSample);
    void clearComp();

    // Rebuilds ProjectTrack::clips from the logical comp. This is the exact
    // active clip list consumed by AudioEngine.
    void rebuildActiveComp();

    [[nodiscard]] bool canUndo() const noexcept { return !undo_.empty(); }
    [[nodiscard]] bool canRedo() const noexcept { return !redo_.empty(); }
    bool undo();
    bool redo();
    void clearHistory() noexcept;

private:
    struct Snapshot {
        std::vector<ProjectCompSection> sections;
        std::vector<ProjectAudioClip> clips;
    };
    struct Command { Snapshot before; Snapshot after; };

    [[nodiscard]] ProjectTrack& track();
    [[nodiscard]] const ProjectTrack& track() const;
    [[nodiscard]] const ProjectTakeLane& findLane(std::uint64_t laneId) const;
    [[nodiscard]] const ProjectAudioClip& findTakeClip(std::uint64_t laneId,
                                                       std::uint64_t clipId) const;
    [[nodiscard]] std::uint64_t nextSectionId() const;
    static void validateTakeLane(const ProjectTakeLane& lane);
    static void validateCompSection(const ProjectCompSection& section);
    void commit(Snapshot before);
    [[nodiscard]] Snapshot snapshot() const;
    void restore(Snapshot state);

    Project& project_;
    std::size_t trackIndex_ {0U};
    std::vector<Command> undo_;
    std::vector<Command> redo_;
};

} // namespace silveton
