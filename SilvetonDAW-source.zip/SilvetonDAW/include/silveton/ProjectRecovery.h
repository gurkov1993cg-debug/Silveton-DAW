#pragma once
#include "silveton/DawCore.h"
#include <cstdint>
#include <string>

namespace silveton {

enum class ProjectRecoverySource : std::uint8_t {
    Primary = 0U,
    Autosave = 1U,
    Backup = 2U
};

struct ProjectRecoveryResult {
    Project project;
    ProjectRecoverySource source {ProjectRecoverySource::Primary};
    std::string path;
};

class ProjectRecovery final {
public:
    // Writes a validated temporary project first. Only after the temporary file
    // can be loaded successfully is the previous project rotated to .bak and the
    // new project atomically renamed into place on the same filesystem.
    static void safeSave(const Project& project, const std::string& projectPath);

    // Autosave never overwrites the user's main project. It uses the same
    // validated-temp + rename contract on `<project>.autosave`.
    static void autosave(const Project& project, const std::string& projectPath);

    // Tries primary -> autosave -> backup. A candidate is accepted only if the
    // complete Project::load validation succeeds.
    static ProjectRecoveryResult loadBestAvailable(const std::string& projectPath);

    [[nodiscard]] static std::string backupPath(const std::string& projectPath);
    [[nodiscard]] static std::string autosavePath(const std::string& projectPath);
};

} // namespace silveton
