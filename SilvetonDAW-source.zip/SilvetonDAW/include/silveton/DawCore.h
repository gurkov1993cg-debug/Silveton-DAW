#pragma once
#include "silveton/AudioBuffer.h"
#include "silveton/WavFile.h"
#include "silveton/MixMath.h"
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <map>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace silveton {
struct AutomationPoint { std::int64_t sample{}; float value{}; };
class AutomationLane {
public:
 void add(std::int64_t s,float v); float valueAt(std::int64_t s,float fallback) const noexcept;
 const std::vector<AutomationPoint>& points() const noexcept { return p_; }
private: std::vector<AutomationPoint> p_;
};
struct MidiEvent { std::int64_t sample{}; std::uint8_t status{}, data1{}, data2{}; };
class MidiTrack { public: void add(MidiEvent e); const std::vector<MidiEvent>& events() const noexcept{return e_;} std::vector<MidiEvent> range(std::int64_t a,std::int64_t b) const; private:std::vector<MidiEvent> e_;};
class AudioEditor {
public:
 static AudioBuffer trim(const AudioBuffer&,std::uint64_t start,std::uint64_t length);
 static AudioBuffer reverse(const AudioBuffer&);
 static void fadeIn(AudioBuffer&,std::uint64_t frames);
 static void fadeOut(AudioBuffer&,std::uint64_t frames);
 static AudioBuffer resampleLinear(const AudioBuffer&,double ratio);
 static AudioBuffer timeStretch(const AudioBuffer&,double ratio);
 static AudioBuffer pitchShift(const AudioBuffer&,double semitones);
};
struct Route { std::size_t from{}, to{}; float gain{1.0f}; };
class RoutingGraph {
public: void setNodeCount(std::size_t n); void addRoute(Route r); std::vector<std::size_t> topologicalOrder() const; const std::vector<Route>& routes() const noexcept{return r_;}
private:std::size_t n_{};std::vector<Route> r_;
};
class DelayCompensator {
public: void setLatencies(const std::vector<std::uint32_t>&); std::uint32_t delayFor(std::size_t i) const; std::uint32_t maxLatency() const noexcept{return max_;}
private:std::vector<std::uint32_t>d_;std::uint32_t max_{};
};
struct ProjectTrack {
    std::string name;
    std::string audioPath;
    float gainDb{};
    float pan{};
    bool mute{};
    bool useDualStereoPan{false};
    float stereoLeftPan{-1.0F};
    float stereoRightPan{1.0F};
};
struct Project {
    double sampleRate{48000};
    double tempo{120};
    PanDepth panDepth{PanDepth::Minus3dB};
    float masterFaderDb{0.0F};
    std::vector<ProjectTrack> tracks;
    void save(const std::string&) const;
    static Project load(const std::string&);
};

struct RecorderStatus {
    bool recording {false};
    bool faulted {false};
    bool overflowed {false};
    bool writerError {false};
    std::uint64_t framesAccepted {0U};
    std::uint64_t framesWritten {0U};
    std::uint64_t droppedFrames {0U};
};

class Recorder {
public:
    Recorder() = default;
    ~Recorder();
    Recorder(const Recorder&) = delete;
    Recorder& operator=(const Recorder&) = delete;

    void prepare(std::uint32_t channels,
                 std::uint32_t sampleRate = 48000U,
                 std::uint32_t ringCapacityFrames = 262144U);

    void start(const std::string& path);
    void start();
    void stop() noexcept;

    [[nodiscard]] bool recording() const noexcept { return recording_.load(std::memory_order_acquire); }

    [[nodiscard]] bool push(const float* const* in,
                            std::uint32_t channels,
                            std::uint32_t frames) noexcept;

    [[nodiscard]] RecorderStatus status() const noexcept;
    [[nodiscard]] const std::string& path() const noexcept { return path_; }
    [[nodiscard]] const AudioBuffer& captured() const;

private:
    void writerLoop() noexcept;
    void writePlaceholderHeader();
    void finalizeHeader();
    void markFault(bool writerError) noexcept;

    std::uint32_t ch_ {0U};
    std::uint32_t sampleRate_ {0U};
    std::uint64_t ringCapacityFrames_ {0U};
    std::vector<float> ring_;

    std::atomic<std::uint64_t> writeFrame_ {0U};
    std::atomic<std::uint64_t> readFrame_ {0U};
    std::atomic<std::uint64_t> framesAccepted_ {0U};
    std::atomic<std::uint64_t> framesWritten_ {0U};
    std::atomic<std::uint64_t> droppedFrames_ {0U};
    std::atomic<std::uint32_t> activePushes_ {0U};
    std::atomic<bool> recording_ {false};
    std::atomic<bool> writerStop_ {false};
    std::atomic<bool> faulted_ {false};
    std::atomic<bool> overflowed_ {false};
    std::atomic<bool> writerError_ {false};

    std::string path_;
    std::ofstream out_;
    std::thread writerThread_;

    mutable AudioBuffer captureCache_;
    mutable bool captureCacheValid_ {false};
    std::uint64_t dataBytesWritten_ {0U};
};
}
