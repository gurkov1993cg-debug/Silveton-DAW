#pragma once
// Silveton Native — built-in processors that live inside the DAW itself.
//
// Every native processor implements the same IVst3PluginInstance contract as a
// hosted Steinberg VST3 plug-in. They are therefore inserted, bypassed,
// automated (sample accurate), state-saved, routed (sidechain) and delay-
// compensated through exactly the same Vst3RuntimeRack / ProcessorGraph path.
// Project slots reference them with modulePath == kNativeModulePath.
#include "silveton/Vst3Runtime.h"

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace silveton {

inline constexpr const char* kNativeModulePath = "silveton:native";

enum class NativeParamScale : std::uint8_t { Linear = 0U, Logarithmic = 1U, Toggle = 2U, Choice = 3U, Integer = 4U };

struct NativeParameterInfo {
    std::uint32_t id {0U};
    std::string name;
    std::string units;
    double minValue {0.0};
    double maxValue {1.0};
    double defaultValue {0.0};
    NativeParamScale scale {NativeParamScale::Linear};
    std::vector<std::string> choices;
};

struct NativePluginInfo {
    std::string classId;
    std::string name;
    std::string category;   // "EQ", "Dynamics", "Delay", "Reverb", "Instrument"
    bool instrument {false};
    bool sidechain {false};
};

[[nodiscard]] const std::vector<NativePluginInfo>& nativePluginCatalog();
[[nodiscard]] bool isNativeModulePath(const std::string& modulePath) noexcept;

// Fixed-capacity single-producer/single-consumer queue. No allocation after
// construction; push/pop are wait-free.
template <typename T, std::size_t Capacity>
class NativeSpscQueue {
public:
    bool push(const T& value) noexcept {
        const std::size_t head = head_.load(std::memory_order_relaxed);
        const std::size_t next = (head + 1U) % Capacity;
        if (next == tail_.load(std::memory_order_acquire)) return false;
        items_[head] = value;
        head_.store(next, std::memory_order_release);
        return true;
    }
    bool pop(T& value) noexcept {
        const std::size_t tail = tail_.load(std::memory_order_relaxed);
        if (tail == head_.load(std::memory_order_acquire)) return false;
        value = items_[tail];
        tail_.store((tail + 1U) % Capacity, std::memory_order_release);
        return true;
    }
private:
    T items_[Capacity] {};
    std::atomic<std::size_t> head_ {0U};
    std::atomic<std::size_t> tail_ {0U};
};

class NativePlugin : public IVst3PluginInstance {
public:
    NativePlugin(const NativePluginInfo& info, std::vector<NativeParameterInfo> parameters);
    ~NativePlugin() override;

    [[nodiscard]] const NativePluginInfo& info() const noexcept { return info_; }
    [[nodiscard]] const std::vector<NativeParameterInfo>& parameters() const noexcept { return parameters_; }
    [[nodiscard]] double normalizedValue(std::uint32_t id) const noexcept;
    [[nodiscard]] double plainValue(std::uint32_t id) const noexcept;
    [[nodiscard]] std::string formatValue(std::uint32_t id) const;
    [[nodiscard]] static double toNormalized(const NativeParameterInfo& p, double plain) noexcept;
    [[nodiscard]] static double toPlain(const NativeParameterInfo& p, double normalized) noexcept;

    // Control-thread (GUI) edits. The value is visible to the audio thread at
    // the next block and an automation gesture is queued for the rack so Write/
    // Touch/Latch lanes record exactly like a hosted VST3 editor would.
    void beginEdit(std::uint32_t id);
    void setFromEditor(std::uint32_t id, double plain);
    void endEdit(std::uint32_t id);
    // Plain control-thread set without recording a gesture (presets, tests).
    void setPlainValue(std::uint32_t id, double plain) noexcept;

    // Realtime meters exposed to the GUI (e.g. gain reduction dB). Index is
    // processor specific; out-of-range returns 0.
    [[nodiscard]] float meter(std::size_t index) const noexcept;

    // IVst3PluginInstance
    [[nodiscard]] const std::string& modulePath() const noexcept override;
    [[nodiscard]] const std::string& classId() const noexcept override { return info_.classId; }
    [[nodiscard]] std::size_t inputBusChannelCount(std::size_t bus) const noexcept override;
    [[nodiscard]] std::size_t outputBusChannelCount(std::size_t bus) const noexcept override;
    bool setComponentState(const std::vector<std::uint8_t>& state) override;
    bool setControllerState(const std::vector<std::uint8_t>& state) override;
    [[nodiscard]] std::vector<std::uint8_t> componentState() const override;
    [[nodiscard]] std::vector<std::uint8_t> controllerState() const override;
    bool savePreset(const std::string& path) const override;
    bool loadPreset(const std::string& path) override;
    [[nodiscard]] bool hasEventInput() const noexcept override { return info_.instrument; }
    bool queueMidi(const Vst3MidiEvent& event) noexcept override;
    bool queueParameter(std::uint32_t parameterId, double normalized, std::int32_t frameOffset) noexcept override;
    bool popAutomationGesture(AutomationGesture& event) noexcept override;
    bool popOutputParameter(Vst3OutputParameterChange& change) noexcept override;
    [[nodiscard]] std::uint32_t consumeRestartFlags() noexcept override;

    // IRoutedTrackProcessor / ITrackProcessor
    [[nodiscard]] std::size_t inputBusCount() const noexcept override;
    [[nodiscard]] std::size_t outputBusCount() const noexcept override { return 1U; }
    void prepare(double sampleRate, std::uint32_t maxFrames) override;
    void reset() noexcept override;
    [[nodiscard]] std::uint32_t latencySamples() const noexcept override { return latency_.load(std::memory_order_acquire); }
    [[nodiscard]] std::uint64_t tailSamples() const noexcept override;
    void process(float* left, float* right, std::uint32_t frames, const ProcessorContext& context) noexcept override;
    bool processBuses(const ConstStereoBus* inputs, std::size_t inputBusCount,
                      StereoBus* outputs, std::size_t outputBusCount,
                      std::uint32_t frames, const ProcessorContext& context) noexcept override;

protected:
    struct RenderIO {
        const float* inL {nullptr};
        const float* inR {nullptr};
        const float* sideL {nullptr};   // null when no sidechain bus is connected
        const float* sideR {nullptr};
        float* outL {nullptr};
        float* outR {nullptr};
        std::uint32_t frames {0U};
    };

    // Plain parameter value for the current sub-block (audio thread).
    [[nodiscard]] double p(std::uint32_t id) const noexcept { return current_[id]; }
    [[nodiscard]] double sampleRate() const noexcept { return sampleRate_; }
    void setMeter(std::size_t index, float value) noexcept;
    void setLatency(std::uint32_t samples) noexcept { latency_.store(samples, std::memory_order_release); }

    virtual void onPrepare(double sampleRate, std::uint32_t maxFrames) = 0;
    virtual void onReset() noexcept = 0;
    virtual void onMidi(const Vst3MidiEvent&) noexcept {}
    // Called once per sub-block after parameters changed (and on first block).
    virtual void onParametersChanged() noexcept {}
    virtual void render(const RenderIO& io, const ProcessorContext& context) noexcept = 0;
    [[nodiscard]] virtual std::uint64_t computeTailSamples() const noexcept { return 0U; }

private:
    struct ParamEvent { std::uint32_t id {0U}; std::int32_t offset {0}; double normalized {0.0}; };
    void snapshotParameters() noexcept;
    void renderRange(const ConstStereoBus* inputs, std::size_t inputCount, StereoBus out,
                     std::uint32_t start, std::uint32_t count, const ProcessorContext& context) noexcept;

    NativePluginInfo info_;
    std::vector<NativeParameterInfo> parameters_;
    std::unique_ptr<std::atomic<double>[]> normalized_;
    std::vector<double> current_;
    std::vector<double> lastApplied_;
    std::atomic<bool> uiDirty_ {true};
    double sampleRate_ {48000.0};
    std::uint32_t maxFrames_ {0U};
    std::atomic<std::uint32_t> latency_ {0U};
    std::atomic<std::uint32_t> restartFlags_ {0U};
    NativeSpscQueue<ParamEvent, 1024U> paramEvents_;
    NativeSpscQueue<Vst3MidiEvent, 2048U> midiEvents_;
    ParamEvent blockParams_[512] {};
    Vst3MidiEvent blockMidi_[1024] {};
    std::vector<float> silentL_;
    std::vector<float> silentR_;
    std::atomic<float> meters_[4] {};
    mutable std::mutex gestureMutex_;
    std::deque<AutomationGesture> gestures_;
};

[[nodiscard]] std::unique_ptr<NativePlugin> createNativePlugin(const std::string& classId, std::string& failureReason);

// Routes kNativeModulePath slots to Silveton Native and everything else to an
// external VST3 factory (normally Vst3Host). `external` may be null.
class CompositeInstanceFactory final : public IVst3InstanceFactory {
public:
    explicit CompositeInstanceFactory(IVst3InstanceFactory* external) noexcept : external_(external) {}
    std::unique_ptr<IVst3PluginInstance> create(const std::string& modulePath,
                                                const std::string& classId,
                                                std::string& failureReason) override;
private:
    IVst3InstanceFactory* external_ {nullptr};
};

} // namespace silveton
