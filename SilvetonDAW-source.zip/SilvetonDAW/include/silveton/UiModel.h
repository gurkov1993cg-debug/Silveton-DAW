#pragma once
// Platform-independent presentation model for the Silveton interface: the
// arrange row layout, timeline <-> pixel mapping, adaptive musical grid and
// counter formatting. Kept out of the AppKit code so it is unit tested.
#include "silveton/DawCore.h"
#include "silveton/TempoMap.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

enum class ArrangeRowKind : std::uint8_t { Folder = 0U, Audio = 1U, Midi = 2U };

struct ArrangeRow {
    ArrangeRowKind kind {ArrangeRowKind::Audio};
    std::size_t index {0U};     // folder vector index, audio track index or MIDI track index
    int depth {0};              // folder nesting depth (indent)
    bool drivesInstrument {false};  // MIDI row that feeds an instrument on the audio row above
};

// Folders (depth-first) with their tracks, MIDI tracks directly beneath the
// instrument track they drive, collapsed folders hide their content.
[[nodiscard]] std::vector<ArrangeRow> buildArrangeRows(const Project& project);

// Index of the audio track whose instrument insert listens on `port`, or -1.
[[nodiscard]] int instrumentTrackForPort(const Project& project, int port) noexcept;
// Next unused MIDI input port across every plug-in slot.
[[nodiscard]] int nextFreeMidiPort(const Project& project) noexcept;

struct TimelineMapping {
    double sampleRate {48000.0};
    double pixelsPerSecond {90.0};
    double originX {0.0};        // x of timeline sample 0 before scrolling
    double scrollSeconds {0.0};  // left edge of the visible window
    [[nodiscard]] double xForSample(std::int64_t sample) const noexcept;
    [[nodiscard]] std::int64_t sampleForX(double x) const noexcept;
};

struct GridLine {
    std::int64_t sample {0};
    int level {0};              // 0 = bar, 1 = beat, 2 = subdivision
    std::string label;          // bar number for level 0 when labelled
};

// Picks bar/beat/16th density so lines stay >= minPixels apart.
[[nodiscard]] std::vector<GridLine> buildGrid(const TempoMap& tempoMap, const TimelineMapping& mapping,
                                              double visibleWidth, double minPixels = 9.0);

// "bar.beat.tick" with 960 ticks per quarter, e.g. "12.3.480".
[[nodiscard]] std::string formatBarsBeats(const TempoMap& tempoMap, std::int64_t sample);
// "mm:ss.mmm" (hours are prefixed when needed).
[[nodiscard]] std::string formatClock(double seconds);
// Parses "bar[.beat[.tick]]" back to a sample; returns false on invalid input.
[[nodiscard]] bool parseBarsBeats(const TempoMap& tempoMap, const std::string& text, std::int64_t& sample);

// Converts a value to fader position (0..1) using a musically spaced dB curve
// and back. -inf..+12 dB, unity at ~0.75.
[[nodiscard]] double faderPositionForDb(double db) noexcept;
[[nodiscard]] double dbForFaderPosition(double position) noexcept;

} // namespace silveton
