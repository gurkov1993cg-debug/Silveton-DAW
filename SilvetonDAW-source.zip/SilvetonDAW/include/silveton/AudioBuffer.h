#pragma once
#include <cstddef>
#include <vector>

namespace silveton {

class AudioBuffer {
public:
    AudioBuffer() = default;
    AudioBuffer(std::size_t channels, std::size_t frames);

    void resize(std::size_t channels, std::size_t frames);
    void clear() noexcept;

    [[nodiscard]] std::size_t channels() const noexcept { return data_.size(); }
    [[nodiscard]] std::size_t frames() const noexcept { return data_.empty() ? 0U : data_.front().size(); }

    float* channelData(std::size_t channel);
    const float* channelData(std::size_t channel) const;

    float& sample(std::size_t channel, std::size_t frame);
    const float& sample(std::size_t channel, std::size_t frame) const;

private:
    std::vector<std::vector<float>> data_;
};

} // namespace silveton
