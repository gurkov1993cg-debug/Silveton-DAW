#pragma once

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <memory>
#include <string>
#include <thread>
#include <vector>

namespace silveton {

struct DiskStreamStatus {
    bool ioError {false};
    std::uint64_t cacheLoads {0U};
    std::uint64_t underflowBlocks {0U};
    std::uint64_t underflowFrames {0U};
};

struct DiskBlockView {
    const float* interleaved {nullptr};
    std::uint32_t channels {0U};
    std::uint32_t frames {0U};
    std::uint32_t frameOffset {0U};
    std::uint32_t pageIndex {0U};
    bool acquired {false};
};

class DiskAudioSource {
public:
    DiskAudioSource(const DiskAudioSource&) = delete;
    DiskAudioSource& operator=(const DiskAudioSource&) = delete;

    [[nodiscard]] const std::string& path() const noexcept { return path_; }
    [[nodiscard]] std::uint32_t sampleRate() const noexcept { return sampleRate_; }
    [[nodiscard]] std::uint32_t channels() const noexcept { return channels_; }
    [[nodiscard]] std::uint64_t frames() const noexcept { return totalFrames_; }
    [[nodiscard]] std::uint32_t cacheFrames() const noexcept { return cacheFrames_; }

    // Audio-thread safe: no allocation, file I/O, locks, logging, or sleeping.
    [[nodiscard]] bool acquire(std::uint64_t sourceFrame,
                               std::uint32_t frames,
                               DiskBlockView& view) noexcept;
    void release(DiskBlockView& view) noexcept;
    void request(std::uint64_t sourceFrame) noexcept;

    [[nodiscard]] DiskStreamStatus status() const noexcept;
    void clearUnderflowCounters() noexcept;

private:
    friend class DiskStreamManager;

    struct Page {
        std::vector<float> interleaved;
        std::atomic<std::uint32_t> readers {0U};
        std::atomic<std::uint64_t> startFrame {0U};
        std::atomic<std::uint32_t> validFrames {0U};
        std::atomic<bool> valid {false};
    };

    DiskAudioSource(std::string path,
                    std::uint32_t sampleRate,
                    std::uint32_t channels,
                    std::uint16_t formatTag,
                    std::uint16_t bitsPerSample,
                    std::uint16_t blockAlign,
                    bool bigEndian,
                    std::uint64_t dataOffset,
                    std::uint64_t dataBytes,
                    std::uint32_t cacheFrames);

    [[nodiscard]] bool pageContains(std::uint32_t pageIndex,
                                    std::uint64_t sourceFrame,
                                    std::uint32_t frames) const noexcept;

    std::string path_;
    std::uint32_t sampleRate_ {0U};
    std::uint32_t channels_ {0U};
    std::uint16_t formatTag_ {0U};
    std::uint16_t bitsPerSample_ {0U};
    std::uint16_t blockAlign_ {0U};
    bool bigEndian_ {false};
    std::uint64_t dataOffset_ {0U};
    std::uint64_t totalFrames_ {0U};
    std::uint32_t cacheFrames_ {0U};

    std::array<Page, 3U> pages_;
    std::atomic<std::uint32_t> activePage_ {0U};
    std::atomic<std::uint64_t> requestedFrame_ {0U};
    std::atomic<bool> ioError_ {false};
    std::atomic<std::uint64_t> cacheLoads_ {0U};
    std::atomic<std::uint64_t> underflowBlocks_ {0U};
    std::atomic<std::uint64_t> underflowFrames_ {0U};
};

class DiskStreamManager {
public:
    static constexpr std::size_t kMaxSources = 256U;

    explicit DiskStreamManager(std::size_t maxOpenFiles = 0U);
    ~DiskStreamManager();
    DiskStreamManager(const DiskStreamManager&) = delete;
    DiskStreamManager& operator=(const DiskStreamManager&) = delete;

    DiskAudioSource& addSource(const std::string& path,
                               std::uint32_t cacheFrames = 16384U);
    void clearSources();
    [[nodiscard]] std::size_t sourceCount() const noexcept { return sources_.size(); }
    [[nodiscard]] DiskAudioSource& source(std::size_t index);
    [[nodiscard]] const DiskAudioSource& source(std::size_t index) const;
    [[nodiscard]] std::shared_ptr<DiskAudioSource> sourceHandle(std::size_t index) const;

    void start();
    void stop() noexcept;
    [[nodiscard]] bool running() const noexcept { return running_.load(std::memory_order_acquire); }

    // Control-thread priming. Returns false on timeout or I/O failure.
    [[nodiscard]] bool prime(std::uint64_t sourceFrame = 0U,
                             std::uint32_t timeoutMilliseconds = 5000U);

private:
    struct OpenFile {
        std::string path;
        std::FILE* file {nullptr};
        std::uint64_t lastUse {0U};
    };

    struct AudioMeta {
        std::uint32_t sampleRate {0U};
        std::uint32_t channels {0U};
        std::uint16_t formatTag {0U};
        std::uint16_t bitsPerSample {0U};
        std::uint16_t blockAlign {0U};
        bool bigEndian {false};
        std::uint64_t dataOffset {0U};
        std::uint64_t dataBytes {0U};
    };

    [[nodiscard]] static AudioMeta inspectAudioFile(const std::string& path);
    [[nodiscard]] std::FILE* acquireFile(const std::string& path) noexcept;
    void closeFiles() noexcept;
    void workerLoop() noexcept;
    void service(DiskAudioSource& source) noexcept;
    [[nodiscard]] bool fillPage(DiskAudioSource& source,
                                std::uint32_t pageIndex,
                                std::uint64_t startFrame) noexcept;
    [[nodiscard]] std::uint32_t chooseFillPage(const DiskAudioSource& source,
                                               std::uint32_t avoidPage) const noexcept;

    std::size_t maxOpenFiles_ {48U};
    std::vector<std::shared_ptr<DiskAudioSource>> sources_;
    std::vector<OpenFile> openFiles_;
    std::vector<std::uint8_t> readScratch_;
    std::uint64_t fileUseCounter_ {0U};
    std::atomic<bool> running_ {false};
    std::atomic<bool> stopRequested_ {false};
    std::thread worker_;
};

} // namespace silveton
