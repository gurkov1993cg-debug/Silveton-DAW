#pragma once
// Offline (non-realtime) audio processing for clips — Silveton's equivalent
// of direct offline processing. The clip's current source range is rendered
// through the process into a new Float32 WAV and the clip is relinked to it.
// The original media file is never modified; ProjectSession undo restores the
// previous clip reference.
#include "silveton/AudioBuffer.h"
#include "silveton/DawCore.h"

#include <cstddef>
#include <cstdint>
#include <string>

namespace silveton {

class AudioEngine;
class Vst3RuntimeRack;

enum class AudioProcess : std::uint8_t {
    Normalize, Gain, Reverse, InvertPhase, RemoveDc, Silence, FadeIn, FadeOut,
    StereoFlip, MonoSum, TimeStretch, PitchShift
};
enum class FadeShape : std::uint8_t { Linear, EqualPower, Exponential };

struct AudioProcessOptions {
    double normalizeTargetDb {-0.3};
    double gainDb {0.0};
    FadeShape fadeShape {FadeShape::EqualPower};
    double stretchRatio {1.0};          // output length / input length
    double semitones {0.0};
    bool preserveFormants {false};
    ElasticAudioQuality quality {ElasticAudioQuality::High};
};

struct AudioProcessResult {
    std::string newPath;
    std::uint64_t frames {0U};
    float peakBefore {0.0F};
    float peakAfter {0.0F};
};

class AudioProcessor final {
public:
    [[nodiscard]] static const char* name(AudioProcess process) noexcept;
    [[nodiscard]] static float peak(const AudioBuffer& buffer) noexcept;
    [[nodiscard]] static AudioBuffer apply(const AudioBuffer& input, AudioProcess process, const AudioProcessOptions& options);
    // Processes the selected clip and relinks it to the rendered file in
    // `outputDirectory`. Throws if the clip or media cannot be read.
    static AudioProcessResult processClip(Project& project, std::size_t trackIndex, std::uint64_t clipId,
                                          AudioProcess process, const AudioProcessOptions& options,
                                          const std::string& outputDirectory);

    struct RenderInPlaceResult {
        std::size_t newTrackIndex {0U};
        std::string path;
        float peak {0.0F};
    };
    // Renders a track "as heard" (inserts, sends, groups, master path) over
    // [start, end) plus processor tails into a new audio track placed below
    // the source. The engine must be prepared, stopped and not driven by a
    // device. The caller rebuilds the runtime and re-applies solo afterwards.
    static RenderInPlaceResult renderInPlace(Project& project, AudioEngine& engine, Vst3RuntimeRack* rack,
                                             std::size_t trackIndex, std::int64_t start, std::int64_t end,
                                             const std::string& outputDirectory, bool muteSource);
};

} // namespace silveton
