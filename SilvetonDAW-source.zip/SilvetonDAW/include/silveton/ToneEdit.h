#pragma once
// Silveton Tone Editor — the maths behind it, free of any window code so it can be tested.
//
// It works on ONE-VOICE audio (a singer, a solo instrument): it finds the pitch of the sound
// over time, cuts it into "tone blocks" (one block per sung note), and lets the user change each
// block — its pitch, how much the pitch wobbles, its colour (formant), its loudness and its
// place in time — and then renders the changed sound again with the highest quality we can do
// (pitch-synchronous overlap-add on pitch marks found in the real waveform, with the voice's
// own formants kept; unvoiced sounds and breath are copied untouched).
//
// Nothing in the original media file is ever changed. The edit (the list of blocks and their
// settings) is small and is stored in the project; the audio is rendered again from the
// original every time.
//
// All positions are samples at the PROJECT rate, counted from the start of the analysed audio.
#include "silveton/AudioBuffer.h"

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

// ===================================================================== scales ==
enum class ToneScaleKind : std::uint8_t {
    Chromatic = 0, Major, NaturalMinor, HarmonicMinor, MelodicMinor, Dorian, Phrygian, Lydian, Mixolydian,
    MajorPentatonic, MinorPentatonic, Blues, WholeTone, Count
};

struct ToneScale {
    ToneScaleKind kind {ToneScaleKind::Chromatic};
    int root {0};   // 0 = C … 11 = B
    static const char* kindName(ToneScaleKind kind) noexcept;
    [[nodiscard]] bool chromatic() const noexcept { return kind == ToneScaleKind::Chromatic; }
    [[nodiscard]] bool contains(int pitchClass) const noexcept;       // pitch class 0..11 (any integer is wrapped)
    // The allowed note closest to `midi` (fractional MIDI note number). Chromatic = the nearest semitone.
    [[nodiscard]] double nearest(double midi) const noexcept;
    [[nodiscard]] std::string name() const;                           // "D Major"
};

// ================================================================== analysis ==
struct ToneAnalysisOptions {
    double lowestHz {60.0};          // lowest voice pitch looked for
    double highestHz {1100.0};       // highest
    double sensitivity {0.5};        // 0..1: higher = weak or rough sounds also count as notes
    double splitSensitivity {0.5};   // 0..1: higher = smaller pitch changes cut a new block
    double minBlockMs {45.0};        // shortest block
};

struct ToneFrames {
    std::size_t hop {0};             // samples between two frames (about 5 ms)
    std::vector<float> hz;           // pitch of each frame; 0 = no pitch (breath, consonant, silence)
    std::vector<float> midi;         // the same as fractional MIDI note number (69 = A4 = 440 Hz); valid where hz > 0
    std::vector<float> rawHz;        // best guess even where the search said "no pitch" (used for blocks drawn by hand); 0 = none
    std::vector<float> level;        // loudness of each frame (RMS, linear)
    [[nodiscard]] std::size_t size() const noexcept { return hz.size(); }
    [[nodiscard]] bool voiced(std::size_t i) const noexcept { return i < hz.size() && hz[i] > 0.0F; }
};

// One tone block (what a note of the singer became after analysis) and everything the user can do to it.
struct ToneBlock {
    std::uint32_t id {0U};
    std::int64_t start {0};          // first sample
    std::int64_t end {0};            // one past the last sample
    float pitch {60.0F};             // heard pitch (fractional MIDI note number)
    float levelDb {-30.0F};          // average loudness
    // ---- the user's changes ----
    float moveCents {0.0F};          // pitch moved by hand (cents)
    float snap {0.0F};               // 0..1: how far the pitch is pulled to the nearest note ("Snap Pitch")
    float flatten {0.0F};            // 0..1: how much of the pitch wobble inside the block is removed ("Flatten")
    float vibrato {1.0F};            // 0..2: size of the pitch wobble that is left (1 = as sung)
    float tiltCents {0.0F};          // the wobble is tilted: this many cents at the end, the opposite at the start
    float formantCents {0.0F};       // colour of the voice: moves the formants (cents), the pitch stays
    float gainDb {0.0F};             // loudness of the block
    bool bypass {false};             // the block is left exactly as sung

    [[nodiscard]] bool touched() const noexcept {
        return moveCents != 0.0F || snap != 0.0F || flatten != 0.0F || vibrato != 1.0F || tiltCents != 0.0F ||
               formantCents != 0.0F || gainDb != 0.0F;
    }
};

// A place in the original sound that is moved to another place in the result ("time bend").
// The first and the last sample of the sound never move.
struct ToneWarpPoint {
    std::int64_t source {0};
    std::int64_t target {0};
};

struct ToneEdit {
    std::vector<ToneBlock> blocks;            // sorted by start, never overlapping
    std::vector<ToneWarpPoint> warp;          // sorted
    ToneScale scale;                          // used by "Snap Pitch" when `snapToScale` is on
    bool snapToScale {false};
    float transitionMs {30.0F};               // how fast the pitch glides from one block to the next when they touch
    std::uint32_t nextId {1U};

    [[nodiscard]] ToneBlock* find(std::uint32_t id) noexcept;
    [[nodiscard]] const ToneBlock* find(std::uint32_t id) const noexcept;
    [[nodiscard]] bool anyChange() const noexcept;       // any block touched or any time bend
};

struct ToneAnalysis {
    double sampleRate {48000.0};
    std::int64_t length {0};         // samples analysed
    ToneFrames frames;
    ToneEdit initial;                // blocks as found automatically, no changes
    ToneAnalysisOptions options;
    bool cancelled {false};
    [[nodiscard]] bool empty() const noexcept { return frames.size() == 0U || initial.blocks.empty(); }
};

class ToneAnalyzer final {
public:
    // Finds the pitch and the tone blocks. `cancel` (optional) is polled; when it becomes true the
    // result has `cancelled` set. `progress` (optional) receives 0..1.
    [[nodiscard]] static ToneAnalysis analyze(const AudioBuffer& audio, double sampleRate, const ToneAnalysisOptions& options,
                                              const std::atomic<bool>* cancel = nullptr, std::atomic<float>* progress = nullptr);
};

// ================================================================= block edit ==
// The pitch a block is going to have after "Snap Pitch" and the manual move (fractional MIDI note).
[[nodiscard]] double toneBlockTargetPitch(const ToneBlock& block, const ToneEdit& edit) noexcept;
// The pitch of one frame of a block after all its settings (fractional MIDI note).
[[nodiscard]] double toneFrameTargetPitch(const ToneBlock& block, const ToneEdit& edit, const ToneAnalysis& analysis, std::size_t frame) noexcept;

class ToneEditing final {
public:
    // Hand-made changes to the blocks. All of them keep the blocks sorted and apart.
    // Returns the id of the (first) block that came out, or 0 when nothing was done.
    static std::uint32_t split(ToneEdit& edit, const ToneAnalysis& analysis, std::uint32_t id, std::int64_t at);
    static std::uint32_t glue(ToneEdit& edit, const ToneAnalysis& analysis, std::uint32_t firstId, std::uint32_t secondId);
    static bool remove(ToneEdit& edit, std::uint32_t id);
    // A block over a part the automatic search missed. The pitch comes from the frames inside; when
    // there is none, `fallbackPitch` is used.
    static std::uint32_t add(ToneEdit& edit, const ToneAnalysis& analysis, std::int64_t start, std::int64_t end, double fallbackPitch);
    static bool setEdges(ToneEdit& edit, const ToneAnalysis& analysis, std::uint32_t id, std::int64_t start, std::int64_t end);
    // The border shared by two blocks that touch moves (both blocks change).
    static bool moveBorder(ToneEdit& edit, const ToneAnalysis& analysis, std::uint32_t leftId, std::uint32_t rightId, std::int64_t position);
    static void resetBlock(ToneEdit& edit, std::uint32_t id);
    static void resetAll(ToneEdit& edit, const ToneAnalysis& analysis);

    // Settings on many blocks (ids empty = every block).
    static void setSnap(ToneEdit& edit, const std::vector<std::uint32_t>& ids, float amount);
    static void setFlatten(ToneEdit& edit, const std::vector<std::uint32_t>& ids, float amount);
    static void setVibrato(ToneEdit& edit, const std::vector<std::uint32_t>& ids, float amount);
    // Moves the pitch of the blocks so that their TARGET pitch is `midi` (a whole note number from dragging).
    static void setTargetPitch(ToneEdit& edit, std::uint32_t id, double midi);
    static void transpose(ToneEdit& edit, const std::vector<std::uint32_t>& ids, double semitones);

    // Time bend. The block is moved so it starts at `newStart` and ends at `newEnd` in the result.
    static bool setBlockTime(ToneEdit& edit, std::uint32_t id, std::int64_t newStart, std::int64_t newEnd, std::int64_t totalLength,
                             std::int64_t minLength);
    // Free bend: a single point of the sound is dragged to another place.
    static bool movePoint(ToneEdit& edit, std::int64_t source, std::int64_t newTarget, std::int64_t totalLength, std::int64_t minGap);
    static bool removeWarpPoint(ToneEdit& edit, std::size_t index);
    // Pulls the block starts toward the nearest grid line (grid in samples, `phase` = where line 0 is). amount 0..1.
    static void snapTiming(ToneEdit& edit, const std::vector<std::uint32_t>& ids, double gridSamples, double phaseSamples, float amount,
                           std::int64_t totalLength, std::int64_t minLength);
    static void clearTiming(ToneEdit& edit);

    // The key that fits the sung notes best (a major or minor scale), and how many percent of the singing it covers.
    static ToneScale detectScale(const ToneEdit& edit, double* coveragePercent = nullptr);
};

// Mapping between positions in the original sound and in the result.
class ToneTimeMap final {
public:
    ToneTimeMap(const std::vector<ToneWarpPoint>& points, std::int64_t length);
    [[nodiscard]] double forward(double source) const noexcept;    // original → result
    [[nodiscard]] double inverse(double target) const noexcept;    // result → original
    [[nodiscard]] bool identity() const noexcept { return identity_; }
    struct Piece { double s0, s1, t0, t1; };
    [[nodiscard]] const std::vector<Piece>& pieces() const noexcept { return pieces_; }
private:
    std::vector<Piece> pieces_;
    bool identity_ {true};
};

// ================================================================== rendering ==
struct ToneRenderOptions {
    double rampMs {7.0};             // cross-fade between changed and untouched sound
};

class ToneRenderer final {
public:
    // The sound after the edit. Same number of channels and samples as `original`.
    // Untouched parts are the original, sample for sample.
    [[nodiscard]] static AudioBuffer render(const AudioBuffer& original, const ToneAnalysis& analysis, const ToneEdit& edit,
                                            const ToneRenderOptions& options = {}, const std::atomic<bool>* cancel = nullptr);
};

// ======================================================================= MIDI ==
struct ToneMidiNote {
    std::int64_t start {0};          // result position (after time bend)
    std::int64_t end {0};
    int pitch {60};                  // MIDI note number
    int velocity {80};
    std::vector<std::pair<std::int64_t, int>> bend;   // (sample, 0..16383, 8192 = centre) when pitch bend is wanted
};

struct ToneMidiOptions {
    bool useBend {false};            // the little pitch moves inside a block become pitch-bend messages
    double bendRangeSemitones {2.0};
    int minVelocity {30};
    int maxVelocity {127};
    bool useTarget {true};           // the corrected pitch (true) or the sung pitch (false)
};

class ToneMidi final {
public:
    [[nodiscard]] static std::vector<ToneMidiNote> extract(const ToneAnalysis& analysis, const ToneEdit& edit, const ToneMidiOptions& options);
};

// ============================================================= text for saving ==
// One edit as text lines (no line contains a newline). Used by the project file.
[[nodiscard]] std::vector<std::string> toneEditToLines(const ToneEdit& edit);
// Reads what toneEditToLines wrote. Throws std::runtime_error on bad input.
[[nodiscard]] ToneEdit toneEditFromLines(const std::vector<std::string>& lines);

} // namespace silveton
