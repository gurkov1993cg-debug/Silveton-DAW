#pragma once
// SILVETON_STUDIO_INTERP_V1 — the Kaiser-windowed sinc from the Silveton
// sampler, used by the DAW for every sample-rate conversion: device input
// (card rate → 96 kHz), device output (96 kHz → card rate), file import and
// export. The kernel is designed exactly like the sampler's Studio mode:
//   * passband 0..20 kHz kept flat,
//   * every image/alias that could land in 0..20 kHz rejected by 110 dB,
//   * Kaiser window, tap count from the Kaiser estimate, 512 polyphase rows
//     with a linear blend between rows, rows normalised to unity gain.
// The sampler designs one kernel per 1/12 octave of playback ratio; the DAW
// converts between two fixed rates, so one kernel is designed per converter.
// Tables are built on the control thread in prepare(); push()/pull() are
// allocation-free and lock-free and may run on the audio thread.
#include "silveton/AudioBuffer.h"

#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton {

struct StudioKernelDesign {
    int taps {0};
    double passbandHz {0.0};   // flat up to here
    double stopbandHz {0.0};   // rejection reached from here (in source Hz)
    double cutoff {0.0};       // cycles per source sample
};

class StudioResampler final {
public:
    static constexpr double kRejectDb = 110.0;
    static constexpr double kAudibleHz = 20000.0;
    static constexpr int kMinTaps = 24;
    static constexpr int kMaxTaps = 128;
    static constexpr int kPhases = 512;

    StudioResampler() = default;

    // Builds the kernel and the history ring. `maxPushFrames` is the largest
    // block push() will receive; `maxPullFrames` the largest pull().
    void prepare(double sourceRate, double destinationRate, std::uint32_t channels,
                 std::uint32_t maxPushFrames, std::uint32_t maxPullFrames);
    void reset() noexcept;
    [[nodiscard]] bool prepared() const noexcept { return taps_ != 0; }
    [[nodiscard]] double ratio() const noexcept { return ratio_; }   // source frames per destination frame
    [[nodiscard]] const StudioKernelDesign& design() const noexcept { return design_; }
    // Delay from a source frame entering push() to its appearance in pull(),
    // in source frames and in destination frames.
    [[nodiscard]] std::uint32_t latencySourceFrames() const noexcept { return taps_ != 0 ? static_cast<std::uint32_t>(taps_ / 2) : 0U; }
    [[nodiscard]] std::uint32_t latencyDestinationFrames() const noexcept;

    // Audio-thread API. push() copies `frames` source frames (null channel
    // pointers count as silence). pull() writes up to `maxFrames` destination
    // frames and returns how many were written.
    void push(const float* const* source, std::uint32_t frames) noexcept;
    [[nodiscard]] std::uint32_t available() const noexcept;
    std::uint32_t pull(float* const* destination, std::uint32_t maxFrames) noexcept;
    // Destination frames that would be produced for the source frames pushed so
    // far if the stream ended now (used by export to write an exact length).
    [[nodiscard]] std::uint64_t sourceFramesPushed() const noexcept { return written_; }

    // Whole-buffer conversion for import/export (control thread). Output length
    // is round(frames * destinationRate / sourceRate); output frame n sits at
    // source time n * sourceRate / destinationRate with no phase offset.
    [[nodiscard]] static AudioBuffer convert(const AudioBuffer& source, double sourceRate, double destinationRate);

private:
    void designKernel(double sourceRate, double destinationRate);
    void renderFrame(float* const* destination, std::uint32_t frameIndex) noexcept;

    double ratio_ {1.0};
    int taps_ {0};
    std::uint32_t channels_ {0U};
    std::vector<float> table_;        // (kPhases + 1) rows of taps_
    std::vector<std::vector<float>> ring_;
    std::size_t mask_ {0U};
    std::uint64_t written_ {0U};      // absolute source frame count pushed
    double position_ {0.0};           // absolute source position of the next destination frame
    StudioKernelDesign design_;
};

} // namespace silveton
