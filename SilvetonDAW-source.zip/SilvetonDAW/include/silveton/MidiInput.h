#pragma once
#include "silveton/MidiTimeline.h"
#include "silveton/TempoMap.h"
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>

namespace silveton {

struct TimedMidiInputEvent {
    int port {-1};
    std::int64_t sample {0};
    std::uint8_t status {0U};
    std::uint8_t data1 {0U};
    std::uint8_t data2 {0U};
};

class MidiInputCapture {
public:
    static constexpr std::size_t kCapacity = 4096U;

    // Single MIDI-input producer. No allocation and no locks.
    bool pushRealtime(const TimedMidiInputEvent& event) noexcept;

    // Audio-thread MIDI-thru reader. Returns only events belonging to this block.
    // Future events remain queued for the next block. Late events are clamped to
    // frame 0 rather than discarded.
    [[nodiscard]] std::size_t eventsForBlock(std::int64_t blockStartSample,
                                             std::uint32_t frames,
                                             TimedMidiInputEvent* output,
                                             std::size_t capacity) noexcept;

    // Control-thread recording lifecycle. Recording receives its own copy of
    // every input event, so MIDI thru can consume independently.
    void beginRecording() noexcept;
    [[nodiscard]] bool recording() const noexcept { return recording_.load(std::memory_order_acquire); }
    [[nodiscard]] std::size_t stopAndCommit(MidiSequence& destination,
                                            const TempoMap& tempoMap,
                                            std::int64_t stopSample);

    [[nodiscard]] bool thruOverflowed() const noexcept { return thruOverflow_.load(std::memory_order_acquire); }
    [[nodiscard]] bool recordOverflowed() const noexcept { return recordOverflow_.load(std::memory_order_acquire); }
    void clearOverflowFlags() noexcept;

private:
    struct Ring {
        std::array<TimedMidiInputEvent, kCapacity> events {};
        std::atomic<std::size_t> write {0U};
        std::atomic<std::size_t> read {0U};
    };

    static bool push(Ring& ring, const TimedMidiInputEvent& event) noexcept;
    static bool peek(const Ring& ring, TimedMidiInputEvent& event) noexcept;
    static bool pop(Ring& ring, TimedMidiInputEvent& event) noexcept;
    static void clear(Ring& ring) noexcept;
    static bool validEvent(const TimedMidiInputEvent& event) noexcept;

    Ring thru_;
    Ring record_;
    std::atomic<bool> recording_ {false};
    std::atomic<bool> thruOverflow_ {false};
    std::atomic<bool> recordOverflow_ {false};
};

} // namespace silveton
