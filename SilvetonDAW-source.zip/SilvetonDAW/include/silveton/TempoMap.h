#pragma once
#include <cstdint>
#include <limits>
#include <vector>

namespace silveton {

struct TempoMapChange {
    std::int64_t sample {0};
    bool changesTempo {false};
    double bpm {120.0};
    bool changesTimeSignature {false};
    std::uint16_t numerator {4U};
    std::uint16_t denominator {4U};
};

struct TempoMapPosition {
    double quarterNotes {0.0};
    double barStartQuarterNotes {0.0};
    std::int64_t bar {1};
    std::uint16_t beat {1U};
    double beatFraction {0.0};
    double bpm {120.0};
    std::uint16_t numerator {4U};
    std::uint16_t denominator {4U};
};

class TempoMap {
public:
    TempoMap();

    void setSampleRate(double sampleRate);
    [[nodiscard]] double sampleRate() const noexcept { return sampleRate_; }
    [[nodiscard]] double initialTempo() const noexcept { return initialTempo_; }
    [[nodiscard]] std::uint16_t initialNumerator() const noexcept { return initialNumerator_; }
    [[nodiscard]] std::uint16_t initialDenominator() const noexcept { return initialDenominator_; }

    void setInitialTempo(double bpm);
    void setInitialTimeSignature(std::uint16_t numerator, std::uint16_t denominator);
    void clearChanges();
    void addTempoChange(std::int64_t sample, double bpm);
    void addTimeSignatureChange(std::int64_t sample,
                                std::uint16_t numerator,
                                std::uint16_t denominator);

    [[nodiscard]] const std::vector<TempoMapChange>& changes() const noexcept { return changes_; }
    [[nodiscard]] double tempoAtSample(std::int64_t sample) const noexcept;
    [[nodiscard]] std::uint16_t numeratorAtSample(std::int64_t sample) const noexcept;
    [[nodiscard]] std::uint16_t denominatorAtSample(std::int64_t sample) const noexcept;
    [[nodiscard]] double quarterNotesAtSample(std::int64_t sample) const noexcept;
    [[nodiscard]] std::int64_t sampleAtQuarterNotes(double quarterNotes) const noexcept;
    [[nodiscard]] TempoMapPosition positionAtSample(std::int64_t sample) const noexcept;
    [[nodiscard]] std::int64_t snapSampleToQuarterGrid(std::int64_t sample, std::uint32_t divisionsPerQuarter) const noexcept;
    [[nodiscard]] std::int64_t nextChangeSampleAfter(std::int64_t sample) const noexcept;

private:
    struct Segment {
        std::int64_t startSample {0};
        double startQuarterNotes {0.0};
        double bpm {120.0};
        std::uint16_t numerator {4U};
        std::uint16_t denominator {4U};
        double meterAnchorQuarterNotes {0.0};
        std::int64_t meterAnchorBarZeroBased {0};
    };

    static void validateTempo(double bpm);
    static void validateTimeSignature(std::uint16_t numerator, std::uint16_t denominator);
    void upsertChange(const TempoMapChange& change);
    void rebuild();
    [[nodiscard]] const Segment& segmentAtSample(std::int64_t sample) const noexcept;
    [[nodiscard]] const Segment& segmentAtQuarterNotes(double quarterNotes) const noexcept;

    double sampleRate_ {48000.0};
    double initialTempo_ {120.0};
    std::uint16_t initialNumerator_ {4U};
    std::uint16_t initialDenominator_ {4U};
    std::vector<TempoMapChange> changes_;
    std::vector<Segment> segments_;
};

} // namespace silveton
