#pragma once
#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/MixMath.h"
#include "silveton/Transport.h"
#include <atomic>
#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton {

class Recorder;
class DiskAudioSource;
class AutomationLane;

struct TimelineTrack {
    const AudioBuffer* source {nullptr};
    std::int64_t timelineStartSample {0};
    std::uint64_t sourceStartSample {0};
    float gainDb {0.0F};
    float pan {0.0F}; // mono pan or stereo balance
    bool mute {false};
    bool voiceEnabled {true};
    int voicePriority {0};

    // Optional dual panner for stereo tracks. Kept off by default so existing
    // Silveton sessions retain the early single-balance behaviour.
    bool useDualStereoPan {false};
    float stereoLeftPan {-1.0F};
    float stereoRightPan {1.0F};

    // Optional disk-backed source. Exactly one of source/diskSource must be set.
    // Disk audio is read only from prefilled memory cache pages; the audio
    // callback never performs file I/O.
    DiskAudioSource* diskSource {nullptr};

    // Optional immutable automation lanes. The lane objects and their point
    // vectors must remain alive and unmodified while referenced by a live
    // voice plan. Values are sampled in the audio callback at timeline-sample
    // resolution; no allocation or locks are used there.
    const AutomationLane* gainAutomationDb {nullptr};
    const AutomationLane* panAutomation {nullptr};
};

struct StereoMeterSnapshot {
    float leftPeak {0.0F};
    float rightPeak {0.0F};
    float leftRms {0.0F};
    float rightRms {0.0F};
};

using TrackMeterSnapshot = StereoMeterSnapshot;

class AudioEngine final : public IAudioDeviceCallback {
public:
    AudioEngine();

    void prepare(const AudioDeviceConfig& config);
    void clearTracks();
    void addTrack(TimelineTrack track);

    // Control-thread edits publish a new immutable voice-plan snapshot. The
    // audio thread adopts it atomically on the next callback boundary, so
    // voice allocation/pan-depth changes do not require stopping transport.
    void setVoiceLimit(std::size_t maxVoices);
    [[nodiscard]] std::size_t voiceLimit() const noexcept { return voiceLimit_.load(std::memory_order_acquire); }
    [[nodiscard]] std::size_t voicedTrackCount() const noexcept { return controlVoicedTrackCount_.load(std::memory_order_acquire); }

    void setLowLatencyInputMonitoring(bool enabled, float gainDb = 0.0F) noexcept;
    void setRecorder(Recorder* recorder) noexcept { recorder_.store(recorder, std::memory_order_release); }
    [[nodiscard]] Recorder* recorder() const noexcept { return recorder_.load(std::memory_order_acquire); }
    [[nodiscard]] bool lowLatencyInputMonitoring() const noexcept { return inputMonitoring_.load(std::memory_order_acquire); }

    // Session-level stereo pan depth. Pro Tools documents the same four
    // centre-attenuation choices; Silveton uses its own pan curve math.
    void setPanDepth(PanDepth depth);
    [[nodiscard]] PanDepth panDepth() const noexcept { return panDepth_.load(std::memory_order_acquire); }

    // Master path gain. Target updates are lock-free; the audio thread ramps
    // between values to avoid zipper/click artifacts. Output meters are post-fader.
    void setMasterFaderDb(float db) noexcept;
    [[nodiscard]] float masterFaderDb() const noexcept { return masterFaderDb_.load(std::memory_order_acquire); }

    [[nodiscard]] Transport& transport() noexcept { return transport_; }
    [[nodiscard]] const Transport& transport() const noexcept { return transport_; }
    [[nodiscard]] StereoMeterSnapshot outputMeter() const noexcept;
    [[nodiscard]] TrackMeterSnapshot trackMeter(std::size_t trackIndex) const noexcept;
    [[nodiscard]] std::size_t trackCount() const noexcept { return controlTrackCount_.load(std::memory_order_acquire); }
    [[nodiscard]] const AudioDeviceConfig& deviceConfig() const noexcept { return config_; }

    void processAudio(const float* const* inputs,
                      float* const* outputs,
                      std::uint32_t inputChannels,
                      std::uint32_t outputChannels,
                      std::uint32_t frames) noexcept override;

private:
    static constexpr std::size_t kMaxEngineTracks = 512U;
    static constexpr int kNoPendingPlan = -1;

    enum class PlanSlotState : std::uint8_t { Free = 0U, Writing = 1U, Pending = 2U, Live = 3U };

    struct TrackMeterAtomic {
        std::atomic<float> leftPeak {0.0F};
        std::atomic<float> rightPeak {0.0F};
        std::atomic<float> leftRms {0.0F};
        std::atomic<float> rightRms {0.0F};
    };

    // PreparedVoice is a complete immutable render snapshot. processAudio()
    // does not dereference the mutable control-thread tracks_ vector.
    struct PreparedVoice {
        std::size_t trackIndex {0U};
        const AudioBuffer* source {nullptr};
        DiskAudioSource* diskSource {nullptr};
        std::int64_t timelineStartSample {0};
        std::uint64_t sourceStartSample {0U};
        std::uint64_t sourceFrames {0U};
        std::size_t channels {0U};
        bool mute {false};
        bool useDualStereoPan {false};
        float gainDb {0.0F};
        float pan {0.0F};
        const AutomationLane* gainAutomationDb {nullptr};
        const AutomationLane* panAutomation {nullptr};
        double gain {1.0};
        StereoGainPair monoPan {1.0, 1.0};
        StereoGainPair balance {1.0, 1.0};
        StereoGainPair stereoLeftPan {1.0, 0.0};
        StereoGainPair stereoRightPan {0.0, 1.0};
    };

    struct VoicePlan {
        std::array<PreparedVoice, kMaxEngineTracks> voices {};
        std::size_t count {0U};
    };

    static float dbToLinear(float db) noexcept;
    void publishMeters(const float* left, const float* right, std::uint32_t frames) noexcept;
    void rebuildVoicePlan();
    [[nodiscard]] std::size_t acquireFreePlanSlot();
    void publishPendingPlan(std::size_t slot) noexcept;
    void adoptPendingPlan() noexcept;
    [[nodiscard]] const VoicePlan& livePlan() const noexcept;
    void addToMix(std::uint32_t index, double left, double right) noexcept;

    AudioDeviceConfig config_ {};
    Transport transport_;

    // Control-thread model only. The audio callback reads VoicePlan snapshots.
    std::vector<TimelineTrack> tracks_;
    std::vector<std::size_t> voicedTrackIndices_;
    std::atomic<std::size_t> controlTrackCount_ {0U};
    std::atomic<std::size_t> controlVoicedTrackCount_ {0U};
    std::atomic<std::size_t> voiceLimit_ {0U}; // 0 = unlimited
    bool prepared_ {false};
    std::atomic<PanDepth> panDepth_ {PanDepth::Minus3dB};

    // Triple-buffered immutable render plans. Control thread writes only a Free
    // slot; audio thread swaps Pending -> Live at block boundaries.
    std::array<VoicePlan, 3U> voicePlans_ {};
    std::array<std::atomic<PlanSlotState>, 3U> voicePlanStates_ {};
    std::atomic<int> pendingPlanIndex_ {kNoPendingPlan};
    std::atomic<int> livePlanIndex_ {0};

    // Allocated only in prepare(); never resized by processAudio().
    std::vector<double> mixLeft_;
    std::vector<double> mixRight_;
    std::vector<double> mixLeftCompensation_;
    std::vector<double> mixRightCompensation_;

    std::atomic<Recorder*> recorder_ {nullptr};
    std::atomic<bool> inputMonitoring_ {false};
    std::atomic<float> inputMonitorGainLinear_ {1.0F};

    std::atomic<float> masterFaderDb_ {0.0F};
    std::atomic<float> masterGainTargetLinear_ {1.0F};
    double masterGainCurrent_ {1.0}; // audio-thread owned after prepare()

    std::array<TrackMeterAtomic, kMaxEngineTracks> trackMeters_ {};

    std::atomic<float> leftPeak_ {0.0F};
    std::atomic<float> rightPeak_ {0.0F};
    std::atomic<float> leftRms_ {0.0F};
    std::atomic<float> rightRms_ {0.0F};
};

} // namespace silveton
