#pragma once
#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/MixMath.h"
#include "silveton/Metronome.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/Transport.h"
#include "silveton/TempoMap.h"
#include <atomic>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <vector>

namespace silveton {

class Recorder;
class DiskAudioSource;
class AutomationLane;
struct Project;

struct TimelineClip {
    const AudioBuffer* source {nullptr};
    DiskAudioSource* diskSource {nullptr};
    // Offline/missing media is represented explicitly instead of failing project
    // restore. When both source pointers are null, these hints describe the
    // original source sufficiently for timeline validation while rendering
    // silence until the media is relinked on the control thread.
    std::uint64_t sourceFramesHint {0U};
    std::uint32_t channelsHint {0U};
    std::int64_t timelineStartSample {0};
    std::uint64_t sourceStartSample {0U};
    std::uint64_t lengthSamples {0U}; // 0 = remaining source
    float gainDb {0.0F};
    bool mute {false};
    std::uint64_t fadeInSamples {0U};
    std::uint64_t fadeOutSamples {0U};
    static constexpr std::uint64_t kAutoFadeAnchor = std::numeric_limits<std::uint64_t>::max();
    std::uint64_t fadeInAnchorSourceSample {kAutoFadeAnchor};
    std::uint64_t fadeOutAnchorSourceSample {kAutoFadeAnchor};

    // Optional ownership handles. Kept after the legacy aggregate fields so old
    // aggregate initializers remain source-compatible.
    std::shared_ptr<const AudioBuffer> sourceOwner;
    std::shared_ptr<DiskAudioSource> diskSourceOwner;
};

struct TimelineTrack {
    const AudioBuffer* source {nullptr};
    std::int64_t timelineStartSample {0};
    std::uint64_t sourceStartSample {0};
    float gainDb {0.0F};
    float pan {0.0F}; // mono pan or stereo balance
    bool mute {false};
    bool voiceEnabled {true};
    int voicePriority {0};

    // Optional dual panner for stereo tracks. Kept off by default so existing
    // Silveton sessions retain the early single-balance behaviour.
    bool useDualStereoPan {false};
    float stereoLeftPan {-1.0F};
    float stereoRightPan {1.0F};

    // Optional disk-backed source. Exactly one of source/diskSource must be set.
    // Disk audio is read only from prefilled memory cache pages; the audio
    // callback never performs file I/O.
    DiskAudioSource* diskSource {nullptr};

    // Optional immutable automation lanes. The lane objects and their point
    // vectors must remain alive and unmodified while referenced by a live
    // voice plan. Values are sampled in the audio callback at timeline-sample
    // resolution; no allocation or locks are used there.
    const AutomationLane* gainAutomationDb {nullptr};
    const AutomationLane* panAutomation {nullptr};
    const AutomationLane* muteAutomation {nullptr};

    // Optional explicit clips. Empty preserves the legacy one-source-per-track path.
    std::vector<TimelineClip> clips;

    // Optional ownership handles copied into immutable realtime snapshots. Kept
    // after the legacy aggregate fields so existing initializers still compile.
    std::shared_ptr<const AudioBuffer> sourceOwner;
    std::shared_ptr<DiskAudioSource> diskSourceOwner;
};

struct StereoMeterSnapshot {
    float leftPeak {0.0F};
    float rightPeak {0.0F};
    float leftRms {0.0F};
    float rightRms {0.0F};
};

using TrackMeterSnapshot = StereoMeterSnapshot;

struct RecordedTimelineSpan {
    std::uint64_t recorderFrameStart {0U};
    std::int64_t projectStartSample {0};
    std::uint32_t frames {0U};
    std::uint64_t cyclePass {0U};
};

class AudioEngine final : public IAudioDeviceCallback {
public:
    AudioEngine();

    // Optional processor/routing graph for the initial pre-prepare configuration.
    // This preserves the 0.7.0 API. The external graph must outlive the engine until
    // it has been replaced and the retired graph plan has been reclaimed.
    void setProcessorGraph(ProcessorGraph* graph,
                           std::uint32_t maxCompensationSamples = 16384U);

    // Live immutable publication. The control thread fully prepares a replacement
    // graph and its routing/PDC scratch storage before publishing it. The audio
    // thread adopts Pending -> Live only at the next callback boundary. `nullptr`
    // publishes the transparent direct-mix path. The returned generation becomes
    // visible through liveProcessorGraphGeneration() after adoption.
    std::uint64_t publishProcessorGraph(std::unique_ptr<ProcessorGraph> graph,
                                        std::uint32_t maxCompensationSamples = 16384U);
    [[nodiscard]] bool processorGraphPublicationPending() const noexcept;
    [[nodiscard]] std::uint64_t liveProcessorGraphGeneration() const noexcept;
    // Rebuild only the immutable routing/PDC plan around the same live processors.
    // Used after a plug-in reports a latency change. The audio thread adopts the
    // replacement at the next block boundary.
    std::uint64_t publishProcessorGraphLatencyRefresh();
    // Release retired immutable voice snapshots on the control thread. This is
    // the lifetime boundary for shared audio/disk source owners copied into a
    // live voice plan. The audio thread only marks the predecessor Retired.
    std::size_t reclaimRetiredVoicePlans() noexcept;

    // Destroy retired owned graphs and their scratch buffers on the control thread.
    // A non-zero return means at least one old realtime graph can no longer be
    // referenced by the audio callback, so external retired plug-in instances may
    // also be released after this boundary.
    std::size_t reclaimRetiredProcessorGraphs() noexcept;
    [[nodiscard]] ProcessorGraph* processorGraph() const noexcept;
    // Aggregate DAW callbacks may adopt all pending immutable realtime state at
    // the very start of the device block, before queuing MIDI/automation.
    // processAudio() calls this too, so direct engine users keep the same API.
    void adoptPendingRealtimeStateAtBlockBoundary() noexcept;

    // Realtime audible metronome. The click is synthesized inside the audio
    // callback with fixed storage only; no allocation, locks, or file I/O.
    // It is mixed after the processor graph and before the Master Fader.
    void setMetronomeEnabled(bool enabled) noexcept { metronomeEnabled_.store(enabled, std::memory_order_release); }
    [[nodiscard]] bool metronomeEnabled() const noexcept { return metronomeEnabled_.load(std::memory_order_acquire); }
    void setMetronomeGainDb(float regularDb, float accentDb) noexcept;
    [[nodiscard]] float metronomeGainDb() const noexcept { return metronomeGainDb_.load(std::memory_order_acquire); }
    [[nodiscard]] float metronomeAccentGainDb() const noexcept { return metronomeAccentGainDb_.load(std::memory_order_acquire); }

    void setTempo(double tempo);
    [[nodiscard]] double tempo() const noexcept { return tempo_.load(std::memory_order_acquire); }
    void setTempoMap(const TempoMap& map);
    std::uint64_t publishTempoMap(const TempoMap& map);
    [[nodiscard]] bool tempoMapPublicationPending() const noexcept;
    [[nodiscard]] std::uint64_t liveTempoMapGeneration() const noexcept;
    [[nodiscard]] TempoMapPosition musicalPositionAtSample(std::int64_t sample) const noexcept;

    void prepare(const AudioDeviceConfig& config);
    void clearTracks();
    void addTrack(TimelineTrack track);
    // Live: new clips for every track (same tracks, same sources), one voice-plan publication, no stop.
    // False (and no change) when the layout does not fit — do a full rebuild then.
    bool replaceTrackClips(std::vector<std::vector<TimelineClip>> clipsPerTrack);
    // Ephemeral audibility mask used by Solo and stem export. This does not
    // mutate project mute automation. An empty/cleared mask renders all tracks.
    void setTrackRenderMask(const std::vector<std::size_t>& audibleTrackIndices);
    void clearTrackRenderMask();
    [[nodiscard]] bool trackRenderMaskActive() const noexcept { return trackRenderMaskActive_; }
    // Offline-only graph-node tap used for Group/FX stem export. -1 restores the
    // normal master output. The selected node is heard after its own fader.
    void setGraphMonitorNode(int node);
    void clearGraphMonitorNode() noexcept { graphMonitorNode_.store(-1, std::memory_order_release); }
    [[nodiscard]] int graphMonitorNode() const noexcept { return graphMonitorNode_.load(std::memory_order_acquire); }
    // Control-thread bridge from persisted project mixer state into immutable
    // voice-plan snapshots. Track audio/source ownership stays unchanged.
    void applyProjectTrackMixerState(const Project& project);

    // Control-thread edits publish a new immutable voice-plan snapshot. The
    // audio thread adopts it atomically on the next callback boundary, so
    // voice allocation/pan-depth changes do not require stopping transport.
    void setVoiceLimit(std::size_t maxVoices);
    [[nodiscard]] std::size_t voiceLimit() const noexcept { return voiceLimit_.load(std::memory_order_acquire); }
    [[nodiscard]] std::size_t voicedTrackCount() const noexcept { return controlVoicedTrackCount_.load(std::memory_order_acquire); }

    void setLowLatencyInputMonitoring(bool enabled, float gainDb = 0.0F) noexcept;
    void setRecorder(Recorder* recorder) noexcept;
    void detachRecorderAndWait() noexcept;
    void setPunchRange(bool enabled, std::int64_t punchInSample, std::int64_t punchOutSample);
    [[nodiscard]] std::vector<RecordedTimelineSpan> recordedTimelineSpans() const;
    [[nodiscard]] bool recordedTimelineSpanOverflowed() const noexcept {
        return recordedTimelineSpanOverflow_.load(std::memory_order_acquire);
    }
    [[nodiscard]] bool punchEnabled() const noexcept { return punchEnabled_.load(std::memory_order_acquire); }
    [[nodiscard]] std::int64_t punchInSample() const noexcept { return punchInSample_.load(std::memory_order_acquire); }
    [[nodiscard]] std::int64_t punchOutSample() const noexcept { return punchOutSample_.load(std::memory_order_acquire); }
    [[nodiscard]] Recorder* recorder() const noexcept { return recorder_.load(std::memory_order_acquire); }
    [[nodiscard]] bool lowLatencyInputMonitoring() const noexcept { return inputMonitoring_.load(std::memory_order_acquire); }

    // Session-level stereo pan depth. Pro Tools documents the same four
    // centre-attenuation choices; Silveton uses its own pan curve math.
    void setPanDepth(PanDepth depth);
    [[nodiscard]] PanDepth panDepth() const noexcept { return panDepth_.load(std::memory_order_acquire); }

    // Master path gain. Target updates are lock-free; the audio thread ramps
    // between values to avoid zipper/click artifacts. Output meters are post-fader.
    void setMasterFaderDb(float db) noexcept;
    void setMasterFaderAutomation(const AutomationLane* lane) noexcept {
        masterFaderAutomation_.store(lane, std::memory_order_release);
    }
    [[nodiscard]] float masterFaderDb() const noexcept { return masterFaderDb_.load(std::memory_order_acquire); }

    // Live faders and mutes of the routing graph (tracks, buses and the master).
    // The graph keeps the values it was built with, so without this a fader move
    // is heard only after the next rebuild. Control thread only; lock-free for the
    // audio thread, which moves to the new value with a short ramp.
    // Returns false (and changes nothing) while a graph is being published or when
    // the graph does not match the project (track/bus count differs). The values
    // belong to the graph generation that is live now: after a new graph goes live
    // the caller repeats the call (see liveProcessorGraphGeneration()).
    bool applyLiveMixerState(const Project& project) noexcept;

    [[nodiscard]] Transport& transport() noexcept { return transport_; }
    [[nodiscard]] const Transport& transport() const noexcept { return transport_; }
    [[nodiscard]] StereoMeterSnapshot outputMeter() const noexcept;
    [[nodiscard]] TrackMeterSnapshot trackMeter(std::size_t trackIndex) const noexcept;
    // Highest peak seen since the previous call (the UI polls at ~30 Hz while the
    // engine measures every 2-6 ms block, so a plain "last block" read would miss
    // most peaks and flicker). Reading resets the accumulator: exactly ONE caller
    // (the UI meter bank) may use these. RMS fields are the last block's value.
    [[nodiscard]] StereoMeterSnapshot takeOutputPeaks() noexcept;
    [[nodiscard]] TrackMeterSnapshot takeTrackPeaks(std::size_t trackIndex) noexcept;
    // The same for Group/FX channels: what leaves the channel after its fader. Same rules as takeTrackPeaks().
    [[nodiscard]] TrackMeterSnapshot takeBusPeaks(std::size_t busIndex) noexcept;
    [[nodiscard]] std::size_t busCount() const noexcept;
    [[nodiscard]] std::size_t trackCount() const noexcept { return controlTrackCount_.load(std::memory_order_acquire); }
    [[nodiscard]] const AudioDeviceConfig& deviceConfig() const noexcept { return config_; }

    void processAudio(const float* const* inputs,
                      float* const* outputs,
                      std::uint32_t inputChannels,
                      std::uint32_t outputChannels,
                      std::uint32_t frames) noexcept override;

private:
    static constexpr std::size_t kMaxEngineTracks = 512U;
    static constexpr int kNoPendingPlan = -1;

    enum class PlanSlotState : std::uint8_t { Free = 0U, Writing = 1U, Pending = 2U, Live = 3U, Retired = 4U };
    enum class GraphSlotState : std::uint8_t { Free = 0U, Writing = 1U, Pending = 2U, Live = 3U, Retired = 4U };
    enum class TempoSlotState : std::uint8_t { Free = 0U, Writing = 1U, Pending = 2U, Live = 3U };

    struct TrackMeterAtomic {
        std::atomic<float> leftPeak {0.0F};
        std::atomic<float> rightPeak {0.0F};
        std::atomic<float> leftRms {0.0F};
        std::atomic<float> rightRms {0.0F};
        std::atomic<float> leftSincePoll {0.0F};    // max peak since takeTrackPeaks()
        std::atomic<float> rightSincePoll {0.0F};
    };

    static void raisePeak(std::atomic<float>& slot, float value) noexcept;
    static constexpr std::size_t kMaxMeteredBuses = 64U;

    struct PreparedClip {
        std::shared_ptr<const AudioBuffer> sourceOwner;
        std::shared_ptr<DiskAudioSource> diskSourceOwner;
        const AudioBuffer* source {nullptr};
        DiskAudioSource* diskSource {nullptr};
        std::int64_t timelineStartSample {0};
        std::uint64_t sourceStartSample {0U};
        std::uint64_t sourceFrames {0U};
        std::uint64_t lengthSamples {0U};
        std::size_t channels {0U};
        double gain {1.0};
        bool mute {false};
        std::uint64_t fadeInSamples {0U};
        std::uint64_t fadeOutSamples {0U};
        std::uint64_t fadeInAnchorSourceSample {0U};
        std::uint64_t fadeOutAnchorSourceSample {0U};
    };

    // PreparedVoice is a complete immutable render snapshot. processAudio()
    // does not dereference the mutable control-thread tracks_ vector.
    struct PreparedVoice {
        std::size_t trackIndex {0U};
        std::shared_ptr<const AudioBuffer> sourceOwner;
        std::shared_ptr<DiskAudioSource> diskSourceOwner;
        const AudioBuffer* source {nullptr};
        DiskAudioSource* diskSource {nullptr};
        std::int64_t timelineStartSample {0};
        std::uint64_t sourceStartSample {0U};
        std::uint64_t sourceFrames {0U};
        std::size_t channels {0U};
        std::vector<PreparedClip> clips;
        bool mute {false};
        bool useDualStereoPan {false};
        float gainDb {0.0F};
        float pan {0.0F};
        AutomationLane gainAutomationDb;
        AutomationLane panAutomation;
        AutomationLane muteAutomation;
        bool hasGainAutomation {false};
        bool hasPanAutomation {false};
        bool hasMuteAutomation {false};
        double gain {1.0};
        StereoGainPair monoPan {1.0, 1.0};
        StereoGainPair balance {1.0, 1.0};
        StereoGainPair stereoLeftPan {1.0, 0.0};
        StereoGainPair stereoRightPan {0.0, 1.0};
    };

    struct VoicePlan {
        std::array<PreparedVoice, kMaxEngineTracks> voices {};
        std::array<std::uint8_t, kMaxEngineTracks> trackNodeEnabled {};
        std::size_t trackNodeMaskCount {0U};
        std::size_t count {0U};
    };

    struct GraphRenderPlan {
        std::unique_ptr<ProcessorGraph> ownedGraph;
        ProcessorGraph* graph {nullptr};
        std::uint32_t maxCompensationSamples {16384U};
        std::size_t nodeCount {0U};
        std::size_t blockCapacity {0U};
        std::vector<float> sourceLeft;
        std::vector<float> sourceRight;
        std::vector<ConstStereoBus> sourceBuses;
        std::vector<float> masterLeft;
        std::vector<float> masterRight;
        std::vector<float> busMeterLeft;     // room to copy a channel's output for the meters
        std::vector<float> busMeterRight;
        std::uint64_t generation {0U};
    };

    static float dbToLinear(float db) noexcept;
    void publishMeters(const float* left, const float* right, std::uint32_t frames) noexcept;
    void rebuildVoicePlan();
    [[nodiscard]] std::size_t acquireFreePlanSlot();
    static void validateTrackContent(const TimelineTrack& track);
    void clearVoicePlan(VoicePlan& plan) noexcept;
    void publishPendingPlan(std::size_t slot) noexcept;
    void adoptPendingPlan() noexcept;
    [[nodiscard]] const VoicePlan& livePlan() const noexcept;

    void prepareGraphRenderPlan(GraphRenderPlan& plan,
                                std::unique_ptr<ProcessorGraph> ownedGraph,
                                ProcessorGraph* externalGraph,
                                std::uint32_t maxCompensationSamples,
                                std::uint64_t generation,
                                const ProcessorGraph* predecessor);
    [[nodiscard]] std::size_t acquireFreeGraphSlot();
    void publishPendingGraph(std::size_t slot);
    void adoptPendingProcessorGraph() noexcept;
    [[nodiscard]] GraphRenderPlan& liveGraphPlan() noexcept;
    [[nodiscard]] const GraphRenderPlan& liveGraphPlan() const noexcept;
    void clearGraphRenderPlan(GraphRenderPlan& plan) noexcept;

    void addToMix(std::uint32_t index, double left, double right) noexcept;
    void addTrackContribution(GraphRenderPlan* graphPlan,
                              std::size_t trackIndex,
                              std::uint32_t index,
                              double left,
                              double right) noexcept;
    void clearGraphSources(GraphRenderPlan* graphPlan, std::uint32_t frames) noexcept;
    void renderProcessorGraph(GraphRenderPlan* graphPlan,
                              std::int64_t projectSample,
                              std::uint32_t sourceOffset,
                              std::uint32_t frames,
                              bool playing,
                              bool recording) noexcept;
    [[nodiscard]] std::size_t acquireFreeTempoSlot();
    void publishPendingTempoMap(std::size_t slot) noexcept;
    void adoptPendingTempoMap() noexcept;
    [[nodiscard]] const TempoMap& liveTempoMap() const noexcept;
    void renderMetronome(std::int64_t blockStart,
                         std::uint32_t frames,
                         bool playing,
                         bool cycleEnabled,
                         std::int64_t cycleStart,
                         std::int64_t cycleEnd) noexcept;

    AudioDeviceConfig config_ {};
    Transport transport_;
    std::atomic<double> tempo_ {120.0};
    TempoMap initialTempoMap_;
    std::array<TempoMap, 3U> tempoMaps_ {};
    std::array<std::atomic<TempoSlotState>, 3U> tempoMapStates_ {};
    std::atomic<int> pendingTempoMapIndex_ {kNoPendingPlan};
    std::atomic<int> liveTempoMapIndex_ {0};
    std::atomic<std::uint64_t> liveTempoMapGeneration_ {0U};
    std::uint64_t nextTempoMapGeneration_ {1U};
    std::array<std::uint64_t, 3U> tempoMapGenerations_ {};

    // Initial graph alias used only before prepare(). Live graphs are published through
    // the triple-buffered GraphRenderPlan slots below. The realtime thread never owns
    // or destroys graph memory.
    ProcessorGraph* initialProcessorGraph_ {nullptr};
    std::uint32_t initialProcessorGraphMaxCompensation_ {16384U};
    std::array<GraphRenderPlan, 3U> graphPlans_ {};
    std::array<std::atomic<GraphSlotState>, 3U> graphPlanStates_ {};
    std::atomic<int> pendingGraphIndex_ {kNoPendingPlan};
    std::atomic<int> liveGraphIndex_ {0};
    std::atomic<std::size_t> controlGraphNodeCount_ {0U};
    static constexpr std::size_t kLiveMixCapacity = 1024U;   // 256 tracks + 256 buses + master, with room to spare
    std::unique_ptr<LiveMixNode[]> liveMix_ {new LiveMixNode[kLiveMixCapacity]};
    // Graph generation the live values were written for. A newer graph is built from the
    // project (already up to date), so it ignores older live values until they are rewritten.
    std::atomic<std::uint64_t> liveMixGeneration_ {std::numeric_limits<std::uint64_t>::max()};
    std::uint64_t nextGraphGeneration_ {1U}; // single control-thread writer

    // Control-thread model only. The audio callback reads VoicePlan snapshots.
    std::vector<TimelineTrack> tracks_;
    std::vector<std::size_t> voicedTrackIndices_;
    std::array<std::uint8_t, kMaxEngineTracks> trackRenderMask_ {};
    bool trackRenderMaskActive_ {false};
    std::atomic<int> graphMonitorNode_ {-1};
    std::atomic<std::size_t> controlTrackCount_ {0U};
    std::atomic<std::size_t> controlVoicedTrackCount_ {0U};
    std::atomic<std::size_t> voiceLimit_ {0U}; // 0 = unlimited
    bool prepared_ {false};
    std::atomic<PanDepth> panDepth_ {PanDepth::Minus3dB};

    // Triple-buffered immutable render plans. Control thread writes only a Free
    // slot; audio thread swaps Pending -> Live at block boundaries.
    std::array<VoicePlan, 3U> voicePlans_ {};
    std::array<std::atomic<PlanSlotState>, 3U> voicePlanStates_ {};
    std::atomic<int> pendingPlanIndex_ {kNoPendingPlan};
    std::atomic<int> livePlanIndex_ {0};

    // Allocated only in prepare(); never resized by processAudio().
    std::vector<double> mixLeft_;
    std::vector<double> mixRight_;
    std::vector<double> mixLeftCompensation_;
    std::vector<double> mixRightCompensation_;
    std::vector<float> trackScratchLeft_;
    std::vector<float> trackScratchRight_;

    static constexpr std::size_t kMaxRecordedTimelineSpans = 16384U;
    struct RecordedTimelineSpanAtomic {
        std::atomic<std::uint64_t> recorderFrameStart {0U};
        std::atomic<std::int64_t> projectStartSample {0};
        std::atomic<std::uint32_t> frames {0U};
        std::atomic<std::uint64_t> cyclePass {0U};
    };
    void appendRecordedTimelineSpan(std::int64_t projectStartSample,
                                    std::uint32_t frames,
                                    std::uint64_t cyclePass) noexcept;
    std::array<RecordedTimelineSpanAtomic, kMaxRecordedTimelineSpans> recordedTimelineSpans_ {};
    std::atomic<std::size_t> recordedTimelineSpanCount_ {0U};
    std::atomic<std::uint64_t> recordedFrameCursor_ {0U};
    std::atomic<bool> recordedTimelineSpanOverflow_ {false};

    std::atomic<Recorder*> recorder_ {nullptr};
    std::atomic<std::uint32_t> recordingCallbackUsers_ {0U};
    std::atomic<bool> punchEnabled_ {false};
    std::atomic<std::int64_t> punchInSample_ {0};
    std::atomic<std::int64_t> punchOutSample_ {0};
    std::atomic<bool> inputMonitoring_ {false};
    std::atomic<float> inputMonitorGainLinear_ {1.0F};

    std::atomic<bool> metronomeEnabled_ {false};
    std::atomic<float> metronomeGainDb_ {-18.0F};
    std::atomic<float> metronomeAccentGainDb_ {-12.0F};
    double metronomePhase_ {0.0};
    double metronomePhaseIncrement_ {0.0};
    double metronomeEnvelope_ {0.0};
    double metronomeEnvelopeDecay_ {0.0};
    std::uint32_t metronomeRemainingSamples_ {0U};

    std::atomic<float> masterFaderDb_ {0.0F};
    std::atomic<float> masterGainTargetLinear_ {1.0F};
    std::atomic<const AutomationLane*> masterFaderAutomation_ {nullptr};
    double masterGainCurrent_ {1.0}; // audio-thread owned after prepare()

    std::array<TrackMeterAtomic, kMaxEngineTracks> trackMeters_ {};
    std::array<TrackMeterAtomic, kMaxMeteredBuses> busMeters_ {};

    std::atomic<float> leftPeak_ {0.0F};
    std::atomic<float> rightPeak_ {0.0F};
    std::atomic<float> leftRms_ {0.0F};
    std::atomic<float> rightRms_ {0.0F};
    std::atomic<float> leftSincePoll_ {0.0F};
    std::atomic<float> rightSincePoll_ {0.0F};
};

} // namespace silveton
