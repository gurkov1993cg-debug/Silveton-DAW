#pragma once
#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/MixMath.h"
#include "silveton/Transport.h"
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton {

class Recorder;

struct TimelineTrack {
    const AudioBuffer* source {nullptr};
    std::int64_t timelineStartSample {0};
    std::uint64_t sourceStartSample {0};
    float gainDb {0.0F};
    float pan {0.0F}; // mono pan or stereo balance
    bool mute {false};
    bool voiceEnabled {true};
    int voicePriority {0};

    // Optional dual panner for stereo tracks. Kept off by default so existing
    // Silveton sessions retain the early single-balance behaviour.
    bool useDualStereoPan {false};
    float stereoLeftPan {-1.0F};
    float stereoRightPan {1.0F};
};

struct StereoMeterSnapshot {
    float leftPeak {0.0F};
    float rightPeak {0.0F};
    float leftRms {0.0F};
    float rightRms {0.0F};
};

class AudioEngine final : public IAudioDeviceCallback {
public:
    AudioEngine() = default;

    void prepare(const AudioDeviceConfig& config);
    void clearTracks();
    void addTrack(TimelineTrack track);

    // Pro-grade playback-engine primitives inspired by documented DAW practice:
    // - deterministic voice allocation, prepared off the audio thread
    // - native low-latency input monitor path
    // - compensated 64-bit floating-point summing accumulator
    void setVoiceLimit(std::size_t maxVoices);
    [[nodiscard]] std::size_t voiceLimit() const noexcept { return voiceLimit_; }
    [[nodiscard]] std::size_t voicedTrackCount() const noexcept { return preparedVoices_.size(); }

    void setLowLatencyInputMonitoring(bool enabled, float gainDb = 0.0F) noexcept;
    void setRecorder(Recorder* recorder) noexcept { recorder_.store(recorder, std::memory_order_release); }
    [[nodiscard]] Recorder* recorder() const noexcept { return recorder_.load(std::memory_order_acquire); }
    [[nodiscard]] bool lowLatencyInputMonitoring() const noexcept { return inputMonitoring_.load(std::memory_order_acquire); }

    // Session-level stereo pan depth. Pro Tools documents the same four
    // centre-attenuation choices; Silveton uses its own pan curve math.
    void setPanDepth(PanDepth depth);
    [[nodiscard]] PanDepth panDepth() const noexcept { return panDepth_; }

    // Master path gain. Target updates are lock-free; the audio thread ramps
    // between values to avoid zipper/click artifacts. Output meters are post-fader.
    void setMasterFaderDb(float db) noexcept;
    [[nodiscard]] float masterFaderDb() const noexcept { return masterFaderDb_.load(std::memory_order_acquire); }

    [[nodiscard]] Transport& transport() noexcept { return transport_; }
    [[nodiscard]] const Transport& transport() const noexcept { return transport_; }
    [[nodiscard]] StereoMeterSnapshot outputMeter() const noexcept;
    [[nodiscard]] const AudioDeviceConfig& deviceConfig() const noexcept { return config_; }

    void processAudio(const float* const* inputs,
                      float* const* outputs,
                      std::uint32_t inputChannels,
                      std::uint32_t outputChannels,
                      std::uint32_t frames) noexcept override;

private:
    struct PreparedVoice {
        std::size_t trackIndex {0U};
        double gain {1.0};
        StereoGainPair monoPan {1.0, 1.0};
        StereoGainPair balance {1.0, 1.0};
        StereoGainPair stereoLeftPan {1.0, 0.0};
        StereoGainPair stereoRightPan {0.0, 1.0};
    };

    static float dbToLinear(float db) noexcept;
    void publishMeters(const float* left, const float* right, std::uint32_t frames) noexcept;
    void rebuildVoicePlan();
    void addToMix(std::uint32_t index, double left, double right) noexcept;

    AudioDeviceConfig config_ {};
    Transport transport_;
    std::vector<TimelineTrack> tracks_;
    std::vector<std::size_t> voicedTrackIndices_;
    std::vector<PreparedVoice> preparedVoices_;
    std::size_t voiceLimit_ {0U}; // 0 = unlimited
    bool prepared_ {false};
    PanDepth panDepth_ {PanDepth::Minus3dB};

    // Allocated only in prepare(); never resized by processAudio().
    std::vector<double> mixLeft_;
    std::vector<double> mixRight_;
    std::vector<double> mixLeftCompensation_;
    std::vector<double> mixRightCompensation_;

    std::atomic<Recorder*> recorder_ {nullptr};
    std::atomic<bool> inputMonitoring_ {false};
    std::atomic<float> inputMonitorGainLinear_ {1.0F};

    std::atomic<float> masterFaderDb_ {0.0F};
    std::atomic<float> masterGainTargetLinear_ {1.0F};
    double masterGainCurrent_ {1.0}; // audio-thread owned after prepare()

    std::atomic<float> leftPeak_ {0.0F};
    std::atomic<float> rightPeak_ {0.0F};
    std::atomic<float> leftRms_ {0.0F};
    std::atomic<float> rightRms_ {0.0F};
};

} // namespace silveton
