#pragma once
#include <algorithm>
#include <cstdint>
#include <stdexcept>
#include <vector>

namespace silveton {

enum class AutomationMode : std::uint8_t { Off = 0, Read = 1, Write = 2, Touch = 3, Latch = 4 };
enum class AutomationGestureType : std::uint8_t { Begin, Value, End };

struct AutomationPoint {
    std::int64_t sample {0};
    float value {0.0F};
};

// Generic sample-domain mixer automation lane. Values stay in their natural
// unit (dB, pan -1..1, boolean 0/1, etc.) so interpolation is performed in
// the same domain the user edits.
class AutomationLane {
public:
    void add(std::int64_t sample, float value);
    [[nodiscard]] float valueAt(std::int64_t sample, float fallback) const noexcept;
    // Boolean/switch automation uses the most recent point instead of interpolation.
    [[nodiscard]] float stepValueAt(std::int64_t sample, float fallback) const noexcept;
    [[nodiscard]] const std::vector<AutomationPoint>& points() const noexcept { return points_; }
private:
    std::vector<AutomationPoint> points_;
};

struct ParameterAutomationPoint {
    std::int64_t sample {0};
    double normalized {0.0};
};

struct AutomationGesture {
    AutomationGestureType type {AutomationGestureType::Value};
    std::uint32_t parameterId {0};
    std::int64_t sample {0};
    double normalized {0.0};
};

class ParameterAutomationLane {
public:
    void write(std::int64_t sample, double normalized);
    [[nodiscard]] double valueAt(std::int64_t sample, double fallback) const noexcept;
    [[nodiscard]] const std::vector<ParameterAutomationPoint>& points() const noexcept { return points_; }
private:
    std::vector<ParameterAutomationPoint> points_;
};

class AutomationWriter {
public:
    void setMode(AutomationMode mode) noexcept;
    [[nodiscard]] AutomationMode mode() const noexcept { return mode_; }
    [[nodiscard]] bool gestureActive() const noexcept { return gestureActive_; }

    void apply(const AutomationGesture& event, ParameterAutomationLane& lane);
    void apply(AutomationGestureType type, std::int64_t sample, float value, AutomationLane& lane);
    void endTransportGesture() noexcept { gestureActive_ = false; latchActive_ = false; }

private:
    AutomationMode mode_ {AutomationMode::Read};
    bool gestureActive_ {false};
    bool latchActive_ {false};
};

} // namespace silveton
