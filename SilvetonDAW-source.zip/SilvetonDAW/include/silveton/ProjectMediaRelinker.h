#pragma once
#include "silveton/DawCore.h"
#include <cstddef>
#include <cstdint>
#include <string>

namespace silveton {

struct ProjectMediaRelinkResult {
    std::size_t updatedReferences {0U};
    std::uint64_t sourceFrames {0U};
    std::uint32_t sourceChannels {0U};
    std::uint32_t sourceSampleRate {0U};
};

// Control-thread utility for resolving offline media. Relink is transactional:
// the replacement is inspected and every referenced source range is validated
// before any project path/metadata is changed.
class ProjectMediaRelinker final {
public:
    // `requireProjectSampleRate` (default): the replacement's frames are counted
    // at the project rate (it keeps its own rate on disk and is converted while it
    // plays), so clip ranges stay valid for any replacement rate.
    [[nodiscard]] static ProjectMediaRelinkResult relinkPath(Project& project,
                                                              const std::string& oldPath,
                                                              const std::string& newPath,
                                                              bool requireProjectSampleRate = true);

    // Converts any DiskStream-supported PCM WAV/AIFF source to a Float32 WAV at
    // the project rate using Silveton's windowed-sinc resampler. This is an
    // explicit control-thread operation; it never runs in the audio callback.
    // The standalone conform helper is used by normal file import/drag-and-drop;
    // it does not mutate the Project.
    [[nodiscard]] static ProjectMediaRelinkResult conformSourceToProjectRate(const Project& project,
                                                                              const std::string& sourcePath,
                                                                              const std::string& conformedWavPath);

    // Reads a whole DiskStream-supported WAV/AIFF (mono/stereo) into memory on
    // the control thread. `sampleRate` receives the file's OWN rate. With
    // `targetRate` > 0 the audio is returned converted to that rate (same Studio
    // sinc as playback, so what is edited is what is heard); the file is never
    // changed.
    [[nodiscard]] static AudioBuffer readWholeSource(const std::string& path, std::uint32_t& sampleRate, double targetRate = 0.0);

    [[nodiscard]] static ProjectMediaRelinkResult conformAndRelinkPath(Project& project,
                                                                       const std::string& oldPath,
                                                                       const std::string& sourcePath,
                                                                       const std::string& conformedWavPath);
};

} // namespace silveton
