#pragma once
#include "silveton/DawCore.h"
#include <cstddef>
#include <cstdint>
#include <string>

namespace silveton {

struct ProjectMediaRelinkResult {
    std::size_t updatedReferences {0U};
    std::uint64_t sourceFrames {0U};
    std::uint32_t sourceChannels {0U};
    std::uint32_t sourceSampleRate {0U};
};

// Control-thread utility for resolving offline media. Relink is transactional:
// the replacement is inspected and every referenced source range is validated
// before any project path/metadata is changed.
class ProjectMediaRelinker final {
public:
    [[nodiscard]] static ProjectMediaRelinkResult relinkPath(Project& project,
                                                              const std::string& oldPath,
                                                              const std::string& newPath,
                                                              bool requireProjectSampleRate = true);

    // Converts any DiskStream-supported PCM WAV/AIFF source to a Float32 WAV at
    // the project rate using Silveton's windowed-sinc resampler. This is an
    // explicit control-thread operation; it never runs in the audio callback.
    [[nodiscard]] static ProjectMediaRelinkResult conformAndRelinkPath(Project& project,
                                                                       const std::string& oldPath,
                                                                       const std::string& sourcePath,
                                                                       const std::string& conformedWavPath);
};

} // namespace silveton
