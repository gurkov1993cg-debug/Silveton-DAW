#pragma once

#include "silveton/AudioDevice.h"

#if defined(__APPLE__)

#include <atomic>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace silveton {

struct CoreAudioDeviceInfo {
    std::uint32_t id {0U};
    std::string name;
    std::string uid;
    std::uint32_t inputChannels {0U};
    std::uint32_t outputChannels {0U};
    double nominalSampleRate {0.0};
    bool isDefaultInput {false};
    bool isDefaultOutput {false};
};

struct CoreAudioDeviceOptions {
    // 0 selects the system default output device. A DAW normally uses one
    // duplex CoreAudio device for both input and output.
    std::uint32_t deviceId {0U};
    // Stable CoreAudio UID. When set, it takes precedence over deviceId and
    // survives AudioDeviceID changes across boots/reconnects.
    std::string deviceUid;
    bool followDefaultOutputDevice {true};
};

struct CoreAudioDeviceStatus {
    bool needsReopen {false};
    std::uint64_t callbackCount {0U};
    std::uint64_t overloadCount {0U};
    std::uint32_t inputLatencyFrames {0U};
    std::uint32_t outputLatencyFrames {0U};
    std::uint32_t audioUnitLatencyFrames {0U};
};

// Native macOS AUHAL/CoreAudio device backend.
//
// Real-time contract:
// - no allocation, locks, device queries, logging or file I/O in renderProc;
// - client buffers are planar Float32;
// - processAudio() receives the exact samples rendered/captured by CoreAudio;
// - device reconfiguration is reported through needsReopen and must be handled
//   from the control thread, never from the audio callback.
class CoreAudioDevice final : public IAudioDevice {
public:
    CoreAudioDevice(AudioDeviceConfig requestedConfig,
                    CoreAudioDeviceOptions options = {});
    ~CoreAudioDevice() override;

    CoreAudioDevice(const CoreAudioDevice&) = delete;
    CoreAudioDevice& operator=(const CoreAudioDevice&) = delete;

    [[nodiscard]] const AudioDeviceConfig& config() const noexcept override;
    void start(IAudioDeviceCallback& callback) override;
    void stop() noexcept override;
    [[nodiscard]] bool isRunning() const noexcept override;

    [[nodiscard]] std::uint32_t deviceId() const noexcept;
    [[nodiscard]] const std::string& deviceUid() const noexcept;
    [[nodiscard]] CoreAudioDeviceStatus status() const noexcept;
    void clearReopenRequest() noexcept;
    // Control-thread only. Re-resolves a stable UID/default device, rebuilds
    // AUHAL and restarts the previous callback if the device was running.
    void reopen();

    [[nodiscard]] static std::vector<CoreAudioDeviceInfo> devices();
    [[nodiscard]] static std::uint32_t defaultInputDeviceId();
    [[nodiscard]] static std::uint32_t defaultOutputDeviceId();

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace silveton

#endif // __APPLE__
