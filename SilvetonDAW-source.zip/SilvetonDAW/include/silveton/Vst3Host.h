#pragma once
#include "silveton/Vst3Blacklist.h"
#include "silveton/Vst3Runtime.h"
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace silveton {

struct Vst3PluginDescriptor {
    std::string modulePath;
    std::string classId;
    std::string name;
    std::string vendor;
    std::string version;
    std::string sdkVersion;
    std::vector<std::string> subCategories;
};

struct Vst3ParameterDescriptor {
    std::uint32_t id {0U};
    std::string title;
    std::string shortTitle;
    std::string units;
    std::int32_t stepCount {0};
    double defaultNormalized {0.0};
    std::int32_t flags {0};
};

struct Vst3BusDescriptor {
    bool input {false};
    bool event {false};
    bool main {false};
    bool defaultActive {false};
    std::int32_t index {0};
    std::int32_t channels {0};
    std::string name;
};

struct Vst3InstanceInfo {
    Vst3PluginDescriptor plugin;
    std::vector<Vst3ParameterDescriptor> parameters;
    std::vector<Vst3BusDescriptor> audioBuses;
    std::vector<Vst3BusDescriptor> eventBuses;
};

class Vst3Host final : public IVst3InstanceFactory {
public:
    Vst3Host();
    ~Vst3Host() override;
    Vst3Host(const Vst3Host&) = delete;
    Vst3Host& operator=(const Vst3Host&) = delete;

    [[nodiscard]] std::vector<Vst3PluginDescriptor> scanModule(const std::string& modulePath,
                                                               std::string& failureReason) const;
    [[nodiscard]] std::vector<std::string> installedModulePaths() const;

    std::unique_ptr<IVst3PluginInstance> create(const std::string& modulePath,
                                                const std::string& classId,
                                                std::string& failureReason) override;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

// Direct scanner helper used by the isolated scanner executable. The returned
// descriptors are deterministic and contain only VST audio-effect classes.
[[nodiscard]] std::vector<Vst3PluginDescriptor> scanVst3ModuleDirect(const std::string& modulePath,
                                                                     std::string& failureReason);

} // namespace silveton
