#pragma once

#include "silveton/AudioBuffer.h"
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

namespace silveton {

struct WaveformPeak {
    float minimum {0.0F};
    float maximum {0.0F};
};

struct WaveformOverview {
    std::uint32_t sampleRate {0U};
    std::uint32_t channels {0U};
    std::uint64_t frames {0U};
    std::uint64_t framesPerPeak {1U};
    std::vector<std::vector<WaveformPeak>> peaks;

    [[nodiscard]] bool empty() const noexcept {
        return frames == 0U || channels == 0U || peaks.empty();
    }
};

// Builds a real min/max envelope from audio samples. The number of peaks is
// capped so the GUI can render long files without touching the audio thread.
[[nodiscard]] WaveformOverview buildWaveformOverview(const AudioBuffer& audio,
                                                      std::uint32_t sampleRate,
                                                      std::size_t maxPeaks = 16384U);

class WaveformCache {
public:
    explicit WaveformCache(std::size_t defaultMaxPeaks = 16384U);
    ~WaveformCache();
    WaveformCache(const WaveformCache&) = delete;
    WaveformCache& operator=(const WaveformCache&) = delete;

    // Non-blocking. Disk I/O and envelope construction happen on the cache
    // worker, never on the GUI or audio callback thread.
    void request(const std::string& audioPath, std::size_t maxPeaks = 0U);

    [[nodiscard]] std::shared_ptr<const WaveformOverview> find(const std::string& audioPath) const;
    [[nodiscard]] bool failed(const std::string& audioPath) const;
    [[nodiscard]] std::string error(const std::string& audioPath) const;

    // Control/test helper. Never call from the audio callback.
    [[nodiscard]] bool waitUntilReady(const std::string& audioPath, std::uint32_t timeoutMs) const;

    void clear();

private:
    enum class State : std::uint8_t { Queued, Loading, Ready, Failed };
    struct Entry {
        State state {State::Queued};
        std::size_t maxPeaks {0U};
        std::shared_ptr<const WaveformOverview> overview;
        std::string error;
    };
    struct Job {
        std::string path;
        std::size_t maxPeaks {0U};
    };

    void workerLoop() noexcept;

    const std::size_t defaultMaxPeaks_;
    mutable std::mutex mutex_;
    mutable std::condition_variable readyCv_;
    std::condition_variable workCv_;
    std::unordered_map<std::string, Entry> entries_;
    std::deque<Job> jobs_;
    bool stop_ {false};
    std::thread worker_;
};

} // namespace silveton
