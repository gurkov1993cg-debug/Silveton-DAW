#pragma once

#include "silveton/AudioBuffer.h"
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

namespace silveton {

struct WaveformPeak {
    float minimum {0.0F};
    float maximum {0.0F};
};

struct WaveformOverview {
    std::uint32_t sampleRate {0U};
    std::uint32_t channels {0U};
    std::uint64_t frames {0U};
    std::uint64_t framesPerPeak {1U};
    std::vector<std::vector<WaveformPeak>> peaks;
    // A second, finer envelope (one peak per `fineFramesPerPeak` frames, 128 by default) for zoomed-in
    // views: the coarse one is capped at a few thousand peaks per file and turns blocky at a bar-wide zoom.
    std::uint64_t fineFramesPerPeak {0U};
    std::vector<std::vector<WaveformPeak>> finePeaks;
    static constexpr std::uint64_t kFineFramesPerPeak = 128U;

    [[nodiscard]] bool empty() const noexcept {
        return frames == 0U || channels == 0U || peaks.empty();
    }
};

// The decoded audio of one file at its own sample rate, kept so an editor can
// show individual samples when the user zooms in past the resolution of the
// envelope. Only requested for the clip that is open in the Sample Editor.
struct WaveformDetail {
    std::uint32_t sampleRate {0U};
    AudioBuffer audio;
};

// A small piece of a file, decoded sample by sample: what the Project window shows when it is
// zoomed in to single samples. Only the part on screen (and a margin around it) is read, so
// many long files cost almost no memory.
struct WaveformWindow {
    std::uint32_t sampleRate {0U};
    std::uint64_t startFrame {0U};   // file frame of audio.sample(c, 0)
    AudioBuffer audio;
    [[nodiscard]] bool covers(std::uint64_t first, std::uint64_t count) const noexcept {
        return first >= startFrame && first + count <= startFrame + audio.frames();
    }
};

// Builds a real min/max envelope from audio samples. The number of peaks is
// capped so the GUI can render long files without touching the audio thread.
[[nodiscard]] WaveformOverview buildWaveformOverview(const AudioBuffer& audio,
                                                      std::uint32_t sampleRate,
                                                      std::size_t maxPeaks = 16384U);

class WaveformCache {
public:
    explicit WaveformCache(std::size_t defaultMaxPeaks = 16384U);
    ~WaveformCache();
    WaveformCache(const WaveformCache&) = delete;
    WaveformCache& operator=(const WaveformCache&) = delete;

    // Non-blocking. Disk I/O and envelope construction happen on the cache
    // worker, never on the GUI or audio callback thread.
    void request(const std::string& audioPath, std::size_t maxPeaks = 0U);

    [[nodiscard]] std::shared_ptr<const WaveformOverview> find(const std::string& audioPath) const;

    // Non-blocking, like request(). Decodes the whole file on the cache worker and keeps
    // it (files above kMaxDetailBytes of decoded audio are refused: detailFailed() is true).
    static constexpr std::size_t kMaxDetailBytes = 768U * 1024U * 1024U;
    void requestDetail(const std::string& audioPath);
    [[nodiscard]] std::shared_ptr<const WaveformDetail> findDetail(const std::string& audioPath) const;
    [[nodiscard]] bool detailFailed(const std::string& audioPath) const;
    [[nodiscard]] bool waitUntilDetailReady(const std::string& audioPath, std::uint32_t timeoutMs) const;
    // Frees the decoded audio of every finished file that is not in `keep` (a detail still being
    // decoded is left alone). The editor calls this so only the files it shows stay in memory.
    void releaseDetailsExcept(const std::vector<std::string>& keep);
    // Non-blocking. Reads `frames` file frames from `startFrame` on the worker (a newer request for the
    // same file replaces an older one that has not started). findWindow() gives the last piece read for
    // the file, which may not cover the latest request yet (check covers()). At most 48 pieces are kept.
    void requestWindow(const std::string& audioPath, std::uint64_t startFrame, std::uint64_t frames);
    [[nodiscard]] std::shared_ptr<const WaveformWindow> findWindow(const std::string& audioPath) const;
    [[nodiscard]] bool failed(const std::string& audioPath) const;
    [[nodiscard]] std::string error(const std::string& audioPath) const;

    // Control/test helper. Never call from the audio callback.
    [[nodiscard]] bool waitUntilReady(const std::string& audioPath, std::uint32_t timeoutMs) const;

    void clear();

private:
    enum class State : std::uint8_t { Queued, Loading, Ready, Failed };
    struct Entry {
        State state {State::Queued};
        std::size_t maxPeaks {0U};
        std::shared_ptr<const WaveformOverview> overview;
        std::string error;
    };
    struct DetailEntry {
        State state {State::Queued};
        std::shared_ptr<const WaveformDetail> detail;
        std::string error;
    };
    struct WindowEntry {
        State state {State::Queued};
        std::uint64_t wantStart {0U};
        std::uint64_t wantFrames {0U};
        std::uint64_t serial {0U};        // bumped by every request: the newest wins
        std::shared_ptr<const WaveformWindow> window;
    };
    struct Job {
        std::string path;
        std::size_t maxPeaks {0U};
        bool detail {false};
        bool window {false};
        std::uint64_t windowStart {0U};
        std::uint64_t windowFrames {0U};
    };

    void workerLoop() noexcept;

    const std::size_t defaultMaxPeaks_;
    mutable std::mutex mutex_;
    mutable std::condition_variable readyCv_;
    std::condition_variable workCv_;
    std::unordered_map<std::string, Entry> entries_;
    std::unordered_map<std::string, DetailEntry> details_;
    std::unordered_map<std::string, WindowEntry> windows_;
    std::uint64_t windowSerial_ {0U};
    std::deque<Job> jobs_;
    bool stop_ {false};
    std::thread worker_;
};

} // namespace silveton
