#pragma once
#include "silveton/AudioBuffer.h"
#include "silveton/MixMath.h"
#include <vector>

namespace silveton {

struct TrackState {
    const AudioBuffer* source {nullptr};
    float gainDb {0.0F};
    float pan {0.0F}; // mono pan or stereo balance
    bool mute {false};

    // Optional Pro Tools-style dual-panner behaviour for stereo sources.
    // Disabled by default for backward compatibility with the early Silveton
    // single stereo balance control.
    bool useDualStereoPan {false};
    float stereoLeftPan {-1.0F};
    float stereoRightPan {1.0F};
};

class Mixer {
public:
    static float dbToLinear(float db) noexcept;
    static void mixStereo(const std::vector<TrackState>& tracks,
                          AudioBuffer& output,
                          PanDepth panDepth = PanDepth::Minus3dB);
};

} // namespace silveton
