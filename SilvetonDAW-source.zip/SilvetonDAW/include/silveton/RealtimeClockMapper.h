#pragma once
#include <atomic>
#include <cstdint>

namespace silveton {

// Lock-free mapping from host-clock ticks to project timeline samples. The
// audio callback publishes one anchor per device block; CoreMIDI and other
// realtime producers can timestamp events against the same host clock.
class RealtimeClockMapper final {
public:
    void setHostTicksPerSecond(double ticksPerSecond) noexcept;
    void update(std::uint64_t hostTime,
                std::int64_t projectSample,
                double sampleRate) noexcept;
    [[nodiscard]] bool valid() const noexcept;
    [[nodiscard]] std::int64_t projectSampleAtHostTime(std::uint64_t hostTime) const noexcept;

private:
    std::atomic<std::uint64_t> hostTime_ {0U};
    std::atomic<std::int64_t> projectSample_ {0};
    std::atomic<double> sampleRate_ {48000.0};
    std::atomic<double> hostTicksPerSecond_ {0.0};
    std::atomic<std::uint64_t> generation_ {0U};
};

} // namespace silveton
