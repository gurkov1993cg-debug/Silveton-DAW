#pragma once
#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include "silveton/MidiInput.h"
#include "silveton/MidiPlaybackScheduler.h"
#include "silveton/RealtimeClockMapper.h"
#include "silveton/RealtimeLifecycleGate.h"
#include "silveton/Vst3Runtime.h"
#include <atomic>

namespace silveton {

// Device callback that joins the already-tested engine, VST3 automation,
// project MIDI and live MIDI-thru paths without moving control-thread work into
// the realtime callback.
class DawAudioCallback final : public IAudioDeviceCallback {
public:
    DawAudioCallback(AudioEngine& engine,
                     Vst3RuntimeRack& rack,
                     MidiPlaybackScheduler& midi,
                     MidiInputCapture& input,
                     RealtimeClockMapper& clock) noexcept;
    void setHostTicksPerSecond(double ticksPerSecond) noexcept { clock_.setHostTicksPerSecond(ticksPerSecond); }
    void updateDeviceTime(const AudioDeviceTimeInfo& info) noexcept override;
    [[nodiscard]] RealtimeLifecycleGate& lifecycleGate() noexcept { return lifecycleGate_; }
    void processAudio(const float* const* inputs,float* const* outputs,
                      std::uint32_t inputChannels,std::uint32_t outputChannels,
                      std::uint32_t frames) noexcept override;
    // How much of the time one block may take is used up (0 = idle, 1 = just in time, > 1 = too slow).
    // Quick to rise, slow to fall, so a short spike stays visible long enough to be read.
    [[nodiscard]] float dspLoad() const noexcept { return dspLoad_.load(std::memory_order_relaxed); }
private:
    AudioEngine& engine_;Vst3RuntimeRack& rack_;MidiPlaybackScheduler& midi_;MidiInputCapture& input_;RealtimeClockMapper& clock_;
    RealtimeLifecycleGate lifecycleGate_;
    std::atomic<std::uint64_t> pendingHostTime_{0U};
    std::atomic<float> dspLoad_{0.0F};
};

} // namespace silveton
