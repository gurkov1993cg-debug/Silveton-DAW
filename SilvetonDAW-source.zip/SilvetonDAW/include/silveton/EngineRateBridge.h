#pragma once
// Runs the engine at its own internal rate (96 kHz) while the audio device
// stays at whatever rate the card uses. Device input is raised to the engine
// rate before the engine sees it, engine output is lowered to the device rate,
// both with the sampler's Studio sinc. The engine is called in fixed blocks
// from inside the device callback; a small FIFO on each side absorbs the
// non-integer ratio. No allocation, locks or I/O after prepare().
#include "silveton/AudioDevice.h"
#include "silveton/StudioResampler.h"

#include <cstdint>
#include <vector>

namespace silveton {

class EngineRateBridge final : public IAudioDeviceCallback {
public:
    // `inner` receives engine-rate blocks of `engineConfig().blockSize` frames.
    void prepare(const AudioDeviceConfig& deviceConfig, double engineRate, IAudioDeviceCallback& inner);
    [[nodiscard]] bool active() const noexcept { return inner_ != nullptr; }
    [[nodiscard]] const AudioDeviceConfig& engineConfig() const noexcept { return engineConfig_; }
    [[nodiscard]] const AudioDeviceConfig& deviceConfig() const noexcept { return deviceConfig_; }
    // Round-trip latency added by the two converters, in device frames.
    [[nodiscard]] std::uint32_t addedLatencyDeviceFrames() const noexcept;
    // Engine input frames that had to be zero-padded because the input
    // converter was short (should stay 0 with the pre-roll; diagnostics).
    [[nodiscard]] std::uint64_t paddedEngineFrames() const noexcept { return paddedFrames_; }

    void updateDeviceTime(const AudioDeviceTimeInfo& info) noexcept override;
    void processAudio(const float* const* inputs, float* const* outputs,
                      std::uint32_t inputChannels, std::uint32_t outputChannels,
                      std::uint32_t frames) noexcept override;

private:
    void runEngineBlock() noexcept;

    IAudioDeviceCallback* inner_ {nullptr};
    AudioDeviceConfig deviceConfig_ {};
    AudioDeviceConfig engineConfig_ {};
    StudioResampler up_;     // device rate -> engine rate (inputs)
    StudioResampler down_;   // engine rate -> device rate (outputs)
    std::vector<std::vector<float>> engineIn_;
    std::vector<std::vector<float>> engineOut_;
    std::vector<const float*> engineInPtrs_;
    std::vector<float*> engineOutPtrs_;
    std::vector<const float*> upPushPtrs_;
    std::vector<float*> upPullPtrs_;
    std::vector<const float*> downPushPtrs_;
    std::vector<float*> downPullPtrs_;
    std::uint32_t engineBlock_ {0U};
    std::uint32_t preRoll_ {0U};
    std::uint64_t paddedFrames_ {0U};
};

} // namespace silveton
