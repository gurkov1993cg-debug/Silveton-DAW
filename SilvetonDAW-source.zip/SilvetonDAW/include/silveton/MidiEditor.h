#pragma once
#include "silveton/MidiTimeline.h"
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton {

class MidiEditor final {
public:
    static constexpr std::size_t kMaxUndoSteps = 128U;
    explicit MidiEditor(MidiSequence& sequence) : sequence_(sequence) {}

    [[nodiscard]] std::uint64_t addNote(MusicalMidiNote note);
    [[nodiscard]] std::uint64_t addController(double quarterNotes, std::uint8_t channel,
                                               std::uint8_t controller, std::uint8_t value);
    [[nodiscard]] std::uint64_t addPitchBend(double quarterNotes, std::uint8_t channel, std::uint16_t value14Bit);
    [[nodiscard]] std::uint64_t addProgramChange(double quarterNotes, std::uint8_t channel, std::uint8_t program);
    bool deleteNote(std::uint64_t id);
    bool deleteMessage(std::uint64_t id);
    bool moveNote(std::uint64_t id, double quarterNotes);
    bool resizeNote(std::uint64_t id, double durationQuarterNotes);
    bool setVelocity(std::uint64_t id, std::uint8_t velocity);
    bool setReleaseVelocity(std::uint64_t id, std::uint8_t velocity);
    bool setPitch(std::uint64_t id, std::uint8_t pitch);
    bool setChannel(std::uint64_t id, std::uint8_t channel);
    bool setNoteMuted(std::uint64_t id, bool muted);
    bool moveMessage(std::uint64_t id, double quarterNotes);
    bool setMessageMuted(std::uint64_t id, bool muted);
    bool setControllerValue(std::uint64_t id, std::uint8_t value);
    void quantize(double divisionsPerQuarter, double strength = 1.0);
    void transpose(int semitones);

    [[nodiscard]] bool canUndo() const noexcept { return !undo_.empty(); }
    [[nodiscard]] bool canRedo() const noexcept { return !redo_.empty(); }
    bool undo();
    bool redo();
    void clearHistory() noexcept { undo_.clear(); redo_.clear(); }

private:
    struct Command { MidiSequence before; MidiSequence after; };
    template <typename Fn> bool mutate(Fn&& fn) {
        MidiSequence before = sequence_;
        if (!fn()) return false;
        push(std::move(before), sequence_);
        return true;
    }
    void push(MidiSequence before, MidiSequence after);

    MidiSequence& sequence_;
    std::vector<Command> undo_;
    std::vector<Command> redo_;
};

} // namespace silveton
