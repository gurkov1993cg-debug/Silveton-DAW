#pragma once
#include "silveton/Vst3Runtime.h"
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

struct Vst3PresetEntry {
    std::string path;
    std::string name;
    std::string modulePath;
    std::string classId;
    bool favorite {false};
    std::uint64_t lastUsedSerial {0U};
};

class Vst3PresetLibrary final {
public:
    void clear() noexcept { entries_.clear(); serial_ = 0U; }
    void scanDirectory(const std::string& directory, bool recursive = true);
    [[nodiscard]] const std::vector<Vst3PresetEntry>& entries() const noexcept { return entries_; }
    [[nodiscard]] std::vector<Vst3PresetEntry> forPlugin(const std::string& modulePath, const std::string& classId) const;
    [[nodiscard]] std::vector<Vst3PresetEntry> recent(std::size_t limit) const;
    [[nodiscard]] std::vector<Vst3PresetEntry> favorites() const;
    bool setFavorite(const std::string& path, bool favorite) noexcept;

    bool savePreset(IVst3PluginInstance& instance, const std::string& path, const std::string& displayName = {});
    bool loadPreset(IVst3PluginInstance& instance, const std::string& path);

    void saveIndex(const std::string& path) const;
    void loadIndex(const std::string& path);

private:
    Vst3PresetEntry* find(const std::string& path) noexcept;
    const Vst3PresetEntry* find(const std::string& path) const noexcept;
    void upsert(Vst3PresetEntry entry);
    static std::string displayNameFromPath(const std::string& path);

    std::vector<Vst3PresetEntry> entries_;
    std::uint64_t serial_ {0U};
};

} // namespace silveton
