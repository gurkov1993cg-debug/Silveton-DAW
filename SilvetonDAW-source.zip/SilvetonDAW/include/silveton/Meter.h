#pragma once
#include "silveton/AudioBuffer.h"
#include <vector>

namespace silveton {

struct ChannelMeter {
    float peakLinear {0.0F};
    float rmsLinear {0.0F};
    float peakDb {-160.0F};
    float rmsDb {-160.0F};
};

class Meter {
public:
    static std::vector<ChannelMeter> measure(const AudioBuffer& buffer);
    static float linearToDb(float value) noexcept;
};

} // namespace silveton
