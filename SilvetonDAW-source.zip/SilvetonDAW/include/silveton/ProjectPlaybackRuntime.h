#pragma once
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/DiskStream.h"
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace silveton {

enum class ProjectMediaIssueKind : std::uint8_t {
    MissingOrUnreadable = 0U,
    SampleRateMismatch = 1U,
    ChannelLayoutMismatch = 2U
};

struct ProjectMediaIssue {
    ProjectMediaIssueKind kind {ProjectMediaIssueKind::MissingOrUnreadable};
    std::string path;
    std::size_t trackIndex {0U};
    std::uint64_t clipId {0U};
    std::string detail;
};

struct ProjectPlaybackRuntimeStatus {
    std::size_t tracksPublished {0U};
    std::size_t uniqueAudioSources {0U};
    std::size_t offlineClips {0U};
    std::vector<ProjectMediaIssue> issues;
};

// Control-thread bridge from persistent Project media references into the
// realtime-safe AudioEngine/DiskStream layer. Missing media is represented as
// silent offline clips so routing, plug-ins, automation and project structure
// remain usable and can be relinked later.
class ProjectPlaybackRuntime final {
public:
    ProjectPlaybackRuntime(Project& project, AudioEngine& engine, std::size_t maxOpenFiles = 0U);
    ~ProjectPlaybackRuntime();
    ProjectPlaybackRuntime(const ProjectPlaybackRuntime&) = delete;
    ProjectPlaybackRuntime& operator=(const ProjectPlaybackRuntime&) = delete;

    ProjectPlaybackRuntimeStatus rebuild(std::uint32_t cacheFrames = 16384U,
                                         std::uint32_t primeTimeoutMilliseconds = 5000U);
    void stop() noexcept;

    [[nodiscard]] bool running() const noexcept { return streams_.running(); }
    [[nodiscard]] const ProjectPlaybackRuntimeStatus& status() const noexcept { return status_; }
    [[nodiscard]] DiskStreamManager& streams() noexcept { return streams_; }
    [[nodiscard]] const DiskStreamManager& streams() const noexcept { return streams_; }

private:
    std::shared_ptr<DiskAudioSource> resolveSource(const std::string& path,
                                   std::size_t trackIndex,
                                   std::uint64_t clipId,
                                   std::uint32_t cacheFrames);
    TimelineClip makeClip(const ProjectAudioClip& clip,
                          const ProjectTrack& track,
                          std::size_t trackIndex,
                          std::uint32_t cacheFrames);

    Project& project_;
    AudioEngine& engine_;
    DiskStreamManager streams_;
    std::unordered_map<std::string, std::size_t> sourceByPath_;
    ProjectPlaybackRuntimeStatus status_;
};

} // namespace silveton
