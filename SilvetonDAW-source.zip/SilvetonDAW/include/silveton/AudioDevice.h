#pragma once
#include <cstdint>
#include <vector>

namespace silveton {

struct AudioDeviceConfig {
    double sampleRate {48000.0};
    std::uint32_t blockSize {256};
    std::uint32_t inputChannels {0};
    std::uint32_t outputChannels {2};
};

struct AudioDeviceTimeInfo {
    double sampleTime {0.0};
    std::uint64_t hostTime {0U};
    bool sampleTimeValid {false};
    bool hostTimeValid {false};
};

class IAudioDeviceCallback {
public:
    virtual ~IAudioDeviceCallback() = default;
    // Optional timing notification immediately before processAudio(). The
    // default implementation keeps existing callbacks source-compatible.
    virtual void updateDeviceTime(const AudioDeviceTimeInfo&) noexcept {}
    virtual void processAudio(const float* const* inputs,
                              float* const* outputs,
                              std::uint32_t inputChannels,
                              std::uint32_t outputChannels,
                              std::uint32_t frames) noexcept = 0;
};

class IAudioDevice {
public:
    virtual ~IAudioDevice() = default;
    [[nodiscard]] virtual const AudioDeviceConfig& config() const noexcept = 0;
    virtual void start(IAudioDeviceCallback& callback) = 0;
    virtual void stop() noexcept = 0;
    [[nodiscard]] virtual bool isRunning() const noexcept = 0;
};

// Deterministic callback driver used to verify the real-time contract before
// adding platform backends (ASIO/CoreAudio). No DSP is hidden in this class.
class ManualAudioDevice final : public IAudioDevice {
public:
    explicit ManualAudioDevice(AudioDeviceConfig config);

    [[nodiscard]] const AudioDeviceConfig& config() const noexcept override { return config_; }
    void start(IAudioDeviceCallback& callback) override;
    void stop() noexcept override;
    [[nodiscard]] bool isRunning() const noexcept override { return callback_ != nullptr; }

    // Executes one device callback synchronously. Test/host harness only.
    void pump();
    [[nodiscard]] const std::vector<std::vector<float>>& lastOutput() const noexcept { return outputs_; }
    float* inputChannelData(std::size_t channel);

private:
    AudioDeviceConfig config_;
    IAudioDeviceCallback* callback_ {nullptr};
    std::vector<std::vector<float>> inputs_;
    std::vector<std::vector<float>> outputs_;
    std::vector<const float*> inputPtrs_;
    std::vector<float*> outputPtrs_;
    double sampleTime_ {0.0};
};

} // namespace silveton
