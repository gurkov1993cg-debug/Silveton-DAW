#pragma once
#include "silveton/TempoMap.h"
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton {

struct MusicalMidiNote {
    std::uint64_t id {0U};
    double startQuarterNotes {0.0};
    double durationQuarterNotes {1.0};
    std::uint8_t channel {0U};
    std::uint8_t pitch {60U};
    std::uint8_t velocity {100U};
    std::uint8_t releaseVelocity {64U};
    bool muted {false};
};


struct MusicalMidiMessage {
    std::uint64_t id {0U};
    double quarterNotes {0.0};
    std::uint8_t status {0U};
    std::uint8_t data1 {0U};
    std::uint8_t data2 {0U};
    bool muted {false};
};

struct ScheduledMidiEvent {
    std::int64_t sample {0};
    std::int32_t frameOffset {0};
    std::uint8_t status {0U};
    std::uint8_t data1 {0U};
    std::uint8_t data2 {0U};
};

class MidiRenderPlan {
public:
    [[nodiscard]] const std::vector<ScheduledMidiEvent>& events() const noexcept { return events_; }

    // Realtime-safe. Writes at most `capacity` events and performs no allocation.
    [[nodiscard]] std::size_t eventsForBlock(std::int64_t blockStartSample,
                                             std::uint32_t frames,
                                             ScheduledMidiEvent* output,
                                             std::size_t capacity) const noexcept;
private:
    friend class MidiSequence;
    std::vector<ScheduledMidiEvent> events_;
};

class MidiSequence {
public:
    [[nodiscard]] const std::vector<MusicalMidiNote>& notes() const noexcept { return notes_; }
    [[nodiscard]] const std::vector<MusicalMidiMessage>& messages() const noexcept { return messages_; }
    [[nodiscard]] std::uint64_t addNote(MusicalMidiNote note);
    [[nodiscard]] std::uint64_t addMessage(MusicalMidiMessage message);
    bool removeMessage(std::uint64_t id) noexcept;
    bool removeNote(std::uint64_t id) noexcept;
    bool moveNote(std::uint64_t id, double startQuarterNotes);
    bool resizeNote(std::uint64_t id, double durationQuarterNotes);
    bool setNoteVelocity(std::uint64_t id, std::uint8_t velocity) noexcept;
    bool setNoteReleaseVelocity(std::uint64_t id, std::uint8_t velocity) noexcept;
    bool setNotePitch(std::uint64_t id, std::uint8_t pitch) noexcept;
    bool setNoteChannel(std::uint64_t id, std::uint8_t channel) noexcept;
    bool setNoteMuted(std::uint64_t id, bool muted) noexcept;
    bool moveMessage(std::uint64_t id, double quarterNotes);
    bool setMessageData(std::uint64_t id, std::uint8_t status, std::uint8_t data1, std::uint8_t data2);
    bool setMessageMuted(std::uint64_t id, bool muted) noexcept;
    void quantize(double divisionsPerQuarter, double strength = 1.0);
    void transpose(int semitones) noexcept;
    [[nodiscard]] MidiRenderPlan compile(const TempoMap& tempoMap) const;

private:
    static void validateNote(const MusicalMidiNote& note);
    static void validateMessage(const MusicalMidiMessage& message);
    MusicalMidiNote* find(std::uint64_t id) noexcept;
    MusicalMidiMessage* findMessage(std::uint64_t id) noexcept;
    std::vector<MusicalMidiNote> notes_;
    std::vector<MusicalMidiMessage> messages_;
    std::uint64_t nextId_ {1U};
    std::uint64_t nextMessageId_ {1U};
};

struct MidiPart {
    std::uint64_t id {0U};
    double timelineStartQuarterNotes {0.0};
    double sourceOffsetQuarterNotes {0.0};
    double lengthQuarterNotes {4.0};
    double loopLengthQuarterNotes {4.0};
    bool muted {false};
    MidiSequence sequence;
};

[[nodiscard]] MidiRenderPlan compileMidiArrangement(const MidiSequence& legacySequence,
                                                    const std::vector<MidiPart>& parts,
                                                    const TempoMap& tempoMap);

} // namespace silveton
