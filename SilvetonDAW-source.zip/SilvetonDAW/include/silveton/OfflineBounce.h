#pragma once
#include <cstdint>
#include <string>

namespace silveton {

class AudioEngine;
class Vst3RuntimeRack;
struct Project;

enum class BounceTailMode : std::uint8_t {
    None = 0U,
    Automatic = 1U,
    Fixed = 2U
};

struct OfflineBounceOptions {
    // [startSample, endSample) in project timeline samples.
    std::int64_t startSample {0};
    std::int64_t endSample {0};

    // Zero uses the AudioEngine device block size. A smaller value is allowed.
    std::uint32_t blockSize {0U};

    // Optional hidden preroll. Preroll is processed but not written to the file,
    // allowing dynamics/delay state before a selected range to settle.
    std::uint64_t preRollSamples {0U};

    BounceTailMode tailMode {BounceTailMode::Automatic};
    std::uint64_t fixedTailSamples {0U};

    // A VST3 processor may report an infinite tail. Automatic bounce caps that
    // case to this many seconds instead of writing forever.
    double infiniteTailLimitSeconds {30.0};
};

struct OfflineBounceResult {
    std::uint64_t rangeFrames {0U};
    std::uint64_t tailFrames {0U};
    std::uint64_t totalFrames {0U};
    float peak {0.0F};
    bool processorReportedInfiniteTail {false};
};

class OfflineBounce final {
public:
    // The AudioEngine must already be prepared and stopped. The current live
    // graph, routing, PDC, automation and master path are used. If a VST3 rack is
    // supplied, project MIDI and VST3 parameter automation are queued for every
    // rendered arrangement block.
    static OfflineBounceResult renderFloat32Wav(const std::string& path,
                                                Project& project,
                                                AudioEngine& engine,
                                                Vst3RuntimeRack* vst3Rack,
                                                const OfflineBounceOptions& options);
};

} // namespace silveton
