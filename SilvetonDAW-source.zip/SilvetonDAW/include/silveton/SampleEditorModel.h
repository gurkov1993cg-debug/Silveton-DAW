#pragma once
// The maths behind the Sample Editor, free of any window code so it can be tested:
// zooming and scrolling, the time ruler, the waveform columns (from the envelope when
// zoomed out, from the real samples when zoomed in), peak read-outs and zero crossings.
//
// Positions are samples at the PROJECT rate. A view position is relative to the start
// of the edited span (see AudioRangeEdit). Media files stay at their own rate, so every
// piece carries the mapping from project samples to file samples.
#include "silveton/WaveformCache.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

struct SampleViewport {
    static constexpr double kMinSamplesPerPixel = 1.0 / 32.0;   // 32 pixels per sample is as far in as it goes

    double length {1.0};            // scrollable length in samples (the span)
    double first {0.0};             // first visible sample
    double samplesPerPixel {1.0};
    double widthPx {1.0};

    [[nodiscard]] double visibleSamples() const noexcept { return samplesPerPixel * widthPx; }
    [[nodiscard]] double sampleAtX(double x) const noexcept { return first + x * samplesPerPixel; }
    [[nodiscard]] double xAtSample(double sample) const noexcept { return (sample - first) / samplesPerPixel; }
    [[nodiscard]] double maxSamplesPerPixel() const noexcept;

    void configure(double spanLength, double width);   // new span or new window width; keeps the zoom when it still fits
    void fitAll();
    void zoomAbout(double anchorX, double factor);     // factor < 1 zooms in, > 1 zooms out
    void zoomToRange(double a, double b);              // shows [a, b] with a small margin
    void scrollPixels(double dx);
    void ensureVisible(double sample);                 // page-turn: jumps so the sample is near the left edge
    void clamp();
};

struct RulerTick {
    double sample {0.0};
    bool major {false};
    std::string label;   // only on major ticks
};

// Time ruler with 1-2-5 steps; a major tick is never closer than `minMajorPx` to the next one.
// `originSamples` is the project position of view position 0: ticks and labels are in project time.
[[nodiscard]] std::vector<RulerTick> buildRuler(const SampleViewport& view, double sampleRate, double minMajorPx = 96.0,
                                                double originSamples = 0.0);
[[nodiscard]] std::string formatRulerTime(double seconds, double stepSeconds);
[[nodiscard]] std::string formatClockTime(double seconds);   // m:ss.mmm for read-outs

// One piece of a clip as the editor draws it.
struct PieceView {
    double startRel {0.0};          // piece start, relative to the span start (project samples)
    double length {0.0};            // project samples
    double sourceStart {0.0};       // project samples into the media
    double projectRate {48000.0};
    const WaveformOverview* overview {nullptr};
    const WaveformDetail* detail {nullptr};

    [[nodiscard]] double fileRate() const noexcept;
    [[nodiscard]] double endRel() const noexcept { return startRel + length; }
    [[nodiscard]] double nativePosition(double rel) const noexcept;   // file sample for a view position
    [[nodiscard]] double relPosition(double nativePos) const noexcept;
};

struct ColumnPeak {
    float minimum {0.0F};
    float maximum {0.0F};
    bool valid {false};
};

// Min/max of the pixel columns [firstColumn, firstColumn + columns); out[i] is column firstColumn + i.
// Columns the piece does not cover (or has no data for yet) are invalid.
void columnPeaks(const PieceView& piece, const SampleViewport& view, std::size_t channel, std::size_t firstColumn,
                 std::size_t columns, std::vector<ColumnPeak>& out);

// File samples per pixel at this zoom (< 1: individual samples can be drawn).
[[nodiscard]] double pixelsPerFileSample(const PieceView& piece, const SampleViewport& view) noexcept;

// Linear interpolation of the real samples; false without sample detail.
[[nodiscard]] bool interpolatedSample(const PieceView& piece, std::size_t channel, double rel, float& value);

// Highest absolute sample of any channel in [relA, relB) (clipped to the piece); -1 when unknown.
[[nodiscard]] float peakInRange(const PieceView& piece, double relA, double relB);

// Nearest place where the sound crosses zero (first channel), within `maxDistance` project samples.
// Returns `rel` itself when there is no real-sample data or no crossing nearby.
[[nodiscard]] double nearestZeroCrossing(const PieceView& piece, double rel, double maxDistance);

} // namespace silveton
