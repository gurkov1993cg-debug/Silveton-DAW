// Level-meter behaviour for the user interface (no drawing, no AppKit):
// instant attack, steady fall in dB per second, a peak-hold marker, a latched
// clip lamp and the highest peak since the last reset. Time based, so the look
// does not change with the repaint rate.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton {

struct MeterChannelDisplay {
    float levelDb {-120.0F};    // the bar
    float holdDb {-120.0F};     // the small peak-hold marker
    float maxDb {-120.0F};      // highest peak since reset (numeric read-out)
    float holdAgeSeconds {0.0F};
    bool clip {false};          // latched until reset
};

struct StereoMeterDisplay {
    MeterChannelDisplay left;
    MeterChannelDisplay right;
    [[nodiscard]] bool clip() const noexcept { return left.clip || right.clip; }
    [[nodiscard]] float maxDb() const noexcept { return std::max(left.maxDb, right.maxDb); }
};

struct MeterBallistics {
    float floorDb {-100.0F};            // anything quieter is drawn as silence
    float fallDbPerSecond {26.0F};      // bar: a steady, calm fall (about 2.3 s for 60 dB)
    float holdSeconds {1.6F};           // the marker stays put this long ...
    float holdFallDbPerSecond {40.0F};  // ... then drops quickly onto the bar
    float clipLinear {1.0F};            // 0 dBFS or more lights the clip lamp
    float maxStepSeconds {0.25F};       // a stalled UI never makes the bar jump

    [[nodiscard]] static float toDb(float linear, float floorDb) noexcept {
        if (!(linear > 0.0F) || !std::isfinite(linear)) return floorDb;
        return std::max(floorDb, 20.0F * std::log10(linear));
    }

    void step(MeterChannelDisplay& m, float peakLinear, double dtSeconds) const noexcept {
        const float dt = static_cast<float>(std::clamp(dtSeconds, 0.0, static_cast<double>(maxStepSeconds)));
        const float db = toDb(peakLinear, floorDb);

        // Bar: attack is immediate (a peak meter must never under-read), release is linear in dB.
        m.levelDb = db >= m.levelDb ? db : std::max(db, m.levelDb - fallDbPerSecond * dt);

        // Marker: set by every new high, held for a moment, then falls and never sinks below the bar.
        if (db >= m.holdDb) {
            m.holdDb = db;
            m.holdAgeSeconds = 0.0F;
        } else {
            m.holdAgeSeconds += dt;
            if (m.holdAgeSeconds > holdSeconds) m.holdDb = std::max(m.levelDb, m.holdDb - holdFallDbPerSecond * dt);
        }
        m.holdDb = std::max(m.holdDb, m.levelDb);

        m.maxDb = std::max(m.maxDb, db);
        if (peakLinear >= clipLinear) m.clip = true;
    }
};

// One display per track plus the master, all driven from the same clock.
class MeterBank {
public:
    explicit MeterBank(MeterBallistics ballistics = {}) : ballistics_(ballistics) {}

    void setTrackCount(std::size_t count) { tracks_.resize(count); }
    [[nodiscard]] std::size_t trackCount() const noexcept { return tracks_.size(); }

    void feedTrack(std::size_t index, float leftPeak, float rightPeak, double dtSeconds) {
        if (index >= tracks_.size()) return;
        ballistics_.step(tracks_[index].left, leftPeak, dtSeconds);
        ballistics_.step(tracks_[index].right, rightPeak, dtSeconds);
    }
    void setBusCount(std::size_t count) { buses_.resize(count); }
    [[nodiscard]] std::size_t busCount() const noexcept { return buses_.size(); }
    void feedBus(std::size_t index, float leftPeak, float rightPeak, double dtSeconds) {
        if (index >= buses_.size()) return;
        ballistics_.step(buses_[index].left, leftPeak, dtSeconds);
        ballistics_.step(buses_[index].right, rightPeak, dtSeconds);
    }
    [[nodiscard]] StereoMeterDisplay bus(std::size_t index) const noexcept {
        return index < buses_.size() ? buses_[index] : StereoMeterDisplay {};
    }
    void resetBusPeaks(std::size_t index) noexcept {
        if (index >= buses_.size()) return;
        buses_[index].left.clip = buses_[index].right.clip = false;
        buses_[index].left.maxDb = buses_[index].left.levelDb;
        buses_[index].right.maxDb = buses_[index].right.levelDb;
    }
    void feedMaster(float leftPeak, float rightPeak, double dtSeconds) {
        ballistics_.step(master_.left, leftPeak, dtSeconds);
        ballistics_.step(master_.right, rightPeak, dtSeconds);
    }

    [[nodiscard]] StereoMeterDisplay track(std::size_t index) const noexcept {
        return index < tracks_.size() ? tracks_[index] : StereoMeterDisplay {};
    }
    [[nodiscard]] const StereoMeterDisplay& master() const noexcept { return master_; }

    // Clears the clip lamps and the numeric maximum (the bars keep running).
    void resetPeaks() noexcept {
        auto clear = [](MeterChannelDisplay& m) { m.clip = false; m.maxDb = m.levelDb; };
        for (auto& t : tracks_) { clear(t.left); clear(t.right); }
        for (auto& b : buses_) { clear(b.left); clear(b.right); }
        clear(master_.left); clear(master_.right);
    }
    void resetTrackPeaks(std::size_t index) noexcept {
        if (index >= tracks_.size()) return;
        tracks_[index].left.clip = tracks_[index].right.clip = false;
        tracks_[index].left.maxDb = tracks_[index].left.levelDb;
        tracks_[index].right.maxDb = tracks_[index].right.levelDb;
    }
    void resetMasterPeaks() noexcept {
        master_.left.clip = master_.right.clip = false;
        master_.left.maxDb = master_.left.levelDb;
        master_.right.maxDb = master_.right.levelDb;
    }

    [[nodiscard]] const MeterBallistics& ballistics() const noexcept { return ballistics_; }

private:
    MeterBallistics ballistics_;
    std::vector<StereoMeterDisplay> tracks_;
    std::vector<StereoMeterDisplay> buses_;
    StereoMeterDisplay master_;
};

} // namespace silveton
