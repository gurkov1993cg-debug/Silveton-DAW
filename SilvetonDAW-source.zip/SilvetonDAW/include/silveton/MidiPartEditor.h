#pragma once
#include "silveton/MidiTimeline.h"
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton {

class MidiPartEditor final {
public:
    static constexpr std::size_t kMaxUndoSteps = 128U;
    explicit MidiPartEditor(std::vector<MidiPart>& parts) : parts_(parts) {}

    [[nodiscard]] std::uint64_t add(MidiPart part);
    bool remove(std::uint64_t id);
    bool move(std::uint64_t id, double timelineStartQuarterNotes);
    bool trimLeft(std::uint64_t id, double amountQuarterNotes);
    bool trimRight(std::uint64_t id, double newLengthQuarterNotes);
    bool setLoopLength(std::uint64_t id, double loopLengthQuarterNotes);
    bool setMuted(std::uint64_t id, bool muted);
    [[nodiscard]] std::uint64_t duplicate(std::uint64_t id, double newTimelineStartQuarterNotes);
    [[nodiscard]] std::uint64_t split(std::uint64_t id, double timelineQuarterNotes);

    [[nodiscard]] bool canUndo() const noexcept { return !undo_.empty(); }
    [[nodiscard]] bool canRedo() const noexcept { return !redo_.empty(); }
    bool undo();
    bool redo();

private:
    struct Command { std::vector<MidiPart> before; std::vector<MidiPart> after; };
    MidiPart* find(std::uint64_t id) noexcept;
    std::uint64_t nextId() const;
    void validate(const MidiPart& part) const;
    void push(std::vector<MidiPart> before);

    std::vector<MidiPart>& parts_;
    std::vector<Command> undo_;
    std::vector<Command> redo_;
};

} // namespace silveton
