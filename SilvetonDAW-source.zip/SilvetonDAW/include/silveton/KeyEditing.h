// Silveton Key Editor — the editing rules behind the note grid, apart from the window.
// Everything works on a MidiSequence and is deterministic, so it can be tested without a screen.
#pragma once

#include "silveton/MidiTimeline.h"
#include "silveton/ToneEdit.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

// ============================================================= controller lanes ==
// A lane under the note grid. Velocity belongs to the notes; the others are messages in the sequence.
struct KeyLane {
    enum class Kind : std::uint8_t { Velocity = 0, Controller, PitchBend, Aftertouch };
    Kind kind {Kind::Velocity};
    std::uint8_t number {0U};     // controller number (Kind::Controller only)

    [[nodiscard]] static KeyLane velocity() noexcept { return {Kind::Velocity, 0U}; }
    [[nodiscard]] static KeyLane controller(std::uint8_t n) noexcept { return {Kind::Controller, static_cast<std::uint8_t>(n & 0x7FU)}; }
    [[nodiscard]] static KeyLane pitchBend() noexcept { return {Kind::PitchBend, 0U}; }
    [[nodiscard]] static KeyLane aftertouch() noexcept { return {Kind::Aftertouch, 0U}; }

    [[nodiscard]] bool operator==(const KeyLane& o) const noexcept { return kind == o.kind && (kind != Kind::Controller || number == o.number); }
    [[nodiscard]] bool operator!=(const KeyLane& o) const noexcept { return !(*this == o); }
    [[nodiscard]] bool isMessageLane() const noexcept { return kind != Kind::Velocity; }
    [[nodiscard]] int maxValue() const noexcept { return kind == Kind::PitchBend ? 16383 : 127; }
    [[nodiscard]] int centreValue() const noexcept { return kind == Kind::PitchBend ? 8192 : 0; }   // what "no change" means
    [[nodiscard]] bool matches(const MusicalMidiMessage& m) const noexcept;
    [[nodiscard]] int valueOf(const MusicalMidiMessage& m) const noexcept;
    [[nodiscard]] MusicalMidiMessage make(double quarterNotes, int value, std::uint8_t channel = 0U) const;
    [[nodiscard]] std::string name() const;
};

struct LanePoint {
    double quarterNotes {0.0};
    int value {0};
};

// The shapes of the Line tool.
enum class LaneShape : std::uint8_t { Line = 0, Parabola, Sine, Triangle, Square, Count };

// ===================================================================== chords ==
enum class ChordKind : std::uint8_t {
    Single = 0, Octave, PowerChord, Major, Minor, Diminished, Augmented, Sus2, Sus4, Major7, Minor7, Dominant7, Count
};

// What a note clipboard holds: the notes, with their places counted from the first one.
struct NoteClip {
    struct Item {
        double offset {0.0};
        double duration {1.0};
        std::uint8_t channel {0U};
        std::uint8_t pitch {60U};
        std::uint8_t velocity {100U};
        std::uint8_t releaseVelocity {64U};
        bool muted {false};
    };
    std::vector<Item> notes;
    double span {0.0};     // from the first start to the last end
    [[nodiscard]] bool empty() const noexcept { return notes.empty(); }
};

class KeyEditing {
public:
    using Ids = std::vector<std::uint64_t>;
    static constexpr double kShortestNote = 1.0 / 64.0;

    // -------------------------------------------------------------- names ----
    [[nodiscard]] static const char* laneShapeName(LaneShape shape) noexcept;
    [[nodiscard]] static const char* chordName(ChordKind kind) noexcept;
    [[nodiscard]] static std::vector<int> chordIntervals(ChordKind kind);      // semitones above the root, root included
    [[nodiscard]] static std::string noteName(int pitch);                      // "C3" = 60

    // ------------------------------------------------------------- notes ----
    [[nodiscard]] static std::vector<MusicalMidiNote> snapshot(const MidiSequence& seq, const Ids& ids);
    [[nodiscard]] static NoteClip copyNotes(const MidiSequence& seq, const Ids& ids);
    [[nodiscard]] static Ids pasteNotes(MidiSequence& seq, const NoteClip& clip, double atQuarterNotes);
    // Copies the notes right behind themselves. `shiftOut` receives the distance they moved.
    [[nodiscard]] static Ids duplicateNotes(MidiSequence& seq, const Ids& ids, double* shiftOut = nullptr);
    static std::size_t removeNotes(MidiSequence& seq, const Ids& ids);

    // Puts the notes `deltaQuarter` later and `deltaPitch` higher than they were in `original`. The whole group is held
    // back together when one note would leave the grid (before 0, below C-2, above G8), so a chord keeps its shape.
    // `appliedQuarter` / `appliedPitch` receive what was really used.
    static void moveFrom(MidiSequence& seq, const std::vector<MusicalMidiNote>& original, double deltaQuarter, int deltaPitch,
                         double* appliedQuarter = nullptr, int* appliedPitch = nullptr);
    // Every note gets `deltaQuarter` longer (or shorter) than in `original`, none shorter than kShortestNote.
    static void resizeFrom(MidiSequence& seq, const std::vector<MusicalMidiNote>& original, double deltaQuarter);
    // Every velocity moves by `delta` from its value in `original` (1..127).
    static void shiftVelocityFrom(MidiSequence& seq, const std::vector<MusicalMidiNote>& original, int delta);

    // Cuts one note in two at `quarter` (both parts at least kShortestNote). Returns {left, right} or nothing.
    [[nodiscard]] static Ids splitNote(MidiSequence& seq, std::uint64_t id, double quarter);
    // Cuts every listed note that sounds at `quarter`; the new right-hand halves are returned.
    [[nodiscard]] static Ids splitNotes(MidiSequence& seq, const Ids& ids, double quarter);
    // Joins notes of the same pitch and channel that touch or overlap into one. Returns the notes that remain.
    [[nodiscard]] static Ids glueNotes(MidiSequence& seq, const Ids& ids);
    // The Glue tool: this note grows through the next note of the same pitch, which disappears. Returns the note, or 0.
    static std::uint64_t glueToNext(MidiSequence& seq, std::uint64_t id);
    static std::size_t muteNotes(MidiSequence& seq, const Ids& ids, int mode);  // 0 = sound, 1 = mute, 2 = flip each note
    // Moves every note to the nearest note of the scale (an empty list means all notes). Returns how many changed.
    static std::size_t fitToScale(MidiSequence& seq, const Ids& ids, const ToneScale& scale);
    [[nodiscard]] static int pitchInScale(int pitch, const ToneScale& scale) noexcept;
    // Adds the notes of a chord on top of one new note. Returns the new ids (the root first).
    [[nodiscard]] static Ids addChord(MidiSequence& seq, const MusicalMidiNote& root, ChordKind kind);

    // Selection helpers (they never change the sequence).
    [[nodiscard]] static Ids allIds(const MidiSequence& seq);
    [[nodiscard]] static Ids invertSelection(const MidiSequence& seq, const Ids& ids);
    [[nodiscard]] static Ids selectSamePitch(const MidiSequence& seq, const Ids& ids);
    [[nodiscard]] static Ids selectFrom(const MidiSequence& seq, double quarter);     // notes that start at or after `quarter`
    [[nodiscard]] static Ids selectInside(const MidiSequence& seq, double fromQuarter, double toQuarter, int lowPitch, int highPitch);
    [[nodiscard]] static bool contains(const Ids& ids, std::uint64_t id) noexcept;
    [[nodiscard]] static const MusicalMidiNote* find(const MidiSequence& seq, std::uint64_t id) noexcept;

    // ------------------------------------------------------------- lanes ----
    [[nodiscard]] static std::vector<MusicalMidiMessage> laneMessages(const MidiSequence& seq, const KeyLane& lane);
    // The points of a shape between two places. `step` is the distance between points, `period` the length of one wave
    // (Sine, Triangle, Square). The points are thinned: a point that repeats the value before it is left out.
    [[nodiscard]] static std::vector<LanePoint> shapePoints(LaneShape shape, double fromQuarter, int fromValue, double toQuarter, int toValue,
                                                            double step, double period, int maxValue);
    // Writes the points into the lane: messages of the lane between the first and the last point are replaced.
    [[nodiscard]] static Ids writePoints(MidiSequence& seq, const KeyLane& lane, const std::vector<LanePoint>& points, std::uint8_t channel = 0U);
    static std::size_t eraseRange(MidiSequence& seq, const KeyLane& lane, double fromQuarter, double toQuarter);
    static std::size_t removeMessages(MidiSequence& seq, const Ids& ids);
    // Removes points that sit (within `tolerance` units) on the straight line between their neighbours.
    static std::size_t reduceLane(MidiSequence& seq, const KeyLane& lane, int tolerance);
    // Sets the value of an existing message of the lane.
    static bool setValue(MidiSequence& seq, const KeyLane& lane, std::uint64_t messageId, int value);
    [[nodiscard]] static const MusicalMidiMessage* findMessage(const MidiSequence& seq, std::uint64_t id) noexcept;
};

} // namespace silveton
