#pragma once
#include "silveton/DawCore.h"
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silveton {

enum class ClipSnapMode : std::uint8_t { Off = 0U, Samples = 1U, Musical = 2U };

struct ClipSnapSettings {
    ClipSnapMode mode {ClipSnapMode::Off};
    std::int64_t sampleStep {1};
    std::uint32_t divisionsPerQuarter {4U};
};

class ClipEditor {
public:
    static constexpr std::size_t kMaxUndoSteps = 128U;

    ClipEditor(Project& project, std::size_t trackIndex);

    [[nodiscard]] std::uint64_t addClip(ProjectAudioClip clip, const ClipSnapSettings& snap = {});
    void removeClip(std::uint64_t clipId);
    void moveClip(std::uint64_t clipId, std::int64_t timelineStartSample, const ClipSnapSettings& snap = {});
    [[nodiscard]] std::uint64_t splitClip(std::uint64_t clipId, std::int64_t timelineSample, const ClipSnapSettings& snap = {});
    void trimLeft(std::uint64_t clipId, std::int64_t newTimelineStartSample, const ClipSnapSettings& snap = {});
    void trimRight(std::uint64_t clipId, std::int64_t newTimelineEndSample, const ClipSnapSettings& snap = {});
    void setFades(std::uint64_t clipId, std::uint64_t fadeInSamples, std::uint64_t fadeOutSamples);
    void setGainDb(std::uint64_t clipId, float gainDb);
    void setMute(std::uint64_t clipId, bool mute);

    [[nodiscard]] bool canUndo() const noexcept { return !undo_.empty(); }
    [[nodiscard]] bool canRedo() const noexcept { return !redo_.empty(); }
    bool undo();
    bool redo();
    void clearHistory() noexcept;

private:
    struct Command {
        std::vector<ProjectAudioClip> before;
        std::vector<ProjectAudioClip> after;
    };

    ProjectTrack& track();
    const ProjectTrack& track() const;
    ProjectAudioClip& find(std::uint64_t clipId);
    [[nodiscard]] std::int64_t snapSample(std::int64_t sample, const ClipSnapSettings& snap) const;
    [[nodiscard]] std::uint64_t nextId() const;
    static void validate(const ProjectAudioClip& clip);
    void commit(std::vector<ProjectAudioClip> before);

    Project& project_;
    std::size_t trackIndex_ {0U};
    std::vector<Command> undo_;
    std::vector<Command> redo_;
};

} // namespace silveton
