#pragma once
// Silveton Tone Editor — how an edit lives inside a project.
//
// A clip is never changed in its media file. The first time a clip is opened in the Tone Editor,
// the sound it plays is kept as the "original". Every edit is rendered again FROM THE ORIGINAL into
// a new Float32 file at the project rate and the clip is relinked to it. The project keeps one
// small record per rendered file (see ProjectToneRecord): where the original is and the list of
// tone blocks with their settings. So the user can come back any day, see the same blocks, change
// them, or reset them — and undo / redo walk through the edits because the record is part of the
// project that undo stores.
#include "silveton/AudioBuffer.h"
#include "silveton/DawCore.h"
#include "silveton/ToneEdit.h"

#include <cstddef>
#include <cstdint>
#include <string>

namespace silveton {

// The sound the Tone Editor works on and where it comes from.
struct ToneSource {
    std::string path;                 // file of the untouched original
    std::uint64_t start {0U};         // frames (project rate) inside that file
    std::uint64_t length {0U};
    bool fromRecord {false};          // true: the clip plays a render of this original
    ToneAnalysisOptions options;      // the settings the edit was made with
};

class ToneProject final {
public:
    // The record of the file `renderedPath`, or null.
    [[nodiscard]] static const ProjectToneRecord* find(const Project& project, const std::string& renderedPath) noexcept;
    // Is `path` played by some clip of the project?
    [[nodiscard]] static bool referenced(const Project& project, const std::string& path) noexcept;

    // What the Tone Editor opens for this clip: the original of its record while the clip still plays
    // that record's render, otherwise the clip's own current sound. Throws when the clip is not found.
    [[nodiscard]] static ToneSource sourceFor(const Project& project, std::size_t trackIndex, std::uint64_t clipId);
    // The saved edit of this clip, or an empty edit when there is none yet.
    [[nodiscard]] static bool savedEdit(const Project& project, std::size_t trackIndex, std::uint64_t clipId, ToneEdit& out);
    // The original sound (project rate). Throws when the file cannot be read.
    [[nodiscard]] static AudioBuffer readSource(const ToneSource& source, double projectRate);

    // Writes a rendered sound as a new Float32 file in `directory` and returns its path.
    [[nodiscard]] static std::string writeRendered(const AudioBuffer& rendered, double projectRate, const std::string& originalPath,
                                                   const std::string& directory);
    // Gives the clip the rendered file and stores / replaces the record. Call it inside one undoable edit.
    // The clip keeps its place, its fades and (after the first render) the part of the sound it shows.
    static void commit(Project& project, std::size_t trackIndex, std::uint64_t clipId, const ToneSource& source, const ToneEdit& edit,
                       const std::string& renderedPath, std::uint64_t renderedFrames, std::uint32_t renderedChannels);

    // Throws away the records of files no clip plays any more.
    static void prune(Project& project);
};

} // namespace silveton
