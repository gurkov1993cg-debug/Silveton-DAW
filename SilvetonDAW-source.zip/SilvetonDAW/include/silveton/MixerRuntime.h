#pragma once

#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/Vst3Runtime.h"
#include <cstddef>
#include <cstdint>

namespace silveton {

struct MixerRuntimeServiceResult {
    Vst3RuntimeServiceResult vst3;
    bool graphPublished {false};
    std::uint64_t graphGeneration {0U};
};

// Control-thread coordinator for the already realtime-safe pieces. It converts
// project/rack state into a replacement immutable graph, publishes it, and only
// releases VST3 instances retired by a reload after the audio thread has adopted
// the replacement and the predecessor graph has been reclaimed.
class MixerRuntimeCoordinator {
public:
    MixerRuntimeCoordinator(Project& project,
                            Vst3RuntimeRack& rack,
                            AudioEngine& engine,
                            std::uint32_t maxCompensationSamples = 16384U) noexcept;

    std::uint64_t publishProjectRouting();
    [[nodiscard]] MixerRuntimeServiceResult serviceVst3Changes();
    std::size_t reclaimRetired() noexcept;

    [[nodiscard]] bool rebuildPending() const noexcept { return rebuildRequired_; }
    [[nodiscard]] std::uint64_t lastPublishedGeneration() const noexcept { return lastPublishedGeneration_; }

private:
    std::uint64_t publishRequiredGraph();

    Project& project_;
    Vst3RuntimeRack& rack_;
    AudioEngine& engine_;
    std::uint32_t maxCompensationSamples_ {16384U};
    bool rebuildRequired_ {false};
    bool retiredInstancesWaiting_ {false};
    std::uint64_t retiredInstancesGeneration_ {0U};
    std::uint64_t lastPublishedGeneration_ {0U};
};

} // namespace silveton
