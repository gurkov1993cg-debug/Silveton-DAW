#pragma once
#include <cstddef>
#include <cstdint>
#include <memory>
#include <stdexcept>
#include <vector>

namespace silveton {

struct ProcessorContext {
    double sampleRate {48000.0};
    std::int64_t projectSample {0};
    std::uint32_t frames {0};
    double tempo {120.0};
    bool playing {false};
    bool recording {false};
    bool cycleActive {false};
    std::int64_t cycleStartSample {0};
    std::int64_t cycleEndSample {0};
    double projectQuarterNotes {0.0};
    double cycleStartQuarterNotes {0.0};
    double cycleEndQuarterNotes {0.0};
};

struct ConstStereoBus {
    const float* left {nullptr};
    const float* right {nullptr};
};

struct StereoBus {
    float* left {nullptr};
    float* right {nullptr};
};

class ITrackProcessor {
public:
    virtual ~ITrackProcessor() = default;
    virtual void prepare(double sampleRate, std::uint32_t maxFrames) = 0;
    virtual void reset() noexcept = 0;
    [[nodiscard]] virtual std::uint32_t latencySamples() const noexcept = 0;
    virtual void process(float* left,
                         float* right,
                         std::uint32_t frames,
                         const ProcessorContext& context) noexcept = 0;
};

class IRoutedTrackProcessor : public ITrackProcessor {
public:
    [[nodiscard]] virtual std::size_t inputBusCount() const noexcept = 0;
    [[nodiscard]] virtual std::size_t outputBusCount() const noexcept = 0;
    virtual bool processBuses(const ConstStereoBus* inputs,
                              std::size_t inputBusCount,
                              StereoBus* outputs,
                              std::size_t outputBusCount,
                              std::uint32_t frames,
                              const ProcessorContext& context) noexcept = 0;
};

struct ProcessorRouting {
    // -1 means no sidechain. Audio effects normally use bus 0 as main input/output;
    // generator instruments may legally expose zero audio input buses.
    int sidechainSourceNode {-1};
    // Index 0 here maps processor output bus 1, index 1 -> output bus 2, ...
    std::vector<int> extraOutputDestinations;
};

struct ProcessorSlotDefinition {
    ITrackProcessor* processor {nullptr};
    ProcessorRouting routing;
};

struct GraphNodeDefinition {
    std::vector<ProcessorSlotDefinition> processors;
};

struct MainRouteDefinition {
    std::size_t from {0};
    std::size_t to {0};
    float gain {1.0F};
};

class ProcessorGraph {
public:
    ProcessorGraph();
    ~ProcessorGraph();
    ProcessorGraph(const ProcessorGraph&) = delete;
    ProcessorGraph& operator=(const ProcessorGraph&) = delete;
    ProcessorGraph(ProcessorGraph&&) noexcept;
    ProcessorGraph& operator=(ProcessorGraph&&) noexcept;

    void configure(std::vector<GraphNodeDefinition> nodes,
                   std::vector<MainRouteDefinition> routes,
                   std::size_t masterNode);
    void prepare(double sampleRate,
                 std::uint32_t maxFrames,
                 std::uint32_t maxCompensationSamples = 16384U);
    void reset() noexcept;
    // Control-thread latency refresh used after a plug-in reports kLatencyChanged.
    // Reuses preallocated delay lines and performs no heap allocation.
    void refreshLatencies();

    [[nodiscard]] std::size_t nodeCount() const noexcept;
    [[nodiscard]] std::uint32_t nodeOutputLatency(std::size_t node) const;
    [[nodiscard]] bool prepared() const noexcept;

    // nodeSources has nodeCount() entries. A null bus is treated as silence.
    // The graph owns all temporary/delay memory and performs no heap allocation here.
    void process(const ConstStereoBus* nodeSources,
                 std::size_t sourceCount,
                 StereoBus masterOutput,
                 std::uint32_t frames,
                 const ProcessorContext& context) noexcept;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace silveton
