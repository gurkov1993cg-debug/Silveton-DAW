#pragma once
#include "silveton/AutomationRuntime.h"
#include "silveton/MixMath.h"
#include <cstddef>
#include <cstdint>
#include <memory>
#include <stdexcept>
#include <vector>

namespace silveton {

enum class ProcessorRunMode : std::uint8_t { Realtime = 0U, Offline = 1U };

struct ProcessorContext {
    double sampleRate {48000.0};
    std::int64_t projectSample {0};
    std::uint32_t frames {0};
    double tempo {120.0};
    std::uint16_t timeSignatureNumerator {4U};
    std::uint16_t timeSignatureDenominator {4U};
    bool playing {false};
    bool recording {false};
    bool cycleActive {false};
    std::int64_t cycleStartSample {0};
    std::int64_t cycleEndSample {0};
    double projectQuarterNotes {0.0};
    double barStartQuarterNotes {0.0};
    double cycleStartQuarterNotes {0.0};
    double cycleEndQuarterNotes {0.0};
};

struct ConstStereoBus {
    const float* left {nullptr};
    const float* right {nullptr};
};

struct StereoBus {
    float* left {nullptr};
    float* right {nullptr};
};

class ITrackProcessor {
public:
    virtual ~ITrackProcessor() = default;
    virtual void prepare(double sampleRate, std::uint32_t maxFrames) = 0;
    virtual void reset() noexcept = 0;
    [[nodiscard]] virtual std::uint32_t latencySamples() const noexcept = 0;
    // Number of samples the processor can continue producing after its input becomes silent.
    // UINT64_MAX denotes an effectively infinite tail. Built-in processors default to no tail.
    [[nodiscard]] virtual std::uint64_t tailSamples() const noexcept { return 0U; }
    // Control-thread mode switch used by offline export. Non-VST processors may
    // use identical algorithms in both modes and therefore accept the default.
    virtual bool setRunMode(ProcessorRunMode) { return true; }
    virtual void process(float* left,
                         float* right,
                         std::uint32_t frames,
                         const ProcessorContext& context) noexcept = 0;
};

class IRoutedTrackProcessor : public ITrackProcessor {
public:
    [[nodiscard]] virtual std::size_t inputBusCount() const noexcept = 0;
    [[nodiscard]] virtual std::size_t outputBusCount() const noexcept = 0;
    virtual bool processBuses(const ConstStereoBus* inputs,
                              std::size_t inputBusCount,
                              StereoBus* outputs,
                              std::size_t outputBusCount,
                              std::uint32_t frames,
                              const ProcessorContext& context) noexcept = 0;
};

struct ProcessorRouting {
    // -1 means no sidechain. Audio effects normally use bus 0 as main input/output;
    // generator instruments may legally expose zero audio input buses.
    int sidechainSourceNode {-1};
    // Index 0 here maps processor output bus 1, index 1 -> output bus 2, ...
    std::vector<int> extraOutputDestinations;
};

struct ProcessorSlotDefinition {
    ITrackProcessor* processor {nullptr};
    ProcessorRouting routing;
};

struct GraphNodeMixControl {
    bool enabled {false};
    float gainDb {0.0F};
    bool mute {false};
    float pan {0.0F};
    bool monoSource {false};
    bool useDualStereoPan {false};
    float stereoLeftPan {-1.0F};
    float stereoRightPan {1.0F};
    PanDepth panDepth {PanDepth::Minus3dB};
    std::shared_ptr<const AutomationLane> gainAutomationDb;
    std::shared_ptr<const AutomationLane> panAutomation;
    std::shared_ptr<const AutomationLane> muteAutomation;
};

struct GraphNodeDefinition {
    std::vector<ProcessorSlotDefinition> processors;
    GraphNodeMixControl mix;
};

enum class MainRouteTap : std::uint8_t {
    PreFader = 0U,
    PostFader = 1U
};

struct MainRouteDefinition {
    std::size_t from {0};
    std::size_t to {0};
    float gain {1.0F};
    MainRouteTap tap {MainRouteTap::PostFader};
    // Optional automation in dB, multiplied by the static linear gain.
    std::shared_ptr<const AutomationLane> gainAutomationDb;
    float gainAutomationFallbackDb {0.0F};
    // Optional 0/1 lane. Values >= 0.5 mean enabled.
    std::shared_ptr<const AutomationLane> enabledAutomation;
    bool enabledFallback {true};
};

class ProcessorGraph {
public:
    ProcessorGraph();
    ~ProcessorGraph();
    ProcessorGraph(const ProcessorGraph&) = delete;
    ProcessorGraph& operator=(const ProcessorGraph&) = delete;
    ProcessorGraph(ProcessorGraph&&) noexcept;
    ProcessorGraph& operator=(ProcessorGraph&&) noexcept;

    void configure(std::vector<GraphNodeDefinition> nodes,
                   std::vector<MainRouteDefinition> routes,
                   std::size_t masterNode);
    void prepare(double sampleRate,
                 std::uint32_t maxFrames,
                 std::uint32_t maxCompensationSamples = 16384U);
    // Prepare a replacement immutable graph while an older graph may still be
    // processing on the realtime thread. Processors already present in the
    // predecessor graph are not re-prepared or reset; only graph-owned routing,
    // scratch and PDC state is allocated/reset on the control thread. Newly
    // introduced processors are prepared normally.
    void prepareForPublication(double sampleRate,
                               std::uint32_t maxFrames,
                               std::uint32_t maxCompensationSamples,
                               const ProcessorGraph* predecessor);
    void reset() noexcept;
    // Control-thread latency refresh used after a plug-in reports kLatencyChanged.
    // Reuses preallocated delay lines and performs no heap allocation.
    void refreshLatencies();

    [[nodiscard]] std::size_t nodeCount() const noexcept;
    [[nodiscard]] std::uint32_t nodeOutputLatency(std::size_t node) const;
    // Conservative graph-wide tail bound. Finite processor tails are summed so
    // serial/parallel routing never truncates a reported tail. UINT64_MAX means
    // at least one processor reports an infinite tail.
    [[nodiscard]] std::uint64_t maximumTailSamples() const noexcept;
    // Switch every unique processor in the graph between normal playback and
    // offline export mode. Must be called from the control thread while the
    // realtime device is not concurrently driving this graph.
    bool setRunMode(ProcessorRunMode mode);
    // Copy the most recently processed post-fader output of one graph node.
    // Used for offline Group/FX stem taps. No allocation is performed.
    bool copyNodePostFader(std::size_t node, StereoBus output, std::uint32_t frames) const noexcept;
    [[nodiscard]] bool prepared() const noexcept;
    [[nodiscard]] bool containsProcessor(const ITrackProcessor* processor) const noexcept;
    [[nodiscard]] bool nodeUsesMixControl(std::size_t node) const noexcept;
    // Number of persistent helper threads currently available for independent
    // graph branches. The audio thread also participates in the work.
    [[nodiscard]] std::uint32_t parallelWorkerCount() const noexcept;
    [[nodiscard]] std::size_t executionLayerCount() const noexcept;
    // Control-thread copy of topology/routing only. Processor pointers are shared
    // intentionally so a live replacement can recalculate PDC without resetting
    // already-running plug-ins.
    [[nodiscard]] std::unique_ptr<ProcessorGraph> cloneDefinition() const;

    // nodeSources has nodeCount() entries. A null bus is treated as silence.
    // The graph owns all temporary/delay memory and performs no heap allocation here.
    void process(const ConstStereoBus* nodeSources,
                 std::size_t sourceCount,
                 StereoBus masterOutput,
                 std::uint32_t frames,
                 const ProcessorContext& context,
                 const std::uint8_t* nodeEnabled = nullptr,
                 std::size_t nodeEnabledCount = 0U) noexcept;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace silveton
