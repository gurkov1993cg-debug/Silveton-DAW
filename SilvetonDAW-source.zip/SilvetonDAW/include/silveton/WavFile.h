#pragma once
#include "silveton/AudioBuffer.h"
#include <cstdint>
#include <filesystem>

namespace silveton {

struct WavData {
    std::uint32_t sampleRate {0};
    AudioBuffer audio;
};

class WavFile {
public:
    static void writeFloat32(const std::filesystem::path& path, std::uint32_t sampleRate, const AudioBuffer& buffer);
    static WavData read(const std::filesystem::path& path);
};

} // namespace silveton
