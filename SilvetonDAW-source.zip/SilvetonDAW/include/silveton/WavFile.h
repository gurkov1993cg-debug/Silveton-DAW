#pragma once
#include "silveton/AudioBuffer.h"
#include <cstdint>
#include <string>

namespace silveton {

struct WavData {
    std::uint32_t sampleRate {0};
    AudioBuffer audio;
};

class WavFile {
public:
    static void writeFloat32(const std::string& path, std::uint32_t sampleRate, const AudioBuffer& buffer);
    static WavData read(const std::string& path);
};

} // namespace silveton
