#pragma once
// Quantize family (Cubase-style): Quantize Setup with grid type / swing /
// iterative strength / magnetic area / non-quantize / random, Groove Quantize
// (extract a groove from a part, built-in swing grooves), Quantize Length, and
// Audio Quantize (transient detection, slicing, moving slices to the grid).
#include "silveton/AudioBuffer.h"
#include "silveton/DawCore.h"
#include "silveton/MidiTimeline.h"

#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

enum class QuantizeGridType : std::uint8_t { Straight = 0, Triplet = 1, Dotted = 2 };

struct QuantizeSettings {
    double gridQuarterNotes {0.25};            // 1/16
    QuantizeGridType type {QuantizeGridType::Straight};
    double swing {0.0};                        // 0..1
    double strength {1.0};                     // 0..1 (iterative quantize)
    double magneticArea {1.0};                 // 0..1 of half a grid step; 0 = nothing moves
    double nonQuantizeQuarterNotes {0.0};      // notes closer than this to the grid stay
    double randomQuarterNotes {0.0};           // +/- after quantizing
    std::uint32_t seed {1U};
    bool quantizeStart {true};
    bool quantizeEnd {false};
    bool quantizeLength {false};               // durations become multiples of the grid
};

struct GrooveTemplate {
    std::string name;
    double gridQuarterNotes {0.25};
    double patternQuarterNotes {1.0};          // repeats every pattern
    std::vector<double> offsetQuarterNotes;    // per grid slot in the pattern
    std::vector<double> velocityScale;         // per grid slot, 1.0 = unchanged
};

class Quantizer final {
public:
    using Selection = std::vector<std::uint64_t>;
    [[nodiscard]] static double effectiveGrid(const QuantizeSettings& s);
    // Nearest grid position (with swing) for a time.
    [[nodiscard]] static double nearestGridPoint(double quarterNotes, const QuantizeSettings& s);
    static std::size_t apply(MidiSequence& seq, const QuantizeSettings& s, const Selection& selection = {});

    // Groove quantize.
    [[nodiscard]] static GrooveTemplate extractGroove(const MidiSequence& seq, double gridQuarterNotes,
                                                      double patternQuarterNotes, const Selection& selection = {});
    [[nodiscard]] static GrooveTemplate swingGroove(double gridQuarterNotes, double percent);   // 50..75
    [[nodiscard]] static std::vector<GrooveTemplate> builtInGrooves();
    static std::size_t applyGroove(MidiSequence& seq, const GrooveTemplate& groove, double timingStrength = 1.0,
                                   double velocityStrength = 0.0, const Selection& selection = {});
};

struct AudioQuantizeOptions {
    double sensitivity {0.5};     // 0..1, higher finds more transients
    double strength {1.0};        // 0..1
    double fadeMilliseconds {3.0};
};

class AudioQuantizer final {
public:
    // Transient positions (frames from the start of `audio`).
    [[nodiscard]] static std::vector<std::uint64_t> detectTransients(const AudioBuffer& audio, double sampleRate, double sensitivity);
    // Slices the clip at its transients and moves every slice to the grid.
    // Returns the number of slices. Edits `project` (use inside a session edit).
    static std::size_t quantizeClip(Project& project, std::size_t trackIndex, std::uint64_t clipId,
                                    const QuantizeSettings& settings, const AudioQuantizeOptions& options = {});
};

} // namespace silveton
