#pragma once
// Range editing for the Sample Editor: select a part of the audio and cut, copy,
// paste, crop or process just that part. Nothing in a media file is ever changed:
// a range edit cuts the clips on the track into pieces (the pieces keep pointing at
// the same media), removes or moves pieces, or renders a new media file for the
// piece that was processed. All positions are timeline samples at the project rate.
//
// The editor does not show one clip but a "span": the clips of one track that touch
// or overlap the selected clip. After a cut the pieces of the span still touch, so
// the editor keeps showing the whole piece of audio the user is working on.
#include "silveton/AudioProcessing.h"
#include "silveton/DawCore.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

struct TimelineRange {
    std::int64_t start {0};
    std::int64_t end {0};
    [[nodiscard]] bool valid() const noexcept { return end > start; }
    [[nodiscard]] std::int64_t length() const noexcept { return end - start; }
};

// Samples drawn by hand (the pencil of the Sample Editor): one value per timeline sample.
struct DrawnSamples {
    std::int64_t start {0};        // timeline sample of values[0]
    std::vector<float> values;     // the audio values to write (-1..1), without clip gain
    int channel {-1};              // the channel to change (0 = left, 1 = right), -1 = all channels
};

struct EditSpan {
    std::int64_t start {0};
    std::int64_t end {0};
    std::vector<std::uint64_t> clipIds;   // ordered by timeline start
    [[nodiscard]] bool empty() const noexcept { return clipIds.empty(); }
    [[nodiscard]] std::int64_t length() const noexcept { return end - start; }
};

// Pieces of audio taken out of a range. Piece positions are relative to the start of the range.
struct RangeClipboard {
    std::vector<ProjectAudioClip> pieces;
    std::int64_t length {0};
    [[nodiscard]] bool empty() const noexcept { return pieces.empty() || length <= 0; }
};

// Where the fades of a clip end / begin, as the editor draws them (timeline samples, inside the clip).
struct ClipFadeGeometry {
    double fadeInEnd {0.0};      // the clip start when there is no fade-in
    double fadeOutStart {0.0};   // the clip end when there is no fade-out
};

class AudioRangeEdit final {
public:
    // The gain of the clip fades at a timeline sample (1 = untouched). Same rule as the engine,
    // including the fade anchors that split pieces keep. The clip gain is not included.
    [[nodiscard]] static double fadeGain(const ProjectAudioClip& clip, double timelineSample) noexcept;
    [[nodiscard]] static ClipFadeGeometry fadeGeometry(const ProjectAudioClip& clip) noexcept;

    // The clips of the track that touch or overlap the clip `clipId`, chained
    // (a gap of up to `tolerance` samples still counts as touching).
    [[nodiscard]] static EditSpan span(const Project& project, std::size_t track, std::uint64_t clipId,
                                       std::int64_t tolerance = 1);

    // Cuts every clip that crosses an edge of `range`, so each piece lies inside or
    // outside. Returns the ids of the pieces inside the range, ordered by start.
    static std::vector<std::uint64_t> isolate(Project& project, std::size_t track, TimelineRange range);

    // Removes the audio inside `range`. With `ripple`, the part of the span after the
    // range (clips that start in [range.end, windowEnd)) moves left to close the gap.
    static void erase(Project& project, std::size_t track, TimelineRange range, bool ripple, std::int64_t windowEnd);

    // Keeps only `range`: the rest of the span is removed. The kept part stays where it is.
    static void crop(Project& project, std::size_t track, TimelineRange range, const EditSpan& span);

    // Copies the audio of `range` (the project is not changed).
    [[nodiscard]] static RangeClipboard copy(const Project& project, std::size_t track, TimelineRange range);

    // Puts the clipboard at `at`. With `ripple` the audio after `at` (clips that start in
    // [at, windowEnd), after a clip crossing `at` is cut) moves right to make room (insert);
    // without it the pasted audio is laid over what is there. Returns the new clip ids.
    static std::vector<std::uint64_t> insert(Project& project, std::size_t track, std::int64_t at,
                                             const RangeClipboard& clipboard, bool ripple, std::int64_t windowEnd);

    // Writes hand-drawn sample values into the audio. Only the pieces under the drawn samples get a
    // new media file; the rest stays. Returns the ids of the changed pieces, ordered by start.
    static std::vector<std::uint64_t> draw(Project& project, std::size_t track, const DrawnSamples& drawn,
                                           const std::string& outputDirectory);

    // Renders `process` for the audio inside `range` only (every piece gets its own new media
    // file in `outputDirectory`). A process that changes the length (time stretch) moves the
    // rest of the span (clips that start in [range.end, windowEnd)). Returns the processed
    // piece ids, ordered by start.
    static std::vector<std::uint64_t> process(Project& project, std::size_t track, TimelineRange range,
                                              AudioProcess process, const AudioProcessOptions& options,
                                              const std::string& outputDirectory, std::int64_t windowEnd);
};

} // namespace silveton
