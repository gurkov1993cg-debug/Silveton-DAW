#pragma once
#include "silveton/Vst3ScannerIsolation.h"
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

struct Vst3CatalogEntry {
    std::string modulePath;
    std::string classId;
    std::string name;
    std::string vendor;
    std::string version;
    std::string sdkVersion;
    std::vector<std::string> subCategories;
};

class Vst3PluginCatalog final {
public:
    [[nodiscard]] const std::vector<Vst3CatalogEntry>& entries() const noexcept { return entries_; }
    void replaceModule(const std::string& modulePath, const std::vector<Vst3ScanRecord>& records);
    [[nodiscard]] std::vector<Vst3CatalogEntry> search(const std::string& text, const Vst3Blacklist* blacklist = nullptr) const;
    void save(const std::string& path) const;
    void load(const std::string& path);
private:
    std::vector<Vst3CatalogEntry> entries_;
};

struct Vst3BatchScanSummary {
    std::size_t requestedModules {0U};
    std::size_t scannedModules {0U};
    std::size_t skippedQuarantined {0U};
    std::size_t failedModules {0U};
    std::size_t discoveredClasses {0U};
};

class Vst3PluginBrowserService final {
public:
    Vst3PluginBrowserService(std::string scannerExecutable,
                             std::string cachePath,
                             std::string quarantinePath,
                             std::uint32_t timeoutMs = 5000U);
    void load();
    void save() const;
    Vst3IsolatedScanResult scanModule(const std::string& modulePath);
    Vst3BatchScanSummary scanModules(const std::vector<std::string>& modulePaths, bool persistAfterScan = true);
    void quarantineClass(const std::string& modulePath, const std::string& classId, const std::string& reason);
    bool removeFromQuarantine(const std::string& modulePath, const std::string& classId);
    [[nodiscard]] std::vector<Vst3CatalogEntry> search(const std::string& text) const;
    [[nodiscard]] const Vst3PluginCatalog& catalog() const noexcept { return catalog_; }
    [[nodiscard]] const Vst3Blacklist& quarantine() const noexcept { return quarantine_; }
private:
    std::string scannerExecutable_, cachePath_, quarantinePath_;
    std::uint32_t timeoutMs_ {5000U};
    Vst3PluginCatalog catalog_;
    Vst3Blacklist quarantine_;
};

} // namespace silveton
