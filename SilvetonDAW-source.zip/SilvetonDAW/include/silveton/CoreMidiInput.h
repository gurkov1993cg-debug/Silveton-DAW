#pragma once
#include "silveton/MidiInput.h"
#include "silveton/RealtimeClockMapper.h"
#if defined(__APPLE__)
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
namespace silveton {
struct CoreMidiSourceInfo { std::uint32_t index{0U}; std::string name; bool connected{false}; };
class CoreMidiInput final {
public:
    CoreMidiInput(MidiInputCapture& capture,RealtimeClockMapper& clock);
    ~CoreMidiInput();
    CoreMidiInput(const CoreMidiInput&)=delete;CoreMidiInput& operator=(const CoreMidiInput&)=delete;
    [[nodiscard]] std::vector<CoreMidiSourceInfo> sources() const;
    void connectAll();void disconnectAll() noexcept;
    void setTargetPort(int port) noexcept;
    [[nodiscard]] int targetPort() const noexcept;
private:class Impl;std::unique_ptr<Impl> impl_;
};
} // namespace silveton
#endif
