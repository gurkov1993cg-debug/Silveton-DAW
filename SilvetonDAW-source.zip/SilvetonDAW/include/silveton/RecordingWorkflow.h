#pragma once
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/Metronome.h"
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

class RecordingWorkflow {
public:
    RecordingWorkflow(AudioEngine& engine, Project& project, std::size_t trackIndex);
    ~RecordingWorkflow();
    RecordingWorkflow(const RecordingWorkflow&) = delete;
    RecordingWorkflow& operator=(const RecordingWorkflow&) = delete;

    void start(const std::string& audioPath,
               std::uint32_t channels,
               std::uint32_t ringCapacityFrames = 262144U);

    // Arms recording with a musical count-in. The transport is positioned the
    // requested number of complete bars before recordStartSample and starts
    // playing immediately, while disk recording is sample-accurately gated to
    // [recordStartSample, recordEndSample). Existing punch settings are restored
    // when Stop Recording commits the takes.
    void startWithCountIn(const std::string& audioPath,
                          std::uint32_t channels,
                          std::int64_t recordStartSample,
                          std::int64_t recordEndSample,
                          std::uint32_t countInBars,
                          std::uint32_t ringCapacityFrames = 262144U);

    // Stops disk recording, waits only on the control thread for any in-flight
    // callback to leave the recorder section, then commits all recorded cycle
    // passes as nondestructive take lanes. Returns the new lane IDs.
    [[nodiscard]] std::vector<std::uint64_t> stopAndCommitTakes();

    // Promotes one committed take to the active comp over every clip range in
    // that lane. Existing comp selections outside those ranges are preserved.
    void promoteTakeToComp(std::uint64_t takeLaneId,
                           std::uint64_t crossfadeSamples = 0U);

    [[nodiscard]] bool active() const noexcept { return active_; }
    [[nodiscard]] RecorderStatus status() const noexcept { return recorder_.status(); }
    [[nodiscard]] WaveformOverview waveformPreview(std::uint64_t firstFrame,
                                                   std::uint64_t frameCount,
                                                   std::size_t maxPeaks = 2048U) const {
        return recorder_.waveformPreview(firstFrame, frameCount, maxPeaks);
    }
    [[nodiscard]] const std::string& audioPath() const noexcept { return audioPath_; }
    [[nodiscard]] bool countInArmed() const noexcept { return countInArmed_; }
    [[nodiscard]] bool countInActive() const noexcept {
        return active_ && countInArmed_ && engine_.transport().positionSamples() < scheduledRecordStartSample_;
    }
    [[nodiscard]] std::int64_t countInStartSample() const noexcept { return countInStartSample_; }
    [[nodiscard]] std::int64_t scheduledRecordStartSample() const noexcept { return scheduledRecordStartSample_; }

private:
    [[nodiscard]] ProjectTrack& track();
    void startRecorder(const std::string& audioPath,
                       std::uint32_t channels,
                       std::uint32_t ringCapacityFrames);
    void restorePunchState() noexcept;

    AudioEngine& engine_;
    Project& project_;
    std::size_t trackIndex_ {0U};
    Recorder recorder_;
    std::string audioPath_;
    bool active_ {false};
    bool countInArmed_ {false};
    std::int64_t countInStartSample_ {0};
    std::int64_t scheduledRecordStartSample_ {0};
    bool restorePunchOnStop_ {false};
    bool previousPunchEnabled_ {false};
    std::int64_t previousPunchIn_ {0};
    std::int64_t previousPunchOut_ {0};
};

} // namespace silveton
