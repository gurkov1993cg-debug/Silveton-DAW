#pragma once

#include <cstdint>

namespace silveton {

// Stereo pan-depth choices mirror the documented Pro Tools session options,
// while the implementation below is original Silveton math.
enum class PanDepth : std::uint8_t {
    Minus2_5dB,
    Minus3dB,
    Minus4_5dB,
    Minus6dB
};

struct StereoGainPair {
    double left {1.0};
    double right {1.0};
};

class MixMath {
public:
    [[nodiscard]] static double dbToLinear(double db) noexcept;
    [[nodiscard]] static double panDepthDb(PanDepth depth) noexcept;

    // Generalised equal-power style pan curve. Hard L/R remain unity/zero,
    // while the centre point lands exactly at the selected pan depth.
    [[nodiscard]] static StereoGainPair monoPan(float pan, PanDepth depth) noexcept;

    // Balance law for a stereo source: the channel on the side being panned
    // toward remains at unity while the opposite channel is attenuated.
    [[nodiscard]] static StereoGainPair stereoBalance(float balance) noexcept;

    // Neumaier compensated 64-bit accumulation. This reduces rounding loss
    // when a bus sums signals with very different magnitudes.
    static void compensatedAdd(double value, double& sum, double& compensation) noexcept;
};

} // namespace silveton
