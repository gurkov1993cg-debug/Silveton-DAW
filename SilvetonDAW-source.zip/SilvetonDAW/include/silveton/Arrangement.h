#pragma once
// Project arrangement tools: solo logic, markers, arranger track, folders,
// track reordering and MIDI track playback modifiers. Pure control-thread
// logic with no platform dependencies; the GUI calls these inside
// ProjectSession edit transactions so every operation is undoable.
#include "silveton/DawCore.h"
#include "silveton/MidiTimeline.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace silveton {

class AudioEngine;

// Silveton's own 16-colour track palette (0xRRGGBB).
[[nodiscard]] std::uint32_t silvetonPaletteColor(std::size_t index) noexcept;
[[nodiscard]] std::uint32_t effectiveTrackColor(const Project& project, std::size_t trackIndex) noexcept;

class SoloResolver {
public:
    [[nodiscard]] static bool anySolo(const Project& project) noexcept;
    // Audio track indices that must be heard with the current solo state.
    // Includes solo-defeated tracks, instrument tracks driven by soloed MIDI
    // tracks and every track that feeds a soloed Group/FX bus (output or send).
    [[nodiscard]] static std::vector<std::size_t> audibleTracks(const Project& project);
    // Publishes the solo state to the engine's render mask (control thread).
    static void apply(AudioEngine& engine, const Project& project);
};

class MarkerTools {
public:
    static std::uint64_t add(Project& project, std::string name, std::int64_t sample);
    static std::uint64_t addCycle(Project& project, std::string name, std::int64_t start, std::int64_t end);
    static bool remove(Project& project, std::uint64_t id);
    static bool move(Project& project, std::uint64_t id, std::int64_t sample);
    static bool rename(Project& project, std::uint64_t id, std::string name);
    [[nodiscard]] static const ProjectMarker* find(const Project& project, std::uint64_t id) noexcept;
    // Navigation: nearest marker strictly after / before `sample`.
    [[nodiscard]] static const ProjectMarker* next(const Project& project, std::int64_t sample) noexcept;
    [[nodiscard]] static const ProjectMarker* previous(const Project& project, std::int64_t sample) noexcept;
    static void sort(Project& project);
};

class ArrangerTools {
public:
    static std::uint64_t addSection(Project& project, std::string name, std::int64_t start, std::int64_t end);
    static bool removeSection(Project& project, std::uint64_t id);
    static bool resizeSection(Project& project, std::uint64_t id, std::int64_t start, std::int64_t end);
    [[nodiscard]] static const ArrangerSection* find(const Project& project, std::uint64_t id) noexcept;
    static void appendToChain(Project& project, std::uint64_t sectionId, std::uint32_t repeats = 1U);
    static void removeChainStep(Project& project, std::size_t index);
    static void moveChainStep(Project& project, std::size_t from, std::size_t to);
    // Source ranges [start,end) in play order, repeats expanded.
    [[nodiscard]] static std::vector<std::pair<std::int64_t, std::int64_t>> chainRanges(const Project& project);
    [[nodiscard]] static std::int64_t chainLengthSamples(const Project& project);
    // Returns a linear project in which the chain has been rendered into the
    // timeline: audio clips cropped/copied, MIDI parts cropped/copied,
    // mixer/plug-in automation copied, and one marker per placed section.
    // Take lanes are dropped (the active comp clips are kept).
    [[nodiscard]] static Project flattenChain(const Project& project);
};

class FolderTools {
public:
    static int addFolder(Project& project, std::string name, int parent = -1);
    // Children and tracks move to the removed folder's parent.
    static bool removeFolder(Project& project, int id);
    [[nodiscard]] static bool isInside(const Project& project, int folder, int ancestor) noexcept;
    [[nodiscard]] static std::vector<std::size_t> audioTracksIn(const Project& project, int folder);
    static void setMute(Project& project, int folder, bool mute);
    static void setSolo(Project& project, int folder, bool solo);
};

// Structural edits that keep graph-node references (sidechain sources)
// consistent. Graph nodes are [tracks][buses][master].
class TrackTools {
public:
    static void insertTrack(Project& project, std::size_t index, ProjectTrack track);
    static void removeTrack(Project& project, std::size_t index);
    static void moveTrack(Project& project, std::size_t from, std::size_t to);
    static void addBus(Project& project, ProjectBus bus);
    static void removeBus(Project& project, std::size_t index);
    [[nodiscard]] static std::size_t duplicateTrack(Project& project, std::size_t index);
};

class MidiTrackTools {
public:
    // Moves notes of a legacy (part-less) MIDI track into one part so parts can
    // be added alongside (the legacy sequence is ignored once parts exist).
    static void ensureParts(ProjectMidiTrack& track);
    // Wraps absolute-position notes (e.g. a MIDI recording) into a bar-aligned
    // part and appends it. Returns the part id, or 0 when `absolute` is empty.
    static std::uint64_t addPartFromAbsolute(ProjectMidiTrack& track, const MidiSequence& absolute,
                                             double barLengthQuarterNotes = 4.0);
    static std::uint64_t addEmptyPart(ProjectMidiTrack& track, double startQuarterNotes, double lengthQuarterNotes);
    [[nodiscard]] static MidiPart* findPart(ProjectMidiTrack& track, std::uint64_t id) noexcept;
};

// MIDI track playback with mute / transpose / velocity modifiers applied.
[[nodiscard]] MidiRenderPlan compileProjectMidiTrack(const ProjectMidiTrack& track, const TempoMap& tempoMap);

} // namespace silveton
