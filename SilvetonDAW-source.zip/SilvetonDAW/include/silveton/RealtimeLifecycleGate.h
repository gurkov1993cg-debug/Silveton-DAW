#pragma once

#include <atomic>
#include <cstdint>
#include <thread>

namespace silveton {

// Lock-free audio/control lifecycle hand-off.
//
// Contract:
// - Exactly one audio thread may call tryEnterAudio()/leaveAudio().
// - Control-side lifecycle operations are serialized by the caller.
// - The audio thread never blocks. If control owns/requested suspension,
//   tryEnterAudio() returns false and the host may bypass/silence that block.
// - The control thread may wait for the currently executing audio block to exit,
//   then owns the protected lifecycle region until resumeControl().
class RealtimeLifecycleGate final {
public:
    enum class State : std::uint8_t {
        Idle = 0U,
        Processing = 1U,
        SuspendRequested = 2U,
        Suspended = 3U,
    };

    [[nodiscard]] bool tryEnterAudio() noexcept {
        State expected = State::Idle;
        return state_.compare_exchange_strong(expected,
                                              State::Processing,
                                              std::memory_order_acquire,
                                              std::memory_order_relaxed);
    }

    void leaveAudio() noexcept {
        State expected = State::Processing;
        if (state_.compare_exchange_strong(expected,
                                           State::Idle,
                                           std::memory_order_release,
                                           std::memory_order_relaxed)) {
            return;
        }

        // The only legal competing transition while audio owns the gate is a
        // control-thread Processing -> SuspendRequested request.
        if (expected == State::SuspendRequested) {
            state_.store(State::Suspended, std::memory_order_release);
        }
    }

    void suspendControl() noexcept {
        for (;;) {
            State observed = state_.load(std::memory_order_acquire);
            if (observed == State::Suspended) return;

            if (observed == State::Idle) {
                if (state_.compare_exchange_weak(observed,
                                                 State::Suspended,
                                                 std::memory_order_acq_rel,
                                                 std::memory_order_acquire)) {
                    return;
                }
                continue;
            }

            if (observed == State::Processing) {
                (void)state_.compare_exchange_weak(observed,
                                                   State::SuspendRequested,
                                                   std::memory_order_acq_rel,
                                                   std::memory_order_acquire);
                continue;
            }

            // SuspendRequested: only the control thread waits. The audio
            // thread will publish Suspended when its current block exits.
            std::this_thread::yield();
        }
    }

    void resumeControl() noexcept {
        state_.store(State::Idle, std::memory_order_release);
    }

    [[nodiscard]] State state() const noexcept {
        return state_.load(std::memory_order_acquire);
    }

private:
    std::atomic<State> state_ {State::Idle};
};

class RealtimeLifecycleAudioGuard final {
public:
    explicit RealtimeLifecycleAudioGuard(RealtimeLifecycleGate& gate) noexcept
        : gate_(&gate), entered_(gate.tryEnterAudio()) {}
    ~RealtimeLifecycleAudioGuard() { if (entered_) gate_->leaveAudio(); }

    RealtimeLifecycleAudioGuard(const RealtimeLifecycleAudioGuard&) = delete;
    RealtimeLifecycleAudioGuard& operator=(const RealtimeLifecycleAudioGuard&) = delete;

    [[nodiscard]] bool entered() const noexcept { return entered_; }

private:
    RealtimeLifecycleGate* gate_ {nullptr};
    bool entered_ {false};
};

class RealtimeLifecycleControlGuard final {
public:
    explicit RealtimeLifecycleControlGuard(RealtimeLifecycleGate& gate) noexcept
        : gate_(&gate) { gate_->suspendControl(); }
    ~RealtimeLifecycleControlGuard() { gate_->resumeControl(); }

    RealtimeLifecycleControlGuard(const RealtimeLifecycleControlGuard&) = delete;
    RealtimeLifecycleControlGuard& operator=(const RealtimeLifecycleControlGuard&) = delete;

private:
    RealtimeLifecycleGate* gate_ {nullptr};
};

} // namespace silveton
