#pragma once
#include <string>
#include <vector>

namespace silveton {

struct Vst3BlacklistEntry {
    std::string modulePath;
    std::string classId;
    std::string reason;
};

class Vst3Blacklist {
public:
    void clear() noexcept { entries_.clear(); }
    void load(const std::string& path);
    void save(const std::string& path) const;

    void add(std::string modulePath, std::string classId, std::string reason);
    bool remove(const std::string& modulePath, const std::string& classId);
    [[nodiscard]] bool contains(const std::string& modulePath, const std::string& classId) const noexcept;
    [[nodiscard]] std::string reason(const std::string& modulePath, const std::string& classId) const;
    [[nodiscard]] const std::vector<Vst3BlacklistEntry>& entries() const noexcept { return entries_; }

private:
    std::vector<Vst3BlacklistEntry> entries_;
};

} // namespace silveton
