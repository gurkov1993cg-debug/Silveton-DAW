#pragma once
// Standard MIDI File (SMF) import/export and Cubase-style MIDI functions.
#include "silveton/MidiTimeline.h"
#include "silveton/TempoMap.h"

#include <cstdint>
#include <string>
#include <vector>

namespace silveton {

struct SmfTrackData {
    std::string name;
    MidiSequence sequence;
    int firstChannel {-1};  // first channel seen in the track, -1 if none
};

struct SmfImportResult {
    std::uint16_t format {1U};
    std::uint16_t ticksPerQuarter {480U};
    TempoMap tempoMap;               // tempo + time-signature changes from the file
    std::vector<SmfTrackData> tracks; // only tracks that contain channel events
};

struct SmfExportTrack {
    std::string name;
    const MidiSequence* sequence {nullptr};
};

class StandardMidiFile final {
public:
    // Reads format 0 and 1 files with PPQ timing. With splitChannels, every
    // MIDI channel of a format-0 file becomes its own track.
    [[nodiscard]] static SmfImportResult read(const std::string& path, double sampleRate, bool splitChannels = false);
    [[nodiscard]] static SmfImportResult parse(const std::vector<std::uint8_t>& bytes, double sampleRate, bool splitChannels = false);
    // Writes a format-1 file: conductor track (tempo/meter) + one track each.
    static void write(const std::string& path, const std::vector<SmfExportTrack>& tracks,
                      const TempoMap& tempoMap, std::uint16_t ticksPerQuarter = 480U);
    [[nodiscard]] static std::vector<std::uint8_t> serialize(const std::vector<SmfExportTrack>& tracks,
                                                             const TempoMap& tempoMap,
                                                             std::uint16_t ticksPerQuarter = 480U);
};

// Rebuilds a timeline MidiSequence (quarter-note positions) from a compiled
// render plan: note-on/off pairs become notes, other messages are kept.
[[nodiscard]] MidiSequence sequenceFromRenderPlan(const MidiRenderPlan& plan, const TempoMap& tempoMap);

// MIDI functions. `selection` lists note ids; empty means every note.
class MidiFunctions final {
public:
    using Selection = std::vector<std::uint64_t>;
    // Extend each note to the start of the next (later-starting) note.
    static std::size_t legato(MidiSequence& seq, double overlapQuarterNotes = 0.0, const Selection& selection = {});
    static std::size_t fixedLength(MidiSequence& seq, double lengthQuarterNotes, const Selection& selection = {});
    static std::size_t fixedVelocity(MidiSequence& seq, std::uint8_t velocity, const Selection& selection = {});
    // v' = v * scale + offset, clamped to 1..127.
    static std::size_t scaleVelocity(MidiSequence& seq, double scale, int offset, const Selection& selection = {});
    // Compress/expand velocities around their mean (ratio < 1 compresses).
    static std::size_t compressVelocity(MidiSequence& seq, double ratio, const Selection& selection = {});
    // Grid quantize with swing (0..1, 1 = triplet feel on off-beats), strength
    // (0..1, iterative quantize) and optional end quantize.
    static std::size_t quantize(MidiSequence& seq, double gridQuarterNotes, double swing = 0.0,
                                double strength = 1.0, bool quantizeEnds = false, const Selection& selection = {});
    // Deterministic random timing (+/- quarter notes) and velocity offsets.
    static std::size_t humanize(MidiSequence& seq, double timingQuarterNotes, int velocityRange,
                                std::uint32_t seed, const Selection& selection = {});
    // Removes notes with identical pitch/channel starting at the same position.
    static std::size_t deleteDoubles(MidiSequence& seq);
    // Shortens notes so notes of the same pitch/channel never overlap.
    static std::size_t deleteOverlaps(MidiSequence& seq);
    // Retrograde: mirror note positions inside [start, end).
    static std::size_t reverse(MidiSequence& seq, double startQuarterNotes, double endQuarterNotes, const Selection& selection = {});
    // Mirror pitches around `axis`.
    static std::size_t invert(MidiSequence& seq, int axisPitch, const Selection& selection = {});
    // Removes notes shorter than `minimumQuarterNotes` or softer than `minimumVelocity`.
    static std::size_t deleteShortOrSoft(MidiSequence& seq, double minimumQuarterNotes, std::uint8_t minimumVelocity);
};

} // namespace silveton
