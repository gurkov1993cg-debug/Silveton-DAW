#pragma once

#include "silveton/DawCore.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/Vst3Runtime.h"
#include <cstddef>
#include <memory>

namespace silveton {

struct MixerGraphLayout {
    std::size_t trackCount {0U};
    std::size_t busCount {0U};

    [[nodiscard]] std::size_t trackNode(std::size_t track) const;
    [[nodiscard]] std::size_t busNode(std::size_t bus) const;
    [[nodiscard]] std::size_t masterNode() const noexcept { return trackCount + busCount; }
    [[nodiscard]] std::size_t nodeCount() const noexcept { return masterNode() + 1U; }
};

class MixerRoutingBuilder {
public:
    // Builds the immutable audio routing graph represented by the current project.
    // Track sources occupy graph nodes [0, trackCount), buses follow, and the
    // final node is the master insert chain. Track/bus inserts execute before
    // their fader. Each send has a real pre- or post-fader tap.
    [[nodiscard]] static std::unique_ptr<ProcessorGraph> build(const Project& project,
                                                               const Vst3RuntimeRack& rack);
    // Builds against a control-thread staged VST3 rack. This is used for
    // live insert topology replacement so the currently published graph keeps
    // owning/using the previous plug-in instances until block-boundary adoption.
    [[nodiscard]] static std::unique_ptr<ProcessorGraph> buildStaged(const Project& project,
                                                                     const Vst3RuntimeRack& rack);
    [[nodiscard]] static MixerGraphLayout layout(const Project& project) noexcept;
};

} // namespace silveton
