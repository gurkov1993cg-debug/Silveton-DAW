#pragma once
#include "silveton/AudioBuffer.h"
#include "silveton/WavFile.h"
#include "silveton/WaveformCache.h"
#include "silveton/MixMath.h"
#include "silveton/AutomationRuntime.h"
#include "silveton/TempoMap.h"
#include "silveton/MidiTimeline.h"
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <limits>
#include <map>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace silveton {
struct MidiEvent { std::int64_t sample{}; std::uint8_t status{}, data1{}, data2{}; };
class MidiTrack { public: void add(MidiEvent e); const std::vector<MidiEvent>& events() const noexcept{return e_;} std::vector<MidiEvent> range(std::int64_t a,std::int64_t b) const; private:std::vector<MidiEvent> e_;};
enum class ElasticAudioQuality : std::uint8_t { Draft = 0U, Balanced = 1U, High = 2U };

class AudioEditor {
public:
 static AudioBuffer trim(const AudioBuffer&,std::uint64_t start,std::uint64_t length);
 static AudioBuffer reverse(const AudioBuffer&);
 static void fadeIn(AudioBuffer&,std::uint64_t frames);
 static void fadeOut(AudioBuffer&,std::uint64_t frames);
 static AudioBuffer resampleLinear(const AudioBuffer&,double ratio);
 static AudioBuffer resampleSinc(const AudioBuffer&,double ratio);
 static AudioBuffer timeStretch(const AudioBuffer&,double ratio);
 static AudioBuffer timeStretch(const AudioBuffer&,double ratio,ElasticAudioQuality quality);
 static AudioBuffer pitchShift(const AudioBuffer&,double semitones);
 static AudioBuffer pitchShift(const AudioBuffer&,double semitones,ElasticAudioQuality quality);
 static AudioBuffer pitchShiftFormantPreserving(const AudioBuffer&,double semitones);
 static AudioBuffer pitchShiftFormantPreserving(const AudioBuffer&,double semitones,ElasticAudioQuality quality);
};
struct Route { std::size_t from{}, to{}; float gain{1.0f}; };
class RoutingGraph {
public: void setNodeCount(std::size_t n); void addRoute(Route r); std::vector<std::size_t> topologicalOrder() const; const std::vector<Route>& routes() const noexcept{return r_;}
private:std::size_t n_{};std::vector<Route> r_;
};
class DelayCompensator {
public: void setLatencies(const std::vector<std::uint32_t>&); std::uint32_t delayFor(std::size_t i) const; std::uint32_t maxLatency() const noexcept{return max_;}
private:std::vector<std::uint32_t>d_;std::uint32_t max_{};
};
struct ProjectPluginAutomationLane {
    std::uint32_t parameterId {0U};
    AutomationMode mode {AutomationMode::Read};
    ParameterAutomationLane lane;
};

struct ProjectPluginSlot {
    std::string modulePath;
    std::string classId;
    bool enabled {true};
    std::uint32_t latencySnapshot {0U};
    int sidechainSourceNode {-1};
    std::vector<int> extraOutputDestinations;
    int midiInputPort {-1};
    std::vector<std::uint8_t> componentState;
    std::vector<std::uint8_t> controllerState;
    std::vector<ProjectPluginAutomationLane> automation;
};


struct ProjectAudioClip {
    static constexpr std::uint64_t kAutoFadeAnchor = std::numeric_limits<std::uint64_t>::max();
    std::uint64_t id {0U};
    std::string audioPath;
    std::int64_t timelineStartSample {0};
    std::uint64_t sourceStartSample {0U};
    std::uint64_t lengthSamples {0U};
    std::uint64_t sourceFrames {0U};
    // Source metadata is persisted so a missing/offline file keeps its true
    // mono/stereo layout and can be relinked without guessing. Zero means
    // unknown for legacy projects.
    std::uint32_t sourceChannels {0U};
    std::uint32_t sourceSampleRate {0U};
    float gainDb {0.0F};
    bool mute {false};
    std::uint64_t fadeInSamples {0U};
    std::uint64_t fadeOutSamples {0U};
    std::uint64_t fadeInAnchorSourceSample {kAutoFadeAnchor};
    std::uint64_t fadeOutAnchorSourceSample {kAutoFadeAnchor};
};

struct ProjectTakeLane {
    std::uint64_t id {0U};
    std::uint64_t cyclePass {0U};
    std::string name;
    std::vector<ProjectAudioClip> clips;
};

struct ProjectCompSection {
    std::uint64_t id {0U};
    std::uint64_t takeLaneId {0U};
    std::uint64_t takeClipId {0U};
    std::int64_t timelineStartSample {0};
    std::uint64_t lengthSamples {0U};
    // Crossfade at this section's left boundary. Zero is a hard edit.
    std::uint64_t crossfadeSamples {0U};
};

enum class ProjectBusKind : std::uint8_t { Group = 0U, FxReturn = 1U };

struct ProjectSend {
    int destinationBus {-1};
    float gainDb {0.0F};
    bool enabled {true};
    // false = after the channel/bus fader, true = before the fader.
    bool preFader {false};
    AutomationMode gainAutomationMode {AutomationMode::Read};
    AutomationLane gainAutomationDb;
    AutomationMode enabledAutomationMode {AutomationMode::Read};
    AutomationLane enabledAutomation;
};

struct ProjectBus {
    std::string name;
    ProjectBusKind kind {ProjectBusKind::Group};
    float gainDb {0.0F};
    bool mute {false};
    // -1 routes directly to master, otherwise this is a zero-based bus index.
    int outputBus {-1};
    std::vector<ProjectSend> sends;
    std::vector<ProjectPluginSlot> pluginSlots;
    AutomationMode gainAutomationMode {AutomationMode::Read};
    AutomationLane gainAutomationDb;
    AutomationMode muteAutomationMode {AutomationMode::Read};
    AutomationLane muteAutomation;
};

struct ProjectTrack {
    std::string name;
    std::string audioPath;
    float gainDb{};
    float pan{};
    bool mute{};
    bool solo{false};
    bool recordEnable{false};
    bool monitor{false};
    std::uint32_t colorCode{0x3A5A8A}; // default Silveton blue
    bool useDualStereoPan{false};
    float stereoLeftPan{-1.0F};
    float stereoRightPan{1.0F};
    std::int64_t timelineStartSample{0};
    std::uint64_t sourceStartSample{0U};
    bool voiceEnabled{true};
    int voicePriority{0};
    // -1 routes directly to master, otherwise this is a zero-based bus index.
    int outputBus{-1};
    std::vector<ProjectSend> sends;
    std::vector<ProjectPluginSlot> pluginSlots;
    // Empty keeps legacy one-file-per-track sessions intact. New arrangement
    // sessions store explicit, nondestructive clips here.
    std::vector<ProjectAudioClip> clips;
    // Loop-record takes remain nondestructive references to their source file.
    // `compSections` selects ranges from these lanes; `clips` is the materialized
    // active comp used by the existing AudioEngine path.
    std::vector<ProjectTakeLane> takeLanes;
    std::vector<ProjectCompSection> compSections;
    AutomationMode gainAutomationMode {AutomationMode::Read};
    AutomationLane gainAutomationDb;
    AutomationMode panAutomationMode {AutomationMode::Read};
    AutomationLane panAutomation;
    AutomationMode muteAutomationMode {AutomationMode::Read};
    AutomationLane muteAutomation;
};
struct ProjectMidiTrack {
    std::string name;
    int outputPort {-1};
    // Legacy single-sequence storage remains valid for projects without parts.
    MidiSequence sequence;
    std::vector<MidiPart> parts;
};

enum class RecordFormat : std::uint8_t { Int16=0U, Int24=1U, Int32=2U, Float32=3U };

struct Project {
    static constexpr std::size_t kMaxTracks = 256U;
    double sampleRate{48000};
    double tempo{120}; // legacy single-tempo view; tempoMap is authoritative when it contains changes
    TempoMap tempoMap;
    PanDepth panDepth{PanDepth::Minus3dB};
    RecordFormat recordFormat{RecordFormat::Float32};
    float masterFaderDb{0.0F};
    bool metronomeEnabled {false};
    float metronomeGainDb {-18.0F};
    float metronomeAccentGainDb {-12.0F};
    std::uint32_t countInBars {2U};
    AutomationMode masterFaderAutomationMode {AutomationMode::Read};
    AutomationLane masterFaderAutomationDb;
    std::vector<ProjectTrack> tracks;
    std::vector<ProjectMidiTrack> midiTracks;
    std::vector<ProjectBus> buses;
    std::vector<ProjectPluginSlot> masterPluginSlots;
    void addTrack(ProjectTrack track);
    void save(const std::string&) const;
    static Project load(const std::string&);
};

struct RecorderStatus {
    bool recording {false};
    bool faulted {false};
    bool overflowed {false};
    bool writerError {false};
    std::uint64_t framesAccepted {0U};
    std::uint64_t framesWritten {0U};
    std::uint64_t droppedFrames {0U};
};

class Recorder {
public:
    Recorder() = default;
    ~Recorder();
    Recorder(const Recorder&) = delete;
    Recorder& operator=(const Recorder&) = delete;

    void prepare(std::uint32_t channels,
                 std::uint32_t sampleRate = 48000U,
                 std::uint32_t ringCapacityFrames = 262144U);

    void start(const std::string& path);
    void start();
    void stop() noexcept;

    [[nodiscard]] bool recording() const noexcept { return recording_.load(std::memory_order_acquire); }

    [[nodiscard]] bool push(const float* const* in,
                            std::uint32_t channels,
                            std::uint32_t frames) noexcept;

    [[nodiscard]] RecorderStatus status() const noexcept;
    // Real waveform envelope generated by the disk-writer thread. This is safe
    // for GUI polling and never reads the recorder ring from the audio thread.
    [[nodiscard]] WaveformOverview waveformPreview(std::uint64_t firstFrame,
                                                   std::uint64_t frameCount,
                                                   std::size_t maxPeaks = 2048U) const;
    [[nodiscard]] const std::string& path() const noexcept { return path_; }
    [[nodiscard]] std::uint32_t channels() const noexcept { return ch_; }
    [[nodiscard]] std::uint32_t sampleRate() const noexcept { return sampleRate_; }
    [[nodiscard]] const AudioBuffer& captured() const;

private:
    void writerLoop() noexcept;
    void writePlaceholderHeader();
    void finalizeHeader();
    void markFault(bool writerError) noexcept;

    std::uint32_t ch_ {0U};
    std::uint32_t sampleRate_ {0U};
    std::uint64_t ringCapacityFrames_ {0U};
    std::vector<float> ring_;

    std::atomic<std::uint64_t> writeFrame_ {0U};
    std::atomic<std::uint64_t> readFrame_ {0U};
    std::atomic<std::uint64_t> framesAccepted_ {0U};
    std::atomic<std::uint64_t> framesWritten_ {0U};
    std::atomic<std::uint64_t> droppedFrames_ {0U};
    std::atomic<std::uint32_t> activePushes_ {0U};
    std::atomic<bool> recording_ {false};
    std::atomic<bool> writerStop_ {false};
    std::atomic<bool> faulted_ {false};
    std::atomic<bool> overflowed_ {false};
    std::atomic<bool> writerError_ {false};

    std::string path_;
    std::ofstream out_;
    std::thread writerThread_;

    mutable AudioBuffer captureCache_;
    mutable bool captureCacheValid_ {false};
    std::uint64_t dataBytesWritten_ {0U};

    static constexpr std::uint64_t kWaveformPreviewFramesPerPeak = 256U;
    mutable std::mutex waveformPreviewMutex_;
    std::vector<std::vector<WaveformPeak>> waveformPreviewPeaks_;
    std::vector<float> waveformPreviewMin_;
    std::vector<float> waveformPreviewMax_;
    std::uint64_t waveformPreviewAccumulatedFrames_ {0U};
};
}
