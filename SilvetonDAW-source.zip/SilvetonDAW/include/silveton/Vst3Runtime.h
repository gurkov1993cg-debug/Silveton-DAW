#pragma once
#include "silveton/DawCore.h"
#include "silveton/MidiTimeline.h"
#include "silveton/ProcessorGraph.h"
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace silveton {

class MidiInputCapture;

enum Vst3RestartFlags : std::uint32_t {
    Vst3RestartNone = 0U,
    Vst3RestartParamValuesChanged = 1U << 0U,
    Vst3RestartLatencyChanged = 1U << 1U,
    Vst3RestartIoChanged = 1U << 2U,
    Vst3RestartReloadComponent = 1U << 3U,
    Vst3RestartMidiMappingChanged = 1U << 4U
};

struct Vst3MidiEvent {
    std::int32_t frameOffset {0};
    std::uint8_t status {0};
    std::uint8_t data1 {0};
    std::uint8_t data2 {0};
};

struct Vst3OutputParameterChange {
    std::uint32_t parameterId {0U};
    std::int32_t frameOffset {0};
    double normalized {0.0};
};

class IVst3PluginInstance : public IRoutedTrackProcessor {
public:
    ~IVst3PluginInstance() override = default;
    [[nodiscard]] virtual const std::string& modulePath() const noexcept = 0;
    [[nodiscard]] virtual const std::string& classId() const noexcept = 0;
    [[nodiscard]] virtual std::size_t inputBusChannelCount(std::size_t bus) const noexcept = 0;
    [[nodiscard]] virtual std::size_t outputBusChannelCount(std::size_t bus) const noexcept = 0;
    virtual bool setComponentState(const std::vector<std::uint8_t>& state) = 0;
    virtual bool setControllerState(const std::vector<std::uint8_t>& state) = 0;
    [[nodiscard]] virtual std::vector<std::uint8_t> componentState() const = 0;
    [[nodiscard]] virtual std::vector<std::uint8_t> controllerState() const = 0;
    // Control-thread VST3 preset I/O. Implementations that do not support the
    // standard .vstpreset container return false without changing state.
    virtual bool savePreset(const std::string& path) const { (void)path; return false; }
    virtual bool loadPreset(const std::string& path) { (void)path; return false; }
    [[nodiscard]] virtual bool hasEventInput() const noexcept = 0;
    virtual bool queueMidi(const Vst3MidiEvent& event) noexcept = 0;
    virtual bool queueParameter(std::uint32_t parameterId, double normalized, std::int32_t frameOffset) noexcept = 0;
    virtual bool popAutomationGesture(AutomationGesture& event) noexcept = 0;
    virtual bool popOutputParameter(Vst3OutputParameterChange& change) noexcept = 0;
    virtual bool popMidiOutput(Vst3MidiEvent& event) noexcept { (void)event; return false; }
    // Control-thread synchronization for processor-originated parameter changes.
    virtual bool syncControllerParameter(std::uint32_t parameterId, double normalized) {
        (void)parameterId; (void)normalized; return false;
    }
    [[nodiscard]] virtual std::uint32_t consumeRestartFlags() noexcept = 0;
    // Control-thread lifecycle hooks required by the VST3 restart contract.
    virtual bool serviceLatencyChange() { return true; }
    // Re-read the controller's current normalized values after
    // kParamValuesChanged and queue them for the processor on the next block.
    virtual bool serviceParameterValuesChanged() { return true; }
    virtual bool serviceMidiMappingChanged() { return true; }
    virtual bool reconfigureAfterIoChange() { return true; }
    virtual bool openEditor() { return false; }
    virtual void closeEditor() noexcept {}
    [[nodiscard]] virtual bool editorOpen() const noexcept { return false; }
};

class IVst3InstanceFactory {
public:
    virtual ~IVst3InstanceFactory() = default;
    virtual std::unique_ptr<IVst3PluginInstance> create(const std::string& modulePath,
                                                        const std::string& classId,
                                                        std::string& failureReason) = 0;
};

struct Vst3RuntimeSlotStatus {
    bool available {false};
    bool enabled {false};
    std::string failureReason;
};

struct Vst3RuntimeServiceResult {
    bool latencyOrIoChanged {false};
    bool reloadRequested {false};
    bool reloadPerformed {false};
    bool reloadFailed {false};
    bool parameterValuesChanged {false};
    bool graphRebuildRequired {false};
};

class Vst3RuntimeRack {
public:
    explicit Vst3RuntimeRack(IVst3InstanceFactory& factory);
    ~Vst3RuntimeRack();
    void clear() noexcept;
    void restore(Project& project);

    [[nodiscard]] std::size_t trackSlotCount(std::size_t track) const;
    [[nodiscard]] std::size_t busSlotCount(std::size_t bus) const;
    [[nodiscard]] std::size_t masterSlotCount() const noexcept;
    [[nodiscard]] Vst3RuntimeSlotStatus trackSlotStatus(std::size_t track, std::size_t slot) const;
    [[nodiscard]] Vst3RuntimeSlotStatus busSlotStatus(std::size_t bus, std::size_t slot) const;
    [[nodiscard]] Vst3RuntimeSlotStatus masterSlotStatus(std::size_t slot) const;
    [[nodiscard]] IVst3PluginInstance* instanceForMidiPort(int port) const noexcept;
    bool popMidiOutputForPort(int port, Vst3MidiEvent& event) noexcept;
    [[nodiscard]] std::size_t queueMidiPlanForBlock(int port,
                                                    const MidiRenderPlan& plan,
                                                    std::int64_t blockStartSample,
                                                    std::uint32_t frames) noexcept;
    // Realtime MIDI-thru: drains input events that fall inside this audio block
    // and queues them to the VST3 instance assigned to each event's port.
    [[nodiscard]] std::size_t queueLiveMidiForBlock(MidiInputCapture& input,
                                                    std::int64_t blockStartSample,
                                                    std::uint32_t frames) noexcept;
    [[nodiscard]] double trackOutputParameterValue(std::size_t track, std::size_t slot, std::uint32_t parameterId, double fallback = 0.0) const noexcept;
    [[nodiscard]] double busOutputParameterValue(std::size_t bus, std::size_t slot, std::uint32_t parameterId, double fallback = 0.0) const noexcept;
    [[nodiscard]] double masterOutputParameterValue(std::size_t slot, std::uint32_t parameterId, double fallback = 0.0) const noexcept;

    [[nodiscard]] GraphNodeDefinition trackNodeDefinition(std::size_t track) const;
    [[nodiscard]] GraphNodeDefinition busNodeDefinition(std::size_t bus) const;
    [[nodiscard]] GraphNodeDefinition masterNodeDefinition() const;

    // Audio/control boundary helpers. No allocations are performed by the instance queues.
    void queueAutomationForBlock(std::int64_t projectSample, std::uint32_t frames) noexcept;
    void serviceAutomationGestures(std::int64_t defaultSample);
    void serviceOutputParameters() noexcept;
    [[nodiscard]] Vst3RuntimeServiceResult serviceRestartFlags() noexcept;
    // Call only after a newly rebuilt immutable processor graph has been published.
    // Retired instances remain alive until this point so old realtime plans cannot dangle.
    void releaseRetiredInstances() noexcept;

    // Synchronize current live instance states back into the project model before save.
    void captureStateToProject();

private:
    struct RuntimeSlot;
    struct Chain;
    IVst3InstanceFactory& factory_;
    Project* project_ {nullptr};
    std::vector<Chain> trackChains_;
    std::vector<Chain> busChains_;
    std::vector<Chain> masterChains_;
    std::unordered_map<int, IVst3PluginInstance*> midiPorts_;
    std::vector<std::unique_ptr<IVst3PluginInstance>> retiredInstances_;

    static GraphNodeDefinition nodeDefinition(const Chain& chain);
    void restoreChain(std::vector<ProjectPluginSlot>& stateSlots, Chain& chain);
    void queueChainAutomation(Chain& chain, std::int64_t projectSample, std::uint32_t frames) noexcept;
    void serviceChainGestures(Chain& chain, std::int64_t defaultSample);
    void serviceChainOutputParameters(Chain& chain) noexcept;
    void captureChainState(Chain& chain, std::vector<ProjectPluginSlot>& stateSlots);
};

} // namespace silveton
