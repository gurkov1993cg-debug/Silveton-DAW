#pragma once
#include "silveton/OfflineBounce.h"
#include <cstddef>
#include <string>
#include <vector>

namespace silveton {

class AudioEngine;
class Vst3RuntimeRack;
struct Project;

struct TrackStemRequest {
    std::string path;
    // One or more source tracks whose complete processed contribution is rendered.
    // Their inserts, sends, downstream groups/FX and master path stay active.
    std::vector<std::size_t> trackIndices;
};

struct TrackStemResult {
    std::string path;
    std::vector<std::size_t> trackIndices;
    OfflineBounceResult bounce;
};

struct BusStemRequest {
    std::string path;
    std::size_t busIndex {0U};
};

struct BusStemResult {
    std::string path;
    std::size_t busIndex {0U};
    OfflineBounceResult bounce;
};

class StemBounce final {
public:
    // Sequentially renders processed track stems using the AudioEngine's immutable
    // track mask. The engine must not be concurrently driven by a realtime device.
    // Existing project mute/automation state is never modified.
    static std::vector<TrackStemResult> renderTrackStems(Project& project,
                                                         AudioEngine& engine,
                                                         Vst3RuntimeRack* vst3Rack,
                                                         const OfflineBounceOptions& options,
                                                         const std::vector<TrackStemRequest>& requests);

    // Renders the post-insert/post-fader output of a Group or FX Return before
    // it enters downstream buses/Master. Project routing remains untouched.
    static std::vector<BusStemResult> renderBusStems(Project& project,
                                                     AudioEngine& engine,
                                                     Vst3RuntimeRack* vst3Rack,
                                                     const OfflineBounceOptions& options,
                                                     const std::vector<BusStemRequest>& requests);
};

} // namespace silveton
