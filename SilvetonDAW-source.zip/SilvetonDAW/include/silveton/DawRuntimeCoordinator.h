#pragma once
#include "silveton/AudioEngine.h"
#include "silveton/DawAudioCallback.h"
#include "silveton/EngineRateBridge.h"
#include "silveton/MidiInput.h"
#include "silveton/MidiPlaybackScheduler.h"
#include "silveton/MixerRuntime.h"
#include "silveton/ProjectPlaybackRuntime.h"
#include "silveton/ProjectSession.h"
#include "silveton/RealtimeClockMapper.h"
#include "silveton/Vst3Runtime.h"
#include <cstddef>
#include <cstdint>

namespace silveton {

struct DawRuntimeStatus {
    ProjectPlaybackRuntimeStatus media;
    std::uint64_t graphGeneration {0U};
    std::uint64_t midiGeneration {0U};
    std::uint64_t tempoGeneration {0U};
};

// Binds persistent project state to the realtime engine, VST3 rack, disk
// streaming and MIDI scheduler. All rebuild/service methods are control-thread
// only; audio is consumed through audioCallback().
class DawRuntimeCoordinator final {
public:
    DawRuntimeCoordinator(ProjectSession& session,
                          AudioEngine& engine,
                          IVst3InstanceFactory& vst3Factory,
                          std::size_t maxOpenAudioFiles = 0U,
                          std::uint32_t maxCompensationSamples = 16384U);

    // Internal engine rate. 0 (default) runs the engine at the device rate.
    // 96000 runs the whole project at 96 kHz behind Studio-sinc converters on
    // the device input/output. Must be set before prepare().
    void setInternalSampleRate(double rate) noexcept { internalRate_ = rate; }
    [[nodiscard]] double internalSampleRate() const noexcept { return internalRate_; }
    [[nodiscard]] bool rateBridgeActive() const noexcept { return bridge_.active(); }
    [[nodiscard]] const EngineRateBridge& rateBridge() const noexcept { return bridge_; }
    void prepare(const AudioDeviceConfig& config);
    // 65536 frames per cache page (0.7 s at 96 kHz, three pages per file): enough margin for a busy
    // window on an older machine; 11 stereo files cost about 17 MB.
    DawRuntimeStatus rebuildProject(std::uint32_t cacheFrames = 65536U,
                                    std::uint32_t primeTimeoutMilliseconds = 5000U);
    MixerRuntimeServiceResult service();
    void capturePluginState();
    // Re-publish the project's solo state to the engine render mask (after a
    // solo button change or an offline stem export that used the mask).
    void applySoloState();

    [[nodiscard]] AudioEngine& engine() noexcept { return engine_; }
    [[nodiscard]] Vst3RuntimeRack& rack() noexcept { return rack_; }
    [[nodiscard]] ProjectPlaybackRuntime& playback() noexcept { return playback_; }
    [[nodiscard]] MidiPlaybackScheduler& midiScheduler() noexcept { return midiScheduler_; }
    [[nodiscard]] MidiInputCapture& midiInput() noexcept { return midiInput_; }
    [[nodiscard]] RealtimeClockMapper& clockMapper() noexcept { return clockMapper_; }
    // Device-facing callback: the rate bridge when the internal rate differs
    // from the device, otherwise the engine callback directly.
    [[nodiscard]] IAudioDeviceCallback& audioCallback() noexcept {
        return bridge_.active() ? static_cast<IAudioDeviceCallback&>(bridge_) : static_cast<IAudioDeviceCallback&>(audioCallback_);
    }
    [[nodiscard]] DawAudioCallback& engineCallback() noexcept { return audioCallback_; }
    [[nodiscard]] bool prepared() const noexcept { return prepared_; }
    [[nodiscard]] bool projectRebuildRequested() const noexcept { return rebuildRequested_; }
    void requestProjectRebuild() noexcept { rebuildRequested_ = true; }
    [[nodiscard]] const DawRuntimeStatus& status() const noexcept { return status_; }

private:
    ProjectSession& session_;
    AudioEngine& engine_;
    Vst3RuntimeRack rack_;
    MixerRuntimeCoordinator mixer_;
    ProjectPlaybackRuntime playback_;
    MidiPlaybackScheduler midiScheduler_;
    MidiInputCapture midiInput_;
    RealtimeClockMapper clockMapper_;
    DawAudioCallback audioCallback_;
    EngineRateBridge bridge_;
    double internalRate_ {0.0};
    bool prepared_ {false};
    bool rebuildRequested_ {false};
    DawRuntimeStatus status_;
};

} // namespace silveton
