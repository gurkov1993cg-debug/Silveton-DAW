#pragma once
#include "silveton/AudioEngine.h"
#include "silveton/DawAudioCallback.h"
#include "silveton/MidiInput.h"
#include "silveton/MidiPlaybackScheduler.h"
#include "silveton/MixerRuntime.h"
#include "silveton/ProjectPlaybackRuntime.h"
#include "silveton/ProjectSession.h"
#include "silveton/RealtimeClockMapper.h"
#include "silveton/Vst3Runtime.h"
#include <cstddef>
#include <cstdint>

namespace silveton {

struct DawRuntimeStatus {
    ProjectPlaybackRuntimeStatus media;
    std::uint64_t graphGeneration {0U};
    std::uint64_t midiGeneration {0U};
    std::uint64_t tempoGeneration {0U};
};

// Binds persistent project state to the realtime engine, VST3 rack, disk
// streaming and MIDI scheduler. All rebuild/service methods are control-thread
// only; audio is consumed through audioCallback().
class DawRuntimeCoordinator final {
public:
    DawRuntimeCoordinator(ProjectSession& session,
                          AudioEngine& engine,
                          IVst3InstanceFactory& vst3Factory,
                          std::size_t maxOpenAudioFiles = 0U,
                          std::uint32_t maxCompensationSamples = 16384U);

    void prepare(const AudioDeviceConfig& config);
    DawRuntimeStatus rebuildProject(std::uint32_t cacheFrames = 16384U,
                                    std::uint32_t primeTimeoutMilliseconds = 5000U);
    MixerRuntimeServiceResult service();
    void capturePluginState();

    [[nodiscard]] AudioEngine& engine() noexcept { return engine_; }
    [[nodiscard]] Vst3RuntimeRack& rack() noexcept { return rack_; }
    [[nodiscard]] ProjectPlaybackRuntime& playback() noexcept { return playback_; }
    [[nodiscard]] MidiPlaybackScheduler& midiScheduler() noexcept { return midiScheduler_; }
    [[nodiscard]] MidiInputCapture& midiInput() noexcept { return midiInput_; }
    [[nodiscard]] RealtimeClockMapper& clockMapper() noexcept { return clockMapper_; }
    [[nodiscard]] DawAudioCallback& audioCallback() noexcept { return audioCallback_; }
    [[nodiscard]] bool prepared() const noexcept { return prepared_; }
    [[nodiscard]] bool projectRebuildRequested() const noexcept { return rebuildRequested_; }
    void requestProjectRebuild() noexcept { rebuildRequested_ = true; }
    [[nodiscard]] const DawRuntimeStatus& status() const noexcept { return status_; }

private:
    ProjectSession& session_;
    AudioEngine& engine_;
    Vst3RuntimeRack rack_;
    MixerRuntimeCoordinator mixer_;
    ProjectPlaybackRuntime playback_;
    MidiPlaybackScheduler midiScheduler_;
    MidiInputCapture midiInput_;
    RealtimeClockMapper clockMapper_;
    DawAudioCallback audioCallback_;
    bool prepared_ {false};
    bool rebuildRequested_ {false};
    DawRuntimeStatus status_;
};

} // namespace silveton
