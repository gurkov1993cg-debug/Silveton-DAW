#pragma once
#include "silveton/DawCore.h"
#include <cstddef>
#include <functional>
#include <string>
#include <vector>

namespace silveton {

class ProjectHistory final {
public:
    explicit ProjectHistory(Project& project, std::size_t capacity = 128U);

    void setApplyCallback(std::function<void()> callback) { applyCallback_ = std::move(callback); }

    void begin(std::string label);
    void commit();
    void cancel();

    [[nodiscard]] bool transactionOpen() const noexcept { return transactionOpen_; }
    [[nodiscard]] bool canUndo() const noexcept { return !undo_.empty(); }
    [[nodiscard]] bool canRedo() const noexcept { return !redo_.empty(); }
    [[nodiscard]] const std::string& undoLabel() const noexcept;
    [[nodiscard]] const std::string& redoLabel() const noexcept;

    bool undo();
    bool redo();
    void clear() noexcept;

private:
    struct Entry {
        std::string label;
        Project before;
        Project after;
    };

    void apply(Project snapshot);
    void pushUndo(Entry entry);

    Project& project_;
    std::size_t capacity_ {128U};
    bool transactionOpen_ {false};
    std::string transactionLabel_;
    Project transactionBefore_;
    std::vector<Entry> undo_;
    std::vector<Entry> redo_;
    std::function<void()> applyCallback_;
};

} // namespace silveton
