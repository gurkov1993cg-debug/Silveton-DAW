# Silveton DAW 0.16.0 — native workflow contract

The native macOS source now uses one primary AppKit workspace instead of requiring separate Mixer and MIDI windows.

- **Top transport:** real Play/Stop/Record, metronome, position, zoom, audio-device setup and master export
- **Left Project/Plug-in browser:** real audio import, MIDI-track creation, track removal, VST3 search/scan and insert creation
- **Center Arrange:** real project audio clips, selection, seek and musical-grid clip movement
- **Right Inspector:** real track gain/pan/mute automation path, measured track/master meters and the real VST3 insert chain/editor/preset actions
- **Bottom Mixer:** real track/Group/FX/Master gain/mute/output routing, pre/post sends and send levels
- **Bottom Audio Clip:** real nondestructive clip gain, mute, fades, trim, split and delete; selecting an audio clip switches to this context
- **Bottom MIDI Editor:** real MIDI-track destination routing, piano-roll note add/select/move/delete and quantize

No decorative meter was added: the two visible meters are fed from `AudioEngine::trackMeter()` and `AudioEngine::outputMeter()`. No placeholder dock tab was added; only backend functions that already exist are exposed. Numeric entry is present for applicable gain/pan/clip/fade controls, and the existing reset slider contract keeps double-click reset behavior.

Native compile/runtime proof for this 0.16.0 AppKit source is pending the Intel GitHub workflow and final iMac 2011 test.

## Audio waveform display

The Arrange timeline now renders real min/max waveform envelopes for audio clips. Waveforms are built from the referenced WAV audio on a background cache worker, not on the GUI or realtime audio thread. While recording, the recorder writer thread builds a real live envelope and the timeline draws the growing take in red with its measured waveform. No synthetic/decorative waveform is used.
