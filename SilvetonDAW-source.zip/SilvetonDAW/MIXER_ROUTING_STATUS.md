# Silveton DAW 0.10.0 — mixer/routing status

## Current mixer model

The project mixer builds a real immutable `ProcessorGraph` from tracks, Group/FX buses, sends and VST3 insert chains.

Deterministic layout:

`Track nodes -> Bus nodes -> Master node`

Track and bus main outputs can feed Master or another bus. All represented sends are real audio routes.

## Signal order

Track path:

`audio source -> track pan -> insert chain -> pre-fader send tap -> volume/mute -> post-fader send tap -> output`

Bus path:

`bus sum -> insert chain -> pre-fader send tap -> bus gain/mute -> post-fader send tap -> output`

Master path:

`master sum -> Master insert chain -> Master Fader -> device output`

The Master Fader now lives in the immutable master graph node for project-mixer operation, so its automation is snapshotted with the rest of the mixer state.

## Automation

Real automation is implemented for track volume/pan/mute, send gain/on-off, bus gain/mute and Master Fader. VST3 parameter automation remains sample-accurate through the existing VST3 queue. See `AUTOMATION_STATUS.md`.

## Live changes

`MixerRuntimeCoordinator` converts edited project/rack state into a replacement graph and publishes it only between audio blocks. The live graph owns copies of automation lanes, so Project edits cannot race with audio processing. Dynamic plug-in latency still rebuilds PDC without resetting reused live processors.

## Project format

Current writer: `SILVETON_PROJECT_V16`.

V16 persists:
- track/bus/master mixer automation;
- send level and on/off automation;
- explicit pre/post-fader send state;
- existing VST3 state/routing/automation.

V15 and older supported formats still load with safe defaults. Dedicated regression coverage includes V14 and V15 compatibility.

## Local verification

- Release: 12/12 PASS;
- ASan + UBSan: 12/12 PASS;
- Clang 17: 12/12 PASS;
- targeted ThreadSanitizer: 2/2 PASS.

Dedicated tests verify numeric pre/post-fader output, stepped mute/send switching, continuous gain automation, bus and Master automation, pan automation through the real AudioEngine, V16 round-trip and zero heap allocations on the automated graph path.

## Target validation boundary

The protected Intel macOS GitHub baseline is Silveton DAW 0.15.0 / Run #21 / SUCCESS. The newer 0.16.0 source is not called Intel-macOS verified until its own CI run passes.
