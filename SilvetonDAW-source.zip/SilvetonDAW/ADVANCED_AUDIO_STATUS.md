# Silveton DAW 0.16.0 advanced-audio status

## Voice-plan and media lifetime

The realtime voice-plan handoff is immutable and block-boundary based. `TimelineTrack`/`TimelineClip` may carry shared media owners; prepared Live/Pending/Retired snapshots retain those owners until the audio callback retires the old plan. `reclaimRetiredVoicePlans()` releases the retired owners only on the control thread. `DiskStreamManager` exposes shared source handles so a project rebuild cannot invalidate disk sources still referenced by the previous realtime plan.

Regression coverage drops external owners, publishes replacement plans, verifies the old source stays alive through callback adoption, then verifies control-thread reclamation releases it. Sample-rate and channel-layout media mismatch handling is also covered.

## Multicore processor graph

`ProcessorGraph` owns persistent helper threads created during control-side prepare. Independent nodes in the same dependency layer can execute concurrently; dependency ordering, PDC and deterministic reduction remain explicit. The audio thread never creates helper threads. A configurable helper limit includes a zero-helper forced-serial reference mode. A 200-block regression proves the multicore graph is sample-identical to the forced single-thread reference for the same topology and processor state.

## Elastic Audio

Silveton uses its own FFT/STFT phase-vocoder path. Current behavior includes transient spectral-flux reset, spectral-peak phase locking, relative phase reconstruction for stereo/multichannel coherence, duration-preserving pitch shift and a formant-preserving vocal correction path.

Quality modes are real DSP choices, not labels:
- **Draft**: smaller FFT / larger hop and reduced peak-lock work
- **Balanced**: normal production path
- **High**: larger FFT / denser hop and strongest formant correction

Regression coverage verifies requested duration, pitch movement, transient behavior, stereo phase relationship, vocal-formant improvement and a material output difference between Draft and High.

## Realtime contract

Measured realtime tests continue to require no heap allocation in the covered callback paths, no file I/O and no GUI work. Live voice/graph adoption is atomic at block boundaries; reclamation is control-thread work.
