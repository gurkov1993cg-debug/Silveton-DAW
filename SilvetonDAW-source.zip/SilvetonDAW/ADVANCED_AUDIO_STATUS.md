# Silveton DAW 0.6.1 advanced-audio status

Implemented and locally verified:

- original C++17 FFT/STFT phase vocoder replaces the previous OLA stretch prototype
- `timeStretch()` changes duration while preserving sinusoidal pitch in regression coverage
- `pitchShift()` composes resampling with phase-vocoder stretch and preserves clip duration
- triple-buffered immutable voice plans (`Live`, `Pending`, `Free`)
- control-thread plan rebuilds no longer require stopped transport
- audio callback does not read the mutable `tracks_` control model
- optional gain-dB and pan automation are sampled at timeline-sample resolution
- immediate control-side voiced-track count reporting
- concurrent control/audio publication stress is covered by the advanced test

Realtime constraints preserved:

- no heap allocation in the existing measured callback tests
- no mutex is introduced in the voice-plan handoff
- plan adoption occurs only at an audio block boundary
- old Live plan is retired only by the audio thread

Lifetime contract:

The control model stores raw audio-source / disk-source / automation-lane references. Those objects
must remain alive and automation lane point storage must remain immutable until every live plan that
references them has retired. Automatic source/automation lifetime reclamation is not claimed yet.

Quality boundary:

The phase vocoder is functionally verified, but this milestone is not labelled final commercial
elastic-audio quality. Transient preservation, formant-aware vocal pitch shifting, phase locking,
multichannel phase coherence and quality/performance modes remain later DSP work.
