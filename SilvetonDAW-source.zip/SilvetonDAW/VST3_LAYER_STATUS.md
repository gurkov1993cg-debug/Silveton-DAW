# Silveton DAW — VST3 Layer Validation Status

This package is an explicit validation package for the VST3 host layer.
It is not a claim that the entire Silveton DAW application is FINISHED.

## Verified baseline and current local status
- GitHub Actions Run #19 (0.9.0 mixer/routing baseline): SUCCESS on macos-15-intel / Xcode 16.4 / x86_64 / macOS 10.13.
- Current 0.10.0 portable Release regression: 12/12 PASS.
- Current 0.10.0 portable ASan + UBSan regression: 12/12 PASS.
- Current 0.10.0 routing + VST3 infrastructure tests pass under GCC ThreadSanitizer.
- 0.10.0 target-class GitHub CI is pending the next uploaded source ZIP.
- VST3 infrastructure tests include routed processor graph, sidechain/multi-output routing,
  cycle rejection, V14 plugin-state/runtime semantics, automation/restart infrastructure,
  isolated scanner crash/timeout containment and persistent blacklist behavior.
- `RealtimeLifecycleGate` prevents `IAudioProcessor::process()` from overlapping dynamic
  `setProcessing`/`setActive`/I/O-reconfiguration and queued bus-activation service. The
  audio side never blocks; control-side service waits for the current block boundary.
- lifecycle-gate regression includes deterministic ownership hand-off plus 2000 concurrent
  suspend/resume cycles with no protected-region overlap and passes GCC ThreadSanitizer.

## Mac validation performed by GitHub Actions
The included workflow must:
- run on macos-15-intel with Xcode 16.4;
- build x86_64 only with macOS 10.13 deployment target;
- checkout exact pinned Steinberg VST3 SDK revisions;
- configure with SILVETON_ENABLE_VST3_HOST=ON;
- build the real host wrapper, scanner and deterministic SilvetonHostTest.vst3 fixture;
- run the full Release suite and VST3 host integration test;
- run Steinberg validator on the fixture;
- verify signing, x86_64 architecture and deployment target;
- run ASan + UBSan suite;
- package the validation artifact.

Run #19 proves this automated boundary through the 0.9.0 mixer/routing baseline. The new 0.10.0 automation/pre-post-send changes must pass a new CI run before they inherit that target validation. Actual iMac 2011 compatibility still requires a real machine runtime test.

## 0.9.0 mixer integration
- track, bus and Master VST3 chains are now represented by the project mixer graph builder;
- Master insert slots are restored, automated, state-captured and restarted by `Vst3RuntimeRack`;
- dynamic latency/I/O/reload restart flags can publish a replacement project graph through `MixerRuntimeCoordinator`;
- retired reload instances remain alive until the predecessor realtime graph is reclaimed.

## 0.10.0 automation integration
- VST3 parameter automation remains sample-accurate and unchanged in the runtime rack;
- mixer automation is now persisted separately in project V16 and snapshotted into immutable realtime state;
- project track/bus/master mixer changes can rebuild and publish safely through the existing mixer coordinator.
