# Silveton DAW — VST3 Layer Validation Status

This package is an explicit validation package for the VST3 host layer.
It is not a claim that the entire Silveton DAW application is FINISHED.

## Locally verified before packaging
- Portable Release regression: 11/11 PASS
- Portable ASan + UBSan regression: 11/11 PASS
- VST3 infrastructure tests include routed processor graph, sidechain/multi-output routing,
  cycle rejection, V14 plugin-state/runtime semantics, automation/restart infrastructure,
  isolated scanner crash/timeout containment and persistent blacklist behavior.

## Mac validation performed by GitHub Actions
The included workflow must:
- run on macos-15-intel with Xcode 16.4;
- build x86_64 only with macOS 10.13 deployment target;
- checkout exact pinned Steinberg VST3 SDK revisions;
- configure with SILVETON_ENABLE_VST3_HOST=ON;
- build the real host wrapper, scanner and deterministic SilvetonHostTest.vst3 fixture;
- run the full Release suite and VST3 host integration test;
- run Steinberg validator on the fixture;
- verify signing, x86_64 architecture and deployment target;
- run ASan + UBSan suite;
- package the validation artifact.

A green CI run proves the automated compile/link/validator/integration boundary only.
Actual iMac 2011 compatibility still requires a real machine runtime test.
