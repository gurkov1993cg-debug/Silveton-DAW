# Silveton DAW Core 0.5.4

Verified C++17 foundation for the Silveton DAW.

## Pro Tools-inspired clean mix architecture (original Silveton implementation)
The goal is not to clone proprietary Avid code or hidden algorithms. The mixer follows publicly documented professional principles while using original C++ math and data structures.

Implemented and tested in this milestone:
- compensated **64-bit floating-point summing** with float device I/O
- floating-point internal headroom with **no hidden hard clipping at 0 dBFS**
- session pan-depth choices: **-2.5 dB, -3.0 dB, -4.5 dB, -6.0 dB**
- exact centre attenuation for the selected pan depth
- optional **dual stereo panner** for stereo tracks
- stereo balance mode retained for backward compatibility
- click-free **Master Fader** target changes
- Master output meters derived from the real **post-fader** output
- pan/gain coefficients precomputed outside the audio callback
- deterministic voice allocation
- native low-latency input-monitor path
- pan-depth, dual-panner and Master Fader state stored in project format V3
- backward project loading for V1/V2

The clean mixer intentionally does **not** add analog saturation, crosstalk, noise, widening or console coloration. A Pro Tools-like transparent digital mixer and an optional console-color system are separate concerns. Any later color engine must be explicit and bypassable.

## Locked transparent-audio contract
The default unity signal path is required to reproduce the interface/playback samples without hidden coloration. At 0 dB monitor gain, 0 dB track gain, neutral stereo balance, no processors and 0 dB Master Fader, Silveton must not add EQ, saturation, limiting, dither, DC, crosstalk, widening, noise or automatic loudness compensation.

The build now FAILS if the dedicated transparency test detects any of the following:
- a bit change in stereo interface-monitor samples at unity
- a bit change in stereo playback samples at unity
- left/right crosstalk in the neutral stereo path
- any non-zero output generated from exact digital silence

Mono panning is intentionally governed by the selected session pan law; that is an explicit mixer control, not hidden coloration. Sample-rate conversion, plugins, fades, gain, pan and other requested processing are allowed to change audio only when those functions are actually engaged.

## Disk-streaming recording 0.5.3
The old RAM-growing `Recorder::push()` path has been removed. Recording now uses a preallocated SPSC ring and a dedicated background writer thread.

Verified recording contract:
- device input is wired `AudioDevice -> AudioEngine -> Recorder`
- `Recorder::push()` performs no heap allocation, file I/O, seek, filesystem call, lock, or buffer resize
- planar device input is copied into a preallocated interleaved ring
- the writer thread drains the ring to IEEE Float32 WAV
- control-thread stop drains an in-flight producer safely before finalizing the file
- ring overflow is sticky and marks the take faulted; dropped frames are counted and never reported as a successful take
- small files finalize as RIFF/WAVE
- the header reserves an in-place `ds64` area and automatically finalizes as RF64 above the 4 GiB RIFF limit
- the WAV reader understands RF64 `ds64`, so long Silveton takes remain readable by the project itself
- legacy `captured()` remains available as an explicit off-audio-thread lazy load of a finalized take

The default ring capacity is 262144 frames (~5.46 s at 48 kHz). It is allocated in `prepare()` and never resized while recording.

## Existing foundation
- AudioBuffer and Float32 WAV I/O
- real peak/RMS metering
- sample-addressed transport and callback harness
- timeline playback
- production disk-streaming recording primitive with SPSC ring + background WAV/RF64 writer
- acyclic routing graph primitive
- delay-compensation calculation primitive
- sample-domain automation primitive
- timestamped MIDI event primitive
- basic audio editing primitives
- own linear resampler
- deterministic OLA time-stretch prototype and pitch-shift composition
- project save/load

## Verification
Release and sanitizer builds are tested through CTest.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
```

Sanitizer build:

```bash
cmake -S . -B build-san -DCMAKE_BUILD_TYPE=Debug -DSILVETON_ENABLE_SANITIZERS=ON
cmake --build build-san
ctest --test-dir build-san --output-on-failure
```

Current dedicated mix-engine tests verify:
- exact pan-depth centre gains and hard-pan endpoints
- compensated summing with extreme magnitude differences
- >0 dBFS floating-point headroom without hidden clipping
- dual stereo panner default image preservation
- Master Fader gain and post-fader metering
- identical static-session mix result at 64 vs 128 sample buffers
- 512-track summing stress
- 2000 audio callbacks with zero heap allocations in the measured RT path
- bit-transparent unity interface monitoring
- bit-transparent unity stereo playback
- zero crosstalk in the neutral stereo path
- exact digital silence preservation (no hidden DC/noise/dither)
- `Recorder::push()` zero-allocation producer-thread path
- SPSC ring wrap-around ordering
- complete writer drain on stop
- real `AudioEngine` input-to-disk recording path
- deterministic recorder overflow/fault accounting
- RF64 `ds64` read compatibility

## Not yet claimed complete
The native CoreAudio backend is implemented but is not claimed target-validated until the Intel macOS workflow compiles it and the real iMac/DAW hardware test is run. ASIO, production VST3 hosting, full routing/PDC graph integration, playback disk streaming/cache, complete GUI/workflow, production elastic-audio quality, plugin sandboxing, multicore processing graph and the remaining professional editing surface are not marked complete until implemented and verified.

## macOS 10.13 path compatibility
Silveton core intentionally avoids `std::filesystem` because Apple libc++ marks that API unavailable before macOS 10.15. Project/WAV/recording paths use UTF-8 `std::string` plus C/POSIX-compatible file operations so the Intel macOS 10.13 deployment target can compile.
