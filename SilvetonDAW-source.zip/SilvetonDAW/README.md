# Silveton DAW 0.16.0

C++17 audio-engine foundation for Silveton DAW, targeting Intel macOS and the user's iMac 2011 workflow.




## Current development source — 0.16.0

The protected target-class baseline is **Silveton DAW 0.15.0 / GitHub Actions Run #21 / SUCCESS**. 0.16.0 builds on that source without replacing the protected proof.

Current source adds automatic realtime media ownership/reclamation, serial-reference-verified multicore graph execution, real Elastic Audio quality modes and the unified native Silveton workflow window. The main AppKit workflow is now one window: left Project/Plug-in browser, central Arrange, right Inspector, and a bottom dock that switches between the real Mixer, nondestructive Audio Clip editor and MIDI Editor. Visible meters read real engine values and the added clip controls call real `ClipEditor` operations.

Portable verification of the current backend source: **GNU Release 33/33 PASS, ASan+UBSan 33/33 PASS, Clang 17 Release 33/33 PASS**. The native AppKit/CoreMIDI/VST3 build remains unclaimed until the prepared Intel GitHub workflow succeeds for this exact 0.16.0 package. Real iMac 2011 compatibility still requires the final machine test.

## Mixer automation and true pre/post sends — 0.10.0

The project mixer now has real sample-domain automation for track volume/pan/mute, send level/on-off, bus gain/mute and Master Fader. VST3 parameter automation remains sample-accurate through the existing VST3 path. Continuous controls interpolate; switch controls are stepped.

Track/bus inserts execute before the fader. Every send explicitly chooses a real pre- or post-fader tap. Automation is snapshotted into immutable graph/voice-plan state before publication, so Project edits cannot race the audio callback. Project writer is now V16; V15 and older supported formats still load. See `AUTOMATION_STATUS.md` and `MIXER_ROUTING_STATUS.md`.

## Project mixer routing — 0.9.0

0.9.0 established the project-level track/Group/FX/Master routing model, automatic graph construction, Master insert chain, dynamic latency/PDC rebuild and safe retired-plug-in lifetime handling. GitHub Actions Run #19 is the confirmed Intel macOS green baseline for that milestone.

## AudioEngine processor/routing execution — 0.7.0

The existing `ProcessorGraph` is now executed by the real `AudioEngine::processAudio()` path instead
of living only behind isolated graph tests. When a graph is attached before engine prepare:

`timeline Track N -> graph node N -> processor chain -> routed buses/PDC -> graph master -> Master Fader -> device`

Implemented/tested behavior:
- track audio is rendered into separate preallocated graph-node source buffers;
- processor chains, sidechain/multi-output routing and PDC execute before the Master Fader;
- graph master output is summed into the existing transparent floating-point master bus;
- the graph runs on every device callback, including stopped transport, so instruments/tails are not tied to Play;
- `ProcessorContext` receives real project sample position, play/record state and session tempo;
- graph-node capacity is raised to 1024, covering 256 track nodes plus bus/master headroom;
- the measured graph callback path performs zero heap allocations;
- the legacy transparent direct-mix path remains unchanged when no graph is attached.

## Live immutable ProcessorGraph publication — 0.8.0

The 0.7.0 graph path can now be rebuilt and replaced while the device callback is running:

`Control build -> prepared Free graph slot -> Pending -> callback-boundary swap -> Live -> Retired -> control-thread reclaim`

Implemented/tested behavior:
- three fixed graph-plan slots prevent graph destruction on the realtime thread;
- `publishProcessorGraph()` prepares all graph-owned routing/PDC/scratch memory on the control thread;
- the audio callback performs only atomic publication adoption and uses one immutable graph plan for the entire block;
- `pending=false` is published only after the Live/Retired transition is complete;
- reused processors are not re-`prepare()`d or `reset()` while the predecessor graph may still process them;
- newly inserted processors receive their first `prepare()` + `reset()` on the control thread;
- the old graph remains reclaimable only after the callback has stopped referencing it;
- publishing `nullptr` switches safely back to the transparent direct-mix path;
- graph generations expose the exact block-boundary publication state;
- the measured adoption callback performs zero heap allocations;
- a dedicated stress test performs 200 control-thread publications while a separate audio thread continuously processes blocks.

The runtime ownership rule remains explicit: processors/VST3 instances referenced by a retired graph must remain alive until `reclaimRetiredProcessorGraphs()` reports that the predecessor graph has been reclaimed. `Vst3RuntimeRack::releaseRetiredInstances()` belongs after that boundary.

### Live-safe VST3 lifecycle barrier

The VST3 host now also protects processor/component lifecycle calls from overlapping the realtime `process()` call. A lock-free `RealtimeLifecycleGate` gives priority to realtime safety:
- the audio thread only attempts an atomic `Idle -> Processing` transition and **never waits**;
- if control-side service has requested suspension, that block is bypassed/silenced through the existing routed-processor failure path rather than blocking the callback;
- the control thread waits only for an already-running audio block to exit, then owns the lifecycle region;
- `setProcessing`, `setActive`, dynamic I/O reconfiguration and queued `activateBus()` requests execute only while realtime processing is suspended;
- resume is published atomically before the next audio block may enter.

A dedicated 2000-cycle control/audio stress test verifies zero protected-region overlap, and the VST3 infrastructure plus live-routing tests pass under GCC ThreadSanitizer.

## 256-track session contract

Silveton now has a locked user-facing capacity of **256 audio tracks per project/session**.
The lower-level engine retains a 512-track ceiling for stress/headroom verification.

The 256-track path is not a decorative counter. The dedicated regression suite renders
**256 simultaneous disk-backed stereo tracks** through the real `AudioEngine`, verifies the
actual summed samples, checks Track 1 and Track 256 meters, and measures zero heap allocations
on the audio callback thread.

Disk playback path:

`WAV/RF64 -> DiskStreamManager worker -> preallocated 3-page track cache -> AudioEngine -> mixer -> master`

Audio-callback contract for disk playback:
- no file open/read/seek/close
- no heap allocation or buffer resize
- no lock/mutex or sleep
- cache miss produces a measured underflow, never hidden I/O on the realtime thread

The disk streamer supports Float32 RIFF/WAVE, PCM16 RIFF/WAVE and RF64/ds64 Float32 long takes.
A bounded handle pool is used off the audio thread; on POSIX/macOS the manager attempts to raise
the soft open-file limit safely and preserves descriptor headroom for large sessions.

## Real track signal path

Each timeline track has real:
- source/timeline offset
- gain
- mono pan or stereo balance
- optional dual stereo panner
- mute
- deterministic voice priority/allocation
- memory-backed or disk-backed audio source
- post-gain/post-pan peak/RMS meter derived from the track's actual contribution to the mix bus

Project format V4 persists up to 256 tracks plus timeline start, source offset, voice-enabled
state and voice priority. V1/V2/V3 loading remains supported.

## Transparent mixer contract

The default unity path intentionally adds no analog coloration. At neutral controls Silveton
must not add hidden EQ, saturation, limiting, dither, DC, crosstalk, widening, noise or automatic
loudness compensation.

Implemented/tested mix foundation:
- compensated 64-bit floating-point summing
- no hidden hard clip at 0 dBFS on the internal float bus
- pan-depth choices -2.5 / -3.0 / -4.5 / -6.0 dB
- dual stereo panner
- click-free Master Fader target changes
- post-fader master peak/RMS meters
- deterministic voice allocation
- low-latency input monitor path
- 512-track in-memory stress test
- 2000 measured callbacks with zero heap allocation


## Advanced audio / live-plan milestone

Silveton 0.6.1 replaces the earlier deterministic OLA stretch prototype with an original
FFT/STFT phase-vocoder path. The regression test verifies that a 440 Hz sinusoid remains near
440 Hz during 1.5x time stretch, while a +12-semitone pitch shift reaches approximately 880 Hz
and keeps the original clip duration. This is a functional phase-vocoder milestone, not yet a
claim of final commercial elastic-audio quality.

The playback engine now uses a triple-buffered immutable voice-plan handoff:

`Control track model -> Free plan slot -> Pending -> block-boundary atomic swap -> Live`

This removes the old requirement to stop transport before `clearTracks`, `addTrack`,
`setVoiceLimit`, or `setPanDepth`. `processAudio()` renders only the immutable Live snapshot and
does not dereference the mutable control-thread `tracks_` vector. The callback remains free of
heap allocation and locks. Source objects and automation-lane storage must remain alive while a
plan that references them can still be live.

Optional gain-dB and pan automation lanes are sampled in the audio callback at timeline-sample
resolution. Automation lanes are immutable while referenced by a live plan; editing/publishing
automation snapshots is a separate future milestone.

## Disk-streaming recording

Recording uses:

`AudioDevice -> AudioEngine -> preallocated SPSC ring -> background writer -> WAV/RF64`

`Recorder::push()` performs no allocation, file I/O, seek, filesystem call, lock or resize.
Overflow/dropped frames are sticky faults and cannot be reported as a successful take.
Long takes automatically finalize as RF64 above the RIFF 4 GiB limit.

## CoreAudio backend

The native macOS backend is AUHAL/CoreAudio with:
- duplex input/output
- planar Float32 client buffers
- device enumeration and stable UID selection
- sample-rate/buffer negotiation
- callback sample/host timestamps
- device/stream/safety-offset plus AudioUnit latency reporting
- overload counter
- device/rate/buffer/default-device change detection
- control-thread reopen contract
- preallocated input buffers and no callback device queries/allocation/logging/file I/O

Native Intel target validation is **not** claimed until the GitHub macOS Intel workflow succeeds,
followed by a real iMac 2011 open/play test.

## Project path compatibility

The macOS 10.13 target intentionally avoids `std::filesystem`, because modern Apple libc++ marks
that API unavailable for deployment targets earlier than macOS 10.15. Paths use UTF-8 strings
and deployment-compatible C/POSIX file operations.

## Verification

Portable Release:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
```

Current portable GNU Release result for 0.16.0: **33/33 PASS**.

Portable ASan+UBSan result for 0.16.0: **33/33 PASS**.

Clang 17 Release result for 0.16.0: **33/33 PASS**.

The live graph publication/routing execution and VST3 lifecycle-gate tests also pass under GCC ThreadSanitizer in the current development environment.

Dedicated 256-track checks cover:
- 256 simultaneous disk-backed stereo voices
- exact expected 256-track sum
- zero callback heap allocations
- zero cache underflows across all 256 sources in the tested window
- real Track 1 and Track 256 meters
- multi-page cache handoff/prefetch continuity
- Project V4 Track 1..256 round-trip
- Track 257 rejection
- PCM16 streaming
- RF64 streaming

## Separate later milestones (not falsely marked complete)

The 256-track session/audio-capacity feature is closed by the tests above. Separate DAW milestones
still include multicore plugin scheduling, complete automation
editing, take-lane/comp workflow, production elastic-audio quality and the full AppKit DAW GUI.
