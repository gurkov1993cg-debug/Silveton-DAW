# Silveton DAW Core 0.6.2

C++17 audio-engine foundation for Silveton DAW, targeting Intel macOS and the user's iMac 2011 workflow.

## 256-track session contract

Silveton now has a locked user-facing capacity of **256 audio tracks per project/session**.
The lower-level engine retains a 512-track ceiling for stress/headroom verification.

The 256-track path is not a decorative counter. The dedicated regression suite renders
**256 simultaneous disk-backed stereo tracks** through the real `AudioEngine`, verifies the
actual summed samples, checks Track 1 and Track 256 meters, and measures zero heap allocations
on the audio callback thread.

Disk playback path:

`WAV/RF64 -> DiskStreamManager worker -> preallocated 3-page track cache -> AudioEngine -> mixer -> master`

Audio-callback contract for disk playback:
- no file open/read/seek/close
- no heap allocation or buffer resize
- no lock/mutex or sleep
- cache miss produces a measured underflow, never hidden I/O on the realtime thread

The disk streamer supports Float32 RIFF/WAVE, PCM16 RIFF/WAVE and RF64/ds64 Float32 long takes.
A bounded handle pool is used off the audio thread; on POSIX/macOS the manager attempts to raise
the soft open-file limit safely and preserves descriptor headroom for large sessions.

## Real track signal path

Each timeline track has real:
- source/timeline offset
- gain
- mono pan or stereo balance
- optional dual stereo panner
- mute
- deterministic voice priority/allocation
- memory-backed or disk-backed audio source
- post-gain/post-pan peak/RMS meter derived from the track's actual contribution to the mix bus

Project format V4 persists up to 256 tracks plus timeline start, source offset, voice-enabled
state and voice priority. V1/V2/V3 loading remains supported.

## Transparent mixer contract

The default unity path intentionally adds no analog coloration. At neutral controls Silveton
must not add hidden EQ, saturation, limiting, dither, DC, crosstalk, widening, noise or automatic
loudness compensation.

Implemented/tested mix foundation:
- compensated 64-bit floating-point summing
- no hidden hard clip at 0 dBFS on the internal float bus
- pan-depth choices -2.5 / -3.0 / -4.5 / -6.0 dB
- dual stereo panner
- click-free Master Fader target changes
- post-fader master peak/RMS meters
- deterministic voice allocation
- low-latency input monitor path
- 512-track in-memory stress test
- 2000 measured callbacks with zero heap allocation


## Advanced audio / live-plan milestone

Silveton 0.6.1 replaces the earlier deterministic OLA stretch prototype with an original
FFT/STFT phase-vocoder path. The regression test verifies that a 440 Hz sinusoid remains near
440 Hz during 1.5x time stretch, while a +12-semitone pitch shift reaches approximately 880 Hz
and keeps the original clip duration. This is a functional phase-vocoder milestone, not yet a
claim of final commercial elastic-audio quality.

The playback engine now uses a triple-buffered immutable voice-plan handoff:

`Control track model -> Free plan slot -> Pending -> block-boundary atomic swap -> Live`

This removes the old requirement to stop transport before `clearTracks`, `addTrack`,
`setVoiceLimit`, or `setPanDepth`. `processAudio()` renders only the immutable Live snapshot and
does not dereference the mutable control-thread `tracks_` vector. The callback remains free of
heap allocation and locks. Source objects and automation-lane storage must remain alive while a
plan that references them can still be live.

Optional gain-dB and pan automation lanes are sampled in the audio callback at timeline-sample
resolution. Automation lanes are immutable while referenced by a live plan; editing/publishing
automation snapshots is a separate future milestone.

## Disk-streaming recording

Recording uses:

`AudioDevice -> AudioEngine -> preallocated SPSC ring -> background writer -> WAV/RF64`

`Recorder::push()` performs no allocation, file I/O, seek, filesystem call, lock or resize.
Overflow/dropped frames are sticky faults and cannot be reported as a successful take.
Long takes automatically finalize as RF64 above the RIFF 4 GiB limit.

## CoreAudio backend

The native macOS backend is AUHAL/CoreAudio with:
- duplex input/output
- planar Float32 client buffers
- device enumeration and stable UID selection
- sample-rate/buffer negotiation
- callback sample/host timestamps
- device/stream/safety-offset plus AudioUnit latency reporting
- overload counter
- device/rate/buffer/default-device change detection
- control-thread reopen contract
- preallocated input buffers and no callback device queries/allocation/logging/file I/O

Native Intel target validation is **not** claimed until the GitHub macOS Intel workflow succeeds,
followed by a real iMac 2011 open/play test.

## Project path compatibility

The macOS 10.13 target intentionally avoids `std::filesystem`, because modern Apple libc++ marks
that API unavailable for deployment targets earlier than macOS 10.15. Paths use UTF-8 strings
and deployment-compatible C/POSIX file operations.

## Verification

Portable Release:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
```

Current portable Release result: **10/10 PASS**.

Portable ASan+UBSan result: **10/10 PASS**.

The dedicated advanced-audio test also passes under ThreadSanitizer in the current development environment.

Dedicated 256-track checks cover:
- 256 simultaneous disk-backed stereo voices
- exact expected 256-track sum
- zero callback heap allocations
- zero cache underflows across all 256 sources in the tested window
- real Track 1 and Track 256 meters
- multi-page cache handoff/prefetch continuity
- Project V4 Track 1..256 round-trip
- Track 257 rejection
- PCM16 streaming
- RF64 streaming

## Separate later milestones (not falsely marked complete)

The 256-track session/audio-capacity feature is closed by the tests above. Separate DAW milestones
still include production VST3 hosting, full routing/PDC execution graph, multicore plugin scheduling,
complete automation editing, take-lane/comp workflow, production elastic-audio quality and the full
AppKit DAW GUI.
