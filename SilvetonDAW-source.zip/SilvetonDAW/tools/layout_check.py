#!/usr/bin/env python3
"""Silveton static layout checker.

Reads the AppKit sources in app/*.mm and, for every control or text whose
rectangle is built from numbers it can work out, checks that

  * the text fits inside its rectangle (button, label, check box, pop-up),
  * the text is not taller than its rectangle,
  * no text touches or overlaps another text or control that shares a parent,
  * nothing sticks out of a fixed-size window.

Text width is measured with Liberation Sans (metric twin of Arial/Helvetica)
and then widened by a safety margin because the Mac system font is a little
wider.  Anything the checker cannot work out (rectangles built from runtime
values) is counted as "skipped" and is never reported as OK.

usage: layout_check.py [app dir]      exit code 1 when an error is found
"""
import os
import re
import sys

from PIL import ImageFont

FONT_DIR = "/usr/share/fonts/truetype/liberation"
REG = os.path.join(FONT_DIR, "LiberationSans-Regular.ttf")
BLD = os.path.join(FONT_DIR, "LiberationSans-Bold.ttf")
_cache = {}


def _font(size, bold):
    key = (size, bold)
    if key not in _cache:
        _cache[key] = ImageFont.truetype(BLD if bold else REG, int(round(size * 8)))
    return _cache[key]


def text_width(s, size, bold):
    # SF is wider than Arial at small sizes; Medium weight (used < 12 pt) a bit more again.
    margin = 1.05 if bold else 1.09
    return max(_font(size, bold).getlength(line) / 8.0 for line in (s.split("\n") or [""])) * margin


def line_height(size):
    return size * 1.22


SKIPPED_LOG = []
TYPE = {"caption": 10.0, "label": 11.0, "body": 12.0, "title": 13.0, "heading": 15.0, "display": 24.0}

# Windows with a fixed size: (file, function fragment) -> (width, height)
BOUNDS = {
    ("SilvetonPrefs.mm", "buildPage"): (580, 520),
    ("SilvetonQuantize.mm", "show"): (440, 616),
}
# Starting values for variables that come from loops / runtime.
PRESET = {
    ("SilvetonEditors.mm", "buildFor"): {"width": 440, "height": 330, "rowH": 30, "y": 200},
    ("SilvetonQuantize.mm", "section("): {"w": 440, "y": 100},
    ("SilvetonQuantize.mm", "slider:"): {"y": 100},
    ("SilvetonPrefs.mm", "heading("): {"y": 18},
    ("SilvetonPanels.mm", "buildLibraryPage"): {"H": 640, "leftW": 512, "midW": 307, "rightW": 461, "third": 155},
}


# ------------------------------------------------------------------ parsing --
def strip_comments(src):
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if c == '"':
            j = i + 1
            while j < n and src[j] != '"':
                j += 2 if src[j] == "\\" else 1
            out.append(src[i:j + 1]); i = j + 1
        elif src.startswith("//", i):
            j = src.find("\n", i); j = n if j < 0 else j
            out.append(" " * (j - i)); i = j
        elif src.startswith("/*", i):
            j = src.find("*/", i); j = n if j < 0 else j + 2
            out.append(re.sub(r"[^\n]", " ", src[i:j])); i = j
        else:
            out.append(c); i += 1
    return "".join(out)


def balanced(src, i):
    """src[i] == '(' -> index after matching ')' (string aware)."""
    depth, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == '"':
            i += 1
            while i < n and src[i] != '"':
                i += 2 if src[i] == "\\" else 1
        elif c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return n


def split_args(s):
    args, depth, cur, i, n = [], 0, [], 0, len(s)
    while i < n:
        c = s[i]
        if c == '"':
            j = i + 1
            while j < n and s[j] != '"':
                j += 2 if s[j] == "\\" else 1
            cur.append(s[i:j + 1]); i = j + 1; continue
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
        if c == "," and depth == 0:
            args.append("".join(cur).strip()); cur = []
        else:
            cur.append(c)
        i += 1
    if cur:
        args.append("".join(cur).strip())
    return args


def literal_text(expr):
    """@"a" @"b" -> 'ab' (None when the text is not a plain literal)."""
    parts = re.findall(r'@"((?:[^"\\]|\\.)*)"', expr)
    if not parts or re.sub(r'@"(?:[^"\\]|\\.)*"', "", expr).strip():
        return None
    s = "".join(parts)
    return s.replace("\\n", "\n").replace('\\"', '"').replace("\\\\", "\\")


def to_py(expr):
    e = expr.strip()
    e = re.sub(r"static_cast<[^>]*>\(", "(", e)
    e = re.sub(r"\(\s*(CGFloat|double|int|float|NSInteger)\s*\)", "", e)
    e = re.sub(r"sv::type::(\w+)", lambda m: str(TYPE.get(m.group(1), 11.0)), e)
    e = re.sub(r"\b(\d+(?:\.\d+)?)[fF]\b", r"\1", e)
    e = e.replace("std::max", "max").replace("std::min", "min").replace("std::floor", "floor")
    e = e.replace("&&", " and ").replace("||", " or ")
    return e


def ev(expr, env):
    try:
        return float(eval(to_py(expr), {"__builtins__": {}, "max": max, "min": min, "floor": lambda v: float(int(v // 1))}, dict(env)))
    except Exception:
        return None


def parse_rect(expr, env):
    m = re.search(r"NSMakeRect\s*\(", expr)
    if not m:
        return None
    end = balanced(expr, m.end() - 1)
    parts = split_args(expr[m.end():end - 1])
    if len(parts) != 4:
        return None
    vals = [ev(p, env) for p in parts]
    return None if any(v is None for v in vals) else tuple(vals)


def parse_font(expr):
    """-> (size, bold) or None."""
    m = re.search(r"sv::(ui|mono)\s*\(\s*([^,)]+)\s*(?:,\s*(true|false))?\s*\)", expr)
    if not m:
        return None
    size = ev(m.group(2), {})
    if size is None:
        return None
    return max(size, 10.0), m.group(3) == "true" or (m.group(1) == "ui" and False)


def parse_align(expr):
    if "NSTextAlignmentCenter" in expr:
        return "c"
    if "NSTextAlignmentRight" in expr:
        return "r"
    return "l"


# ----------------------------------------------------------------- elements --
class El:
    __slots__ = ("kind", "x", "y", "w", "h", "text", "size", "bold", "align", "parent", "line", "extra", "wrap")

    def __init__(self, **k):
        for s in self.__slots__:
            setattr(self, s, k.get(s))


def text_box(e):
    """Rectangle the visible glyphs really occupy."""
    if e.text is None or e.size is None:
        return (e.x, e.y, e.w, e.h)
    tw = text_width(e.text, e.size, e.bold)
    lines = e.text.count("\n") + 1
    th = min(e.h, line_height(e.size) * lines) if e.kind != "label" else line_height(e.size) * lines
    tw = min(tw, e.w)
    if e.align == "c":
        x = e.x + (e.w - tw) / 2
    elif e.align == "r":
        x = e.x + e.w - tw
    else:
        x = e.x
    return (x, e.y, tw, th)


GLOBAL_ENV = {}


def load_constants(root):
    """constexpr CGFloat a = 1, b = a + 2;  from every .h/.mm in the app folder."""
    for fn in sorted(os.listdir(root)):
        if not fn.endswith((".h", ".mm")):
            continue
        src = strip_comments(open(os.path.join(root, fn), encoding="utf-8").read())
        for _ in range(3):  # a few passes: constants may refer to each other
            for m in re.finditer(r"constexpr\s+(?:CGFloat|double|int|float|NSInteger)\s+([^;]*);", src):
                for part in split_args(m.group(1)):
                    mm = re.match(r"([A-Za-z_]\w*)\s*=\s*(.+)$", part.strip(), re.S)
                    if mm:
                        v = ev(mm.group(2), GLOBAL_ENV)
                        if v is not None:
                            GLOBAL_ENV[mm.group(1)] = v


def collect(path, text):
    src = strip_comments(text)
    lines_at = [m.start() for m in re.finditer(r"\n", src)]

    def lineno(pos):
        import bisect
        return bisect.bisect_left(lines_at, pos) + 1

    # scope starts: Objective-C methods and top-level C++ functions
    starts = [m.start() for m in re.finditer(r"(?m)^(?:[-+]\s*\([^)]*\)|[A-Za-z_][\w:<>\*&, ]*\s+\**\w+\([^;{]*\)\s*(?:const\s*)?)\s*[^;{]*\{\s*$", src)]
    starts = sorted(set(starts)) or [0]
    scopes = []
    for k, s in enumerate(starts):
        scopes.append((s, starts[k + 1] if k + 1 < len(starts) else len(src)))
    results, skipped = [], 0
    global SKIPPED_LOG

    for (a, b) in scopes:
        body = src[a:b]
        head = body.split("\n", 1)[0].strip()
        env = dict(GLOBAL_ENV)
        sticky = {}
        for (f, frag), preset in PRESET.items():
            if os.path.basename(path) == f and frag in head:
                env.update(preset)
                sticky.update(preset)
        events = []
        # assignments
        for m in re.finditer(r"(?<![\w.>\]\)])(?:const\s+)?(?:CGFloat|double|int|float|NSInteger|auto)?\s*\b([A-Za-z_]\w*)\s*(\+=|-=|\*=|=)\s*([^;=][^;]*);", body):
            if m.group(2) == "=" and not re.search(r"(CGFloat|double|int|float|NSInteger|auto)\s*$", body[max(0, m.start() - 0):m.start(1)]) \
                    and not re.search(r"(?m)^\s*$", body[max(0, m.start(1) - 1):m.start(1)]) and body[m.start(1) - 1] not in " \t\n;{}":
                continue
            events.append((m.start(), "assign", m))
        for m in re.finditer(r"(?m)^\s*(?:const\s+)?(?:CGFloat|double|int|float|NSInteger)\s+([^;(]*,[^;]*);", body):
            events.append((m.start(), "decl", m))
        for m in re.finditer(r"\bswitch\s*\(", body):
            events.append((m.start(), "switch", m))
        for m in re.finditer(r"\b(case\s+[\w:]+\s*:|default\s*:)", body):
            events.append((m.start(), "case", m))
        # drawing / control calls
        pats = [
            ("label", r"\b(?:lbl|makeLabel)\s*\("),
            ("text", r"\bsv::textIn\s*\("),
            ("field", r"\bfld\s*\("),
            ("popup", r"\bpop\s*\("),
            ("check", r"\bcheck\s*\("),
            ("pill", r"\bsv::pill\s*\("),
            ("button", r"\[\s*SVButton\s+buttonWithTitle:"),
            ("toggle", r"\[\s*SVToggle\s+toggleWithTitle:"),
            ("nlabel", r"\blabelWith:"),
            ("tools", r"\btitles:\s*@\["),
        ]
        for kind, pat in pats:
            for m in re.finditer(pat, body):
                events.append((m.start(), kind, m))
        events.sort(key=lambda t: t[0])
        snap = dict(env)
        elements = []
        block = 0
        for pos, kind, m in events:
            if kind == "switch":
                snap = dict(env)
            elif kind == "case":
                env = dict(snap)
                block += 1
            elif kind == "decl":
                for part in split_args(m.group(1)):
                    mm = re.match(r"([A-Za-z_]\w*)\s*=\s*(.+)$", part.strip(), re.S)
                    if mm:
                        v = ev(mm.group(2), env)
                        if v is None:
                            env.pop(mm.group(1), None)
                        else:
                            env[mm.group(1)] = v
            elif kind == "assign":
                env.update(sticky)
                name, op, rhs = m.group(1), m.group(2), m.group(3)
                if name in ("self", "return") or len(split_args(rhs)) > 1:
                    continue
                val = ev(rhs, env)
                if op == "=":
                    if val is None:
                        env.pop(name, None)
                    else:
                        env[name] = val
                elif name in env and val is not None:
                    env[name] = {"+=": env[name] + val, "-=": env[name] - val, "*=": env[name] * val}[op]
                else:
                    env.pop(name, None)
            else:
                abs_pos = a + pos
                if kind in ("label", "text", "field", "popup", "check", "pill"):
                    op = body.index("(", pos)
                    end = balanced(body, op)
                    args = split_args(body[op + 1:end - 1])
                    try:
                        if kind == "label":
                            parent, tx, rc, fn, al = args[0], args[1], args[2], args[3], (args[5] if len(args) > 5 else "")
                        elif kind == "text":
                            parent, tx, rc, fn, al = "<draw>", args[0], args[1], args[2], (args[4] if len(args) > 4 else "")
                        elif kind == "field":
                            parent, tx, rc, fn, al = args[0], None, args[1], "", ""
                        elif kind == "popup":
                            parent, tx, rc, fn, al = args[0], args[2], args[1], "", ""
                        elif kind == "check":
                            parent, tx, rc, fn, al = args[0], args[1], args[2], "", ""
                        else:  # pill(rect, label, on, colour)
                            parent, tx, rc, fn, al = "<draw>", args[1], args[0], "", ""
                    except IndexError:
                        skipped += 1
                        continue
                    rect = parse_rect(rc, env)
                    if rect is None:
                        skipped += 1
                        SKIPPED_LOG.append(f"{os.path.basename(path)}:{lineno(abs_pos)} {rc[:70]}")
                        continue
                    font = parse_font(fn) if fn else None
                    txt = literal_text(tx) if tx else None
                    size, bold = (font if font else (11.0, False))
                    extra = None
                    if kind == "popup":
                        items = re.findall(r'@"((?:[^"\\]|\\.)*)"', tx or "")
                        extra = items
                        txt = max(items, key=len) if items else None
                        size, bold = 11.0, False
                    if kind == "check":
                        size, bold = 11.0, False
                    if kind == "pill":
                        size, bold = 10.0, True
                    if kind == "label" and font is None:
                        skipped += 1
                        continue
                    wrap = "WordWrapping" in body[end:end + 260].split(";")[0] + body[end:end + 260].split(";")[1] if kind == "label" and body[end:end + 260].count(";") > 1 else False
                    elements.append(El(kind=kind, x=rect[0], y=rect[1], w=rect[2], h=rect[3], text=txt, size=size, bold=bold,
                                       align=parse_align(al), parent=f"{parent}#{block}", line=lineno(abs_pos), extra=extra, wrap=wrap))
                elif kind in ("button", "toggle"):
                    seg = body[pos:balanced(body, body.rindex("[", 0, pos + 2) if False else body.index("[", pos)) ]
                    t = re.search(r"[Tt]itle:\s*(@\"(?:[^\"\\]|\\.)*\")", seg)
                    fr = re.search(r"frame:\s*(NSMakeRect.*)", seg, re.S)
                    pre = body[max(0, pos - 80):pos]
                    pm = re.search(r"\[\s*(\w+)\s+addSubview:\s*$", pre)
                    rect = parse_rect(fr.group(1), env) if fr else None
                    if rect is None or not t:
                        skipped += 1
                        continue
                    elements.append(El(kind=kind, x=rect[0], y=rect[1], w=rect[2], h=rect[3], text=literal_text(t.group(1)), size=11.0,
                                       bold=True, align="c", parent=(pm.group(1) + f"#{block}") if pm else f"?{lineno(abs_pos)}", line=lineno(abs_pos)))
                elif kind == "tools":
                    st = body.index("@[", pos)
                    items = re.findall(r'@"((?:[^"\\]|\\.)*)"', body[st:balanced(body, body.index("[", st))])
                    for k, title in enumerate(items):
                        elements.append(El(kind="button", x=8 + (k % 2) * 120, y=28 + (k // 2) * 30, w=112, h=24, text=title, size=11.0, bold=True,
                                           align="c", parent=f"tools@{lineno(abs_pos)}", line=lineno(abs_pos)))
                elif kind == "nlabel":
                    seg = body[pos:pos + 400]
                    mm = re.match(r"labelWith:(.+?)\s+frame:(NSMakeRect\s*\(.*?\))\s+font:(sv::\w+\([^)]*\))\s+color:.*?align:(\w+)", seg, re.S)
                    if not mm:
                        skipped += 1
                        continue
                    rect = parse_rect(mm.group(2), env)
                    font = parse_font(mm.group(3))
                    if rect is None or font is None:
                        skipped += 1
                        continue
                    elements.append(El(kind="label", x=rect[0], y=rect[1], w=rect[2], h=rect[3], text=literal_text(mm.group(1)), size=font[0],
                                       bold=font[1], align=parse_align(mm.group(4)), parent=f"root#{block}", line=lineno(abs_pos)))
        if elements:
            results.append((head, elements))
    return results, skipped


def check_file(path):
    errors, warns, count = [], [], 0
    results, skipped = collect(path, open(path, encoding="utf-8").read())
    base = os.path.basename(path)
    for head, elements in results:
        count += len(elements)
        bounds = None
        for (f, frag), wh in BOUNDS.items():
            if f == base and frag in head:
                bounds = wh
        for e in elements:
            tag = f"{base}:{e.line}"
            nm = (e.text or "").replace("\n", "\\n")
            if e.text is not None and e.size:
                tw = text_width(e.text, e.size, e.bold)
                if e.wrap and tw > e.w:
                    import math
                    nlines = math.ceil(tw / (e.w - 4))
                    if line_height(e.size) * nlines > e.h + 1.0:
                        errors.append(f"{tag}  wrapped text too tall: '{nm}' needs {nlines} lines ({line_height(e.size) * nlines:.0f}px), rectangle is {e.h:.0f}px")
                    continue
                pad = {"label": 1, "text": 1, "button": 14, "toggle": 8, "pill": 6, "check": 22, "popup": 32}.get(e.kind, 0)
                if e.kind in ("label", "text") and "\n" in e.text:
                    pass
                if tw + pad > e.w + 0.5 and not (e.kind in ("label", "text") and "\n" in e.text and tw <= e.w):
                    errors.append(f"{tag}  does not fit: '{nm}' needs {tw + pad:.0f}px, rectangle is {e.w:.0f}px ({e.kind}, {e.size:g}pt)")
                lines = e.text.count("\n") + 1
                if line_height(e.size) * lines > e.h + 1.0:
                    errors.append(f"{tag}  too short: '{nm}' needs {line_height(e.size) * lines:.0f}px height, rectangle is {e.h:.0f}px ({e.kind}, {e.size:g}pt)")
            if bounds and (e.x < -0.5 or e.y < -0.5 or e.x + e.w > bounds[0] + 0.5 or e.y + e.h > bounds[1] + 0.5):
                errors.append(f"{tag}  outside the window {bounds[0]}x{bounds[1]}: x={e.x:g} y={e.y:g} w={e.w:g} h={e.h:g} '{nm}'")
        # sibling overlaps
        for i in range(len(elements)):
            for j in range(i + 1, len(elements)):
                a, b = elements[i], elements[j]
                if a.parent != b.parent:
                    continue
                ax, ay, aw, ah = text_box(a)
                bx, by, bw, bh = text_box(b)
                ox = min(ax + aw, bx + bw) - max(ax, bx)
                oy = min(ay + ah, by + bh) - max(ay, by)
                if ox > 0.5 and oy > 0.5:
                    # a text sitting inside a pill/button drawn at the same spot is not a clash when contained
                    errors.append(f"{base}:{a.line}/{b.line}  overlap {ox:.0f}x{oy:.0f}px: '{(a.text or a.kind)}' ({a.kind}) with '{(b.text or b.kind)}' ({b.kind})")
                elif oy > 0.5 and -2.0 < ox <= 0.5 and (a.kind != "field" or b.kind != "field"):
                    warns.append(f"{base}:{a.line}/{b.line}  touching (gap {-ox:.1f}px): '{(a.text or a.kind)}' and '{(b.text or b.kind)}'")
    return errors, warns, count, skipped


def main():
    verbose = "-v" in sys.argv
    args = [a for a in sys.argv[1:] if a != "-v"]
    root = args[0] if args else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app")
    total_e, total_w = 0, 0
    load_constants(root)
    for fn in sorted(os.listdir(root)):
        if not fn.endswith(".mm"):
            continue
        errs, warns, count, skipped = check_file(os.path.join(root, fn))
        print(f"== {fn}: checked {count} text/controls, {skipped} skipped (runtime sizes)")
        for e in errs:
            print("  ERROR ", e)
        for w in warns:
            print("  warn  ", w)
        total_e += len(errs); total_w += len(warns)
    if verbose:
        print("\nskipped:")
        for l in SKIPPED_LOG:
            print("  ", l)
    print(f"\n{total_e} error(s), {total_w} warning(s)")
    return 1 if total_e else 0


if __name__ == "__main__":
    sys.exit(main())
