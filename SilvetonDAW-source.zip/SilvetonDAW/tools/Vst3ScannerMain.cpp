#include "silveton/Vst3Host.h"
#include "silveton/Vst3ScannerIsolation.h"
#include <fstream>
#include <string>

int main(int argc, char** argv) {
    if (argc != 3) return 2;
    const std::string modulePath = argv[1];
    const std::string outputPath = argv[2];
    std::ofstream out(outputPath, std::ios::binary | std::ios::trunc);
    if (!out) return 3;
    std::string error;
    const auto plugins = silveton::scanVst3ModuleDirect(modulePath, error);
    if (!error.empty()) {
        out << "ERR\t" << silveton::encodeVst3ScanField(error) << '\n';
        out.flush();
        return 4;
    }
    for (const auto& p : plugins) {
        out << "PLUGIN\t"
            << silveton::encodeVst3ScanField(p.modulePath) << '\t'
            << silveton::encodeVst3ScanField(p.classId) << '\t'
            << silveton::encodeVst3ScanField(p.name) << '\t'
            << silveton::encodeVst3ScanField(p.vendor) << '\t'
            << silveton::encodeVst3ScanField(p.version) << '\t'
            << silveton::encodeVst3ScanField(p.sdkVersion) << '\t';
        std::string categories;
        for (std::size_t i = 0; i < p.subCategories.size(); ++i) {
            if (i != 0U) categories += '\n';
            categories += p.subCategories[i];
        }
        out << silveton::encodeVst3ScanField(categories) << '\n';
    }
    out.flush();
    return out ? 0 : 5;
}
