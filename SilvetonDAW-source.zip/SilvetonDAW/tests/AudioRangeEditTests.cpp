// Range editing in the Sample Editor: cut, crop, copy, insert and process just a
// selected part. The media files are never touched; pieces keep pointing at them.
#include "silveton/AudioRangeEdit.h"
#include "silveton/WavFile.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
using namespace silveton;

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

constexpr std::uint32_t kRate = 48000U;

std::string makeMedia(const char* name, std::size_t frames, float level) {
    const std::string path = std::string("/tmp/") + name;
    AudioBuffer audio(2U, frames);
    for (std::size_t i = 0U; i < frames; ++i) {
        audio.sample(0U, i) = level * static_cast<float>(i) / static_cast<float>(frames);   // a ramp, so positions are recognisable
        audio.sample(1U, i) = level * 0.5F;
    }
    WavFile::writeFloat32(path, kRate, audio);
    return path;
}

ProjectAudioClip makeClip(std::uint64_t id, const std::string& path, std::int64_t at, std::uint64_t sourceStart, std::uint64_t length,
                          std::uint64_t sourceFrames) {
    ProjectAudioClip c;
    c.id = id; c.audioPath = path; c.timelineStartSample = at; c.sourceStartSample = sourceStart; c.lengthSamples = length;
    c.sourceFrames = sourceFrames; c.sourceChannels = 2U; c.sourceSampleRate = kRate;
    return c;
}

Project oneClipProject(const std::string& path, std::uint64_t frames) {
    Project p;
    p.sampleRate = static_cast<double>(kRate);
    ProjectTrack t; t.name = "T";
    t.clips.push_back(makeClip(1U, path, 0, 0U, frames, frames));
    p.tracks.push_back(t);
    return p;
}

const ProjectAudioClip* clipWithId(const Project& p, std::uint64_t id) {
    for (const auto& c : p.tracks[0].clips) if (c.id == id) return &c;
    return nullptr;
}

void testFadeGeometry() {
    // Auto anchors: the fades sit at the clip edges.
    ProjectAudioClip c = makeClip(1U, "/tmp/a.wav", 1000, 200U, 4000U, 9000U);
    c.fadeInSamples = 400U; c.fadeOutSamples = 1000U;
    require(std::abs(AudioRangeEdit::fadeGain(c, 1000.0)) < 1.0e-9, "the fade-in starts at zero");
    require(std::abs(AudioRangeEdit::fadeGain(c, 1200.0) - 0.5) < 1.0e-9, "half way through the fade-in");
    require(std::abs(AudioRangeEdit::fadeGain(c, 2500.0) - 1.0) < 1.0e-9, "no fade in the middle");
    require(std::abs(AudioRangeEdit::fadeGain(c, 4500.0) - 0.5) < 1.0e-9, "half way through the fade-out");
    const ClipFadeGeometry g = AudioRangeEdit::fadeGeometry(c);
    require(std::abs(g.fadeInEnd - 1400.0) < 1.0e-9 && std::abs(g.fadeOutStart - 4000.0) < 1.0e-9, "fade handle positions");
    ProjectAudioClip none = makeClip(2U, "/tmp/a.wav", 1000, 0U, 4000U, 9000U);
    const ClipFadeGeometry n = AudioRangeEdit::fadeGeometry(none);
    require(n.fadeInEnd == 1000.0 && n.fadeOutStart == 5000.0, "no fades: the handles sit on the edges");

    // A split child keeps the parent's anchors: the fade-in began 300 source samples before this piece.
    ProjectAudioClip child = makeClip(3U, "/tmp/a.wav", 5000, 1300U, 2000U, 9000U);
    child.fadeInSamples = 1000U; child.fadeInAnchorSourceSample = 1000U;
    require(std::abs(AudioRangeEdit::fadeGain(child, 5000.0) - 0.3) < 1.0e-9, "the child starts part way into the parent's fade");
    require(std::abs(AudioRangeEdit::fadeGeometry(child).fadeInEnd - 5700.0) < 1.0e-9, "the fade ends 700 samples into the child");
}

void testSpan() {
    Project p;
    p.sampleRate = kRate;
    ProjectTrack t; t.name = "T";
    t.clips.push_back(makeClip(1U, "/tmp/a.wav", 1000, 0U, 1000U, 5000U));
    t.clips.push_back(makeClip(2U, "/tmp/a.wav", 2000, 0U, 1000U, 5000U));   // touches 1
    t.clips.push_back(makeClip(3U, "/tmp/a.wav", 2900, 0U, 600U, 5000U));    // overlaps 2
    t.clips.push_back(makeClip(4U, "/tmp/a.wav", 9000, 0U, 500U, 5000U));    // far away
    t.clips.push_back(makeClip(5U, "/tmp/a.wav", 400, 0U, 500U, 5000U));     // gap of 100 before 1: not part of it
    p.tracks.push_back(t);
    const EditSpan s = AudioRangeEdit::span(p, 0U, 2U);
    require(s.start == 1000 && s.end == 3500 && s.clipIds.size() == 3U, "span must chain touching and overlapping clips");
    require(s.clipIds[0] == 1U && s.clipIds[1] == 2U && s.clipIds[2] == 3U, "span clips must be ordered by start");
    require(AudioRangeEdit::span(p, 0U, 4U).clipIds.size() == 1U, "a lonely clip is its own span");
    require(AudioRangeEdit::span(p, 0U, 99U).empty(), "an unknown clip gives an empty span");
}

void testIsolateAndErase() {
    const std::string path = makeMedia("silveton_range_a.wav", 8000U, 0.8F);
    Project p = oneClipProject(path, 8000U);
    const auto inside = AudioRangeEdit::isolate(p, 0U, {2000, 3000});
    require(inside.size() == 1U, "one piece inside the range");
    const ProjectAudioClip* mid = clipWithId(p, inside[0]);
    require(mid != nullptr && mid->timelineStartSample == 2000 && mid->lengthSamples == 1000U && mid->sourceStartSample == 2000U,
            "the piece must cover exactly the range and point at the same media position");
    require(p.tracks[0].clips.size() == 3U, "three pieces after isolating a middle range");
    std::uint64_t total = 0U;
    for (const auto& c : p.tracks[0].clips) { total += c.lengthSamples; require(c.audioPath == path, "pieces must keep the media"); }
    require(total == 8000U, "no audio lost or added by cutting");

    // Delete with ripple: the audio after the range moves left, nothing is lost around it.
    Project r = oneClipProject(path, 8000U);
    const EditSpan span = AudioRangeEdit::span(r, 0U, 1U);
    AudioRangeEdit::erase(r, 0U, {2000, 3000}, true, span.end);
    require(r.tracks[0].clips.size() == 2U, "two pieces remain");
    const auto after = AudioRangeEdit::span(r, 0U, r.tracks[0].clips[0].id);
    require(after.start == 0 && after.end == 7000 && after.clipIds.size() == 2U, "the pieces must still touch after a ripple cut");
    const ProjectAudioClip* right = &r.tracks[0].clips[0];
    for (const auto& c : r.tracks[0].clips) if (c.timelineStartSample > 0) right = &c;
    require(right->timelineStartSample == 2000 && right->sourceStartSample == 3000, "the right piece plays what followed the range");

    // Delete without ripple leaves a gap.
    Project g = oneClipProject(path, 8000U);
    AudioRangeEdit::erase(g, 0U, {2000, 3000}, false, 8000);
    const auto gapSpan = AudioRangeEdit::span(g, 0U, g.tracks[0].clips[0].id);
    require(gapSpan.end == 2000, "without ripple the later piece must not move");
    std::remove(path.c_str());
}

void testCrop() {
    const std::string path = makeMedia("silveton_range_b.wav", 8000U, 0.8F);
    Project p = oneClipProject(path, 8000U);
    const EditSpan span = AudioRangeEdit::span(p, 0U, 1U);
    AudioRangeEdit::crop(p, 0U, {2000, 5000}, span);
    require(p.tracks[0].clips.size() == 1U, "crop keeps one piece");
    const auto& c = p.tracks[0].clips[0];
    require(c.timelineStartSample == 2000 && c.lengthSamples == 3000U && c.sourceStartSample == 2000U, "crop keeps the range in place");
    std::remove(path.c_str());
}

void testCopyAndInsert() {
    const std::string path = makeMedia("silveton_range_c.wav", 8000U, 0.8F);
    Project p = oneClipProject(path, 8000U);
    p.tracks[0].clips[0].fadeInSamples = 500U;
    p.tracks[0].clips[0].fadeOutSamples = 400U;
    const RangeClipboard whole = AudioRangeEdit::copy(p, 0U, {0, 8000});
    require(whole.pieces.size() == 1U && whole.pieces[0].fadeInSamples == 500U && whole.pieces[0].fadeOutSamples == 400U,
            "copying the whole clip keeps its fades");
    const RangeClipboard part = AudioRangeEdit::copy(p, 0U, {1000, 3000});
    require(part.length == 2000 && part.pieces.size() == 1U && part.pieces[0].timelineStartSample == 0 &&
                part.pieces[0].sourceStartSample == 1000U && part.pieces[0].lengthSamples == 2000U &&
                part.pieces[0].fadeInSamples == 0U && part.pieces[0].fadeOutSamples == 0U,
            "a middle copy has no fades and starts at 0");
    require(p.tracks[0].clips.size() == 1U, "copy must not change the project");

    // Insert (ripple) in the middle: later audio moves right by the pasted length.
    const EditSpan span = AudioRangeEdit::span(p, 0U, 1U);
    const auto created = AudioRangeEdit::insert(p, 0U, 6000, part, true, span.end);
    require(created.size() == 1U, "one pasted piece");
    const auto grown = AudioRangeEdit::span(p, 0U, created[0]);
    require(grown.start == 0 && grown.end == 10000, "the span must grow by the pasted length");
    const ProjectAudioClip* pasted = clipWithId(p, created[0]);
    require(pasted != nullptr && pasted->timelineStartSample == 6000 && pasted->sourceStartSample == 1000U, "pasted piece position");
    bool tail = false;
    for (const auto& c : p.tracks[0].clips) if (c.timelineStartSample == 8000 && c.sourceStartSample == 6000U) tail = true;
    require(tail, "the audio after the paste point moved right");

    // Paste over (no ripple): nothing moves.
    Project q = oneClipProject(path, 8000U);
    (void)AudioRangeEdit::insert(q, 0U, 100, part, false, 8000);
    require(q.tracks[0].clips.size() == 2U && AudioRangeEdit::span(q, 0U, 1U).end == 8000, "overlay paste must not move anything");
    std::remove(path.c_str());
}

void testProcessRange() {
    const std::string path = makeMedia("silveton_range_d.wav", 8000U, 0.5F);
    Project p = oneClipProject(path, 8000U);
    p.tracks[0].clips[0].fadeInSamples = 600U;
    p.tracks[0].clips[0].fadeOutSamples = 600U;
    AudioProcessOptions options;
    options.gainDb = 6.0;
    const EditSpan span = AudioRangeEdit::span(p, 0U, 1U);
    const auto done = AudioRangeEdit::process(p, 0U, {2000, 4000}, AudioProcess::Gain, options, "/tmp", span.end);
    require(done.size() == 1U, "one processed piece");
    const ProjectAudioClip* mid = clipWithId(p, done[0]);
    require(mid != nullptr && mid->audioPath != path && mid->timelineStartSample == 2000 && mid->lengthSamples == 2000U &&
                mid->sourceStartSample == 0U,
            "the processed piece points at new media");
    require(mid->fadeInSamples == 0U && mid->fadeOutSamples == 0U, "the original clip's edge fades must not leak onto the processed piece");
    int untouched = 0;
    for (const auto& c : p.tracks[0].clips) if (c.audioPath == path) ++untouched;
    require(untouched == 2, "the audio outside the range keeps the original media");
    const auto media = WavFile::read(mid->audioPath);
    require(media.sampleRate == kRate && media.audio.frames() == 2000U, "processed media length and rate");
    const float expected = 0.5F * (2000.0F / 8000.0F) * std::pow(10.0F, 6.0F / 20.0F);
    require(std::abs(media.audio.sample(0U, 0U) - expected) < 1.0e-4F, "the gain was applied to the selected part only");
    const auto original = WavFile::read(path);
    require(std::abs(original.audio.sample(0U, 2000U) - 0.5F * 0.25F) < 1.0e-6F, "the original media is unchanged");
    std::remove(mid->audioPath.c_str());

    // The edge fades of the original clip stay with the outer pieces.
    bool firstFade = false, lastFade = false;
    for (const auto& c : p.tracks[0].clips) {
        if (c.timelineStartSample == 0 && c.fadeInSamples == 600U) firstFade = true;
        if (c.timelineStartSample == 4000 && c.fadeOutSamples == 600U) lastFade = true;
    }
    require(firstFade && lastFade, "outer pieces keep the original fades");

    // A process that changes the length moves the rest of the span.
    Project s = oneClipProject(path, 8000U);
    AudioProcessOptions stretch;
    stretch.stretchRatio = 2.0;
    stretch.quality = ElasticAudioQuality::Draft;
    const EditSpan stretchSpan = AudioRangeEdit::span(s, 0U, 1U);
    const auto stretched = AudioRangeEdit::process(s, 0U, {2000, 4000}, AudioProcess::TimeStretch, stretch, "/tmp", stretchSpan.end);
    require(stretched.size() == 1U, "one stretched piece");
    const ProjectAudioClip* st = clipWithId(s, stretched[0]);
    require(st != nullptr && st->lengthSamples > 3800U && st->lengthSamples < 4200U, "the piece became about twice as long");
    const auto grownSpan = AudioRangeEdit::span(s, 0U, stretched[0]);
    require(grownSpan.start == 0 && grownSpan.end == 8000 + static_cast<std::int64_t>(st->lengthSamples) - 2000, "the audio after the piece moved by the length change");
    require(grownSpan.clipIds.size() == 3U, "pieces still touch after the stretch");
    std::remove(st->audioPath.c_str());

    // A locked track is refused and nothing changes.
    Project l = oneClipProject(path, 8000U);
    l.tracks[0].locked = true;
    bool refused = false;
    try { (void)AudioRangeEdit::process(l, 0U, {100, 200}, AudioProcess::Reverse, options, "/tmp", 8000); } catch (const std::runtime_error&) { refused = true; }
    require(refused && l.tracks[0].clips.size() == 1U, "locked track must be refused before anything is cut");
    std::remove(path.c_str());
}


void testNormalizeAcrossPieces() {
    // Two touching clips, one quiet and one loud: Normalize over both keeps their balance.
    const std::string quiet = makeMedia("silveton_range_nq.wav", 4000U, 0.2F);
    const std::string loud = makeMedia("silveton_range_nl.wav", 4000U, 0.8F);
    Project p;
    p.sampleRate = static_cast<double>(kRate);
    ProjectTrack t; t.name = "T";
    t.clips.push_back(makeClip(1U, quiet, 0, 0U, 4000U, 4000U));
    t.clips.push_back(makeClip(2U, loud, 4000, 0U, 4000U, 4000U));
    p.tracks.push_back(t);
    AudioProcessOptions options;
    options.normalizeTargetDb = -6.0;
    const auto done = AudioRangeEdit::process(p, 0U, {0, 8000}, AudioProcess::Normalize, options, "/tmp", 8000);
    require(done.size() == 2U, "two pieces were normalized");
    float peakQuiet = 0.0F, peakLoud = 0.0F;
    for (const auto& c : p.tracks[0].clips) {
        const auto media = WavFile::read(c.audioPath);
        float pk = 0.0F;
        for (std::size_t ch = 0U; ch < media.audio.channels(); ++ch)
            for (std::size_t i = 0U; i < media.audio.frames(); ++i) pk = std::max(pk, std::abs(media.audio.sample(ch, i)));
        if (c.timelineStartSample == 0) peakQuiet = pk; else peakLoud = pk;
        std::remove(c.audioPath.c_str());
    }
    require(std::abs(peakLoud - std::pow(10.0F, -6.0F / 20.0F)) < 2.0e-3F, "the loudest piece reaches the target");
    require(std::abs(peakQuiet / peakLoud - 0.25F) < 2.0e-3F, "the quieter piece keeps its distance to the loud one");
    std::remove(quiet.c_str());
    std::remove(loud.c_str());
}

void testDrawSamples() {
    const std::string path = makeMedia("silveton_range_draw.wav", 8000U, 0.5F);
    Project p = oneClipProject(path, 8000U);
    DrawnSamples drawn;
    drawn.start = 3000;
    drawn.channel = 0;
    for (int i = 0; i < 100; ++i) drawn.values.push_back(i % 2 == 0 ? 0.8F : -0.8F);
    const auto done = AudioRangeEdit::draw(p, 0U, drawn, "/tmp");
    require(done.size() == 1U, "one piece was drawn on");
    const ProjectAudioClip* mid = clipWithId(p, done[0]);
    require(mid != nullptr && mid->timelineStartSample == 3000 && mid->lengthSamples == 100U && mid->audioPath != path,
            "the drawn piece has its own media");
    int untouched = 0;
    for (const auto& c : p.tracks[0].clips) if (c.audioPath == path) ++untouched;
    require(untouched == 2, "audio outside the drawing keeps the original media");
    const auto media = WavFile::read(mid->audioPath);
    require(media.audio.frames() == 100U, "drawn media length");
    require(std::abs(media.audio.sample(0U, 0U) - 0.8F) < 1.0e-6F && std::abs(media.audio.sample(0U, 1U) + 0.8F) < 1.0e-6F,
            "the drawn values are in the chosen channel");
    require(std::abs(media.audio.sample(1U, 0U) - 0.25F) < 1.0e-6F, "the other channel is left alone");
    std::remove(mid->audioPath.c_str());

    // A drawing over the end of the audio only changes what exists, and 'all channels' writes both.
    Project q = oneClipProject(path, 8000U);
    DrawnSamples edge;
    edge.start = 7950;
    edge.channel = -1;
    edge.values.assign(200U, -0.5F);
    const auto tail = AudioRangeEdit::draw(q, 0U, edge, "/tmp");
    require(tail.size() == 1U, "a drawing past the end changes the last piece only");
    const ProjectAudioClip* last = clipWithId(q, tail[0]);
    require(last != nullptr && last->lengthSamples == 50U, "only the existing 50 samples are drawn");
    const auto lastMedia = WavFile::read(last->audioPath);
    require(std::abs(lastMedia.audio.sample(1U, 10U) + 0.5F) < 1.0e-6F, "all channels were drawn");
    std::remove(last->audioPath.c_str());
    std::remove(path.c_str());
}
} // namespace

int main() {
    try {
        testFadeGeometry();
        testSpan();
        testIsolateAndErase();
        testCrop();
        testCopyAndInsert();
        testProcessRange();
        testNormalizeAcrossPieces();
        testDrawSamples();
        std::cout << "audio range edit tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
