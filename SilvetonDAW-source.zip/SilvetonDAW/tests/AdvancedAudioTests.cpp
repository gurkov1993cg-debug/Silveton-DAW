#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>
#include <atomic>

namespace {
constexpr double kPi = 3.141592653589793238462643383279502884;

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

bool near(float a, float b, float epsilon) noexcept {
    return std::abs(a - b) <= epsilon;
}

double estimateFrequency(const silveton::AudioBuffer& audio,
                         double sampleRate,
                         std::size_t begin,
                         std::size_t end) {
    if (audio.channels() == 0U || end <= begin + 2U || end > audio.frames()) return 0.0;
    const float* data = audio.channelData(0U);
    std::size_t crossings = 0U;
    std::size_t first = 0U;
    std::size_t last = 0U;
    bool haveFirst = false;
    for (std::size_t i = begin + 1U; i < end; ++i) {
        if (data[i - 1U] <= 0.0F && data[i] > 0.0F) {
            if (!haveFirst) {
                first = i;
                haveFirst = true;
            }
            last = i;
            ++crossings;
        }
    }
    if (crossings < 2U || last <= first) return 0.0;
    return static_cast<double>(crossings - 1U) * sampleRate /
           static_cast<double>(last - first);
}
}

int main() {
    try {
        constexpr double sampleRate = 48000.0;

        // Phase-vocoder time stretch: duration changes while the sinusoid's
        // fundamental remains at the original pitch.
        silveton::AudioBuffer sine(1U, 48000U);
        for (std::size_t i = 0U; i < sine.frames(); ++i) {
            sine.sample(0U, i) = static_cast<float>(0.5 * std::sin(2.0 * kPi * 440.0 *
                                                                  static_cast<double>(i) / sampleRate));
        }
        const auto stretched = silveton::AudioEditor::timeStretch(sine, 1.5);
        require(stretched.frames() == 72000U, "phase vocoder stretch length incorrect");
        const double stretchedFrequency = estimateFrequency(stretched, sampleRate, 12000U, 60000U);
        require(std::abs(stretchedFrequency - 440.0) < 6.0,
                "phase vocoder changed pitch during time stretch");

        // +12 semitones should double frequency while preserving duration.
        const auto shifted = silveton::AudioEditor::pitchShift(sine, 12.0);
        require(shifted.frames() == sine.frames(), "pitch shift changed clip duration");
        const double shiftedFrequency = estimateFrequency(shifted, sampleRate, 8000U, 40000U);
        require(std::abs(shiftedFrequency - 880.0) < 12.0,
                "phase-vocoder pitch shift did not reach one octave up");

        // Sample-domain gain + pan automation is read by the audio callback.
        constexpr std::uint32_t block = 64U;
        silveton::AudioBuffer automatedSource(1U, block);
        for (std::size_t i = 0U; i < block; ++i) automatedSource.sample(0U, i) = 1.0F;
        silveton::AutomationLane gainLane;
        gainLane.add(0, -6.0205999F); // 0.5 linear
        gainLane.add(63, 0.0F);
        silveton::AutomationLane panLane;
        panLane.add(0, -1.0F);
        panLane.add(63, 1.0F);

        silveton::AudioEngine automationEngine;
        automationEngine.prepare({sampleRate, block, 0U, 2U});
        silveton::TimelineTrack automatedTrack;
        automatedTrack.source = &automatedSource;
        automatedTrack.gainAutomationDb = &gainLane;
        automatedTrack.panAutomation = &panLane;
        automationEngine.addTrack(automatedTrack);
        silveton::ManualAudioDevice automationDevice({sampleRate, block, 0U, 2U});
        automationDevice.start(automationEngine);
        automationEngine.transport().play();
        automationDevice.pump();
        automationEngine.transport().stop();
        require(near(automationDevice.lastOutput()[0U][0U], 0.5F, 2.0e-4F),
                "gain/pan automation start point incorrect");
        require(std::abs(automationDevice.lastOutput()[1U][0U]) < 2.0e-4F,
                "pan automation hard-left leaked right");
        require(std::abs(automationDevice.lastOutput()[0U][63U]) < 2.0e-4F,
                "pan automation hard-right leaked left");
        require(near(automationDevice.lastOutput()[1U][63U], 1.0F, 2.0e-4F),
                "gain/pan automation end point incorrect");
        automationDevice.stop();

        // Lock-free voice-plan replacement while transport is running. No
        // stop/restart is required; the latest control-thread plan appears at
        // the next callback boundary.
        silveton::AudioBuffer sourceA(2U, block);
        silveton::AudioBuffer sourceB(2U, block);
        silveton::AudioBuffer sourceC(2U, block);
        for (std::size_t i = 0U; i < block; ++i) {
            sourceA.sample(0U, i) = sourceA.sample(1U, i) = 0.25F;
            sourceB.sample(0U, i) = sourceB.sample(1U, i) = 0.75F;
            sourceC.sample(0U, i) = sourceC.sample(1U, i) = 0.50F;
        }

        silveton::AudioEngine swapEngine;
        swapEngine.prepare({sampleRate, block, 0U, 2U});
        swapEngine.addTrack({&sourceA, 0, 0U, 0.0F, 0.0F, false, true, 0});
        silveton::ManualAudioDevice swapDevice({sampleRate, block, 0U, 2U});
        swapDevice.start(swapEngine);
        swapEngine.transport().play();
        swapDevice.pump();
        require(near(swapDevice.lastOutput()[0U][0U], 0.25F, 1.0e-6F),
                "initial live plan rendered wrong source");

        // These operations used to throw while transport was playing.
        swapEngine.setVoiceLimit(1U);
        swapEngine.clearTracks();
        swapEngine.addTrack({&sourceB, 0, 0U, 0.0F, 0.0F, false, true, 1});
        require(swapEngine.voicedTrackCount() == 1U,
                "control-thread voiced count is not immediately visible");
        swapEngine.transport().seekSamples(0);
        swapDevice.pump();
        require(near(swapDevice.lastOutput()[0U][0U], 0.75F, 1.0e-6F),
                "pending plan was not adopted at callback boundary");

        swapEngine.addTrack({&sourceC, 0, 0U, 0.0F, 0.0F, false, true, 10});
        swapEngine.setVoiceLimit(1U);
        require(swapEngine.voicedTrackCount() == 1U,
                "voice limit control state incorrect while playing");
        swapEngine.transport().seekSamples(0);
        swapDevice.pump();
        require(near(swapDevice.lastOutput()[0U][0U], 0.50F, 1.0e-6F),
                "latest pending voice-priority plan did not win");
        swapEngine.transport().stop();
        swapDevice.stop();

        // Concurrent control/audio stress: the audio thread continuously
        // consumes immutable plans while the control thread publishes new
        // pan-depth/voice-limit/track snapshots. Source lifetimes are held for
        // the whole stress interval.
        constexpr std::uint32_t stressBlock = 64U;
        silveton::AudioBuffer stressA(2U, 65536U);
        silveton::AudioBuffer stressB(2U, 65536U);
        for (std::size_t i = 0U; i < stressA.frames(); ++i) {
            stressA.sample(0U, i) = stressA.sample(1U, i) = 0.10F;
            stressB.sample(0U, i) = stressB.sample(1U, i) = -0.10F;
        }
        silveton::AudioEngine stressEngine;
        stressEngine.prepare({sampleRate, stressBlock, 0U, 2U});
        stressEngine.addTrack({&stressA, 0, 0U, 0.0F, 0.0F, false, true, 0});
        silveton::ManualAudioDevice stressDevice({sampleRate, stressBlock, 0U, 2U});
        stressDevice.start(stressEngine);
        stressEngine.transport().play();
        std::atomic<bool> callbackFailed {false};
        std::thread audioThread([&] {
            try {
                for (int i = 0; i < 800; ++i) stressDevice.pump();
            } catch (...) {
                callbackFailed.store(true, std::memory_order_release);
            }
        });
        for (int i = 0; i < 400; ++i) {
            stressEngine.setPanDepth((i & 1) == 0 ? silveton::PanDepth::Minus3dB
                                                  : silveton::PanDepth::Minus4_5dB);
            stressEngine.setVoiceLimit((i % 3) == 0 ? 1U : 0U);
            if ((i % 25) == 0) {
                stressEngine.clearTracks();
                stressEngine.addTrack({(i & 1) == 0 ? &stressA : &stressB,
                                       0, 0U, 0.0F, 0.0F, false, true, i});
            }
        }
        audioThread.join();
        stressEngine.transport().stop();
        stressDevice.stop();
        require(!callbackFailed.load(std::memory_order_acquire),
                "concurrent voice-plan stress threw from audio callback driver");

        std::cout << "PASS: phase vocoder preserves pitch during time stretch\n";
        std::cout << "PASS: phase-vocoder pitch shift preserves duration\n";
        std::cout << "PASS: sample-domain gain/pan automation reaches audio callback\n";
        std::cout << "PASS: lock-free voice-plan swap works while playing\n";
        std::cout << "PASS: concurrent control/audio plan publication stress\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
