#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include "silveton/MixMath.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}
bool near(float a, float b, float eps = 1.0e-5F) { return std::abs(a - b) <= eps; }

class TimeProbe final : public silveton::IAudioDeviceCallback {
public:
    void updateDeviceTime(const silveton::AudioDeviceTimeInfo& time) noexcept override {
        last = time;
        ++updates;
    }
    void processAudio(const float* const*, float* const* outputs,
                      std::uint32_t, std::uint32_t outputChannels,
                      std::uint32_t frames) noexcept override {
        for (std::uint32_t c = 0U; c < outputChannels; ++c) {
            if (outputs[c] == nullptr) continue;
            for (std::uint32_t i = 0U; i < frames; ++i) outputs[c][i] = 0.0F;
        }
    }
    silveton::AudioDeviceTimeInfo last {};
    std::uint32_t updates {0U};
};
}

int main() {
    try {
        constexpr std::uint32_t block = 64U;
        silveton::AudioDeviceConfig config {48000.0, block, 0U, 2U};
        silveton::AudioEngine engine;
        engine.prepare(config);

        silveton::AudioBuffer mono(1U, 256U);
        for (std::size_t i = 0; i < mono.frames(); ++i) mono.sample(0U, i) = 0.5F;

        engine.addTrack({&mono, 32, 0U, 0.0F, 0.0F, false});
        silveton::ManualAudioDevice device(config);
        device.start(engine);

        engine.transport().seekSamples(0);
        engine.transport().play();
        device.pump();
        const auto& first = device.lastOutput();

        for (std::size_t i = 0; i < 32U; ++i) {
            require(near(first[0][i], 0.0F), "timeline emitted audio before clip start (L)");
            require(near(first[1][i], 0.0F), "timeline emitted audio before clip start (R)");
        }
        const float center = 0.5F * static_cast<float>(silveton::MixMath::dbToLinear(-3.0));
        for (std::size_t i = 32U; i < block; ++i) {
            require(near(first[0][i], center, 2.0e-5F), "mono constant-power pan incorrect (L)");
            require(near(first[1][i], center, 2.0e-5F), "mono constant-power pan incorrect (R)");
        }
        require(engine.transport().positionSamples() == 64, "sample clock did not advance exactly one block");
        const auto meter = engine.outputMeter();
        require(near(meter.leftPeak, center, 2.0e-5F), "engine peak meter is not from rendered output");
        require(meter.leftRms > 0.24F && meter.leftRms < 0.26F, "engine RMS meter incorrect for half-silent block");

        engine.transport().stop();
        device.pump();
        const auto& stopped = device.lastOutput();
        for (std::size_t i = 0; i < block; ++i) {
            require(near(stopped[0][i], 0.0F), "stop did not silence output");
            require(near(stopped[1][i], 0.0F), "stop did not silence output");
        }
        require(engine.transport().positionSamples() == 64, "stopped transport advanced sample clock");

        engine.transport().seekSamples(96);
        engine.transport().play();
        device.pump();
        require(engine.transport().positionSamples() == 160, "seek/play sample clock mismatch");
        require(near(device.lastOutput()[0][0], center, 2.0e-5F), "seek did not address timeline source correctly");

        engine.transport().stop();
        engine.clearTracks();

        silveton::AudioBuffer stereo(2U, 64U);
        for (std::size_t i = 0; i < stereo.frames(); ++i) {
            stereo.sample(0U, i) = 0.25F;
            stereo.sample(1U, i) = 0.5F;
        }
        engine.addTrack({&stereo, 0, 0U, 0.0F, 1.0F, false});
        engine.transport().seekSamples(0);
        engine.transport().play();
        device.pump();
        require(std::abs(device.lastOutput()[0][0]) < 1.0e-5F, "stereo balance hard-right leaks left");
        require(near(device.lastOutput()[1][0], 0.5F, 2.0e-5F), "stereo balance altered hard-right channel incorrectly");

        device.stop();

        // Device timing contract: the backend publishes the device sample clock
        // immediately before each audio callback. CoreAudio supplies this from
        // AudioTimeStamp; the manual backend makes it deterministic for tests.
        silveton::ManualAudioDevice timingDevice(config);
        TimeProbe timingProbe;
        timingDevice.start(timingProbe);
        timingDevice.pump();
        require(timingProbe.updates == 1U, "device timing was not published before callback");
        require(timingProbe.last.sampleTimeValid && timingProbe.last.sampleTime == 0.0,
                "first device sample timestamp is incorrect");
        timingDevice.pump();
        require(timingProbe.updates == 2U, "second device timing update missing");
        require(timingProbe.last.sampleTimeValid && timingProbe.last.sampleTime == static_cast<double>(block),
                "device sample timestamp did not advance exactly one block");
        timingDevice.stop();

        std::cout << "PASS: device callback abstraction drives engine\n";
        std::cout << "PASS: transport play/stop/seek is sample-addressed\n";
        std::cout << "PASS: timeline mixing changes real output samples\n";
        std::cout << "PASS: output meters derive from callback samples\n";
        std::cout << "PASS: device sample timestamps are callback-aligned\n";
        std::cout << "PASS: realtime milestone 0.2.0\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
