#include "silveton/DawRuntimeCoordinator.h"
#include "silveton/WavFile.h"
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdexcept>
namespace {void req(bool c,const char*m){if(!c)throw std::runtime_error(m);}class Inst:public silveton::IVst3PluginInstance{public:std::string m{"m"},c{"c"};const std::string&modulePath()const noexcept override{return m;}const std::string&classId()const noexcept override{return c;}void prepare(double,std::uint32_t)override{}void reset()noexcept override{}std::uint32_t latencySamples()const noexcept override{return 0;}void process(float*l,float*r,std::uint32_t n,const silveton::ProcessorContext&)noexcept override{(void)l;(void)r;(void)n;}std::size_t inputBusCount()const noexcept override{return 1;}std::size_t outputBusCount()const noexcept override{return 1;}std::size_t inputBusChannelCount(std::size_t)const noexcept override{return 2;}std::size_t outputBusChannelCount(std::size_t)const noexcept override{return 2;}bool processBuses(const silveton::ConstStereoBus*,std::size_t,silveton::StereoBus*,std::size_t,std::uint32_t,const silveton::ProcessorContext&)noexcept override{return true;}bool setComponentState(const std::vector<std::uint8_t>&s)override{state=s;return true;}bool setControllerState(const std::vector<std::uint8_t>&)override{return true;}std::vector<std::uint8_t> componentState()const override{return state;}std::vector<std::uint8_t> controllerState()const override{return{};}bool hasEventInput()const noexcept override{return true;}bool queueMidi(const silveton::Vst3MidiEvent&)noexcept override{return true;}bool queueParameter(std::uint32_t,double,std::int32_t)noexcept override{return true;}bool popAutomationGesture(silveton::AutomationGesture&)noexcept override{return false;}bool popOutputParameter(silveton::Vst3OutputParameterChange&)noexcept override{return false;}std::uint32_t consumeRestartFlags()noexcept override{return 0;}std::vector<std::uint8_t> state{1,2,3};};class F:public silveton::IVst3InstanceFactory{public:std::unique_ptr<silveton::IVst3PluginInstance>create(const std::string&,const std::string&,std::string&)override{return std::make_unique<Inst>();}};}
int main(){using namespace silveton;const std::string wav="/tmp/SilvetonRuntimeCoordinator.wav";try{AudioBuffer b(2,256);for(std::size_t i=0;i<b.frames();++i){b.sample(0,i)=.1F;b.sample(1,i)=.1F;}WavFile::writeFloat32(wav,48000,b);ProjectSession session;session.project().tempoMap.setSampleRate(48000.0);session.project().tempoMap.setInitialTempo(120.0);session.project().tempoMap.addTempoChange(128,90.0);ProjectTrack t;t.audioPath=wav;ProjectPluginSlot ps;ps.modulePath="m";ps.classId="c";ps.midiInputPort=5;t.pluginSlots.push_back(ps);session.project().tracks.push_back(t);ProjectMidiTrack mt;mt.outputPort=5;MusicalMidiNote n;n.startQuarterNotes=0;n.durationQuarterNotes=.25;(void)mt.sequence.addNote(n);session.project().midiTracks.push_back(mt);AudioEngine engine;F f;DawRuntimeCoordinator runtime(session,engine,f);runtime.prepare({48000,64,0,2});req(runtime.status().media.tracksPublished==1,"runtime did not publish project audio");float l[64]{},r[64]{};float*o[2]{l,r};runtime.audioCallback().processAudio(nullptr,o,0,2,64);req(engine.trackCount()==1,"runtime engine track count mismatch");req(std::abs(engine.musicalPositionAtSample(128).bpm-90.0)<1.0e-9,"routing rebuild destroyed project tempo map");(void)runtime.service();runtime.capturePluginState();req(session.project().tracks[0].pluginSlots[0].componentState==std::vector<std::uint8_t>({1,2,3}),"runtime did not capture plugin state");// Regression: import 12 source tracks after an empty/small initial graph,
// keeping 48 kHz WAV media untouched while the engine renders at 96 kHz.
{
    const std::string multiWav = "/tmp/SilvetonTwelveTracks48k.wav";
    AudioBuffer tone(2U, 4096U);
    for (std::size_t i = 0; i < tone.frames(); ++i) {
        tone.sample(0U, i) = 0.04F;
        tone.sample(1U, i) = 0.04F;
    }
    WavFile::writeFloat32(multiWav, 48000U, tone);
    ProjectSession multiSession;
    AudioEngine multiEngine;
    F multiFactory;
    DawRuntimeCoordinator multiRuntime(multiSession, multiEngine, multiFactory);
    multiRuntime.setInternalSampleRate(96000.0);
    multiRuntime.prepare({48000.0, 64U, 0U, 2U});
    // Commit the starter graph before changing the project topology.
    multiEngine.adoptPendingRealtimeStateAtBlockBoundary();
    for (std::size_t i = 0; i < 12U; ++i) {
        ProjectTrack track;
        track.name = "Audio " + std::to_string(i + 1U);
        track.audioPath = multiWav;
        ProjectAudioClip clip;   // as the app imports: one clip, frames counted at the project rate (4096 @ 48 kHz = 8192 @ 96 kHz)
        clip.id = 1U;
        clip.audioPath = multiWav;
        clip.lengthSamples = 8192U;
        clip.sourceFrames = 8192U;
        clip.sourceChannels = 2U;
        clip.sourceSampleRate = 48000U;
        track.clips.push_back(clip);
        multiSession.project().addTrack(std::move(track));
    }
    const auto rebuilt = multiRuntime.rebuildProject(4096U, 2000U);
    req(rebuilt.media.tracksPublished == 12U, "12 tracks were not published");
    req(rebuilt.media.offlineClips == 0U, "48 kHz clips were offline in a 96 kHz project");
    req(multiEngine.trackCount() == 12U, "12 tracks did not reach the audio engine");
    multiEngine.adoptPendingRealtimeStateAtBlockBoundary();
    req(multiEngine.processorGraph() && multiEngine.processorGraph()->nodeCount() >= 13U,
        "12 tracks did not receive a new processor graph");
    multiEngine.transport().play();
    float outL[64] {}, outR[64] {};
    float* multiOut[2] {outL, outR};
    multiEngine.processAudio(nullptr, multiOut, 0U, 2U, 64U);
    req(std::abs(outL[0]) > 0.01F && std::abs(outR[0]) > 0.01F,
        "12 imported 48 kHz tracks rendered silence at 96 kHz");
    multiEngine.transport().stop();
    // Live clip refresh: the first clip moves 2 s later; no rebuild, the plan is published again and
    // the start of the timeline is silent on that track while the moved clip still plays later.
    {
        auto& clips = multiSession.project().tracks[0].clips;
        req(!clips.empty(), "imported track has no clip");
        clips[0].timelineStartSample = 2 * 96000;
        req(multiRuntime.playback().refreshClips(), "live clip refresh was refused for a file that streams");
        req(multiEngine.trackCount() == 12U, "live clip refresh changed the track count");
        multiEngine.adoptPendingRealtimeStateAtBlockBoundary();
        multiEngine.transport().seekSamples(2 * 96000 + 1024);
        multiEngine.transport().play();
        float movedL[64] {}, movedR[64] {};
        float* movedOut[2] {movedL, movedR};
        multiEngine.processAudio(nullptr, movedOut, 0U, 2U, 64U);
        req(std::abs(movedL[0]) > 0.001F, "the moved clip is silent at its new place after the live refresh");
        multiEngine.transport().stop();
        ProjectTrack extra;
        extra.name = "New";
        extra.clips.push_back(multiSession.project().tracks[0].clips[0]);
        multiSession.project().addTrack(std::move(extra));
        req(!multiRuntime.playback().refreshClips(), "live clip refresh must refuse a changed track count");
    }
    multiRuntime.playback().stop();
    (void)std::remove(multiWav.c_str());
    std::cout << "PASS: 12 48 kHz tracks rebuild live 96 kHz graph and produce audio; live clip refresh\n";
}
(void)std::remove(wav.c_str());std::cout<<"PASS: application runtime rebuilds media/VST3/MIDI/routing and captures state\n";return 0;}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<'\n';(void)std::remove(wav.c_str());return 1;}}
