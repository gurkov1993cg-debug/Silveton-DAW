// Level meters: the engine keeps the highest peak between two UI reads, and the
// UI-side ballistics (instant attack, steady fall, peak hold, latched clip) are
// time based and predictable.
#include "silveton/AudioBuffer.h"
#include "silveton/AudioEngine.h"
#include "silveton/MeterBank.h"

#include <cmath>
#include <iostream>
#include <stdexcept>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
bool near(double a, double b, double eps) { return std::abs(a - b) <= eps; }

float linear(double db) { return static_cast<float>(std::pow(10.0, db / 20.0)); }

void testBallistics() {
    using namespace silveton;
    const MeterBallistics ball;
    MeterChannelDisplay m;

    // Attack is instant and exact.
    ball.step(m, linear(-6.0), 0.033);
    require(near(m.levelDb, -6.0, 0.01), "attack must reach the peak immediately");
    require(near(m.holdDb, -6.0, 0.01), "hold marker must follow a new high");

    // Release is a steady fall in dB per second, independent of the repaint rate.
    MeterChannelDisplay a, b;
    ball.step(a, 1.0F, 0.0);
    ball.step(b, 1.0F, 0.0);
    for (int i = 0; i < 15; ++i) ball.step(a, 0.0F, 1.0 / 30.0);    // 0.5 s at 30 Hz
    for (int i = 0; i < 25; ++i) ball.step(b, 0.0F, 0.5 / 25.0);    // 0.5 s at 50 Hz
    require(near(a.levelDb, -13.0, 0.05), "fall must be 26 dB per second");
    require(near(a.levelDb, b.levelDb, 0.05), "fall must not depend on the repaint rate");

    // The marker stays for the hold time, then drops onto the bar.
    require(near(a.holdDb, 0.0, 0.01), "hold marker must stay while held");
    for (int i = 0; i < 150; ++i) ball.step(a, 0.0F, 1.0 / 30.0);   // +5 s
    require(a.holdDb <= a.levelDb + 0.01F, "hold marker must settle onto the bar after the hold time");

    // A louder block always wins, a quieter one never lifts the bar.
    MeterChannelDisplay c;
    ball.step(c, linear(-20.0), 0.033);
    ball.step(c, linear(-30.0), 0.033);
    require(c.levelDb < -20.0F && c.levelDb > -22.0F, "a quieter block must not raise the bar");

    // A stalled UI (the window was busy) must not make the bar jump.
    MeterChannelDisplay d;
    ball.step(d, 1.0F, 0.0);
    ball.step(d, 0.0F, 10.0);
    require(d.levelDb > -7.0F, "a long stall may only fall by the maximum step");

    // Silence goes to the floor, never to NaN or infinity.
    MeterChannelDisplay e;
    ball.step(e, 0.0F, 0.033);
    require(near(e.levelDb, ball.floorDb, 0.001) && std::isfinite(e.levelDb), "silence must sit at the floor");
    ball.step(e, std::nanf(""), 0.033);
    require(std::isfinite(e.levelDb), "NaN input must not poison the meter");
}

void testClipAndReset() {
    using namespace silveton;
    MeterBank bank;
    bank.setTrackCount(2U);
    bank.feedTrack(0U, 0.5F, 0.5F, 0.033);
    require(!bank.track(0U).clip(), "no clip below 0 dBFS");
    bank.feedTrack(0U, 1.2F, 0.2F, 0.033);
    require(bank.track(0U).left.clip && !bank.track(0U).right.clip, "clip lamp must light for the channel that clipped");
    for (int i = 0; i < 300; ++i) bank.feedTrack(0U, 0.0F, 0.0F, 0.033);
    require(bank.track(0U).left.clip, "clip lamp must stay latched");
    require(bank.track(0U).maxDb() > 1.0F, "maximum must be remembered");
    require(!bank.track(1U).clip(), "other tracks must be untouched");
    bank.resetTrackPeaks(0U);
    require(!bank.track(0U).clip() && bank.track(0U).maxDb() < -60.0F, "reset clears lamp and maximum");

    bank.feedMaster(1.5F, 1.5F, 0.033);
    require(bank.master().clip(), "master clip");
    bank.resetPeaks();
    require(!bank.master().clip(), "reset all clears the master lamp");
    require(bank.track(99U).left.levelDb < -100.0F, "unknown track reads as silence");
}

void testEngineKeepsPeaksBetweenReads() {
    constexpr std::uint32_t block = 64U;
    silveton::AudioBuffer source(2U, 4U * block);
    for (std::size_t i = 0U; i < block; ++i) source.sample(0U, i) = source.sample(1U, i) = 0.8F;   // loud first block, then silence

    silveton::TimelineClip clip;
    clip.source = &source;
    clip.timelineStartSample = 0;
    clip.lengthSamples = 4U * block;
    silveton::TimelineTrack track;
    track.clips = {clip};

    silveton::AudioDeviceConfig config {48000.0, block, 0U, 2U};
    silveton::AudioEngine engine;
    engine.prepare(config);
    engine.addTrack(track);
    silveton::ManualAudioDevice device(config);
    device.start(engine);
    engine.transport().play();
    for (int i = 0; i < 3; ++i) device.pump();   // loud block, then two silent ones

    // The classic "last block" read has already forgotten the loud block ...
    require(engine.trackMeter(0U).leftPeak < 0.001F, "last-block meter should be silent now");
    // ... the accumulator has not.
    const auto track1 = engine.takeTrackPeaks(0U);
    require(track1.leftPeak > 0.4F && track1.rightPeak > 0.4F, "track peak between two reads was lost");
    const auto master1 = engine.takeOutputPeaks();
    require(master1.leftPeak > 0.1F && master1.rightPeak > 0.1F, "master peak between two reads was lost");

    // Reading resets the accumulator; the next read only sees what happened afterwards.
    device.pump();
    require(engine.takeTrackPeaks(0U).leftPeak < 0.001F, "track accumulator must reset on read");
    require(engine.takeOutputPeaks().leftPeak < 0.001F, "master accumulator must reset on read");
    require(engine.takeTrackPeaks(99U).leftPeak == 0.0F, "unknown track reads as silence");
    device.stop();
}
} // namespace

int main() {
    try {
        testBallistics();
        testClipAndReset();
        testEngineKeepsPeaksBetweenReads();
        std::cout << "meter bank tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
