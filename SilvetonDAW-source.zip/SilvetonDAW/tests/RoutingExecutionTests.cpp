#include "silveton/AudioBuffer.h"
#include "silveton/AudioEngine.h"
#include "silveton/ProcessorGraph.h"
#include <array>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <new>
#include <stdexcept>
#include <vector>

namespace {
std::atomic<bool> gTrackAllocations {false};
std::atomic<std::size_t> gAllocationCount {0U};

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

class DelayProcessor final : public silveton::ITrackProcessor {
public:
    explicit DelayProcessor(std::uint32_t latency) : latency_(latency) {}

    void prepare(double, std::uint32_t maxFrames) override {
        const std::size_t size = static_cast<std::size_t>(latency_) + maxFrames + 1U;
        left_.assign(size, 0.0F);
        right_.assign(size, 0.0F);
        write_ = 0U;
    }

    void reset() noexcept override {
        std::fill(left_.begin(), left_.end(), 0.0F);
        std::fill(right_.begin(), right_.end(), 0.0F);
        write_ = 0U;
    }

    std::uint32_t latencySamples() const noexcept override { return latency_; }

    void process(float* left,
                 float* right,
                 std::uint32_t frames,
                 const silveton::ProcessorContext&) noexcept override {
        if (latency_ == 0U || left_.empty()) return;
        const std::size_t size = left_.size();
        for (std::uint32_t i = 0U; i < frames; ++i) {
            const float inL = left[i];
            const float inR = right[i];
            left_[write_] = inL;
            right_[write_] = inR;
            const std::size_t read = (write_ + size - latency_) % size;
            left[i] = left_[read];
            right[i] = right_[read];
            write_ = (write_ + 1U) % size;
        }
    }

private:
    std::uint32_t latency_ {0U};
    std::vector<float> left_;
    std::vector<float> right_;
    std::size_t write_ {0U};
};

class GeneratorProcessor final : public silveton::IRoutedTrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 0U; }
    std::size_t outputBusCount() const noexcept override { return 1U; }

    bool processBuses(const silveton::ConstStereoBus*,
                      std::size_t inputCount,
                      silveton::StereoBus* outputs,
                      std::size_t outputCount,
                      std::uint32_t frames,
                      const silveton::ProcessorContext& context) noexcept override {
        if (inputCount != 0U || outputCount < 1U || outputs == nullptr) return false;
        lastTempo = context.tempo;
        lastProjectSample = context.projectSample;
        lastPlaying = context.playing;
        for (std::uint32_t i = 0U; i < frames; ++i) {
            outputs[0].left[i] = 0.25F;
            outputs[0].right[i] = -0.25F;
        }
        return true;
    }

    double lastTempo {0.0};
    std::int64_t lastProjectSample {-1};
    bool lastPlaying {true};
};

void testAudioEngineGraphPdcAndRealtimeSafety() {
    constexpr std::uint32_t frames = 16U;
    DelayProcessor delay(4U);

    std::vector<silveton::GraphNodeDefinition> nodes(3U);
    nodes[0].processors.push_back({&delay, {}});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U, 2U, 1.0F}, {1U, 2U, 1.0F}}, 2U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(&graph, 64U);
    engine.prepare({48000.0, frames, 0U, 2U});

    silveton::AudioBuffer a(2U, frames);
    silveton::AudioBuffer b(2U, frames);
    a.sample(0U, 0U) = 1.0F;
    a.sample(1U, 0U) = 1.0F;
    b.sample(0U, 0U) = 1.0F;
    b.sample(1U, 0U) = 1.0F;
    engine.addTrack({&a, 0, 0U, 0.0F, 0.0F, false, true, 0});
    engine.addTrack({&b, 0, 0U, 0.0F, 0.0F, false, true, 0});
    engine.transport().play();

    std::array<float, frames> outL {};
    std::array<float, frames> outR {};
    float* outputs[2] {outL.data(), outR.data()};

    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const float expected = i == 4U ? 2.0F : 0.0F;
        require(std::abs(outL[i] - expected) < 1.0e-6F, "AudioEngine graph PDC left mismatch");
        require(std::abs(outR[i] - expected) < 1.0e-6F, "AudioEngine graph PDC right mismatch");
    }

    graph.reset();
    engine.transport().seekSamples(0);
    gAllocationCount.store(0U, std::memory_order_relaxed);
    gTrackAllocations.store(true, std::memory_order_release);
    for (int iteration = 0; iteration < 256; ++iteration) {
        engine.transport().seekSamples(0);
        engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    }
    gTrackAllocations.store(false, std::memory_order_release);
    require(gAllocationCount.load(std::memory_order_acquire) == 0U,
            "heap allocation occurred in AudioEngine ProcessorGraph callback path");
}

void testGraphRunsWhileTransportStoppedAndReceivesContext() {
    constexpr std::uint32_t frames = 8U;
    GeneratorProcessor generator;
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    nodes[0].processors.push_back({&generator, {}});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U, 1U, 1.0F}}, 1U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(&graph, 64U);
    engine.setTempo(137.0);
    engine.prepare({48000.0, frames, 0U, 2U});
    engine.transport().seekSamples(1234);

    std::array<float, frames> outL {};
    std::array<float, frames> outR {};
    float* outputs[2] {outL.data(), outR.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);

    for (std::uint32_t i = 0U; i < frames; ++i) {
        require(std::abs(outL[i] - 0.25F) < 1.0e-6F,
                "stopped-transport instrument graph did not reach master left");
        require(std::abs(outR[i] + 0.25F) < 1.0e-6F,
                "stopped-transport instrument graph did not reach master right");
    }
    require(std::abs(generator.lastTempo - 137.0) < 1.0e-12,
            "AudioEngine did not pass session tempo into ProcessorContext");
    require(generator.lastProjectSample == 1234,
            "AudioEngine did not pass project sample into ProcessorContext");
    require(!generator.lastPlaying,
            "AudioEngine ProcessorContext incorrectly reported stopped transport as playing");
}

void testGraphCapacityCovers256TracksPlusMaster() {
    constexpr std::size_t nodesNeeded = 257U;
    std::vector<silveton::GraphNodeDefinition> nodes(nodesNeeded);
    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {}, 256U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(&graph, 64U);
    engine.prepare({48000.0, 16U, 0U, 2U});
    require(graph.nodeCount() == nodesNeeded,
            "ProcessorGraph capacity does not cover 256 tracks plus master node");
}
}

void* operator new(std::size_t size) {
    if (gTrackAllocations.load(std::memory_order_relaxed))
        gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}

void* operator new[](std::size_t size) {
    if (gTrackAllocations.load(std::memory_order_relaxed))
        gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}

void* operator new(std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackAllocations.load(std::memory_order_relaxed))
        gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    return std::malloc(size);
}

void* operator new[](std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackAllocations.load(std::memory_order_relaxed))
        gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    return std::malloc(size);
}

void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }
void operator delete(void* p, const std::nothrow_t&) noexcept { std::free(p); }
void operator delete[](void* p, const std::nothrow_t&) noexcept { std::free(p); }

int main() {
    try {
        testAudioEngineGraphPdcAndRealtimeSafety();
        testGraphRunsWhileTransportStoppedAndReceivesContext();
        testGraphCapacityCovers256TracksPlusMaster();
        std::cout << "PASS: ProcessorGraph executes in real AudioEngine callback with PDC\n";
        std::cout << "PASS: ProcessorGraph callback path performs zero heap allocations\n";
        std::cout << "PASS: stopped-transport instrument processing + ProcessorContext tempo/sample state\n";
        std::cout << "PASS: graph capacity covers 256 track nodes plus master\n";
        return 0;
    } catch (const std::exception& e) {
        gTrackAllocations.store(false, std::memory_order_release);
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
