#include "silveton/AudioBuffer.h"
#include "silveton/AudioEngine.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/MixerRouting.h"
#include "silveton/MixerRuntime.h"
#include "silveton/Vst3Runtime.h"
#include <array>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <new>
#include <stdexcept>
#include <thread>
#include <vector>

namespace {
std::atomic<bool> gTrackAllocations {false};
std::atomic<std::size_t> gAllocationCount {0U};

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

class DelayProcessor final : public silveton::ITrackProcessor {
public:
    explicit DelayProcessor(std::uint32_t latency) : latency_(latency) {}

    void prepare(double, std::uint32_t maxFrames) override {
        const std::size_t size = static_cast<std::size_t>(latency_) + maxFrames + 1U;
        left_.assign(size, 0.0F);
        right_.assign(size, 0.0F);
        write_ = 0U;
    }

    void reset() noexcept override {
        std::fill(left_.begin(), left_.end(), 0.0F);
        std::fill(right_.begin(), right_.end(), 0.0F);
        write_ = 0U;
    }

    std::uint32_t latencySamples() const noexcept override { return latency_; }

    void process(float* left,
                 float* right,
                 std::uint32_t frames,
                 const silveton::ProcessorContext&) noexcept override {
        if (latency_ == 0U || left_.empty()) return;
        const std::size_t size = left_.size();
        for (std::uint32_t i = 0U; i < frames; ++i) {
            const float inL = left[i];
            const float inR = right[i];
            left_[write_] = inL;
            right_[write_] = inR;
            const std::size_t read = (write_ + size - latency_) % size;
            left[i] = left_[read];
            right[i] = right_[read];
            write_ = (write_ + 1U) % size;
        }
    }

private:
    std::uint32_t latency_ {0U};
    std::vector<float> left_;
    std::vector<float> right_;
    std::size_t write_ {0U};
};


class CountingGainProcessor final : public silveton::ITrackProcessor {
public:
    explicit CountingGainProcessor(float gain) : gain_(gain) {}

    void prepare(double, std::uint32_t) override { ++prepareCount; }
    void reset() noexcept override { ++resetCount; }
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float* left,
                 float* right,
                 std::uint32_t frames,
                 const silveton::ProcessorContext&) noexcept override {
        for (std::uint32_t i = 0U; i < frames; ++i) {
            left[i] *= gain_;
            right[i] *= gain_;
        }
    }

    int prepareCount {0};
    int resetCount {0};

private:
    float gain_ {1.0F};
};

class AdjustableLatencyProcessor final : public silveton::ITrackProcessor {
public:
    void prepare(double, std::uint32_t) override { ++prepareCount; }
    void reset() noexcept override { ++resetCount; }
    std::uint32_t latencySamples() const noexcept override { return latency_; }
    void setLatency(std::uint32_t value) noexcept { latency_ = value; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    int prepareCount {0};
    int resetCount {0};
private:
    std::uint32_t latency_ {0U};
};

std::unique_ptr<silveton::ProcessorGraph> makeTrackMasterGraph(silveton::ITrackProcessor* processor,
                                                               float routeGain = 1.0F) {
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    if (processor != nullptr) nodes[0].processors.push_back({processor, {}});
    std::unique_ptr<silveton::ProcessorGraph> graph(new silveton::ProcessorGraph);
    graph->configure(std::move(nodes), {{0U, 1U, routeGain}}, 1U);
    return graph;
}

class NullFactory final : public silveton::IVst3InstanceFactory {
public:
    std::unique_ptr<silveton::IVst3PluginInstance> create(const std::string&,
                                                          const std::string&,
                                                          std::string& failureReason) override {
        failureReason = "not used";
        return {};
    }
};

class GeneratorProcessor final : public silveton::IRoutedTrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 0U; }
    std::size_t outputBusCount() const noexcept override { return 1U; }

    bool processBuses(const silveton::ConstStereoBus*,
                      std::size_t inputCount,
                      silveton::StereoBus* outputs,
                      std::size_t outputCount,
                      std::uint32_t frames,
                      const silveton::ProcessorContext& context) noexcept override {
        if (inputCount != 0U || outputCount < 1U || outputs == nullptr) return false;
        lastTempo = context.tempo;
        lastProjectSample = context.projectSample;
        lastPlaying = context.playing;
        for (std::uint32_t i = 0U; i < frames; ++i) {
            outputs[0].left[i] = 0.25F;
            outputs[0].right[i] = -0.25F;
        }
        return true;
    }

    double lastTempo {0.0};
    std::int64_t lastProjectSample {-1};
    bool lastPlaying {true};
};

void testAudioEngineGraphPdcAndRealtimeSafety() {
    constexpr std::uint32_t frames = 16U;
    DelayProcessor delay(4U);

    std::vector<silveton::GraphNodeDefinition> nodes(3U);
    nodes[0].processors.push_back({&delay, {}});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U, 2U, 1.0F}, {1U, 2U, 1.0F}}, 2U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(&graph, 64U);
    engine.prepare({48000.0, frames, 0U, 2U});

    silveton::AudioBuffer a(2U, frames);
    silveton::AudioBuffer b(2U, frames);
    a.sample(0U, 0U) = 1.0F;
    a.sample(1U, 0U) = 1.0F;
    b.sample(0U, 0U) = 1.0F;
    b.sample(1U, 0U) = 1.0F;
    engine.addTrack({&a, 0, 0U, 0.0F, 0.0F, false, true, 0});
    engine.addTrack({&b, 0, 0U, 0.0F, 0.0F, false, true, 0});
    engine.transport().play();

    std::array<float, frames> outL {};
    std::array<float, frames> outR {};
    float* outputs[2] {outL.data(), outR.data()};

    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const float expected = i == 4U ? 2.0F : 0.0F;
        require(std::abs(outL[i] - expected) < 1.0e-6F, "AudioEngine graph PDC left mismatch");
        require(std::abs(outR[i] - expected) < 1.0e-6F, "AudioEngine graph PDC right mismatch");
    }

    graph.reset();
    engine.transport().seekSamples(0);
    gAllocationCount.store(0U, std::memory_order_relaxed);
    gTrackAllocations.store(true, std::memory_order_release);
    for (int iteration = 0; iteration < 256; ++iteration) {
        engine.transport().seekSamples(0);
        engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    }
    gTrackAllocations.store(false, std::memory_order_release);
    require(gAllocationCount.load(std::memory_order_acquire) == 0U,
            "heap allocation occurred in AudioEngine ProcessorGraph callback path");
}

void testGraphRunsWhileTransportStoppedAndReceivesContext() {
    constexpr std::uint32_t frames = 8U;
    GeneratorProcessor generator;
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    nodes[0].processors.push_back({&generator, {}});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U, 1U, 1.0F}}, 1U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(&graph, 64U);
    engine.setTempo(137.0);
    engine.prepare({48000.0, frames, 0U, 2U});
    engine.transport().seekSamples(1234);

    std::array<float, frames> outL {};
    std::array<float, frames> outR {};
    float* outputs[2] {outL.data(), outR.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);

    for (std::uint32_t i = 0U; i < frames; ++i) {
        require(std::abs(outL[i] - 0.25F) < 1.0e-6F,
                "stopped-transport instrument graph did not reach master left");
        require(std::abs(outR[i] + 0.25F) < 1.0e-6F,
                "stopped-transport instrument graph did not reach master right");
    }
    require(std::abs(generator.lastTempo - 137.0) < 1.0e-12,
            "AudioEngine did not pass session tempo into ProcessorContext");
    require(generator.lastProjectSample == 1234,
            "AudioEngine did not pass project sample into ProcessorContext");
    require(!generator.lastPlaying,
            "AudioEngine ProcessorContext incorrectly reported stopped transport as playing");
}

void testLiveImmutableGraphPublicationAndReclamation() {
    constexpr std::uint32_t frames = 8U;
    CountingGainProcessor reused(1.0F);
    CountingGainProcessor newlyInserted(2.0F);

    auto initialOwned = makeTrackMasterGraph(&reused, 1.0F);
    silveton::ProcessorGraph* initial = initialOwned.get();

    silveton::AudioEngine engine;
    engine.setProcessorGraph(initial, 64U);
    engine.prepare({48000.0, frames, 0U, 2U});
    require(reused.prepareCount == 1, "initial processor prepare count mismatch");
    require(reused.resetCount == 1, "initial processor reset count mismatch");

    silveton::AudioBuffer source(2U, 64U);
    for (std::size_t i = 0U; i < source.frames(); ++i) {
        source.sample(0U, i) = 1.0F;
        source.sample(1U, i) = 1.0F;
    }
    engine.addTrack({&source, 0, 0U, 0.0F, 0.0F, false, true, 0});
    engine.transport().play();

    std::array<float, frames> outL {};
    std::array<float, frames> outR {};
    float* outputs[2] {outL.data(), outR.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    for (std::uint32_t i = 0U; i < frames; ++i)
        require(std::abs(outL[i] - 1.0F) < 1.0e-6F, "initial live graph output mismatch");

    auto replacement = makeTrackMasterGraph(&reused, 0.5F);
    const std::uint64_t generation1 = engine.publishProcessorGraph(std::move(replacement), 64U);
    require(generation1 == 1U, "first live graph generation mismatch");
    require(engine.processorGraphPublicationPending(), "graph publication was not marked pending");
    require(engine.liveProcessorGraphGeneration() == 0U, "pending graph became live before callback boundary");
    require(reused.prepareCount == 1, "reused live processor was prepared during immutable rebuild");
    require(reused.resetCount == 1, "reused live processor was reset during immutable rebuild");
    require(engine.reclaimRetiredProcessorGraphs() == 0U, "old graph retired before callback adoption");

    bool rejectedSecondPending = false;
    try {
        engine.publishProcessorGraph(makeTrackMasterGraph(&reused, 0.25F), 64U);
    } catch (const std::logic_error&) {
        rejectedSecondPending = true;
    }
    require(rejectedSecondPending, "second pending graph publication was not rejected");

    engine.transport().seekSamples(0);
    gAllocationCount.store(0U, std::memory_order_relaxed);
    gTrackAllocations.store(true, std::memory_order_release);
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    gTrackAllocations.store(false, std::memory_order_release);
    require(gAllocationCount.load(std::memory_order_acquire) == 0U,
            "heap allocation occurred while adopting live processor graph");
    require(engine.liveProcessorGraphGeneration() == generation1, "pending graph not adopted at callback boundary");
    require(!engine.processorGraphPublicationPending(), "pending graph flag remained set after adoption");
    for (std::uint32_t i = 0U; i < frames; ++i)
        require(std::abs(outL[i] - 0.5F) < 1.0e-6F, "replacement graph route gain mismatch");
    require(engine.reclaimRetiredProcessorGraphs() == 1U, "retired predecessor graph was not reclaimable");

    auto insertedGraph = makeTrackMasterGraph(&newlyInserted, 1.0F);
    const std::uint64_t generation2 = engine.publishProcessorGraph(std::move(insertedGraph), 64U);
    require(newlyInserted.prepareCount == 1, "new processor was not prepared on control thread");
    require(newlyInserted.resetCount == 1, "new processor was not reset during first prepare");
    engine.transport().seekSamples(0);
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    require(engine.liveProcessorGraphGeneration() == generation2, "inserted processor graph did not become live");
    for (std::uint32_t i = 0U; i < frames; ++i)
        require(std::abs(outL[i] - 2.0F) < 1.0e-6F, "new live processor output mismatch");
    require(engine.reclaimRetiredProcessorGraphs() == 1U, "replaced owned graph was not reclaimed");

    const std::uint64_t generation3 = engine.publishProcessorGraph(nullptr, 64U);
    engine.transport().seekSamples(0);
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    require(engine.liveProcessorGraphGeneration() == generation3, "direct-mix publication generation mismatch");
    require(engine.processorGraph() == nullptr, "processor graph detach did not reach live state");
    for (std::uint32_t i = 0U; i < frames; ++i)
        require(std::abs(outL[i] - 1.0F) < 1.0e-6F, "direct-mix output mismatch after live graph detach");
    require(engine.reclaimRetiredProcessorGraphs() == 1U, "detached graph was not reclaimed");

    // The initial graph is intentionally externally owned to prove the legacy 0.7 API
    // can be replaced live without transferring ownership into AudioEngine.
    initialOwned.reset();
}

void testConcurrentLiveGraphPublicationStress() {
    constexpr std::uint32_t frames = 16U;
    constexpr int publications = 200;
    GeneratorProcessor generatorA;
    GeneratorProcessor generatorB;

    auto initialOwned = makeTrackMasterGraph(&generatorA, 1.0F);
    silveton::AudioEngine engine;
    engine.setProcessorGraph(initialOwned.get(), 64U);
    engine.prepare({48000.0, frames, 0U, 2U});

    std::atomic<bool> stop {false};
    std::atomic<bool> audioFailed {false};
    std::atomic<std::uint64_t> callbacks {0U};

    std::thread audioThread([&]() {
        std::array<float, frames> outL {};
        std::array<float, frames> outR {};
        float* outputs[2] {outL.data(), outR.data()};
        while (!stop.load(std::memory_order_acquire)) {
            engine.processAudio(nullptr, outputs, 0U, 2U, frames);
            for (std::uint32_t i = 0U; i < frames; ++i) {
                if (!std::isfinite(outL[i]) || !std::isfinite(outR[i]) ||
                    std::abs(outL[i] - 0.25F) > 1.0e-6F ||
                    std::abs(outR[i] + 0.25F) > 1.0e-6F) {
                    audioFailed.store(true, std::memory_order_release);
                    stop.store(true, std::memory_order_release);
                    break;
                }
            }
            callbacks.fetch_add(1U, std::memory_order_relaxed);
        }
    });

    for (int i = 0; i < publications && !audioFailed.load(std::memory_order_acquire); ++i) {
        silveton::ITrackProcessor* processor = (i & 1) == 0
            ? static_cast<silveton::ITrackProcessor*>(&generatorB)
            : static_cast<silveton::ITrackProcessor*>(&generatorA);
        (void)engine.publishProcessorGraph(makeTrackMasterGraph(processor, 1.0F), 64U);
        while (engine.processorGraphPublicationPending() && !audioFailed.load(std::memory_order_acquire))
            std::this_thread::yield();
        (void)engine.reclaimRetiredProcessorGraphs();
    }

    stop.store(true, std::memory_order_release);
    audioThread.join();
    require(!audioFailed.load(std::memory_order_acquire),
            "concurrent graph publication produced invalid realtime output");
    require(callbacks.load(std::memory_order_acquire) > 0U,
            "concurrent graph publication stress did not execute audio callbacks");
    require(!engine.processorGraphPublicationPending(),
            "concurrent graph publication left a pending generation");
    (void)engine.reclaimRetiredProcessorGraphs();
}



void testLiveLatencyRefreshPublishesNewPdcPlan() {
    constexpr std::uint32_t frames = 16U;
    AdjustableLatencyProcessor processor;
    auto initialGraph = makeTrackMasterGraph(&processor, 1.0F);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(initialGraph.get(), 512U);
    engine.prepare({48000.0, frames, 0U, 2U});
    require(processor.prepareCount == 1 && processor.resetCount == 1,
            "initial latency processor lifecycle count is wrong");
    require(engine.processorGraph()->nodeOutputLatency(0U) == 0U,
            "initial processor latency plan is wrong");

    processor.setLatency(128U);
    const std::uint64_t generation = engine.publishProcessorGraphLatencyRefresh();
    require(engine.processorGraphPublicationPending(),
            "latency refresh was not published as a pending immutable graph");
    require(processor.prepareCount == 1 && processor.resetCount == 1,
            "latency refresh re-prepared or reset a live processor");

    std::array<float, frames> outL {}, outR {};
    float* outputs[2] {outL.data(), outR.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    require(engine.liveProcessorGraphGeneration() == generation,
            "latency refresh generation did not become live at block boundary");
    require(engine.processorGraph()->nodeOutputLatency(0U) == 128U,
            "new latency was not reflected in the live PDC graph");
    require(processor.prepareCount == 1 && processor.resetCount == 1,
            "live latency refresh disturbed processor lifecycle state");
    require(engine.reclaimRetiredProcessorGraphs() == 1U,
            "previous latency graph was not reclaimable");
}

void testProjectMixerRoutesThroughAudioEngine() {
    constexpr std::uint32_t frames = 16U;

    silveton::Project project;
    silveton::ProjectTrack trackState;
    trackState.name = "Track";
    trackState.outputBus = 0;
    trackState.sends.push_back({1, -6.0205999F, true});
    project.tracks.push_back(trackState);

    silveton::ProjectBus group;
    group.name = "Group";
    group.gainDb = -6.0205999F;
    group.outputBus = -1;
    project.buses.push_back(group);

    silveton::ProjectBus fx;
    fx.name = "FX";
    fx.kind = silveton::ProjectBusKind::FxReturn;
    fx.outputBus = -1;
    project.buses.push_back(fx);

    NullFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(project);
    auto graph = silveton::MixerRoutingBuilder::build(project, rack);

    silveton::AudioBuffer audio(2U, frames);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        audio.sample(0U, i) = 1.0F;
        audio.sample(1U, i) = 1.0F;
    }

    silveton::AudioEngine engine;
    silveton::TimelineTrack timeline;
    timeline.source = &audio;
    timeline.gainDb = 0.0F;
    timeline.pan = 0.0F;
    engine.addTrack(timeline);
    engine.setProcessorGraph(graph.get(), 64U);
    engine.prepare({48000.0, frames, 0U, 2U});
    engine.transport().play();

    std::array<float, frames> outL {}, outR {};
    float* outputs[2] {outL.data(), outR.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    for (std::uint32_t i = 0U; i < frames; ++i)
        require(std::abs(outL[i] - 1.0F) < 2.0e-5F && std::abs(outR[i] - 1.0F) < 2.0e-5F,
                "AudioEngine did not render group + FX send mixer routing");

    project.buses[0].mute = true;
    const std::uint64_t generation = engine.publishProcessorGraph(
        silveton::MixerRoutingBuilder::build(project, rack), 64U);
    engine.transport().seekSamples(0);
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    require(engine.liveProcessorGraphGeneration() == generation,
            "live mixer routing change did not become active at block boundary");
    for (std::uint32_t i = 0U; i < frames; ++i)
        require(std::abs(outL[i] - 0.5F) < 2.0e-5F && std::abs(outR[i] - 0.5F) < 2.0e-5F,
                "live bus mute did not preserve only the FX send path");
    require(engine.reclaimRetiredProcessorGraphs() == 1U,
            "old mixer routing graph was not reclaimable after live change");
}


void testPrePostFaderAndMixerAutomation() {
    constexpr std::uint32_t frames = 8U;
    constexpr float minus6 = -6.0205999F;

    silveton::Project project;
    silveton::ProjectTrack track;
    track.name = "Automated Track";
    track.outputBus = 0; // muted group keeps the direct path out of the expected sum
    track.gainDb = 0.0F;
    track.gainAutomationMode = silveton::AutomationMode::Read;
    track.gainAutomationDb.add(0, 0.0F);
    track.gainAutomationDb.add(7, minus6);
    track.muteAutomationMode = silveton::AutomationMode::Read;
    track.muteAutomation.add(4, 1.0F);
    track.muteAutomation.add(6, 0.0F);

    silveton::ProjectSend pre;
    pre.destinationBus = 1;
    pre.preFader = true;
    pre.gainAutomationMode = silveton::AutomationMode::Read;
    pre.gainAutomationDb.add(0, 0.0F);
    pre.gainAutomationDb.add(7, minus6);
    pre.enabledAutomationMode = silveton::AutomationMode::Read;
    pre.enabledAutomation.add(2, 0.0F);
    pre.enabledAutomation.add(5, 1.0F);
    track.sends.push_back(pre);

    silveton::ProjectSend post;
    post.destinationBus = 2;
    post.preFader = false;
    track.sends.push_back(post);
    project.tracks.push_back(track);

    silveton::ProjectBus mutedMain;
    mutedMain.name = "Muted Main Group";
    mutedMain.mute = true;
    project.buses.push_back(mutedMain);

    silveton::ProjectBus preReturn;
    preReturn.name = "Pre Return";
    preReturn.kind = silveton::ProjectBusKind::FxReturn;
    preReturn.muteAutomationMode = silveton::AutomationMode::Read;
    preReturn.muteAutomation.add(6, 1.0F);
    preReturn.muteAutomation.add(7, 0.0F);
    project.buses.push_back(preReturn);

    silveton::ProjectBus postReturn;
    postReturn.name = "Post Return";
    postReturn.kind = silveton::ProjectBusKind::FxReturn;
    postReturn.gainAutomationMode = silveton::AutomationMode::Read;
    postReturn.gainAutomationDb.add(0, 0.0F);
    postReturn.gainAutomationDb.add(7, minus6);
    project.buses.push_back(postReturn);

    project.masterFaderAutomationMode = silveton::AutomationMode::Read;
    project.masterFaderAutomationDb.add(0, 0.0F);
    project.masterFaderAutomationDb.add(7, minus6);

    NullFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(project);
    auto graph = silveton::MixerRoutingBuilder::build(project, rack);
    graph->prepare(48000.0, frames, 64U);
    // Editing the project after publication must not mutate the live graph's
    // automation snapshots.
    project.tracks[0].gainAutomationDb.add(0, -48.0F);
    project.tracks[0].sends[0].gainAutomationDb.add(0, -48.0F);
    project.buses[2].gainAutomationDb.add(0, -48.0F);
    project.masterFaderAutomationDb.add(0, -48.0F);

    std::array<float, frames> oneL {}, oneR {}, masterL {}, masterR {};
    oneL.fill(1.0F);
    oneR.fill(1.0F);
    const auto layout = silveton::MixerRoutingBuilder::layout(project);
    std::vector<silveton::ConstStereoBus> sources(layout.nodeCount());
    sources[layout.trackNode(0U)] = {oneL.data(), oneR.data()};
    silveton::ProcessorContext context;
    context.frames = frames;
    context.sampleRate = 48000.0;
    context.projectSample = 0;
    context.playing = true;
    graph->process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, frames, context);

    for (std::uint32_t i = 0U; i < frames; ++i) {
        const double t = static_cast<double>(i) / 7.0;
        const double automatedDb = static_cast<double>(minus6) * t;
        const double trackGain = silveton::MixMath::dbToLinear(automatedDb);
        const double preGain = silveton::MixMath::dbToLinear(automatedDb);
        const double busGain = silveton::MixMath::dbToLinear(automatedDb);
        const double masterGain = silveton::MixMath::dbToLinear(automatedDb);
        const bool trackMuted = i >= 4U && i < 6U;
        const bool preEnabled = i < 2U || i >= 5U;
        const bool preBusMuted = i == 6U;
        const double prePath = (preEnabled && !preBusMuted) ? preGain : 0.0;
        const double postPath = trackMuted ? 0.0 : trackGain * busGain;
        const float expected = static_cast<float>((prePath + postPath) * masterGain);
        require(std::abs(masterL[i] - expected) < 3.0e-5F,
                "pre/post-fader mixer automation left mismatch");
        require(std::abs(masterR[i] - expected) < 3.0e-5F,
                "pre/post-fader mixer automation right mismatch");
    }

    gAllocationCount.store(0U, std::memory_order_relaxed);
    gTrackAllocations.store(true, std::memory_order_release);
    for (int n = 0; n < 128; ++n) {
        graph->process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, frames, context);
    }
    gTrackAllocations.store(false, std::memory_order_release);
    require(gAllocationCount.load(std::memory_order_acquire) == 0U,
            "mixer automation allocated on realtime graph path");
}

void testProjectPanAutomationThroughRuntimeCoordinator() {
    constexpr std::uint32_t frames = 8U;
    silveton::Project project;
    silveton::ProjectTrack track;
    track.name = "Mono Pan";
    track.panAutomationMode = silveton::AutomationMode::Read;
    track.panAutomation.add(0, -1.0F);
    track.panAutomation.add(7, 1.0F);
    project.tracks.push_back(track);

    NullFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(project);

    silveton::AudioBuffer mono(1U, frames);
    for (std::uint32_t i = 0U; i < frames; ++i) mono.sample(0U, i) = 1.0F;

    silveton::AudioEngine engine;
    silveton::TimelineTrack timeline;
    timeline.source = &mono;
    engine.addTrack(timeline);
    engine.prepare({48000.0, frames, 0U, 2U});
    silveton::MixerRuntimeCoordinator coordinator(project, rack, engine, 64U);
    const auto generation = coordinator.publishProjectRouting();
    require(generation != 0U, "mixer runtime did not publish project automation graph");
    // The voice plan has already snapshotted this lane. A control-side edit now
    // must not change the pending/live audio plan until the next publication.
    project.tracks[0].panAutomation.add(0, 1.0F);
    engine.transport().play();

    std::array<float, frames> outL {}, outR {};
    float* outputs[2] {outL.data(), outR.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    require(engine.liveProcessorGraphGeneration() == generation,
            "project automation graph was not adopted at block boundary");
    require(std::abs(outL[0] - 1.0F) < 1.0e-6F && std::abs(outR[0]) < 1.0e-6F,
            "track pan automation did not start hard left");
    require(std::abs(outL[7]) < 1.0e-6F && std::abs(outR[7] - 1.0F) < 1.0e-6F,
            "track pan automation did not end hard right");
}

class ParallelProbeProcessor final : public silveton::ITrackProcessor {
public:
    ParallelProbeProcessor(std::atomic<int>& active,
                           std::atomic<int>& maxActive,
                           std::atomic<int>& completed)
        : active_(active), maxActive_(maxActive), completed_(completed) {}

    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }

    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {
        const int now = active_.fetch_add(1, std::memory_order_acq_rel) + 1;
        int observed = maxActive_.load(std::memory_order_relaxed);
        while (observed < now &&
               !maxActive_.compare_exchange_weak(observed, now, std::memory_order_relaxed)) {}

        // Hold the first branch briefly so an awakened helper has a deterministic
        // opportunity to enter the second independent branch. The loop is bounded.
        for (int spin = 0; spin < 5000000 && active_.load(std::memory_order_acquire) < 2; ++spin) {
#if defined(__i386__) || defined(__x86_64__)
            __builtin_ia32_pause();
#else
            std::atomic_signal_fence(std::memory_order_seq_cst);
#endif
        }
        active_.fetch_sub(1, std::memory_order_acq_rel);
        completed_.fetch_add(1, std::memory_order_release);
    }

private:
    std::atomic<int>& active_;
    std::atomic<int>& maxActive_;
    std::atomic<int>& completed_;
};

class DependencyProbeProcessor final : public silveton::ITrackProcessor {
public:
    explicit DependencyProbeProcessor(std::atomic<int>& completed) : completed_(completed) {}
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {
        sawAllDependencies = completed_.load(std::memory_order_acquire) == 2;
    }
    bool sawAllDependencies {false};
private:
    std::atomic<int>& completed_;
};

void testParallelIndependentGraphBranches() {
    constexpr std::uint32_t frames = 32U;
    std::atomic<int> active {0};
    std::atomic<int> maxActive {0};
    std::atomic<int> completed {0};
    ParallelProbeProcessor leftBranch(active, maxActive, completed);
    ParallelProbeProcessor rightBranch(active, maxActive, completed);
    DependencyProbeProcessor masterProbe(completed);

    std::vector<silveton::GraphNodeDefinition> nodes(3U);
    nodes[0].processors.push_back({&leftBranch, {}});
    nodes[1].processors.push_back({&rightBranch, {}});
    nodes[2].processors.push_back({&masterProbe, {}});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U, 2U, 1.0F}, {1U, 2U, 1.0F}}, 2U);
    graph.prepare(48000.0, frames, 64U);
    require(graph.executionLayerCount() == 2U,
            "parallel graph did not produce two dependency layers");

    std::array<float, frames> src0L {}, src0R {}, src1L {}, src1R {};
    std::fill(src0L.begin(), src0L.end(), 0.25F);
    std::fill(src0R.begin(), src0R.end(), 0.25F);
    std::fill(src1L.begin(), src1L.end(), 0.5F);
    std::fill(src1R.begin(), src1R.end(), 0.5F);
    std::array<silveton::ConstStereoBus, 3U> sources {{
        {src0L.data(), src0R.data()},
        {src1L.data(), src1R.data()},
        {nullptr, nullptr}
    }};
    std::array<float, frames> outL {}, outR {};
    silveton::ProcessorContext context;
    context.sampleRate = 48000.0;
    context.frames = frames;
    graph.process(sources.data(), sources.size(), {outL.data(), outR.data()}, frames, context);

    require(completed.load(std::memory_order_acquire) == 2,
            "parallel graph did not execute both independent branches");
    require(masterProbe.sawAllDependencies,
            "dependent master node started before independent branches completed");
    for (std::uint32_t i = 0U; i < frames; ++i) {
        require(std::abs(outL[i] - 0.75F) < 1.0e-6F,
                "parallel graph changed left audio result");
        require(std::abs(outR[i] - 0.75F) < 1.0e-6F,
                "parallel graph changed right audio result");
    }
    if (graph.parallelWorkerCount() > 0U) {
        require(maxActive.load(std::memory_order_acquire) >= 2,
                "independent graph branches were not executed concurrently");
    }
}

void testParallelMatchesSerialReference() {
    constexpr std::uint32_t frames = 64U;
    CountingGainProcessor serialA(0.75F), serialB(1.25F), serialMaster(0.9F);
    CountingGainProcessor parallelA(0.75F), parallelB(1.25F), parallelMaster(0.9F);

    const auto build = [](silveton::ProcessorGraph& graph,
                          silveton::ITrackProcessor* a,
                          silveton::ITrackProcessor* b,
                          silveton::ITrackProcessor* master,
                          std::uint32_t workers) {
        graph.setParallelWorkerLimit(workers);
        std::vector<silveton::GraphNodeDefinition> nodes(3U);
        nodes[0].processors.push_back({a, {}});
        nodes[1].processors.push_back({b, {}});
        nodes[2].processors.push_back({master, {}});
        graph.configure(std::move(nodes), {{0U, 2U, 1.0F}, {1U, 2U, 1.0F}}, 2U);
        graph.prepare(48000.0, frames, 64U);
    };

    silveton::ProcessorGraph serialGraph, parallelGraph;
    build(serialGraph, &serialA, &serialB, &serialMaster, 0U);
    build(parallelGraph, &parallelA, &parallelB, &parallelMaster, 4U);
    require(serialGraph.parallelWorkerCount() == 0U,
            "worker limit zero did not force single-thread graph execution");
    require(parallelGraph.parallelWorkerLimit() == 4U,
            "parallel worker-limit configuration was not retained");

    auto cloned = parallelGraph.cloneDefinition();
    require(cloned->parallelWorkerLimit() == parallelGraph.parallelWorkerLimit(),
            "graph clone lost the multicore worker limit");

    std::array<float, frames> aL {}, aR {}, bL {}, bR {};
    std::array<float, frames> serialL {}, serialR {}, parallelL {}, parallelR {};
    std::array<silveton::ConstStereoBus, 3U> sources {{
        {aL.data(), aR.data()}, {bL.data(), bR.data()}, {nullptr, nullptr}
    }};
    silveton::ProcessorContext context;
    context.sampleRate = 48000.0;
    context.frames = frames;

    for (int block = 0; block < 200; ++block) {
        for (std::uint32_t i = 0U; i < frames; ++i) {
            const float x = static_cast<float>(((block * 17 + static_cast<int>(i) * 13) % 101) - 50) / 50.0F;
            const float y = static_cast<float>(((block * 7 + static_cast<int>(i) * 19) % 89) - 44) / 44.0F;
            aL[i] = x; aR[i] = -0.5F * x;
            bL[i] = 0.25F * y; bR[i] = y;
        }
        context.projectSample = static_cast<std::int64_t>(block) * frames;
        serialGraph.process(sources.data(), sources.size(), {serialL.data(), serialR.data()}, frames, context);
        parallelGraph.process(sources.data(), sources.size(), {parallelL.data(), parallelR.data()}, frames, context);
        for (std::uint32_t i = 0U; i < frames; ++i) {
            require(std::abs(serialL[i] - parallelL[i]) < 1.0e-7F,
                    "multicore graph left output differs from deterministic serial reference");
            require(std::abs(serialR[i] - parallelR[i]) < 1.0e-7F,
                    "multicore graph right output differs from deterministic serial reference");
        }
    }
}

void testGraphCapacityCovers256TracksPlusMaster() {
    constexpr std::size_t nodesNeeded = 257U;
    std::vector<silveton::GraphNodeDefinition> nodes(nodesNeeded);
    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {}, 256U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(&graph, 64U);
    engine.prepare({48000.0, 16U, 0U, 2U});
    require(graph.nodeCount() == nodesNeeded,
            "ProcessorGraph capacity does not cover 256 tracks plus master node");
}
}

void* operator new(std::size_t size) {
    if (gTrackAllocations.load(std::memory_order_relaxed))
        gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}

void* operator new[](std::size_t size) {
    if (gTrackAllocations.load(std::memory_order_relaxed))
        gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}

void* operator new(std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackAllocations.load(std::memory_order_relaxed))
        gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    return std::malloc(size);
}

void* operator new[](std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackAllocations.load(std::memory_order_relaxed))
        gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    return std::malloc(size);
}

void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }
void operator delete(void* p, const std::nothrow_t&) noexcept { std::free(p); }
void operator delete[](void* p, const std::nothrow_t&) noexcept { std::free(p); }

int main() {
    try {
        testAudioEngineGraphPdcAndRealtimeSafety();
        testGraphRunsWhileTransportStoppedAndReceivesContext();
        testLiveImmutableGraphPublicationAndReclamation();
        testConcurrentLiveGraphPublicationStress();
        testGraphCapacityCovers256TracksPlusMaster();
        testParallelIndependentGraphBranches();
        testParallelMatchesSerialReference();
        testProjectMixerRoutesThroughAudioEngine();
        testPrePostFaderAndMixerAutomation();
        testProjectPanAutomationThroughRuntimeCoordinator();
        testLiveLatencyRefreshPublishesNewPdcPlan();
        std::cout << "PASS: ProcessorGraph executes in real AudioEngine callback with PDC\n";
        std::cout << "PASS: ProcessorGraph callback path performs zero heap allocations\n";
        std::cout << "PASS: stopped-transport instrument processing + ProcessorContext tempo/sample state\n";
        std::cout << "PASS: live immutable graph publication/reclamation at callback boundary\n";
        std::cout << "PASS: reused processors are not re-prepared/reset during live graph rebuild\n";
        std::cout << "PASS: 200 concurrent control/audio graph publications completed safely\n";
        std::cout << "PASS: graph capacity covers 256 track nodes plus master\n";
        std::cout << "PASS: independent graph branches execute concurrently and dependency layers stay ordered\n";
        std::cout << "PASS: multicore graph is sample-identical to forced single-thread reference across 200 blocks\n";
        std::cout << "PASS: project mixer group/FX routing executes in the real AudioEngine and swaps live\n";
        std::cout << "PASS: real pre/post-fader sends + track/bus/send/master automation\n";
        std::cout << "PASS: project pan automation reaches the real AudioEngine through mixer runtime\n";
        std::cout << "PASS: mixer automation graph path performs zero heap allocations\n";
        std::cout << "PASS: plug-in latency changes publish a new PDC plan without resetting the live processor\n";
        return 0;
    } catch (const std::exception& e) {
        gTrackAllocations.store(false, std::memory_order_release);
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
