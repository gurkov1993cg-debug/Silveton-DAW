// A device block that is not a divisor of the disk cache page (44.1 kHz cards
// behind the 96 kHz bridge give 557/558-frame blocks) used to straddle two
// pages. The engine asked for the whole block from one page, failed, and
// silenced it: a dropout at every page boundary (crackle several times a second).
#include "silveton/AudioBuffer.h"
#include "silveton/AudioEngine.h"
#include "silveton/DiskStream.h"
#include "silveton/WavFile.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
std::string tempPath(const char* name) {
    const char* env = std::getenv("TMPDIR");
    std::string base = (env != nullptr && *env != '\0') ? std::string(env) : std::string("/tmp");
    if (!base.empty() && base.back() != '/') base += '/';
    return base + name;
}

struct Result { std::size_t zeroFrames {0U}; std::uint64_t underflows {0U}; };

Result play(const std::string& path, std::uint32_t cacheFrames, std::uint32_t blockSize, std::size_t blocks) {
    using namespace silveton;
    DiskStreamManager streams(2U);
    auto& source = streams.addSource(path, cacheFrames);
    streams.start();
    require(streams.prime(0U, 5000U), "disk stream did not prime");
    AudioEngine engine;
    engine.prepare({48000.0, 1024U, 0U, 2U});
    TimelineTrack track;
    track.diskSource = &source;
    engine.addTrack(track);
    engine.transport().play();
    std::vector<float> left(blockSize), right(blockSize);
    Result result;
    for (std::size_t b = 0U; b < blocks; ++b) {
        float* out[2] {left.data(), right.data()};
        engine.processAudio(nullptr, out, 0U, 2U, blockSize);
        if (b >= 1U)   // the very first block may include the engine's own start-up
            for (std::uint32_t i = 0U; i < blockSize; ++i)
                if (left[i] == 0.0F && right[i] == 0.0F) ++result.zeroFrames;
        // a real device callback comes every few ms: give the streaming thread time to prefetch
        std::this_thread::sleep_for(std::chrono::milliseconds(4));
    }
    engine.transport().stop();
    streams.stop();
    result.underflows = source.status().underflowBlocks;
    return result;
}
} // namespace

int main() {
    using namespace silveton;
    try {
        const std::string path = tempPath("silveton_page_boundary.wav");
        std::remove(path.c_str());
        constexpr std::size_t frames = 48000U;
        AudioBuffer audio(2U, frames);
        for (std::size_t i = 0U; i < frames; ++i) { audio.sample(0U, i) = 0.5F; audio.sample(1U, i) = 0.5F; }
        WavFile::writeFloat32(path, 48000U, audio);

        // 557 frames per block over 2048-frame pages: a block crosses a boundary often.
        const Result odd = play(path, 2048U, 557U, 60U);
        require(odd.zeroFrames == 0U, "a block that crosses a disk-cache page boundary was silenced (dropout)");
        require(odd.underflows == 0U, "disk playback reported underflows at page boundaries");
        // 512 over 4096 aligns by luck; must still be clean.
        const Result even = play(path, 4096U, 512U, 60U);
        require(even.zeroFrames == 0U && even.underflows == 0U, "aligned block sizes are no longer clean");
        std::remove(path.c_str());
        std::cout << "disk page boundary tests passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAILED: " << e.what() << '\n';
        return 1;
    }
}
