// Tone Editor tests: pitch search, tone blocks, every kind of change, time bend, MIDI, saving.
// A made-up "voice" is used: a row of harmonics (so the waveform is truly periodic) shaped by three
// formants, with a little breath noise. Checks measure the result by running the same analysis again.
#include "silveton/DawCore.h"
#include "silveton/ProjectMediaRelinker.h"
#include "silveton/ToneEdit.h"
#include "silveton/ToneProject.h"
#include "silveton/WavFile.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <complex>
#include <cstdio>
#include <dirent.h>
#include <fstream>
#include <sys/stat.h>
#include <unistd.h>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>

using namespace silveton;

namespace {
void require(bool c, const std::string& m) { if (!c) throw std::runtime_error(m); }
int passed = 0;
void pass(const char* n) { ++passed; std::cout << "PASS: " << n << '\n'; }

constexpr double kPi = 3.14159265358979323846;
double hzOfMidi(double m) { return 440.0 * std::pow(2.0, (m - 69.0) / 12.0); }

struct Note {
    double start, end, midi;
    double vibratoCents {0.0};
    double vibratoHz {5.5};
    double detuneCents {0.0};
};

AudioBuffer makeVoice(double rate, const std::vector<Note>& notes, double seconds, double f1 = 700.0, bool stereo = false) {
    const std::size_t n = static_cast<std::size_t>(seconds * rate);
    AudioBuffer out(stereo ? 2U : 1U, n);
    std::mt19937 rng(7);
    std::normal_distribution<double> noise(0.0, 1.0);
    const double formants[3] = {f1, 1220.0, 2600.0}, widths[3] = {110.0, 90.0, 160.0}, gains[3] = {1.0, 0.6, 0.35};
    for (const Note& note : notes) {
        const std::size_t a = static_cast<std::size_t>(note.start * rate), b = std::min(n, static_cast<std::size_t>(note.end * rate));
        double phase = 0.0;
        for (std::size_t i = a; i < b; ++i) {
            const double t = static_cast<double>(i) / rate - note.start;
            const double cents = note.detuneCents + note.vibratoCents * std::sin(2.0 * kPi * note.vibratoHz * t);
            const double f0 = hzOfMidi(note.midi) * std::pow(2.0, cents / 1200.0);
            phase += f0 / rate;
            double v = 0.0;
            for (int k = 1; k * f0 < 7000.0 && k < 60; ++k) {
                const double f = k * f0;
                double env = 0.12 / k;
                for (int q = 0; q < 3; ++q) { const double d = (f - formants[q]) / widths[q]; env += gains[q] / (1.0 + d * d); }
                v += env * std::sin(2.0 * kPi * k * phase);
            }
            // loudness: short fade in and out
            const double len = note.end - note.start;
            const double fade = std::min({1.0, t / 0.02, (len - t) / 0.03});
            const float s = static_cast<float>(0.12 * v * std::max(0.0, fade) + 0.0007 * noise(rng));
            out.sample(0, i) += s;
            if (stereo) out.sample(1, i) += s * 0.8F;
        }
    }
    return out;
}

std::vector<Note> threeNotes() {
    return {
        {0.20, 0.80, 57.0},                     // A3
        {0.85, 1.50, 60.0},                     // C4
        {1.55, 2.40, 64.0, 40.0, 5.5},          // E4 with vibrato
    };
}

ToneAnalysis analyse(const AudioBuffer& a, double rate) {
    ToneAnalysisOptions o;
    return ToneAnalyzer::analyze(a, rate, o);
}

double blockMidiNear(const ToneAnalysis& an, double seconds) {
    const std::int64_t s = static_cast<std::int64_t>(seconds * an.sampleRate);
    for (const auto& b : an.initial.blocks) if (s >= b.start && s < b.end) return static_cast<double>(b.pitch);
    return -1.0;
}

double rms(const AudioBuffer& a, std::size_t from, std::size_t to) {
    double e = 0.0;
    for (std::size_t i = from; i < to; ++i) e += static_cast<double>(a.sample(0, i)) * static_cast<double>(a.sample(0, i));
    return std::sqrt(e / static_cast<double>(std::max<std::size_t>(1U, to - from)));
}

// ------------------------------------------------------------------ tiny FFT --
void fftInPlace(std::vector<std::complex<double>>& a) {
    const std::size_t n = a.size();
    for (std::size_t i = 1U, j = 0U; i < n; ++i) {
        std::size_t bit = n >> 1U;
        for (; j & bit; bit >>= 1U) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (std::size_t len = 2U; len <= n; len <<= 1U) {
        const double ang = -2.0 * kPi / static_cast<double>(len);
        const std::complex<double> wl(std::cos(ang), std::sin(ang));
        for (std::size_t i = 0U; i < n; i += len) {
            std::complex<double> w(1.0, 0.0);
            for (std::size_t k = 0U; k < len / 2U; ++k) {
                const auto u = a[i + k], v = a[i + k + len / 2U] * w;
                a[i + k] = u + v; a[i + k + len / 2U] = u - v; w *= wl;
            }
        }
    }
}

// Position (Hz) of the strongest part of the smoothed spectrum between lo and hi.
double envelopePeak(const AudioBuffer& a, double rate, double fromSec, double toSec, double lo, double hi) {
    const std::size_t N = 16384;
    std::vector<std::complex<double>> buf(N);
    const std::size_t start = static_cast<std::size_t>(fromSec * rate);
    const std::size_t len = std::min<std::size_t>(N, static_cast<std::size_t>((toSec - fromSec) * rate));
    for (std::size_t i = 0U; i < len; ++i) buf[i] = a.sample(0, start + i) * (0.5 - 0.5 * std::cos(2.0 * kPi * static_cast<double>(i) / static_cast<double>(len - 1U)));
    fftInPlace(buf);
    const double binHz = rate / static_cast<double>(N);
    std::vector<double> mag(N / 2U);
    for (std::size_t k = 0U; k < mag.size(); ++k) mag[k] = std::abs(buf[k]);
    const std::size_t smooth = static_cast<std::size_t>(220.0 / binHz);
    double best = 0.0, bestHz = 0.0;
    for (std::size_t k = static_cast<std::size_t>(lo / binHz); k < static_cast<std::size_t>(hi / binHz); ++k) {
        double sum = 0.0;
        for (std::size_t j = k - smooth; j <= k + smooth; ++j) sum += mag[j] * mag[j];
        if (sum > best) { best = sum; bestHz = static_cast<double>(k) * binHz; }
    }
    return bestHz;
}

// ------------------------------------------------------------------- tests --
void testScales() {
    ToneScale major; major.kind = ToneScaleKind::Major; major.root = 2;   // D major: D E F# G A B C#
    require(major.contains(2) && major.contains(4) && major.contains(6) && !major.contains(5) && !major.contains(0), "D major notes");
    require(std::abs(major.nearest(65.2) - 66.0) < 1e-9, "F -> F# in D major (65.2 closer to 66 than 64? 65.2: 64.. 66)");
    require(std::abs(major.nearest(64.4) - 64.0) < 1e-9, "E stays");
    ToneScale chroma;
    require(std::abs(chroma.nearest(60.49) - 60.0) < 1e-9 && std::abs(chroma.nearest(60.51) - 61.0) < 1e-9, "chromatic rounding");
    require(major.name() == "D Major", "scale name");
    pass("scales");
}

void testAnalysis(double rate) {
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const auto t0 = std::chrono::steady_clock::now();
    const ToneAnalysis an = analyse(voice, rate);
    const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::printf("  analysis of 2.6 s at %.0f Hz took %.2f s, %zu blocks\n", rate, seconds, an.initial.blocks.size());
    for (const auto& b : an.initial.blocks) std::printf("   block %u  %.3f..%.3f s  pitch %.3f  level %.1f dB\n", b.id,
        static_cast<double>(b.start) / rate, static_cast<double>(b.end) / rate, static_cast<double>(b.pitch), static_cast<double>(b.levelDb));
    require(an.initial.blocks.size() == 3U, "three notes found");
    const double expected[3] = {57.0, 60.0, 64.0};
    const double startAt[3] = {0.20, 0.85, 1.55};
    const double endAt[3] = {0.80, 1.50, 2.40};
    for (int i = 0; i < 3; ++i) {
        const auto& b = an.initial.blocks[static_cast<std::size_t>(i)];
        require(std::abs(static_cast<double>(b.pitch) - expected[i]) < 0.08, "block pitch within 8 cents");
        require(std::abs(static_cast<double>(b.start) / rate - startAt[i]) < 0.05, "block start close");
        require(std::abs(static_cast<double>(b.end) / rate - endAt[i]) < 0.05, "block end close");
    }
    // a silent file has no blocks
    AudioBuffer silent(1U, static_cast<std::size_t>(rate));
    require(analyse(silent, rate).initial.blocks.empty(), "silence has no blocks");
    pass("pitch search and tone blocks");
}

void testSameOutputWhenUntouched() {
    const double rate = 48000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const ToneAnalysis an = analyse(voice, rate);
    ToneEdit edit = an.initial;
    const AudioBuffer same = ToneRenderer::render(voice, an, edit);
    for (std::size_t i = 0U; i < voice.frames(); ++i) require(same.sample(0, i) == voice.sample(0, i), "untouched is identical");
    // a hair-thin change makes the renderer run through the whole block: it must still sound the same
    edit.blocks[1].formantCents = 0.05F;   // the renderer runs through the whole block
    const AudioBuffer tiny = ToneRenderer::render(voice, an, edit);
    double err = 0.0, sig = 0.0;
    for (std::size_t i = 0U; i < voice.frames(); ++i) {
        const double d = static_cast<double>(tiny.sample(0, i)) - static_cast<double>(voice.sample(0, i));
        err += d * d; sig += static_cast<double>(voice.sample(0, i)) * static_cast<double>(voice.sample(0, i));
    }
    const double snr = 10.0 * std::log10(sig / std::max(err, 1e-30));
    std::printf("  tiny change: signal-to-error %.1f dB\n", snr);
    require(snr > 24.0, "a hair-thin change keeps the sound (SNR > 24 dB)");
    // far from the changed block nothing moved
    for (std::size_t i = 0U; i < static_cast<std::size_t>(0.8 * rate); ++i) require(tiny.sample(0, i) == voice.sample(0, i), "outside the block is the original");
    pass("untouched sound stays");
}

void testShiftBlock(double rate) {
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const ToneAnalysis an = analyse(voice, rate);
    ToneEdit edit = an.initial;
    ToneEditing::setTargetPitch(edit, edit.blocks[1].id, 62.0);          // C4 -> D4
    const auto t0 = std::chrono::steady_clock::now();
    const AudioBuffer out = ToneRenderer::render(voice, an, edit);
    std::printf("  render took %.2f s\n", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
    require(out.frames() == voice.frames(), "same length");
    const ToneAnalysis after = analyse(out, rate);
    require(after.initial.blocks.size() == 3U, "still three blocks");
    require(std::abs(blockMidiNear(after, 1.2) - 62.0) < 0.06, "block moved up two semitones (6 cents)");
    require(std::abs(blockMidiNear(after, 0.5) - 57.0) < 0.05, "first block untouched");
    require(std::abs(blockMidiNear(after, 2.0) - 64.0) < 0.06, "third block untouched");
    for (std::size_t i = 0U; i < static_cast<std::size_t>(0.15 * rate); ++i) require(out.sample(0, i) == voice.sample(0, i), "before everything: original");
    // loudness stays about the same
    const double r0 = rms(voice, static_cast<std::size_t>(0.95 * rate), static_cast<std::size_t>(1.4 * rate));
    const double r1 = rms(out, static_cast<std::size_t>(0.95 * rate), static_cast<std::size_t>(1.4 * rate));
    require(std::abs(20.0 * std::log10(r1 / r0)) < 2.0, "loudness within 2 dB");
    pass("move a block");
}

void testLargeShifts() {
    const double rate = 96000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const ToneAnalysis an = analyse(voice, rate);
    for (const double semis : {-7.0, -3.0, 5.0, 12.0}) {
        ToneEdit edit = an.initial;
        ToneEditing::transpose(edit, {edit.blocks[0].id}, semis);
        const AudioBuffer out = ToneRenderer::render(voice, an, edit);
        const ToneAnalysis after = analyse(out, rate);
        const double got = blockMidiNear(after, 0.5);
        std::printf("  shift %+.0f st -> measured %+.3f st\n", semis, got - 57.0);
        require(std::abs(got - (57.0 + semis)) < 0.12, "large shift lands on the note");
    }
    pass("shifts from -7 to +12 semitones");
}

void testSnap() {
    const double rate = 48000.0;
    std::vector<Note> notes = {{0.2, 1.0, 57.0, 0.0, 5.5, 35.0}, {1.05, 1.9, 60.0, 0.0, 5.5, -28.0}};
    const AudioBuffer voice = makeVoice(rate, notes, 2.2);
    const ToneAnalysis an = analyse(voice, rate);
    require(an.initial.blocks.size() == 2U, "two blocks");
    require(std::abs(static_cast<double>(an.initial.blocks[0].pitch) - 57.35) < 0.06, "detuned note measured");
    ToneEdit edit = an.initial;
    ToneEditing::setSnap(edit, {}, 1.0F);
    const ToneAnalysis after = analyse(ToneRenderer::render(voice, an, edit), rate);
    require(std::abs(blockMidiNear(after, 0.6) - 57.0) < 0.05, "snapped to A");
    require(std::abs(blockMidiNear(after, 1.5) - 60.0) < 0.05, "snapped to C");
    // half way
    ToneEditing::setSnap(edit, {}, 0.5F);
    const ToneAnalysis half = analyse(ToneRenderer::render(voice, an, edit), rate);
    require(std::abs(blockMidiNear(half, 0.6) - 57.175) < 0.06, "half snap lands half way");
    // scale snap: C4 detuned toward C# but the scale is C major → C or D, never C#
    ToneEdit scaleEdit = an.initial;
    scaleEdit.scale.kind = ToneScaleKind::Major;
    scaleEdit.scale.root = 0;
    scaleEdit.snapToScale = true;
    ToneEditing::setTargetPitch(scaleEdit, scaleEdit.blocks[1].id, 60.9);   // free drag
    require(std::abs(toneBlockTargetPitch(scaleEdit.blocks[1], scaleEdit) - 60.9) < 1e-6, "free drag keeps the value");
    scaleEdit.blocks[1].moveCents = 90.0F; scaleEdit.blocks[1].snap = 1.0F;
    const double got = toneBlockTargetPitch(scaleEdit.blocks[1], scaleEdit);
    require(std::abs(got - 62.0) < 1e-6 || std::abs(got - 60.0) < 1e-6, "scale snap never lands on C#");
    pass("snap pitch");
}

double pitchSpreadCents(const ToneAnalysis& an, double from, double to) {
    const std::size_t a = static_cast<std::size_t>(from * an.sampleRate / static_cast<double>(an.frames.hop));
    const std::size_t b = static_cast<std::size_t>(to * an.sampleRate / static_cast<double>(an.frames.hop));
    std::vector<double> v;
    for (std::size_t i = a; i < b && i < an.frames.size(); ++i) if (an.frames.hz[i] > 0.0F) v.push_back(static_cast<double>(an.frames.midi[i]) * 100.0);
    require(v.size() > 10U, "enough pitch frames");
    double mean = 0.0; for (double x : v) mean += x; mean /= static_cast<double>(v.size());
    double var = 0.0; for (double x : v) var += (x - mean) * (x - mean);
    return std::sqrt(var / static_cast<double>(v.size()));
}

void testFlattenAndVibrato() {
    const double rate = 48000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const ToneAnalysis an = analyse(voice, rate);
    const double before = pitchSpreadCents(an, 1.7, 2.3);
    require(before > 20.0, "the source has vibrato");
    ToneEdit edit = an.initial;
    ToneEditing::setFlatten(edit, {edit.blocks[2].id}, 1.0F);
    const ToneAnalysis flat = analyse(ToneRenderer::render(voice, an, edit), rate);
    const double afterFlat = pitchSpreadCents(flat, 1.7, 2.3);
    std::printf("  wobble %.1f -> %.1f cents\n", before, afterFlat);
    require(afterFlat < 7.0, "flat pitch");
    require(std::abs(blockMidiNear(flat, 2.0) - 64.0) < 0.06, "pitch centre kept");
    ToneEditing::resetBlock(edit, edit.blocks[2].id);
    ToneEditing::setVibrato(edit, {edit.blocks[2].id}, 2.0F);
    const ToneAnalysis wide = analyse(ToneRenderer::render(voice, an, edit), rate);
    const double afterWide = pitchSpreadCents(wide, 1.7, 2.3);
    std::printf("  wobble x2: %.1f cents\n", afterWide);
    require(afterWide > before * 1.6, "bigger vibrato");
    pass("flatten and vibrato");
}

void testFormant() {
    const double rate = 48000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const ToneAnalysis an = analyse(voice, rate);
    const double original = envelopePeak(voice, rate, 0.30, 0.75, 450.0, 1100.0);
    ToneEdit edit = an.initial;
    ToneEditing::transpose(edit, {edit.blocks[0].id}, 4.0);
    const AudioBuffer shifted = ToneRenderer::render(voice, an, edit);
    const double kept = envelopePeak(shifted, rate, 0.30, 0.75, 450.0, 1100.0);
    ToneEditing::resetBlock(edit, edit.blocks[0].id);
    edit.blocks[0].formantCents = 400.0F;
    const AudioBuffer coloured = ToneRenderer::render(voice, an, edit);
    const double moved = envelopePeak(coloured, rate, 0.30, 0.75, 450.0, 1300.0);
    std::printf("  formant peak: original %.0f Hz, pitch +4 st %.0f Hz, colour +400 cents %.0f Hz\n", original, kept, moved);
    require(std::abs(kept - original) < 100.0, "formants stay when the pitch moves");
    require(moved > original * 1.12, "formant shift moves the colour up");
    const ToneAnalysis pitchCheck = analyse(coloured, rate);
    require(std::abs(blockMidiNear(pitchCheck, 0.5) - 57.0) < 0.07, "formant shift keeps the pitch");
    pass("formants");
}

void testGain() {
    const double rate = 48000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const ToneAnalysis an = analyse(voice, rate);
    ToneEdit edit = an.initial;
    edit.blocks[0].gainDb = -6.0F;
    const AudioBuffer out = ToneRenderer::render(voice, an, edit);
    const double a = rms(voice, static_cast<std::size_t>(0.3 * rate), static_cast<std::size_t>(0.7 * rate));
    const double b = rms(out, static_cast<std::size_t>(0.3 * rate), static_cast<std::size_t>(0.7 * rate));
    require(std::abs(b / a - 0.5012) < 0.03, "-6 dB");
    require(std::abs(rms(out, static_cast<std::size_t>(1.0 * rate), static_cast<std::size_t>(1.4 * rate)) / rms(voice, static_cast<std::size_t>(1.0 * rate), static_cast<std::size_t>(1.4 * rate)) - 1.0) < 1e-6,
            "other blocks untouched");
    pass("block loudness");
}

void testTimeBend() {
    const double rate = 48000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const ToneAnalysis an = analyse(voice, rate);
    ToneEdit edit = an.initial;
    const std::int64_t shift = static_cast<std::int64_t>(0.12 * rate);
    require(ToneEditing::setBlockTime(edit, edit.blocks[1].id, edit.blocks[1].start + shift, edit.blocks[1].end + shift,
                                      an.length, static_cast<std::int64_t>(0.05 * rate)), "time set");
    const AudioBuffer out = ToneRenderer::render(voice, an, edit);
    require(out.frames() == voice.frames(), "same length after bend");
    const ToneAnalysis after = analyse(out, rate);
    require(after.initial.blocks.size() == 3U, "three blocks after bend");
    const auto& moved = after.initial.blocks[1];
    std::printf("  moved block starts %.3f s (was %.3f)\n", static_cast<double>(moved.start) / rate, static_cast<double>(an.initial.blocks[1].start) / rate);
    require(std::abs(static_cast<double>(moved.start - an.initial.blocks[1].start) / rate - 0.12) < 0.03, "block moved 120 ms later");
    require(std::abs(static_cast<double>(moved.pitch) - 60.0) < 0.07, "pitch kept while moving in time");
    require(std::abs(static_cast<double>(after.initial.blocks[2].pitch) - 64.0) < 0.1, "third block fine");
    // block time map
    const ToneTimeMap map(edit.warp, an.length);
    require(std::abs(map.forward(static_cast<double>(edit.blocks[1].start)) - static_cast<double>(edit.blocks[1].start + shift)) < 1.0, "forward map");
    require(std::abs(map.inverse(map.forward(12345.0)) - 12345.0) < 1e-6, "inverse map");
    // snapping the timing to a grid
    ToneEditing::clearTiming(edit);
    const double grid = 0.25 * rate;
    ToneEditing::snapTiming(edit, {}, grid, 0.0, 1.0F, an.length, static_cast<std::int64_t>(0.05 * rate));
    const ToneTimeMap snapped(edit.warp, an.length);
    for (const auto& b : edit.blocks) {
        const double start = snapped.forward(static_cast<double>(b.start));
        const double line = std::floor(start / grid + 0.5) * grid;
        require(std::abs(start - line) < 2.0 || b.start < 10, "block start is on the grid");
    }
    const AudioBuffer outSnapped = ToneRenderer::render(voice, an, edit);
    require(outSnapped.frames() == voice.frames(), "snapped render length");
    pass("time bend and timing snap");
}

void testSplitGlue() {
    const double rate = 48000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const ToneAnalysis an = analyse(voice, rate);
    ToneEdit edit = an.initial;
    const auto id = edit.blocks[2].id;
    const std::int64_t mid = (edit.blocks[2].start + edit.blocks[2].end) / 2;
    const std::uint32_t left = ToneEditing::split(edit, an, id, mid);
    require(left == id && edit.blocks.size() == 4U, "split");
    require(edit.blocks[2].end == edit.blocks[3].start, "halves touch");
    require(ToneEditing::split(edit, an, id, edit.blocks[2].start + 5) == 0U, "no tiny pieces");
    require(ToneEditing::glue(edit, an, edit.blocks[2].id, edit.blocks[3].id) == id && edit.blocks.size() == 3U, "glue");
    require(std::abs(static_cast<double>(edit.blocks[2].pitch) - 64.0) < 0.1, "pitch after glue");
    require(ToneEditing::add(edit, an, edit.blocks[0].end + 10, edit.blocks[0].end + 40, 60.0) == 0U, "a block too short is refused");
    require(ToneEditing::remove(edit, edit.blocks[1].id) && edit.blocks.size() == 2U, "remove");
    const std::uint32_t added = ToneEditing::add(edit, an, an.initial.blocks[1].start, an.initial.blocks[1].end, 60.0);
    require(added != 0U && std::abs(static_cast<double>(edit.find(added)->pitch) - 60.0) < 0.07, "add finds the pitch");
    ToneEditing::resetAll(edit, an);
    require(edit.blocks.size() == 3U && !edit.anyChange(), "reset all");
    pass("split, glue, add, remove, reset");
}

void testMidi() {
    const double rate = 48000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const ToneAnalysis an = analyse(voice, rate);
    ToneEdit edit = an.initial;
    ToneMidiOptions o;
    const auto notes = ToneMidi::extract(an, edit, o);
    require(notes.size() == 3U && notes[0].pitch == 57 && notes[1].pitch == 60 && notes[2].pitch == 64, "note numbers");
    require(notes[0].velocity >= 30 && notes[0].velocity <= 127, "velocity");
    ToneEditing::transpose(edit, {edit.blocks[1].id}, 2.0);
    require(ToneMidi::extract(an, edit, o)[1].pitch == 62, "corrected pitch is used");
    o.useBend = true;
    const auto bent = ToneMidi::extract(an, edit, o);
    require(!bent[2].bend.empty(), "vibrato becomes pitch bend");
    pass("MIDI extraction");
}

void testSaving() {
    ToneEdit e;
    e.scale.kind = ToneScaleKind::Dorian; e.scale.root = 7; e.snapToScale = true; e.transitionMs = 42.5F; e.nextId = 9U;
    ToneBlock b; b.id = 3; b.start = 100; b.end = 5000; b.pitch = 61.234F; b.levelDb = -22.5F; b.moveCents = -35.5F; b.snap = 0.75F;
    b.flatten = 0.25F; b.vibrato = 1.5F; b.tiltCents = 12.0F; b.formantCents = -80.0F; b.gainDb = 2.5F; b.bypass = true;
    e.blocks.push_back(b);
    e.warp.push_back({1000, 1200});
    const auto lines = toneEditToLines(e);
    const ToneEdit back = toneEditFromLines(lines);
    require(back.blocks.size() == 1U && back.warp.size() == 1U, "counts");
    require(back.blocks[0].pitch == b.pitch && back.blocks[0].moveCents == b.moveCents && back.blocks[0].bypass && back.blocks[0].start == 100, "block fields");
    require(back.scale.kind == ToneScaleKind::Dorian && back.scale.root == 7 && back.snapToScale && back.transitionMs == 42.5F && back.nextId == 9U, "header");
    bool threw = false;
    try { (void)toneEditFromLines({"BLOCK\t1\t2"}); } catch (const std::exception&) { threw = true; }
    require(threw, "bad text is refused");
    pass("saving and loading");
}

void testDetectScale() {
    const double rate = 48000.0;
    // C major melody: C D E G A G E C
    std::vector<Note> notes;
    const double melody[] = {60, 62, 64, 67, 69, 67, 64, 60};
    double t = 0.1;
    for (double m : melody) { notes.push_back({t, t + 0.4, m}); t += 0.45; }
    const AudioBuffer voice = makeVoice(rate, notes, t + 0.1);
    const ToneAnalysis an = analyse(voice, rate);
    double coverage = 0.0;
    const ToneScale s = ToneEditing::detectScale(an.initial, &coverage);
    std::printf("  detected key: %s (%.0f %%)\n", s.name().c_str(), coverage);
    require(s.kind == ToneScaleKind::Major && s.root == 0 && coverage > 95.0, "C major found");
    pass("key detection");
}

void testStereoAndMismatch() {
    const double rate = 48000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6, 700.0, true);
    const ToneAnalysis an = analyse(voice, rate);
    ToneEdit edit = an.initial;
    ToneEditing::transpose(edit, {edit.blocks[0].id}, 3.0);
    const AudioBuffer out = ToneRenderer::render(voice, an, edit);
    require(out.channels() == 2U && out.frames() == voice.frames(), "stereo kept");
    double ratio = 0.0; int n = 0;
    for (std::size_t i = static_cast<std::size_t>(0.4 * rate); i < static_cast<std::size_t>(0.7 * rate); i += 7) {
        if (std::abs(out.sample(0, i)) > 0.05F) { ratio += static_cast<double>(out.sample(1, i) / out.sample(0, i)); ++n; }
    }
    require(n > 100 && std::abs(ratio / n - 0.8) < 0.01, "channels stay in proportion");
    AudioBuffer other(1U, 1000U);
    bool threw = false;
    try { (void)ToneRenderer::render(other, an, edit); } catch (const std::invalid_argument&) { threw = true; }
    require(threw, "analysis of other audio is refused");
    pass("stereo");
}

void testCancel() {
    const double rate = 48000.0;
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    std::atomic<bool> stop {true};
    const ToneAnalysis an = ToneAnalyzer::analyze(voice, rate, ToneAnalysisOptions {}, &stop);
    require(an.cancelled, "analysis can be stopped");
    pass("cancel");
}

void testBassAndHigh() {
    const double rate = 48000.0;
    // low male voice (E2 = 82 Hz) and high female voice (A5 = 880 Hz)
    for (const double midi : {40.0, 81.0}) {
        std::vector<Note> notes = {{0.2, 1.2, midi}};
        const AudioBuffer voice = makeVoice(rate, notes, 1.5);
        const ToneAnalysis an = analyse(voice, rate);
        require(an.initial.blocks.size() == 1U && std::abs(static_cast<double>(an.initial.blocks[0].pitch) - midi) < 0.08, "extreme voices measured");
        ToneEdit edit = an.initial;
        ToneEditing::transpose(edit, {}, 2.0);
        const ToneAnalysis after = analyse(ToneRenderer::render(voice, an, edit), rate);
        require(after.initial.blocks.size() == 1U && std::abs(static_cast<double>(after.initial.blocks[0].pitch) - (midi + 2.0)) < 0.1, "extreme voices moved");
    }
    pass("low and high voices");
}


// A temporary folder with plain system calls (the newer C++ file library is not on the macOS 10.13 target).
void removeFolder(const std::string& dir) {
    DIR* d = ::opendir(dir.c_str());
    if (d == nullptr) return;
    while (const dirent* entry = ::readdir(d)) {
        const std::string name = entry->d_name;
        if (name == "." || name == "..") continue;
        const std::string full = dir + "/" + name;
        struct stat info {};
        if (::stat(full.c_str(), &info) == 0 && S_ISDIR(info.st_mode)) removeFolder(full);
        else (void)::unlink(full.c_str());
    }
    ::closedir(d);
    (void)::rmdir(dir.c_str());
}

bool copyFileBytes(const std::string& from, const std::string& to) {
    std::ifstream in(from, std::ios::binary);
    std::ofstream out(to, std::ios::binary | std::ios::trunc);
    if (!in || !out) return false;
    out << in.rdbuf();
    return static_cast<bool>(out);
}

void testProjectLayer() {
    const double rate = 48000.0;
    const std::string dir = "/tmp/silveton_tone_project_test_" + std::to_string(static_cast<long long>(::getpid()));
    removeFolder(dir);
    require(::mkdir(dir.c_str(), 0755) == 0, "temporary folder made");
    const AudioBuffer voice = makeVoice(rate, threeNotes(), 2.6);
    const std::string original = dir + "/voice.wav";
    WavFile::writeFloat32(original, 48000U, voice);

    Project project;
    project.sampleRate = rate;
    ProjectTrack track;
    track.name = "Voice";
    ProjectAudioClip clip;
    clip.id = 7U;
    clip.audioPath = original;
    clip.timelineStartSample = 96000;
    clip.sourceStartSample = 0U;
    clip.lengthSamples = voice.frames();
    clip.sourceFrames = voice.frames();
    clip.sourceChannels = 1U;
    clip.sourceSampleRate = 48000U;
    clip.fadeInSamples = 480U;
    track.clips.push_back(clip);
    project.tracks.push_back(track);

    // first time: the clip's own sound
    ToneSource source = ToneProject::sourceFor(project, 0U, 7U);
    require(!source.fromRecord && source.path == original && source.length == voice.frames(), "first source is the clip sound");
    ToneEdit saved;
    require(!ToneProject::savedEdit(project, 0U, 7U, saved), "no edit saved yet");
    const AudioBuffer audio = ToneProject::readSource(source, rate);
    require(audio.frames() == voice.frames(), "source read at the project rate");
    const ToneAnalysis an = analyse(audio, rate);
    ToneEdit edit = an.initial;
    ToneEditing::transpose(edit, {edit.blocks.front().id}, 3.0);
    const AudioBuffer rendered = ToneRenderer::render(audio, an, edit);
    const std::string renderedPath = ToneProject::writeRendered(rendered, rate, source.path, dir);
    const Project before = project;
    ToneProject::commit(project, 0U, 7U, source, edit, renderedPath, rendered.frames(), 1U);
    const auto& c1 = project.tracks[0].clips[0];
    require(c1.audioPath == renderedPath && c1.lengthSamples == voice.frames() && c1.sourceStartSample == 0U, "clip relinked to the render");
    require(c1.timelineStartSample == 96000 && c1.fadeInSamples == 480U, "clip place and fades kept");
    require(ToneProject::find(project, renderedPath) != nullptr && project.toneRecords.size() == 1U, "record stored");
    require(before.toneRecords.empty() && before.tracks[0].clips[0].audioPath == original, "undo copy keeps the old state");

    // coming back: the original and the blocks are there again
    ToneSource again = ToneProject::sourceFor(project, 0U, 7U);
    require(again.fromRecord && again.path == original && again.length == voice.frames(), "second source is the original");
    ToneEdit back;
    require(ToneProject::savedEdit(project, 0U, 7U, back) && back.blocks.size() == edit.blocks.size(), "blocks come back");
    require(std::abs(static_cast<double>(back.blocks.front().moveCents) - 300.0) < 1.0, "block setting comes back");

    // saving and loading the project
    const std::string file = dir + "/test.svproj";
    project.save(file);
    const Project loaded = Project::load(file);
    require(loaded.toneRecords.size() == 1U, "record survives saving");
    require(loaded.toneRecords[0].renderedPath == renderedPath && loaded.toneRecords[0].originalPath == original, "record paths survive saving");
    ToneEdit fromFile;
    require(ToneProject::savedEdit(loaded, 0U, 7U, fromFile) && fromFile.blocks.size() == edit.blocks.size(), "edit survives saving");
    require(std::abs(static_cast<double>(fromFile.blocks.front().moveCents) - 300.0) < 1.0, "block setting survives saving");

    // second edit: the clip is trimmed first, the trim stays after the new render
    project.tracks[0].clips[0].sourceStartSample = 4800U;
    project.tracks[0].clips[0].lengthSamples = voice.frames() - 9600U;
    ToneEdit second = back;
    ToneEditing::setSnap(second, {}, 1.0F);
    const AudioBuffer rendered2 = ToneRenderer::render(audio, an, second);
    const std::string path2 = ToneProject::writeRendered(rendered2, rate, again.path, dir);
    ToneProject::commit(project, 0U, 7U, again, second, path2, rendered2.frames(), 1U);
    const auto& c2 = project.tracks[0].clips[0];
    require(c2.audioPath == path2 && c2.sourceStartSample == 4800U && c2.lengthSamples == voice.frames() - 9600U, "trim kept after a new render");
    require(project.toneRecords.size() == 1U && project.toneRecords[0].renderedPath == path2, "old record replaced");

    // a copy of the clip keeps the old record alive
    project.tracks[0].clips.push_back(project.tracks[0].clips[0]);
    project.tracks[0].clips.back().id = 8U;
    ToneEdit third = second;
    ToneEditing::setSnap(third, {}, 0.5F);
    const AudioBuffer rendered3 = ToneRenderer::render(audio, an, third);
    const std::string path3 = ToneProject::writeRendered(rendered3, rate, again.path, dir);
    ToneProject::commit(project, 0U, 7U, again, third, path3, rendered3.frames(), 1U);
    require(project.toneRecords.size() == 2U, "the copy still has its record");
    require(ToneProject::find(project, path2) != nullptr && ToneProject::find(project, path3) != nullptr, "both records found");

    // records of files nobody plays are dropped
    project.tracks[0].clips.pop_back();
    ToneProject::prune(project);
    require(project.toneRecords.size() == 1U && project.toneRecords[0].renderedPath == path3, "unused record dropped");

    // moving the media file keeps the record
    const std::string moved = dir + "/moved.wav";
    require(copyFileBytes(path3, moved), "media file copied");
    (void)ProjectMediaRelinker::relinkPath(project, path3, moved, true);
    require(project.toneRecords[0].renderedPath == moved && project.tracks[0].clips[0].audioPath == moved, "relink follows the record");

    bool refused = false;
    project.tracks[0].locked = true;
    try { ToneProject::commit(project, 0U, 7U, again, third, path3, rendered3.frames(), 1U); } catch (const std::exception&) { refused = true; }
    require(refused, "locked track refuses");
    removeFolder(dir);
    pass("project layer");
}

} // namespace

int main() {
    try {
        testScales();
        testAnalysis(48000.0);
        testAnalysis(96000.0);
        testAnalysis(44100.0);
        testSameOutputWhenUntouched();
        testShiftBlock(48000.0);
        testShiftBlock(96000.0);
        testLargeShifts();
        testSnap();
        testFlattenAndVibrato();
        testFormant();
        testGain();
        testTimeBend();
        testSplitGlue();
        testMidi();
        testSaving();
        testDetectScale();
        testStereoAndMismatch();
        testCancel();
        testBassAndHigh();
        testProjectLayer();
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
    std::cout << passed << " tone editor checks passed\n";
    return 0;
}
