#include "silveton/Arrangement.h"
#include "silveton/UiModel.h"

#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silveton;

namespace {
void require(bool c, const std::string& m) { if (!c) throw std::runtime_error(m); }
int passed = 0;
void pass(const char* n) { ++passed; std::cout << "PASS: " << n << '\n'; }

void testRows() {
    Project p;
    p.tracks.resize(4U);
    ProjectPluginSlot synth; synth.midiInputPort = 3;
    p.tracks[1].pluginSlots.push_back(synth);
    p.midiTracks.resize(2U);
    p.midiTracks[0].outputPort = 3;     // drives track 1
    p.midiTracks[1].outputPort = -1;
    const int f = FolderTools::addFolder(p, "Band");
    const int sub = FolderTools::addFolder(p, "Keys", f);
    p.tracks[1].folder = sub;
    p.tracks[2].folder = f;
    auto rows = buildArrangeRows(p);
    // Band, Keys, T1, M0(linked), T2, T0, T3, M1
    require(rows.size() == 8U, "row count " + std::to_string(rows.size()));
    require(rows[0].kind == ArrangeRowKind::Folder && rows[0].depth == 0, "folder row");
    require(rows[1].kind == ArrangeRowKind::Folder && rows[1].depth == 1, "sub folder");
    require(rows[2].kind == ArrangeRowKind::Audio && rows[2].index == 1U && rows[2].depth == 2, "nested audio");
    require(rows[3].kind == ArrangeRowKind::Midi && rows[3].index == 0U && rows[3].drivesInstrument, "linked MIDI under instrument");
    require(rows[4].kind == ArrangeRowKind::Audio && rows[4].index == 2U && rows[4].depth == 1, "folder audio");
    require(rows[5].index == 0U && rows[6].index == 3U && rows[7].kind == ArrangeRowKind::Midi && rows[7].index == 1U, "top-level rows");
    p.folders[0].collapsed = true;
    rows = buildArrangeRows(p);
    require(rows.size() == 4U && rows[0].kind == ArrangeRowKind::Folder, "collapsed folder hides content");
    require(instrumentTrackForPort(p, 3) == 1 && instrumentTrackForPort(p, 9) == -1, "instrument lookup");
    require(nextFreeMidiPort(p) == 4, "next free MIDI port");
    pass("Arrange rows: nested folders, linked MIDI under instrument, collapse");
}

void testMappingGridAndFormat() {
    TempoMap tempo;
    tempo.setSampleRate(48000.0);
    tempo.setInitialTempo(120.0);
    TimelineMapping m;
    m.sampleRate = 48000.0; m.pixelsPerSecond = 100.0; m.originX = 200.0; m.scrollSeconds = 1.0;
    require(std::abs(m.xForSample(96000) - 300.0) < 1e-9, "xForSample");
    require(m.sampleForX(300.0) == 96000, "sampleForX");
    auto grid = buildGrid(tempo, m, 800.0);
    // 120 BPM: quarter = 50 px, bar = 200 px, 16th = 12.5 px.
    int bars = 0, beats = 0, subs = 0;
    for (const auto& g : grid) { if (g.level == 0) ++bars; else if (g.level == 1) ++beats; else ++subs; }
    require(bars >= 4 && beats >= 12 && subs >= 36, "grid densities");
    require(grid.front().label == "1" || !grid.front().label.empty(), "bar label");
    m.pixelsPerSecond = 2.0;   // very zoomed out: labels thin out
    grid = buildGrid(tempo, m, 800.0);
    int labelled = 0;
    for (const auto& g : grid) if (!g.label.empty()) ++labelled;
    require(labelled > 0 && labelled < 40, "label thinning");
    require(formatBarsBeats(tempo, 0) == "1.1.0", "counter at 0: " + formatBarsBeats(tempo, 0));
    require(formatBarsBeats(tempo, 24000 * 5 + 12000) == "2.2.480", "counter: " + formatBarsBeats(tempo, 24000 * 5 + 12000));
    std::int64_t s = 0;
    require(parseBarsBeats(tempo, "2.2.480", s) && s == 24000 * 5 + 12000, "parse bars/beats");
    require(parseBarsBeats(tempo, "3", s) && s == 24000 * 8, "parse bar only");
    require(!parseBarsBeats(tempo, "0.1.0", s) && !parseBarsBeats(tempo, "1.5.0", s) && !parseBarsBeats(tempo, "x", s), "reject invalid");
    tempo.addTimeSignatureChange(tempo.sampleAtQuarterNotes(8.0), 3U, 4U);
    require(parseBarsBeats(tempo, "4.1.0", s) && s == tempo.sampleAtQuarterNotes(11.0), "parse across meter change");
    require(formatClock(83.4567) == "01:23.457" && formatClock(3725.0) == "1:02:05.000", "clock format");
    for (double db : {-60.0, -30.0, -6.0, 0.0, 6.0, 12.0})
        require(std::abs(dbForFaderPosition(faderPositionForDb(db)) - db) < 1e-9, "fader curve inverse");
    require(std::abs(faderPositionForDb(0.0) - 0.75) < 1e-12 && faderPositionForDb(-200.0) == 0.0, "fader curve anchors");
    pass("Timeline mapping, adaptive grid, bar/beat counter parse/format, fader curve");
}
} // namespace

int main() {
    try {
        testRows();
        testMappingGridAndFormat();
        std::cout << passed << " UI model checks passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
