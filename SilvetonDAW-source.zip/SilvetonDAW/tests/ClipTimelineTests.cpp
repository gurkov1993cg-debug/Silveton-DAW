#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

bool near(float a, float b, float eps = 2.0e-5F) {
    return std::abs(a - b) <= eps;
}

std::vector<float> renderTrack(const silveton::TimelineTrack& track,
                               std::uint32_t blockSize,
                               std::uint32_t blocks) {
    silveton::AudioDeviceConfig config {48000.0, blockSize, 0U, 2U};
    silveton::AudioEngine engine;
    engine.prepare(config);
    engine.addTrack(track);
    silveton::ManualAudioDevice device(config);
    device.start(engine);
    engine.transport().seekSamples(0);
    engine.transport().play();

    std::vector<float> rendered;
    rendered.reserve(static_cast<std::size_t>(blockSize) * blocks);
    for (std::uint32_t b = 0U; b < blocks; ++b) {
        device.pump();
        const auto& out = device.lastOutput();
        rendered.insert(rendered.end(), out[0].begin(), out[0].end());
    }
    device.stop();
    return rendered;
}

void testOverlapCrossfadeAndMeter() {
    constexpr std::uint32_t block = 64U;
    silveton::AudioBuffer a(2U, 64U);
    silveton::AudioBuffer b(2U, 64U);
    for (std::size_t i = 0U; i < 64U; ++i) {
        a.sample(0U, i) = a.sample(1U, i) = 1.0F;
        b.sample(0U, i) = b.sample(1U, i) = 1.0F;
    }

    silveton::TimelineClip left;
    left.source = &a;
    left.timelineStartSample = 0;
    left.lengthSamples = 64U;
    left.fadeOutSamples = 32U;

    silveton::TimelineClip right;
    right.source = &b;
    right.timelineStartSample = 32;
    right.lengthSamples = 64U;
    right.fadeInSamples = 32U;

    silveton::TimelineTrack track;
    track.clips = {left, right};

    silveton::AudioDeviceConfig config {48000.0, block, 0U, 2U};
    silveton::AudioEngine engine;
    engine.prepare(config);
    engine.addTrack(track);
    silveton::ManualAudioDevice device(config);
    device.start(engine);
    engine.transport().play();
    device.pump();

    const auto& out = device.lastOutput();
    for (std::size_t i = 0U; i < block; ++i) {
        require(near(out[0][i], 1.0F), "complementary crossfade changed left-channel level");
        require(near(out[1][i], 1.0F), "complementary crossfade changed right-channel level");
    }
    const auto meter = engine.trackMeter(0U);
    require(near(meter.leftPeak, 1.0F), "track meter did not measure summed crossfade result");
    require(near(meter.rightPeak, 1.0F), "track meter did not measure summed crossfade result (R)");
    require(near(meter.leftRms, 1.0F), "track RMS did not measure summed crossfade result");
    device.stop();
}

void testSplitInsideFadeIsSampleIdentical() {
    silveton::AudioBuffer source(2U, 64U);
    for (std::size_t i = 0U; i < 64U; ++i) {
        source.sample(0U, i) = 0.75F;
        source.sample(1U, i) = -0.5F;
    }

    silveton::TimelineClip whole;
    whole.source = &source;
    whole.timelineStartSample = 0;
    whole.sourceStartSample = 0U;
    whole.lengthSamples = 64U;
    whole.fadeInSamples = 48U;
    whole.fadeOutSamples = 48U;

    silveton::TimelineTrack unsplit;
    unsplit.clips = {whole};
    const auto reference = renderTrack(unsplit, 64U, 1U);

    silveton::TimelineClip first = whole;
    first.lengthSamples = 32U;
    first.fadeInAnchorSourceSample = 0U;
    first.fadeOutAnchorSourceSample = 64U;

    silveton::TimelineClip second = whole;
    second.timelineStartSample = 32;
    second.sourceStartSample = 32U;
    second.lengthSamples = 32U;
    second.fadeInAnchorSourceSample = 0U;
    second.fadeOutAnchorSourceSample = 64U;

    silveton::TimelineTrack split;
    split.clips = {first, second};
    const auto rendered = renderTrack(split, 64U, 1U);
    require(reference.size() == rendered.size(), "split render size mismatch");
    for (std::size_t i = 0U; i < reference.size(); ++i)
        require(near(reference[i], rendered[i]), "split inside fade changed rendered sample");
}
}

int main() {
    try {
        testOverlapCrossfadeAndMeter();
        testSplitInsideFadeIsSampleIdentical();
        std::cout << "PASS: overlapping clips sum before track pan/fader and meter\n";
        std::cout << "PASS: complementary crossfade preserves level\n";
        std::cout << "PASS: split inside fade is sample-identical\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
