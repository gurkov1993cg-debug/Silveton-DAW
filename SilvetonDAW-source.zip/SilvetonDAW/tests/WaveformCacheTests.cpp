#include "silveton/WaveformCache.h"
#include "silveton/WavFile.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silveton;

static void require(bool ok, const char* message) {
    if (!ok) throw std::runtime_error(message);
}

int main() {
    try {
        AudioBuffer audio(2U, 4096U);
        for (std::size_t i = 0U; i < audio.frames(); ++i) {
            const float phase = static_cast<float>(i) * 0.03125F;
            audio.channelData(0)[i] = 0.8F * std::sin(phase);
            audio.channelData(1)[i] = 0.4F * std::cos(phase);
        }
        audio.channelData(0)[300] = -0.95F;
        audio.channelData(0)[301] = 0.97F;

        const auto overview = buildWaveformOverview(audio, 48000U, 64U);
        require(overview.channels == 2U && overview.frames == 4096U, "waveform metadata mismatch");
        require(overview.peaks.size() == 2U && overview.peaks[0].size() <= 64U,
                "waveform peak cap mismatch");
        bool foundNegative = false;
        bool foundPositive = false;
        for (const auto& p : overview.peaks[0]) {
            foundNegative = foundNegative || p.minimum <= -0.94F;
            foundPositive = foundPositive || p.maximum >= 0.96F;
            require(std::isfinite(p.minimum) && std::isfinite(p.maximum) && p.minimum <= p.maximum,
                    "invalid waveform extrema");
        }
        require(foundNegative && foundPositive, "waveform lost real signal peaks");

        const std::string path = "/tmp/silveton_waveform_cache_test.wav";
        std::remove(path.c_str());
        WavFile::writeFloat32(path, 48000U, audio);
        {
            WaveformCache cache(128U);
            cache.request(path);
            require(cache.waitUntilReady(path, 3000U), "async waveform cache did not become ready");
            const auto cached = cache.find(path);
            require(cached && cached->channels == 2U && cached->frames == 4096U,
                    "async waveform cache metadata mismatch");
            require(!cache.failed(path), "async waveform cache reported failure");
        }
        std::remove(path.c_str());

        std::cout << "PASS: real min/max waveform overview and background file cache\n";
        return EXIT_SUCCESS;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return EXIT_FAILURE;
    }
}
