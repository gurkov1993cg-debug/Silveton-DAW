#include "silveton/WaveformCache.h"
#include "silveton/WavFile.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silveton;

static void require(bool ok, const char* message) {
    if (!ok) throw std::runtime_error(message);
}

static void writeBE16(std::FILE* f, std::uint16_t value) {
    const unsigned char bytes[2] {static_cast<unsigned char>((value >> 8U) & 0xFFU),
                                  static_cast<unsigned char>(value & 0xFFU)};
    if (std::fwrite(bytes, 1U, 2U, f) != 2U) throw std::runtime_error("AIFF test write failed");
}

static void writeBE32(std::FILE* f, std::uint32_t value) {
    const unsigned char bytes[4] {static_cast<unsigned char>((value >> 24U) & 0xFFU),
                                  static_cast<unsigned char>((value >> 16U) & 0xFFU),
                                  static_cast<unsigned char>((value >> 8U) & 0xFFU),
                                  static_cast<unsigned char>(value & 0xFFU)};
    if (std::fwrite(bytes, 1U, 4U, f) != 4U) throw std::runtime_error("AIFF test write failed");
}

static void writeExtended80(std::FILE* f, double value) {
    int exponent = 0;
    double fraction = std::frexp(value, &exponent);
    fraction *= 2.0;
    --exponent;
    writeBE16(f, static_cast<std::uint16_t>(exponent + 16383));
    const auto mantissa = static_cast<std::uint64_t>(static_cast<long double>(fraction) * 9223372036854775808.0L);
    for (int i = 7; i >= 0; --i) {
        const unsigned char byte = static_cast<unsigned char>((mantissa >> (i * 8)) & 0xFFU);
        if (std::fwrite(&byte, 1U, 1U, f) != 1U) throw std::runtime_error("AIFF test write failed");
    }
}

static void writePcm16Aiff(const std::string& path, std::uint32_t frames) {
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) throw std::runtime_error("cannot create AIFF waveform test file");
    const std::uint16_t channels = 2U;
    const std::uint32_t dataBytes = frames * channels * 2U;
    std::fwrite("FORM", 1U, 4U, f); writeBE32(f, 46U + dataBytes); std::fwrite("AIFF", 1U, 4U, f);
    std::fwrite("COMM", 1U, 4U, f); writeBE32(f, 18U); writeBE16(f, channels); writeBE32(f, frames); writeBE16(f, 16U); writeExtended80(f, 48000.0);
    std::fwrite("SSND", 1U, 4U, f); writeBE32(f, dataBytes + 8U); writeBE32(f, 0U); writeBE32(f, 0U);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const double phase = static_cast<double>(i) * 0.037;
        const std::int16_t left = static_cast<std::int16_t>(std::sin(phase) * 28000.0);
        const std::int16_t right = static_cast<std::int16_t>(std::cos(phase) * 14000.0);
        writeBE16(f, static_cast<std::uint16_t>(left));
        writeBE16(f, static_cast<std::uint16_t>(right));
    }
    std::fclose(f);
}

int main() {
    try {
        AudioBuffer audio(2U, 4096U);
        for (std::size_t i = 0U; i < audio.frames(); ++i) {
            const float phase = static_cast<float>(i) * 0.03125F;
            audio.channelData(0)[i] = 0.8F * std::sin(phase);
            audio.channelData(1)[i] = 0.4F * std::cos(phase);
        }
        audio.channelData(0)[300] = -0.95F;
        audio.channelData(0)[301] = 0.97F;

        const auto overview = buildWaveformOverview(audio, 48000U, 64U);
        require(overview.channels == 2U && overview.frames == 4096U, "waveform metadata mismatch");
        require(overview.peaks.size() == 2U && overview.peaks[0].size() <= 64U,
                "waveform peak cap mismatch");
        bool foundNegative = false;
        bool foundPositive = false;
        for (const auto& p : overview.peaks[0]) {
            foundNegative = foundNegative || p.minimum <= -0.94F;
            foundPositive = foundPositive || p.maximum >= 0.96F;
            require(std::isfinite(p.minimum) && std::isfinite(p.maximum) && p.minimum <= p.maximum,
                    "invalid waveform extrema");
        }
        require(foundNegative && foundPositive, "waveform lost real signal peaks");

        const std::string path = "/tmp/silveton_waveform_cache_test.wav";
        std::remove(path.c_str());
        WavFile::writeFloat32(path, 48000U, audio);
        {
            WaveformCache cache(128U);
            cache.request(path);
            require(cache.waitUntilReady(path, 3000U), "async waveform cache did not become ready");
            const auto cached = cache.find(path);
            require(cached && cached->channels == 2U && cached->frames == 4096U,
                    "async waveform cache metadata mismatch");
            require(!cache.failed(path), "async waveform cache reported failure");
        }
        std::remove(path.c_str());

        const std::string aiffPath = "/tmp/silveton_waveform_cache_test.aiff";
        std::remove(aiffPath.c_str());
        writePcm16Aiff(aiffPath, 4096U);
        {
            WaveformCache cache(128U);
            cache.request(aiffPath);
            require(cache.waitUntilReady(aiffPath, 3000U), "AIFF waveform cache did not become ready");
            const auto cached = cache.find(aiffPath);
            require(cached && cached->sampleRate == 48000U && cached->channels == 2U && cached->frames == 4096U,
                    "AIFF waveform cache metadata mismatch");
            require(!cache.failed(aiffPath), "AIFF waveform cache reported failure");
        }
        std::remove(aiffPath.c_str());

        std::cout << "PASS: real min/max waveform overview and background WAV/AIFF file cache\n";
        return EXIT_SUCCESS;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return EXIT_FAILURE;
    }
}
