#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include "silveton/Mixer.h"
#include <cstring>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silveton;

namespace {
void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

bool sameFloatBits(float a, float b) noexcept {
    std::uint32_t ua = 0U;
    std::uint32_t ub = 0U;
    static_assert(sizeof(ua) == sizeof(a), "float bit comparison size mismatch");
    std::memcpy(&ua, &a, sizeof(ua));
    std::memcpy(&ub, &b, sizeof(ub));
    return ua == ub;
}

float testSample(std::size_t i, float scale, float phase) {
    return static_cast<float>(scale * std::sin(phase + 0.071 * static_cast<double>(i))
                            + 0.17 * scale * std::cos(0.113 * static_cast<double>(i)));
}
}

int main() {
    try {
        constexpr std::uint32_t block = 256;

        // 1) Interface-monitor contract: at 0 dB, with no timeline signal and
        // a unity master, every finite float sample must reach the device-bound
        // output bit-for-bit unchanged. No EQ, saturation, limiter, dither,
        // loudness compensation or hidden gain is allowed in this path.
        AudioEngine monitorEngine;
        monitorEngine.prepare({48000.0, block, 2U, 2U});
        monitorEngine.setLowLatencyInputMonitoring(true, 0.0F);
        monitorEngine.setMasterFaderDb(0.0F);

        ManualAudioDevice monitorDevice({48000.0, block, 2U, 2U});
        monitorDevice.start(monitorEngine);
        for (std::size_t i = 0; i < block; ++i) {
            monitorDevice.inputChannelData(0U)[i] = testSample(i, 0.71F, 0.13F);
            monitorDevice.inputChannelData(1U)[i] = testSample(i, 0.53F, 0.79F);
        }
        monitorDevice.pump();
        for (std::size_t i = 0; i < block; ++i) {
            require(sameFloatBits(monitorDevice.lastOutput()[0][i], monitorDevice.inputChannelData(0U)[i]),
                    "unity input monitor changed left-channel sample bits");
            require(sameFloatBits(monitorDevice.lastOutput()[1][i], monitorDevice.inputChannelData(1U)[i]),
                    "unity input monitor changed right-channel sample bits");
        }
        monitorDevice.stop();

        // 2) Playback contract: a stereo track at 0 dB, centre stereo balance,
        // no processors and a 0 dB master is bit-transparent through the engine.
        AudioBuffer source(2U, block);
        for (std::size_t i = 0; i < block; ++i) {
            source.sample(0U, i) = testSample(i, 0.63F, 0.37F);
            source.sample(1U, i) = testSample(i, 0.41F, 1.11F);
        }

        AudioEngine playbackEngine;
        playbackEngine.prepare({48000.0, block, 0U, 2U});
        playbackEngine.setMasterFaderDb(0.0F);
        playbackEngine.addTrack({&source, 0, 0, 0.0F, 0.0F, false, true, 0});
        playbackEngine.transport().play();

        AudioBuffer rendered(2U, block);
        float* outs[2] { rendered.channelData(0U), rendered.channelData(1U) };
        playbackEngine.processAudio(nullptr, outs, 0U, 2U, block);

        for (std::size_t i = 0; i < block; ++i) {
            require(sameFloatBits(rendered.sample(0U, i), source.sample(0U, i)),
                    "unity playback changed left-channel sample bits");
            require(sameFloatBits(rendered.sample(1U, i), source.sample(1U, i)),
                    "unity playback changed right-channel sample bits");
        }

        // 3) No hidden crosstalk: isolated L and R signals stay isolated when
        // using the neutral stereo-balance path.
        AudioBuffer isolated(2U, block);
        isolated.clear();
        isolated.sample(0U, 17U) = 0.75F;
        isolated.sample(1U, 93U) = -0.625F;
        AudioBuffer isolatedOut(2U, block);
        Mixer::mixStereo({TrackState{&isolated, 0.0F, 0.0F, false}}, isolatedOut);
        for (std::size_t i = 0; i < block; ++i) {
            require(sameFloatBits(isolatedOut.sample(0U, i), isolated.sample(0U, i)),
                    "neutral stereo path introduced left-channel change/crosstalk");
            require(sameFloatBits(isolatedOut.sample(1U, i), isolated.sample(1U, i)),
                    "neutral stereo path introduced right-channel change/crosstalk");
        }

        // 4) Digital silence remains exact silence. This catches hidden DC,
        // denormal noise injection, dither or always-on analogue modelling.
        AudioBuffer silence(2U, block);
        AudioEngine silenceEngine;
        silenceEngine.prepare({96000.0, block, 0U, 2U});
        silenceEngine.addTrack({&silence, 0, 0, 0.0F, 0.0F, false, true, 0});
        silenceEngine.transport().play();
        AudioBuffer silenceOut(2U, block);
        float* silencePtrs[2] { silenceOut.channelData(0U), silenceOut.channelData(1U) };
        silenceEngine.processAudio(nullptr, silencePtrs, 0U, 2U, block);
        for (std::size_t c = 0; c < 2U; ++c)
            for (std::size_t i = 0; i < block; ++i)
                require(silenceOut.sample(c, i) == 0.0F, "unity engine added non-zero signal to digital silence");

        std::cout << "PASS: interface monitor is bit-transparent at unity\n";
        std::cout << "PASS: stereo playback path is bit-transparent at unity\n";
        std::cout << "PASS: neutral stereo path adds no crosstalk\n";
        std::cout << "PASS: digital silence remains exact silence\n";
        std::cout << "PASS: no hidden colour in the default unity signal path\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
