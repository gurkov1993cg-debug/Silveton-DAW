#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/WavFile.h"
#include <cmath>
#include <chrono>
#include <thread>
#include <atomic>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <new>
#include <stdexcept>
#include <string>

namespace {
thread_local bool gTrackThisThread = false;
thread_local std::size_t gThisThreadAllocations = 0U;

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}
bool near(float a, float b, float eps = 1.0e-7F) { return std::abs(a - b) <= eps; }

std::string tempPath(const char* name) {
    const char* env = std::getenv("TMPDIR");
    std::string base = (env != nullptr && *env != '\0') ? std::string(env) : std::string("/tmp");
    if (!base.empty() && base.back() != '/') base += '/';
    return base + name;
}
}

void* operator new(std::size_t size) {
    if (gTrackThisThread) ++gThisThreadAllocations;
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}
void* operator new[](std::size_t size) {
    if (gTrackThisThread) ++gThisThreadAllocations;
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}
void* operator new(std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackThisThread) ++gThisThreadAllocations;
    return std::malloc(size);
}
void* operator new[](std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackThisThread) ++gThisThreadAllocations;
    return std::malloc(size);
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }
void operator delete(void* p, const std::nothrow_t&) noexcept { std::free(p); }
void operator delete[](void* p, const std::nothrow_t&) noexcept { std::free(p); }

int main() {
    using namespace silveton;
    try {
        constexpr std::uint32_t block = 64U;
        constexpr std::uint32_t blocks = 256U;
        const auto directPath = tempPath("silveton_streaming_record_test.wav");
        const auto enginePath = tempPath("silveton_engine_record_test.wav");
        const auto overflowPath = tempPath("silveton_overflow_record_test.wav");
        std::remove(directPath.c_str());
        std::remove(enginePath.c_str());
        std::remove(overflowPath.c_str());

        Recorder recorder;
        recorder.prepare(2U, 48000U, 65536U);
        recorder.start(directPath);
        float left[block] {};
        float right[block] {};
        const float* input[2] {left, right};

        gThisThreadAllocations = 0U;
        gTrackThisThread = true;
        for (std::uint32_t b = 0U; b < blocks; ++b) {
            for (std::uint32_t i = 0U; i < block; ++i) {
                const std::uint32_t n = b * block + i;
                left[i] = static_cast<float>(n) * 0.00001F;
                right[i] = -left[i];
            }
            if (!recorder.push(input, 2U, block)) {
                gTrackThisThread = false;
                throw std::runtime_error("streaming recorder rejected a normal block");
            }
        }
        gTrackThisThread = false;
        require(gThisThreadAllocations == 0U, "heap allocation occurred in Recorder::push audio-thread path");
        recorder.stop();

        const auto directStatus = recorder.status();
        require(!directStatus.faulted, "streaming recorder reported a fault");
        require(!directStatus.overflowed && directStatus.droppedFrames == 0U, "streaming recorder dropped frames");
        require(directStatus.framesAccepted == static_cast<std::uint64_t>(block) * blocks, "accepted frame count mismatch");
        require(directStatus.framesWritten == directStatus.framesAccepted, "writer did not drain all accepted frames");

        const auto direct = WavFile::read(directPath);
        require(direct.sampleRate == 48000U, "recorded sample rate mismatch");
        require(direct.audio.channels() == 2U, "recorded channel count mismatch");
        require(direct.audio.frames() == static_cast<std::size_t>(block) * blocks, "recorded frame count mismatch");
        require(near(direct.audio.sample(0U, 1234U), static_cast<float>(1234U) * 0.00001F), "left recorded sample mismatch");
        require(near(direct.audio.sample(1U, 1234U), -static_cast<float>(1234U) * 0.00001F), "right recorded sample mismatch");

        // Force the monotonic SPSC indices through several physical ring wraps.
        const auto wrapPath = tempPath("silveton_ring_wrap_test.wav");
        std::remove(wrapPath.c_str());
        Recorder wrap;
        wrap.prepare(2U, 48000U, 128U);
        wrap.start(wrapPath);
        float wrapL[64] {};
        float wrapR[64] {};
        const float* wrapIn[2] {wrapL, wrapR};
        for (std::uint32_t blockIndex = 0U; blockIndex < 6U; ++blockIndex) {
            for (std::uint32_t i = 0U; i < 64U; ++i) {
                const float v = static_cast<float>(blockIndex * 64U + i) / 1000.0F;
                wrapL[i] = v;
                wrapR[i] = -v;
            }
            require(wrap.push(wrapIn, 2U, 64U), "ring-wrap push failed");
            const auto target = static_cast<std::uint64_t>(blockIndex + 1U) * 64U;
            const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(1);
            while (wrap.status().framesWritten < target && std::chrono::steady_clock::now() < deadline)
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            require(wrap.status().framesWritten >= target, "writer did not drain ring-wrap block");
        }
        wrap.stop();
        const auto wrapTake = WavFile::read(wrapPath);
        require(wrapTake.audio.frames() == 384U, "ring-wrap recorded frame count mismatch");
        require(near(wrapTake.audio.sample(0U, 257U), 0.257F, 1.0e-6F), "ring-wrap sample order mismatch");
        require(near(wrapTake.audio.sample(1U, 383U), -0.383F, 1.0e-6F), "ring-wrap tail sample mismatch");

        AudioEngine engine;
        engine.prepare({48000.0, block, 2U, 2U});
        Recorder engineRecorder;
        engineRecorder.prepare(2U, 48000U, 8192U);
        engineRecorder.start(enginePath);
        engine.setRecorder(&engineRecorder);
        ManualAudioDevice device({48000.0, block, 2U, 2U});
        device.start(engine);
        for (std::uint32_t i = 0U; i < block; ++i) {
            device.inputChannelData(0U)[i] = 0.25F;
            device.inputChannelData(1U)[i] = -0.5F;
        }
        for (int i = 0; i < 32; ++i) device.pump();
        device.stop();
        engine.setRecorder(nullptr);
        engineRecorder.stop();
        const auto engineStatus = engineRecorder.status();
        require(!engineStatus.faulted && engineStatus.droppedFrames == 0U, "engine-wired recording faulted");
        const auto engineTake = WavFile::read(enginePath);
        require(engineTake.audio.frames() == block * 32U, "engine recording frame count mismatch");
        require(near(engineTake.audio.sample(0U, block + 3U), 0.25F), "engine recording left sample mismatch");
        require(near(engineTake.audio.sample(1U, block + 3U), -0.5F), "engine recording right sample mismatch");

        // Control-thread stop can race a callback already entering push().
        const auto racePath = tempPath("silveton_stop_race_test.wav");
        std::remove(racePath.c_str());
        Recorder race;
        race.prepare(2U, 48000U, 65536U);
        race.start(racePath);
        std::atomic<bool> producerStarted {false};
        std::thread producer([&] {
            float a[64] {};
            float b[64] {};
            const float* ptrs[2] {a, b};
            producerStarted.store(true, std::memory_order_release);
            for (;;) {
                if (!race.push(ptrs, 2U, 64U)) break;
                std::this_thread::sleep_for(std::chrono::microseconds(100));
            }
        });
        while (!producerStarted.load(std::memory_order_acquire)) std::this_thread::yield();
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
        race.stop();
        producer.join();
        const auto raceStatus = race.status();
        require(!raceStatus.writerError && !raceStatus.overflowed, "stop/push race caused writer or overflow fault");
        require(raceStatus.framesAccepted == raceStatus.framesWritten, "stop did not drain an in-flight push");

        Recorder overflow;
        overflow.prepare(2U, 48000U, 32U);
        overflow.start(overflowPath);
        float tooLongL[64] {};
        float tooLongR[64] {};
        const float* tooLong[2] {tooLongL, tooLongR};
        require(!overflow.push(tooLong, 2U, 64U), "oversized block should have overflowed recorder ring");
        overflow.stop();
        const auto overflowStatus = overflow.status();
        require(overflowStatus.faulted && overflowStatus.overflowed, "overflow was not marked as a fatal take fault");
        require(overflowStatus.droppedFrames == 64U, "overflow dropped-frame count mismatch");

        std::remove(directPath.c_str());
        std::remove(enginePath.c_str());
        std::remove(overflowPath.c_str());

        std::cout << "PASS: Recorder::push performs zero heap allocations on the producer thread\n";
        std::cout << "PASS: background writer drains every accepted frame to Float32 WAV\n";
        std::cout << "PASS: SPSC ring preserves order across physical wrap-around\n";
        std::cout << "PASS: AudioEngine device input is wired to the disk-streaming recorder\n";
        std::cout << "PASS: control-thread stop safely drains an in-flight producer push\n";
        std::cout << "PASS: ring overflow is detected and marks the take faulted\n";
        return 0;
    } catch (const std::exception& e) {
        gTrackThisThread = false;
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
