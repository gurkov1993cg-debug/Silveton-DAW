#include "silveton/Vst3ScannerIsolation.h"
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <string>
#include <thread>

int main(int argc, char** argv) {
    if (argc != 3) return 2;
    const std::string module = argv[1];
    const std::string output = argv[2];
    if (module.find("crash") != std::string::npos) std::abort();
    if (module.find("timeout") != std::string::npos) {
        std::this_thread::sleep_for(std::chrono::seconds(5));
        return 0;
    }
    std::ofstream out(output, std::ios::binary | std::ios::trunc);
    if (!out) return 3;
    out << "PLUGIN\t"
        << silveton::encodeVst3ScanField(module) << '\t'
        << silveton::encodeVst3ScanField("00112233445566778899AABBCCDDEEFF") << '\t'
        << silveton::encodeVst3ScanField("Fixture\tName") << '\t'
        << silveton::encodeVst3ScanField("Silveton") << '\t'
        << silveton::encodeVst3ScanField("1.0") << '\n';
    return out ? 0 : 4;
}
