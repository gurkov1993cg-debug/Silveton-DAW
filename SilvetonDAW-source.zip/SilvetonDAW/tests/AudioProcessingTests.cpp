#include "silveton/AudioProcessing.h"
#include "silveton/DawRuntimeCoordinator.h"
#include "silveton/NativePlugins.h"
#include "silveton/ProjectSession.h"
#include "silveton/WavFile.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silveton;

namespace {
void require(bool c, const std::string& m) { if (!c) throw std::runtime_error(m); }
int passed = 0;
void pass(const char* n) { ++passed; std::cout << "PASS: " << n << '\n'; }

AudioBuffer testSignal(std::size_t frames) {
    AudioBuffer b(2U, frames);
    for (std::size_t i = 0; i < frames; ++i) {
        b.sample(0, i) = static_cast<float>(0.4 * std::sin(i * 0.01) + 0.1);
        b.sample(1, i) = static_cast<float>(-0.2 * std::sin(i * 0.02));
    }
    return b;
}

void testApply() {
    const auto in = testSignal(4800);
    AudioProcessOptions o;
    o.normalizeTargetDb = -1.0;
    const auto norm = AudioProcessor::apply(in, AudioProcess::Normalize, o);
    require(std::abs(AudioProcessor::peak(norm) - static_cast<float>(std::pow(10.0, -1.0 / 20.0))) < 1e-5F, "normalize peak");
    const auto rev = AudioProcessor::apply(in, AudioProcess::Reverse, o);
    require(rev.sample(0, 0) == in.sample(0, 4799) && rev.sample(1, 4799) == in.sample(1, 0), "reverse");
    const auto inv = AudioProcessor::apply(in, AudioProcess::InvertPhase, o);
    require(inv.sample(0, 100) == -in.sample(0, 100), "invert");
    const auto dc = AudioProcessor::apply(in, AudioProcess::RemoveDc, o);
    double mean = 0.0; for (std::size_t i = 0; i < 4800; ++i) mean += dc.sample(0, i);
    require(std::abs(mean / 4800.0) < 1e-6, "remove DC");
    const auto fin = AudioProcessor::apply(in, AudioProcess::FadeIn, o);
    require(fin.sample(0, 0) == 0.0F && std::abs(fin.sample(0, 4799) - in.sample(0, 4799)) < 1e-6F, "fade in");
    const auto fout = AudioProcessor::apply(in, AudioProcess::FadeOut, o);
    require(std::abs(fout.sample(0, 4799)) < 1e-6F && std::abs(fout.sample(0, 0) - in.sample(0, 0)) < 1e-6F, "fade out");
    const auto flip = AudioProcessor::apply(in, AudioProcess::StereoFlip, o);
    require(flip.sample(0, 10) == in.sample(1, 10) && flip.sample(1, 10) == in.sample(0, 10), "stereo flip");
    const auto mono = AudioProcessor::apply(in, AudioProcess::MonoSum, o);
    require(mono.sample(0, 10) == mono.sample(1, 10), "mono sum");
    const auto sil = AudioProcessor::apply(in, AudioProcess::Silence, o);
    require(AudioProcessor::peak(sil) == 0.0F, "silence");
    o.gainDb = 6.0;
    const auto gain = AudioProcessor::apply(in, AudioProcess::Gain, o);
    require(std::abs(gain.sample(0, 50) / in.sample(0, 50) - static_cast<float>(std::pow(10.0, 0.3))) < 1e-5F, "gain");
    o.stretchRatio = 1.5;
    o.quality = ElasticAudioQuality::Draft;
    const auto st = AudioProcessor::apply(in, AudioProcess::TimeStretch, o);
    require(std::abs(static_cast<double>(st.frames()) / 4800.0 - 1.5) < 0.01, "time stretch length");
    o.semitones = 3.0;
    const auto ps = AudioProcessor::apply(in, AudioProcess::PitchShift, o);
    require(ps.frames() == in.frames() || std::abs(static_cast<double>(ps.frames()) - 4800.0) < 48.0, "pitch shift keeps length");
    o.stretchRatio = 9.0;
    bool threw = false;
    try { (void)AudioProcessor::apply(in, AudioProcess::TimeStretch, o); } catch (const std::invalid_argument&) { threw = true; }
    require(threw, "invalid stretch accepted");
    pass("Offline processes: normalize, gain, reverse, invert, DC, fades, flip, mono, silence, stretch, pitch");
}

void testProcessClip() {
    const std::string src = "/tmp/silveton_proc_src.wav";
    const auto signal = testSignal(48000);
    WavFile::writeFloat32(src, 48000U, signal);
    Project p;
    p.sampleRate = 48000.0;
    ProjectTrack t; t.name = "Gtr";
    ProjectAudioClip c; c.id = 7U; c.audioPath = src; c.timelineStartSample = 96000; c.sourceStartSample = 1000;
    c.lengthSamples = 20000U; c.sourceFrames = 48000U; c.sourceChannels = 2U; c.sourceSampleRate = 48000U; c.fadeInSamples = 30000U;
    t.clips.push_back(c);
    p.tracks.push_back(t);
    AudioProcessOptions o;
    o.normalizeTargetDb = -3.0;
    const auto r = AudioProcessor::processClip(p, 0, 7U, AudioProcess::Normalize, o, "/tmp");
    const auto& clip = p.tracks[0].clips[0];
    require(clip.audioPath == r.newPath && clip.sourceStartSample == 0U && clip.lengthSamples == 20000U &&
                clip.timelineStartSample == 96000, "clip relinked to rendered media");
    require(clip.fadeInSamples == 20000U, "fade clamped to new length");
    const auto rendered = WavFile::read(r.newPath);
    require(rendered.audio.frames() == 20000U, "rendered length");
    require(std::abs(AudioProcessor::peak(rendered.audio) - static_cast<float>(std::pow(10.0, -3.0 / 20.0))) < 1e-5F, "rendered peak");
    const double expectedGain = std::pow(10.0, -3.0 / 20.0) / AudioProcessor::peak(AudioEditor::trim(signal, 1000, 20000));
    require(std::abs(rendered.audio.sample(0, 0) - signal.sample(0, 1000) * expectedGain) < 1e-5, "rendered region start");
    const auto original = WavFile::read(src);
    for (std::size_t i = 0; i < 48000; i += 997) require(original.audio.sample(0, i) == signal.sample(0, i), "original media modified");
    p.tracks[0].locked = true;
    bool threw = false;
    try { (void)AudioProcessor::processClip(p, 0, 7U, AudioProcess::Reverse, o, "/tmp"); } catch (const std::runtime_error&) { threw = true; }
    require(threw, "locked track processed");
    std::remove(r.newPath.c_str());
    std::remove(src.c_str());
    pass("Clip processing renders the clip range to new media and relinks nondestructively");
}

void testProcessClipOnFileWithOtherRate() {
    // The file stays at 44.1 kHz on disk; the project runs at 96 kHz. Processing reads the clip range
    // converted to the project rate (like playback), renders new media at the project rate and never
    // touches the original.
    const std::string src = "/tmp/silveton_proc_441.wav";
    AudioBuffer constant(2U, 44100U);
    for (std::size_t i = 0; i < constant.frames(); ++i) { constant.sample(0, i) = 0.3F; constant.sample(1, i) = 0.3F; }
    WavFile::writeFloat32(src, 44100U, constant);
    Project p;
    p.sampleRate = 96000.0;
    ProjectTrack t; t.name = "Vox";
    ProjectAudioClip c; c.id = 3U; c.audioPath = src; c.sourceStartSample = 10000; c.lengthSamples = 20000U;
    c.sourceFrames = 96000U; c.sourceChannels = 2U; c.sourceSampleRate = 44100U;
    t.clips.push_back(c);
    p.tracks.push_back(t);
    AudioProcessOptions o;
    o.gainDb = 6.0;
    const auto r = AudioProcessor::processClip(p, 0, 3U, AudioProcess::Gain, o, "/tmp");
    const auto rendered = WavFile::read(r.newPath);
    require(rendered.sampleRate == 96000U && rendered.audio.frames() == 20000U, "rendered media must be at the project rate with the clip length");
    const float expected = 0.3F * static_cast<float>(std::pow(10.0, 6.0 / 20.0));
    require(std::abs(rendered.audio.sample(0, 10000) - expected) < 2.0e-3F, "gain was not applied to the converted audio");
    const auto original = WavFile::read(src);
    require(original.sampleRate == 44100U && original.audio.frames() == 44100U, "the original file must stay at its own rate");
    std::remove(r.newPath.c_str());
    std::remove(src.c_str());
    pass("Clip processing works on a 44.1 kHz file inside a 96 kHz project without converting the original");
}

void testRenderInPlace() {
    const std::string src = "/tmp/silveton_rip_src.wav";
    AudioBuffer b(2U, 24000U);
    for (std::size_t i = 0; i < b.frames(); ++i) { b.sample(0, i) = 0.25F; b.sample(1, i) = 0.25F; }
    WavFile::writeFloat32(src, 48000U, b);
    ProjectSession session;
    auto& p = session.project();
    p.tempoMap.setSampleRate(48000.0);
    ProjectTrack t; t.name = "Pad"; t.audioPath = src;
    ProjectAudioClip c; c.id = 1U; c.audioPath = src; c.lengthSamples = 24000U; c.sourceFrames = 24000U; c.sourceChannels = 2U; c.sourceSampleRate = 48000U;
    t.clips.push_back(c);
    ProjectPluginSlot eq; eq.modulePath = kNativeModulePath; eq.classId = "silveton.contour-eq";
    std::string why;
    auto proto = createNativePlugin("silveton.contour-eq", why);
    proto->setPlainValue(0, 6.0);
    eq.componentState = proto->componentState();
    t.pluginSlots.push_back(eq);
    p.tracks.push_back(t);
    ProjectTrack other; other.name = "Other"; p.tracks.push_back(other);
    CompositeInstanceFactory factory(nullptr);
    AudioEngine engine;
    DawRuntimeCoordinator runtime(session, engine, factory);
    runtime.prepare({48000.0, 256U, 0U, 2U});
    float l[256] {}, r[256] {};
    float* outs[2] {l, r};
    runtime.audioCallback().processAudio(nullptr, outs, 0U, 2U, 256U);
    (void)runtime.service();
    const auto res = AudioProcessor::renderInPlace(p, engine, &runtime.rack(), 0U, 0, 24000, "/tmp", true);
    require(res.newTrackIndex == 1U && p.tracks.size() == 3U && p.tracks[1].name == "Pad (Rendered)" && p.tracks[2].name == "Other",
            "rendered track placement");
    require(p.tracks[0].mute, "source not muted");
    const auto w = WavFile::read(res.path);
    const float expected = 0.25F * static_cast<float>(std::pow(10.0, 6.0 / 20.0));
    require(std::abs(w.audio.sample(0, 12000) - expected) < 0.01F, "rendered level " + std::to_string(w.audio.sample(0, 12000)));
    require(p.tracks[1].clips.size() == 1U && p.tracks[1].clips[0].lengthSamples == w.audio.frames(), "rendered clip length");
    std::remove(res.path.c_str());
    std::remove(src.c_str());
    pass("Render in place: track rendered through its inserts into a new track below the source");
}
} // namespace

int main() {
    try {
        testApply();
        testProcessClip();
        testProcessClipOnFileWithOtherRate();
        testRenderInPlace();
        std::cout << passed << " audio processing checks passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
