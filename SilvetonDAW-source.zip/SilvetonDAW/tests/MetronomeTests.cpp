#include "silveton/Metronome.h"
#include <array>
#include <iostream>
#include <stdexcept>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

void testFourFourAndAccent() {
    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    std::array<silveton::MetronomeBeatEvent, 16U> events {};
    const auto count = silveton::MetronomeClock::eventsForBlock(map, 0, 96001U, events.data(), events.size());
    require(count == 5U, "4/4 metronome beat count mismatch");
    require(events[0].frameOffset == 0 && events[0].bar == 1 && events[0].beat == 1U && events[0].accent,
            "4/4 first beat/accent mismatch");
    require(events[1].frameOffset == 24000 && events[1].beat == 2U && !events[1].accent,
            "4/4 second beat mismatch");
    require(events[4].frameOffset == 96000 && events[4].bar == 2 && events[4].beat == 1U && events[4].accent,
            "4/4 second bar accent mismatch");
}

void testCountInAcrossMeterAndTempoChange() {
    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    // Bar 2 begins at q=4 / sample 96000, becomes 3/4 and 60 BPM.
    map.addTempoChange(96000, 60.0);
    map.addTimeSignatureChange(96000, 3U, 4U);

    // Bar 3 beat 1 is sample 240000. One-bar count-in starts at bar 2 beat 1.
    require(silveton::CountInPlanner::startSample(map, 240000, 1U) == 96000,
            "one-bar count-in across tempo/meter change mismatch");
    // Preserve offset within the bar: bar 3 beat 2 -> bar 2 beat 2.
    require(silveton::CountInPlanner::startSample(map, 288000, 1U) == 144000,
            "count-in did not preserve beat offset across previous bar");
    // Asking for more history than exists clamps cleanly to project start.
    require(silveton::CountInPlanner::startSample(map, 240000, 8U) == 0,
            "count-in did not clamp at project start");
}

void testTempoAndMeterChange() {
    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    map.addTempoChange(96000, 60.0);
    map.addTimeSignatureChange(96000, 3U, 4U);

    std::array<silveton::MetronomeBeatEvent, 16U> events {};
    const auto count = silveton::MetronomeClock::eventsForBlock(map, 72000, 168001U, events.data(), events.size());
    require(count == 5U, "tempo/time-signature metronome beat count mismatch");
    require(events[0].frameOffset == 0 && events[0].bar == 1 && events[0].beat == 4U,
            "pre-change metronome beat mismatch");
    require(events[1].frameOffset == 24000 && events[1].bar == 2 && events[1].beat == 1U && events[1].accent,
            "3/4 change accent mismatch");
    require(events[2].frameOffset == 72000 && events[2].beat == 2U,
            "60 BPM second beat mismatch");
    require(events[3].frameOffset == 120000 && events[3].beat == 3U,
            "60 BPM third beat mismatch");
    require(events[4].frameOffset == 168000 && events[4].bar == 3 && events[4].beat == 1U && events[4].accent,
            "3/4 next bar accent mismatch");
}
}

int main() {
    try {
        testFourFourAndAccent();
        testTempoAndMeterChange();
        testCountInAcrossMeterAndTempoChange();
        std::cout << "Metronome tests passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Metronome tests failed: " << e.what() << '\n';
        return 1;
    }
}
