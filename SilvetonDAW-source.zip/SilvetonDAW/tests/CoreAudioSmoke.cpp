#include "silveton/CoreAudioDevice.h"

#if defined(__APPLE__)

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <exception>
#include <iostream>
#include <string>
#include <thread>

namespace {
class SilenceCallback final : public silveton::IAudioDeviceCallback {
public:
    void processAudio(const float* const*, float* const* outputs,
                      std::uint32_t, std::uint32_t outputChannels,
                      std::uint32_t frames) noexcept override {
        for (std::uint32_t channel = 0U; channel < outputChannels; ++channel) {
            if (outputs[channel] == nullptr) continue;
            for (std::uint32_t frame = 0U; frame < frames; ++frame) outputs[channel][frame] = 0.0F;
        }
    }
};
}

int main(int argc, char** argv) {
    try {
        const auto devices = silveton::CoreAudioDevice::devices();
        std::cout << "CoreAudio devices: " << devices.size() << '\n';
        for (const auto& device : devices) {
            std::cout << device.id << " | " << device.name
                      << " | uid=" << device.uid
                      << " | in=" << device.inputChannels
                      << " out=" << device.outputChannels
                      << " sr=" << device.nominalSampleRate
                      << (device.isDefaultOutput ? " [default out]" : "") << '\n';
        }

        // Enumeration is safe for build/CI smoke. Passing --stream explicitly
        // opts into a real hardware open/start/stop test on the target Mac.
        if (argc < 2 || std::string(argv[1]) != "--stream") return 0;

        const auto defaultOut = silveton::CoreAudioDevice::defaultOutputDeviceId();
        if (defaultOut == 0U) {
            std::cerr << "No default CoreAudio output device.\n";
            return 2;
        }

        const auto it = std::find_if(devices.begin(), devices.end(), [defaultOut](const auto& d) { return d.id == defaultOut; });
        if (it == devices.end() || it->outputChannels < 2U) {
            std::cerr << "Default output cannot provide stereo.\n";
            return 3;
        }

        silveton::AudioDeviceConfig config;
        config.sampleRate = it->nominalSampleRate > 0.0 ? it->nominalSampleRate : 48000.0;
        config.blockSize = 256U;
        config.inputChannels = 0U;
        config.outputChannels = 2U;

        silveton::CoreAudioDevice device(config, {defaultOut, {}, false});
        SilenceCallback callback;
        device.start(callback);
        std::this_thread::sleep_for(std::chrono::milliseconds(250));
        device.stop();

        const auto status = device.status();
        std::cout << "callbacks=" << status.callbackCount
                  << " overloads=" << status.overloadCount
                  << " outLatencyFrames=" << status.outputLatencyFrames
                  << " auLatencyFrames=" << status.audioUnitLatencyFrames << '\n';
        return status.callbackCount > 0U ? 0 : 4;
    } catch (const std::exception& e) {
        std::cerr << "CoreAudio smoke failed: " << e.what() << '\n';
        return 1;
    }
}

#else
int main() { return 0; }
#endif
