#include "silveton/DawCore.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <iostream>
#include <stdexcept>
using namespace silveton;
static std::string tmp(const char* name){const char*e=std::getenv("TMPDIR");std::string b=(e&&*e)?e:"/tmp";if(!b.empty()&&b.back()!='/')b+='/';return b+name;}
static void ok(bool x,const char*m){if(!x)throw std::runtime_error(m);}
int main(){
 AutomationLane a;a.add(0,0);a.add(100,1);ok(std::abs(a.valueAt(50,0)-.5f)<1e-6,"automation");
 MidiTrack mt;mt.add({20,0x90,60,100});mt.add({10,0x90,62,100});ok(mt.range(0,15).front().data1==62,"midi order");
 AudioBuffer b(2,1000);for(size_t i=0;i<1000;++i){b.sample(0,i)=float(i)/1000;b.sample(1,i)=-float(i)/1000;}
 auto t=AudioEditor::trim(b,100,200);ok(t.frames()==200&&std::abs(t.sample(0,0)-.1f)<1e-6,"trim");
 auto rv=AudioEditor::reverse(t);ok(std::abs(rv.sample(0,199)-.1f)<1e-6,"reverse");
 AudioEditor::fadeIn(t,10);ok(t.sample(0,0)==0,"fadein");AudioEditor::fadeOut(t,10);ok(t.sample(0,199)==0,"fadeout");
 auto rs=AudioEditor::resampleLinear(b,2);ok(rs.frames()==2000,"resample");
 auto st=AudioEditor::timeStretch(b,1.5);ok(st.frames()==1500,"stretch");auto ps=AudioEditor::pitchShift(b,12);ok(std::abs(double(ps.frames())-1000)<3,"pitch length");
 RoutingGraph g;g.setNodeCount(4);g.addRoute({0,2,1});g.addRoute({1,2,1});g.addRoute({2,3,1});ok(g.topologicalOrder().size()==4,"routing");bool cyc=false;try{g.addRoute({3,0,1});}catch(const std::logic_error&){cyc=true;}ok(cyc,"cycle reject");
 DelayCompensator p;p.setLatencies({10,30,0});ok(p.maxLatency()==30&&p.delayFor(0)==20&&p.delayFor(1)==0&&p.delayFor(2)==30,"pdc");
 Project pr;pr.sampleRate=44100;pr.tempo=128;pr.panDepth=PanDepth::Minus4_5dB;pr.masterFaderDb=-3.0F;
 ProjectTrack pt{"Kick","kick.wav",-3,.1f,false};pt.useDualStereoPan=true;pt.stereoLeftPan=-0.75f;pt.stereoRightPan=0.8f;pr.tracks.push_back(pt);
 auto path=tmp("silveton_test.svp");pr.save(path);auto q=Project::load(path);
 ok(q.tracks.size()==1&&q.tracks[0].name=="Kick"&&q.tempo==128,"project");
 ok(q.panDepth==PanDepth::Minus4_5dB,"project pan depth recall");
 ok(std::abs(q.masterFaderDb+3.0f)<1e-6f,"project master fader recall");
 ok(q.tracks[0].useDualStereoPan&&std::abs(q.tracks[0].stereoLeftPan+0.75f)<1e-6f&&std::abs(q.tracks[0].stereoRightPan-0.8f)<1e-6f,"project stereo pan recall");
 std::remove(path.c_str());
 auto recPath=tmp("silveton_daw_test_record.wav");std::remove(recPath.c_str());Recorder r;r.prepare(2,48000,1024);float l[4]={1,2,3,4},rr[4]={5,6,7,8};const float* in[2]={l,rr};r.start(recPath);ok(r.push(in,2,4),"record push");r.stop();ok(!r.status().faulted&&r.captured().frames()==4&&r.captured().sample(1,3)==8,"record");std::remove(recPath.c_str());
 std::cout<<"Silveton DAW subsystem tests PASS\n";return 0;
}
