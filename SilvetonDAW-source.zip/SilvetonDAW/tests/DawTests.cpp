#include "silveton/DawCore.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <iostream>
#include <stdexcept>
using namespace silveton;
static std::string tmp(const char* name){const char*e=std::getenv("TMPDIR");std::string b=(e&&*e)?e:"/tmp";if(!b.empty()&&b.back()!='/')b+='/';return b+name;}
static void ok(bool x,const char*m){if(!x)throw std::runtime_error(m);}
int main(){
 AutomationLane a;a.add(0,0);a.add(100,1);ok(std::abs(a.valueAt(50,0)-.5f)<1e-6,"automation");
 ok(a.movePoint(100,120,0.75F),"automation move point");ok(a.points().size()==2U&&a.points()[1].sample==120&&std::abs(a.points()[1].value-0.75F)<1e-6F,"automation move result");
 ok(a.removeAt(0),"automation remove point");ok(a.points().size()==1U,"automation remove result");
 a.replacePoints({{10,0.25F},{20,0.5F}});ok(a.points().size()==2U&&std::abs(a.valueAt(15,0.0F)-0.375F)<1e-6F,"automation replace points");
 ParameterAutomationLane pa;pa.write(0,0.2);pa.write(100,0.8);ok(pa.movePoint(100,80,0.6),"parameter automation move");ok(pa.removeAt(0),"parameter automation remove");pa.replacePoints({{5,0.1},{15,0.9}});ok(pa.points().size()==2U&&std::abs(pa.valueAt(10,0.0)-0.5)<1e-9,"parameter automation replace");
 MidiTrack mt;mt.add({20,0x90,60,100});mt.add({10,0x90,62,100});ok(mt.range(0,15).front().data1==62,"midi order");
 AudioBuffer b(2,1000);for(size_t i=0;i<1000;++i){b.sample(0,i)=float(i)/1000;b.sample(1,i)=-float(i)/1000;}
 auto t=AudioEditor::trim(b,100,200);ok(t.frames()==200&&std::abs(t.sample(0,0)-.1f)<1e-6,"trim");
 auto rv=AudioEditor::reverse(t);ok(std::abs(rv.sample(0,199)-.1f)<1e-6,"reverse");
 AudioEditor::fadeIn(t,10);ok(t.sample(0,0)==0,"fadein");AudioEditor::fadeOut(t,10);ok(t.sample(0,199)==0,"fadeout");
 auto rs=AudioEditor::resampleLinear(b,2);ok(rs.frames()==2000,"resample");
 auto st=AudioEditor::timeStretch(b,1.5);ok(st.frames()==1500,"stretch");auto ps=AudioEditor::pitchShift(b,12);ok(std::abs(double(ps.frames())-1000)<3,"pitch length");
 RoutingGraph g;g.setNodeCount(4);g.addRoute({0,2,1});g.addRoute({1,2,1});g.addRoute({2,3,1});ok(g.topologicalOrder().size()==4,"routing");bool cyc=false;try{g.addRoute({3,0,1});}catch(const std::logic_error&){cyc=true;}ok(cyc,"cycle reject");
 DelayCompensator p;p.setLatencies({10,30,0});ok(p.maxLatency()==30&&p.delayFor(0)==20&&p.delayFor(1)==0&&p.delayFor(2)==30,"pdc");
 Project pr;pr.sampleRate=44100;pr.tempo=128;pr.panDepth=PanDepth::Minus4_5dB;pr.masterFaderDb=-3.0F;
 ProjectTrack pt{"Kick","kick.wav",-3,.1f,false};pt.useDualStereoPan=true;pt.stereoLeftPan=-0.75f;pt.stereoRightPan=0.8f;pr.tracks.push_back(pt);
 auto path=tmp("silveton_test.svp");pr.save(path);auto q=Project::load(path);
 ok(q.tracks.size()==1&&q.tracks[0].name=="Kick"&&q.tempo==128,"project");
 ok(q.panDepth==PanDepth::Minus4_5dB,"project pan depth recall");
 ok(std::abs(q.masterFaderDb+3.0f)<1e-6f,"project master fader recall");
 ok(q.tracks[0].useDualStereoPan&&std::abs(q.tracks[0].stereoLeftPan+0.75f)<1e-6f&&std::abs(q.tracks[0].stereoRightPan-0.8f)<1e-6f,"project stereo pan recall");
 std::remove(path.c_str());
 auto legacyPath=tmp("silveton_v14_compat.svp");{std::ofstream f(legacyPath.c_str());f<<"SILVETON_PROJECT_V14\n48000\t120\t30\t0\nTRACKS\t1\nTRACK\tLegacy\tlegacy.wav\t0\t0\t0\t0\t-1\t1\t0\t0\t1\t0\nSLOTS\t0\nBUSES\t1\nBUS\tLegacyBus\nSLOTS\t0\nEND\n";}
 auto legacy=Project::load(legacyPath);ok(legacy.tracks.size()==1&&legacy.buses.size()==1,"V14 compatibility load");ok(legacy.tracks[0].outputBus==-1&&legacy.tracks[0].sends.empty()&&legacy.masterPluginSlots.empty(),"V14 routing defaults");std::remove(legacyPath.c_str());
 auto v15Path=tmp("silveton_v15_compat.svp");{std::ofstream f(v15Path.c_str());f<<"SILVETON_PROJECT_V15\n48000\t120\t30\t0\nTRACKS\t1\nTRACK\tLegacy15\tlegacy15.wav\t0\t0\t0\t0\t-1\t1\t0\t0\t1\t0\t-1\nSLOTS\t0\nSENDS\t1\nSEND\t0\t-6\t1\nBUSES\t1\nBUS\tFX\t1\t0\t0\t-1\nSLOTS\t0\nSENDS\t0\nMASTER\nSLOTS\t0\nEND\n";}
 auto legacy15=Project::load(v15Path);ok(legacy15.tracks.size()==1&&legacy15.buses.size()==1,"V15 compatibility load");ok(legacy15.tracks[0].sends.size()==1&& !legacy15.tracks[0].sends[0].preFader && legacy15.tracks[0].sends[0].gainAutomationDb.points().empty(),"V15 automation defaults");std::remove(v15Path.c_str());
 auto recPath=tmp("silveton_daw_test_record.wav");std::remove(recPath.c_str());Recorder r;r.prepare(2,48000,1024);float l[4]={1,2,3,4},rr[4]={5,6,7,8};const float* in[2]={l,rr};r.start(recPath);ok(r.push(in,2,4),"record push");r.stop();ok(!r.status().faulted&&r.captured().frames()==4&&r.captured().sample(1,3)==8,"record");std::remove(recPath.c_str());
 std::cout<<"Silveton DAW subsystem tests PASS\n";return 0;
}
