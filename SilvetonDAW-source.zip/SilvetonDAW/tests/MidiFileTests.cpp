#include "silveton/MidiFile.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silveton;

namespace {
void require(bool c, const std::string& m) { if (!c) throw std::runtime_error(m); }
int passed = 0;
void pass(const char* n) { ++passed; std::cout << "PASS: " << n << '\n'; }

MusicalMidiNote note(double start, double dur, int pitch, int vel = 100, int ch = 0) {
    MusicalMidiNote n; n.startQuarterNotes = start; n.durationQuarterNotes = dur;
    n.pitch = static_cast<std::uint8_t>(pitch); n.velocity = static_cast<std::uint8_t>(vel); n.channel = static_cast<std::uint8_t>(ch);
    return n;
}

void testRoundTrip() {
    TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(96.0);
    map.setInitialTimeSignature(3U, 4U);
    map.addTempoChange(map.sampleAtQuarterNotes(12.0), 140.0);
    map.addTimeSignatureChange(map.sampleAtQuarterNotes(12.0), 7U, 8U);
    MidiSequence a, b;
    (void)a.addNote(note(0.0, 1.0, 60, 90));
    (void)a.addNote(note(0.5, 0.25, 64, 70, 1));
    (void)a.addNote(note(13.0, 2.0, 67, 127));
    MusicalMidiMessage cc; cc.quarterNotes = 1.0; cc.status = 0xB0; cc.data1 = 7; cc.data2 = 99;
    (void)a.addMessage(cc);
    MusicalMidiMessage pc; pc.quarterNotes = 0.0; pc.status = 0xC1; pc.data1 = 12;
    (void)a.addMessage(pc);
    MusicalMidiMessage pb; pb.quarterNotes = 2.0; pb.status = 0xE0; pb.data1 = 0; pb.data2 = 80;
    (void)a.addMessage(pb);
    (void)b.addNote(note(4.0, 4.0, 36, 110, 9));
    const std::string path = "/tmp/silveton_roundtrip.mid";
    StandardMidiFile::write(path, {{"Piano", &a}, {"Drums", &b}}, map, 960U);
    const auto r = StandardMidiFile::read(path, 48000.0);
    std::remove(path.c_str());
    require(r.format == 1U && r.ticksPerQuarter == 960U, "header");
    require(r.tracks.size() == 2U && r.tracks[0].name == "Piano" && r.tracks[1].name == "Drums", "track names");
    const auto& n = r.tracks[0].sequence.notes();
    require(n.size() == 3U, "note count");
    require(std::abs(n[1].startQuarterNotes - 0.5) < 1e-9 && std::abs(n[1].durationQuarterNotes - 0.25) < 1e-9 &&
                n[1].pitch == 64 && n[1].velocity == 70 && n[1].channel == 1, "note fields");
    require(r.tracks[0].sequence.messages().size() == 3U, "controller/program/bend messages");
    bool sawPc = false;
    for (const auto& m : r.tracks[0].sequence.messages()) if (m.status == 0xC1 && m.data1 == 12) sawPc = true;
    require(sawPc, "program change");
    require(std::abs(r.tempoMap.initialTempo() - 96.0) < 0.01 && r.tempoMap.initialNumerator() == 3U, "initial tempo/meter");
    const std::int64_t at13 = r.tempoMap.sampleAtQuarterNotes(13.0);
    require(std::abs(r.tempoMap.tempoAtSample(at13) - 140.0) < 0.01, "tempo change");
    require(r.tempoMap.numeratorAtSample(at13) == 7U && r.tempoMap.denominatorAtSample(at13) == 8U, "meter change");
    require(std::llabs(at13 - map.sampleAtQuarterNotes(13.0)) <= 1, "tempo map sample positions");
    pass("SMF format-1 round trip: notes, CC, program, pitch bend, names, tempo and meter changes");
}

void testHandCraftedFormat0() {
    // Format 0, 96 ppq: running status, note-on velocity 0 as note-off,
    // sysex, a hanging note, split by channel.
    std::vector<std::uint8_t> f = {'M','T','h','d', 0,0,0,6, 0,0, 0,1, 0,96,
                                   'M','T','r','k', 0,0,0,0};
    std::vector<std::uint8_t> t = {
        0x00, 0xF0, 0x03, 0x7E, 0x09, 0xF7,   // sysex
        0x00, 0x90, 60, 100,                  // ch1 note on
        0x30, 64, 90,                         // running status note on (delta 48)
        0x30, 60, 0,                          // running status vel 0 = off (tick 96)
        0x00, 0x99, 38, 120,                  // ch10 note on at 96
        0x60, 0x80, 64, 0,                    // off 64 at tick 192
        0x00, 0x89, 38, 0,
        0x00, 0x91, 72, 80,                   // hanging ch2 note
        0x81, 0x00, 0xFF, 0x2F, 0x00};        // end at tick 320
    const auto len = static_cast<std::uint32_t>(t.size());
    f[18] = static_cast<std::uint8_t>(len >> 24); f[19] = static_cast<std::uint8_t>(len >> 16);
    f[20] = static_cast<std::uint8_t>(len >> 8); f[21] = static_cast<std::uint8_t>(len);
    f.insert(f.end(), t.begin(), t.end());
    const auto r = StandardMidiFile::parse(f, 48000.0, true);
    require(r.format == 0U && r.tracks.size() == 3U, "split by channel into 3 tracks");
    const auto& ch1 = r.tracks[0].sequence.notes();
    require(ch1.size() == 2U && std::abs(ch1[0].durationQuarterNotes - 1.0) < 1e-9 && std::abs(ch1[1].startQuarterNotes - 0.5) < 1e-9 &&
                std::abs(ch1[1].durationQuarterNotes - 1.5) < 1e-9, "running status + vel0 note-off");
    require(r.tracks[1].firstChannel == 1 && std::abs(r.tracks[1].sequence.notes()[0].startQuarterNotes - 2.0) < 1e-9, "hanging note kept");
    require(std::abs(r.tracks[1].sequence.notes()[0].durationQuarterNotes - (320.0 - 192.0) / 96.0) < 1e-9, "hanging note closed at track end");
    require(r.tracks[2].firstChannel == 9, "drum channel");
    bool threw = false;
    try { (void)StandardMidiFile::parse({'R','I','F','F'}, 48000.0); } catch (const std::runtime_error&) { threw = true; }
    require(threw, "garbage accepted");
    pass("SMF parser: running status, velocity-0 note-off, sysex skip, hanging notes, channel split");
}

void testFunctions() {
    MidiSequence s;
    const auto n1 = s.addNote(note(0.0, 0.25, 60, 50));
    const auto n2 = s.addNote(note(1.0, 0.25, 62, 100));
    (void)s.addNote(note(2.0, 0.25, 64, 120));
    require(MidiFunctions::legato(s) == 2U, "legato count");
    for (const auto& n : s.notes()) {
        if (n.id == n1) require(std::abs(n.durationQuarterNotes - 1.0) < 1e-9, "legato note 1");
        if (n.id == n2) require(std::abs(n.durationQuarterNotes - 1.0) < 1e-9, "legato note 2");
    }
    MidiFunctions::fixedLength(s, 0.5);
    for (const auto& n : s.notes()) require(std::abs(n.durationQuarterNotes - 0.5) < 1e-9, "fixed length");
    MidiFunctions::compressVelocity(s, 0.5);
    std::vector<int> v; for (const auto& n : s.notes()) v.push_back(n.velocity);
    require(v[0] == 70 && v[1] == 95 && v[2] == 105, "compress velocity around mean 90");
    MidiFunctions::scaleVelocity(s, 2.0, 0);
    for (const auto& n : s.notes()) require(n.velocity == 127 || n.velocity == 127, "scale clamps to 127");
    MidiFunctions::fixedVelocity(s, 64, {n2});
    for (const auto& n : s.notes()) require((n.id == n2) == (n.velocity == 64), "fixed velocity respects selection");

    MidiSequence q;
    (void)q.addNote(note(0.1, 0.2, 60));
    (void)q.addNote(note(0.45, 0.2, 62));
    (void)q.addNote(note(0.9, 0.2, 64));
    MidiFunctions::quantize(q, 0.5, 0.0, 1.0);
    require(std::abs(q.notes()[0].startQuarterNotes) < 1e-9 && std::abs(q.notes()[1].startQuarterNotes - 0.5) < 1e-9 &&
                std::abs(q.notes()[2].startQuarterNotes - 1.0) < 1e-9, "straight quantize");
    MidiSequence sw;
    (void)sw.addNote(note(0.5, 0.2, 60));
    MidiFunctions::quantize(sw, 0.5, 1.0, 1.0);
    require(std::abs(sw.notes()[0].startQuarterNotes - (0.5 + 0.5 / 3.0)) < 1e-9, "100% swing moves off-beat to triplet position");
    MidiSequence it;
    (void)it.addNote(note(0.2, 0.2, 60));
    MidiFunctions::quantize(it, 0.5, 0.0, 0.5);
    require(std::abs(it.notes()[0].startQuarterNotes - 0.1) < 1e-9, "iterative quantize 50%");

    MidiSequence h1, h2;
    for (int i = 0; i < 8; ++i) { (void)h1.addNote(note(i, 0.5, 60, 100)); (void)h2.addNote(note(i, 0.5, 60, 100)); }
    MidiFunctions::humanize(h1, 0.02, 10, 42U);
    MidiFunctions::humanize(h2, 0.02, 10, 42U);
    bool moved = false;
    for (std::size_t i = 0; i < 8; ++i) {
        require(h1.notes()[i].startQuarterNotes == h2.notes()[i].startQuarterNotes, "humanize deterministic");
        require(std::abs(h1.notes()[i].velocity - 100) <= 10, "humanize velocity range");
        if (std::abs(h1.notes()[i].startQuarterNotes - std::round(h1.notes()[i].startQuarterNotes)) > 1e-6) moved = true;
    }
    require(moved, "humanize changed nothing");

    MidiSequence d;
    (void)d.addNote(note(1.0, 1.0, 60));
    (void)d.addNote(note(1.0, 0.5, 60));
    (void)d.addNote(note(1.5, 1.0, 60));
    (void)d.addNote(note(1.0, 1.0, 61));
    require(MidiFunctions::deleteDoubles(d) == 1U && d.notes().size() == 3U, "delete doubles");
    require(MidiFunctions::deleteOverlaps(d) == 1U, "delete overlaps");
    for (const auto& n : d.notes()) if (n.pitch == 60 && n.startQuarterNotes < 1.2) require(std::abs(n.durationQuarterNotes - 0.5) < 1e-9, "overlap trimmed");

    MidiSequence r;
    (void)r.addNote(note(0.0, 1.0, 60));
    (void)r.addNote(note(3.0, 1.0, 72));
    MidiFunctions::reverse(r, 0.0, 4.0);
    for (const auto& n : r.notes()) require((n.pitch == 60) == (std::abs(n.startQuarterNotes - 3.0) < 1e-9), "retrograde");
    MidiFunctions::invert(r, 66);
    for (const auto& n : r.notes()) require(n.pitch == 72 || n.pitch == 60, "invert around 66");
    (void)r.addNote(note(5.0, 0.01, 40, 5));
    require(MidiFunctions::deleteShortOrSoft(r, 0.05, 10) == 1U, "delete short/soft");
    pass("MIDI functions: legato, fixed length/velocity, velocity compress/scale, quantize (swing, iterative), humanize, doubles, overlaps, retrograde, invert");
}
} // namespace

void testSequenceFromPlan() {
    TempoMap map; map.setSampleRate(48000.0); map.setInitialTempo(100.0);
    MidiPart part; part.id = 1; part.timelineStartQuarterNotes = 8.0; part.lengthQuarterNotes = 2.0; part.loopLengthQuarterNotes = 1.0;
    (void)part.sequence.addNote(note(0.0, 0.5, 60, 99));
    MusicalMidiMessage cc; cc.quarterNotes = 0.25; cc.status = 0xB0; cc.data1 = 1; cc.data2 = 50;
    (void)part.sequence.addMessage(cc);
    const auto plan = compileMidiArrangement(MidiSequence {}, {part}, map);
    const auto seq = sequenceFromRenderPlan(plan, map);
    require(seq.notes().size() == 2U, "looped part flattened to two notes");
    require(std::abs(seq.notes()[0].startQuarterNotes - 8.0) < 1e-6 && std::abs(seq.notes()[1].startQuarterNotes - 9.0) < 1e-6 &&
                std::abs(seq.notes()[0].durationQuarterNotes - 0.5) < 1e-6 && seq.notes()[0].velocity == 99, "flattened note timing");
    require(seq.messages().size() == 2U, "flattened controller messages");
    pass("Render plan -> timeline sequence (loop-expanded parts) for MIDI export");
}

int main() {
    try {
        testSequenceFromPlan();
        testRoundTrip();
        testHandCraftedFormat0();
        testFunctions();
        std::cout << passed << " MIDI file/function checks passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
