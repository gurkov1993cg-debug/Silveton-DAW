#include "silveton/MidiInput.h"
#include <array>
#include <cmath>
#include <iostream>
#include <stdexcept>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
void near(double a, double b, double tolerance, const char* message) {
    if (std::abs(a - b) > tolerance) throw std::runtime_error(message);
}

void testRealtimeThruBlockScheduling() {
    silveton::MidiInputCapture input;
    require(input.pushRealtime({7, 100, 0x90U, 60U, 100U}), "MIDI thru note-on push failed");
    require(input.pushRealtime({7, 131, 0x80U, 60U, 45U}), "MIDI thru note-off push failed");
    require(input.pushRealtime({7, 200, 0xB0U, 1U, 64U}), "MIDI thru future CC push failed");

    std::array<silveton::TimedMidiInputEvent, 8U> events {};
    const auto first = input.eventsForBlock(96, 64U, events.data(), events.size());
    require(first == 2U, "MIDI thru block event count mismatch");
    require(events[0].sample == 100 && events[1].sample == 131, "MIDI thru block timing mismatch");
    const auto second = input.eventsForBlock(192, 64U, events.data(), events.size());
    require(second == 1U && events[0].sample == 200, "MIDI thru future event was not preserved");
}

void testRecordingCommitsMusicalNotesAcrossTempoChange() {
    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    map.addTempoChange(48000, 60.0); // q=2 at sample 48000

    silveton::MidiInputCapture input;
    input.beginRecording();
    require(input.pushRealtime({3, 24000, 0x92U, 64U, 111U}), "MIDI record note-on push failed"); // q=1
    require(input.pushRealtime({3, 48000, 0xB2U, 64U, 127U}), "MIDI record sustain push failed");
    require(input.pushRealtime({3, 60000, 0xE2U, 1U, 96U}), "MIDI record pitch-bend push failed");
    require(input.pushRealtime({3, 72000, 0x82U, 64U, 31U}), "MIDI record note-off push failed"); // q=2.5

    silveton::MidiSequence sequence;
    const auto committed = input.stopAndCommit(sequence, map, 72000);
    require(committed == 3U && sequence.notes().size() == 1U, "MIDI recording did not commit note + controllers");
    require(sequence.messages().size() == 2U, "MIDI recording controller count mismatch");
    const auto& note = sequence.notes()[0];
    near(note.startQuarterNotes, 1.0, 1.0e-12, "MIDI recording start lost musical timing");
    near(note.durationQuarterNotes, 1.5, 1.0e-12, "MIDI recording duration lost tempo-map timing");
    require(note.channel == 2U && note.pitch == 64U && note.velocity == 111U && note.releaseVelocity == 31U,
            "MIDI recording note data mismatch");
    require(sequence.messages()[0].status == 0xB2U && sequence.messages()[0].data1 == 64U &&
            sequence.messages()[0].data2 == 127U, "recorded sustain controller mismatch");
    require(sequence.messages()[1].status == 0xE2U && sequence.messages()[1].data1 == 1U &&
            sequence.messages()[1].data2 == 96U, "recorded pitch bend mismatch");
}

void testHangingNoteClosesAtStopAndInvalidInputRejected() {
    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    silveton::MidiInputCapture input;
    require(!input.pushRealtime({-1, 0, 0x90U, 60U, 100U}), "invalid MIDI input port accepted");
    input.beginRecording();
    require(input.pushRealtime({1, 0, 0x90U, 67U, 90U}), "hanging MIDI note push failed");
    silveton::MidiSequence sequence;
    require(input.stopAndCommit(sequence, map, 24000) == 1U, "hanging MIDI note was not closed at Stop");
    near(sequence.notes()[0].durationQuarterNotes, 1.0, 1.0e-12, "hanging MIDI note stop duration mismatch");
}
}

int main() {
    try {
        testRealtimeThruBlockScheduling();
        testRecordingCommitsMusicalNotesAcrossTempoChange();
        testHangingNoteClosesAtStopAndInvalidInputRejected();
        std::cout << "PASS: realtime MIDI input thru scheduling and MIDI recording commit\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
