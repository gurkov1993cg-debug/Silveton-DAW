// The Sample Editor's maths: zoom, ruler, waveform columns and zero crossings.
#include "silveton/SampleEditorModel.h"

#include <cmath>
#include <iostream>
#include <random>
#include <stdexcept>

namespace {
using namespace silveton;

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
bool near(double a, double b, double eps) { return std::abs(a - b) <= eps; }

void testViewport() {
    SampleViewport v;
    v.configure(96000.0 * 10.0, 1000.0);   // 10 s at 96 kHz in 1000 px
    v.fitAll();
    require(near(v.samplesPerPixel, 960.0, 1.0e-9) && v.first == 0.0, "fit shows everything");

    // Zooming keeps the sample under the pointer where it is.
    v.zoomAbout(250.0, 0.5);
    require(near(v.samplesPerPixel, 480.0, 1.0e-9), "zoom in halves the scale");
    v.first = 100000.0;
    const double anchor = v.sampleAtX(400.0);
    v.zoomAbout(400.0, 0.25);
    require(near(v.sampleAtX(400.0), anchor, 1.0e-6), "the sample under the pointer must stay put");

    // Limits: not further out than the whole span, not further in than 32 px per sample.
    for (int i = 0; i < 40; ++i) v.zoomAbout(500.0, 0.1);
    require(near(v.samplesPerPixel, SampleViewport::kMinSamplesPerPixel, 1.0e-12), "zoom-in limit");
    for (int i = 0; i < 40; ++i) v.zoomAbout(500.0, 10.0);
    require(near(v.samplesPerPixel, 960.0, 1.0e-9) && v.first == 0.0, "zoom-out limit is the fitted view");

    // Scrolling stays inside the span.
    v.zoomAbout(0.0, 0.1);
    v.scrollPixels(-1.0e9);
    require(v.first == 0.0, "no scrolling before the start");
    v.scrollPixels(1.0e12);
    require(near(v.first, v.length - v.visibleSamples(), 1.0e-6), "no scrolling past the end");

    // Zoom to a range, and follow the playhead.
    v.zoomToRange(200000.0, 300000.0);
    require(v.sampleAtX(0.0) <= 200000.0 && v.sampleAtX(1000.0) >= 300000.0, "the range must be fully visible");
    require(v.visibleSamples() < 120000.0, "and fill most of the view");
    v.ensureVisible(900000.0);
    require(900000.0 >= v.first && 900000.0 <= v.first + v.visibleSamples(), "ensureVisible must bring the sample into view");

    // A new window width keeps a fitted view fitted.
    SampleViewport f;
    f.configure(48000.0, 800.0);
    f.fitAll();
    f.configure(48000.0, 1600.0);
    require(near(f.samplesPerPixel, 30.0, 1.0e-9), "a fitted view stays fitted when the window grows");
}

void testRuler() {
    SampleViewport v;
    v.configure(96000.0 * 60.0, 1000.0);
    v.fitAll();                                   // 60 s over 1000 px
    auto ticks = buildRuler(v, 96000.0, 96.0);
    require(!ticks.empty(), "ruler has ticks");
    double lastMajor = -1.0;
    int majors = 0;
    for (const auto& t : ticks) {
        if (!t.major) { require(t.label.empty(), "minor ticks have no label"); continue; }
        ++majors;
        require(!t.label.empty(), "major ticks are labelled");
        if (lastMajor >= 0.0) require(v.xAtSample(t.sample) - v.xAtSample(lastMajor) >= 95.0, "majors must not be closer than the minimum");
        lastMajor = t.sample;
    }
    require(majors >= 3 && majors <= 12, "a sensible number of labels");
    require(ticks.front().label == "0:00", "the first label is the start");

    // A clip that starts at 1.5 s in the project: the ruler speaks project time.
    SampleViewport o;
    o.configure(96000.0 * 4.0, 1000.0);
    o.fitAll();
    ticks = buildRuler(o, 96000.0, 96.0, 96000.0 * 1.5);
    require(ticks.front().label == "0:01.5" || ticks.front().label == "0:02" || ticks.front().label == "0:01.50",
            "the first label of a clip that starts at 1.5 s must be a project time");
    require(ticks.front().sample >= -1.0e-6 || ticks.front().sample > -96000.0 * 1.0, "ticks stay near the view");
    for (const auto& t : ticks) if (t.major && t.label == "0:02") require(std::abs(t.sample - 96000.0 * 0.5) < 1.0e-6, "project 2.0 s is 0.5 s into the view");

    // Zoomed in to milliseconds, labels carry decimals.
    v.zoomToRange(96000.0 * 1.0, 96000.0 * 1.02);
    ticks = buildRuler(v, 96000.0, 96.0);
    bool decimals = false;
    for (const auto& t : ticks) if (t.major && t.label.find('.') != std::string::npos) decimals = true;
    require(decimals, "fine zoom needs decimals in the labels");

    require(formatRulerTime(75.0, 5.0) == "1:15", "whole seconds");
    require(formatRulerTime(75.25, 0.05) == "1:15.25", "hundredths");
    require(formatRulerTime(3725.0, 1.0) == "1:02:05", "hours");
    require(formatClockTime(1.5) == "0:01.500", "clock read-out");
}

AudioBuffer rampAudio(std::size_t frames, std::size_t channels) {
    AudioBuffer audio(channels, frames);
    for (std::size_t c = 0U; c < channels; ++c)
        for (std::size_t i = 0U; i < frames; ++i)
            audio.sample(c, i) = static_cast<float>(std::sin(static_cast<double>(i) * 0.01 * static_cast<double>(c + 1)));
    return audio;
}

void testColumnPeaks() {
    // A 44.1 kHz file in a 96 kHz project, with detail and a coarse overview.
    WaveformDetail detail;
    detail.sampleRate = 44100U;
    detail.audio = rampAudio(44100U, 2U);
    const WaveformOverview overview = buildWaveformOverview(detail.audio, 44100U, 200U);

    PieceView piece;
    piece.startRel = 1000.0;
    piece.length = 96000.0;                // one second of project time
    piece.sourceStart = 0.0;
    piece.projectRate = 96000.0;
    piece.overview = &overview;
    piece.detail = &detail;
    require(near(piece.fileRate(), 44100.0, 1.0e-9), "the file rate comes from the media");
    require(near(piece.nativePosition(1000.0 + 96000.0), 44100.0, 1.0e-6), "one project second is 44100 file samples");

    SampleViewport v;
    v.configure(100000.0, 800.0);
    v.first = 0.0;
    v.samplesPerPixel = 120.0;   // 120 project samples = 55 file samples per pixel (finer than the 221-sample overview)
    std::vector<ColumnPeak> cols;
    columnPeaks(piece, v, 0U, 0U, 800U, cols);
    require(!cols[0].valid, "before the piece nothing is drawn");   // x = 0 .. 120 covers 0..120 < start 1000
    require(cols[20].valid, "inside the piece there is data");
    // Brute force check of one column against the real samples.
    {
        const std::size_t c = 300U;
        const double n0 = piece.nativePosition(v.sampleAtX(static_cast<double>(c)));
        const double n1 = piece.nativePosition(v.sampleAtX(static_cast<double>(c) + 1.0));
        float mn = 9.0F, mx = -9.0F;
        for (long long i = static_cast<long long>(std::floor(n0)); i <= std::max<long long>(static_cast<long long>(std::floor(n0)) + 1, static_cast<long long>(std::ceil(n1))); ++i) {
            mn = std::min(mn, detail.audio.sample(0U, static_cast<std::size_t>(i)));
            mx = std::max(mx, detail.audio.sample(0U, static_cast<std::size_t>(i)));
        }
        require(cols[c].valid && cols[c].minimum == mn && cols[c].maximum == mx, "detail column must equal the brute-force min/max");
    }
    // Zoomed far out, the overview is used (cheap) and still brackets the real signal.
    v.samplesPerPixel = 2000.0;
    columnPeaks(piece, v, 0U, 0U, 50U, cols);
    require(cols[10].valid && cols[10].maximum <= 1.0F && cols[10].minimum >= -1.0F, "overview columns");
    // Beyond the end of the piece.
    v.first = 1.0e6;
    columnPeaks(piece, v, 0U, 0U, 10U, cols);
    require(!cols[0].valid, "after the piece nothing is drawn");

    // Without detail and overview nothing is valid, and nothing crashes.
    PieceView empty = piece;
    empty.overview = nullptr; empty.detail = nullptr;
    columnPeaks(empty, v, 0U, 0U, 10U, cols);
    require(!cols[0].valid, "no data, no columns");

    // Samples at extreme zoom: pixels per file sample and interpolation.
    v.samplesPerPixel = SampleViewport::kMinSamplesPerPixel;
    require(pixelsPerFileSample(piece, v) > 50.0, "individual samples are huge at maximum zoom");
    float value = 0.0F;
    const double rel = piece.relPosition(100.0);
    require(interpolatedSample(piece, 0U, rel, value) && near(value, detail.audio.sample(0U, 100U), 1.0e-5), "exact at a file sample");
    const double mid = piece.relPosition(100.5);
    require(interpolatedSample(piece, 0U, mid, value) &&
                near(value, 0.5 * (detail.audio.sample(0U, 100U) + detail.audio.sample(0U, 101U)), 1.0e-5),
            "linear halfway between two file samples");
    require(!interpolatedSample(empty, 0U, rel, value), "no interpolation without samples");
}

void testPeakAndZeroCrossing() {
    WaveformDetail detail;
    detail.sampleRate = 48000U;
    detail.audio = AudioBuffer(1U, 4800U);
    for (std::size_t i = 0U; i < 4800U; ++i) detail.audio.sample(0U, i) = 0.25F * static_cast<float>(std::sin(static_cast<double>(i) * 0.1));
    detail.audio.sample(0U, 2000U) = -0.9F;
    PieceView piece;
    piece.startRel = 0.0; piece.length = 4800.0; piece.sourceStart = 0.0; piece.projectRate = 48000.0;
    piece.detail = &detail;
    require(near(peakInRange(piece, 1900.0, 2100.0), 0.9, 1.0e-6), "peak finds the loud sample");
    require(near(peakInRange(piece, 0.0, 1000.0), 0.25, 0.01), "peak of a quiet part");
    require(peakInRange(piece, 9000.0, 9100.0) < 0.0F, "outside the piece the peak is unknown");

    // sin(0.1 i) crosses zero near i = 31.4159 (pi/0.1).
    const double zc = nearestZeroCrossing(piece, 25.0, 40.0);
    require(near(zc, 31.4159, 0.2), "zero crossing found at the right place");
    require(nearestZeroCrossing(piece, 25.0, 3.0) == 25.0, "no crossing within reach keeps the position");
    PieceView none = piece; none.detail = nullptr;
    require(nearestZeroCrossing(none, 25.0, 40.0) == 25.0, "without samples the position is unchanged");
}
} // namespace

int main() {
    try {
        testViewport();
        testRuler();
        testColumnPeaks();
        testPeakAndZeroCrossing();
        std::cout << "sample editor model tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
