#include "silveton/ProjectSession.h"
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace { void require(bool c,const char*m){if(!c)throw std::runtime_error(m);} }

int main(){
    using namespace silveton;
    const std::string path="/tmp/SilvetonSessionTest.silveton";
    (void)std::remove(path.c_str());(void)std::remove(ProjectRecovery::backupPath(path).c_str());(void)std::remove(ProjectRecovery::autosavePath(path).c_str());
    try{
        ProjectSession s(48000.0,8U);int rebuilds=0,beforeSave=0;s.setRuntimeRebuildCallback([&]{++rebuilds;});s.setBeforeSaveCallback([&]{++beforeSave;});
        s.beginEdit("Add track");ProjectTrack t;t.name="Vocal";s.project().tracks.push_back(t);s.commitEdit();
        require(s.dirty()&&s.history().canUndo()&&rebuilds==1,"session edit/history wiring failed");
        require(s.undo()&&s.project().tracks.empty()&&s.dirty(),"session undo failed");
        require(s.redo()&&s.project().tracks.size()==1U,"session redo failed");
        s.saveAs(path);require(!s.dirty()&&s.projectPath()==path&&beforeSave==1,"session saveAs failed");
        s.beginEdit("Rename");s.project().tracks[0].name="Lead Vocal";s.commitEdit();
        s.setAutosaveIntervalSeconds(10.0);require(!s.serviceAutosave(100.0),"autosave fired before interval arm");require(!s.serviceAutosave(109.0),"autosave fired too early");require(s.serviceAutosave(110.0),"autosave did not fire at interval");
        require(beforeSave==2,"autosave did not capture runtime state");
        {std::ofstream broken(path.c_str(),std::ios::trunc);broken<<"BROKEN\n";}
        ProjectSession restored;auto lr=restored.open(path);require(lr.recovered&&lr.source==ProjectRecoverySource::Autosave,"session did not recover autosave");require(restored.project().tracks.size()==1U&&restored.project().tracks[0].name=="Lead Vocal","recovered session content mismatch");require(restored.dirty(),"recovered project must remain dirty until explicit save");
        restored.newProject(44100.0);require(!restored.dirty()&&!restored.hasProjectPath()&&restored.project().sampleRate==44100.0,"new project reset failed");
        (void)std::remove(path.c_str());(void)std::remove(ProjectRecovery::backupPath(path).c_str());(void)std::remove(ProjectRecovery::autosavePath(path).c_str());
        std::cout<<"PASS: project session safe save/recovery/autosave/global undo runtime wiring\n";return 0;
    }catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}
}
