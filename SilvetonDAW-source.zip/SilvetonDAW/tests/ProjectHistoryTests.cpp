#include "silveton/ProjectHistory.h"
#include <iostream>
#include <stdexcept>

namespace {
void require(bool condition, const char* message) { if (!condition) throw std::runtime_error(message); }
}

int main() {
    using namespace silveton;
    try {
        Project project;
        project.sampleRate = 48000.0;
        project.tracks.resize(1U);
        project.tracks[0].name = "Lead";
        project.tracks[0].gainDb = 0.0F;
        project.buses.resize(1U);
        project.buses[0].name = "Group";
        project.midiTracks.resize(1U);
        project.midiTracks[0].name = "MIDI";

        ProjectHistory history(project, 3U);
        int applied = 0;
        history.setApplyCallback([&] { ++applied; });

        history.begin("Mixer move");
        project.tracks[0].gainDb = -6.0F;
        project.tracks[0].pan = 0.4F;
        project.tracks[0].outputBus = 0;
        project.buses[0].gainDb = -2.0F;
        project.masterFaderDb = -1.0F;
        history.commit();
        require(history.canUndo() && history.undoLabel() == "Mixer move", "project history did not capture mixer transaction");

        history.begin("Arrangement and MIDI");
        ProjectAudioClip clip;
        clip.id = 1U;
        clip.audioPath = "/tmp/a.wav";
        clip.lengthSamples = 100U;
        clip.sourceFrames = 100U;
        project.tracks[0].clips.push_back(clip);
        MidiPart part;
        part.id = 1U;
        part.lengthQuarterNotes = 4.0;
        project.midiTracks[0].parts.push_back(part);
        history.commit();

        require(history.undo(), "project history first undo failed");
        require(project.tracks[0].clips.empty() && project.midiTracks[0].parts.empty(), "project history did not restore arrangement/MIDI snapshot");
        require(project.tracks[0].gainDb == -6.0F && project.tracks[0].outputBus == 0, "project history first undo damaged prior mixer state");
        require(history.redo(), "project history redo failed");
        require(project.tracks[0].clips.size() == 1U && project.midiTracks[0].parts.size() == 1U, "project history redo did not restore arrangement/MIDI");
        require(applied == 2, "project history apply callback count mismatch");

        history.begin("Cancelled edit");
        project.tracks[0].mute = true;
        history.cancel();
        require(!project.tracks[0].mute, "project history cancel did not restore project");
        require(applied == 3, "project history cancel did not notify runtime rebuild");

        history.begin("New edit after undo");
        project.tracks[0].name = "Lead Vox";
        history.commit();
        require(!history.canRedo(), "new project transaction did not clear redo history");

        history.begin("One"); project.masterFaderDb = -2.0F; history.commit();
        history.begin("Two"); project.masterFaderDb = -3.0F; history.commit();
        history.begin("Three"); project.masterFaderDb = -4.0F; history.commit();
        history.begin("Four"); project.masterFaderDb = -5.0F; history.commit();
        int undoCount = 0;
        while (history.undo()) ++undoCount;
        require(undoCount == 3, "project history capacity was not enforced");

        std::cout << "PASS: global project Undo/Redo groups mixer/routing/arrangement/MIDI edits and publishes restored state\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
