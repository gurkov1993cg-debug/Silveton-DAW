#include "silveton/Vst3Host.h"
#include "silveton/Vst3ScannerIsolation.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

void clear(std::vector<float>& v) { std::fill(v.begin(), v.end(), 0.0F); }
}

int main(int argc, char** argv) {
    try {
        require(argc == 3, "usage: vst3_host_integration <plugin.vst3> <scanner>");
        const std::string pluginPath = argv[1];
        const std::string scannerPath = argv[2];

        silveton::Vst3Host host;
        std::string reason;
        const auto scanned = host.scanModule(pluginPath, reason);
        require(reason.empty(), "direct module scan failed");
        require(scanned.size() == 3U, "fixture must expose host-test, 8-channel layout and multi-output instrument classes");
        const auto mainIt = std::find_if(scanned.begin(), scanned.end(), [](const auto& p) { return p.name == "Silveton Host Test"; });
        const auto layoutIt = std::find_if(scanned.begin(), scanned.end(), [](const auto& p) { return p.name == "Silveton Layout 8ch Test"; });
        const auto instrumentIt = std::find_if(scanned.begin(), scanned.end(), [](const auto& p) { return p.name == "Silveton MultiOut Instrument Test"; });
        require(mainIt != scanned.end() && layoutIt != scanned.end() && instrumentIt != scanned.end(), "fixture class discovery mismatch");

        silveton::Vst3Blacklist blacklist;
        const auto isolated = silveton::scanVst3ModuleIsolated(scannerPath, pluginPath, 10000U, blacklist);
        require(!isolated.crashedOrFailed && isolated.plugins.size() == 3U, "isolated real VST3 scan failed");

        auto layout = host.create(pluginPath, layoutIt->classId, reason);
        require(layout != nullptr, "8-channel layout instance creation failed");
        require(layout->inputBusCount() == 1U && layout->inputBusChannelCount(0U) == 2U, "8-channel fixture input layout mismatch");
        require(layout->outputBusCount() == 1U && layout->outputBusChannelCount(0U) == 8U, "8-channel fixture output layout mismatch");

        auto instrument = host.create(pluginPath, instrumentIt->classId, reason);
        require(instrument != nullptr, "zero-input multi-output VST3 instrument creation failed");
        instrument->prepare(48000.0, 64U);
        require(instrument->inputBusCount() == 0U, "VST3 instrument unexpectedly exposes an audio input bus");
        require(instrument->outputBusCount() == 4U, "VST3 instrument does not expose four output buses");
        require(instrument->queueMidi({0, 0x90U, 60U, 100U}), "VST3 instrument MIDI queue rejected note");
        std::array<std::array<float, 16>, 8> instrumentChannels {};
        std::array<silveton::StereoBus, 4> instrumentOutputs {{{instrumentChannels[0].data(), instrumentChannels[1].data()},
                                                               {instrumentChannels[2].data(), instrumentChannels[3].data()},
                                                               {instrumentChannels[4].data(), instrumentChannels[5].data()},
                                                               {instrumentChannels[6].data(), instrumentChannels[7].data()}}};
        silveton::ProcessorContext instrumentContext;
        instrumentContext.sampleRate = 48000.0; instrumentContext.frames = 16U; instrumentContext.playing = true;
        require(instrument->processBuses(nullptr, 0U, instrumentOutputs.data(), instrumentOutputs.size(), 16U, instrumentContext),
                "zero-input VST3 instrument processing failed");
        for (std::uint32_t i = 0; i < 16U; ++i) {
            require(std::abs(instrumentChannels[0][i] - 0.1F) < 1.0e-6F, "instrument main output mismatch");
            require(std::abs(instrumentChannels[2][i] - 0.2F) < 1.0e-6F, "instrument output 2 mismatch");
            require(std::abs(instrumentChannels[4][i] - 0.3F) < 1.0e-6F, "instrument output 3 mismatch");
            require(std::abs(instrumentChannels[6][i] - 0.4F) < 1.0e-6F, "instrument output 4 mismatch");
        }

        auto instance = host.create(pluginPath, mainIt->classId, reason);
        require(instance != nullptr && reason.empty(), "VST3 instance creation failed");
        require(instance->inputBusCount() == 2U, "fixture sidechain input bus was not exposed");
        require(instance->inputBusChannelCount(0U) == 2U && instance->inputBusChannelCount(1U) == 1U,
                "stereo main / mono sidechain layout mismatch");
        require(instance->outputBusCount() == 4U, "fixture multi-output buses were not exposed");
        for (std::size_t b = 0U; b < 4U; ++b) require(instance->outputBusChannelCount(b) == 2U, "fixture stereo output layout mismatch");
        require(instance->hasEventInput(), "fixture MIDI event input missing");
        instance->prepare(48000.0, 64U);
        require(instance->latencySamples() == 0U, "fixture initial latency must be zero");

        constexpr std::uint32_t frames = 16U;
        std::vector<float> mainL(frames, 1.0F), mainR(frames, -1.0F);
        std::vector<float> sideL(frames, 0.25F), sideR(frames, 0.25F);
        std::array<silveton::ConstStereoBus, 2U> inputs {{{mainL.data(), mainR.data()}, {sideL.data(), sideR.data()}}};
        std::array<std::vector<float>, 8U> channels;
        for (auto& c : channels) c.assign(frames, 0.0F);
        std::array<silveton::StereoBus, 4U> outputs {{{channels[0].data(),channels[1].data()},
                                                      {channels[2].data(),channels[3].data()},
                                                      {channels[4].data(),channels[5].data()},
                                                      {channels[6].data(),channels[7].data()}}};
        silveton::ProcessorContext context;
        context.sampleRate = 48000.0; context.frames = frames; context.tempo = 123.0; context.playing = true;
        context.projectSample = 96000; context.projectQuarterNotes = 4.0;
        require(instance->processBuses(inputs.data(), inputs.size(), outputs.data(), outputs.size(), frames, context), "VST3 sidechain/multiout process failed");
        for (std::uint32_t i = 0; i < frames; ++i) {
            require(std::abs(channels[0][i] - 1.25F) < 1.0e-6F, "main+sidechain left mismatch");
            require(std::abs(channels[1][i] + 0.75F) < 1.0e-6F, "main+sidechain right mismatch");
            require(std::abs(channels[2][i] - 2.50F) < 1.0e-6F, "output bus 2 mismatch");
            require(std::abs(channels[4][i] - 3.75F) < 1.0e-6F, "output bus 3 mismatch");
            require(std::abs(channels[6][i] - 5.00F) < 1.0e-6F, "output bus 4 mismatch");
        }

        // Sample-accurate automation: fixture gain parameter id 100 changes at frame 8.
        for (auto& c : channels) clear(c);
        require(instance->queueParameter(100U, 0.5, 8), "queueParameter rejected frame-8 point");
        require(instance->processBuses(inputs.data(), inputs.size(), outputs.data(), outputs.size(), frames, context), "automation process failed");
        for (std::uint32_t i = 0; i < frames; ++i) {
            const float g = i < 8U ? 1.0F : 0.5F;
            require(std::abs(channels[0][i] - 1.25F * g) < 1.0e-6F, "automation was not sample-accurate at frame 8");
        }

        silveton::Vst3OutputParameterChange meter;
        require(instance->popOutputParameter(meter), "plugin-generated output parameter was not captured");
        require(meter.parameterId == 101U, "wrong plugin-generated parameter id");

        // MIDI event must traverse host->plug-in and plug-in->host with exact sample offset.
        silveton::Vst3MidiEvent note {4, 0x90U, 60U, 100U};
        require(instance->queueMidi(note), "MIDI input queue rejected note");
        for (auto& c : channels) clear(c);
        require(instance->processBuses(inputs.data(), inputs.size(), outputs.data(), outputs.size(), frames, context), "MIDI process failed");
        silveton::Vst3MidiEvent echoed;
        require(instance->popMidiOutput(echoed), "plugin MIDI output was not captured");
        require(echoed.frameOffset == 4 && echoed.status == 0x90U && echoed.data1 == 60U && echoed.data2 == 100U,
                "MIDI output event changed in transit");

        // Component/controller state round trip into a fresh instance.
        const auto componentState = instance->componentState();
        const auto controllerState = instance->controllerState();
        require(!componentState.empty() && !controllerState.empty(), "VST3 state blobs are empty");
        const std::string presetPath = "/tmp/SilvetonHostTest.vstpreset";
        (void)std::remove(presetPath.c_str());
        require(instance->savePreset(presetPath), "standard .vstpreset save failed");
        require(instance->queueParameter(100U, 0.2, 0), "preset mutation parameter queue failed");
        for (auto& c : channels) clear(c);
        require(instance->processBuses(inputs.data(), inputs.size(), outputs.data(), outputs.size(), frames, context),
                "preset mutation process failed");
        require(std::abs(channels[0][0] - 0.25F) < 1.0e-6F, "preset mutation did not change processor state");
        require(instance->loadPreset(presetPath), "standard .vstpreset load failed");
        for (auto& c : channels) clear(c);
        require(instance->processBuses(inputs.data(), inputs.size(), outputs.data(), outputs.size(), frames, context),
                "preset-restored process failed");
        require(std::abs(channels[0][0] - 0.625F) < 1.0e-6F, ".vstpreset did not restore processor state");
        (void)std::remove(presetPath.c_str());
        auto restored = host.create(pluginPath, mainIt->classId, reason);
        require(restored != nullptr, "second VST3 instance creation failed");
        require(restored->setComponentState(componentState), "component state restore failed");
        require(restored->setControllerState(controllerState), "controller state restore failed");
        restored->prepare(48000.0, 64U);
        for (auto& c : channels) clear(c);
        require(restored->processBuses(inputs.data(), inputs.size(), outputs.data(), outputs.size(), frames, context), "restored instance process failed");
        require(std::abs(channels[0][0] - 0.625F) < 1.0e-6F, "restored component gain state mismatch");

#if defined(__APPLE__)
        // The fixture editor signals a real kLatencyChanged restart and sets processor latency to 512.
        require(restored->openEditor(), "Cocoa VST3 editor did not open");
        require(restored->editorOpen(), "editor open-state mismatch");
        silveton::AutomationGesture g0 {}, g1 {}, g2 {};
        require(restored->popAutomationGesture(g0) && restored->popAutomationGesture(g1) && restored->popAutomationGesture(g2),
                "editor begin/perform/end automation gesture bridge failed");
        require(g0.type == silveton::AutomationGestureType::Begin &&
                g1.type == silveton::AutomationGestureType::Value && std::abs(g1.normalized - 0.75) < 1.0e-12 &&
                g2.type == silveton::AutomationGestureType::End, "editor automation gesture content mismatch");
        const auto restart = restored->consumeRestartFlags();
        require((restart & silveton::Vst3RestartLatencyChanged) != 0U, "kLatencyChanged was not propagated to host");
        require((restart & silveton::Vst3RestartIoChanged) != 0U, "IComponentHandlerBusActivation request was not serviced");
        require(restored->serviceLatencyChange(), "VST3 latency-change deactivate/reactivate service failed");
        require(restored->reconfigureAfterIoChange(), "VST3 I/O-change reconfiguration service failed");
        require(restored->latencySamples() == 512U, "dynamic VST3 latency was not refreshed");
        restored->closeEditor();
        require(!restored->editorOpen(), "editor did not close cleanly");
        for (int i = 0; i < 100; ++i) {
            require(restored->openEditor(), "editor lifecycle stress open failed");
            restored->closeEditor();
        }
#endif

        // Real Project V14 -> VST3 runtime rack restore, including MIDI binding,
        // unavailable-slot state preservation, automation and processor-originated state.
        silveton::Project project;
        silveton::ProjectTrack track;
        track.name = "Host Integration Track";
        silveton::ProjectPluginSlot slot;
        slot.modulePath = pluginPath;
        slot.classId = mainIt->classId;
        slot.enabled = true;
        slot.midiInputPort = 11;
        slot.componentState = componentState;
        slot.controllerState = controllerState;
        silveton::ProjectPluginAutomationLane gainLane;
        gainLane.parameterId = 100U;
        gainLane.mode = silveton::AutomationMode::Touch;
        gainLane.lane.write(0, 0.5);
        gainLane.lane.write(8, 0.75);
        slot.automation.push_back(gainLane);
        track.pluginSlots.push_back(slot);
        project.tracks.push_back(track);
        silveton::ProjectBus missingBus;
        missingBus.name = "Missing Plug-in Bus";
        silveton::ProjectPluginSlot missingSlot = slot;
        missingSlot.modulePath = "/definitely/missing/SilvetonMissing.vst3";
        missingSlot.classId = "00000000000000000000000000000000";
        missingSlot.midiInputPort = -1;
        missingBus.pluginSlots.push_back(missingSlot);
        project.buses.push_back(missingBus);

        silveton::Vst3RuntimeRack rack(host);
        rack.restore(project);
        require(rack.trackSlotStatus(0U, 0U).available, "real VST3 Project V14 slot did not restore");
        require(!rack.busSlotStatus(0U, 0U).available, "missing VST3 slot was not preserved as unavailable");
        require(project.buses[0].pluginSlots[0].componentState == missingSlot.componentState &&
                project.buses[0].pluginSlots[0].controllerState == missingSlot.controllerState,
                "unavailable VST3 slot lost opaque state");
        auto* rackInstance = rack.instanceForMidiPort(11);
        require(rackInstance != nullptr, "Project V14 MIDI input port did not bind to live VST3 instance");
        const auto graphNode = rack.trackNodeDefinition(0U);
        require(graphNode.processors.size() == 1U && graphNode.processors[0].processor == rackInstance,
                "restored VST3 instance was not inserted into processor chain");
        rackInstance->prepare(48000.0, 64U);
        rack.queueAutomationForBlock(0, frames);
        for (auto& c : channels) clear(c);
        require(rackInstance->processBuses(inputs.data(), inputs.size(), outputs.data(), outputs.size(), frames, context),
                "Project V14 restored VST3 process failed");
        require(std::abs(channels[0][0] - 0.625F) < 1.0e-6F &&
                std::abs(channels[0][8] - 0.9375F) < 1.0e-6F,
                "Project V14 automation was not sample-accurate through live VST3 instance");
        rack.serviceOutputParameters();
        require(rack.trackOutputParameterValue(0U, 0U, 101U, -1.0) >= 0.0,
                "processor-originated VST3 parameter was not reflected in DAW runtime state");
        require(rackInstance->queueMidi({3, 0x90U, 67U, 120U}), "runtime-rack MIDI queue failed");
        for (auto& c : channels) clear(c);
        require(rackInstance->processBuses(inputs.data(), inputs.size(), outputs.data(), outputs.size(), frames, context),
                "runtime-rack MIDI process failed");
        silveton::Vst3MidiEvent rackMidi {};
        require(rack.popMidiOutputForPort(11, rackMidi) && rackMidi.frameOffset == 3 && rackMidi.data1 == 67U,
                "runtime-rack plugin MIDI output routing failed");
        rack.captureStateToProject();
        require(!project.tracks[0].pluginSlots[0].componentState.empty() &&
                !project.tracks[0].pluginSlots[0].controllerState.empty(),
                "runtime-rack state capture back to Project V14 failed");

        std::cout << "PASS: VST3 direct + isolated scan + 8-channel layout + zero-input instrument discovery\n";
        std::cout << "PASS: VST3 real sidechain + four output buses\n";
        std::cout << "PASS: VST3 zero-input multi-output instrument\n";
        std::cout << "PASS: VST3 sample-accurate automation + output parameter changes\n";
        std::cout << "PASS: VST3 MIDI input/output\n";
        std::cout << "PASS: VST3 component/controller state round trip\n";
        std::cout << "PASS: VST3 standard .vstpreset save/load\n";
        std::cout << "PASS: Project V14 real runtime restore + unavailable slot + MIDI/automation state\n";
#if defined(__APPLE__)
        std::cout << "PASS: VST3 dynamic latency restart + Cocoa editor 100x lifecycle\n";
#endif
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
