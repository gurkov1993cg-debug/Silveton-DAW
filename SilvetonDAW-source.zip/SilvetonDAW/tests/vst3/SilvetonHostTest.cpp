#include "public.sdk/source/common/pluginview.h"
#include "public.sdk/source/vst/vstaudioeffect.h"
#include "public.sdk/source/vst/vsteditcontroller.h"
#include "base/source/fstreamer.h"
#include "pluginterfaces/vst/ivstevents.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "pluginterfaces/vst/vstspeaker.h"
#include "public.sdk/source/main/pluginfactory.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstring>
#include <vector>

namespace Steinberg::Vst {
namespace {
static DECLARE_UID(TestProcessorUID, 0xA41E89F1, 0x34E54B61, 0xA1C04321, 0x0BEE1001);
static DECLARE_UID(TestControllerUID, 0xB52F9A02, 0x45F64C72, 0xB2D15432, 0x1CFF2002);
static DECLARE_UID(Layout8ProcessorUID, 0xC630AB13, 0x56A75D83, 0xC3E26543, 0x2D003003);
static DECLARE_UID(InstrumentProcessorUID, 0xD741BC24, 0x67B86E94, 0xD4F37654, 0x3E114114);
constexpr ParamID kGainId = 100U;
constexpr ParamID kMeterId = 101U;
constexpr std::uint32_t kMaxLatency = 512U;
}

class SilvetonHostTestProcessor final : public AudioEffect {
public:
    SilvetonHostTestProcessor() { setControllerClass(TestControllerUID); }
    static FUnknown* create(void*) { return static_cast<IAudioProcessor*>(new SilvetonHostTestProcessor()); }

    tresult PLUGIN_API initialize(FUnknown* context) override {
        const auto r = AudioEffect::initialize(context);
        if (r != kResultOk) return r;
        addAudioInput(STR16("Main In"), SpeakerArr::kStereo, kMain, BusInfo::kDefaultActive);
        addAudioInput(STR16("Sidechain"), SpeakerArr::kMono, kAux, 0);
        addAudioOutput(STR16("Main Out"), SpeakerArr::kStereo, kMain, BusInfo::kDefaultActive);
        addAudioOutput(STR16("Out 2"), SpeakerArr::kStereo, kAux, 0);
        addAudioOutput(STR16("Out 3"), SpeakerArr::kStereo, kAux, 0);
        addAudioOutput(STR16("Out 4"), SpeakerArr::kStereo, kAux, 0);
        addEventInput(STR16("MIDI In"), 16, kMain, BusInfo::kDefaultActive);
        addEventOutput(STR16("MIDI Out"), 16, kMain, BusInfo::kDefaultActive);
        return kResultOk;
    }

    tresult PLUGIN_API setupProcessing(ProcessSetup& setup) override {
        delayL_.assign(kMaxLatency + static_cast<std::uint32_t>(setup.maxSamplesPerBlock) + 1U, 0.0F);
        delayR_.assign(delayL_.size(), 0.0F);
        delayPos_ = 0U;
        return AudioEffect::setupProcessing(setup);
    }

    tresult PLUGIN_API setActive(TBool state) override {
        if (state) {
            std::fill(delayL_.begin(), delayL_.end(), 0.0F);
            std::fill(delayR_.begin(), delayR_.end(), 0.0F);
            delayPos_ = 0U;
        }
        return AudioEffect::setActive(state);
    }

    uint32 PLUGIN_API getLatencySamples() override { return latency_.load(std::memory_order_acquire); }

    tresult PLUGIN_API process(ProcessData& data) override {
        struct Point { int32 offset; double value; };
        std::array<Point, 64> gainPoints {};
        std::size_t pointCount = 0U;
        if (data.inputParameterChanges) {
            const int32 n = data.inputParameterChanges->getParameterCount();
            for (int32 q = 0; q < n; ++q) {
                auto* queue = data.inputParameterChanges->getParameterData(q);
                if (!queue || queue->getParameterId() != kGainId) continue;
                const int32 pc = queue->getPointCount();
                for (int32 p = 0; p < pc && pointCount < gainPoints.size(); ++p) {
                    int32 offset = 0; ParamValue value = 0.0;
                    if (queue->getPoint(p, offset, value) == kResultTrue)
                        gainPoints[pointCount++] = {offset, std::clamp(value, 0.0, 1.0)};
                }
            }
        }

        if (data.inputEvents && data.outputEvents) {
            const int32 n = data.inputEvents->getEventCount();
            for (int32 i = 0; i < n; ++i) {
                Event e {};
                if (data.inputEvents->getEvent(i, e) == kResultTrue &&
                    (e.type == Event::kNoteOnEvent || e.type == Event::kNoteOffEvent || e.type == Event::kPolyPressureEvent))
                    (void)data.outputEvents->addEvent(e);
            }
        }

        if (data.numOutputs <= 0 || data.outputs == nullptr) return kResultOk;
        const bool haveMainIn = data.numInputs > 0 && data.inputs && data.inputs[0].numChannels > 0;
        const bool haveSide = data.numInputs > 1 && data.inputs[1].numChannels > 0;
        float* mainL = haveMainIn ? data.inputs[0].channelBuffers32[0] : nullptr;
        float* mainR = (haveMainIn && data.inputs[0].numChannels > 1) ? data.inputs[0].channelBuffers32[1] : mainL;
        float* side = haveSide ? data.inputs[1].channelBuffers32[0] : nullptr;

        double gain = gain_.load(std::memory_order_relaxed);
        std::size_t nextPoint = 0U;
        float meter = 0.0F;
        const std::uint32_t latency = latency_.load(std::memory_order_acquire);
        for (int32 i = 0; i < data.numSamples; ++i) {
            while (nextPoint < pointCount && gainPoints[nextPoint].offset == i) {
                gain = gainPoints[nextPoint].value;
                gain_.store(gain, std::memory_order_relaxed);
                ++nextPoint;
            }
            const float l = (mainL ? mainL[i] : 0.0F) + (side ? side[i] : 0.0F);
            const float r = (mainR ? mainR[i] : 0.0F) + (side ? side[i] : 0.0F);
            const float processedL = static_cast<float>(l * gain);
            const float processedR = static_cast<float>(r * gain);
            float delayedL = processedL;
            float delayedR = processedR;
            if (latency > 0U && !delayL_.empty()) {
                const std::size_t readPos = (delayPos_ + delayL_.size() - latency) % delayL_.size();
                delayedL = delayL_[readPos];
                delayedR = delayR_[readPos];
                delayL_[delayPos_] = processedL;
                delayR_[delayPos_] = processedR;
                delayPos_ = (delayPos_ + 1U) % delayL_.size();
            }
            meter = std::max(meter, std::max(std::abs(delayedL), std::abs(delayedR)));
            for (int32 b = 0; b < data.numOutputs; ++b) {
                auto& bus = data.outputs[b];
                const float scale = static_cast<float>(b + 1);
                if (bus.numChannels > 0 && bus.channelBuffers32[0]) bus.channelBuffers32[0][i] = delayedL * scale;
                if (bus.numChannels > 1 && bus.channelBuffers32[1]) bus.channelBuffers32[1][i] = delayedR * scale;
            }
        }

        if (data.outputParameterChanges) {
            int32 queueIndex = 0;
            if (auto* q = data.outputParameterChanges->addParameterData(kMeterId, queueIndex)) {
                int32 pointIndex = 0;
                (void)q->addPoint(std::max(0, data.numSamples - 1), std::clamp<double>(meter, 0.0, 1.0), pointIndex);
            }
        }
        return kResultOk;
    }

    tresult PLUGIN_API setState(IBStream* state) override {
        IBStreamer s(state, kLittleEndian);
        double gain = 1.0;
        int32 latency = 0;
        if (!s.readDouble(gain) || !s.readInt32(latency)) return kResultFalse;
        gain_.store(std::clamp(gain, 0.0, 1.0), std::memory_order_relaxed);
        latency_.store(static_cast<uint32>(std::clamp<int32>(latency, 0, static_cast<int32>(kMaxLatency))), std::memory_order_release);
        return kResultTrue;
    }
    tresult PLUGIN_API getState(IBStream* state) override {
        IBStreamer s(state, kLittleEndian);
        return s.writeDouble(gain_.load(std::memory_order_relaxed)) &&
               s.writeInt32(static_cast<int32>(latency_.load(std::memory_order_acquire))) ? kResultTrue : kResultFalse;
    }

    tresult receiveText(const char8* text) override {
        if (text && std::strcmp(text, "latency512") == 0) {
            latency_.store(kMaxLatency, std::memory_order_release);
            return kResultTrue;
        }
        return AudioEffect::receiveText(text);
    }

private:
    std::atomic<double> gain_ {1.0};
    std::atomic<uint32> latency_ {0U};
    std::vector<float> delayL_;
    std::vector<float> delayR_;
    std::size_t delayPos_ {0U};
};

class SilvetonLayout8Processor final : public AudioEffect {
public:
    SilvetonLayout8Processor() { setControllerClass(TestControllerUID); }
    static FUnknown* create(void*) { return static_cast<IAudioProcessor*>(new SilvetonLayout8Processor()); }
    tresult PLUGIN_API initialize(FUnknown* context) override {
        const auto r = AudioEffect::initialize(context);
        if (r != kResultOk) return r;
        addAudioInput(STR16("Stereo In"), SpeakerArr::kStereo, kMain, BusInfo::kDefaultActive);
        addAudioOutput(STR16("7.1 Out"), SpeakerArr::k71Music, kMain, BusInfo::kDefaultActive);
        return kResultOk;
    }
    tresult PLUGIN_API process(ProcessData& data) override {
        if (data.numOutputs > 0 && data.outputs != nullptr) {
            for (int32 b = 0; b < data.numOutputs; ++b) {
                for (int32 c = 0; c < data.outputs[b].numChannels; ++c) {
                    if (data.outputs[b].channelBuffers32[c] != nullptr)
                        std::fill_n(data.outputs[b].channelBuffers32[c], data.numSamples, 0.0F);
                }
            }
        }
        return kResultOk;
    }
};

class SilvetonInstrumentProcessor final : public AudioEffect {
public:
    SilvetonInstrumentProcessor() { setControllerClass(TestControllerUID); }
    static FUnknown* create(void*) { return static_cast<IAudioProcessor*>(new SilvetonInstrumentProcessor()); }
    tresult PLUGIN_API initialize(FUnknown* context) override {
        const auto r = AudioEffect::initialize(context);
        if (r != kResultOk) return r;
        // A true generator: no audio input buses.
        addAudioOutput(STR16("Main Out"), SpeakerArr::kStereo, kMain, BusInfo::kDefaultActive);
        addAudioOutput(STR16("Out 2"), SpeakerArr::kStereo, kAux, 0);
        addAudioOutput(STR16("Out 3"), SpeakerArr::kStereo, kAux, 0);
        addAudioOutput(STR16("Out 4"), SpeakerArr::kStereo, kAux, 0);
        addEventInput(STR16("MIDI In"), 16, kMain, BusInfo::kDefaultActive);
        return kResultOk;
    }
    tresult PLUGIN_API process(ProcessData& data) override {
        if (data.inputEvents) {
            const int32 n = data.inputEvents->getEventCount();
            for (int32 i = 0; i < n; ++i) {
                Event e {};
                if (data.inputEvents->getEvent(i, e) != kResultTrue) continue;
                if (e.type == Event::kNoteOnEvent && e.noteOn.velocity > 0.0F) gate_ = true;
                else if (e.type == Event::kNoteOffEvent) gate_ = false;
            }
        }
        if (data.numOutputs <= 0 || data.outputs == nullptr) return kResultOk;
        for (int32 b = 0; b < data.numOutputs; ++b) {
            const float value = gate_ ? 0.1F * static_cast<float>(b + 1) : 0.0F;
            auto& bus = data.outputs[b];
            for (int32 c = 0; c < bus.numChannels; ++c) {
                if (bus.channelBuffers32[c]) std::fill_n(bus.channelBuffers32[c], data.numSamples, c == 0 ? value : -value);
            }
        }
        return kResultOk;
    }
private:
    bool gate_ {false};
};

class SilvetonHostTestController;
class SilvetonHostTestView final : public CPluginView {
public:
    explicit SilvetonHostTestView(SilvetonHostTestController* controller);
    tresult PLUGIN_API isPlatformTypeSupported(FIDString type) override {
        return type && std::strcmp(type, kPlatformTypeNSView) == 0 ? kResultTrue : kResultFalse;
    }
    tresult PLUGIN_API attached(void* parent, FIDString type) override;
private:
    SilvetonHostTestController* controller_ {nullptr};
};

class SilvetonHostTestController final : public EditController {
public:
    static FUnknown* create(void*) { return static_cast<IEditController*>(new SilvetonHostTestController()); }
    tresult PLUGIN_API initialize(FUnknown* context) override {
        const auto r = EditController::initialize(context);
        if (r != kResultOk) return r;
        parameters.addParameter(STR16("Gain"), nullptr, 0, 1.0, ParameterInfo::kCanAutomate, kGainId);
        parameters.addParameter(STR16("Meter"), nullptr, 0, 0.0, ParameterInfo::kIsReadOnly, kMeterId);
        return kResultOk;
    }
    tresult PLUGIN_API setComponentState(IBStream* state) override {
        IBStreamer s(state, kLittleEndian);
        double gain = 1.0; int32 latency = 0;
        if (!s.readDouble(gain) || !s.readInt32(latency)) return kResultFalse;
        (void)latency;
        return setParamNormalized(kGainId, std::clamp(gain, 0.0, 1.0));
    }
    tresult PLUGIN_API setState(IBStream* state) override {
        IBStreamer s(state, kLittleEndian);
        int32 value = 0;
        if (!s.readInt32(value)) return kResultFalse;
        uiState_ = static_cast<uint32>(value);
        return kResultTrue;
    }
    tresult PLUGIN_API getState(IBStream* state) override {
        IBStreamer s(state, kLittleEndian);
        return s.writeInt32(static_cast<int32>(uiState_)) ? kResultTrue : kResultFalse;
    }
    IPlugView* PLUGIN_API createView(FIDString name) override {
        if (name && std::strcmp(name, ViewType::kEditor) == 0) return new SilvetonHostTestView(this);
        return nullptr;
    }
    void triggerHostContracts() {
        (void)beginEdit(kGainId);
        (void)performEdit(kGainId, 0.75);
        (void)endEdit(kGainId);
        (void)sendTextMessage("latency512");
        if (auto* handler = getComponentHandler()) {
            FUnknownPtr<IComponentHandlerBusActivation> busActivation(handler);
            if (busActivation) (void)busActivation->requestBusActivation(kAudio, kInput, 1, true);
            (void)handler->restartComponent(kLatencyChanged);
        }
    }
private:
    uint32 uiState_ {0x53494C56U};
};

SilvetonHostTestView::SilvetonHostTestView(SilvetonHostTestController* controller)
    : CPluginView([] { static ViewRect rect(0, 0, 360, 180); return &rect; }()), controller_(controller) {}

tresult PLUGIN_API SilvetonHostTestView::attached(void* parent, FIDString type) {
    const auto r = CPluginView::attached(parent, type);
    if (r == kResultTrue && controller_) controller_->triggerHostContracts();
    return r;
}

} // namespace Steinberg::Vst

BEGIN_FACTORY_DEF("Silveton", "https://example.invalid", "hosttest@example.invalid")
DEF_CLASS2(INLINE_UID(0xA41E89F1, 0x34E54B61, 0xA1C04321, 0x0BEE1001),
          Steinberg::PClassInfo::kManyInstances,
          kVstAudioEffectClass,
          "Silveton Host Test",
          Steinberg::Vst::kDistributable,
          "Fx|Test",
          "1.0.0",
          kVstVersionString,
          Steinberg::Vst::SilvetonHostTestProcessor::create)
DEF_CLASS2(INLINE_UID(0xC630AB13, 0x56A75D83, 0xC3E26543, 0x2D003003),
          Steinberg::PClassInfo::kManyInstances,
          kVstAudioEffectClass,
          "Silveton Layout 8ch Test",
          Steinberg::Vst::kDistributable,
          "Fx|Test",
          "1.0.0",
          kVstVersionString,
          Steinberg::Vst::SilvetonLayout8Processor::create)
DEF_CLASS2(INLINE_UID(0xD741BC24, 0x67B86E94, 0xD4F37654, 0x3E114114),
          Steinberg::PClassInfo::kManyInstances,
          kVstAudioEffectClass,
          "Silveton MultiOut Instrument Test",
          Steinberg::Vst::kDistributable,
          "Instrument|Synth",
          "1.0.0",
          kVstVersionString,
          Steinberg::Vst::SilvetonInstrumentProcessor::create)
DEF_CLASS2(INLINE_UID(0xB52F9A02, 0x45F64C72, 0xB2D15432, 0x1CFF2002),
          Steinberg::PClassInfo::kManyInstances,
          kVstComponentControllerClass,
          "Silveton Host Test Controller",
          0,
          "",
          "1.0.0",
          kVstVersionString,
          Steinberg::Vst::SilvetonHostTestController::create)
END_FACTORY
