#include "silveton/DawCore.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>
namespace {
void require(bool b,const char*m){if(!b)throw std::runtime_error(m);}
constexpr double pi=3.141592653589793238462643383279502884;

double bandMagnitude(const silveton::AudioBuffer& x, double centerHz, double sampleRate) {
    const std::size_t n=std::min<std::size_t>(4096U,x.frames());
    double total=0.0;
    for(int offset=-5;offset<=5;++offset){
        const double frequency=centerHz+offset*25.0;
        if(frequency<=0.0||frequency>=sampleRate*0.5)continue;
        double re=0.0,im=0.0;
        for(std::size_t i=0;i<n;++i){
            const double w=0.5-0.5*std::cos(2.0*pi*double(i)/double(n-1U));
            const double phase=2.0*pi*frequency*double(i)/sampleRate;
            const double sample=x.sample(0,i)*w;
            re+=sample*std::cos(phase); im-=sample*std::sin(phase);
        }
        total+=std::sqrt(re*re+im*im);
    }
    return total;
}

double envelopeError(const silveton::AudioBuffer& reference,const silveton::AudioBuffer& candidate,double sampleRate){
    std::vector<double>a,b;
    for(double f=400.0;f<=3400.0;f+=200.0){a.push_back(std::log(1.0e-9+bandMagnitude(reference,f,sampleRate)));b.push_back(std::log(1.0e-9+bandMagnitude(candidate,f,sampleRate)));}
    const double ma=*std::max_element(a.begin(),a.end()),mb=*std::max_element(b.begin(),b.end());
    double e=0.0;for(std::size_t i=0;i<a.size();++i){const double d=(a[i]-ma)-(b[i]-mb);e+=d*d;}return std::sqrt(e/double(a.size()));
}
}
int main(){
    constexpr std::size_t n=8192; constexpr double sr=48000.0;
    silveton::AudioBuffer stereo(2,n);
    for(std::size_t i=0;i<n;++i){const float s=0.4F*std::sin(2.0*pi*440.0*double(i)/sr);stereo.sample(0,i)=s;stereo.sample(1,i)=s*0.5F;}
    stereo.sample(0,1024)+=1.0F;stereo.sample(1,1024)+=0.5F;
    auto stretched=silveton::AudioEditor::timeStretch(stereo,1.5);require(stretched.frames()==12288,"stretch length mismatch");double relationError=0.0,energy=0.0;for(std::size_t i=0;i<stretched.frames();++i){relationError+=std::abs(double(stretched.sample(1,i))-0.5*double(stretched.sample(0,i)));energy+=std::abs(stretched.sample(0,i));}require(relationError/std::max(1.0,energy)<0.03,"stereo phase/level relationship drifted");float pv=0;for(std::size_t i=0;i<stretched.frames();++i){float a=std::abs(stretched.sample(0,i));if(a>pv){pv=a;}}require(pv>0.4F,"transient peak was excessively smeared");

    const auto draft=silveton::AudioEditor::timeStretch(stereo,1.5,silveton::ElasticAudioQuality::Draft);
    const auto high=silveton::AudioEditor::timeStretch(stereo,1.5,silveton::ElasticAudioQuality::High);
    require(draft.frames()==stretched.frames()&&high.frames()==stretched.frames(),"elastic quality mode changed requested duration");
    double draftRelation=0.0,highRelation=0.0,draftEnergy=0.0,highEnergy=0.0,modeDifference=0.0;
    for(std::size_t i=0;i<stretched.frames();++i){
        draftRelation+=std::abs(double(draft.sample(1,i))-0.5*double(draft.sample(0,i)));draftEnergy+=std::abs(draft.sample(0,i));
        highRelation+=std::abs(double(high.sample(1,i))-0.5*double(high.sample(0,i)));highEnergy+=std::abs(high.sample(0,i));
        modeDifference+=std::abs(double(draft.sample(0,i))-double(high.sample(0,i)));
    }
    require(draftRelation/std::max(1.0,draftEnergy)<0.04,"Draft elastic mode broke stereo coherence");
    require(highRelation/std::max(1.0,highEnergy)<0.025,"High elastic mode broke stereo coherence");
    require(modeDifference>1.0,"elastic quality modes are not changing the DSP path");

    auto shifted=silveton::AudioEditor::pitchShift(stereo,12.0);require(shifted.frames()==n,"pitch shift changed duration");double zc=0;for(std::size_t i=1;i<n;++i)if(shifted.sample(0,i-1)<=0&&shifted.sample(0,i)>0)zc+=1;require(zc>120.0&&zc<190.0,"octave pitch shift frequency is implausible");auto sinc=silveton::AudioEditor::resampleSinc(stereo,0.75);require(sinc.frames()==6144,"sinc resample length mismatch");

    silveton::AudioBuffer vocal(1,n);
    constexpr double f0=125.0;
    double norm=0.0;
    std::vector<double> amps;
    for(int h=1;h<=32;++h){const double f=f0*h;const double env=0.025+1.0*std::exp(-0.5*std::pow((f-800.0)/170.0,2.0))+0.75*std::exp(-0.5*std::pow((f-1450.0)/220.0,2.0))+0.55*std::exp(-0.5*std::pow((f-2550.0)/300.0,2.0));amps.push_back(env);norm+=env;}
    for(std::size_t i=0;i<n;++i){double v=0.0;for(int h=1;h<=32;++h)v+=amps[std::size_t(h-1)]*std::sin(2.0*pi*f0*h*double(i)/sr);v*=0.8/norm;v*=std::min(1.0,double(i)/256.0);v*=std::min(1.0,double(n-1U-i)/256.0);vocal.sample(0,i)=float(v);}
    const auto generic=silveton::AudioEditor::pitchShift(vocal,7.0);
    const auto preserved=silveton::AudioEditor::pitchShiftFormantPreserving(vocal,7.0);
    const auto preservedDraft=silveton::AudioEditor::pitchShiftFormantPreserving(vocal,7.0,silveton::ElasticAudioQuality::Draft);
    const auto preservedHigh=silveton::AudioEditor::pitchShiftFormantPreserving(vocal,7.0,silveton::ElasticAudioQuality::High);
    require(preserved.frames()==vocal.frames()&&preservedDraft.frames()==vocal.frames()&&preservedHigh.frames()==vocal.frames(),"formant-preserving pitch shift changed duration");
    const double genericError=envelopeError(vocal,generic,sr),preservedError=envelopeError(vocal,preserved,sr);
    const double draftFormantError=envelopeError(vocal,preservedDraft,sr),highFormantError=envelopeError(vocal,preservedHigh,sr);
    require(preservedError < genericError*0.92,"formant-preserving mode did not improve spectral-envelope retention");
    require(draftFormantError < genericError&&highFormantError < genericError,
            "explicit formant-preserving quality modes did not retain the vocal envelope");
    std::cout<<"PASS: transient-aware phase-locked stereo stretch, sinc pitch shift and formant-preserving vocal mode\n";
    std::cout<<"PASS: Draft/Balanced/High elastic quality modes select distinct coherent DSP paths\n";return 0;
}
