// A fader or mute move must be heard in the next block (smoothly), without
// rebuilding the routing graph. The graph keeps the values it was built with, so
// the engine carries live values next to it.
#include "silveton/AudioBuffer.h"
#include "silveton/AudioEngine.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/ProjectSession.h"

#include <array>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <vector>

namespace {
using namespace silveton;

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
bool near(float a, float b, float eps) { return std::abs(a - b) <= eps; }

constexpr std::uint32_t kFrames = 8U;

std::unique_ptr<ProcessorGraph> makeGraph(float trackFaderDb) {
    std::vector<GraphNodeDefinition> nodes(2U);   // node 0 = track, node 1 = master
    nodes[0].mix.enabled = true;
    nodes[0].mix.gainDb = trackFaderDb;
    nodes[1].mix.enabled = true;
    std::unique_ptr<ProcessorGraph> graph(new ProcessorGraph);
    graph->configure(std::move(nodes), {{0U, 1U, 1.0F}}, 1U);
    return graph;
}

struct Rig {
    AudioBuffer source {2U, 64U};
    AudioEngine engine;
    std::unique_ptr<ProcessorGraph> initial;
    std::array<float, kFrames> left {};
    std::array<float, kFrames> right {};

    explicit Rig(float trackFaderDb) {
        for (std::size_t i = 0U; i < source.frames(); ++i) { source.sample(0U, i) = 1.0F; source.sample(1U, i) = 1.0F; }
        initial = makeGraph(trackFaderDb);
        engine.setProcessorGraph(initial.get(), 64U);
        engine.prepare({48000.0, kFrames, 0U, 2U});
        engine.addTrack({&source, 0, 0U, 0.0F, 0.0F, false, true, 0});
        engine.transport().play();
    }
    void block() {
        engine.transport().seekSamples(0);
        float* outs[2] {left.data(), right.data()};
        engine.processAudio(nullptr, outs, 0U, 2U, kFrames);
    }
    bool steady(float value, float eps = 1.0e-5F) const {
        for (std::size_t i = 0U; i < kFrames; ++i) if (!near(left[i], value, eps) || !near(right[i], value, eps)) return false;
        return true;
    }
};

Project oneTrackProject(float gainDb, bool mute, float masterDb) {
    Project p;
    p.tracks.resize(1U);
    p.tracks[0].gainDb = gainDb;
    p.tracks[0].mute = mute;
    p.masterFaderDb = masterDb;
    return p;
}

void testTrackFaderIsLive() {
    Rig rig(0.0F);
    rig.block();
    require(rig.steady(1.0F), "start level");

    require(rig.engine.applyLiveMixerState(oneTrackProject(-20.0F, false, 0.0F)), "live state refused on a matching graph");
    rig.block();   // the block with the move glides from 1.0 to 0.1
    require(rig.left[0] < 1.0F && rig.left[0] > 0.1F, "the move must glide, not jump");
    require(near(rig.left[kFrames - 1U], 0.1F, 1.0e-4F), "the block must end on the new level");
    for (std::size_t i = 1U; i < kFrames; ++i) require(rig.left[i] <= rig.left[i - 1U], "the glide must be monotonic");
    rig.block();
    require(rig.steady(0.1F, 1.0e-4F), "the new level must hold");

    // Raising again is heard just as fast.
    require(rig.engine.applyLiveMixerState(oneTrackProject(0.0F, false, 0.0F)), "second live state refused");
    rig.block();
    rig.block();
    require(rig.steady(1.0F), "raising the fader must be heard");
}

void testMuteAndMaster() {
    Rig rig(0.0F);
    rig.block();
    require(rig.engine.applyLiveMixerState(oneTrackProject(0.0F, true, 0.0F)), "mute refused");
    rig.block();
    require(near(rig.left[kFrames - 1U], 0.0F, 1.0e-6F), "mute must reach silence within the block");
    rig.block();
    require(rig.steady(0.0F, 1.0e-6F), "muted track must stay silent");
    require(rig.engine.applyLiveMixerState(oneTrackProject(0.0F, false, 0.0F)), "unmute refused");
    rig.block();
    rig.block();
    require(rig.steady(1.0F), "unmute must bring the sound back");

    require(rig.engine.applyLiveMixerState(oneTrackProject(0.0F, false, -6.0205999F)), "master refused");
    rig.block();
    rig.block();
    require(rig.steady(0.5F, 1.0e-4F), "master fader must be live too");
}

void testNewGraphStartsFromTheProject() {
    Rig rig(0.0F);
    rig.block();
    require(rig.engine.applyLiveMixerState(oneTrackProject(-20.0F, false, 0.0F)), "live state refused");
    rig.block();
    rig.block();
    require(rig.steady(0.1F, 1.0e-4F), "live level");

    // A new graph is built from the project (fader -6.02 dB). While it is pending the call is refused.
    const std::uint64_t generation = rig.engine.publishProcessorGraph(makeGraph(-6.0205999F), 64U);
    require(!rig.engine.applyLiveMixerState(oneTrackProject(-6.0205999F, false, 0.0F)), "must refuse while a graph is pending");
    rig.block();
    require(rig.engine.liveProcessorGraphGeneration() == generation, "new graph not live");
    rig.block();
    require(rig.steady(0.5F, 1.0e-4F), "old live values must not override a freshly built graph");

    // After the new generation is live the same call works again.
    require(rig.engine.applyLiveMixerState(oneTrackProject(-20.0F, false, 0.0F)), "live state refused after the new graph");
    rig.block();
    rig.block();
    require(rig.steady(0.1F, 1.0e-4F), "live level on the new graph");

    // A project that does not match the graph (an extra track) is refused and changes nothing.
    Project mismatched = oneTrackProject(0.0F, false, 0.0F);
    mismatched.tracks.resize(2U);
    require(!rig.engine.applyLiveMixerState(mismatched), "layout mismatch must be refused");
    rig.block();
    require(rig.steady(0.1F, 1.0e-4F), "a refused call must change nothing");
}
} // namespace

int main() {
    try {
        testTrackFaderIsLive();
        testMuteAndMaster();
        testNewGraphStartsFromTheProject();
        std::cout << "live mixer tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
