#include "silveton/AudioBuffer.h"
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/OfflineBounce.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/StemBounce.h"
#include "silveton/WavFile.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

bool near(float a, float b, float eps = 1.0e-6F) {
    return std::abs(a - b) <= eps;
}

class TailProcessor final : public silveton::ITrackProcessor {
public:
    explicit TailProcessor(std::uint32_t tail) : tail_(tail) {}

    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override { remaining_ = 0U; }
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    std::uint64_t tailSamples() const noexcept override { return tail_; }
    bool setRunMode(silveton::ProcessorRunMode mode) override {
        if (mode == silveton::ProcessorRunMode::Offline) ++offlineEntries;
        else ++realtimeEntries;
        return true;
    }

    void process(float* left,
                 float* right,
                 std::uint32_t frames,
                 const silveton::ProcessorContext&) noexcept override {
        for (std::uint32_t i = 0U; i < frames; ++i) {
            if (std::abs(left[i]) > 1.0e-8F || std::abs(right[i]) > 1.0e-8F) {
                remaining_ = tail_;
                continue;
            }
            if (remaining_ != 0U) {
                left[i] += 0.25F;
                right[i] += 0.25F;
                --remaining_;
            }
        }
    }

    int offlineEntries {0};
    int realtimeEntries {0};

private:
    std::uint32_t tail_ {0U};
    std::uint32_t remaining_ {0U};
};

void testSelectedRangeAndStreamingWave() {
    constexpr std::uint32_t block = 16U;
    silveton::AudioEngine engine;
    engine.prepare({48000.0, block, 0U, 2U});

    silveton::AudioBuffer source(2U, 64U);
    for (std::size_t i = 0U; i < source.frames(); ++i) {
        source.sample(0U, i) = static_cast<float>(i) * 0.01F;
        source.sample(1U, i) = -static_cast<float>(i) * 0.01F;
    }
    engine.addTrack({&source, 0, 0U, 0.0F, 0.0F, false});
    engine.transport().seekSamples(42);
    engine.transport().setCycleRange(true, 4, 12);

    silveton::Project project;
    project.sampleRate = 48000.0;

    const std::string path = "/tmp/silveton_offline_range.wav";
    silveton::OfflineBounceOptions options;
    options.startSample = 10;
    options.endSample = 30;
    options.blockSize = 7U;
    options.tailMode = silveton::BounceTailMode::None;

    const auto result = silveton::OfflineBounce::renderFloat32Wav(path, project, engine, nullptr, options);
    require(result.rangeFrames == 20U && result.tailFrames == 0U && result.totalFrames == 20U,
            "offline bounce range frame count is wrong");
    require(engine.transport().positionSamples() == 42, "offline bounce did not restore transport position");
    require(engine.transport().cycleEnabled() && engine.transport().cycleStartSample() == 4 && engine.transport().cycleEndSample() == 12,
            "offline bounce did not restore cycle range");

    const auto wav = silveton::WavFile::read(path);
    require(wav.sampleRate == 48000U, "offline bounce WAV sample rate is wrong");
    require(wav.audio.channels() == 2U && wav.audio.frames() == 20U, "offline bounce WAV shape is wrong");
    for (std::size_t i = 0U; i < 20U; ++i) {
        require(near(wav.audio.sample(0U, i), static_cast<float>(i + 10U) * 0.01F),
                "offline bounce selected-range left sample mismatch");
        require(near(wav.audio.sample(1U, i), -static_cast<float>(i + 10U) * 0.01F),
                "offline bounce selected-range right sample mismatch");
    }
    std::remove(path.c_str());
}

void testAutomaticProcessorTailAndNoPostRangeLeak() {
    constexpr std::uint32_t block = 8U;
    TailProcessor tail(4U);
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    nodes[0].processors.push_back({&tail, {}});
    auto graph = std::make_unique<silveton::ProcessorGraph>();
    graph->configure(std::move(nodes), {{0U, 1U, 1.0F}}, 1U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(graph.get(), 64U);
    engine.prepare({48000.0, block, 0U, 2U});

    silveton::AudioBuffer source(2U, 16U);
    source.sample(0U, 7U) = 1.0F;
    source.sample(1U, 7U) = 1.0F;
    // Audio after the selected range must not leak into the effect-tail section.
    for (std::size_t i = 8U; i < source.frames(); ++i) {
        source.sample(0U, i) = 0.9F;
        source.sample(1U, i) = 0.9F;
    }
    engine.addTrack({&source, 0, 0U, 0.0F, 0.0F, false});

    silveton::Project project;
    project.sampleRate = 48000.0;
    const std::string path = "/tmp/silveton_offline_tail.wav";
    silveton::OfflineBounceOptions options;
    options.startSample = 0;
    options.endSample = 8;
    options.tailMode = silveton::BounceTailMode::Automatic;

    const auto result = silveton::OfflineBounce::renderFloat32Wav(path, project, engine, nullptr, options);
    require(result.rangeFrames == 8U && result.tailFrames == 4U && result.totalFrames == 12U,
            "automatic processor tail length is wrong");
    require(!result.processorReportedInfiniteTail, "finite tail was marked infinite");
    require(tail.offlineEntries == 1 && tail.realtimeEntries == 1,
            "offline bounce did not switch processor mode offline then back to realtime");

    const auto wav = silveton::WavFile::read(path);
    require(wav.audio.frames() == 12U, "tail WAV frame count is wrong");
    require(near(wav.audio.sample(0U, 7U), 1.0F), "range impulse was not rendered");
    for (std::size_t i = 8U; i < 12U; ++i) {
        require(near(wav.audio.sample(0U, i), 0.25F), "effect tail was truncated or contaminated by post-range audio");
        require(near(wav.audio.sample(1U, i), 0.25F), "effect tail right channel mismatch");
    }
    std::remove(path.c_str());
}

void testFixedTailWithoutProcessors() {
    silveton::AudioEngine engine;
    engine.prepare({48000.0, 16U, 0U, 2U});
    silveton::AudioBuffer source(2U, 4U);
    for (std::size_t i = 0U; i < 4U; ++i) {
        source.sample(0U, i) = 0.5F;
        source.sample(1U, i) = 0.5F;
    }
    engine.addTrack({&source, 0, 0U, 0.0F, 0.0F, false});

    silveton::Project project;
    project.sampleRate = 48000.0;
    const std::string path = "/tmp/silveton_offline_fixed_tail.wav";
    silveton::OfflineBounceOptions options;
    options.startSample = 0;
    options.endSample = 4;
    options.tailMode = silveton::BounceTailMode::Fixed;
    options.fixedTailSamples = 3U;

    const auto result = silveton::OfflineBounce::renderFloat32Wav(path, project, engine, nullptr, options);
    require(result.totalFrames == 7U && result.tailFrames == 3U, "fixed bounce tail count is wrong");
    const auto wav = silveton::WavFile::read(path);
    require(wav.audio.frames() == 7U, "fixed-tail WAV frame count is wrong");
    for (std::size_t i = 4U; i < 7U; ++i) {
        require(near(wav.audio.sample(0U, i), 0.0F) && near(wav.audio.sample(1U, i), 0.0F),
                "fixed tail without processors should contain silence");
    }
    std::remove(path.c_str());
}


class ConstantGenerator final : public silveton::ITrackProcessor {
public:
    explicit ConstantGenerator(float value) : value_(value) {}
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float* left, float* right, std::uint32_t frames,
                 const silveton::ProcessorContext&) noexcept override {
        for (std::uint32_t i = 0U; i < frames; ++i) {
            left[i] = value_;
            right[i] = value_;
        }
    }
private:
    float value_ {0.0F};
};

void testTrackRenderMaskAlsoSuppressesGeneratorNodes() {
    constexpr std::uint32_t block = 8U;
    ConstantGenerator generator(0.5F);
    std::vector<silveton::GraphNodeDefinition> nodes(3U);
    nodes[0].processors.push_back({&generator, {}});
    auto graph = std::make_unique<silveton::ProcessorGraph>();
    graph->configure(std::move(nodes), {{0U, 2U, 1.0F}, {1U, 2U, 1.0F}}, 2U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(graph.get(), 64U);
    engine.prepare({48000.0, block, 0U, 2U});
    silveton::AudioBuffer silent(2U, block);
    silveton::AudioBuffer source(2U, block);
    for (std::size_t i = 0U; i < block; ++i) {
        source.sample(0U, i) = 0.2F;
        source.sample(1U, i) = 0.2F;
    }
    engine.addTrack({&silent, 0, 0U, 0.0F, 0.0F, false});
    engine.addTrack({&source, 0, 0U, 0.0F, 0.0F, false});

    std::array<float, block> left {};
    std::array<float, block> right {};
    float* outputs[2] {left.data(), right.data()};

    engine.setTrackRenderMask({1U});
    engine.transport().seekSamples(0);
    engine.transport().play();
    engine.processAudio(nullptr, outputs, 0U, 2U, block);
    engine.transport().stop();
    for (std::size_t i = 0U; i < block; ++i)
        require(near(left[i], 0.2F) && near(right[i], 0.2F),
                "track render mask allowed a disabled generator node to leak");

    engine.clearTrackRenderMask();
    engine.transport().seekSamples(0);
    engine.transport().play();
    engine.processAudio(nullptr, outputs, 0U, 2U, block);
    engine.transport().stop();
    for (std::size_t i = 0U; i < block; ++i)
        require(near(left[i], 0.7F) && near(right[i], 0.7F),
                "clearing track render mask did not restore all graph nodes");
}


void testProcessedTrackStemExportAndMaskRestore() {
    constexpr std::uint32_t block = 8U;
    silveton::AudioEngine engine;
    engine.prepare({48000.0, block, 0U, 2U});

    silveton::AudioBuffer a(2U, block);
    silveton::AudioBuffer b(2U, block);
    for (std::size_t i = 0U; i < block; ++i) {
        a.sample(0U, i) = 0.25F;
        a.sample(1U, i) = 0.25F;
        b.sample(0U, i) = 0.5F;
        b.sample(1U, i) = 0.5F;
    }
    engine.addTrack({&a, 0, 0U, 0.0F, 0.0F, false});
    engine.addTrack({&b, 0, 0U, 0.0F, 0.0F, false});

    silveton::Project project;
    project.sampleRate = 48000.0;
    silveton::OfflineBounceOptions options;
    options.startSample = 0;
    options.endSample = static_cast<std::int64_t>(block);
    options.tailMode = silveton::BounceTailMode::None;

    const std::string pathA = "/tmp/silveton_stem_a.wav";
    const std::string pathB = "/tmp/silveton_stem_b.wav";
    std::remove(pathA.c_str());
    std::remove(pathB.c_str());
    const std::vector<silveton::TrackStemRequest> requests {
        {pathA, {0U}},
        {pathB, {1U}}
    };
    const auto results = silveton::StemBounce::renderTrackStems(project, engine, nullptr, options, requests);
    require(results.size() == 2U, "track stem result count mismatch");
    const auto wavA = silveton::WavFile::read(pathA);
    const auto wavB = silveton::WavFile::read(pathB);
    for (std::size_t i = 0U; i < block; ++i) {
        require(near(wavA.audio.sample(0U, i), 0.25F) && near(wavA.audio.sample(1U, i), 0.25F),
                "first processed track stem contains another track");
        require(near(wavB.audio.sample(0U, i), 0.5F) && near(wavB.audio.sample(1U, i), 0.5F),
                "second processed track stem contains another track");
    }
    require(!engine.trackRenderMaskActive(), "track stem export left solo/render mask active");

    std::array<float, block> left {};
    std::array<float, block> right {};
    float* outputs[2] {left.data(), right.data()};
    engine.transport().seekSamples(0);
    engine.transport().play();
    engine.processAudio(nullptr, outputs, 0U, 2U, block);
    engine.transport().stop();
    for (std::size_t i = 0U; i < block; ++i)
        require(near(left[i], 0.75F) && near(right[i], 0.75F),
                "normal project rendering was not restored after stem export");

    std::remove(pathA.c_str());
    std::remove(pathB.c_str());
}


void testBusStemCapturesPostFaderNodeBeforeMaster() {
    constexpr std::uint32_t block = 8U;
    std::vector<silveton::GraphNodeDefinition> nodes(4U);
    auto graph = std::make_unique<silveton::ProcessorGraph>();
    graph->configure(std::move(nodes),
                     {{0U, 2U, 1.0F}, {2U, 3U, 1.0F}, {1U, 3U, 1.0F}},
                     3U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(graph.get(), 64U);
    engine.prepare({48000.0, block, 0U, 2U});

    silveton::AudioBuffer groupSource(2U, block);
    silveton::AudioBuffer directSource(2U, block);
    for (std::size_t i = 0U; i < block; ++i) {
        groupSource.sample(0U, i) = 0.25F;
        groupSource.sample(1U, i) = 0.25F;
        directSource.sample(0U, i) = 0.5F;
        directSource.sample(1U, i) = 0.5F;
    }
    engine.addTrack({&groupSource, 0, 0U, 0.0F, 0.0F, false});
    engine.addTrack({&directSource, 0, 0U, 0.0F, 0.0F, false});

    silveton::Project project;
    project.sampleRate = 48000.0;
    project.tracks.resize(2U);
    project.buses.resize(1U);
    project.buses[0].name = "Drum Group";

    silveton::OfflineBounceOptions options;
    options.startSample = 0;
    options.endSample = static_cast<std::int64_t>(block);
    options.tailMode = silveton::BounceTailMode::None;
    const std::string path = "/tmp/silveton_bus_stem.wav";
    std::remove(path.c_str());

    const std::vector<silveton::BusStemRequest> requests {{path, 0U}};
    const auto results = silveton::StemBounce::renderBusStems(project, engine, nullptr, options, requests);
    require(results.size() == 1U && results[0].busIndex == 0U, "bus stem result metadata mismatch");
    const auto wav = silveton::WavFile::read(path);
    for (std::size_t i = 0U; i < block; ++i)
        require(near(wav.audio.sample(0U, i), 0.25F) && near(wav.audio.sample(1U, i), 0.25F),
                "bus stem included direct-to-master material or wrong tap point");
    require(engine.graphMonitorNode() < 0, "bus stem export left graph tap active");

    std::array<float, block> left {};
    std::array<float, block> right {};
    float* outputs[2] {left.data(), right.data()};
    engine.transport().seekSamples(0);
    engine.transport().play();
    engine.processAudio(nullptr, outputs, 0U, 2U, block);
    engine.transport().stop();
    for (std::size_t i = 0U; i < block; ++i)
        require(near(left[i], 0.75F) && near(right[i], 0.75F),
                "master output was not restored after bus stem export");

    std::remove(path.c_str());
}

} // namespace

int main() {
    try {
        testSelectedRangeAndStreamingWave();
        testAutomaticProcessorTailAndNoPostRangeLeak();
        testFixedTailWithoutProcessors();
        testTrackRenderMaskAlsoSuppressesGeneratorNodes();
        testProcessedTrackStemExportAndMaskRestore();
        testBusStemCapturesPostFaderNodeBeforeMaster();
        std::cout << "PASS: offline bounce writes exact selected range without whole-project buffering\n";
        std::cout << "PASS: automatic processor tails render after transport stops\n";
        std::cout << "PASS: post-range arrangement audio cannot leak into the effect tail\n";
        std::cout << "PASS: offline bounce restores transport/cycle state\n";
        std::cout << "PASS: stem/solo track mask suppresses disabled generator processor nodes\n";
        std::cout << "PASS: processed track stems isolate sources and restore normal rendering\n";
        std::cout << "PASS: Group/FX bus stems tap post-fader output before Master\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
