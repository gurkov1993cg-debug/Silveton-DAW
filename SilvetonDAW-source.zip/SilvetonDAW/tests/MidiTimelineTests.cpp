#include "silveton/MidiTimeline.h"
#include "silveton/DawCore.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <string>
#include <iostream>
#include <stdexcept>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
void near(double a, double b, double tolerance, const char* message) {
    if (std::abs(a - b) > tolerance) throw std::runtime_error(message);
}

void testMusicalTimingFollowsTempoMap() {
    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    map.addTempoChange(96000, 60.0); // q=4 at the change

    silveton::MidiSequence sequence;
    const auto id = sequence.addNote({0U, 5.0, 1.0, 0U, 64U, 110U, 32U, false});
    require(id != 0U, "MIDI note ID was not assigned");
    const auto plan = sequence.compile(map);
    require(plan.events().size() == 2U, "MIDI note did not compile to note-on/note-off");
    require(plan.events()[0].sample == 144000, "MIDI note did not follow slower tempo after tempo-map change");
    require(plan.events()[1].sample == 192000, "MIDI note duration did not follow slower tempo");
}

void testQuantizeTransposeAndBlockScheduling() {
    silveton::MidiSequence sequence;
    const auto first = sequence.addNote({0U, 1.13, 0.5, 1U, 60U, 100U, 64U, false});
    const auto second = sequence.addNote({0U, 1.75, 0.25, 1U, 60U, 90U, 20U, false});
    (void)second;
    sequence.quantize(4.0, 1.0); // sixteenth-note starts
    require(sequence.notes().size() == 2U, "MIDI quantize changed note count");
    near(sequence.notes()[0].startQuarterNotes, 1.25, 1.0e-12, "MIDI full-strength quantize mismatch");
    sequence.transpose(12);
    require(sequence.notes()[0].pitch == 72U, "MIDI transpose mismatch");
    require(sequence.moveNote(first, 1.5), "MIDI move by ID failed");
    require(sequence.resizeNote(first, 0.25), "MIDI resize by ID failed");

    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    const auto plan = sequence.compile(map);
    std::array<silveton::ScheduledMidiEvent, 8U> events {};
    const std::int64_t blockStart = 36000; // q=1.5 exactly at 120 BPM
    const std::size_t count = plan.eventsForBlock(blockStart, 7000U, events.data(), events.size());
    require(count >= 1U, "MIDI block scheduler missed note-on");
    require(events[0].frameOffset == 0, "MIDI block scheduler frame offset mismatch");
    require((events[0].status & 0xF0U) == 0x90U && events[0].data1 == 72U, "MIDI scheduled event data mismatch");
}

void testMidiProjectRoundTrip() {
    const std::string path = "/tmp/silveton_midi_project_roundtrip.silveton";
    silveton::Project project;
    project.sampleRate = 48000.0;
    project.tempo = 120.0;
    project.tempoMap.setSampleRate(48000.0);
    project.tempoMap.setInitialTempo(120.0);
    project.tempoMap.addTempoChange(96000, 60.0);

    silveton::ProjectMidiTrack track;
    track.name = "Lead MIDI";
    track.outputPort = 9;
    const auto id = track.sequence.addNote({0U, 5.0, 0.75, 2U, 71U, 113U, 37U, false});
    require(id != 0U, "MIDI project fixture note ID missing");
    const auto sustainId = track.sequence.addMessage({0U, 4.5, 0xB2U, 64U, 127U, false});
    const auto bendId = track.sequence.addMessage({0U, 5.25, 0xE2U, 0U, 96U, false});
    require(sustainId != 0U && bendId != 0U, "MIDI project controller IDs missing");
    project.midiTracks.push_back(track);
    project.save(path);

    const auto loaded = silveton::Project::load(path);
    require(loaded.midiTracks.size() == 1U, "MIDI project track count round-trip mismatch");
    require(loaded.midiTracks[0].name == "Lead MIDI", "MIDI project track name round-trip mismatch");
    require(loaded.midiTracks[0].outputPort == 9, "MIDI project output port round-trip mismatch");
    require(loaded.midiTracks[0].sequence.notes().size() == 1U, "MIDI project note count round-trip mismatch");
    const auto& note = loaded.midiTracks[0].sequence.notes()[0];
    near(note.startQuarterNotes, 5.0, 1.0e-12, "MIDI project note start round-trip mismatch");
    near(note.durationQuarterNotes, 0.75, 1.0e-12, "MIDI project note duration round-trip mismatch");
    require(note.channel == 2U && note.pitch == 71U && note.velocity == 113U && note.releaseVelocity == 37U,
            "MIDI project note data round-trip mismatch");
    require(loaded.midiTracks[0].sequence.messages().size() == 2U,
            "MIDI project controller count round-trip mismatch");
    const auto& sustain = loaded.midiTracks[0].sequence.messages()[0];
    require(sustain.status == 0xB2U && sustain.data1 == 64U && sustain.data2 == 127U,
            "MIDI sustain controller round-trip mismatch");

    const auto plan = loaded.midiTracks[0].sequence.compile(loaded.tempoMap);
    require(plan.events().size() == 4U, "MIDI project restored note/controllers did not compile");
    // q=4 at 96000, then 60 BPM: q=5 is 144000.
    bool foundNoteOn = false, foundSustain = false, foundBend = false;
    for (const auto& event : plan.events()) {
        if ((event.status & 0xF0U) == 0x90U && event.data1 == 71U) {
            require(event.sample == 144000, "MIDI project restored note lost tempo-map timing");
            foundNoteOn = true;
        }
        if ((event.status & 0xF0U) == 0xB0U && event.data1 == 64U) foundSustain = true;
        if ((event.status & 0xF0U) == 0xE0U) foundBend = true;
    }
    require(foundNoteOn && foundSustain && foundBend, "MIDI project restored controller events missing");
    std::remove(path.c_str());
}

void testReleasePrecedesRetrigger() {
    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    silveton::MidiSequence sequence;
    (void)sequence.addNote({0U, 0.0, 1.0, 0U, 60U, 100U, 64U, false});
    (void)sequence.addNote({0U, 1.0, 1.0, 0U, 60U, 100U, 64U, false});
    (void)sequence.addMessage({0U, 1.0, 0xB0U, 64U, 0U, false});
    const auto plan = sequence.compile(map);
    require(plan.events().size() == 5U, "MIDI retrigger/controller event count mismatch");
    // q=1 contains first note-off and second note-on; note-off must be first.
    require(plan.events()[1].sample == plan.events()[2].sample, "MIDI retrigger events are not colocated");
    require((plan.events()[1].status & 0xF0U) == 0x80U, "MIDI note-off did not precede same-sample retrigger");
    require((plan.events()[2].status & 0xF0U) == 0xB0U, "MIDI controller was not ordered between release and retrigger");
    require((plan.events()[3].status & 0xF0U) == 0x90U, "MIDI same-sample retrigger note-on missing");
}
}

int main() {
    try {
        testMusicalTimingFollowsTempoMap();
        testQuantizeTransposeAndBlockScheduling();
        testMidiProjectRoundTrip();
        testReleasePrecedesRetrigger();
        std::cout << "MIDI timeline tests passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "MIDI timeline tests failed: " << e.what() << '\n';
        return 1;
    }
}
