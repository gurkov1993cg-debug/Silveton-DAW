#include "silveton/MidiEditor.h"
#include <iostream>
#include <stdexcept>

namespace { void require(bool ok, const char* m){ if(!ok) throw std::runtime_error(m); } }

int main() {
    silveton::MidiSequence sequence;
    silveton::MidiEditor editor(sequence);
    const auto note = editor.addNote({0U, 1.0, 1.0, 0U, 60U, 100U, 64U, false});
    require(editor.setVelocity(note, 87U), "velocity edit failed");
    require(editor.setPitch(note, 64U), "pitch edit failed");
    require(editor.setChannel(note, 2U), "channel edit failed");
    require(editor.setNoteMuted(note, true), "note mute failed");
    require(sequence.notes()[0].velocity == 87U && sequence.notes()[0].pitch == 64U && sequence.notes()[0].channel == 2U && sequence.notes()[0].muted,
            "note edit state mismatch");

    const auto sustain = editor.addController(2.0, 2U, 64U, 127U);
    const auto bend = editor.addPitchBend(2.5, 2U, 12288U);
    const auto program = editor.addProgramChange(3.0, 2U, 9U);
    require(sustain != 0U && bend != 0U && program != 0U && sequence.messages().size() == 3U, "controller lanes missing");
    require(editor.setControllerValue(sustain, 0U), "controller value edit failed");
    require(sequence.messages()[0].data2 == 0U, "controller value mismatch");

    const std::size_t beforeDelete = sequence.messages().size();
    require(editor.deleteMessage(program), "message delete failed");
    require(sequence.messages().size() + 1U == beforeDelete, "message delete state mismatch");
    require(editor.undo(), "undo delete failed");
    require(sequence.messages().size() == beforeDelete, "undo did not restore message");
    require(editor.redo(), "redo delete failed");
    require(sequence.messages().size() + 1U == beforeDelete, "redo did not re-delete message");

    require(editor.undo(), "second undo failed");
    require(editor.undo(), "undo controller edit failed");
    require(sequence.messages()[0].data2 == 127U, "undo controller value mismatch");

    silveton::TempoMap map;
    map.setSampleRate(48000.0); map.setInitialTempo(120.0);
    sequence.setNoteMuted(note, false);
    const auto plan = sequence.compile(map);
    require(!plan.events().empty(), "edited sequence did not compile");
    std::cout << "PASS: MIDI note/controller editor and Undo/Redo\n";
    return 0;
}
