#include "silveton/DawRuntimeCoordinator.h"
#include "silveton/NativePlugins.h"
#include "silveton/OfflineBounce.h"
#include "silveton/ProjectSession.h"
#include "silveton/WavFile.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <memory>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

using namespace silveton;

namespace {

constexpr double kSr = 48000.0;
constexpr double kPi = 3.14159265358979323846;
int passed = 0;

void require(bool c, const std::string& m) { if (!c) throw std::runtime_error(m); }

std::unique_ptr<NativePlugin> make(const std::string& id) {
    std::string why;
    auto p = createNativePlugin(id, why);
    require(p != nullptr, "cannot create " + id + ": " + why);
    p->prepare(kSr, 512U);
    return p;
}

ProcessorContext ctx(std::int64_t sample = 0, double tempo = 120.0) {
    ProcessorContext c; c.sampleRate = kSr; c.projectSample = sample; c.tempo = tempo; c.playing = true; return c;
}

// Run a mono-duplicated signal through a plug-in in 256-frame blocks.
std::vector<float> run(NativePlugin& p, const std::vector<float>& in, std::vector<float>* right = nullptr,
                       const std::vector<float>* side = nullptr) {
    std::vector<float> outL(in.size()), outR(in.size());
    const std::uint32_t block = 256U;
    for (std::size_t pos = 0U; pos < in.size(); pos += block) {
        const auto n = static_cast<std::uint32_t>(std::min<std::size_t>(block, in.size() - pos));
        ConstStereoBus buses[2] {{in.data() + pos, in.data() + pos}, {nullptr, nullptr}};
        std::size_t count = p.info().instrument ? 0U : 1U;
        if (side) { buses[1] = {side->data() + pos, side->data() + pos}; count = 2U; }
        StereoBus out {outL.data() + pos, outR.data() + pos};
        require(p.processBuses(buses, count, &out, 1U, n, ctx(static_cast<std::int64_t>(pos))), "processBuses failed");
    }
    if (right) *right = outR;
    return outL;
}

std::vector<float> sine(double freq, double amp, std::size_t n) {
    std::vector<float> v(n);
    for (std::size_t i = 0; i < n; ++i) v[i] = static_cast<float>(amp * std::sin(2.0 * kPi * freq * i / kSr));
    return v;
}

double rms(const std::vector<float>& v, std::size_t from, std::size_t to) {
    double s = 0.0;
    for (std::size_t i = from; i < to; ++i) s += double(v[i]) * v[i];
    return std::sqrt(s / double(to - from));
}
double db(double x) { return 20.0 * std::log10(std::max(x, 1e-12)); }
double peak(const std::vector<float>& v, std::size_t from = 0, std::size_t to = SIZE_MAX) {
    double m = 0.0; to = std::min(to, v.size());
    for (std::size_t i = from; i < to; ++i) m = std::max(m, double(std::abs(v[i])));
    return m;
}
bool allFinite(const std::vector<float>& v) { for (float x : v) if (!std::isfinite(x)) return false; return true; }

void pass(const char* name) { ++passed; std::cout << "PASS: " << name << '\n'; }

void testCatalogAndState() {
    std::mt19937 rng(7);
    for (const auto& info : nativePluginCatalog()) {
        auto a = make(info.classId);
        require(a->modulePath() == kNativeModulePath, "module path");
        require(a->hasEventInput() == info.instrument, "event input flag");
        std::uniform_real_distribution<double> d(0.0, 1.0);
        for (const auto& prm : a->parameters()) a->setPlainValue(prm.id, NativePlugin::toPlain(prm, d(rng)));
        auto state = a->componentState();
        auto b = make(info.classId);
        require(b->setComponentState(state), "state restore " + info.classId);
        for (const auto& prm : a->parameters())
            require(std::abs(a->normalizedValue(prm.id) - b->normalizedValue(prm.id)) < 1e-12, "state value " + prm.name);
        auto other = make(info.classId == "silveton.gate" ? "silveton.echo" : "silveton.gate");
        require(!other->setComponentState(state), "state accepted by a different processor");
        for (const auto& prm : a->parameters()) {
            const double pl = a->plainValue(prm.id);
            require(std::abs(NativePlugin::toNormalized(prm, pl) - a->normalizedValue(prm.id)) < 1e-9 ||
                        prm.scale == NativeParamScale::Choice || prm.scale == NativeParamScale::Integer ||
                        prm.scale == NativeParamScale::Toggle,
                    "normalized/plain round trip " + prm.name);
            require(!a->formatValue(prm.id).empty(), "format value");
        }
    }
    pass("catalog creates every processor; state round-trips and rejects foreign state");
}

void testEqNullAndResponse() {
    auto eq = make("silveton.contour-eq");
    std::mt19937 rng(3);
    std::uniform_real_distribution<float> d(-1.0F, 1.0F);
    std::vector<float> noise(20000);
    for (auto& x : noise) x = d(rng);
    auto out = run(*eq, noise);
    for (std::size_t i = 0; i < noise.size(); ++i) require(out[i] == noise[i], "flat EQ is not bit-transparent");

    auto bell = make("silveton.contour-eq");
    bell->setPlainValue(6, 6.0);    // Low Mid Gain
    bell->setPlainValue(7, 1000.0); // Low Mid Freq
    bell->setPlainValue(8, 1.0);
    const auto s1k = sine(1000.0, 0.25, 48000);
    const auto o1k = run(*bell, s1k);
    const double g1k = db(rms(o1k, 24000, 48000) / rms(s1k, 24000, 48000));
    require(std::abs(g1k - 6.0) < 0.1, "bell gain at centre is " + std::to_string(g1k));
    bell->reset();
    const auto s100 = sine(100.0, 0.25, 48000);
    const double g100 = db(rms(run(*bell, s100), 24000, 48000) / rms(s100, 24000, 48000));
    require(std::abs(g100) < 0.3, "bell leaks at 100 Hz: " + std::to_string(g100));

    auto hp = make("silveton.contour-eq");
    hp->setPlainValue(1, 1.0); hp->setPlainValue(2, 200.0); hp->setPlainValue(3, 1.0);
    const auto s50 = sine(50.0, 0.5, 48000);
    const double a50 = db(rms(run(*hp, s50), 24000, 48000) / rms(s50, 24000, 48000));
    require(a50 < -40.0, "24 dB/oct low cut attenuates 50 Hz only " + std::to_string(a50));
    pass("Contour EQ: bit-exact when flat, +6.0 dB bell, >40 dB low-cut rejection");
}

void testCompressor() {
    auto c = make("silveton.press");
    c->setPlainValue(0, -18.0); c->setPlainValue(1, 4.0); c->setPlainValue(2, 0.0);
    c->setPlainValue(9, 1.0); // RMS detector
    const auto s = sine(1000.0, 0.5, 96000);
    const auto o = run(*c, s);
    const double inDb = db(rms(s, 48000, 96000) * std::sqrt(2.0));  // RMS detector reads peak-equivalent
    const double expected = (-18.0 + (inDb + 18.0) / 4.0) - inDb;
    const double measured = db(rms(o, 48000, 96000) / rms(s, 48000, 96000));
    require(std::abs(measured - expected) < 0.5, "compressor GR " + std::to_string(measured) + " expected " + std::to_string(expected));
    require(c->meter(0) < -8.0, "compressor gain-reduction meter");

    // Sidechain keying: quiet main, loud key.
    auto sc = make("silveton.press");
    sc->setPlainValue(8, 1.0);
    const auto quiet = sine(500.0, 0.05, 48000);
    const auto key = sine(80.0, 0.9, 48000);
    const auto o2 = run(*sc, quiet, nullptr, &key);
    require(rms(o2, 24000, 48000) < rms(quiet, 24000, 48000) * 0.5, "sidechain key did not duck the main signal");
    pass("Press compressor: static curve within 0.5 dB, sidechain ducking");
}

void testGate() {
    auto g = make("silveton.gate");
    const auto quiet = sine(300.0, 0.001, 48000);  // -60 dB < -40 threshold
    const auto oq = run(*g, quiet);
    require(rms(oq, 24000, 48000) < rms(quiet, 24000, 48000) * 0.001, "gate did not close");
    g->reset();
    const auto loud = sine(300.0, 0.3, 48000);
    const auto ol = run(*g, loud);
    require(std::abs(db(rms(ol, 24000, 48000) / rms(loud, 24000, 48000))) < 0.05, "gate not transparent when open");
    pass("Gate closes below threshold and is transparent when open");
}

void testLimiter() {
    auto l = make("silveton.ceiling");
    l->setPlainValue(1, -1.0);
    const double ceil = std::pow(10.0, -1.0 / 20.0);
    auto s = sine(997.0, 2.0, 48000);
    for (std::size_t i = 10000; i < 10005; ++i) s[i] = (i % 2) ? 4.0F : -4.0F;  // brutal transient
    const auto o = run(*l, s);
    require(peak(o) <= ceil + 1e-6, "limiter exceeded ceiling: " + std::to_string(peak(o)));
    const auto lat = l->latencySamples();
    require(lat == 72U, "limiter latency " + std::to_string(lat));
    auto l2 = make("silveton.ceiling");
    std::vector<float> imp(1000, 0.0F); imp[0] = 0.1F;
    const auto oi = run(*l2, imp);
    require(std::abs(oi[lat] - 0.1F) < 1e-7F, "limiter latency does not match reported value");
    for (std::size_t i = 0; i < oi.size(); ++i) if (i != lat) require(std::abs(oi[i]) < 1e-9F, "limiter smeared a sub-threshold impulse");
    pass("Ceiling limiter: never exceeds ceiling, latency reported exactly");
}

void testDelay() {
    auto d = make("silveton.echo");
    d->setPlainValue(0, 0.0); d->setPlainValue(2, 100.0); d->setPlainValue(3, 0.0); d->setPlainValue(7, 100.0);
    d->setPlainValue(5, 20.0); d->setPlainValue(6, 20000.0);
    std::vector<float> imp(12000, 0.0F); imp[0] = 1.0F;
    const auto o = run(*d, imp);
    std::size_t at = 0; double best = 0.0;
    for (std::size_t i = 0; i < o.size(); ++i) if (std::abs(o[i]) > best) { best = std::abs(o[i]); at = i; }
    require(at == 4800U, "echo at sample " + std::to_string(at));
    require(best > 0.8, "echo level " + std::to_string(best));
    auto sync = make("silveton.echo");
    sync->setPlainValue(1, 8.0); sync->setPlainValue(3, 0.0); sync->setPlainValue(7, 100.0); sync->setPlainValue(6, 20000.0);
    std::vector<float> imp2(30000, 0.0F); imp2[0] = 1.0F;
    const auto o2 = run(*sync, imp2);
    std::size_t at2 = 0; best = 0.0;
    for (std::size_t i = 0; i < o2.size(); ++i) if (std::abs(o2[i]) > best) { best = std::abs(o2[i]); at2 = i; }
    require(at2 == 24000U, "1/4 note at 120 BPM echo at " + std::to_string(at2));
    pass("Echo delay: exact ms timing and tempo-synced 1/4 note");
}

void testReverb() {
    auto r = make("silveton.space");
    r->setPlainValue(0, 0.0); r->setPlainValue(1, 1.0); r->setPlainValue(3, 0.0); r->setPlainValue(7, 100.0);
    r->setPlainValue(4, 20.0); r->setPlainValue(5, 20000.0); r->setPlainValue(8, 0.0);
    std::vector<float> imp(static_cast<std::size_t>(kSr * 2.5), 0.0F); imp[0] = 1.0F;
    std::vector<float> right;
    const auto o = run(*r, imp, &right);
    require(allFinite(o) && allFinite(right), "reverb produced non-finite output");
    // Schroeder backward integration, T20 fit (-5..-25 dB) *3 -> RT60.
    std::vector<double> edc(o.size());
    double acc = 0.0;
    for (std::size_t i = o.size(); i-- > 0;) { acc += double(o[i]) * o[i] + double(right[i]) * right[i]; edc[i] = acc; }
    const double e0 = edc[0];
    std::size_t t5 = 0, t25 = 0;
    for (std::size_t i = 0; i < edc.size(); ++i) {
        const double lvl = 10.0 * std::log10(edc[i] / e0);
        if (!t5 && lvl <= -5.0) t5 = i;
        if (!t25 && lvl <= -25.0) { t25 = i; break; }
    }
    require(t5 && t25 > t5, "reverb decay did not reach -25 dB");
    const double rt60 = double(t25 - t5) / kSr * 3.0;
    require(rt60 > 0.7 && rt60 < 1.4, "reverb RT60 " + std::to_string(rt60) + " s for 1.0 s setting");
    double corr = 0.0, el = 0.0, er = 0.0;
    for (std::size_t i = 2000; i < 30000; ++i) { corr += double(o[i]) * right[i]; el += double(o[i]) * o[i]; er += double(right[i]) * right[i]; }
    require(std::abs(corr / std::sqrt(el * er)) < 0.5, "reverb output is not decorrelated");
    auto longTail = make("silveton.space");
    longTail->setPlainValue(1, 20.0); longTail->setPlainValue(7, 100.0);
    const auto noise = sine(220.0, 0.5, static_cast<std::size_t>(kSr * 6));
    const auto ol = run(*longTail, noise);
    require(allFinite(ol) && peak(ol) < 20.0, "20 s reverb became unstable");
    pass("Space reverb: RT60 tracks setting, decorrelated stereo, stable at 20 s");
}

void testDriveAndChorus() {
    auto dr = make("silveton.drive");
    dr->setPlainValue(0, 12.0);
    const auto small = sine(440.0, 0.002, 24000);
    const auto os = run(*dr, small);
    require(std::abs(db(rms(os, 12000, 24000) / rms(small, 12000, 24000))) < 0.1, "drive not unity at low level");
    auto third = [](const std::vector<float>& v, double f) {
        double re = 0.0, im = 0.0;
        for (std::size_t i = 12000; i < v.size(); ++i) { re += v[i] * std::cos(2 * kPi * f * i / kSr); im += v[i] * std::sin(2 * kPi * f * i / kSr); }
        return std::sqrt(re * re + im * im);
    };
    dr->reset();
    const auto loud = sine(440.0, 0.8, 24000);
    const auto ol = run(*dr, loud);
    require(third(ol, 1320.0) / third(ol, 440.0) > 0.05, "drive produced no harmonics");
    require(allFinite(ol), "drive non-finite");

    auto ch = make("silveton.chorus");
    ch->setPlainValue(4, 0.0);
    const auto s = sine(300.0, 0.5, 8000);
    const auto oc = run(*ch, s);
    for (std::size_t i = 0; i < s.size(); ++i) require(std::abs(oc[i] - s[i]) < 1e-7F, "chorus at 0% mix is not dry");
    auto ch2 = make("silveton.chorus");
    require(allFinite(run(*ch2, s)), "chorus non-finite");
    pass("Drive: unity small-signal gain + harmonics; Chorus dry at 0% mix");
}

void testSynth() {
    auto s = make("silveton.poly");
    s->setPlainValue(0, 3.0);  // sine
    s->setPlainValue(4, 0.0);  // osc2 off
    s->setPlainValue(7, 20000.0); s->setPlainValue(9, 0.0); s->setPlainValue(8, 0.0);
    s->setPlainValue(14, 50.0); // release 50 ms
    require(s->queueMidi({0, 0x90, 69, 127}), "queue note on");
    std::vector<float> silence(48000, 0.0F);
    const auto o = run(*s, silence);
    std::size_t crossings = 0;
    for (std::size_t i = 24001; i < 48000; ++i) if (o[i - 1] < 0.0F && o[i] >= 0.0F) ++crossings;
    require(crossings >= 219 && crossings <= 221, "synth A4 frequency: " + std::to_string(crossings * 2) + " Hz");
    require(peak(o, 24000) > 0.1, "synth too quiet");
    require(s->queueMidi({0, 0x80, 69, 0}), "queue note off");
    const auto rel = run(*s, silence);
    require(peak(rel, 12000) < 1e-5, "synth did not release to silence");

    s->reset();
    require(s->queueMidi({0, 0xB0, 64, 127}), "sustain on");
    require(s->queueMidi({0, 0x90, 60, 100}), "note");
    require(s->queueMidi({100, 0x80, 60, 0}), "note off");
    const auto held = run(*s, silence);
    require(peak(held, 40000) > 0.05, "sustain pedal did not hold the note");
    require(s->queueMidi({0, 0xB0, 64, 0}), "sustain off");
    const auto after = run(*s, silence);
    require(peak(after, 12000) < 1e-5, "note did not release after pedal up");
    pass("Poly synth: 440 Hz pitch, release to silence, sustain pedal");
}

void testSampleAccurateAutomation() {
    auto a = make("silveton.drive");
    auto b = make("silveton.drive");
    a->setPlainValue(0, 0.0); b->setPlainValue(0, 0.0);
    const auto s = sine(200.0, 0.1, 256);
    std::vector<float> oa(256), ob(256), dummy(256);
    ConstStereoBus in {s.data(), s.data()};
    StereoBus outA {oa.data(), dummy.data()}, outB {ob.data(), dummy.data()};
    const auto* outInfo = &a->parameters()[3];
    require(a->queueParameter(3, NativePlugin::toNormalized(*outInfo, -6.0), 100), "queue automation");
    require(a->processBuses(&in, 1, &outA, 1, 256, ctx()), "process a");
    require(b->processBuses(&in, 1, &outB, 1, 256, ctx()), "process b");
    for (std::size_t i = 0; i < 100; ++i) require(oa[i] == ob[i], "automation applied before its offset");
    const double g = std::pow(10.0, -6.0 / 20.0);
    for (std::size_t i = 100; i < 256; ++i) require(std::abs(oa[i] - ob[i] * g) < 1e-6, "automation not applied at its offset");
    require(std::abs(a->plainValue(3) + 6.0) < 1e-9, "automated value not visible to editor");
    pass("Sample-accurate parameter automation at frame offset 100");
}

void testEditorGestures() {
    auto a = make("silveton.press");
    a->beginEdit(0); a->setFromEditor(0, -30.0); a->endEdit(0);
    AutomationGesture g;
    require(a->popAutomationGesture(g) && g.type == AutomationGestureType::Begin, "begin gesture");
    require(a->popAutomationGesture(g) && g.type == AutomationGestureType::Value && g.parameterId == 0U, "value gesture");
    require(a->popAutomationGesture(g) && g.type == AutomationGestureType::End, "end gesture");
    require(!a->popAutomationGesture(g), "extra gesture");
    require(std::abs(a->plainValue(0) + 30.0) < 1e-9, "editor value");
    pass("Editor gestures feed Write/Touch/Latch automation");
}

void testProjectIntegration() {
    const std::string path = "/tmp/silveton_native_integration.wav";
    ProjectSession session;
    auto& project = session.project();
    project.tempoMap.setSampleRate(kSr);
    ProjectTrack inst;
    inst.name = "Poly";
    ProjectPluginSlot synth;
    synth.modulePath = kNativeModulePath;
    synth.classId = "silveton.poly";
    synth.midiInputPort = 0;
    inst.pluginSlots.push_back(synth);
    ProjectPluginSlot verb;
    verb.modulePath = kNativeModulePath;
    verb.classId = "silveton.space";
    inst.pluginSlots.push_back(verb);
    project.tracks.push_back(inst);
    ProjectMidiTrack mt;
    mt.outputPort = 0;
    MusicalMidiNote n; n.startQuarterNotes = 0.0; n.durationQuarterNotes = 1.0; n.pitch = 57; n.velocity = 110;
    (void)mt.sequence.addNote(n);
    project.midiTracks.push_back(mt);

    CompositeInstanceFactory factory(nullptr);
    AudioEngine engine;
    DawRuntimeCoordinator runtime(session, engine, factory);
    runtime.prepare({kSr, 256U, 0U, 2U});
    require(runtime.status().media.issues.empty(), "instrument track reported offline media");
    require(runtime.rack().trackSlotStatus(0, 0).available, "native synth not available in rack");
    {
        float l[256] {}, r[256] {};
        float* outs[2] {l, r};
        runtime.audioCallback().processAudio(nullptr, outs, 0U, 2U, 256U);  // adopt the published graph
        (void)runtime.service();
    }
    OfflineBounceOptions opt;
    opt.startSample = 0; opt.endSample = static_cast<std::int64_t>(kSr);
    opt.tailMode = BounceTailMode::None;
    OfflineBounceFileOptions fo;
    const auto result = OfflineBounce::renderAudioFile(path, project, engine, &runtime.rack(), opt, fo);
    require(result.peak > 0.02F, "rendered instrument track is silent (peak " + std::to_string(result.peak) + ")");

    // State capture into the project and restore through a fresh project load.
    auto* inst0 = dynamic_cast<NativePlugin*>(runtime.rack().trackInstance(0, 1));
    require(inst0 != nullptr, "native instance type");
    inst0->setPlainValue(1, 5.5);
    runtime.capturePluginState();
    const std::string projPath = "/tmp/silveton_native_integration.silveton";
    project.save(projPath);
    Project loaded = Project::load(projPath);
    std::string why;
    auto restored = createNativePlugin("silveton.space", why);
    require(restored->setComponentState(loaded.tracks[0].pluginSlots[1].componentState), "saved native state restore");
    require(std::abs(restored->plainValue(1) - 5.5) < 1e-6, "native state did not persist through project save");

    std::string reason;
    require(factory.create("/Library/Audio/Plug-Ins/VST3/X.vst3", "abc", reason) == nullptr && !reason.empty(),
            "composite factory must report missing VST3 host");
    std::remove(path.c_str());
    std::remove(projPath.c_str());
    pass("Instrument track: MIDI -> native synth -> native reverb renders; state persists via project");
}

} // namespace

int main() {
    try {
        testCatalogAndState();
        testEqNullAndResponse();
        testCompressor();
        testGate();
        testLimiter();
        testDelay();
        testReverb();
        testDriveAndChorus();
        testSynth();
        testSampleAccurateAutomation();
        testEditorGestures();
        testProjectIntegration();
        std::cout << passed << " native processor checks passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
