#include "silveton/Vst3PresetLibrary.h"
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace {
void require(bool b,const char*m){if(!b)throw std::runtime_error(m);}
class FakeInstance final : public silveton::IVst3PluginInstance {
public:
    FakeInstance(std::string m,std::string c):m_(std::move(m)),c_(std::move(c)){}
    const std::string& modulePath() const noexcept override{return m_;}
    const std::string& classId() const noexcept override{return c_;}
    void prepare(double,std::uint32_t) override{}
    void reset() noexcept override{}
    std::uint32_t latencySamples() const noexcept override{return 0U;}
    void process(float*,float*,std::uint32_t,const silveton::ProcessorContext&) noexcept override{}
    std::size_t inputBusCount() const noexcept override{return 1U;}
    std::size_t outputBusCount() const noexcept override{return 1U;}
    std::size_t inputBusChannelCount(std::size_t) const noexcept override{return 2U;}
    std::size_t outputBusChannelCount(std::size_t) const noexcept override{return 2U;}
    bool processBuses(const silveton::ConstStereoBus*,std::size_t,silveton::StereoBus*,std::size_t,std::uint32_t,const silveton::ProcessorContext&) noexcept override{return true;}
    bool setComponentState(const std::vector<std::uint8_t>&s) override{state_=s;return true;}
    bool setControllerState(const std::vector<std::uint8_t>&) override{return true;}
    std::vector<std::uint8_t> componentState() const override{return state_;}
    std::vector<std::uint8_t> controllerState() const override{return {};}
    bool savePreset(const std::string& path) const override{std::ofstream out(path.c_str(),std::ios::binary|std::ios::trunc);out.write(reinterpret_cast<const char*>(state_.data()),static_cast<std::streamsize>(state_.size()));return static_cast<bool>(out);}
    bool loadPreset(const std::string& path) override{std::ifstream in(path.c_str(),std::ios::binary);if(!in)return false;state_.assign(std::istreambuf_iterator<char>(in),{});return true;}
    bool hasEventInput() const noexcept override{return false;}
    bool queueMidi(const silveton::Vst3MidiEvent&) noexcept override{return false;}
    bool queueParameter(std::uint32_t,double,std::int32_t) noexcept override{return false;}
    bool popAutomationGesture(silveton::AutomationGesture&) noexcept override{return false;}
    bool popOutputParameter(silveton::Vst3OutputParameterChange&) noexcept override{return false;}
    std::uint32_t consumeRestartFlags() noexcept override{return 0U;}
    void setState(std::vector<std::uint8_t>s){state_=std::move(s);} const std::vector<std::uint8_t>& state()const{return state_;}
private:std::string m_,c_;mutable std::vector<std::uint8_t> state_;
};
}
int main(){const std::string preset="/tmp/SilvetonPresetTest.vstpreset",index="/tmp/SilvetonPresetIndex.txt";(void)std::remove(preset.c_str());(void)std::remove(index.c_str());silveton::Vst3PresetLibrary lib;FakeInstance a("/tmp/A.vst3","CLASSA");a.setState({1,2,3,4});require(lib.savePreset(a,preset,"My Preset"),"preset save failed");a.setState({9});require(lib.loadPreset(a,preset),"preset load failed");require(a.state()==std::vector<std::uint8_t>({1,2,3,4}),"preset did not restore state");require(lib.setFavorite(preset,true),"favorite failed");require(lib.favorites().size()==1U&&lib.recent(5).size()==1U,"favorite/recent lists failed");FakeInstance b("/tmp/B.vst3","CLASSB");require(!lib.loadPreset(b,preset),"preset class mismatch was not rejected");lib.saveIndex(index);silveton::Vst3PresetLibrary restored;restored.loadIndex(index);require(restored.entries().size()==1U&&restored.favorites().size()==1U,"preset index round trip failed");require(restored.forPlugin("/tmp/A.vst3","CLASSA").size()==1U,"plugin preset filtering failed");(void)std::remove(preset.c_str());(void)std::remove(index.c_str());std::cout<<"PASS: VST3 preset save/load/catalog/favorites/recent\n";return 0;}
