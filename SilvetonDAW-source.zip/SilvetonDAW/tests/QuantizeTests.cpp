#include "silveton/ClipEditor.h"
#include "silveton/Quantize.h"
#include "silveton/WavFile.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silveton;

namespace {
void require(bool c, const std::string& m) { if (!c) throw std::runtime_error(m); }
int passed = 0;
void pass(const char* n) { ++passed; std::cout << "PASS: " << n << '\n'; }
MusicalMidiNote note(double s, double d, int p = 60, int v = 100) {
    MusicalMidiNote n; n.startQuarterNotes = s; n.durationQuarterNotes = d; n.pitch = static_cast<std::uint8_t>(p); n.velocity = static_cast<std::uint8_t>(v); return n;
}
double startOf(const MidiSequence& s, std::size_t i) { return s.notes()[i].startQuarterNotes; }

void testMidiQuantize() {
    MidiSequence s;
    (void)s.addNote(note(0.02, 0.2)); (void)s.addNote(note(0.27, 0.2)); (void)s.addNote(note(0.49, 0.2)); (void)s.addNote(note(0.78, 0.2));
    QuantizeSettings q; q.gridQuarterNotes = 0.25;
    Quantizer::apply(s, q);
    require(std::abs(startOf(s, 0) - 0.0) < 1e-9 && std::abs(startOf(s, 1) - 0.25) < 1e-9 && std::abs(startOf(s, 2) - 0.5) < 1e-9 && std::abs(startOf(s, 3) - 0.75) < 1e-9, "straight 1/16");
    MidiSequence t; (void)t.addNote(note(0.30, 0.2)); (void)t.addNote(note(0.05, 0.2));
    QuantizeSettings h = q; h.strength = 0.5;
    Quantizer::apply(t, h);
    require(std::abs(startOf(t, 0) - 0.025) < 1e-9 && std::abs(startOf(t, 1) - 0.275) < 1e-9, "iterative strength 50%");
    MidiSequence m; (void)m.addNote(note(0.30, 0.2)); (void)m.addNote(note(0.40, 0.2));
    QuantizeSettings mg = q; mg.magneticArea = 0.5;     // only within 1/4 of a grid step... = 0.0625
    Quantizer::apply(m, mg);
    require(std::abs(startOf(m, 0) - 0.25) < 1e-9 && std::abs(startOf(m, 1) - 0.40) < 1e-9, "magnetic area leaves far notes alone");
    MidiSequence nq; (void)nq.addNote(note(0.26, 0.2));
    QuantizeSettings nz = q; nz.nonQuantizeQuarterNotes = 0.02;
    Quantizer::apply(nq, nz);
    require(std::abs(startOf(nq, 0) - 0.26) < 1e-9, "non-quantize keeps close notes");
    MidiSequence tr; (void)tr.addNote(note(0.34, 0.1)); (void)tr.addNote(note(0.66, 0.1));
    QuantizeSettings tp = q; tp.gridQuarterNotes = 0.5; tp.type = QuantizeGridType::Triplet;     // 1/8T = 1/3 quarter
    Quantizer::apply(tr, tp);
    require(std::abs(startOf(tr, 0) - 1.0 / 3.0) < 1e-9 && std::abs(startOf(tr, 1) - 2.0 / 3.0) < 1e-9, "triplet grid");
    MidiSequence dt; (void)dt.addNote(note(0.74, 0.1));
    QuantizeSettings dq = q; dq.gridQuarterNotes = 0.5; dq.type = QuantizeGridType::Dotted;
    Quantizer::apply(dt, dq);
    require(std::abs(startOf(dt, 0) - 0.75) < 1e-9, "dotted grid");
    MidiSequence sw; (void)sw.addNote(note(0.0, 0.2)); (void)sw.addNote(note(0.25, 0.2)); (void)sw.addNote(note(0.5, 0.2));
    QuantizeSettings ss = q; ss.swing = 0.6;
    Quantizer::apply(sw, ss);
    require(std::abs(startOf(sw, 1) - (0.25 + 0.6 * 0.25 / 3.0)) < 1e-9 && std::abs(startOf(sw, 2) - 0.5) < 1e-9, "swing delays off-beat");
    MidiSequence ln; (void)ln.addNote(note(0.0, 0.31));
    QuantizeSettings ls = q; ls.quantizeLength = true;
    Quantizer::apply(ln, ls);
    require(std::abs(ln.notes()[0].durationQuarterNotes - 0.25) < 1e-9, "quantize length");
    MidiSequence en; (void)en.addNote(note(0.0, 0.46));
    QuantizeSettings es = q; es.quantizeEnd = true; es.quantizeStart = false;
    Quantizer::apply(en, es);
    require(std::abs(en.notes()[0].durationQuarterNotes - 0.5) < 1e-9, "quantize end");
    MidiSequence rn; (void)rn.addNote(note(1.0, 0.2)); (void)rn.addNote(note(2.0, 0.2));
    QuantizeSettings rs = q; rs.randomQuarterNotes = 0.05;
    Quantizer::apply(rn, rs);
    require(std::abs(startOf(rn, 0) - 1.0) <= 0.05 + 1e-9 && std::abs(startOf(rn, 0) - 1.0) + std::abs(startOf(rn, 1) - 2.0) > 1e-6, "random offsets");
    pass("MIDI quantize: straight/triplet/dotted, swing, strength, magnetic area, non-quantize, length, end, random");
}

void testGroove() {
    MidiSequence s;
    for (int i = 0; i < 8; ++i) (void)s.addNote(note(i * 0.5 + ((i % 2) ? 0.1 : 0.0), 0.2, 60, (i % 2) ? 60 : 110));
    const auto g = Quantizer::extractGroove(s, 0.5, 1.0);
    require(g.offsetQuarterNotes.size() == 2U && std::abs(g.offsetQuarterNotes[0]) < 1e-9 && std::abs(g.offsetQuarterNotes[1] - 0.1) < 1e-9, "groove offsets");
    require(g.velocityScale[0] > g.velocityScale[1], "groove velocity");
    MidiSequence straight;
    for (int i = 0; i < 4; ++i) (void)straight.addNote(note(i * 0.5, 0.2, 60, 100));
    Quantizer::applyGroove(straight, g, 1.0, 1.0);
    require(std::abs(startOf(straight, 1) - 0.6) < 1e-9 && std::abs(startOf(straight, 2) - 1.0) < 1e-9, "groove applied");
    require(straight.notes()[0].velocity > straight.notes()[1].velocity, "groove velocity applied");
    const auto sg = Quantizer::swingGroove(0.25, 66.0);
    require(std::abs(sg.offsetQuarterNotes[1] - (0.5 * 0.66 - 0.25)) < 1e-9, "swing groove math");
    require(Quantizer::builtInGrooves().size() >= 8U, "built-in grooves");
    pass("Groove quantize: extract timing/velocity from a part, apply, built-in swing grooves");
}

void testAudioQuantize() {
    const std::uint32_t sr = 48000U;
    const double bpm = 120.0;              // 1 quarter = 0.5 s = 24000 frames
    const std::size_t frames = sr * 4U;
    AudioBuffer buf(1U, frames);
    // clicks at quarter-note times 0.0, 0.5+0.04s, 1.0-0.03s, ... (off-grid by a few ms)
    const double offsets[] = {0.000, 0.540, 0.970, 1.512, 2.000, 2.470, 3.020};
    for (double t : offsets) {
        const auto at = static_cast<std::size_t>(t * sr);
        for (std::size_t i = 0U; i < 1200U && at + i < frames; ++i)
            buf.channelData(0)[at + i] += 0.8F * std::exp(-static_cast<float>(i) / 300.0F) * std::sin(static_cast<float>(i) * 0.4F);
    }
    const std::string path = "/tmp/silveton_quant_test.wav";
    WavFile::writeFloat32(path, sr, buf);
    const auto found = AudioQuantizer::detectTransients(buf, sr, 0.5);
    require(found.size() == 7U, "found " + std::to_string(found.size()) + " transients, expected 7");
    for (std::size_t i = 0U; i < found.size(); ++i)
        require(std::abs(static_cast<double>(found[i]) / sr - offsets[i]) < 0.012, "transient position " + std::to_string(i));

    Project p; p.sampleRate = sr; p.tempo = bpm; p.tempoMap.setSampleRate(sr); p.tempoMap.setInitialTempo(bpm);
    ProjectTrack tr; tr.name = "Drums";
    ProjectAudioClip c; c.id = 1U; c.audioPath = path; c.timelineStartSample = 0; c.sourceStartSample = 0U; c.lengthSamples = frames; c.sourceFrames = frames; c.sourceChannels = 1U; c.sourceSampleRate = sr;
    tr.clips.push_back(c);
    p.addTrack(tr);
    QuantizeSettings q; q.gridQuarterNotes = 1.0;
    const auto slices = AudioQuantizer::quantizeClip(p, 0U, 1U, q);
    require(slices == 7U, "slices " + std::to_string(slices));
    const auto& clips = p.tracks[0].clips;
    require(clips.size() == 7U, "clip count");
    std::vector<std::int64_t> starts;
    for (const auto& cl : clips) starts.push_back(cl.timelineStartSample);
    std::sort(starts.begin(), starts.end());
    for (std::size_t i = 0U; i < starts.size(); ++i) {
        const double qn = p.tempoMap.quarterNotesAtSample(starts[i]);
        require(std::abs(qn - std::round(qn)) < 0.01, "slice " + std::to_string(i) + " on the grid, qn=" + std::to_string(qn));
    }
    std::int64_t covered = 0;
    for (const auto& cl : clips) { require(cl.lengthSamples > 0U, "slice length"); covered += static_cast<std::int64_t>(cl.lengthSamples); }
    require(covered > static_cast<std::int64_t>(frames) - 2 * 24000, "slices still cover the clip");
    std::remove(path.c_str());
    pass("Audio quantize: transients found within 12 ms, slices land on the quarter-note grid");
}
} // namespace

int main() {
    try {
        testMidiQuantize();
        testGroove();
        testAudioQuantize();
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
    std::cout << passed << " quantize checks passed\n";
    return 0;
}
