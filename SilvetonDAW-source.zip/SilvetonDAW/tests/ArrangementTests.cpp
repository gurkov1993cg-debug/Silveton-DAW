#include "silveton/Arrangement.h"
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silveton;

namespace {
void require(bool c, const std::string& m) { if (!c) throw std::runtime_error(m); }
int passed = 0;
void pass(const char* n) { ++passed; std::cout << "PASS: " << n << '\n'; }

ProjectAudioClip clip(std::uint64_t id, std::int64_t start, std::uint64_t len, std::uint64_t srcStart = 0U) {
    ProjectAudioClip c;
    c.id = id; c.audioPath = "/tmp/none.wav"; c.timelineStartSample = start; c.lengthSamples = len;
    c.sourceStartSample = srcStart; c.sourceFrames = 1000000U; c.sourceChannels = 2U; c.sourceSampleRate = 48000U;
    return c;
}

void testExtensionRoundTrip() {
    Project p;
    p.tempoMap.setSampleRate(48000.0);
    p.notes = "Line one\nTab\there 100% done";
    ProjectTrack t; t.name = "Vox"; t.color = 0x123456U; t.solo = true; t.soloDefeat = true; t.recordArm = true;
    t.monitor = true; t.locked = true; t.folder = 2; t.notes = "take 3\tbest";
    t.clips.push_back(clip(1, 0, 100));
    p.tracks.push_back(t);
    ProjectMidiTrack m; m.name = "Keys"; m.color = 0xABCDEFU; m.mute = true; m.solo = true; m.folder = 2; m.transpose = -5; m.velocityShift = 12;
    p.midiTracks.push_back(m);
    ProjectBus b; b.name = "Drums"; b.color = 0x00FF00U; b.solo = true;
    p.buses.push_back(b);
    FolderTools::addFolder(p, "Band");
    (void)FolderTools::addFolder(p, "Rhythm", 1);
    MarkerTools::add(p, "Verse\tA", 48000);
    MarkerTools::addCycle(p, "Loop", 96000, 144000);
    const auto a = ArrangerTools::addSection(p, "A", 0, 48000);
    const auto bsec = ArrangerTools::addSection(p, "B", 48000, 96000);
    ArrangerTools::appendToChain(p, a, 2);
    ArrangerTools::appendToChain(p, bsec, 1);
    const std::string path = "/tmp/silveton_arrangement_rt.silveton";
    p.save(path);
    const Project r = Project::load(path);
    std::remove(path.c_str());
    require(r.notes == p.notes, "project notes");
    const auto& rt = r.tracks[0];
    require(rt.color == 0x123456U && rt.solo && rt.soloDefeat && rt.recordArm && rt.monitor && rt.locked && rt.folder == 2 &&
                rt.notes == "take 3\tbest", "track meta");
    const auto& rm = r.midiTracks[0];
    require(rm.color == 0xABCDEFU && rm.mute && rm.solo && rm.folder == 2 && rm.transpose == -5 && rm.velocityShift == 12, "MIDI meta");
    require(r.buses[0].color == 0x00FF00U && r.buses[0].solo, "bus meta");
    require(r.folders.size() == 2U && r.folders[1].name == "Rhythm" && r.folders[1].parent == 1, "folders");
    require(r.markers.size() == 2U && r.markers[0].name == "Verse\tA" && r.markers[1].cycle && r.markers[1].endSample == 144000, "markers");
    require(r.arrangerSections.size() == 2U && r.arrangerChain.size() == 2U && r.arrangerChain[0].repeats == 2U, "arranger");
    pass("V26 extension block round-trips track/MIDI/bus state, folders, markers, arranger, notes");
}

void testSoloResolver() {
    Project p;
    for (int i = 0; i < 5; ++i) { ProjectTrack t; t.name = "T" + std::to_string(i); p.tracks.push_back(t); }
    require(SoloResolver::audibleTracks(p).size() == 5U && !SoloResolver::anySolo(p), "no solo => all audible");
    p.tracks[1].solo = true;
    p.tracks[3].soloDefeat = true;
    auto a = SoloResolver::audibleTracks(p);
    require(a == std::vector<std::size_t>({1U, 3U}), "track solo + solo defeat");
    p.tracks[1].solo = false;
    // Instrument track 4 driven by soloed MIDI track.
    ProjectPluginSlot synth; synth.modulePath = "silveton:native"; synth.classId = "silveton.poly"; synth.midiInputPort = 7;
    p.tracks[4].pluginSlots.push_back(synth);
    ProjectMidiTrack m; m.outputPort = 7; m.solo = true;
    p.midiTracks.push_back(m);
    a = SoloResolver::audibleTracks(p);
    require(a == std::vector<std::size_t>({3U, 4U}), "MIDI solo keeps its instrument audible");
    p.midiTracks[0].solo = false;
    // Bus solo: track0 -> bus0 -> bus1 (soloed); track2 sends into bus1.
    ProjectBus b0; b0.outputBus = 1; ProjectBus b1; b1.solo = true;
    p.buses = {b0, b1};
    p.tracks[0].outputBus = 0;
    ProjectSend s; s.destinationBus = 1; p.tracks[2].sends.push_back(s);
    a = SoloResolver::audibleTracks(p);
    require(a == std::vector<std::size_t>({0U, 2U, 3U}), "bus solo keeps every upstream track");

    // Engine application: only the soloed track is heard.
    AudioEngine engine;
    engine.prepare({48000.0, 64U, 0U, 2U});
    AudioBuffer one(2U, 4096U), two(2U, 4096U);
    for (std::size_t i = 0; i < 4096U; ++i) { one.sample(0, i) = one.sample(1, i) = 0.25F; two.sample(0, i) = two.sample(1, i) = 0.5F; }
    engine.addTrack({&one, 0, 0U, 0.0F, 0.0F, false});
    engine.addTrack({&two, 0, 0U, 0.0F, 0.0F, false});
    Project q; q.tracks.resize(2U); q.tracks[1].solo = true;
    SoloResolver::apply(engine, q);
    require(engine.trackRenderMaskActive(), "solo mask not active");
    engine.transport().play();
    float l[64] {}, r[64] {};
    float* outs[2] {l, r};
    engine.processAudio(nullptr, outs, 0U, 2U, 64U);
    const float soloLevel = l[10];
    q.tracks[1].solo = false;
    SoloResolver::apply(engine, q);
    require(!engine.trackRenderMaskActive(), "solo mask not cleared");
    engine.processAudio(nullptr, outs, 0U, 2U, 64U);
    const float allLevel = l[10];
    require(soloLevel > 0.0F && std::abs(allLevel / soloLevel - 1.5F) < 1e-3F,
            "solo level ratio " + std::to_string(allLevel / soloLevel));
    pass("Solo resolver: track/defeat/MIDI-instrument/bus-upstream rules and engine render mask");
}

void testMarkers() {
    Project p;
    const auto m1 = MarkerTools::add(p, "A", 1000);
    const auto m2 = MarkerTools::add(p, "B", 500);
    (void)MarkerTools::addCycle(p, "C", 2000, 3000);
    require(p.markers[0].id == m2, "markers sorted");
    require(MarkerTools::next(p, 500)->id == m1, "next marker");
    require(MarkerTools::previous(p, 1000)->id == m2, "previous marker");
    require(MarkerTools::next(p, 5000) == nullptr, "no next marker");
    require(MarkerTools::move(p, m2, 4000) && p.markers.back().id == m2, "move + resort");
    require(MarkerTools::rename(p, m1, "Chorus") && MarkerTools::find(p, m1)->name == "Chorus", "rename");
    require(MarkerTools::remove(p, m1) && !MarkerTools::find(p, m1), "remove");
    bool threw = false;
    try { (void)MarkerTools::addCycle(p, "bad", 10, 10); } catch (const std::invalid_argument&) { threw = true; }
    require(threw, "empty cycle marker accepted");
    pass("Markers: sorted insert, next/previous navigation, move, rename, remove, cycle validation");
}

void testArrangerFlatten() {
    Project p;
    p.sampleRate = 48000.0;
    p.tempoMap.setSampleRate(48000.0);
    p.tempoMap.setInitialTempo(120.0);   // 1 quarter = 24000 samples
    ProjectTrack t; t.name = "Audio";
    t.clips.push_back(clip(1, 0, 192000, 1000));    // 4 s clip
    auto fadeClip = clip(2, 200000, 10000);
    fadeClip.fadeInSamples = 500; fadeClip.fadeOutSamples = 700;
    t.clips.push_back(fadeClip);
    t.gainAutomationDb.add(0, -6.0F);
    t.gainAutomationDb.add(96000, 0.0F);
    p.tracks.push_back(t);
    ProjectMidiTrack m;
    MusicalMidiNote n; n.startQuarterNotes = 2.5; n.durationQuarterNotes = 0.5; n.pitch = 64;
    (void)m.sequence.addNote(n);   // inside section B (quarters 2..4)
    p.midiTracks.push_back(m);
    const auto A = ArrangerTools::addSection(p, "A", 0, 48000);        // quarters 0..2
    const auto B = ArrangerTools::addSection(p, "B", 48000, 96000);    // quarters 2..4
    bool threw = false;
    try { (void)ArrangerTools::addSection(p, "X", 40000, 50000); } catch (const std::invalid_argument&) { threw = true; }
    require(threw, "overlapping section accepted");
    ArrangerTools::appendToChain(p, A);
    ArrangerTools::appendToChain(p, B, 2);
    ArrangerTools::appendToChain(p, A);
    require(ArrangerTools::chainLengthSamples(p) == 192000, "chain length");
    const Project f = ArrangerTools::flattenChain(p);
    const auto& clips = f.tracks[0].clips;
    require(clips.size() == 4U, "flattened clip count " + std::to_string(clips.size()));
    const std::int64_t expectStart[4] = {0, 48000, 96000, 144000};
    const std::uint64_t expectSrc[4] = {1000, 49000, 49000, 1000};
    for (int i = 0; i < 4; ++i) {
        require(clips[i].timelineStartSample == expectStart[i], "flattened clip start");
        require(clips[i].sourceStartSample == expectSrc[i], "flattened source offset");
        require(clips[i].lengthSamples == 48000U, "flattened clip length");
        require(clips[i].fadeInSamples == 0U && clips[i].fadeOutSamples == 0U, "cropped clip kept fades");
    }
    require(std::abs(f.tracks[0].gainAutomationDb.valueAt(0, 99.0F) + 6.0F) < 1e-4F, "automation start");
    require(std::abs(f.tracks[0].gainAutomationDb.valueAt(144000, 99.0F) + 6.0F) < 1e-4F, "automation copied for repeated A");
    const auto& parts = f.midiTracks[0].parts;
    require(parts.size() == 4U, "MIDI parts per placed section: " + std::to_string(parts.size()));
    require(std::abs(parts[1].timelineStartQuarterNotes - 2.0) < 1e-9 && std::abs(parts[2].timelineStartQuarterNotes - 4.0) < 1e-9 &&
                std::abs(parts[3].timelineStartQuarterNotes - 6.0) < 1e-9, "MIDI part placement");
    const auto plan = compileMidiArrangement(f.midiTracks[0].sequence, parts, f.tempoMap);
    int noteOns = 0;
    for (const auto& e : plan.events()) {
        if ((e.status & 0xF0) == 0x90 && e.data2 > 0) {
            ++noteOns;
            require(e.sample == 60000 || e.sample == 108000, "flattened note at sample " + std::to_string(e.sample));
        }
    }
    require(noteOns == 2, "flattened note count");
    require(f.markers.size() == 4U && f.markers[1].name == "B 1" && f.markers[2].sample == 96000, "section markers");
    require(f.arrangerChain.empty(), "flattened project keeps chain");
    pass("Arranger: overlap validation, chain length, flatten audio/automation/MIDI + section markers");
}

void testTrackToolsRemap() {
    Project p;
    for (int i = 0; i < 3; ++i) p.tracks.emplace_back();
    ProjectBus bus; p.buses.push_back(bus);   // bus node = 3, master = 4
    ProjectPluginSlot comp; comp.modulePath = "silveton:native"; comp.classId = "silveton.press";
    comp.sidechainSourceNode = 2;             // keyed from track 2
    p.tracks[0].pluginSlots.push_back(comp);
    ProjectPluginSlot fromBus = comp; fromBus.sidechainSourceNode = 3;   // keyed from bus 0
    p.tracks[1].pluginSlots.push_back(fromBus);

    p.addTrack(ProjectTrack {});                         // tracks 4 -> bus node now 4
    require(p.tracks[1].pluginSlots[0].sidechainSourceNode == 4, "addTrack did not shift bus node");
    require(p.tracks[0].pluginSlots[0].sidechainSourceNode == 2, "addTrack moved track node");
    TrackTools::insertTrack(p, 0, ProjectTrack {});      // everything shifts by 1
    require(p.tracks[1].pluginSlots[0].sidechainSourceNode == 3 && p.tracks[2].pluginSlots[0].sidechainSourceNode == 5, "insertTrack remap");
    TrackTools::moveTrack(p, 3, 0);                      // key track (node 3) moves to 0
    require(p.tracks[2].pluginSlots[0].sidechainSourceNode == 0, "moveTrack remap");
    TrackTools::removeTrack(p, 0);                       // key track removed
    require(p.tracks[1].pluginSlots[0].sidechainSourceNode == -1, "removed key track not cleared");
    require(p.tracks[2].pluginSlots[0].sidechainSourceNode == 4, "bus node after remove");
    ProjectBus b2; TrackTools::addBus(p, b2);
    require(p.tracks[2].pluginSlots[0].sidechainSourceNode == 4, "addBus moved existing bus node");
    p.tracks[0].outputBus = 1;
    TrackTools::removeBus(p, 0);
    require(p.tracks[2].pluginSlots[0].sidechainSourceNode == -1, "removed bus key not cleared");
    require(p.tracks[0].outputBus == 0, "bus output index not shifted");
    const auto dup = TrackTools::duplicateTrack(p, 0);
    require(dup == 1U && p.tracks.size() == 5U && p.tracks[1].name == " Copy", "duplicate");
    pass("Track tools keep sidechain node references valid across insert/move/remove/bus edits");
}

void testFoldersAndMidiModifiers() {
    Project p;
    const int band = FolderTools::addFolder(p, "Band");
    const int drums = FolderTools::addFolder(p, "Drums", band);
    p.tracks.resize(3U);
    p.tracks[0].folder = drums; p.tracks[1].folder = band;
    require(FolderTools::audioTracksIn(p, band) == std::vector<std::size_t>({0U, 1U}), "folder membership");
    FolderTools::setMute(p, band, true);
    require(p.tracks[0].mute && p.tracks[1].mute && !p.tracks[2].mute, "folder mute");
    require(FolderTools::removeFolder(p, band) && p.tracks[1].folder == -1 && p.folders[0].parent == -1, "folder removal reparents");

    TempoMap map; map.setSampleRate(48000.0);
    ProjectMidiTrack m;
    MusicalMidiNote n; n.pitch = 60; n.velocity = 100;
    (void)m.sequence.addNote(n);
    m.transpose = 7; m.velocityShift = 40;
    const auto plan = compileProjectMidiTrack(m, map);
    require(!plan.events().empty() && plan.events()[0].data1 == 67 && plan.events()[0].data2 == 127, "MIDI modifiers");
    m.mute = true;
    require(compileProjectMidiTrack(m, map).events().empty(), "muted MIDI track still plays");
    require(silvetonPaletteColor(0) != silvetonPaletteColor(1) && effectiveTrackColor(p, 2) == silvetonPaletteColor(2), "palette");
    pass("Folders (nested mute, reparent on removal) and MIDI track transpose/velocity/mute");
}
} // namespace

void testMidiTrackTools() {
    ProjectMidiTrack t;
    MusicalMidiNote n; n.startQuarterNotes = 1.0; n.durationQuarterNotes = 1.0; n.pitch = 60;
    (void)t.sequence.addNote(n);
    MidiTrackTools::ensureParts(t);
    require(t.parts.size() == 1U && t.sequence.notes().empty() && std::abs(t.parts[0].lengthQuarterNotes - 4.0) < 1e-9, "legacy to part");
    MidiSequence rec;
    MusicalMidiNote r1; r1.startQuarterNotes = 9.5; r1.durationQuarterNotes = 3.0; r1.pitch = 64;
    (void)rec.addNote(r1);
    const auto id = MidiTrackTools::addPartFromAbsolute(t, rec);
    const MidiPart* part = MidiTrackTools::findPart(t, id);
    require(part && std::abs(part->timelineStartQuarterNotes - 8.0) < 1e-9 && std::abs(part->lengthQuarterNotes - 8.0) < 1e-9 &&
                std::abs(part->sequence.notes()[0].startQuarterNotes - 1.5) < 1e-9, "recorded part placement");
    TempoMap map; map.setSampleRate(48000.0);
    int ons = 0;
    const auto plan = compileMidiArrangement(t.sequence, t.parts, map);
    for (const auto& e : plan.events()) if ((e.status & 0xF0) == 0x90) ++ons;
    require(ons == 2, "both parts play: " + std::to_string(ons));
    pass("MIDI track tools: legacy->part conversion, bar-aligned recorded part");
}

int main() {
    try {
        testMidiTrackTools();
        testExtensionRoundTrip();
        testSoloResolver();
        testMarkers();
        testArrangerFlatten();
        testTrackToolsRemap();
        testFoldersAndMidiModifiers();
        std::cout << passed << " arrangement checks passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
