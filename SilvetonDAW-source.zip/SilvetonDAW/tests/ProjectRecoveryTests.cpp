#include "silveton/ProjectRecovery.h"
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void require(bool ok, const char* message) { if (!ok) throw std::runtime_error(message); }

silveton::Project makeProject(const std::string& name, float gain) {
    silveton::Project p;
    p.sampleRate = 48000.0;
    p.tempo = 120.0;
    p.tempoMap.setSampleRate(48000.0);
    p.tempoMap.setInitialTempo(120.0);
    silveton::ProjectTrack t;
    t.name = name;
    t.gainDb = gain;
    p.addTrack(std::move(t));
    return p;
}
}

int main() {
    const std::string path = "/tmp/SilvetonRecoveryTest.silv";
    const std::string backup = silveton::ProjectRecovery::backupPath(path);
    const std::string autosave = silveton::ProjectRecovery::autosavePath(path);
    (void)std::remove(path.c_str());
    (void)std::remove(backup.c_str());
    (void)std::remove(autosave.c_str());
    (void)std::remove((path + ".tmp").c_str());
    (void)std::remove((autosave + ".tmp").c_str());

    auto first = makeProject("first", -1.0F);
    silveton::ProjectRecovery::safeSave(first, path);
    auto loaded = silveton::ProjectRecovery::loadBestAvailable(path);
    require(loaded.source == silveton::ProjectRecoverySource::Primary, "primary recovery source mismatch");
    require(loaded.project.tracks.size() == 1U && loaded.project.tracks[0].name == "first", "primary project mismatch");

    auto second = makeProject("second", -2.0F);
    silveton::ProjectRecovery::safeSave(second, path);
    const auto old = silveton::Project::load(backup);
    require(old.tracks[0].name == "first", "backup did not preserve previous project");

    auto automatic = makeProject("autosave", -3.0F);
    silveton::ProjectRecovery::autosave(automatic, path);
    {
        std::ofstream broken(path.c_str(), std::ios::binary | std::ios::trunc);
        broken << "BROKEN\n";
    }
    loaded = silveton::ProjectRecovery::loadBestAvailable(path);
    require(loaded.source == silveton::ProjectRecoverySource::Autosave, "autosave recovery was not preferred");
    require(loaded.project.tracks[0].name == "autosave", "autosave project mismatch");

    {
        std::ofstream broken(autosave.c_str(), std::ios::binary | std::ios::trunc);
        broken << "BROKEN TOO\n";
    }
    loaded = silveton::ProjectRecovery::loadBestAvailable(path);
    require(loaded.source == silveton::ProjectRecoverySource::Backup, "backup recovery fallback mismatch");
    require(loaded.project.tracks[0].name == "first", "backup recovery project mismatch");

    auto invalid = makeProject("invalid", 0.0F);
    silveton::ProjectAudioClip clip;
    clip.id = 1U;
    clip.audioPath = ""; // Project::save must reject this before target rotation.
    clip.sourceFrames = 10U;
    clip.lengthSamples = 10U;
    invalid.tracks[0].clips.push_back(clip);
    bool rejected = false;
    try { silveton::ProjectRecovery::safeSave(invalid, backup); }
    catch (...) { rejected = true; }
    require(rejected, "invalid project save was not rejected");
    const auto preserved = silveton::Project::load(backup);
    require(preserved.tracks[0].name == "first", "failed save damaged previous project");

    (void)std::remove(path.c_str());
    (void)std::remove(backup.c_str());
    (void)std::remove(autosave.c_str());
    std::cout << "PASS: validated save/backup/autosave/recovery\n";
    return 0;
}
