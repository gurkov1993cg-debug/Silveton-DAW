#include "silveton/TakeComp.h"
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include <unistd.h>

namespace {

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

std::string tempPath(const char* stem) {
    return std::string("/tmp/") + stem + "_" + std::to_string(static_cast<long long>(::getpid())) + ".svp";
}

silveton::ProjectTakeLane makeLane(std::uint64_t laneId,
                                   std::uint64_t pass,
                                   std::uint64_t sourceStart,
                                   float gainDb = 0.0F) {
    silveton::ProjectTakeLane lane;
    lane.id = laneId;
    lane.cyclePass = pass;
    lane.name = "Take " + std::to_string(laneId);
    silveton::ProjectAudioClip clip;
    clip.id = 1U;
    clip.audioPath = "/tmp/shared_take.wav";
    clip.timelineStartSample = 0;
    clip.sourceStartSample = sourceStart;
    clip.lengthSamples = 16U;
    clip.sourceFrames = 32U;
    clip.gainDb = gainDb;
    lane.clips.push_back(clip);
    return lane;
}

void testTakeLaneBuilder() {
    std::vector<silveton::RecordedTimelineSpan> spans {
        {0U, 30, 5U, 0U},
        {5U, 25, 10U, 1U}
    };
    const auto lanes = silveton::TakeLaneBuilder::fromRecordedTimelineSpans(
        "/tmp/loop.wav", 15U, spans, false);
    require(lanes.size() == 2U, "take builder did not create one lane per cycle pass");
    require(lanes[0].cyclePass == 0U && lanes[0].clips.size() == 1U, "first take lane mismatch");
    require(lanes[0].clips[0].sourceStartSample == 0U && lanes[0].clips[0].timelineStartSample == 30 &&
            lanes[0].clips[0].lengthSamples == 5U, "first take clip range mismatch");
    require(lanes[1].cyclePass == 1U && lanes[1].clips[0].sourceStartSample == 5U &&
            lanes[1].clips[0].timelineStartSample == 25 && lanes[1].clips[0].lengthSamples == 10U,
            "second take clip range mismatch");

    bool rejectedOverflow = false;
    try {
        (void)silveton::TakeLaneBuilder::fromRecordedTimelineSpans("/tmp/loop.wav", 15U, spans, true);
    } catch (const std::runtime_error&) {
        rejectedOverflow = true;
    }
    require(rejectedOverflow, "take builder accepted an overflowed recording span journal");
}

void testCompOverwriteCrossfadeAndUndo() {
    silveton::Project project;
    project.tracks.push_back({});
    auto& track = project.tracks[0];
    track.takeLanes.push_back(makeLane(1U, 0U, 0U));
    track.takeLanes.push_back(makeLane(2U, 1U, 16U));

    silveton::CompEditor editor(project, 0U);
    const auto baseId = editor.selectRange(1U, 1U, 0, 16, 0U);
    require(baseId != 0U, "base comp section id is zero");
    require(track.compSections.size() == 1U && track.clips.size() == 1U,
            "base comp did not materialize one active clip");
    require(track.clips[0].sourceStartSample == 0U && track.clips[0].lengthSamples == 16U,
            "base comp source range mismatch");

    const auto middleId = editor.selectRange(2U, 1U, 4, 12, 2U);
    require(middleId != 0U, "middle comp section id is zero");
    require(track.compSections.size() == 3U, "range overwrite did not preserve left/right comp sections");
    require(track.clips.size() == 3U, "range overwrite did not materialize three active clips");

    // Left section 0..4 is extended two samples into the new middle section.
    require(track.clips[0].timelineStartSample == 0 && track.clips[0].lengthSamples == 6U,
            "left comp crossfade extension mismatch");
    require(track.clips[0].fadeOutSamples == 2U, "left comp fade-out mismatch");
    require(track.clips[1].timelineStartSample == 4 && track.clips[1].sourceStartSample == 20U,
            "middle comp source offset mismatch");
    require(track.clips[1].fadeInSamples == 2U, "middle comp fade-in mismatch");

    // Preserved right section starts at 12 and receives the same boundary crossfade.
    require(track.clips[1].lengthSamples == 10U && track.clips[1].fadeOutSamples == 2U,
            "middle-to-right crossfade extension mismatch");
    require(track.clips[2].timelineStartSample == 12 && track.clips[2].sourceStartSample == 12U &&
            track.clips[2].fadeInSamples == 2U, "right comp crossfade mismatch");

    require(editor.undo(), "comp undo failed");
    require(track.compSections.size() == 1U && track.clips.size() == 1U && track.clips[0].lengthSamples == 16U,
            "comp undo did not restore previous take selection");
    require(editor.redo(), "comp redo failed");
    require(track.compSections.size() == 3U && track.clips.size() == 3U,
            "comp redo did not restore overwritten selection");

    editor.clearRange(6, 10);
    require(track.compSections.size() == 4U, "comp clear range did not split surrounding sections correctly");
    for (const auto& section : track.compSections) {
        const auto end = section.timelineStartSample + static_cast<std::int64_t>(section.lengthSamples);
        require(end <= 6 || section.timelineStartSample >= 10, "comp clear range left selected audio inside cleared area");
    }
}

void testCrossfadeDoesNotReadOutsideTakeClip() {
    silveton::Project project;
    project.tracks.push_back({});
    auto& track = project.tracks[0];
    // First lane's clip ends exactly at sample 8 even though the WAV continues.
    auto lane1 = makeLane(1U, 0U, 0U);
    lane1.clips[0].lengthSamples = 8U;
    auto lane2 = makeLane(2U, 1U, 16U);
    track.takeLanes = {lane1, lane2};

    silveton::CompEditor editor(project, 0U);
    (void)editor.selectRange(1U, 1U, 0, 8, 0U);
    (void)editor.selectRange(2U, 1U, 8, 16, 4U);
    require(track.clips.size() == 2U, "bounded crossfade comp size mismatch");
    require(track.clips[0].lengthSamples == 8U && track.clips[0].fadeOutSamples == 0U,
            "crossfade illegally read beyond first take clip boundary");
    require(track.clips[1].fadeInSamples == 0U,
            "one-sided crossfade remained after previous take boundary rejected overlap");
}

void testProjectV21RoundTripAndV20Compatibility() {
    silveton::Project project;
    project.sampleRate = 48000.0;
    project.tempoMap.setSampleRate(48000.0);
    project.tempoMap.setInitialTempo(120.0);
    project.tracks.push_back({});
    auto& track = project.tracks[0];
    track.name = "Lead Vocal";
    track.takeLanes = {makeLane(1U, 0U, 0U), makeLane(2U, 1U, 16U)};
    silveton::CompEditor editor(project, 0U);
    (void)editor.selectRange(1U, 1U, 0, 8, 0U);
    (void)editor.selectRange(2U, 1U, 8, 16, 3U);

    const std::string path = tempPath("silveton_take_comp_v21");
    std::remove(path.c_str());
    project.save(path);
    const silveton::Project restored = silveton::Project::load(path);
    require(restored.tracks.size() == 1U, "V21 round-trip lost track");
    const auto& rt = restored.tracks[0];
    require(rt.takeLanes.size() == 2U && rt.compSections.size() == 2U,
            "V21 round-trip lost take lanes or comp sections");
    require(rt.takeLanes[0].cyclePass == 0U && rt.takeLanes[1].cyclePass == 1U,
            "V21 round-trip changed take pass numbers");
    require(rt.compSections[1].takeLaneId == 2U && rt.compSections[1].timelineStartSample == 8 &&
            rt.compSections[1].lengthSamples == 8U && rt.compSections[1].crossfadeSamples == 3U,
            "V21 round-trip changed comp selection");
    require(rt.clips.size() == 2U && rt.clips[0].fadeOutSamples == 3U && rt.clips[1].fadeInSamples == 3U,
            "V21 round-trip changed materialized comp clips");
    std::remove(path.c_str());

    // Build an exact V20-compatible file from a project that has no take data.
    silveton::Project legacySource;
    legacySource.sampleRate = 48000.0;
    legacySource.tempoMap.setSampleRate(48000.0);
    legacySource.tempoMap.setInitialTempo(120.0);
    legacySource.tracks.push_back({});
    legacySource.tracks[0].name = "Legacy";
    const std::string v21Empty = tempPath("silveton_empty_v21");
    const std::string v20Path = tempPath("silveton_legacy_v20");
    legacySource.save(v21Empty);
    std::ifstream in(v21Empty);
    std::ofstream out(v20Path);
    std::string line;
    bool first = true;
    while (std::getline(in, line)) {
        if (first) { out << "SILVETON_PROJECT_V20\n"; first = false; continue; }
        if (line == "TAKE_LANES\t0" || line == "COMP\t0") continue;
        out << line << '\n';
    }
    out.close();
    in.close();
    const silveton::Project legacy = silveton::Project::load(v20Path);
    require(legacy.tracks.size() == 1U && legacy.tracks[0].name == "Legacy",
            "V20 backward compatibility failed after V21 take format");
    require(legacy.tracks[0].takeLanes.empty() && legacy.tracks[0].compSections.empty(),
            "V20 load invented take/comp data");
    std::remove(v21Empty.c_str());
    std::remove(v20Path.c_str());
}

} // namespace

int main() {
    try {
        testTakeLaneBuilder();
        testCompOverwriteCrossfadeAndUndo();
        testCrossfadeDoesNotReadOutsideTakeClip();
        testProjectV21RoundTripAndV20Compatibility();
        std::cout << "PASS: loop recording spans become nondestructive take lanes\n";
        std::cout << "PASS: comp range overwrite preserves surrounding selections with bounded crossfades\n";
        std::cout << "PASS: comp edit Undo/Redo restores complete logical and active clip state\n";
        std::cout << "PASS: V21 saves take lanes/comp state and V20 remains loadable\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
