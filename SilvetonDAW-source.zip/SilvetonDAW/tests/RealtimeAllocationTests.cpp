#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <new>
#include <stdexcept>
#include <vector>

namespace {
std::atomic<bool> gTrackAllocations {false};
std::atomic<std::size_t> gAllocationCount {0U};
}

void* operator new(std::size_t size) {
    if (gTrackAllocations.load(std::memory_order_relaxed)) gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}

void* operator new[](std::size_t size) {
    if (gTrackAllocations.load(std::memory_order_relaxed)) gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}

void* operator new(std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackAllocations.load(std::memory_order_relaxed)) gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    return std::malloc(size);
}

void* operator new[](std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackAllocations.load(std::memory_order_relaxed)) gAllocationCount.fetch_add(1U, std::memory_order_relaxed);
    return std::malloc(size);
}

void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }
void operator delete(void* p, const std::nothrow_t&) noexcept { std::free(p); }
void operator delete[](void* p, const std::nothrow_t&) noexcept { std::free(p); }

int main() {
    try {
        constexpr std::uint32_t block = 64U;
        constexpr std::size_t trackCount = 512U;

        silveton::AudioEngine engine;
        engine.prepare({48000.0, block, 0U, 2U});

        silveton::AudioBuffer source(2U, block);
        for (std::size_t i = 0; i < block; ++i) {
            source.sample(0U, i) = 0.01F;
            source.sample(1U, i) = -0.01F;
        }

        for (std::size_t i = 0; i < trackCount; ++i)
            engine.addTrack({&source, 0, 0U, 0.0F, 0.0F, false, true, 0});

        silveton::ManualAudioDevice device({48000.0, block, 0U, 2U});
        device.start(engine);
        engine.transport().play();

        // Warm-up outside the measured region.
        device.pump();
        engine.transport().seekSamples(0);

        gAllocationCount.store(0U, std::memory_order_relaxed);
        gTrackAllocations.store(true, std::memory_order_release);
        for (int i = 0; i < 2000; ++i) {
            engine.transport().seekSamples(0);
            device.pump();
        }
        gTrackAllocations.store(false, std::memory_order_release);

        if (gAllocationCount.load(std::memory_order_acquire) != 0U)
            throw std::runtime_error("heap allocation occurred in audio callback path");

        const float expected = static_cast<float>(trackCount) * 0.01F;
        if (std::abs(device.lastOutput()[0][0] - expected) > 2.0e-4F)
            throw std::runtime_error("512-track summing stress produced incorrect left output");
        if (std::abs(device.lastOutput()[1][0] + expected) > 2.0e-4F)
            throw std::runtime_error("512-track summing stress produced incorrect right output");

        device.stop();
        std::cout << "PASS: 512-track real-time summing stress\n";
        std::cout << "PASS: 2000 callback iterations with zero heap allocations\n";
        return 0;
    } catch (const std::exception& e) {
        gTrackAllocations.store(false, std::memory_order_release);
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
