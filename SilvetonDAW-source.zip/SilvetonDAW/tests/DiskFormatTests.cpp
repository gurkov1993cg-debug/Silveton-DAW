#include "silveton/DiskStream.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

template <typename T>
void writeLE(std::FILE* f, T value) {
    if (std::fwrite(&value, sizeof(T), 1U, f) != 1U) throw std::runtime_error("test WAV write failed");
}

std::string tempPath(const char* name) {
    const char* env = std::getenv("TMPDIR");
    std::string base = (env != nullptr && *env != '\0') ? std::string(env) : std::string("/tmp");
    if (!base.empty() && base.back() != '/') base += '/';
    return base + name;
}

void writePcm16(const std::string& path) {
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (f == nullptr) throw std::runtime_error("cannot create PCM16 test WAV");
    const std::uint16_t channels = 2U;
    const std::uint32_t sampleRate = 48000U;
    const std::uint16_t blockAlign = channels * sizeof(std::int16_t);
    const std::uint32_t frames = 32U;
    const std::uint32_t dataBytes = frames * blockAlign;
    std::fwrite("RIFF", 1U, 4U, f); writeLE(f, std::uint32_t{36U + dataBytes}); std::fwrite("WAVE", 1U, 4U, f);
    std::fwrite("fmt ", 1U, 4U, f); writeLE(f, std::uint32_t{16U}); writeLE(f, std::uint16_t{1U});
    writeLE(f, channels); writeLE(f, sampleRate); writeLE(f, sampleRate * blockAlign); writeLE(f, blockAlign); writeLE(f, std::uint16_t{16U});
    std::fwrite("data", 1U, 4U, f); writeLE(f, dataBytes);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const std::int16_t l = static_cast<std::int16_t>(1000 + static_cast<int>(i));
        const std::int16_t r = static_cast<std::int16_t>(-2000 - static_cast<int>(i));
        writeLE(f, l); writeLE(f, r);
    }
    std::fclose(f);
}

void writeSmallRf64Float(const std::string& path) {
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (f == nullptr) throw std::runtime_error("cannot create RF64 test WAV");
    const std::uint16_t channels = 2U;
    const std::uint32_t sampleRate = 48000U;
    const std::uint16_t blockAlign = channels * sizeof(float);
    const std::uint64_t frames = 32U;
    const std::uint64_t dataBytes = frames * blockAlign;
    const std::uint64_t riffSize = 72U + dataBytes;

    std::fwrite("RF64", 1U, 4U, f); writeLE(f, std::uint32_t{0xFFFFFFFFU}); std::fwrite("WAVE", 1U, 4U, f);
    std::fwrite("ds64", 1U, 4U, f); writeLE(f, std::uint32_t{28U});
    writeLE(f, riffSize); writeLE(f, dataBytes); writeLE(f, frames); writeLE(f, std::uint32_t{0U});
    std::fwrite("fmt ", 1U, 4U, f); writeLE(f, std::uint32_t{16U}); writeLE(f, std::uint16_t{3U});
    writeLE(f, channels); writeLE(f, sampleRate); writeLE(f, sampleRate * blockAlign); writeLE(f, blockAlign); writeLE(f, std::uint16_t{32U});
    std::fwrite("data", 1U, 4U, f); writeLE(f, std::uint32_t{0xFFFFFFFFU});
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const float l = 0.01F * static_cast<float>(i);
        const float r = -0.02F * static_cast<float>(i);
        writeLE(f, l); writeLE(f, r);
    }
    std::fclose(f);
}
}

int main() {
    using namespace silveton;
    try {
        const std::string pcmPath = tempPath("silveton_pcm16_stream.wav");
        const std::string rf64Path = tempPath("silveton_rf64_stream.wav");
        std::remove(pcmPath.c_str());
        std::remove(rf64Path.c_str());
        writePcm16(pcmPath);
        writeSmallRf64Float(rf64Path);

        DiskStreamManager manager(4U);
        auto& pcm = manager.addSource(pcmPath, 32U);
        auto& rf64 = manager.addSource(rf64Path, 32U);
        require(pcm.channels() == 2U && pcm.frames() == 32U, "PCM16 metadata parse failed");
        require(rf64.channels() == 2U && rf64.frames() == 32U, "RF64 metadata parse failed");
        manager.start();
        require(manager.prime(0U, 5000U), "format cache prime failed");

        DiskBlockView pcmView;
        require(pcm.acquire(0U, 32U, pcmView), "PCM16 cache acquire failed");
        const std::size_t pcmBase = 7U * pcmView.channels;
        require(std::abs(pcmView.interleaved[pcmBase] - (1007.0F / 32768.0F)) < 1.0e-7F,
                "PCM16 left conversion mismatch");
        require(std::abs(pcmView.interleaved[pcmBase + 1U] - (-2007.0F / 32768.0F)) < 1.0e-7F,
                "PCM16 right conversion mismatch");
        pcm.release(pcmView);

        DiskBlockView rf64View;
        require(rf64.acquire(0U, 32U, rf64View), "RF64 cache acquire failed");
        const std::size_t rf64Base = 11U * rf64View.channels;
        require(std::abs(rf64View.interleaved[rf64Base] - 0.11F) < 1.0e-7F,
                "RF64 left sample mismatch");
        require(std::abs(rf64View.interleaved[rf64Base + 1U] + 0.22F) < 1.0e-7F,
                "RF64 right sample mismatch");
        rf64.release(rf64View);

        require(!pcm.status().ioError && !rf64.status().ioError, "format streamer reported I/O error");
        manager.stop();
        std::remove(pcmPath.c_str());
        std::remove(rf64Path.c_str());

        std::cout << "PASS: disk cache streams PCM16 WAV and converts samples correctly\n";
        std::cout << "PASS: disk cache parses and streams RF64 Float32 takes\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
