#include "silveton/DiskStream.h"
#include "silveton/WavFile.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

template <typename T>
void writeLE(std::FILE* f, T value) {
    if (std::fwrite(&value, sizeof(T), 1U, f) != 1U) throw std::runtime_error("test WAV write failed");
}

std::string tempPath(const char* name) {
    const char* env = std::getenv("TMPDIR");
    std::string base = (env != nullptr && *env != '\0') ? std::string(env) : std::string("/tmp");
    if (!base.empty() && base.back() != '/') base += '/';
    return base + name;
}

void writePcm16(const std::string& path) {
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (f == nullptr) throw std::runtime_error("cannot create PCM16 test WAV");
    const std::uint16_t channels = 2U;
    const std::uint32_t sampleRate = 48000U;
    const std::uint16_t blockAlign = channels * sizeof(std::int16_t);
    const std::uint32_t frames = 32U;
    const std::uint32_t dataBytes = frames * blockAlign;
    std::fwrite("RIFF", 1U, 4U, f); writeLE(f, std::uint32_t{36U + dataBytes}); std::fwrite("WAVE", 1U, 4U, f);
    std::fwrite("fmt ", 1U, 4U, f); writeLE(f, std::uint32_t{16U}); writeLE(f, std::uint16_t{1U});
    writeLE(f, channels); writeLE(f, sampleRate); writeLE(f, sampleRate * blockAlign); writeLE(f, blockAlign); writeLE(f, std::uint16_t{16U});
    std::fwrite("data", 1U, 4U, f); writeLE(f, dataBytes);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const std::int16_t l = static_cast<std::int16_t>(1000 + static_cast<int>(i));
        const std::int16_t r = static_cast<std::int16_t>(-2000 - static_cast<int>(i));
        writeLE(f, l); writeLE(f, r);
    }
    std::fclose(f);
}

void writeBE16(std::FILE* f, std::uint16_t value) {
    const unsigned char bytes[2] {static_cast<unsigned char>((value >> 8U) & 0xFFU), static_cast<unsigned char>(value & 0xFFU)};
    if (std::fwrite(bytes, 1U, 2U, f) != 2U) throw std::runtime_error("test AIFF write failed");
}

void writeBE32(std::FILE* f, std::uint32_t value) {
    const unsigned char bytes[4] {static_cast<unsigned char>((value >> 24U) & 0xFFU), static_cast<unsigned char>((value >> 16U) & 0xFFU),
                                  static_cast<unsigned char>((value >> 8U) & 0xFFU), static_cast<unsigned char>(value & 0xFFU)};
    if (std::fwrite(bytes, 1U, 4U, f) != 4U) throw std::runtime_error("test AIFF write failed");
}

void writeExtended80(std::FILE* f, double value) {
    int exponent = 0;
    double fraction = std::frexp(value, &exponent);
    fraction *= 2.0;
    --exponent;
    writeBE16(f, static_cast<std::uint16_t>(exponent + 16383));
    const auto mantissa = static_cast<std::uint64_t>(static_cast<long double>(fraction) * 9223372036854775808.0L);
    for (int i = 7; i >= 0; --i) {
        const unsigned char byte = static_cast<unsigned char>((mantissa >> (i * 8)) & 0xFFU);
        if (std::fwrite(&byte, 1U, 1U, f) != 1U) throw std::runtime_error("test AIFF write failed");
    }
}

void writePcmWav(const std::string& path, std::uint16_t bits) {
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (f == nullptr) throw std::runtime_error("cannot create PCM WAV test file");
    const std::uint16_t channels = 2U;
    const std::uint32_t sampleRate = 48000U;
    const std::uint16_t bytesPerSample = static_cast<std::uint16_t>(bits / 8U);
    const std::uint16_t blockAlign = static_cast<std::uint16_t>(channels * bytesPerSample);
    const std::uint32_t frames = 32U;
    const std::uint32_t dataBytes = frames * blockAlign;
    std::fwrite("RIFF", 1U, 4U, f); writeLE(f, std::uint32_t{36U + dataBytes}); std::fwrite("WAVE", 1U, 4U, f);
    std::fwrite("fmt ", 1U, 4U, f); writeLE(f, std::uint32_t{16U}); writeLE(f, std::uint16_t{1U});
    writeLE(f, channels); writeLE(f, sampleRate); writeLE(f, sampleRate * blockAlign); writeLE(f, blockAlign); writeLE(f, bits);
    std::fwrite("data", 1U, 4U, f); writeLE(f, dataBytes);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const std::int32_t left = bits == 24U ? (0x100000 + static_cast<std::int32_t>(i) * 257) : (0x10000000 + static_cast<std::int32_t>(i) * 65537);
        const std::int32_t right = -left;
        for (const std::int32_t sample : {left, right}) {
            const std::uint32_t raw = static_cast<std::uint32_t>(sample);
            for (unsigned byte = 0U; byte < bytesPerSample; ++byte) {
                const unsigned char value = static_cast<unsigned char>((raw >> (8U * byte)) & 0xFFU);
                if (std::fwrite(&value, 1U, 1U, f) != 1U) throw std::runtime_error("test PCM WAV write failed");
            }
        }
    }
    std::fclose(f);
}

void writePcmAiff(const std::string& path, std::uint16_t bits) {
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (f == nullptr) throw std::runtime_error("cannot create PCM AIFF test file");
    const std::uint16_t channels = 2U;
    const std::uint32_t sampleRate = 48000U;
    const std::uint16_t bytesPerSample = static_cast<std::uint16_t>(bits / 8U);
    const std::uint32_t frames = 32U;
    const std::uint32_t dataBytes = frames * channels * bytesPerSample;
    std::fwrite("FORM", 1U, 4U, f); writeBE32(f, 46U + dataBytes); std::fwrite("AIFF", 1U, 4U, f);
    std::fwrite("COMM", 1U, 4U, f); writeBE32(f, 18U); writeBE16(f, channels); writeBE32(f, frames); writeBE16(f, bits); writeExtended80(f, sampleRate);
    std::fwrite("SSND", 1U, 4U, f); writeBE32(f, dataBytes + 8U); writeBE32(f, 0U); writeBE32(f, 0U);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const std::int32_t left = bits == 16U ? (4096 + static_cast<std::int32_t>(i)) :
                                  bits == 24U ? (0x100000 + static_cast<std::int32_t>(i) * 257) :
                                                (0x10000000 + static_cast<std::int32_t>(i) * 65537);
        const std::int32_t right = -left;
        for (const std::int32_t sample : {left, right}) {
            const std::uint32_t raw = static_cast<std::uint32_t>(sample);
            for (int byte = static_cast<int>(bytesPerSample) - 1; byte >= 0; --byte) {
                const unsigned char value = static_cast<unsigned char>((raw >> (8U * static_cast<unsigned>(byte))) & 0xFFU);
                if (std::fwrite(&value, 1U, 1U, f) != 1U) throw std::runtime_error("test PCM AIFF write failed");
            }
        }
    }
    std::fclose(f);
}

void writeSmallRf64Float(const std::string& path) {
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (f == nullptr) throw std::runtime_error("cannot create RF64 test WAV");
    const std::uint16_t channels = 2U;
    const std::uint32_t sampleRate = 48000U;
    const std::uint16_t blockAlign = channels * sizeof(float);
    const std::uint64_t frames = 32U;
    const std::uint64_t dataBytes = frames * blockAlign;
    const std::uint64_t riffSize = 72U + dataBytes;

    std::fwrite("RF64", 1U, 4U, f); writeLE(f, std::uint32_t{0xFFFFFFFFU}); std::fwrite("WAVE", 1U, 4U, f);
    std::fwrite("ds64", 1U, 4U, f); writeLE(f, std::uint32_t{28U});
    writeLE(f, riffSize); writeLE(f, dataBytes); writeLE(f, frames); writeLE(f, std::uint32_t{0U});
    std::fwrite("fmt ", 1U, 4U, f); writeLE(f, std::uint32_t{16U}); writeLE(f, std::uint16_t{3U});
    writeLE(f, channels); writeLE(f, sampleRate); writeLE(f, sampleRate * blockAlign); writeLE(f, blockAlign); writeLE(f, std::uint16_t{32U});
    std::fwrite("data", 1U, 4U, f); writeLE(f, std::uint32_t{0xFFFFFFFFU});
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const float l = 0.01F * static_cast<float>(i);
        const float r = -0.02F * static_cast<float>(i);
        writeLE(f, l); writeLE(f, r);
    }
    std::fclose(f);
}
}

int main() {
    using namespace silveton;
    try {
        const std::string pcmPath = tempPath("silveton_pcm16_stream.wav");
        const std::string pcm24Path = tempPath("silveton_pcm24_stream.wav");
        const std::string pcm32Path = tempPath("silveton_pcm32_stream.wav");
        const std::string aiff16Path = tempPath("silveton_pcm16_stream.aiff");
        const std::string aiff24Path = tempPath("silveton_pcm24_stream.aiff");
        const std::string aiff32Path = tempPath("silveton_pcm32_stream.aiff");
        const std::string rf64Path = tempPath("silveton_rf64_stream.wav");
        for (const auto& path : {pcmPath, pcm24Path, pcm32Path, aiff16Path, aiff24Path, aiff32Path, rf64Path}) std::remove(path.c_str());
        writePcm16(pcmPath);
        writePcmWav(pcm24Path, 24U);
        writePcmWav(pcm32Path, 32U);
        writePcmAiff(aiff16Path, 16U);
        writePcmAiff(aiff24Path, 24U);
        writePcmAiff(aiff32Path, 32U);
        writeSmallRf64Float(rf64Path);

        const auto pcm24Memory = WavFile::read(pcm24Path);
        const auto pcm32Memory = WavFile::read(pcm32Path);
        require(pcm24Memory.audio.frames() == 32U && pcm32Memory.audio.frames() == 32U, "PCM24/32 WAV memory reader failed");
        require(std::abs(pcm24Memory.audio.sample(0U, 7U) - static_cast<float>((0x100000 + 7 * 257) / 8388608.0)) < 2.0e-7F,
                "PCM24 WAV memory conversion mismatch");
        require(std::abs(pcm32Memory.audio.sample(1U, 9U) + static_cast<float>((0x10000000 + 9 * 65537) / 2147483648.0)) < 2.0e-7F,
                "PCM32 WAV memory conversion mismatch");

        DiskStreamManager manager(8U);
        auto& pcm = manager.addSource(pcmPath, 32U);
        auto& pcm24 = manager.addSource(pcm24Path, 32U);
        auto& pcm32 = manager.addSource(pcm32Path, 32U);
        auto& aiff16 = manager.addSource(aiff16Path, 32U);
        auto& aiff24 = manager.addSource(aiff24Path, 32U);
        auto& aiff32 = manager.addSource(aiff32Path, 32U);
        auto& rf64 = manager.addSource(rf64Path, 32U);
        require(pcm.channels() == 2U && pcm.frames() == 32U, "PCM16 metadata parse failed");
        require(rf64.channels() == 2U && rf64.frames() == 32U, "RF64 metadata parse failed");
        manager.start();
        require(manager.prime(0U, 5000U), "format cache prime failed");

        DiskBlockView pcmView;
        require(pcm.acquire(0U, 32U, pcmView), "PCM16 cache acquire failed");
        const std::size_t pcmBase = 7U * pcmView.channels;
        require(std::abs(pcmView.interleaved[pcmBase] - (1007.0F / 32768.0F)) < 1.0e-7F,
                "PCM16 left conversion mismatch");
        require(std::abs(pcmView.interleaved[pcmBase + 1U] - (-2007.0F / 32768.0F)) < 1.0e-7F,
                "PCM16 right conversion mismatch");
        pcm.release(pcmView);

        const auto checkPcmSource = [](DiskAudioSource& source, std::uint32_t frame, float expectedLeft, float expectedRight, const char* message) {
            DiskBlockView view;
            require(source.acquire(0U, 32U, view), message);
            const std::size_t base = static_cast<std::size_t>(frame) * view.channels;
            require(std::abs(view.interleaved[base] - expectedLeft) < 2.0e-7F, message);
            require(std::abs(view.interleaved[base + 1U] - expectedRight) < 2.0e-7F, message);
            source.release(view);
        };
        checkPcmSource(pcm24, 7U, static_cast<float>((0x100000 + 7 * 257) / 8388608.0),
                       -static_cast<float>((0x100000 + 7 * 257) / 8388608.0), "PCM24 stream conversion mismatch");
        checkPcmSource(pcm32, 9U, static_cast<float>((0x10000000 + 9 * 65537) / 2147483648.0),
                       -static_cast<float>((0x10000000 + 9 * 65537) / 2147483648.0), "PCM32 stream conversion mismatch");
        checkPcmSource(aiff16, 6U, static_cast<float>((4096 + 6) / 32768.0),
                       -static_cast<float>((4096 + 6) / 32768.0), "AIFF PCM16 stream conversion mismatch");
        checkPcmSource(aiff24, 8U, static_cast<float>((0x100000 + 8 * 257) / 8388608.0),
                       -static_cast<float>((0x100000 + 8 * 257) / 8388608.0), "AIFF PCM24 stream conversion mismatch");
        checkPcmSource(aiff32, 10U, static_cast<float>((0x10000000 + 10 * 65537) / 2147483648.0),
                       -static_cast<float>((0x10000000 + 10 * 65537) / 2147483648.0), "AIFF PCM32 stream conversion mismatch");

        DiskBlockView rf64View;
        require(rf64.acquire(0U, 32U, rf64View), "RF64 cache acquire failed");
        const std::size_t rf64Base = 11U * rf64View.channels;
        require(std::abs(rf64View.interleaved[rf64Base] - 0.11F) < 1.0e-7F,
                "RF64 left sample mismatch");
        require(std::abs(rf64View.interleaved[rf64Base + 1U] + 0.22F) < 1.0e-7F,
                "RF64 right sample mismatch");
        rf64.release(rf64View);

        require(!pcm.status().ioError && !pcm24.status().ioError && !pcm32.status().ioError &&
                !aiff16.status().ioError && !aiff24.status().ioError && !aiff32.status().ioError && !rf64.status().ioError,
                "format streamer reported I/O error");
        manager.stop();
        for (const auto& path : {pcmPath, pcm24Path, pcm32Path, aiff16Path, aiff24Path, aiff32Path, rf64Path}) std::remove(path.c_str());

        std::cout << "PASS: WAV memory reader handles PCM16/24/32 and Float32/RF64\n";
        std::cout << "PASS: disk cache streams WAV PCM16/24/32 and RF64 Float32\n";
        std::cout << "PASS: disk cache streams AIFF PCM16/24/32 with big-endian conversion\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
