// Studio-sinc sample-rate conversion (the sampler's interpolation) and the
// 96 kHz internal-rate bridge.
#include "silveton/AudioEngine.h"
#include "silveton/DawRuntimeCoordinator.h"
#include "silveton/EngineRateBridge.h"
#include "silveton/NativePlugins.h"
#include "silveton/ProjectSession.h"
#include "silveton/StudioResampler.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace silveton;

namespace {

constexpr double kPi = 3.14159265358979323846;
int passed = 0;

void require(bool c, const std::string& m) { if (!c) throw std::runtime_error(m); }
void pass(const char* n) { ++passed; std::cout << "PASS: " << n << '\n'; }

AudioBuffer sine(double rate, double hz, std::size_t frames, float amp = 0.5F) {
    AudioBuffer b(1U, frames);
    for (std::size_t i = 0U; i < frames; ++i)
        b.channelData(0)[i] = amp * static_cast<float>(std::sin(2.0 * kPi * hz * static_cast<double>(i) / rate));
    return b;
}

// Goertzel power at `hz` over [start, end), normalised to a full-scale sine == 0 dB.
double toneDb(const float* x, std::size_t start, std::size_t end, double rate, double hz) {
    const double w = 2.0 * kPi * hz / rate;
    const double c = 2.0 * std::cos(w);
    double s0 = 0.0, s1 = 0.0, s2 = 0.0;
    const std::size_t n = end - start;
    for (std::size_t i = start; i < end; ++i) {
        // Hann window keeps the leakage of the strong tone away from the alias bin.
        const double win = 0.5 - 0.5 * std::cos(2.0 * kPi * static_cast<double>(i - start) / static_cast<double>(n));
        s0 = x[i] * win + c * s1 - s2;
        s2 = s1; s1 = s0;
    }
    const double power = s1 * s1 + s2 * s2 - c * s1 * s2;
    const double amp = 2.0 * std::sqrt(std::max(0.0, power)) / (0.5 * static_cast<double>(n));
    return 20.0 * std::log10(std::max(amp, 1.0e-12));
}

void testKernelDesign() {
    StudioResampler a; a.prepare(48000.0, 96000.0, 1U, 256U, 512U);
    require(a.design().taps >= StudioResampler::kMinTaps && a.design().taps <= StudioResampler::kMaxTaps, "48->96 taps");
    require(a.design().passbandHz >= 19000.0, "48->96 passband " + std::to_string(a.design().passbandHz));
    require(a.design().stopbandHz <= 24000.0 + 1.0, "48->96 stopband at source Nyquist");
    require(std::abs(a.ratio() - 0.5) < 1e-12, "48->96 ratio");

    StudioResampler b; b.prepare(96000.0, 48000.0, 1U, 512U, 256U);
    require(b.design().passbandHz >= 19000.0, "96->48 passband " + std::to_string(b.design().passbandHz));
    require(b.design().stopbandHz <= 28000.0 + 1.0, "96->48 stopband must sit where aliases would fold into 0-20 kHz");
    require(b.latencySourceFrames() == static_cast<std::uint32_t>(b.design().taps / 2), "latency == taps/2");
    require(b.latencyDestinationFrames() == static_cast<std::uint32_t>(std::ceil(b.design().taps / 2 / 2.0)), "destination latency");

    StudioResampler c; c.prepare(44100.0, 96000.0, 2U, 1024U, 4096U);
    require(c.design().passbandHz >= 19000.0 && c.design().passbandHz <= 20100.0, "44.1->96 passband");
    require(c.design().taps % 4 == 0, "taps multiple of 4 for the unrolled loop");
    pass("Kernel design: 48->96, 96->48, 44.1->96 keep 0-20 kHz flat and reject images by design");
}

void testConvertAccuracy() {
    // A 1 kHz sine converted 48 -> 96 must match the ideal sine (no phase offset).
    const std::size_t n = 48000U;
    const AudioBuffer src = sine(48000.0, 1000.0, n);
    const AudioBuffer out = StudioResampler::convert(src, 48000.0, 96000.0);
    require(out.frames() == 2U * n, "48->96 output length " + std::to_string(out.frames()));
    double err = 0.0; std::size_t cnt = 0U;
    for (std::size_t i = 2000U; i + 2000U < out.frames(); ++i) {
        const double ideal = 0.5 * std::sin(2.0 * kPi * 1000.0 * static_cast<double>(i) / 96000.0);
        err += (out.channelData(0)[i] - ideal) * (out.channelData(0)[i] - ideal); ++cnt;
    }
    err = std::sqrt(err / static_cast<double>(cnt));
    require(err < 1.0e-4, "48->96 sine rms error " + std::to_string(err));

    // Round trip 48 -> 96 -> 48 of a 15 kHz tone stays flat within 0.1 dB.
    const AudioBuffer hi = sine(48000.0, 15000.0, n);
    const AudioBuffer back = StudioResampler::convert(StudioResampler::convert(hi, 48000.0, 96000.0), 96000.0, 48000.0);
    require(back.frames() == n, "round-trip length");
    const double level = toneDb(back.channelData(0), 4000U, n - 4000U, 48000.0, 15000.0);
    require(std::abs(level - 20.0 * std::log10(0.5)) < 0.1, "15 kHz round-trip level " + std::to_string(level));

    // Same-rate conversion is a pass-through, empty input stays empty.
    require(StudioResampler::convert(hi, 48000.0, 48000.0).frames() == n, "same rate");
    require(StudioResampler::convert(AudioBuffer {}, 44100.0, 96000.0).frames() == 0U, "empty input");
    pass("Conversion accuracy: 1 kHz sine exact, 15 kHz round trip flat, no phase offset");
}

void testAliasRejection() {
    // A 30 kHz tone at 96 kHz would fold to 18 kHz at 48 kHz. It must vanish.
    const std::size_t n = 96000U;
    const AudioBuffer src = sine(96000.0, 30000.0, n, 1.0F);
    const AudioBuffer out = StudioResampler::convert(src, 96000.0, 48000.0);
    require(out.frames() == n / 2U, "96->48 length");
    const double alias = toneDb(out.channelData(0), 4000U, out.frames() - 4000U, 48000.0, 18000.0);
    require(alias < -100.0, "alias at 18 kHz is " + std::to_string(alias) + " dB");
    // Content inside the audible band passes unchanged.
    const AudioBuffer mid = sine(96000.0, 10000.0, n, 1.0F);
    const AudioBuffer midOut = StudioResampler::convert(mid, 96000.0, 48000.0);
    const double keep = toneDb(midOut.channelData(0), 4000U, midOut.frames() - 4000U, 48000.0, 10000.0);
    require(std::abs(keep) < 0.05, "10 kHz level after 96->48 is " + std::to_string(keep) + " dB");
    pass("Alias rejection: 30 kHz folded tone below -100 dB after 96->48, 10 kHz untouched");
}

void testStreamingMatchesConvert() {
    // Push in odd-sized blocks, pull in other odd sizes; result == whole-buffer convert.
    const std::size_t n = 44100U;
    AudioBuffer src(2U, n);
    for (std::size_t i = 0U; i < n; ++i) {
        src.channelData(0)[i] = 0.4F * static_cast<float>(std::sin(2.0 * kPi * 440.0 * static_cast<double>(i) / 44100.0));
        src.channelData(1)[i] = 0.3F * static_cast<float>(std::sin(2.0 * kPi * 3300.0 * static_cast<double>(i) / 44100.0));
    }
    const AudioBuffer ref = StudioResampler::convert(src, 44100.0, 96000.0);

    StudioResampler rs;
    rs.prepare(44100.0, 96000.0, 2U, 333U, 777U);
    std::vector<float> outL, outR;
    std::vector<float> tmpL(777U), tmpR(777U);
    float* dst[2] {tmpL.data(), tmpR.data()};
    std::size_t pos = 0U;
    std::uint32_t pushSize = 1U;
    while (pos < n) {
        const auto cnt = static_cast<std::uint32_t>(std::min<std::size_t>(pushSize, n - pos));
        const float* in[2] {src.channelData(0) + pos, src.channelData(1) + pos};
        rs.push(in, cnt);
        pos += cnt;
        pushSize = pushSize % 333U + 1U;
        std::uint32_t got;
        while ((got = rs.pull(dst, 777U)) > 0U) {
            outL.insert(outL.end(), tmpL.begin(), tmpL.begin() + got);
            outR.insert(outR.end(), tmpR.begin(), tmpR.begin() + got);
        }
    }
    require(outL.size() <= ref.frames(), "streaming never produces more than the whole-buffer length");
    require(outL.size() + 2U * rs.latencyDestinationFrames() + 4U >= ref.frames(), "streaming produced too little: " + std::to_string(outL.size()));
    float maxDiff = 0.0F;
    for (std::size_t i = 0U; i < outL.size(); ++i) {
        maxDiff = std::max(maxDiff, std::abs(outL[i] - ref.channelData(0)[i]));
        maxDiff = std::max(maxDiff, std::abs(outR[i] - ref.channelData(1)[i]));
    }
    require(maxDiff < 1.0e-6F, "streaming vs convert max diff " + std::to_string(maxDiff));
    pass("Streaming push/pull with odd block sizes equals whole-buffer conversion, both channels");
}

// Engine stand-in: copies input to output and counts frames.
class Passthrough final : public IAudioDeviceCallback {
public:
    std::uint64_t frames {0U};
    std::uint32_t lastBlock {0U};
    bool uniformBlocks {true};
    void processAudio(const float* const* inputs, float* const* outputs,
                      std::uint32_t inputChannels, std::uint32_t outputChannels,
                      std::uint32_t n) noexcept override {
        if (lastBlock != 0U && lastBlock != n) uniformBlocks = false;
        lastBlock = n;
        frames += n;
        for (std::uint32_t c = 0U; c < outputChannels; ++c) {
            const float* in = (inputs != nullptr && c < inputChannels) ? inputs[c] : nullptr;
            for (std::uint32_t i = 0U; i < n; ++i) outputs[c][i] = in != nullptr ? in[i] : 0.0F;
        }
    }
};

void runBridgeCase(double deviceRate, std::uint32_t blockSize, double engineRate) {
    const std::string tag = std::to_string(static_cast<int>(deviceRate)) + "/" + std::to_string(blockSize) + "->" + std::to_string(static_cast<int>(engineRate)) + ": ";
    AudioDeviceConfig dev; dev.sampleRate = deviceRate; dev.blockSize = blockSize; dev.inputChannels = 2U; dev.outputChannels = 2U;
    Passthrough inner;
    EngineRateBridge bridge;
    bridge.prepare(dev, engineRate, inner);
    require(bridge.active(), tag + "bridge active");
    require(std::abs(bridge.engineConfig().sampleRate - engineRate) < 1e-9, tag + "engine rate");
    const std::uint32_t eb = bridge.engineConfig().blockSize;
    require(eb % 32U == 0U && static_cast<double>(eb) >= static_cast<double>(blockSize) * engineRate / deviceRate, tag + "engine block " + std::to_string(eb));
    const std::uint32_t latency = bridge.addedLatencyDeviceFrames();
    require(latency > 0U && latency < 2000U, tag + "latency " + std::to_string(latency));

    // Two seconds of a 1 kHz sine through the bridge in device blocks.
    const std::size_t total = static_cast<std::size_t>(deviceRate * 2.0);
    std::vector<float> inL(total), outL, outR;
    for (std::size_t i = 0U; i < total; ++i)
        inL[i] = 0.5F * static_cast<float>(std::sin(2.0 * kPi * 1000.0 * static_cast<double>(i) / deviceRate));
    std::vector<float> zero(blockSize, 0.0F), bufL(blockSize), bufR(blockSize);
    for (std::size_t pos = 0U; pos + blockSize <= total; pos += blockSize) {
        const float* ins[2] {inL.data() + pos, zero.data()};
        float* outs[2] {bufL.data(), bufR.data()};
        bridge.processAudio(ins, outs, 2U, 2U, blockSize);
        outL.insert(outL.end(), bufL.begin(), bufL.end());
        outR.insert(outR.end(), bufR.begin(), bufR.end());
    }
    require(inner.uniformBlocks && inner.lastBlock == eb, tag + "engine always called with full fixed blocks");
    require(bridge.paddedEngineFrames() == 0U, tag + "engine input was zero-padded " + std::to_string(bridge.paddedEngineFrames()) + " frames");
    const double expectEngine = static_cast<double>(outL.size()) * engineRate / deviceRate;
    require(static_cast<double>(inner.frames) >= expectEngine && static_cast<double>(inner.frames) <= expectEngine + 4.0 * eb,
            tag + "engine frame count " + std::to_string(inner.frames));

    // Output == input delayed by `latency` frames: no gaps, no glitches.
    double err = 0.0; float worst = 0.0F; std::size_t cnt = 0U;
    for (std::size_t i = latency + 4000U; i < outL.size(); ++i) {
        const float d = outL[i] - inL[i - latency];
        err += static_cast<double>(d) * d; worst = std::max(worst, std::abs(d)); ++cnt;
    }
    err = std::sqrt(err / static_cast<double>(cnt));
    require(err < 2.0e-3, tag + "round-trip rms error " + std::to_string(err));
    require(worst < 1.0e-2F, tag + "worst-case sample error " + std::to_string(worst) + " (dropout?)");
    float silent = 0.0F;
    for (const float v : outR) silent = std::max(silent, std::abs(v));
    require(silent < 1.0e-6F, tag + "silent input channel stays silent");
}

void testBridge() {
    runBridgeCase(48000.0, 256U, 96000.0);
    runBridgeCase(48000.0, 64U, 96000.0);
    runBridgeCase(48000.0, 1024U, 96000.0);
    runBridgeCase(44100.0, 512U, 96000.0);
    runBridgeCase(44100.0, 100U, 96000.0);
    runBridgeCase(96000.0, 256U, 48000.0);
    runBridgeCase(88200.0, 256U, 96000.0);
    pass("Rate bridge: fixed engine blocks, never padded, continuous output with known latency (7 device setups)");
}

void testCoordinatorAt96k() {
    ProjectSession session;
    auto& project = session.project();
    project.tempoMap.setSampleRate(48000.0);
    ProjectTrack inst;
    inst.name = "Poly";
    ProjectPluginSlot synth;
    synth.modulePath = kNativeModulePath;
    synth.classId = "silveton.poly";
    synth.midiInputPort = 0;
    inst.pluginSlots.push_back(synth);
    project.tracks.push_back(inst);
    ProjectMidiTrack mt;
    mt.outputPort = 0;
    MusicalMidiNote n; n.startQuarterNotes = 0.0; n.durationQuarterNotes = 8.0; n.pitch = 60; n.velocity = 110;
    (void)mt.sequence.addNote(n);
    project.midiTracks.push_back(mt);

    CompositeInstanceFactory factory(nullptr);
    AudioEngine engine;
    DawRuntimeCoordinator runtime(session, engine, factory);
    runtime.setInternalSampleRate(96000.0);
    AudioDeviceConfig dev; dev.sampleRate = 48000.0; dev.blockSize = 256U; dev.inputChannels = 0U; dev.outputChannels = 2U;
    runtime.prepare(dev);
    require(runtime.rateBridgeActive(), "bridge must engage on a 48 kHz device");
    require(std::abs(project.sampleRate - 96000.0) < 1e-9, "project runs at 96 kHz, got " + std::to_string(project.sampleRate));
    require(std::abs(engine.deviceConfig().sampleRate - 96000.0) < 1e-9, "engine runs at 96 kHz");
    require(runtime.rack().trackSlotStatus(0, 0).available, "native synth available");

    float l[256] {}, r[256] {};
    float* outs[2] {l, r};
    runtime.audioCallback().processAudio(nullptr, outs, 0U, 2U, 256U);   // adopt the graph
    (void)runtime.service();
    engine.transport().seekSamples(0);
    engine.transport().play();
    float peak = 0.0F;
    for (int block = 0; block < 200; ++block) {
        runtime.audioCallback().processAudio(nullptr, outs, 0U, 2U, 256U);
        for (int i = 0; i < 256; ++i) peak = std::max(peak, std::abs(l[i]));
    }
    engine.transport().stop();
    require(peak > 0.02F, "no audio through the 96 kHz engine on a 48 kHz device (peak " + std::to_string(peak) + ")");

    // Same device rate as internal rate: no bridge, direct callback.
    ProjectSession s2;
    AudioEngine e2;
    DawRuntimeCoordinator r2(s2, e2, factory);
    r2.setInternalSampleRate(96000.0);
    AudioDeviceConfig dev96 = dev; dev96.sampleRate = 96000.0;
    r2.prepare(dev96);
    require(!r2.rateBridgeActive(), "no bridge when the card already runs at 96 kHz");
    require(std::abs(s2.project().sampleRate - 96000.0) < 1e-9, "project at 96 kHz");
    pass("Coordinator: 96 kHz internal on a 48 kHz card bridges and plays; 96 kHz card runs direct");
}

} // namespace

int main() {
    try {
        testKernelDesign();
        testConvertAccuracy();
        testAliasRejection();
        testStreamingMatchesConvert();
        testBridge();
        testCoordinatorAt96k();
        std::cout << passed << " studio resampler checks passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
