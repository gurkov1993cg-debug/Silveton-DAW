#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/WavFile.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <unistd.h>
#include <vector>

namespace {

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

bool near(float a, float b, float eps = 1.0e-6F) {
    return std::abs(a - b) <= eps;
}

std::string tempPath(const char* name) {
    return std::string("/tmp/") + name + "_" + std::to_string(static_cast<long long>(::getpid())) + ".wav";
}

class ContextRecorder final : public silveton::ITrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override { callCount = 0U; }
    std::uint32_t latencySamples() const noexcept override { return 0U; }

    void process(float*, float*, std::uint32_t frames, const silveton::ProcessorContext& context) noexcept override {
        if (callCount < starts.size()) {
            starts[callCount] = context.projectSample;
            sizes[callCount] = frames;
            playing[callCount] = context.playing;
        }
        ++callCount;
    }

    std::array<std::int64_t, 8U> starts {};
    std::array<std::uint32_t, 8U> sizes {};
    std::array<bool, 8U> playing {};
    std::size_t callCount {0U};
};

void testPlaybackWrapInsideOneBlock() {
    constexpr std::uint32_t block = 6U;
    silveton::AudioBuffer source(2U, 16U);
    for (std::size_t i = 0U; i < source.frames(); ++i) {
        const float v = static_cast<float>(i) * 0.1F;
        source.sample(0U, i) = v;
        source.sample(1U, i) = -v;
    }

    silveton::TimelineClip clip;
    clip.source = &source;
    clip.timelineStartSample = 0;
    clip.lengthSamples = 16U;
    silveton::TimelineTrack track;
    track.clips.push_back(clip);

    silveton::AudioEngine engine;
    silveton::AudioDeviceConfig config {48000.0, block, 0U, 2U};
    engine.prepare(config);
    engine.addTrack(track);
    engine.transport().setCycleRange(true, 4, 8);
    engine.transport().seekSamples(6);
    engine.transport().play();

    silveton::ManualAudioDevice device(config);
    device.start(engine);
    device.pump();
    const auto& out = device.lastOutput();
    constexpr std::array<std::size_t, block> expectedSource {6U, 7U, 4U, 5U, 6U, 7U};
    for (std::size_t i = 0U; i < expectedSource.size(); ++i) {
        const float v = static_cast<float>(expectedSource[i]) * 0.1F;
        require(near(out[0][i], v), "cycle playback left sample mismatch");
        require(near(out[1][i], -v), "cycle playback right sample mismatch");
    }
    require(engine.transport().positionSamples() == 4, "cycle transport final position mismatch");
    require(engine.transport().cyclePass() == 2U, "cycle pass counter mismatch");
    device.stop();
}

void testProcessorGraphSplitsAtCycleBoundary() {
    constexpr std::uint32_t block = 6U;
    ContextRecorder recorder;
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    nodes[0].processors.push_back({&recorder, {}});
    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U, 1U, 1.0F}}, 1U);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(&graph, 64U);
    engine.prepare({48000.0, block, 0U, 2U});
    engine.transport().setCycleRange(true, 4, 8);
    engine.transport().seekSamples(6);
    engine.transport().play();

    std::array<float, block> left {};
    std::array<float, block> right {};
    float* outputs[2] {left.data(), right.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, block);

    require(recorder.callCount == 2U, "processor graph was not split at cycle wrap");
    require(recorder.starts[0] == 6 && recorder.sizes[0] == 2U, "pre-wrap processor context mismatch");
    require(recorder.starts[1] == 4 && recorder.sizes[1] == 4U, "post-wrap processor context mismatch");
    require(recorder.playing[0] && recorder.playing[1], "cycle processor context lost playing state");
}

void testPunchRepeatsAcrossCyclePass() {
    constexpr std::uint32_t block = 32U;
    const std::string path = tempPath("silveton_cycle_punch");
    std::remove(path.c_str());

    silveton::AudioEngine engine;
    silveton::AudioDeviceConfig config {48000.0, block, 2U, 2U};
    engine.prepare(config);
    engine.transport().setCycleRange(true, 20, 40);
    engine.transport().seekSamples(30);
    engine.setPunchRange(true, 25, 35);

    silveton::Recorder recorder;
    recorder.prepare(2U, 48000U, 1024U);
    recorder.start(path);
    engine.setRecorder(&recorder);

    silveton::ManualAudioDevice device(config);
    for (std::uint32_t i = 0U; i < block; ++i) {
        const float v = static_cast<float>(i + 1U) * 0.001F;
        device.inputChannelData(0U)[i] = v;
        device.inputChannelData(1U)[i] = -v;
    }
    device.start(engine);
    engine.transport().play();
    device.pump();
    device.stop();
    engine.setRecorder(nullptr);
    recorder.stop();

    require(!engine.recordedTimelineSpanOverflowed(), "cycle recording timeline span log overflowed");
    const auto spans = engine.recordedTimelineSpans();
    require(spans.size() == 2U, "cycle punch span log did not create one logical span per pass");
    require(spans[0].recorderFrameStart == 0U && spans[0].projectStartSample == 30 &&
            spans[0].frames == 5U && spans[0].cyclePass == 0U,
            "first cycle punch timeline span mismatch");
    require(spans[1].recorderFrameStart == 5U && spans[1].projectStartSample == 25 &&
            spans[1].frames == 10U && spans[1].cyclePass == 1U,
            "wrapped cycle punch timeline span mismatch");

    const auto take = silveton::WavFile::read(path);
    require(take.audio.frames() == 15U, "cycle punch recorded wrong frame count");
    // First pass: project 30..34 -> device input offsets 0..4.
    for (std::size_t i = 0U; i < 5U; ++i) {
        const float expected = static_cast<float>(i + 1U) * 0.001F;
        require(near(take.audio.sample(0U, i), expected), "first cycle punch segment mismatch");
        require(near(take.audio.sample(1U, i), -expected), "first cycle punch right segment mismatch");
    }
    // Wrapped pass: project 25..34 -> input offsets 15..24.
    for (std::size_t i = 0U; i < 10U; ++i) {
        const float expected = static_cast<float>(i + 16U) * 0.001F;
        require(near(take.audio.sample(0U, 5U + i), expected), "wrapped cycle punch segment mismatch");
        require(near(take.audio.sample(1U, 5U + i), -expected), "wrapped cycle punch right segment mismatch");
    }
    require(engine.transport().cyclePass() == 2U, "cycle pass count after 32-frame block mismatch");
    require(engine.transport().positionSamples() == 22, "cycle position after recording block mismatch");

    std::remove(path.c_str());
}

} // namespace

int main() {
    try {
        testPlaybackWrapInsideOneBlock();
        testProcessorGraphSplitsAtCycleBoundary();
        testPunchRepeatsAcrossCyclePass();
        std::cout << "PASS: cycle playback wraps sample-accurately inside a device block\n";
        std::cout << "PASS: ProcessorGraph receives exact pre/post-wrap project positions\n";
        std::cout << "PASS: punch recording repeats at exact cycle positions without buffer-boundary over-record\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
