#include "silveton/ProjectPlaybackRuntime.h"
#include "silveton/ProjectMediaRelinker.h"
#include "silveton/WavFile.h"
#include <cmath>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace {
void require(bool c,const char* m){if(!c)throw std::runtime_error(m);}
void makeTone(const std::string& path,std::uint32_t rate,float value){
    silveton::AudioBuffer b(2U,512U);
    for(std::size_t i=0;i<b.frames();++i){b.sample(0U,i)=value;b.sample(1U,i)=-value;}
    silveton::WavFile::writeFloat32(path,rate,b);
}
}

void testRelinkAndConform(){
    using namespace silveton;
    const std::string replacement="/tmp/SilvetonRelinkMono.wav";
    const std::string mismatch="/tmp/SilvetonRelink441.wav";
    const std::string conformed="/tmp/SilvetonRelinkConformed.wav";
    const std::string imported="/tmp/SilvetonImportedConformed.wav";
    (void)std::remove(replacement.c_str());(void)std::remove(mismatch.c_str());(void)std::remove(conformed.c_str());(void)std::remove(imported.c_str());
    AudioBuffer mono(1U,256U);for(std::size_t i=0;i<mono.frames();++i)mono.sample(0U,i)=static_cast<float>(i)/256.0F;
    WavFile::writeFloat32(replacement,48000U,mono);
    AudioBuffer stereo(2U,441U);for(std::size_t i=0;i<stereo.frames();++i){stereo.sample(0U,i)=0.2F;stereo.sample(1U,i)=-0.2F;}
    WavFile::writeFloat32(mismatch,44100U,stereo);
    Project p;p.sampleRate=48000.0;p.tempoMap.setSampleRate(48000.0);
    ProjectTrack t;ProjectAudioClip c;c.id=1U;c.audioPath="/tmp/offline-original.wav";c.sourceFrames=128U;c.lengthSamples=128U;t.clips.push_back(c);p.tracks.push_back(t);
    const auto relink=ProjectMediaRelinker::relinkPath(p,"/tmp/offline-original.wav",replacement,true);
    require(relink.updatedReferences==1U&&relink.sourceChannels==1U&&relink.sourceSampleRate==48000U,"media relink metadata mismatch");
    require(p.tracks[0].clips[0].audioPath==replacement&&p.tracks[0].clips[0].sourceChannels==1U&&p.tracks[0].clips[0].sourceSampleRate==48000U,"project clip metadata was not updated by relink");
    // A replacement at another rate is accepted: it keeps its own rate on disk and its frames are
    // counted at the project rate (441 frames at 44.1 kHz = 480 frames at 48 kHz).
    const auto mixedRate=ProjectMediaRelinker::relinkPath(p,replacement,mismatch,true);
    require(mixedRate.updatedReferences==1U&&mixedRate.sourceSampleRate==44100U&&mixedRate.sourceFrames==480U,"replacement at another rate was not counted at the project rate");
    require(p.tracks[0].clips[0].audioPath==mismatch&&p.tracks[0].clips[0].sourceSampleRate==44100U&&p.tracks[0].clips[0].sourceFrames==480U,"project clip did not keep the file's own rate and the project-rate frame count");
    bool tooShort=false;{Project q=p;q.tracks[0].clips[0].lengthSamples=900U;try{(void)ProjectMediaRelinker::relinkPath(q,mismatch,replacement,true);}catch(const std::runtime_error&){tooShort=true;}
        require(tooShort&&q.tracks[0].clips[0].audioPath==mismatch,"a replacement shorter than the clip range must be rejected without touching the project");}
    (void)ProjectMediaRelinker::relinkPath(p,mismatch,replacement,true);
    require(p.tracks[0].clips[0].audioPath==replacement&&p.tracks[0].clips[0].sourceSampleRate==48000U,"relink back failed");
    const auto importedMeta=ProjectMediaRelinker::conformSourceToProjectRate(p,mismatch,imported);
    const auto importedWav=WavFile::read(imported);
    require(importedMeta.updatedReferences==0U&&importedMeta.sourceSampleRate==48000U&&importedMeta.sourceChannels==2U,"standalone import conform metadata mismatch");
    require(importedWav.sampleRate==48000U&&importedWav.audio.channels()==2U&&importedWav.audio.frames()==480U,"standalone import conform did not convert to project rate");
    const auto con=ProjectMediaRelinker::conformAndRelinkPath(p,replacement,mismatch,conformed);
    require(con.updatedReferences==1U&&con.sourceSampleRate==48000U&&con.sourceChannels==2U,"media conform/relink metadata mismatch");
    const auto wav=WavFile::read(conformed);require(wav.sampleRate==48000U&&wav.audio.channels()==2U,"conformed media file format mismatch");
    require(p.tracks[0].clips[0].audioPath==conformed,"conformed media was not relinked into project");
    (void)std::remove(replacement.c_str());(void)std::remove(mismatch.c_str());(void)std::remove(conformed.c_str());(void)std::remove(imported.c_str());
}

int main(){
    using namespace silveton;
    const std::string ok="/tmp/SilvetonPlaybackRuntime.wav";
    const std::string wrong="/tmp/SilvetonPlaybackRuntimeWrong.wav";
    (void)std::remove(ok.c_str());(void)std::remove(wrong.c_str());
    makeTone(ok,48000U,0.25F); makeTone(wrong,44100U,0.5F);
    try{
        testRelinkAndConform();
        Project p; p.sampleRate=48000.0; p.tempoMap.setSampleRate(48000.0); p.tempoMap.setInitialTempo(120.0);
        ProjectTrack a; a.name="Online"; a.audioPath=ok; p.tracks.push_back(a);
        ProjectTrack b; b.name="Missing"; ProjectAudioClip bc; bc.id=2U;bc.audioPath="/tmp/does-not-exist.wav";bc.lengthSamples=128U;bc.sourceFrames=128U;b.clips.push_back(bc);p.tracks.push_back(b);
        ProjectTrack c; c.name="Other rate (converted on the fly, muted here: its sound is checked in the virtual-rate tests)"; c.mute=true; ProjectAudioClip cc; cc.id=3U;cc.audioPath=wrong;cc.lengthSamples=128U;cc.sourceFrames=512U;c.clips.push_back(cc);p.tracks.push_back(c);
        ProjectTrack d; d.name="Wrong channels"; ProjectAudioClip dc; dc.id=4U;dc.audioPath=ok;dc.lengthSamples=128U;dc.sourceFrames=512U;dc.sourceChannels=1U;d.clips.push_back(dc);p.tracks.push_back(d);
        AudioEngine engine; engine.prepare({48000.0,64U,0U,2U});
        ProjectPlaybackRuntime runtime(p,engine);
        const auto status=runtime.rebuild(256U,2000U);
        require(status.tracksPublished==4U,"runtime did not preserve project track count");
        require(status.uniqueAudioSources==2U,"runtime source de-dup/load count mismatch");
        // The 44.1 kHz file is NOT offline any more: it keeps its rate on disk and plays converted.
        require(status.offlineClips==2U,"missing/wrong-channel media were not represented offline");
        require(status.issues.size()>=2U,"media issues were not reported");
        bool sawMissing=false,sawRate=false,sawChannels=false;for(const auto&i:status.issues){sawMissing|=i.kind==ProjectMediaIssueKind::MissingOrUnreadable;sawRate|=i.kind==ProjectMediaIssueKind::SampleRateMismatch;sawChannels|=i.kind==ProjectMediaIssueKind::ChannelLayoutMismatch;}
        require(sawMissing&&sawChannels&&!sawRate,"runtime must report missing/channel problems and no rate problem");
        require(runtime.streams().sourceCount()==2U&&runtime.streams().source(1U).rateConverted()&&runtime.streams().source(1U).sampleRate()==48000U&&runtime.streams().source(1U).nativeSampleRate()==44100U,"44.1 kHz media was not converted to the project rate while streaming");
        require(engine.trackCount()==4U,"engine track count changed after offline-media restore");
        engine.transport().play();
        float l[64]{},r[64]{};float* outs[2]{l,r};engine.processAudio(nullptr,outs,0U,2U,64U);
        require(std::abs(l[0]-0.25F)<1.0e-4F&&std::abs(r[0]+0.25F)<1.0e-4F,"online media did not render while offline media stayed silent");
        engine.transport().stop();

        // Live voice plans now own their disk-source lifetime. Rebuilding media
        // may drop the control-layer source immediately, but the old source must
        // stay alive until the audio callback adopts the replacement plan and the
        // control thread reclaims the retired voice snapshot.
        std::weak_ptr<DiskAudioSource> retiredSource = runtime.streams().sourceHandle(0U);
        (void)runtime.rebuild(256U,2000U);
        require(!retiredSource.expired(),
                "project rebuild destroyed a disk source still referenced by the live voice plan");
        engine.processAudio(nullptr,outs,0U,2U,64U);
        require(!retiredSource.expired(),
                "audio thread destroyed retired voice-plan media instead of deferring reclamation");
        require(engine.reclaimRetiredVoicePlans() >= 1U,
                "retired voice plan was not reclaimable on the control thread");
        require(retiredSource.expired(),
                "retired disk source remained alive after safe voice-plan reclamation");

        runtime.stop();
        (void)std::remove(ok.c_str());(void)std::remove(wrong.c_str());
        std::cout<<"PASS: project media restore streams valid files and keeps missing/mismatched clips safely offline\n";
        std::cout<<"PASS: live voice plans own disk media until control-thread reclamation\n";return 0;
    }catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<'\n';(void)std::remove(ok.c_str());(void)std::remove(wrong.c_str());return 1;}
}
