// Key Editor tests: group moves, copy and paste, cut and glue, scale fitting, controller lanes, listening queue.
#include "silveton/KeyEditing.h"
#include "silveton/MidiInput.h"

#include <array>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silveton;

namespace {
void require(bool c, const std::string& m) { if (!c) throw std::runtime_error(m); }
int passed = 0;
void pass(const char* n) { ++passed; std::cout << "PASS: " << n << '\n'; }
bool near(double a, double b, double tol = 1.0e-9) { return std::abs(a - b) <= tol; }

std::uint64_t add(MidiSequence& s, double start, double len, int pitch, int velocity = 100) {
    MusicalMidiNote n;
    n.startQuarterNotes = start; n.durationQuarterNotes = len;
    n.pitch = static_cast<std::uint8_t>(pitch); n.velocity = static_cast<std::uint8_t>(velocity);
    return s.addNote(n);
}

void testNamesAndChords() {
    require(KeyEditing::noteName(60) == "C3" && KeyEditing::noteName(0) == "C-2" && KeyEditing::noteName(127) == "G8", "note names");
    require(KeyEditing::noteName(61) == "C#3" && KeyEditing::noteName(69) == "A3", "sharp and A names");
    require(KeyEditing::chordIntervals(ChordKind::Major) == std::vector<int>({0, 4, 7}), "major chord");
    require(KeyEditing::chordIntervals(ChordKind::Dominant7) == std::vector<int>({0, 4, 7, 10}), "dominant seventh");
    require(KeyEditing::chordIntervals(ChordKind::Single) == std::vector<int>({0}), "single note");
    MidiSequence s;
    MusicalMidiNote root; root.startQuarterNotes = 1.0; root.durationQuarterNotes = 0.5; root.pitch = 60; root.velocity = 90;
    const auto ids = KeyEditing::addChord(s, root, ChordKind::Minor7);
    require(ids.size() == 4U && s.notes().size() == 4U, "chord note count");
    require(KeyEditing::find(s, ids[0])->pitch == 60 && KeyEditing::find(s, ids[3])->pitch == 70, "chord pitches");
    require(KeyEditing::find(s, ids[2])->velocity == 90 && near(KeyEditing::find(s, ids[2])->startQuarterNotes, 1.0), "chord notes share the root's timing and velocity");
    MidiSequence top;
    MusicalMidiNote high; high.pitch = 123;
    require(KeyEditing::addChord(top, high, ChordKind::Major7).size() == 2U, "chord notes above 127 are left out");
    pass("note names and chords");
}

void testGroupMoveKeepsChordShape() {
    MidiSequence s;
    const auto a = add(s, 0.5, 1.0, 60), b = add(s, 0.5, 1.0, 64), c = add(s, 2.0, 0.5, 67);
    const auto orig = KeyEditing::snapshot(s, {a, b, c});
    require(orig.size() == 3U, "snapshot size");
    double dq = 0.0; int dp = 0;
    KeyEditing::moveFrom(s, orig, -3.0, 70, &dq, &dp);   // would leave the grid on both sides
    require(near(dq, -0.5) && dp == 127 - 67, "the group is held back together");
    require(near(KeyEditing::find(s, a)->startQuarterNotes, 0.0) && near(KeyEditing::find(s, c)->startQuarterNotes, 1.5), "start moved as a group");
    require(KeyEditing::find(s, a)->pitch == 60 + 60 && KeyEditing::find(s, b)->pitch - KeyEditing::find(s, a)->pitch == 4, "pitches moved as a group");
    // moving again from the same original gives the same result as one move (a drag is not cumulative)
    KeyEditing::moveFrom(s, orig, 1.0, 2, &dq, &dp);
    require(near(KeyEditing::find(s, b)->startQuarterNotes, 1.5) && KeyEditing::find(s, b)->pitch == 66, "drag from the original");
    // the notes stay sorted by start
    double last = -1.0;
    for (const auto& n : s.notes()) { require(n.startQuarterNotes >= last, "notes sorted after a move"); last = n.startQuarterNotes; }
    bool threw = false;
    try { (void)s.placeNotes({{a, -1.0, 60}}); } catch (const std::invalid_argument&) { threw = true; }
    require(threw, "placeNotes refuses a negative start");
    pass("group move keeps the shape and is not cumulative");
}

void testResizeAndVelocityGroups() {
    MidiSequence s;
    const auto a = add(s, 0, 1.0, 60, 100), b = add(s, 1, 0.25, 62, 20);
    const auto orig = KeyEditing::snapshot(s, {a, b});
    KeyEditing::resizeFrom(s, orig, -0.5);
    require(near(KeyEditing::find(s, a)->durationQuarterNotes, 0.5) && near(KeyEditing::find(s, b)->durationQuarterNotes, KeyEditing::kShortestNote), "resize with a floor");
    KeyEditing::resizeFrom(s, orig, 0.75);
    require(near(KeyEditing::find(s, b)->durationQuarterNotes, 1.0), "resize from the original");
    KeyEditing::shiftVelocityFrom(s, orig, 60);
    require(KeyEditing::find(s, a)->velocity == 127 && KeyEditing::find(s, b)->velocity == 80, "velocity shift clamps");
    KeyEditing::shiftVelocityFrom(s, orig, -90);
    require(KeyEditing::find(s, a)->velocity == 10 && KeyEditing::find(s, b)->velocity == 1, "velocity never reaches 0");
    pass("group resize and velocity");
}

void testCopyPasteDuplicate() {
    MidiSequence s;
    const auto a = add(s, 4.0, 1.0, 60, 90), b = add(s, 5.0, 0.5, 64, 80);
    (void)s.setNoteMuted(b, true);
    const NoteClip clip = KeyEditing::copyNotes(s, {b, a});
    require(clip.notes.size() == 2U && near(clip.span, 1.5), "clip span");
    require(near(clip.notes[0].offset, 0.0) && near(clip.notes[1].offset, 1.0), "clip offsets count from the first note");
    const auto pasted = KeyEditing::pasteNotes(s, clip, 10.0);
    require(pasted.size() == 2U && s.notes().size() == 4U, "paste adds notes");
    require(near(KeyEditing::find(s, pasted[1])->startQuarterNotes, 11.0) && KeyEditing::find(s, pasted[1])->muted, "paste keeps timing and mute");
    double shift = 0.0;
    const auto dup = KeyEditing::duplicateNotes(s, {a, b}, &shift);
    require(near(shift, 1.5) && dup.size() == 2U, "duplicate distance");
    require(near(KeyEditing::find(s, dup[0])->startQuarterNotes, 5.5), "duplicate lands right behind the selection");
    require(KeyEditing::copyNotes(s, {}).empty() && KeyEditing::duplicateNotes(s, {}).empty(), "nothing selected, nothing copied");
    require(KeyEditing::pasteNotes(s, clip, -3.0).size() == 2U && s.notes().back().startQuarterNotes >= 0.0, "paste before 0 lands on 0");
    require(KeyEditing::removeNotes(s, {a, b, 9999U}) == 2U, "remove counts real notes");
    pass("copy, paste and duplicate");
}

void testSplitAndGlue() {
    MidiSequence s;
    const auto a = add(s, 1.0, 2.0, 60, 77);
    const auto pair = KeyEditing::splitNote(s, a, 2.0);
    require(pair.size() == 2U && near(KeyEditing::find(s, a)->durationQuarterNotes, 1.0), "left half");
    const auto* right = KeyEditing::find(s, pair[1]);
    require(right && near(right->startQuarterNotes, 2.0) && near(right->durationQuarterNotes, 1.0) && right->velocity == 77, "right half");
    require(KeyEditing::splitNote(s, a, 1.0).empty() && KeyEditing::splitNote(s, a, 5.0).empty(), "no cut outside the note");
    require(KeyEditing::splitNote(s, a, 1.0 + 1.0 / 128.0).empty(), "no sliver shorter than the shortest note");
    const auto g = KeyEditing::glueNotes(s, {a, pair[1]});
    require(g.size() == 1U && s.notes().size() == 1U && near(s.notes()[0].durationQuarterNotes, 2.0), "touching halves join again");
    // different pitch or a gap stays apart
    MidiSequence t;
    const auto n1 = add(t, 0, 1, 60), n2 = add(t, 1, 1, 62), n3 = add(t, 3, 1, 60), n4 = add(t, 0.5, 1, 60);
    const auto kept = KeyEditing::glueNotes(t, {n1, n2, n3, n4});
    require(t.notes().size() == 3U && kept.size() == 3U, "overlapping notes join; other pitch and gap stay");
    require(near(KeyEditing::find(t, n1)->durationQuarterNotes, 1.5), "joined note covers both");
    // the Glue tool reaches across a gap
    require(KeyEditing::glueToNext(t, n1) == n1 && t.notes().size() == 2U, "glue to next same-pitch note");
    require(near(KeyEditing::find(t, n1)->durationQuarterNotes, 4.0), "glue spans the gap");
    require(KeyEditing::glueToNext(t, n1) == 0U, "no next note, no glue");
    const auto rights = KeyEditing::splitNotes(t, {n1, n2}, 1.5);
    require(rights.size() == 2U, "split all notes under a cursor");
    pass("split and glue");
}

void testMuteAndSelection() {
    MidiSequence s;
    const auto a = add(s, 0, 1, 60), b = add(s, 1, 1, 62), c = add(s, 2, 1, 60), d = add(s, 4, 1, 64);
    require(KeyEditing::muteNotes(s, {a, b}, 1) == 2U && KeyEditing::muteNotes(s, {a, b}, 1) == 0U, "mute only changes what is needed");
    require(KeyEditing::muteNotes(s, {a, c}, 2) == 2U && !KeyEditing::find(s, a)->muted && KeyEditing::find(s, c)->muted, "flip");
    require(KeyEditing::muteNotes(s, {b, c}, 0) == 2U, "unmute");
    require(KeyEditing::selectSamePitch(s, {a}).size() == 2U, "same pitch");
    require(KeyEditing::invertSelection(s, {a, b}).size() == 2U && KeyEditing::allIds(s).size() == 4U, "invert and all");
    require(KeyEditing::selectFrom(s, 2.0).size() == 2U, "from cursor");
    const auto inside = KeyEditing::selectInside(s, 0.5, 1.5, 61, 63);
    require(inside.size() == 1U && inside[0] == b, "rubber band");
    require(KeyEditing::selectInside(s, 1.5, 0.5, 63, 61).size() == 1U, "rubber band drawn backwards");
    (void)d;
    pass("mute and selection");
}

void testScaleFitting() {
    ToneScale cmaj; cmaj.kind = ToneScaleKind::Major; cmaj.root = 0;
    require(KeyEditing::pitchInScale(61, cmaj) == 60, "C# falls to C (tie goes down)");
    require(KeyEditing::pitchInScale(63, cmaj) == 62 && KeyEditing::pitchInScale(66, cmaj) == 65, "other ties");
    require(KeyEditing::pitchInScale(64, cmaj) == 64, "a scale note stays");
    const ToneScale csharp {ToneScaleKind::Major, 1};
    require(csharp.contains(KeyEditing::pitchInScale(127, csharp)) && KeyEditing::pitchInScale(127, csharp) <= 127, "top of the range stays in the scale");
    ToneScale chromatic;
    require(KeyEditing::pitchInScale(61, chromatic) == 61, "chromatic changes nothing");
    MidiSequence s;
    const auto a = add(s, 0, 1, 61), b = add(s, 1, 1, 64), c = add(s, 2, 1, 70);
    require(KeyEditing::fitToScale(s, {}, cmaj) == 2U, "fit all");
    require(KeyEditing::find(s, a)->pitch == 60 && KeyEditing::find(s, b)->pitch == 64 && KeyEditing::find(s, c)->pitch == 69, "fitted pitches");
    require(KeyEditing::fitToScale(s, {a}, cmaj) == 0U && KeyEditing::fitToScale(s, {}, chromatic) == 0U, "nothing left to fit");
    pass("scale fitting");
}

void testLaneBasics() {
    const KeyLane bend = KeyLane::pitchBend();
    for (int v : {0, 1, 127, 128, 8192, 12345, 16383}) {
        const auto m = bend.make(1.0, v, 3U);
        require(bend.matches(m) && bend.valueOf(m) == v && (m.status & 0x0F) == 3, "pitch bend round trip");
    }
    const KeyLane mod = KeyLane::controller(1);
    const auto m1 = mod.make(2.0, 200, 0U);
    require(m1.status == 0xB0U && m1.data1 == 1U && m1.data2 == 127U, "controller value is clamped");
    require(mod.matches(m1) && !KeyLane::controller(2).matches(m1) && !bend.matches(m1), "lane matching");
    const KeyLane at = KeyLane::aftertouch();
    const auto m2 = at.make(0.0, 50, 0U);
    require(m2.status == 0xD0U && at.valueOf(m2) == 50 && at.matches(m2), "aftertouch");
    require(mod.name() == "Modulation (CC 1)" && KeyLane::controller(23).name() == "Controller 23" && bend.name() == "Pitch Bend", "lane names");
    require(KeyLane::velocity() != bend && KeyLane::controller(1) != KeyLane::controller(2) && KeyLane::controller(1) == mod, "lane equality");
    require(bend.centreValue() == 8192 && bend.maxValue() == 16383 && mod.maxValue() == 127, "lane ranges");
    MidiSequence s;
    (void)s.addMessage(m1);
    require(s.messages().size() == 1U, "a pitch bend or controller message is accepted by the sequence");
    pass("lane basics");
}

void testShapes() {
    const auto line = KeyEditing::shapePoints(LaneShape::Line, 1.0, 0, 2.0, 100, 0.25, 1.0, 127);
    require(line.size() == 5U && near(line.front().quarterNotes, 1.0) && near(line.back().quarterNotes, 2.0), "line ends");
    require(line.front().value == 0 && line.back().value == 100 && line[2].value == 50, "line values");
    for (std::size_t i = 1U; i < line.size(); ++i) require(line[i].value >= line[i - 1U].value && line[i].quarterNotes > line[i - 1U].quarterNotes, "line is steady");
    const auto back = KeyEditing::shapePoints(LaneShape::Line, 2.0, 100, 1.0, 0, 0.25, 1.0, 127);
    require(back.size() == line.size() && back[2].value == 50, "drawing backwards gives the same line");
    const auto curve = KeyEditing::shapePoints(LaneShape::Parabola, 0.0, 0, 1.0, 100, 0.25, 1.0, 127);
    require(curve[1].value == 6 && curve[2].value == 25 && curve.back().value == 100, "curve starts slow");
    const auto sine = KeyEditing::shapePoints(LaneShape::Sine, 0.0, 20, 2.0, 100, 0.125, 1.0, 127);
    int low = 1000, high = -1;
    for (const auto& p : sine) { low = std::min(low, p.value); high = std::max(high, p.value); }
    require(low == 20 && high == 100, "sine swings between the two values");
    bool atHalf = false;
    for (const auto& p : sine) if (near(p.quarterNotes, 0.5) && p.value == 100) atHalf = true;
    require(atHalf, "sine peaks at half a period");
    const auto tri = KeyEditing::shapePoints(LaneShape::Triangle, 0.0, 0, 1.0, 100, 0.25, 1.0, 127);
    require(tri[2].value == 100 && tri.back().value == 0, "triangle");
    const auto sq = KeyEditing::shapePoints(LaneShape::Square, 0.0, 10, 2.0, 90, 0.3, 1.0, 127);
    for (const auto& p : sq) require(p.value == 10 || p.value == 90, "square has only two values");
    bool edgeExact = false;
    for (const auto& p : sq) if (near(p.quarterNotes, 0.5) && p.value == 90) edgeExact = true;
    require(edgeExact, "square changes exactly at half periods");
    require(KeyEditing::shapePoints(LaneShape::Line, 1.0, 5, 1.0, 9, 0.1, 1.0, 127).size() == 1U, "no length, one point");
    require(KeyEditing::shapePoints(LaneShape::Line, 0.0, 0, 1000.0, 127, 0.0001, 1.0, 127).size() <= 4100U, "point count is limited");
    const auto bendLine = KeyEditing::shapePoints(LaneShape::Line, 0.0, 0, 1.0, 16383, 0.5, 1.0, 16383);
    require(bendLine.back().value == 16383, "pitch bend range");
    pass("line shapes");
}

void testWriteAndReduce() {
    MidiSequence s;
    const KeyLane mod = KeyLane::controller(1);
    (void)s.addMessage(mod.make(0.5, 10));
    (void)s.addMessage(mod.make(3.5, 20));
    (void)s.addMessage(KeyLane::controller(7).make(1.0, 99));
    const auto ids = KeyEditing::writePoints(s, mod, KeyEditing::shapePoints(LaneShape::Line, 1.0, 0, 3.0, 100, 0.5, 1.0, 127));
    require(ids.size() == 5U, "points written");
    require(KeyEditing::laneMessages(s, mod).size() == 7U, "messages outside the drawn range stay");
    require(KeyEditing::laneMessages(s, KeyLane::controller(7)).size() == 1U, "other controllers are untouched");
    const auto again = KeyEditing::writePoints(s, mod, {{1.0, 5}, {2.0, 6}});
    require(again.size() == 2U && KeyEditing::laneMessages(s, mod).size() == 6U, "drawing again replaces the range");
    require(KeyEditing::writePoints(s, KeyLane::velocity(), {{1.0, 5}}).empty() && KeyEditing::writePoints(s, mod, {}).empty(), "velocity has no messages; no points, no change");
    require(KeyEditing::setValue(s, mod, again[0], 77) && mod.valueOf(*KeyEditing::findMessage(s, again[0])) == 77, "set value");
    require(!KeyEditing::setValue(s, KeyLane::pitchBend(), again[0], 1) && !KeyEditing::setValue(s, mod, 99999U, 1), "wrong lane or id");
    require(KeyEditing::eraseRange(s, mod, 0.0, 2.5) == 4U, "erase range");
    // reducing
    MidiSequence r;
    for (int i = 0; i <= 10; ++i) (void)r.addMessage(mod.make(i * 0.25, i * 10));
    (void)r.addMessage(mod.make(2.75, 5));
    const std::size_t removed = KeyEditing::reduceLane(r, mod, 1);
    require(removed == 9U, "points on the straight line are removed");
    const auto left = KeyEditing::laneMessages(r, mod);
    require(left.size() == 3U && mod.valueOf(left.front()) == 0 && mod.valueOf(left.back()) == 5, "ends and the corner stay");
    require(KeyEditing::removeMessages(r, {left[0].id, 424242U}) == 1U, "remove messages");
    pass("lane writing, erasing and reducing");
}

void testAuditionQueue() {
    MidiInputCapture input;
    input.beginRecording();
    require(input.pushAudition({5, 12345, 0x90U, 60U, 100U}), "audition push");
    require(input.pushAudition({5, 99999, 0x80U, 60U, 0U}), "audition note off");
    require(!input.pushAudition({-1, 0, 0x90U, 60U, 100U}) && !input.pushAudition({5, 0, 0x90U, 200U, 100U}), "audition refuses wrong events");
    std::array<TimedMidiInputEvent, 8U> events {};
    const auto n = input.eventsForBlock(48000, 256U, events.data(), events.size());
    require(n == 2U && events[0].sample == 48000 && events[0].status == 0x90U && events[1].status == 0x80U, "audition is played at the start of the next block");
    require(input.eventsForBlock(48256, 256U, events.data(), events.size()) == 0U, "audition is played once");
    MidiSequence seq;
    TempoMap map; map.setSampleRate(48000.0); map.setInitialTempo(120.0);
    require(input.stopAndCommit(seq, map, 96000) == 0U && seq.notes().empty(), "audition is never recorded");
    // live input and audition together
    require(input.pushRealtime({5, 48100, 0x90U, 64U, 90U}) && input.pushAudition({5, 0, 0x90U, 67U, 90U}), "both queues");
    require(input.eventsForBlock(48000, 256U, events.data(), events.size()) == 2U, "both queues are read");
    pass("audition queue");
}
} // namespace

int main() {
    try {
        testNamesAndChords();
        testGroupMoveKeepsChordShape();
        testResizeAndVelocityGroups();
        testCopyPasteDuplicate();
        testSplitAndGlue();
        testMuteAndSelection();
        testScaleFitting();
        testLaneBasics();
        testShapes();
        testWriteAndReduce();
        testAuditionQueue();
        std::cout << "All " << passed << " Key Editor checks passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
