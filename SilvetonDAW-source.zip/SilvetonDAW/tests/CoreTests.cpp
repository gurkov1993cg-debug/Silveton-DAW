#include "silveton/AudioBuffer.h"
#include "silveton/Meter.h"
#include "silveton/Mixer.h"
#include "silveton/WavFile.h"
#include <cmath>
#include <filesystem>
#include <fstream>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

bool near(float a, float b, float eps = 1.0e-4F) { return std::abs(a - b) <= eps; }
}

int main() {
    try {
        constexpr std::size_t frames = 48000;
        constexpr float sampleRate = 48000.0F;
        silveton::AudioBuffer tone(1, frames);
        for (std::size_t i = 0; i < frames; ++i)
            tone.sample(0, i) = 0.5F * std::sin(2.0F * 3.14159265358979323846F * 1000.0F * static_cast<float>(i) / sampleRate);

        const auto toneMeter = silveton::Meter::measure(tone);
        require(near(toneMeter[0].peakLinear, 0.5F, 1.0e-3F), "peak meter incorrect");
        require(near(toneMeter[0].rmsLinear, 0.353553F, 1.0e-3F), "RMS meter incorrect");

        silveton::AudioBuffer out(2, frames);
        silveton::TrackState center {&tone, 0.0F, 0.0F, false};
        silveton::Mixer::mixStereo({center}, out);
        const float expectedCenterPeak = 0.5F * 0.70710678F;
        const auto outMeter = silveton::Meter::measure(out);
        require(near(outMeter[0].peakLinear, expectedCenterPeak, 2.0e-3F), "center pan left incorrect");
        require(near(outMeter[1].peakLinear, expectedCenterPeak, 2.0e-3F), "center pan right incorrect");

        silveton::TrackState left {&tone, -6.0F, -1.0F, false};
        silveton::Mixer::mixStereo({left}, out);
        const auto leftMeter = silveton::Meter::measure(out);
        require(leftMeter[0].peakLinear > 0.24F && leftMeter[0].peakLinear < 0.26F, "-6dB gain incorrect");
        require(leftMeter[1].peakLinear < 1.0e-5F, "hard-left pan leaks right");

        const auto wavPath = std::filesystem::temp_directory_path() / "silveton_core_test.wav";
        silveton::WavFile::writeFloat32(wavPath, 48000U, out);
        const auto reloaded = silveton::WavFile::read(wavPath);
        require(reloaded.sampleRate == 48000U, "WAV sample rate mismatch");
        require(reloaded.audio.channels() == 2U && reloaded.audio.frames() == frames, "WAV shape mismatch");
        require(near(reloaded.audio.sample(0, 1234), out.sample(0, 1234), 1.0e-7F), "WAV roundtrip mismatch");
        std::filesystem::remove(wavPath);

        // RF64 reader contract: long streaming takes use ds64 sizes. This tiny
        // synthetic RF64 file exercises the same parser without allocating >4 GiB.
        const auto rf64Path = std::filesystem::temp_directory_path() / "silveton_rf64_read_test.wav";
        {
            std::ofstream rf(rf64Path, std::ios::binary | std::ios::trunc);
            auto w16 = [&rf](std::uint16_t v){ rf.write(reinterpret_cast<const char*>(&v), sizeof(v)); };
            auto w32 = [&rf](std::uint32_t v){ rf.write(reinterpret_cast<const char*>(&v), sizeof(v)); };
            auto w64 = [&rf](std::uint64_t v){ rf.write(reinterpret_cast<const char*>(&v), sizeof(v)); };
            rf.write("RF64",4); w32(0xFFFFFFFFU); rf.write("WAVE",4);
            rf.write("ds64",4); w32(28U); w64(80U); w64(8U); w64(1U); w32(0U);
            rf.write("fmt ",4); w32(16U); w16(3U); w16(2U); w32(48000U); w32(384000U); w16(8U); w16(32U);
            rf.write("data",4); w32(0xFFFFFFFFU);
            const float a = 0.25F, b = -0.5F;
            rf.write(reinterpret_cast<const char*>(&a), sizeof(a));
            rf.write(reinterpret_cast<const char*>(&b), sizeof(b));
        }
        const auto rf64 = silveton::WavFile::read(rf64Path);
        require(rf64.audio.channels()==2U && rf64.audio.frames()==1U, "RF64 shape mismatch");
        require(near(rf64.audio.sample(0U,0U),0.25F) && near(rf64.audio.sample(1U,0U),-0.5F), "RF64 sample mismatch");
        std::filesystem::remove(rf64Path);

        std::cout << "PASS: meters are derived from real samples\n";
        std::cout << "PASS: constant-power pan and gain affect actual samples\n";
        std::cout << "PASS: Float32 WAV write/read roundtrip\n";
        std::cout << "PASS: RF64 ds64 read path\n";
        std::cout << "PASS: core milestone 0.1.0\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
