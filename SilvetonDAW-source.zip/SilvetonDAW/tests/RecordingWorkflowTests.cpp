#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include "silveton/RecordingWorkflow.h"
#include "silveton/WavFile.h"
#include <atomic>
#include <cmath>
#include <thread>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unistd.h>

namespace {

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

std::string tempPath(const char* stem) {
    return std::string("/tmp/") + stem + "_" + std::to_string(static_cast<long long>(::getpid())) + ".wav";
}

void testLoopRecordingCommitsTakesAndPromotesComp() {
    constexpr std::uint32_t block = 32U;
    const std::string path = tempPath("silveton_recording_workflow");
    std::remove(path.c_str());

    silveton::Project project;
    project.sampleRate = 48000.0;
    project.tempoMap.setSampleRate(48000.0);
    project.tempoMap.setInitialTempo(120.0);
    project.tracks.push_back({});
    project.tracks[0].name = "Lead Vocal";

    silveton::AudioEngine engine;
    silveton::AudioDeviceConfig config {48000.0, block, 2U, 2U};
    engine.prepare(config);
    engine.transport().setCycleRange(true, 20, 40);
    engine.transport().seekSamples(30);
    engine.setPunchRange(true, 25, 35);

    silveton::RecordingWorkflow workflow(engine, project, 0U);
    workflow.start(path, 2U, 1024U);

    silveton::ManualAudioDevice device(config);
    for (std::uint32_t i = 0U; i < block; ++i) {
        const float value = static_cast<float>(i + 1U) * 0.01F;
        device.inputChannelData(0U)[i] = value;
        device.inputChannelData(1U)[i] = -value;
    }
    device.start(engine);
    engine.transport().play();
    device.pump();
    device.stop();

    const auto ids = workflow.stopAndCommitTakes();
    require(ids.size() == 2U, "recording workflow did not commit one take per loop pass");
    require(project.tracks[0].takeLanes.size() == 2U, "recording workflow take lane count mismatch");
    const auto& first = project.tracks[0].takeLanes[0];
    const auto& second = project.tracks[0].takeLanes[1];
    require(first.id == ids[0] && first.cyclePass == 0U && first.clips.size() == 1U,
            "first committed take metadata mismatch");
    require(first.clips[0].sourceStartSample == 0U && first.clips[0].timelineStartSample == 30 &&
            first.clips[0].lengthSamples == 5U, "first committed take range mismatch");
    require(second.id == ids[1] && second.cyclePass == 1U && second.clips.size() == 1U,
            "second committed take metadata mismatch");
    require(second.clips[0].sourceStartSample == 5U && second.clips[0].timelineStartSample == 25 &&
            second.clips[0].lengthSamples == 10U, "second committed take range mismatch");

    const auto wav = silveton::WavFile::read(path);
    require(wav.audio.frames() == 15U, "recording workflow finalized wrong WAV length");
    require(first.clips[0].sourceFrames == 15U && second.clips[0].sourceFrames == 15U,
            "take clips do not reference finalized WAV frame count");

    workflow.promoteTakeToComp(ids[1], 0U);
    require(project.tracks[0].compSections.size() == 1U, "take promotion did not create comp section");
    require(project.tracks[0].clips.size() == 1U, "take promotion did not materialize active clip");
    const auto& active = project.tracks[0].clips[0];
    require(active.audioPath == path && active.timelineStartSample == 25 &&
            active.sourceStartSample == 5U && active.lengthSamples == 10U,
            "take promotion materialized wrong active clip");

    std::remove(path.c_str());
}

void testConsecutiveSessionsAppendStableLaneIds() {
    constexpr std::uint32_t block = 8U;
    const std::string pathA = tempPath("silveton_recording_session_a");
    const std::string pathB = tempPath("silveton_recording_session_b");
    std::remove(pathA.c_str());
    std::remove(pathB.c_str());

    silveton::Project project;
    project.tracks.push_back({});
    silveton::AudioEngine engine;
    silveton::AudioDeviceConfig config {48000.0, block, 1U, 2U};
    engine.prepare(config);
    silveton::ManualAudioDevice device(config);
    for (std::uint32_t i = 0U; i < block; ++i) device.inputChannelData(0U)[i] = 0.25F;
    device.start(engine);
    engine.transport().play();

    silveton::RecordingWorkflow workflow(engine, project, 0U);
    workflow.start(pathA, 1U, 128U);
    device.pump();
    const auto firstIds = workflow.stopAndCommitTakes();
    require(firstIds.size() == 1U && firstIds[0] == 1U, "first recording lane ID mismatch");

    workflow.start(pathB, 1U, 128U);
    device.pump();
    const auto secondIds = workflow.stopAndCommitTakes();
    require(secondIds.size() == 1U && secondIds[0] == 2U, "second recording lane ID was not stable/monotonic");
    require(project.tracks[0].takeLanes.size() == 2U && project.tracks[0].takeLanes[1].name == "Take 2",
            "second recording session did not append take lane correctly");
    device.stop();

    std::remove(pathA.c_str());
    std::remove(pathB.c_str());
}



void testCountInStartsTransportEarlyButRecordsOnlyScheduledRange() {
    constexpr std::uint32_t block = 512U;
    const std::string path = tempPath("silveton_recording_count_in");
    std::remove(path.c_str());

    silveton::Project project;
    project.sampleRate = 1000.0;
    project.tempoMap.setSampleRate(1000.0);
    project.tempoMap.setInitialTempo(120.0);
    project.tracks.push_back({});

    silveton::AudioEngine engine;
    engine.setTempoMap(project.tempoMap);
    silveton::AudioDeviceConfig config {1000.0, block, 1U, 2U};
    engine.prepare(config);
    engine.setPunchRange(true, 100, 200); // Must be restored after this recording session.

    silveton::ManualAudioDevice device(config);
    for (std::uint32_t i = 0U; i < block; ++i) device.inputChannelData(0U)[i] = 0.2F;
    device.start(engine);

    silveton::RecordingWorkflow workflow(engine, project, 0U);
    // 120 BPM @ 1 kHz => 500 samples/beat, 2000 samples/bar in 4/4.
    // Record starts at bar 3 (sample 4000); a two-bar count-in starts at zero.
    workflow.startWithCountIn(path, 1U, 4000, 4500, 2U, 8192U);
    require(workflow.countInArmed(), "count-in was not armed");
    require(workflow.countInStartSample() == 0, "count-in start sample mismatch");
    require(workflow.scheduledRecordStartSample() == 4000, "scheduled record start mismatch");
    require(workflow.countInActive(), "count-in should be active at transport start");
    require(engine.transport().positionSamples() == 0 && engine.transport().isPlaying(),
            "count-in did not start transport at planned position");

    for (int i = 0; i < 9; ++i) device.pump(); // position 4608, crossing both punch boundaries exactly in-buffer
    require(!workflow.countInActive(), "count-in remained active after record point");

    const auto ids = workflow.stopAndCommitTakes();
    device.stop();
    require(ids.size() == 1U, "count-in recording did not commit one take");
    require(project.tracks[0].takeLanes.size() == 1U && project.tracks[0].takeLanes[0].clips.size() == 1U,
            "count-in recording take layout mismatch");
    const auto& clip = project.tracks[0].takeLanes[0].clips[0];
    require(clip.timelineStartSample == 4000 && clip.lengthSamples == 500U,
            "count-in leaked pre-roll audio into the take");
    const auto wav = silveton::WavFile::read(path);
    require(wav.audio.frames() == 500U, "count-in WAV contains audio outside scheduled record range");
    require(engine.punchEnabled() && engine.punchInSample() == 100 && engine.punchOutSample() == 200,
            "count-in workflow did not restore previous punch range");

    std::remove(path.c_str());
}

void testConcurrentStopDoesNotLoseFinalRecordedMetadata() {
    constexpr std::uint32_t block = 1024U;
    constexpr int iterations = 32;

    for (int iteration = 0; iteration < iterations; ++iteration) {
        const std::string path = tempPath((std::string("silveton_recording_concurrent_") + std::to_string(iteration)).c_str());
        std::remove(path.c_str());

        silveton::Project project;
        project.sampleRate = 48000.0;
        project.tracks.push_back({});

        silveton::AudioEngine engine;
        silveton::AudioDeviceConfig config {48000.0, block, 1U, 2U};
        engine.prepare(config);
        engine.transport().seekSamples(0);
        engine.transport().play();

        silveton::ManualAudioDevice device(config);
        for (std::uint32_t i = 0U; i < block; ++i)
            device.inputChannelData(0U)[i] = static_cast<float>((i % 31U) + 1U) * 0.001F;
        device.start(engine);

        silveton::RecordingWorkflow workflow(engine, project, 0U);
        workflow.start(path, 1U, block * 128U);

        std::atomic<bool> keepRunning {true};
        std::atomic<std::uint32_t> completedPumps {0U};
        std::thread audioThread([&] {
            while (keepRunning.load(std::memory_order_acquire)) {
                device.pump();
                completedPumps.fetch_add(1U, std::memory_order_release);
                // ManualAudioDevice can run orders of magnitude faster than a real
                // 48 kHz device. Yield so this test stresses Stop/callback overlap
                // instead of intentionally overflowing the recorder ring.
                std::this_thread::yield();
            }
        });

        while (completedPumps.load(std::memory_order_acquire) < 2U)
            std::this_thread::yield();

        std::vector<std::uint64_t> ids;
        try {
            ids = workflow.stopAndCommitTakes();
        } catch (...) {
            keepRunning.store(false, std::memory_order_release);
            if (audioThread.joinable()) audioThread.join();
            device.stop();
            throw;
        }
        keepRunning.store(false, std::memory_order_release);
        audioThread.join();
        device.stop();

        require(ids.size() == 1U, "concurrent stop did not commit exactly one non-cycle take");
        require(project.tracks[0].takeLanes.size() == 1U,
                "concurrent stop committed wrong take lane count");
        const auto wav = silveton::WavFile::read(path);
        require(wav.audio.frames() > 0U, "concurrent stop finalized an empty WAV");
        const auto& lane = project.tracks[0].takeLanes[0];
        require(lane.clips.size() == 1U, "concurrent stop did not coalesce contiguous recording metadata");
        require(lane.clips[0].sourceStartSample == 0U,
                "concurrent stop take source did not start at WAV frame zero");
        require(lane.clips[0].lengthSamples == wav.audio.frames(),
                "concurrent stop lost final recorded timeline metadata");
        require(lane.clips[0].sourceFrames == wav.audio.frames(),
                "concurrent stop take source length disagrees with finalized WAV");

        std::remove(path.c_str());
    }
}

} // namespace

int main() {
    try {
        testLoopRecordingCommitsTakesAndPromotesComp();
        testConsecutiveSessionsAppendStableLaneIds();
        testCountInStartsTransportEarlyButRecordsOnlyScheduledRange();
        testConcurrentStopDoesNotLoseFinalRecordedMetadata();
        std::cout << "PASS: Stop Recording commits loop passes as take lanes from the finalized WAV\n";
        std::cout << "PASS: committed takes can be promoted directly into the active comp\n";
        std::cout << "PASS: consecutive recording sessions keep stable monotonic take lane IDs\n";
        std::cout << "PASS: count-in starts early but records only the scheduled range and restores punch\n";
        std::cout << "PASS: concurrent Stop finalizes the WAV without losing final take metadata\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
