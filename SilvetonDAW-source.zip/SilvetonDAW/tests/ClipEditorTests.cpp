#include "silveton/ClipEditor.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

std::string tempPath(const char* name) {
    const char* root = std::getenv("TMPDIR");
    std::string path = (root != nullptr && *root != '\0') ? root : "/tmp";
    if (!path.empty() && path.back() != '/') path.push_back('/');
    return path + name;
}

silveton::ProjectAudioClip makeClip() {
    silveton::ProjectAudioClip clip;
    clip.audioPath = "voice.wav";
    clip.timelineStartSample = 13;
    clip.sourceStartSample = 100U;
    clip.lengthSamples = 400U;
    clip.sourceFrames = 1000U;
    clip.gainDb = -3.0F;
    clip.fadeInSamples = 80U;
    clip.fadeOutSamples = 120U;
    return clip;
}
}

int main() {
    try {
        silveton::Project project;
        project.sampleRate = 48000.0;
        project.tempoMap.setSampleRate(48000.0);
        project.tempoMap.setInitialTempo(120.0);
        project.tracks.push_back({});
        project.tracks[0].name = "Vocal";

        silveton::ClipEditor editor(project, 0U);
        silveton::ClipSnapSettings sampleSnap;
        sampleSnap.mode = silveton::ClipSnapMode::Samples;
        sampleSnap.sampleStep = 10;
        const std::uint64_t firstId = editor.addClip(makeClip(), sampleSnap);
        require(firstId == 1U, "automatic clip ID is wrong");
        require(project.tracks[0].clips[0].timelineStartSample == 10, "sample snap did not round clip start");

        editor.moveClip(firstId, 26, sampleSnap);
        require(project.tracks[0].clips[0].timelineStartSample == 30, "sample snap did not round move");
        require(editor.undo(), "move undo missing");
        require(project.tracks[0].clips[0].timelineStartSample == 10, "move undo did not restore clip");
        require(editor.redo(), "move redo missing");
        require(project.tracks[0].clips[0].timelineStartSample == 30, "move redo did not restore edit");

        editor.setFades(firstId, 80U, 120U);
        const std::uint64_t secondId = editor.splitClip(firstId, 230);
        require(project.tracks[0].clips.size() == 2U, "split did not create second clip");
        const auto& first = project.tracks[0].clips[0];
        const auto& second = project.tracks[0].clips[1];
        require(second.id == secondId && second.timelineStartSample == 230, "split position is wrong");
        require(first.lengthSamples == 200U && second.lengthSamples == 200U, "split lengths are wrong");
        require(second.sourceStartSample == 300U, "split source offset is wrong");
        require(first.fadeInAnchorSourceSample == 100U && second.fadeInAnchorSourceSample == 100U,
                "split did not preserve fade-in anchor");
        require(first.fadeOutAnchorSourceSample == 500U && second.fadeOutAnchorSourceSample == 500U,
                "split did not preserve fade-out anchor");

        require(editor.undo(), "split undo missing");
        require(project.tracks[0].clips.size() == 1U && project.tracks[0].clips[0].lengthSamples == 400U,
                "split undo did not restore one clip");
        require(editor.redo(), "split redo missing");
        require(project.tracks[0].clips.size() == 2U, "split redo did not restore two clips");

        // Musical snap at 120 BPM / 48 kHz: a 1/4-quarter grid is 6000 samples.
        silveton::ClipSnapSettings musical;
        musical.mode = silveton::ClipSnapMode::Musical;
        musical.divisionsPerQuarter = 4U;
        editor.moveClip(secondId, 6200, musical);
        auto it = std::find_if(project.tracks[0].clips.begin(), project.tracks[0].clips.end(),
                               [secondId](const auto& c) { return c.id == secondId; });
        require(it != project.tracks[0].clips.end() && it->timelineStartSample == 6000,
                "musical snap did not use tempo map");

        editor.trimLeft(secondId, 6010);
        it = std::find_if(project.tracks[0].clips.begin(), project.tracks[0].clips.end(),
                          [secondId](const auto& c) { return c.id == secondId; });
        require(it->sourceStartSample == 310U && it->lengthSamples == 190U,
                "left trim did not move source start nondestructively");
        editor.trimRight(secondId, 6150);
        it = std::find_if(project.tracks[0].clips.begin(), project.tracks[0].clips.end(),
                          [secondId](const auto& c) { return c.id == secondId; });
        require(it->lengthSamples == 140U, "right trim did not change clip length");

        const std::string path = tempPath("silveton_clip_v20.svp");
        std::remove(path.c_str());
        project.save(path);
        const silveton::Project restored = silveton::Project::load(path);
        std::remove(path.c_str());
        require(restored.tracks.size() == 1U && restored.tracks[0].clips.size() == 2U,
                "V20 clip round-trip lost clips");
        const auto& restoredSecond = restored.tracks[0].clips[1];
        require(restoredSecond.id == secondId && restoredSecond.audioPath == "voice.wav" &&
                restoredSecond.timelineStartSample == 6010 && restoredSecond.sourceStartSample == 310U &&
                restoredSecond.lengthSamples == 140U && restoredSecond.sourceFrames == 1000U,
                "V20 clip round-trip changed clip state");

        // Duplicate IDs must be rejected before saving a corrupt project.
        silveton::Project broken = restored;
        broken.tracks[0].clips.push_back(broken.tracks[0].clips[0]);
        bool rejected = false;
        try { broken.save(tempPath("silveton_bad_clip_ids.svp")); }
        catch (const std::runtime_error&) { rejected = true; }
        std::remove(tempPath("silveton_bad_clip_ids.svp").c_str());
        require(rejected, "duplicate clip IDs were accepted");

        std::cout << "PASS: clip move/split/trim use nondestructive project state\n";
        std::cout << "PASS: sample and musical snap work\n";
        std::cout << "PASS: clip undo/redo is one operation per edit\n";
        std::cout << "PASS: V20 project saves and restores explicit clips\n";
        std::cout << "PASS: duplicate clip IDs are rejected\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
