// A 44.1/48 kHz file stays untouched on disk and still plays at the internal
// rate: the disk streamer converts one cache page at a time with the Studio
// sinc. These tests prove that the result is bit-identical to converting the
// whole file in one go, that page boundaries are seamless, and that mono,
// stereo, up- and down-conversion all agree.
#include "silveton/AudioBuffer.h"
#include "silveton/AudioEngine.h"
#include "silveton/DiskStream.h"
#include "silveton/StudioResampler.h"
#include "silveton/WavFile.h"

#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {
using namespace silveton;

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

std::string tempPath(const char* name) {
    const char* env = std::getenv("TMPDIR");
    std::string base = (env != nullptr && *env != '\0') ? std::string(env) : std::string("/tmp");
    if (!base.empty() && base.back() != '/') base += '/';
    return base + name;
}

AudioBuffer makeSignal(std::uint32_t channels, std::size_t frames, double rate) {
    AudioBuffer audio(channels, frames);
    std::mt19937 rng(1234U);
    std::uniform_real_distribution<float> noise(-0.05F, 0.05F);
    for (std::uint32_t c = 0U; c < channels; ++c)
        for (std::size_t i = 0U; i < frames; ++i) {
            const double t = static_cast<double>(i) / rate;
            audio.sample(c, i) = static_cast<float>(0.4 * std::sin(2.0 * 3.14159265358979 * (440.0 + 110.0 * c) * t) +
                                                    0.2 * std::sin(2.0 * 3.14159265358979 * 3100.0 * t)) + noise(rng);
        }
    return audio;
}

bool identical(const AudioBuffer& a, const AudioBuffer& b) {
    if (a.channels() != b.channels() || a.frames() != b.frames()) return false;
    for (std::size_t c = 0U; c < a.channels(); ++c)
        for (std::size_t i = 0U; i < a.frames(); ++i)
            if (a.sample(c, i) != b.sample(c, i)) return false;
    return true;
}

// 1. Any range rendered on demand equals the same frames of the whole conversion.
void testRangesMatchWholeConversion(double sourceRate, double destinationRate, std::uint32_t channels) {
    const std::size_t sourceFrames = 60000U;
    const AudioBuffer source = makeSignal(channels, sourceFrames, sourceRate);
    const AudioBuffer whole = StudioResampler::convert(source, sourceRate, destinationRate);
    StudioRangeConverter converter;
    converter.prepare(sourceRate, destinationRate);
    require(StudioRangeConverter::destinationFrames(sourceFrames, sourceRate, destinationRate) == whole.frames(),
            "converted length differs from convert()");

    std::mt19937_64 rng(99U);
    std::vector<std::vector<float>> pad(channels);
    std::vector<float> weights(converter.weightScratchSize());
    std::vector<float> out;
    const std::uint64_t total = whole.frames();
    std::vector<std::pair<std::uint64_t, std::uint32_t>> ranges {{0U, 1U}, {0U, 4096U}, {total - 1U, 1U}, {total - 700U, 700U}};
    for (int i = 0; i < 40; ++i) {
        const std::uint32_t count = 1U + static_cast<std::uint32_t>(rng() % 5000U);
        const std::uint64_t start = rng() % (total - count + 1U);
        ranges.emplace_back(start, count);
    }
    for (const auto& range : ranges) {
        const std::uint64_t start = range.first;
        const std::uint32_t count = range.second;
        std::int64_t first = 0;
        std::uint32_t length = 0U;
        converter.sourceRange(start, count, first, length);
        std::vector<const float*> pointers(channels);
        for (std::uint32_t c = 0U; c < channels; ++c) {
            pad[c].assign(length, 0.0F);
            for (std::uint32_t k = 0U; k < length; ++k) {
                const std::int64_t index = first + static_cast<std::int64_t>(k);
                if (index >= 0 && index < static_cast<std::int64_t>(sourceFrames)) pad[c][k] = source.sample(c, static_cast<std::size_t>(index));
            }
            pointers[c] = pad[c].data();
        }
        out.assign(static_cast<std::size_t>(count) * channels, 0.0F);
        converter.render(pointers.data(), channels, first, start, count, out.data(), weights.data());
        for (std::uint32_t i = 0U; i < count; ++i)
            for (std::uint32_t c = 0U; c < channels; ++c)
                require(out[static_cast<std::size_t>(i) * channels + c] == whole.sample(c, static_cast<std::size_t>(start + i)),
                        "range conversion differs from the whole-file conversion");
    }
}

// 2. A converted disk source, read the way the engine reads it (blocks that are
//    split at page boundaries), equals the whole-file conversion exactly.
void testConvertedDiskSource(double fileRate, std::uint32_t targetRate, std::uint32_t channels, std::uint32_t cacheFrames) {
    const std::string path = tempPath("SilvetonVirtualRate.wav");
    (void)std::remove(path.c_str());
    const AudioBuffer source = makeSignal(channels, 52000U, fileRate);
    WavFile::writeFloat32(path, static_cast<std::uint32_t>(fileRate), source);
    const AudioBuffer expected = StudioResampler::convert(source, fileRate, static_cast<double>(targetRate));

    DiskStreamManager streams(2U);
    DiskAudioSource& disk = streams.addSource(path, cacheFrames, targetRate);
    require(disk.rateConverted(), "source was not converted");
    require(disk.sampleRate() == targetRate, "converted source must report the target rate");
    require(disk.nativeSampleRate() == static_cast<std::uint32_t>(fileRate), "native rate lost");
    require(disk.frames() == expected.frames(), "converted frame count differs from convert()");
    require(disk.nativeFrames() == source.frames(), "native frame count lost");
    streams.start();
    require(streams.prime(0U, 5000U), "converted source did not prime");

    AudioBuffer played(channels, static_cast<std::size_t>(disk.frames()));
    std::uint64_t frame = 0U;
    std::mt19937 rng(7U);
    while (frame < disk.frames()) {
        std::uint32_t block = 1U + static_cast<std::uint32_t>(rng() % 700U);   // 557-like, never a divisor of the page
        block = static_cast<std::uint32_t>(std::min<std::uint64_t>(block, disk.frames() - frame));
        block = std::min(block, disk.framesUntilPageEnd(frame));
        DiskBlockView view;
        bool ok = false;
        for (int retry = 0; retry < 5000 && !ok; ++retry) {
            ok = disk.acquire(frame, block, view);
            if (!ok) std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        require(ok, "converted page was not available");
        for (std::uint32_t i = 0U; i < block; ++i)
            for (std::uint32_t c = 0U; c < channels; ++c)
                played.sample(c, static_cast<std::size_t>(frame + i)) = view.interleaved[static_cast<std::size_t>(view.frameOffset + i) * view.channels + c];
        disk.release(view);
        frame += block;
    }
    streams.stop();
    require(identical(played, expected), "streamed conversion differs from the whole-file conversion");
    (void)std::remove(path.c_str());
}

// 3. A file already at the target rate is streamed untouched (no converter).
void testSameRateIsNotConverted() {
    const std::string path = tempPath("SilvetonSameRate.wav");
    WavFile::writeFloat32(path, 96000U, makeSignal(2U, 5000U, 96000.0));
    DiskStreamManager streams(1U);
    DiskAudioSource& disk = streams.addSource(path, 4096U, 96000U);
    require(!disk.rateConverted() && disk.frames() == 5000U && disk.sampleRate() == 96000U, "same-rate file must stay unconverted");
    DiskStreamManager plain(1U);
    DiskAudioSource& none = plain.addSource(path, 4096U);
    require(!none.rateConverted() && none.sampleRate() == 96000U, "default addSource must not convert");
    (void)std::remove(path.c_str());
}

// 4. Through the engine: a 44.1 kHz file on a 96 kHz engine plays at the right
//    speed (a 1 kHz tone keeps its pitch) and the page boundaries are silent-free.
void testEnginePlaysConvertedFileAtRightPitch() {
    const std::string path = tempPath("SilvetonEnginePitch.wav");
    AudioBuffer tone(1U, 44100U);
    for (std::size_t i = 0U; i < tone.frames(); ++i) tone.sample(0U, i) = static_cast<float>(0.5 * std::sin(2.0 * 3.14159265358979 * 1000.0 * static_cast<double>(i) / 44100.0));
    WavFile::writeFloat32(path, 44100U, tone);

    DiskStreamManager streams(1U);
    auto& disk = streams.addSource(path, 16384U, 96000U);
    streams.start();
    require(streams.prime(0U, 5000U), "did not prime");
    AudioEngine engine;
    engine.prepare({96000.0, 557U, 0U, 2U});
    TimelineTrack track;
    TimelineClip clip;
    clip.diskSource = &disk;
    clip.timelineStartSample = 0;
    clip.lengthSamples = disk.frames();
    track.clips.push_back(clip);
    engine.addTrack(std::move(track));
    engine.transport().play();

    std::vector<float> left;
    std::vector<float> right(557U), block(557U);
    for (int b = 0; b < 160; ++b) {
        float* outs[2] {block.data(), right.data()};
        engine.processAudio(nullptr, outs, 0U, 2U, 557U);
        left.insert(left.end(), block.begin(), block.end());
        std::this_thread::sleep_for(std::chrono::microseconds(300));
    }
    streams.stop();
    // Count zero crossings in the steady middle: 1 kHz at 96 kHz = 192 per 96000 frames.
    std::size_t crossings = 0U;
    const std::size_t begin = 20000U, end = 80000U;
    for (std::size_t i = begin + 1U; i < end; ++i) if ((left[i - 1U] < 0.0F) != (left[i] < 0.0F)) ++crossings;
    const double hz = static_cast<double>(crossings) / 2.0 / (static_cast<double>(end - begin) / 96000.0);
    require(std::abs(hz - 1000.0) < 15.0, "converted file plays at the wrong pitch");
    // No dropout: every 64-frame window in the middle has signal.
    for (std::size_t i = begin; i + 64U < end; i += 64U) {
        float peak = 0.0F;
        for (std::size_t k = 0U; k < 64U; ++k) peak = std::max(peak, std::abs(left[i + k]));
        require(peak > 0.05F, "dropout while playing a converted file");
    }
    (void)std::remove(path.c_str());
}
} // namespace

int main() {
    try {
        testRangesMatchWholeConversion(44100.0, 96000.0, 2U);
        testRangesMatchWholeConversion(48000.0, 96000.0, 1U);
        testRangesMatchWholeConversion(192000.0, 96000.0, 2U);
        testConvertedDiskSource(44100.0, 96000U, 2U, 4096U);
        testConvertedDiskSource(48000.0, 96000U, 1U, 16384U);
        testConvertedDiskSource(88200.0, 96000U, 2U, 3000U);
        testSameRateIsNotConverted();
        testEnginePlaysConvertedFileAtRightPitch();
        std::cout << "virtual-rate source tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
