#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/DiskStream.h"
#include "silveton/WavFile.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <chrono>
#include <thread>
#include <new>
#include <stdexcept>
#include <string>

namespace {
thread_local bool gTrackAllocations = false;
thread_local std::size_t gAllocationCount = 0U;

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

std::string tempPath(const char* name) {
    const char* env = std::getenv("TMPDIR");
    std::string base = (env != nullptr && *env != '\0') ? std::string(env) : std::string("/tmp");
    if (!base.empty() && base.back() != '/') base += '/';
    return base + name;
}
}

void* operator new(std::size_t size) {
    if (gTrackAllocations) ++gAllocationCount;
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}
void* operator new[](std::size_t size) {
    if (gTrackAllocations) ++gAllocationCount;
    if (void* p = std::malloc(size)) return p;
    throw std::bad_alloc();
}
void* operator new(std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackAllocations) ++gAllocationCount;
    return std::malloc(size);
}
void* operator new[](std::size_t size, const std::nothrow_t&) noexcept {
    if (gTrackAllocations) ++gAllocationCount;
    return std::malloc(size);
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }
void operator delete(void* p, const std::nothrow_t&) noexcept { std::free(p); }
void operator delete[](void* p, const std::nothrow_t&) noexcept { std::free(p); }

int main() {
    using namespace silveton;
    try {
        constexpr std::uint32_t block = 64U;
        constexpr std::size_t trackCount = Project::kMaxTracks;
        constexpr std::size_t fileFrames = 4096U;
        constexpr float perTrack = 0.001F;

        const std::string audioPath = tempPath("silveton_256_track_source.wav");
        const std::string projectPath = tempPath("silveton_256_track_project.svp");
        std::remove(audioPath.c_str());
        std::remove(projectPath.c_str());

        AudioBuffer sourceAudio(2U, fileFrames);
        for (std::size_t i = 0U; i < fileFrames; ++i) {
            sourceAudio.sample(0U, i) = perTrack;
            sourceAudio.sample(1U, i) = -perTrack;
        }
        WavFile::writeFloat32(audioPath, 48000U, sourceAudio);

        DiskStreamManager streams(16U); // LRU file-handle pool stays well below old macOS soft limits.
        for (std::size_t i = 0U; i < trackCount; ++i) {
            auto& disk = streams.addSource(audioPath, static_cast<std::uint32_t>(fileFrames));
            require(disk.channels() == 2U && disk.frames() == fileFrames, "disk source metadata mismatch");
        }
        require(streams.sourceCount() == trackCount, "256 disk sources were not created");
        bool rejected257 = false;
        try {
            (void)streams.addSource(audioPath, static_cast<std::uint32_t>(fileFrames));
        } catch (const std::length_error&) {
            rejected257 = true;
        }
        require(rejected257, "257th disk source was not rejected");

        streams.start();
        require(streams.prime(0U, 10000U), "256-track disk cache did not prime");

        AudioEngine engine;
        engine.prepare({48000.0, block, 0U, 2U});
        for (std::size_t i = 0U; i < trackCount; ++i) {
            TimelineTrack track;
            track.diskSource = &streams.source(i);
            track.timelineStartSample = 0;
            track.sourceStartSample = 0U;
            track.gainDb = 0.0F;
            track.pan = 0.0F;
            track.mute = false;
            track.voiceEnabled = true;
            track.voicePriority = 0;
            engine.addTrack(track);
        }
        require(engine.voicedTrackCount() == trackCount, "engine did not voice all 256 session tracks");

        ManualAudioDevice device({48000.0, block, 0U, 2U});
        device.start(engine);
        engine.transport().play();

        // Warm-up outside the measured region.
        device.pump();
        engine.transport().seekSamples(0);

        gAllocationCount = 0U;
        gTrackAllocations = true;
        for (int i = 0; i < 32; ++i) device.pump();
        gTrackAllocations = false;

        require(gAllocationCount == 0U, "heap allocation occurred in 256-track disk playback callback");
        const float expectedLeft = static_cast<float>(trackCount) * perTrack;
        const float expectedRight = -expectedLeft;
        require(std::abs(device.lastOutput()[0][0] - expectedLeft) < 2.0e-5F,
                "256-track disk sum left output mismatch");
        require(std::abs(device.lastOutput()[1][0] - expectedRight) < 2.0e-5F,
                "256-track disk sum right output mismatch");
        const auto firstTrackMeter = engine.trackMeter(0U);
        const auto lastTrackMeter = engine.trackMeter(255U);
        require(std::abs(firstTrackMeter.leftPeak - perTrack) < 1.0e-7F &&
                std::abs(firstTrackMeter.rightPeak - perTrack) < 1.0e-7F,
                "track 1 meter is not derived from its real post-pan signal");
        require(std::abs(lastTrackMeter.leftPeak - perTrack) < 1.0e-7F &&
                std::abs(lastTrackMeter.rightPeak - perTrack) < 1.0e-7F,
                "track 256 meter is not derived from its real post-pan signal");

        engine.transport().stop();
        device.stop();
        for (std::size_t i = 0U; i < trackCount; ++i) {
            const auto status = streams.source(i).status();
            require(!status.ioError, "disk source reported I/O error");
            require(status.underflowBlocks == 0U && status.underflowFrames == 0U,
                    "disk source underflowed during 256-track playback");
        }
        streams.stop();

        // Exercise real cache-page handoff instead of only a fully cached test window.
        DiskStreamManager continuity(4U);
        auto& continuitySource = continuity.addSource(audioPath, 128U);
        continuity.start();
        require(continuity.prime(0U, 5000U), "small-page stream did not prime");
        const auto prefetchDeadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
        while (continuitySource.status().cacheLoads < 2U && std::chrono::steady_clock::now() < prefetchDeadline)
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        require(continuitySource.status().cacheLoads >= 2U, "disk streamer did not prefetch next cache page");

        AudioEngine continuityEngine;
        continuityEngine.prepare({48000.0, block, 0U, 2U});
        TimelineTrack continuityTrack;
        continuityTrack.diskSource = &continuitySource;
        continuityEngine.addTrack(continuityTrack);
        ManualAudioDevice continuityDevice({48000.0, block, 0U, 2U});
        continuityDevice.start(continuityEngine);
        continuityEngine.transport().play();
        for (int i = 0; i < 24; ++i) {
            continuityDevice.pump();
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
        continuityEngine.transport().stop();
        continuityDevice.stop();
        require(!continuitySource.status().ioError, "small-page disk stream reported I/O error");
        require(continuitySource.status().underflowBlocks == 0U,
                "disk playback underflowed while crossing cache page boundaries");
        require(continuitySource.status().cacheLoads >= 8U,
                "disk streamer did not advance through multiple cache pages");
        continuity.stop();

        Project project;
        project.sampleRate = 48000.0;
        project.tempo = 120.0;
        for (std::size_t i = 0U; i < trackCount; ++i) {
            ProjectTrack track;
            track.name = "Track " + std::to_string(i + 1U);
            track.audioPath = audioPath;
            track.gainDb = -3.0F;
            track.pan = 0.0F;
            track.timelineStartSample = static_cast<std::int64_t>(i * 8U);
            track.sourceStartSample = static_cast<std::uint64_t>(i % 32U);
            track.voiceEnabled = true;
            track.voicePriority = static_cast<int>(i % 4U);
            project.addTrack(std::move(track));
        }
        bool projectRejected257 = false;
        try {
            project.addTrack(ProjectTrack{});
        } catch (const std::length_error&) {
            projectRejected257 = true;
        }
        require(projectRejected257, "257th project track was not rejected");

        project.save(projectPath);
        const Project restored = Project::load(projectPath);
        require(restored.tracks.size() == trackCount, "256 project tracks did not round-trip");
        require(restored.tracks[255U].name == "Track 256", "track 256 identity did not round-trip");
        require(restored.tracks[255U].timelineStartSample == static_cast<std::int64_t>(255U * 8U),
                "track 256 timeline position did not round-trip");
        require(restored.tracks[255U].sourceStartSample == 31U,
                "track 256 source offset did not round-trip");
        require(restored.tracks[255U].voicePriority == 3,
                "track 256 voice priority did not round-trip");

        std::remove(audioPath.c_str());
        std::remove(projectPath.c_str());

        std::cout << "PASS: 256 disk-backed stereo tracks are voiced simultaneously\n";
        std::cout << "PASS: 256-track disk playback performs zero heap allocations in the callback\n";
        std::cout << "PASS: 256-track real summed output matches the expected audio samples\n";
        std::cout << "PASS: Track 1 and Track 256 meters are derived from real post-pan samples\n";
        std::cout << "PASS: all 256 disk sources complete playback without cache underflow\n";
        std::cout << "PASS: disk playback crosses multiple cache pages without callback I/O/underflow\n";
        std::cout << "PASS: project V4 persists 256 track timeline/source/voice states\n";
        std::cout << "PASS: session contract rejects track 257\n";
        return 0;
    } catch (const std::exception& e) {
        gTrackAllocations = false;
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
