#include "silveton/DawCore.h"
#include "silveton/MidiPartEditor.h"
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace { void require(bool ok, const char* m){ if(!ok) throw std::runtime_error(m); } }

int main() {
    silveton::TempoMap map; map.setSampleRate(48000.0); map.setInitialTempo(120.0);
    std::vector<silveton::MidiPart> parts;
    silveton::MidiPartEditor editor(parts);
    silveton::MidiPart part;
    part.timelineStartQuarterNotes = 4.0;
    part.lengthQuarterNotes = 8.0;
    part.loopLengthQuarterNotes = 4.0;
    (void)part.sequence.addNote({0U, 0.0, 1.0, 0U, 60U, 100U, 64U, false});
    (void)part.sequence.addMessage({0U, 2.0, 0xB0U, 1U, 80U, false});
    const auto partId = editor.add(part);

    silveton::MidiSequence legacy;
    const auto before = silveton::compileMidiArrangement(legacy, parts, map).events();
    require(before.size() == 6U, "looped MIDI part did not generate two note pairs + two CC events");
    require(before[0].sample == 96000, "MIDI part start sample mismatch");

    const auto rightId = editor.split(partId, 8.0);
    require(rightId != 0U && parts.size() == 2U, "MIDI part split failed");
    const auto after = silveton::compileMidiArrangement(legacy, parts, map).events();
    require(after.size() == before.size(), "split changed MIDI event count");
    for (std::size_t i = 0; i < before.size(); ++i) {
        require(before[i].sample == after[i].sample && before[i].status == after[i].status && before[i].data1 == after[i].data1 && before[i].data2 == after[i].data2,
                "split changed loop phase/events");
    }
    require(editor.undo(), "MIDI part undo failed");
    require(parts.size() == 1U, "MIDI part undo did not restore part");
    require(editor.redo(), "MIDI part redo failed");
    require(parts.size() == 2U, "MIDI part redo did not restore split");

    silveton::Project project;
    project.sampleRate = 48000.0; project.tempo = 120.0;
    project.tempoMap = map;
    silveton::ProjectMidiTrack track; track.name = "Instrument"; track.outputPort = 7; track.parts = parts;
    project.midiTracks.push_back(track);
    const std::string path = "/tmp/SilvetonMidiPartsV23.silv";
    project.save(path);
    const auto loaded = silveton::Project::load(path);
    require(loaded.midiTracks.size() == 1U && loaded.midiTracks[0].parts.size() == 2U, "V23 MIDI parts round trip failed");
    const auto restored = silveton::compileMidiArrangement(loaded.midiTracks[0].sequence, loaded.midiTracks[0].parts, loaded.tempoMap).events();
    require(restored.size() == after.size(), "restored MIDI part plan mismatch");
    (void)std::remove(path.c_str());
    std::cout << "PASS: MIDI parts loop/split/Undo/Redo and V23 save/load\n";
    return 0;
}
