#include "silveton/AudioBuffer.h"
#include "silveton/AudioDevice.h"
#include "silveton/AudioEngine.h"
#include "silveton/MixMath.h"
#include <array>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace silveton;
static void require(bool v, const std::string& m) { if (!v) throw std::runtime_error(m); }
static bool near(double a, double b, double eps = 1.0e-10) { return std::abs(a-b) <= eps; }

int main() {
    try {
        constexpr std::uint32_t block = 64;
        AudioEngine engine;
        engine.prepare({48000.0, block, 2U, 2U});

        // Voice allocation: highest priority track remains voiced when limited.
        AudioBuffer quiet(2, block), loud(2, block);
        for (std::size_t i=0;i<block;++i) {
            quiet.sample(0,i)=quiet.sample(1,i)=0.1F;
            loud.sample(0,i)=loud.sample(1,i)=0.8F;
        }
        engine.addTrack({&quiet,0,0,0.0F,0.0F,false,true,1});
        engine.addTrack({&loud,0,0,0.0F,0.0F,false,true,10});
        engine.setVoiceLimit(1);
        require(engine.voicedTrackCount()==1, "voice limit not applied");
        ManualAudioDevice dev({48000.0, block, 2U, 2U});
        dev.start(engine);
        engine.transport().play();
        dev.pump();
        require(std::abs(dev.lastOutput()[0][0]-0.8F)<1e-5F, "voice priority plan did not select highest-priority track");
        engine.transport().stop();

        // Native low-latency monitor path works even with stopped transport.
        engine.setLowLatencyInputMonitoring(true, -6.0205999F); // ~= 0.5 linear
        for (std::size_t i=0;i<block;++i) {
            dev.inputChannelData(0)[i]=0.4F;
            dev.inputChannelData(1)[i]=-0.2F;
        }
        dev.pump();
        require(std::abs(dev.lastOutput()[0][0]-0.2F)<2e-5F, "input monitoring L incorrect");
        require(std::abs(dev.lastOutput()[1][0]+0.1F)<2e-5F, "input monitoring R incorrect");
        const auto m=engine.outputMeter();
        require(std::abs(m.leftPeak-0.2F)<2e-5F, "monitoring meter not derived from real output");
        engine.setLowLatencyInputMonitoring(false);

        // Session pan-depth choices land exactly at their documented centre attenuation.
        const std::array<std::pair<PanDepth,double>,4> depths {{
            {PanDepth::Minus2_5dB,-2.5},
            {PanDepth::Minus3dB,-3.0},
            {PanDepth::Minus4_5dB,-4.5},
            {PanDepth::Minus6dB,-6.0}
        }};
        for (const auto& [depth, db] : depths) {
            const auto g = MixMath::monoPan(0.0F, depth);
            const double expected = MixMath::dbToLinear(db);
            require(near(g.left, expected, 2.0e-12), "pan-depth centre gain incorrect (L)");
            require(near(g.right, expected, 2.0e-12), "pan-depth centre gain incorrect (R)");
            const auto hardL = MixMath::monoPan(-1.0F, depth);
            const auto hardR = MixMath::monoPan(1.0F, depth);
            require(hardL.left == 1.0 && hardL.right == 0.0, "hard-left pan endpoint incorrect");
            require(hardR.left == 0.0 && hardR.right == 1.0, "hard-right pan endpoint incorrect");
        }

        // Compensated 64-bit accumulator keeps small contributions beside a huge value.
        double sum = 0.0, comp = 0.0;
        MixMath::compensatedAdd(1.0e16, sum, comp);
        for (int i=0;i<1000;++i) MixMath::compensatedAdd(1.0, sum, comp);
        MixMath::compensatedAdd(-1.0e16, sum, comp);
        require(near(sum + comp, 1000.0, 1.0e-6), "compensated summing lost low-level contributions");

        // Floating-point mix bus deliberately keeps >0 dBFS headroom; no hidden hard clip.
        engine.clearTracks();
        engine.setVoiceLimit(0);
        AudioBuffer hotA(2, block), hotB(2, block);
        for (std::size_t i=0;i<block;++i) {
            hotA.sample(0,i)=hotA.sample(1,i)=0.9F;
            hotB.sample(0,i)=hotB.sample(1,i)=0.9F;
        }
        engine.addTrack({&hotA,0,0,0.0F,0.0F,false,true,0});
        engine.addTrack({&hotB,0,0,0.0F,0.0F,false,true,0});
        engine.transport().seekSamples(0);
        engine.transport().play();
        dev.pump();
        engine.transport().stop();
        require(dev.lastOutput()[0][0] > 1.79F, "mix bus clipped floating-point headroom at 0 dBFS");
        require(engine.outputMeter().leftPeak > 1.79F, "meter failed to report real over-0dBFS level");

        // Master path is post-sum, click-free, and metering follows post-fader output.
        engine.clearTracks();
        AudioBuffer masterTone(2, block);
        for (std::size_t i=0;i<block;++i) masterTone.sample(0,i)=masterTone.sample(1,i)=1.0F;
        engine.addTrack({&masterTone,0,0,0.0F,0.0F,false,true,0});
        engine.setMasterFaderDb(-6.0205999F);
        engine.transport().seekSamples(0);
        engine.transport().play();
        dev.pump(); // ramp block
        engine.transport().seekSamples(0);
        dev.pump(); // settled block
        engine.transport().stop();
        require(std::abs(dev.lastOutput()[0][0]-0.5F)<2e-5F, "master fader gain incorrect");
        require(std::abs(engine.outputMeter().leftPeak-0.5F)<2e-5F, "master meter is not post-fader");
        engine.setMasterFaderDb(0.0F);
        engine.transport().seekSamples(0);
        engine.transport().play();
        dev.pump();
        engine.transport().stop();

        // Pro-style dual stereo panner: default hard L/R preserves the stereo source.
        engine.clearTracks();
        AudioBuffer stereo(2, block);
        for (std::size_t i=0;i<block;++i) {
            stereo.sample(0,i)=0.25F;
            stereo.sample(1,i)=0.50F;
        }
        TimelineTrack stereoTrack {&stereo,0,0,0.0F,0.0F,false,true,0};
        stereoTrack.useDualStereoPan = true;
        stereoTrack.stereoLeftPan = -1.0F;
        stereoTrack.stereoRightPan = 1.0F;
        engine.addTrack(stereoTrack);
        engine.transport().seekSamples(0);
        engine.transport().play();
        dev.pump();
        engine.transport().stop();
        require(std::abs(dev.lastOutput()[0][0]-0.25F)<1e-6F, "dual stereo pan altered left source at default position");
        require(std::abs(dev.lastOutput()[1][0]-0.50F)<1e-6F, "dual stereo pan altered right source at default position");

        // Mix output is invariant to host buffer size for static session state.
        AudioBuffer invariantSource(2, 256);
        for (std::size_t i=0;i<invariantSource.frames();++i) {
            invariantSource.sample(0,i)=static_cast<float>(0.3*std::sin(0.071*static_cast<double>(i)));
            invariantSource.sample(1,i)=static_cast<float>(0.2*std::cos(0.053*static_cast<double>(i)));
        }
        auto renderWithBlock = [&invariantSource](std::uint32_t bs) {
            AudioEngine e; e.prepare({48000.0,bs,0U,2U}); e.setPanDepth(PanDepth::Minus4_5dB);
            TimelineTrack t{&invariantSource,0,0,-1.5F,0.2F,false,true,0};
            e.addTrack(t); e.transport().play();
            std::vector<float> allL, allR; allL.reserve(256); allR.reserve(256);
            std::vector<float> l(bs), r(bs); float* outs[2]={l.data(),r.data()};
            for (std::size_t done=0; done<256; done+=bs) {
                e.processAudio(nullptr,outs,0U,2U,bs);
                allL.insert(allL.end(),l.begin(),l.end()); allR.insert(allR.end(),r.begin(),r.end());
            }
            return std::pair<std::vector<float>,std::vector<float>>{std::move(allL),std::move(allR)};
        };
        const auto mix64=renderWithBlock(64U);
        const auto mix128=renderWithBlock(128U);
        for (std::size_t i=0;i<256;++i) {
            require(std::abs(mix64.first[i]-mix128.first[i])<1e-7F, "buffer size changed left mix result");
            require(std::abs(mix64.second[i]-mix128.second[i])<1e-7F, "buffer size changed right mix result");
        }

        dev.stop();
        std::cout << "PASS: deterministic voice allocation\n";
        std::cout << "PASS: native low-latency input monitor path\n";
        std::cout << "PASS: exact session pan-depth centre gains\n";
        std::cout << "PASS: compensated 64-bit floating-point summing\n";
        std::cout << "PASS: floating-point headroom is not hard-clipped\n";
        std::cout << "PASS: click-free master fader and post-fader metering\n";
        std::cout << "PASS: dual stereo panner preserves default stereo image\n";
        std::cout << "PASS: mix result is invariant across 64/128-sample buffers\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
