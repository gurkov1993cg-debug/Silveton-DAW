#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/TempoMap.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <string>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

void requireNear(double actual, double expected, double tolerance, const char* message) {
    if (std::abs(actual - expected) > tolerance) throw std::runtime_error(message);
}

class ContextProbe final : public silveton::IRoutedTrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override { callCount = 0U; }
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 0U; }
    std::size_t outputBusCount() const noexcept override { return 1U; }

    bool processBuses(const silveton::ConstStereoBus*,
                      std::size_t,
                      silveton::StereoBus* outputs,
                      std::size_t outputCount,
                      std::uint32_t frames,
                      const silveton::ProcessorContext& context) noexcept override {
        if (callCount < tempos.size()) {
            tempos[callCount] = context.tempo;
            samples[callCount] = context.projectSample;
            frameCounts[callCount] = context.frames;
            quarterNotes[callCount] = context.projectQuarterNotes;
            numerators[callCount] = context.timeSignatureNumerator;
            denominators[callCount] = context.timeSignatureDenominator;
        }
        ++callCount;
        if (outputCount > 0U && outputs != nullptr) {
            for (std::uint32_t i = 0U; i < frames; ++i) {
                outputs[0].left[i] = 0.125F;
                outputs[0].right[i] = -0.125F;
            }
        }
        return true;
    }

    std::array<double, 8U> tempos {};
    std::array<double, 8U> quarterNotes {};
    std::array<std::int64_t, 8U> samples {};
    std::array<std::uint32_t, 8U> frameCounts {};
    std::array<std::uint16_t, 8U> numerators {};
    std::array<std::uint16_t, 8U> denominators {};
    std::size_t callCount {0U};
};

std::unique_ptr<silveton::ProcessorGraph> makeGeneratorGraph(ContextProbe& probe) {
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    nodes[0].processors.push_back({&probe, {}});
    auto graph = std::make_unique<silveton::ProcessorGraph>();
    graph->configure(std::move(nodes), {{0U, 1U, 1.0F}}, 1U);
    return graph;
}

void testTempoMapMathAndMeter() {
    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    map.addTempoChange(48000, 60.0);

    requireNear(map.quarterNotesAtSample(0), 0.0, 1.0e-12, "quarter note origin mismatch");
    requireNear(map.quarterNotesAtSample(48000), 2.0, 1.0e-12, "120 BPM segment integral mismatch");
    requireNear(map.quarterNotesAtSample(96000), 3.0, 1.0e-12, "60 BPM segment integral mismatch");
    require(map.sampleAtQuarterNotes(2.5) == 72000, "quarter-note to sample conversion mismatch");
    require(map.nextChangeSampleAfter(0) == 48000, "next tempo change lookup mismatch");

    // At 120 BPM one 4/4 bar is exactly 96000 samples at 48 kHz.
    silveton::TempoMap meterMap;
    meterMap.setSampleRate(48000.0);
    meterMap.setInitialTempo(120.0);
    meterMap.addTempoChange(96000, 60.0);
    meterMap.addTimeSignatureChange(96000, 3U, 4U);
    auto atChange = meterMap.positionAtSample(96000);
    require(atChange.bar == 2 && atChange.beat == 1U, "4/4 to 3/4 bar boundary mismatch");
    require(atChange.numerator == 3U && atChange.denominator == 4U, "time-signature state mismatch");
    requireNear(atChange.quarterNotes, 4.0, 1.0e-12, "time-signature change quarter-note mismatch");
    requireNear(atChange.barStartQuarterNotes, 4.0, 1.0e-12, "bar-start quarter-note mismatch");

    const auto nextBar = meterMap.positionAtSample(240000); // +3 quarter notes at 60 BPM
    require(nextBar.bar == 3 && nextBar.beat == 1U, "3/4 next bar calculation mismatch");

    // 1/4-quarter grid = sixteenth notes. 13000 samples at 120 BPM is nearest 12000.
    silveton::TempoMap snapMap;
    snapMap.setSampleRate(48000.0);
    snapMap.setInitialTempo(120.0);
    require(snapMap.snapSampleToQuarterGrid(13000, 4U) == 12000, "tempo-map snap mismatch");

    bool rejected = false;
    try {
        silveton::TempoMap invalid;
        invalid.setSampleRate(48000.0);
        invalid.addTimeSignatureChange(1000, 3U, 4U);
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "off-bar time-signature change was not rejected");
}

void testTempoMapProjectRoundTrip() {
    const std::string path = "/tmp/silveton_tempo_map_roundtrip.silveton";
    silveton::Project project;
    project.sampleRate = 48000.0;
    project.tempo = 120.0;
    project.tempoMap.setSampleRate(project.sampleRate);
    project.tempoMap.setInitialTempo(120.0);
    project.tempoMap.addTempoChange(96000, 60.0);
    project.tempoMap.addTimeSignatureChange(96000, 3U, 4U);
    project.save(path);

    const silveton::Project loaded = silveton::Project::load(path);
    require(loaded.tempoMap.changes().size() == 1U, "tempo-map project round-trip change count mismatch");
    requireNear(loaded.tempoMap.tempoAtSample(0), 120.0, 1.0e-12, "tempo-map project round-trip initial tempo mismatch");
    requireNear(loaded.tempoMap.tempoAtSample(96000), 60.0, 1.0e-12, "tempo-map project round-trip changed tempo mismatch");
    const auto pos = loaded.tempoMap.positionAtSample(96000);
    require(pos.bar == 2 && pos.beat == 1U, "tempo-map project round-trip bar/beat mismatch");
    require(pos.numerator == 3U && pos.denominator == 4U, "tempo-map project round-trip time signature mismatch");
    std::remove(path.c_str());
}

void testAudioEngineSplitsAtTempoChangeAndPublishesLiveMap() {
    constexpr std::uint32_t frames = 16U;
    ContextProbe probe;
    silveton::AudioEngine engine;

    silveton::TempoMap initial;
    initial.setSampleRate(48000.0);
    initial.setInitialTempo(120.0);
    // Change exactly in the middle of the first callback.
    initial.addTempoChange(8, 90.0);
    engine.setTempoMap(initial);

    auto graph = makeGeneratorGraph(probe);
    engine.setProcessorGraph(graph.get(), 64U);
    engine.prepare({48000.0, frames, 0U, 2U});
    engine.transport().play();

    std::array<float, frames> outL {};
    std::array<float, frames> outR {};
    float* outputs[2] {outL.data(), outR.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);

    require(probe.callCount == 2U, "processor graph was not split at intra-block tempo change");
    require(probe.samples[0] == 0 && probe.samples[1] == 8, "tempo split project-sample mismatch");
    require(probe.frameCounts[0] == 8U && probe.frameCounts[1] == 8U, "tempo split frame count mismatch");
    requireNear(probe.tempos[0], 120.0, 1.0e-12, "first tempo segment mismatch");
    requireNear(probe.tempos[1], 90.0, 1.0e-12, "second tempo segment mismatch");
    require(probe.numerators[0] == 4U && probe.denominators[0] == 4U, "default time signature missing from processor context");
    requireNear(probe.quarterNotes[1], 8.0 * 120.0 / (60.0 * 48000.0), 1.0e-12,
                "intra-block musical position mismatch");
    for (std::uint32_t i = 0U; i < frames; ++i) {
        requireNear(outL[i], 0.125, 1.0e-6, "generator left output discontinuity at tempo split");
        requireNear(outR[i], -0.125, 1.0e-6, "generator right output discontinuity at tempo split");
    }

    silveton::TempoMap replacement;
    replacement.setSampleRate(48000.0);
    replacement.setInitialTempo(77.0);
    const std::uint64_t generation = engine.publishTempoMap(replacement);
    require(engine.tempoMapPublicationPending(), "live tempo-map publication was not pending");
    probe.callCount = 0U;
    engine.processAudio(nullptr, outputs, 0U, 2U, frames);
    require(!engine.tempoMapPublicationPending(), "live tempo-map publication was not adopted");
    require(engine.liveTempoMapGeneration() == generation, "live tempo-map generation mismatch");
    require(probe.callCount == 1U, "constant replacement tempo should process as one segment");
    requireNear(probe.tempos[0], 77.0, 1.0e-12, "live replacement tempo did not reach processor context");
}
}

int main() {
    try {
        testTempoMapMathAndMeter();
        testTempoMapProjectRoundTrip();
        testAudioEngineSplitsAtTempoChangeAndPublishesLiveMap();
        std::cout << "Tempo map tests passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Tempo map tests failed: " << e.what() << '\n';
        return 1;
    }
}
