#include "silveton/AutomationRuntime.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/Vst3Blacklist.h"
#include "silveton/Vst3Runtime.h"
#include "silveton/Vst3ScannerIsolation.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

class DelayProcessor final : public silveton::ITrackProcessor {
public:
    explicit DelayProcessor(std::uint32_t latency) : latency_(latency) {}
    void prepare(double, std::uint32_t maxFrames) override {
        const std::size_t n = static_cast<std::size_t>(latency_) + maxFrames + 1U;
        l_.assign(n, 0.0F); r_.assign(n, 0.0F); write_ = 0U;
    }
    void reset() noexcept override {
        std::fill(l_.begin(), l_.end(), 0.0F); std::fill(r_.begin(), r_.end(), 0.0F); write_ = 0U;
    }
    std::uint32_t latencySamples() const noexcept override { return latency_; }
    void process(float* left, float* right, std::uint32_t frames, const silveton::ProcessorContext&) noexcept override {
        if (latency_ == 0U) return;
        const std::size_t size = l_.size();
        for (std::uint32_t i = 0U; i < frames; ++i) {
            const float inL = left[i], inR = right[i];
            l_[write_] = inL; r_[write_] = inR;
            const std::size_t read = (write_ + size - latency_) % size;
            left[i] = l_[read]; right[i] = r_[read];
            write_ = (write_ + 1U) % size;
        }
    }
private:
    std::uint32_t latency_ {0U};
    std::vector<float> l_, r_;
    std::size_t write_ {0U};
};

class SidechainSumProcessor final : public silveton::IRoutedTrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 2U; }
    std::size_t outputBusCount() const noexcept override { return 1U; }
    bool processBuses(const silveton::ConstStereoBus* inputs,
                      std::size_t inputCount,
                      silveton::StereoBus* outputs,
                      std::size_t outputCount,
                      std::uint32_t frames,
                      const silveton::ProcessorContext&) noexcept override {
        if (inputCount < 2U || outputCount < 1U) return false;
        for (std::uint32_t i = 0U; i < frames; ++i) {
            outputs[0].left[i] = inputs[0].left[i] + inputs[1].left[i];
            outputs[0].right[i] = inputs[0].right[i] + inputs[1].right[i];
        }
        return true;
    }
};

class FourOutputProcessor final : public silveton::IRoutedTrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 1U; }
    std::size_t outputBusCount() const noexcept override { return 4U; }
    bool processBuses(const silveton::ConstStereoBus* inputs,
                      std::size_t inputCount,
                      silveton::StereoBus* outputs,
                      std::size_t outputCount,
                      std::uint32_t frames,
                      const silveton::ProcessorContext&) noexcept override {
        if (inputCount < 1U || outputCount < 4U) return false;
        for (std::size_t b = 0U; b < 4U; ++b) {
            const float g = static_cast<float>(b + 1U);
            for (std::uint32_t i = 0U; i < frames; ++i) {
                outputs[b].left[i] = inputs[0].left[i] * g;
                outputs[b].right[i] = inputs[0].right[i] * g;
            }
        }
        return true;
    }
};


class GeneratorFourOutputProcessor final : public silveton::IRoutedTrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 0U; }
    std::size_t outputBusCount() const noexcept override { return 4U; }
    bool processBuses(const silveton::ConstStereoBus*, std::size_t inputCount,
                      silveton::StereoBus* outputs, std::size_t outputCount,
                      std::uint32_t frames, const silveton::ProcessorContext&) noexcept override {
        if (inputCount != 0U || outputs == nullptr || outputCount < 4U) return false;
        for (std::size_t b = 0U; b < 4U; ++b) {
            const float v = static_cast<float>(b + 1U) * 0.1F;
            for (std::uint32_t i = 0U; i < frames; ++i) {
                outputs[b].left[i] = v;
                outputs[b].right[i] = -v;
            }
        }
        return true;
    }
};

class DelayedTwoOutputProcessor final : public silveton::IRoutedTrackProcessor {
public:
    explicit DelayedTwoOutputProcessor(std::uint32_t latency) : latency_(latency) {}
    void prepare(double, std::uint32_t maxFrames) override {
        const std::size_t n = static_cast<std::size_t>(latency_) + maxFrames + 1U;
        l_.assign(n, 0.0F); r_.assign(n, 0.0F); write_ = 0U;
    }
    void reset() noexcept override { std::fill(l_.begin(),l_.end(),0.0F); std::fill(r_.begin(),r_.end(),0.0F); write_=0U; }
    std::uint32_t latencySamples() const noexcept override { return latency_; }
    void setLatency(std::uint32_t v) noexcept { latency_ = v; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 1U; }
    std::size_t outputBusCount() const noexcept override { return 2U; }
    bool processBuses(const silveton::ConstStereoBus* inputs, std::size_t inputCount,
                      silveton::StereoBus* outputs, std::size_t outputCount,
                      std::uint32_t frames, const silveton::ProcessorContext&) noexcept override {
        if (inputCount < 1U || outputCount < 2U || l_.empty()) return false;
        const std::size_t size = l_.size();
        for (std::uint32_t i=0;i<frames;++i) {
            const float inL = inputs[0].left ? inputs[0].left[i] : 0.0F;
            const float inR = inputs[0].right ? inputs[0].right[i] : inL;
            l_[write_] = inL; r_[write_] = inR;
            const std::size_t read = (write_ + size - latency_) % size;
            const float dl = latency_ == 0U ? inL : l_[read];
            const float dr = latency_ == 0U ? inR : r_[read];
            outputs[0].left[i] = dl; outputs[0].right[i] = dr;
            outputs[1].left[i] = dl * 2.0F; outputs[1].right[i] = dr * 2.0F;
            write_ = (write_ + 1U) % size;
        }
        return true;
    }
private:
    std::uint32_t latency_ {0U};
    std::vector<float> l_, r_;
    std::size_t write_ {0U};
};


std::string tempPath(const char* leaf);

class MockVst3Instance final : public silveton::IVst3PluginInstance {
public:
    MockVst3Instance(std::string module, std::string cls, bool eventInput = true, int* destroyed = nullptr)
        : module_(std::move(module)), class_(std::move(cls)), eventInput_(eventInput), destroyed_(destroyed) { queued_.reserve(128U); }
    ~MockVst3Instance() override { if (destroyed_ != nullptr) ++*destroyed_; }
    const std::string& modulePath() const noexcept override { return module_; }
    const std::string& classId() const noexcept override { return class_; }
    std::size_t inputBusChannelCount(std::size_t bus) const noexcept override { return bus < 2U ? 2U : 0U; }
    std::size_t outputBusChannelCount(std::size_t bus) const noexcept override { return bus < 4U ? 2U : 0U; }
    bool setComponentState(const std::vector<std::uint8_t>& state) override { component_ = state; return true; }
    bool setControllerState(const std::vector<std::uint8_t>& state) override { controller_ = state; return true; }
    std::vector<std::uint8_t> componentState() const override { return component_; }
    std::vector<std::uint8_t> controllerState() const override { return controller_; }
    bool hasEventInput() const noexcept override { return eventInput_; }
    bool queueMidi(const silveton::Vst3MidiEvent&) noexcept override { return eventInput_; }
    bool queueParameter(std::uint32_t parameterId, double normalized, std::int32_t frameOffset) noexcept override {
        if (queued_.size() >= queued_.capacity()) return false;
        queued_.push_back({parameterId, frameOffset, normalized});
        return true;
    }
    bool popAutomationGesture(silveton::AutomationGesture& event) noexcept override {
        if (gestureRead_ >= gestures_.size()) return false;
        event = gestures_[gestureRead_++]; return true;
    }
    bool popOutputParameter(silveton::Vst3OutputParameterChange& change) noexcept override {
        if (outputRead_ >= outputs_.size()) return false;
        change = outputs_[outputRead_++]; return true;
    }
    bool popMidiOutput(silveton::Vst3MidiEvent& event) noexcept override {
        if (midiOutputRead_ >= midiOutputs_.size()) return false;
        event = midiOutputs_[midiOutputRead_++]; return true;
    }
    bool syncControllerParameter(std::uint32_t parameterId, double normalized) override {
        syncedParameterId_ = parameterId; syncedParameterValue_ = normalized; return true;
    }
    std::uint32_t consumeRestartFlags() noexcept override { const auto f = restart_; restart_ = 0U; return f; }
    bool serviceParameterValuesChanged() override { ++parameterValueServices_; return true; }
    int parameterValueServiceCount() const noexcept { return parameterValueServices_; }
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return latency_; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 2U; }
    std::size_t outputBusCount() const noexcept override { return 4U; }
    bool processBuses(const silveton::ConstStereoBus* inputs, std::size_t inputCount,
                      silveton::StereoBus* outputs, std::size_t outputCount,
                      std::uint32_t frames, const silveton::ProcessorContext&) noexcept override {
        if (inputCount == 0U || outputCount == 0U) return false;
        for (std::uint32_t i = 0U; i < frames; ++i) {
            outputs[0].left[i] = inputs[0].left[i]; outputs[0].right[i] = inputs[0].right[i];
        }
        return true;
    }
    void pushGesture(silveton::AutomationGesture e) { gestures_.push_back(e); }
    void pushOutputParameter(silveton::Vst3OutputParameterChange e) { outputs_.push_back(e); }
    void pushMidiOutput(silveton::Vst3MidiEvent e) { midiOutputs_.push_back(e); }
    void setRestart(std::uint32_t f) noexcept { restart_ = f; }
    void setLatency(std::uint32_t l) noexcept { latency_ = l; }
    const std::vector<silveton::Vst3OutputParameterChange>& queued() const noexcept { return queued_; }
    std::uint32_t syncedParameterId() const noexcept { return syncedParameterId_; }
    double syncedParameterValue() const noexcept { return syncedParameterValue_; }
private:
    std::string module_, class_;
    bool eventInput_ {true};
    std::vector<std::uint8_t> component_, controller_;
    std::vector<silveton::Vst3OutputParameterChange> queued_;
    std::vector<silveton::AutomationGesture> gestures_;
    std::vector<silveton::Vst3OutputParameterChange> outputs_;
    std::vector<silveton::Vst3MidiEvent> midiOutputs_;
    std::size_t gestureRead_ {0U}, outputRead_ {0U}, midiOutputRead_ {0U};
    std::uint32_t syncedParameterId_ {0U};
    double syncedParameterValue_ {0.0};
    std::uint32_t restart_ {0U}, latency_ {0U};
    int parameterValueServices_ {0};
    int* destroyed_ {nullptr};
};

class MockFactory final : public silveton::IVst3InstanceFactory {
public:
    std::unique_ptr<silveton::IVst3PluginInstance> create(const std::string& modulePath,
                                                           const std::string& classId,
                                                           std::string& failureReason) override {
        if (modulePath.find("Missing") != std::string::npos) { failureReason = "module missing"; return {}; }
        auto instance = std::make_unique<MockVst3Instance>(modulePath, classId, true, &destroyed);
        lastCreated = instance.get();
        ++created;
        return instance;
    }
    MockVst3Instance* lastCreated {nullptr};
    int created {0};
    int destroyed {0};
};

void testProjectV14RuntimeRestore() {
    silveton::Project p;
    silveton::ProjectTrack track;
    track.name = "VST Track";
    silveton::ProjectPluginSlot slot;
    slot.modulePath = "/Plugins/Good.vst3";
    slot.classId = "GOODCLASS";
    slot.enabled = true;
    slot.latencySnapshot = 32U;
    slot.sidechainSourceNode = 2;
    slot.extraOutputDestinations = {3,4,5};
    slot.midiInputPort = 7;
    slot.componentState = {1U,2U,3U,4U};
    slot.controllerState = {9U,8U,7U};
    silveton::ProjectPluginAutomationLane lane;
    lane.parameterId = 42U;
    lane.mode = silveton::AutomationMode::Touch;
    lane.lane.write(0, 0.1); lane.lane.write(8, 0.8); lane.lane.write(16, 0.4);
    slot.automation.push_back(lane);
    track.pluginSlots.push_back(slot);
    p.tracks.push_back(track);
    silveton::ProjectBus bus;
    bus.name = "FX Bus";
    silveton::ProjectPluginSlot missing = slot;
    missing.modulePath = "/Plugins/Missing.vst3";
    missing.classId = "MISSING";
    missing.midiInputPort = -1;
    bus.pluginSlots.push_back(missing);
    p.buses.push_back(bus);

    const auto path = tempPath("silveton_project_v14_vst3_test.svp");
    p.save(path);
    auto restored = silveton::Project::load(path);
    require(restored.tracks.size() == 1U && restored.buses.size() == 1U, "V14 track/bus state did not round-trip");
    const auto& rs = restored.tracks[0].pluginSlots[0];
    require(rs.modulePath == slot.modulePath && rs.classId == slot.classId, "V14 VST3 identity did not round-trip");
    require(rs.componentState == slot.componentState && rs.controllerState == slot.controllerState, "V14 opaque VST3 state did not round-trip");
    require(rs.sidechainSourceNode == 2 && rs.extraOutputDestinations == slot.extraOutputDestinations, "V14 routed metadata did not round-trip");
    require(rs.midiInputPort == 7, "V14 MIDI destination did not round-trip");
    require(rs.automation.size() == 1U && rs.automation[0].lane.points().size() == 3U, "V14 automation did not round-trip");

    MockFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(restored);
    require(rack.trackSlotStatus(0,0).available, "runtime rack did not create available plugin");
    require(!rack.busSlotStatus(0,0).available, "missing plug-in was not kept unavailable");
    require(restored.buses[0].pluginSlots[0].componentState == missing.componentState, "unavailable slot lost component state");
    require(rack.instanceForMidiPort(7) != nullptr, "VST3 MIDI port was not restored");
    require(factory.lastCreated != nullptr, "mock instance missing");

    // Factory.lastCreated is the bus attempt only when successful; bus is missing, so it still points to track instance.
    auto* live = factory.lastCreated;
    rack.queueAutomationForBlock(0, 16U);
    require(live->queued().size() >= 2U, "automation block did not reach plugin queue");
    require(live->queued()[0].frameOffset == 0 && std::abs(live->queued()[0].normalized - 0.1) < 1e-12, "automation block start value wrong");
    bool foundSample8 = false;
    for (const auto& q : live->queued()) if (q.frameOffset == 8 && q.parameterId == 42U && std::abs(q.normalized - 0.8) < 1e-12) foundSample8 = true;
    require(foundSample8, "sample-accurate automation point at frame 8 was not queued");

    live->pushGesture({silveton::AutomationGestureType::Begin, 42U, 4, 0.0});
    live->pushGesture({silveton::AutomationGestureType::Value, 42U, 4, 0.55});
    live->pushGesture({silveton::AutomationGestureType::End, 42U, 5, 0.0});
    rack.serviceAutomationGestures(0);
    require(std::abs(restored.tracks[0].pluginSlots[0].automation[0].lane.valueAt(4,0.0) - 0.55) < 1e-12,
            "VST3 Touch gesture did not write project automation lane");
    bool queuedGuiValue = false;
    for (const auto& q : live->queued())
        if (q.parameterId == 42U && q.frameOffset == 0 && std::abs(q.normalized - 0.55) < 1e-12) queuedGuiValue = true;
    require(queuedGuiValue, "VST3 GUI edit was not forwarded to processor parameter queue");

    live->pushOutputParameter({99U, 7, 0.66});
    rack.serviceOutputParameters();
    require(std::abs(rack.trackOutputParameterValue(0U, 0U, 99U, -1.0) - 0.66) < 1e-12,
            "plugin-generated output parameter was not stored in DAW runtime state");
    require(live->syncedParameterId() == 99U && std::abs(live->syncedParameterValue() - 0.66) < 1e-12,
            "plugin-generated output parameter was not synchronized to controller state");

    live->pushMidiOutput({5, 0x90U, 64U, 110U});
    silveton::Vst3MidiEvent midiOut {};
    require(rack.popMidiOutputForPort(7, midiOut), "plugin-generated MIDI output was not exposed by runtime rack");
    require(midiOut.frameOffset == 5 && midiOut.status == 0x90U && midiOut.data1 == 64U && midiOut.data2 == 110U,
            "plugin-generated MIDI output changed in runtime routing");

    live->setLatency(512U);
    live->setRestart(silveton::Vst3RestartLatencyChanged | silveton::Vst3RestartIoChanged | silveton::Vst3RestartParamValuesChanged);
    const auto service = rack.serviceRestartFlags();
    require(service.latencyOrIoChanged && service.graphRebuildRequired,
            "VST3 latency/I/O restart did not request graph/PDC rebuild");
    require(service.parameterValuesChanged && live->parameterValueServiceCount() == 1,
            "VST3 kParamValuesChanged was not serviced on the control thread");
    require(restored.tracks[0].pluginSlots[0].latencySnapshot == 512U,
            "dynamic latency was not committed before graph rebuild");

    // Reload is transactional: the old instance must remain alive until the caller publishes
    // a graph that points at the replacement, and the MIDI port must rebind immediately.
    auto* oldInstance = rack.instanceForMidiPort(7);
    const int destroyedBefore = factory.destroyed;
    live->setRestart(silveton::Vst3RestartReloadComponent);
    const auto reload = rack.serviceRestartFlags();
    require(reload.reloadRequested && reload.reloadPerformed && !reload.reloadFailed && reload.graphRebuildRequired,
            "VST3 transactional reload did not complete");
    require(rack.instanceForMidiPort(7) == oldInstance,
            "VST3 MIDI port moved before replacement graph publication");
    require(factory.destroyed == destroyedBefore, "retired VST3 instance was destroyed before graph publication");
    rack.releaseRetiredInstances();
    auto* newInstance = rack.instanceForMidiPort(7);
    require(newInstance != nullptr && newInstance != oldInstance, "VST3 MIDI port did not rebind after replacement graph publication");
    require(factory.destroyed == destroyedBefore + 1, "retired VST3 instance was not released after graph publication");

    rack.captureStateToProject();
    (void)std::remove(path.c_str());
}
std::string tempPath(const char* leaf) {
    const char* base = std::getenv("TMPDIR");
    std::string result = (base != nullptr && *base != '\0') ? base : "/tmp";
    if (!result.empty() && result.back() != '/') result += '/';
    result += leaf;
    return result;
}

void testBlacklist() {
    const std::string path = tempPath("silveton_vst3_blacklist_test.txt");
    (void)std::remove(path.c_str());
    silveton::Vst3Blacklist b;
    b.add("/A/Bad\\Plugin.vst3", "*", "scanner crash\nexit 139");
    b.add("/B/Plugin.vst3", "0123", "invalid\tstate");
    b.save(path);

    silveton::Vst3Blacklist loaded;
    loaded.load(path);
    require(loaded.contains("/A/Bad\\Plugin.vst3", "ANYCLASS"), "wildcard blacklist entry not restored");
    require(loaded.reason("/A/Bad\\Plugin.vst3", "x") == "scanner crash\nexit 139", "blacklist reason escape roundtrip failed");
    require(loaded.contains("/B/Plugin.vst3", "0123"), "class blacklist entry not restored");
    loaded.add("/B/Plugin.vst3", "0123", "updated");
    require(loaded.reason("/B/Plugin.vst3", "0123") == "updated", "blacklist update failed");
    require(loaded.remove("/B/Plugin.vst3", "0123"), "blacklist remove failed");
    require(!loaded.contains("/B/Plugin.vst3", "0123"), "blacklist remove ineffective");
    (void)std::remove(path.c_str());
}

void testAutomation() {
    silveton::ParameterAutomationLane lane;
    lane.write(8, 0.25);
    lane.write(0, 0.0);
    lane.write(16, 1.0);
    lane.write(8, 0.5);
    require(lane.points().size() == 3U, "same-sample automation did not replace point");
    require(std::abs(lane.valueAt(8, 0.0) - 0.5) < 1.0e-12, "automation replacement value wrong");
    require(std::abs(lane.valueAt(12, 0.0) - 0.75) < 1.0e-12, "automation interpolation wrong");

    silveton::ParameterAutomationLane touchLane;
    silveton::AutomationWriter writer;
    writer.setMode(silveton::AutomationMode::Touch);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 1, 0.1}, touchLane);
    require(touchLane.points().empty(), "Touch wrote without gesture");
    writer.apply({silveton::AutomationGestureType::Begin, 1U, 2, 0.0}, touchLane);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 3, 0.4}, touchLane);
    writer.apply({silveton::AutomationGestureType::End, 1U, 4, 0.0}, touchLane);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 5, 0.8}, touchLane);
    require(touchLane.points().size() == 1U && touchLane.points()[0].sample == 3, "Touch gesture semantics wrong");

    silveton::ParameterAutomationLane latchLane;
    writer.setMode(silveton::AutomationMode::Latch);
    writer.apply({silveton::AutomationGestureType::Begin, 1U, 10, 0.0}, latchLane);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 11, 0.2}, latchLane);
    writer.apply({silveton::AutomationGestureType::End, 1U, 12, 0.0}, latchLane);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 13, 0.7}, latchLane);
    require(latchLane.points().size() == 2U, "Latch did not continue after gesture end");
}

void testSidechainPdc() {
    constexpr std::uint32_t frames = 16U;
    DelayProcessor sideDelay(4U);
    SidechainSumProcessor sum;

    std::vector<silveton::GraphNodeDefinition> nodes(3U);
    nodes[0].processors.push_back({&sideDelay, {}});
    silveton::ProcessorRouting routing;
    routing.sidechainSourceNode = 0;
    nodes[1].processors.push_back({&sum, routing});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{1U, 2U, 1.0F}}, 2U);
    graph.prepare(48000.0, frames, 64U);
    require(graph.nodeOutputLatency(0U) == 4U, "sidechain source latency not propagated");
    require(graph.nodeOutputLatency(1U) == 4U, "main path was not aligned to sidechain latency");

    std::array<float, frames> sideL {}, sideR {}, mainL {}, mainR {}, masterL {}, masterR {};
    sideL[0] = sideR[0] = 1.0F;
    mainL[0] = mainR[0] = 1.0F;
    std::array<silveton::ConstStereoBus, 3U> sources {{{sideL.data(), sideR.data()}, {mainL.data(), mainR.data()}, {nullptr, nullptr}}};
    silveton::ProcessorContext context; context.frames = frames; context.playing = true;
    graph.process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, frames, context);

    for (std::size_t i = 0U; i < frames; ++i) {
        const float expected = i == 4U ? 2.0F : 0.0F;
        require(std::abs(masterL[i] - expected) < 1.0e-6F, "sidechain/main inputs were not PDC-aligned before routed processing");
        require(std::abs(masterR[i] - expected) < 1.0e-6F, "right sidechain PDC mismatch");
    }
}

void testMultiOutput() {
    constexpr std::uint32_t frames = 8U;
    FourOutputProcessor proc;
    std::vector<silveton::GraphNodeDefinition> nodes(5U);
    silveton::ProcessorRouting routing;
    routing.extraOutputDestinations = {1, 2, 3};
    nodes[0].processors.push_back({&proc, routing});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U,4U,1.0F},{1U,4U,1.0F},{2U,4U,1.0F},{3U,4U,1.0F}}, 4U);
    graph.prepare(48000.0, frames, 64U);

    std::array<float, frames> inL {}, inR {}, masterL {}, masterR {};
    inL.fill(0.25F); inR.fill(-0.25F);
    std::array<silveton::ConstStereoBus, 5U> sources {{{inL.data(),inR.data()},{nullptr,nullptr},{nullptr,nullptr},{nullptr,nullptr},{nullptr,nullptr}}};
    silveton::ProcessorContext context; context.frames = frames;
    graph.process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, frames, context);
    for (std::size_t i = 0U; i < frames; ++i) {
        require(std::abs(masterL[i] - 2.5F) < 1.0e-6F, "multi-output buses did not reach DAW destinations");
        require(std::abs(masterR[i] + 2.5F) < 1.0e-6F, "multi-output right routing wrong");
    }
}




void testZeroInputMultiOutputInstrument() {
    constexpr std::uint32_t frames = 8U;
    GeneratorFourOutputProcessor instrument;
    std::vector<silveton::GraphNodeDefinition> nodes(5U);
    silveton::ProcessorRouting routing;
    routing.extraOutputDestinations = {1, 2, 3};
    nodes[0].processors.push_back({&instrument, routing});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U,4U,1.0F},{1U,4U,1.0F},{2U,4U,1.0F},{3U,4U,1.0F}}, 4U);
    graph.prepare(48000.0, frames, 64U);

    std::array<silveton::ConstStereoBus,5U> sources {};
    std::array<float,frames> masterL {}, masterR {};
    silveton::ProcessorContext context; context.frames = frames; context.playing = true;
    graph.process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, frames, context);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        // 0.1 main + 0.2 + 0.3 + 0.4 routed outputs.
        require(std::abs(masterL[i] - 1.0F) < 1.0e-6F,
                "zero-input multi-output instrument did not generate/reroute all outputs");
        require(std::abs(masterR[i] + 1.0F) < 1.0e-6F,
                "zero-input multi-output instrument right channel mismatch");
    }
}

void testMultiOutputPdcAndLatencyRefresh() {
    constexpr std::uint32_t frames = 16U;
    DelayedTwoOutputProcessor proc(4U);
    std::vector<silveton::GraphNodeDefinition> nodes(3U);
    silveton::ProcessorRouting routing;
    routing.extraOutputDestinations = {2};
    nodes[0].processors.push_back({&proc, routing});
    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U,2U,1.0F},{1U,2U,1.0F}}, 2U);
    graph.prepare(48000.0, frames, 1024U);
    require(graph.nodeOutputLatency(0U) == 4U && graph.nodeOutputLatency(2U) == 4U,
            "multi-output latency was not propagated through PDC graph");

    std::array<float,frames> aL{},aR{},bL{},bR{},mL{},mR{};
    aL[0]=aR[0]=1.0F; bL[0]=bR[0]=1.0F;
    std::array<silveton::ConstStereoBus,3U> src {{{aL.data(),aR.data()},{bL.data(),bR.data()},{nullptr,nullptr}}};
    silveton::ProcessorContext ctx; ctx.frames=frames;
    graph.process(src.data(),src.size(),{mL.data(),mR.data()},frames,ctx);
    for (std::size_t i=0;i<frames;++i) {
        const float expected = i==4U ? 4.0F : 0.0F; // main(1) + extra(2) + aligned local source(1)
        require(std::abs(mL[i]-expected)<1e-6F && std::abs(mR[i]-expected)<1e-6F,
                "multi-output route was not PDC-aligned with other graph inputs");
    }

    proc.setLatency(8U);
    graph.refreshLatencies();
    require(graph.nodeOutputLatency(0U) == 8U && graph.nodeOutputLatency(2U) == 8U,
            "dynamic processor latency refresh did not update graph PDC");
}

void testMultiOutputCycleRejection() {
    FourOutputProcessor proc;
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    silveton::ProcessorRouting routing;
    routing.extraOutputDestinations = {1};
    nodes[0].processors.push_back({&proc, routing});
    bool rejected=false;
    try {
        silveton::ProcessorGraph graph;
        graph.configure(std::move(nodes), {{1U,0U,1.0F}}, 1U);
    } catch (const std::logic_error& e) { rejected = std::string(e.what()) == "routing cycle"; }
    require(rejected, "hidden multi-output feedback cycle was not rejected");
}

void testScannerIsolation(const std::string& scanner) {
    const std::string blacklistPath = "/tmp/silveton-scanner-isolation-blacklist.txt";
    std::remove(blacklistPath.c_str());
    silveton::Vst3Blacklist blacklist;

    auto ok = silveton::scanVst3ModuleIsolated(scanner, "/tmp/good-fixture.vst3", 1000U, blacklist);
    require(!ok.crashedOrFailed && !ok.timedOut && ok.plugins.size() == 1U, "isolated scanner success path failed");
    require(ok.plugins[0].name == "Fixture\tName", "scanner field escaping failed");

    auto crash = silveton::scanVst3ModuleIsolated(scanner, "/tmp/crash-fixture.vst3", 1000U, blacklist);
    require(crash.crashedOrFailed && blacklist.contains("/tmp/crash-fixture.vst3", "*"), "scanner crash was not blacklisted");
    auto skipped = silveton::scanVst3ModuleIsolated(scanner, "/tmp/crash-fixture.vst3", 1000U, blacklist);
    require(skipped.skippedBlacklisted, "blacklisted scanner module was launched again");

    auto timeout = silveton::scanVst3ModuleIsolated(scanner, "/tmp/timeout-fixture.vst3", 50U, blacklist);
    require(timeout.timedOut && timeout.crashedOrFailed && blacklist.contains("/tmp/timeout-fixture.vst3", "*"), "scanner timeout was not contained/blacklisted");
    blacklist.save(blacklistPath);
    silveton::Vst3Blacklist loaded;
    loaded.load(blacklistPath);
    require(loaded.contains("/tmp/crash-fixture.vst3", "*") && loaded.contains("/tmp/timeout-fixture.vst3", "*"), "scanner blacklist persistence failed");
    std::remove(blacklistPath.c_str());
}

void testCycleRejection() {
    SidechainSumProcessor proc;
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    silveton::ProcessorRouting routing;
    routing.sidechainSourceNode = 1;
    nodes[0].processors.push_back({&proc, routing});
    bool rejected = false;
    try {
        silveton::ProcessorGraph graph;
        graph.configure(std::move(nodes), {{0U,1U,1.0F}}, 1U);
    } catch (const std::logic_error& e) {
        rejected = std::string(e.what()) == "routing cycle";
    }
    require(rejected, "hidden sidechain feedback cycle was not rejected");
}
}

int main(int argc, char** argv) {
    try {
        testBlacklist();
        testAutomation();
        testSidechainPdc();
        testMultiOutput();
        testZeroInputMultiOutputInstrument();
        testMultiOutputPdcAndLatencyRefresh();
        testCycleRejection();
        testMultiOutputCycleRejection();
        testProjectV14RuntimeRestore();
        require(argc == 2, "fake scanner path missing");
        testScannerIsolation(argv[1]);
        std::cout << "PASS: VST3 blacklist persistence\n";
        std::cout << "PASS: automation Write/Touch/Latch primitives\n";
        std::cout << "PASS: real sidechain PDC alignment\n";
        std::cout << "PASS: real multi-output routing + PDC + dynamic latency refresh\n";
        std::cout << "PASS: sidechain and multi-output feedback cycle rejection\n";
        std::cout << "PASS: Project V14 VST3 state + runtime restore + sample-accurate automation\n";
        std::cout << "PASS: isolated scanner crash/timeout containment + blacklist persistence\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
