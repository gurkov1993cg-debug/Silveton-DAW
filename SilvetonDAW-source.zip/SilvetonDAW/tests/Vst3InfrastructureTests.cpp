#include "silveton/AutomationRuntime.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/MixerRouting.h"
#include "silveton/MixerRuntime.h"
#include "silveton/MidiInput.h"
#include "silveton/RealtimeLifecycleGate.h"
#include "silveton/Vst3Blacklist.h"
#include "silveton/Vst3Runtime.h"
#include "silveton/Vst3ScannerIsolation.h"
#include <array>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {
void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

class DelayProcessor final : public silveton::ITrackProcessor {
public:
    explicit DelayProcessor(std::uint32_t latency) : latency_(latency) {}
    void prepare(double, std::uint32_t maxFrames) override {
        const std::size_t n = static_cast<std::size_t>(latency_) + maxFrames + 1U;
        l_.assign(n, 0.0F); r_.assign(n, 0.0F); write_ = 0U;
    }
    void reset() noexcept override {
        std::fill(l_.begin(), l_.end(), 0.0F); std::fill(r_.begin(), r_.end(), 0.0F); write_ = 0U;
    }
    std::uint32_t latencySamples() const noexcept override { return latency_; }
    void process(float* left, float* right, std::uint32_t frames, const silveton::ProcessorContext&) noexcept override {
        if (latency_ == 0U) return;
        const std::size_t size = l_.size();
        for (std::uint32_t i = 0U; i < frames; ++i) {
            const float inL = left[i], inR = right[i];
            l_[write_] = inL; r_[write_] = inR;
            const std::size_t read = (write_ + size - latency_) % size;
            left[i] = l_[read]; right[i] = r_[read];
            write_ = (write_ + 1U) % size;
        }
    }
private:
    std::uint32_t latency_ {0U};
    std::vector<float> l_, r_;
    std::size_t write_ {0U};
};

class SidechainSumProcessor final : public silveton::IRoutedTrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 2U; }
    std::size_t outputBusCount() const noexcept override { return 1U; }
    bool processBuses(const silveton::ConstStereoBus* inputs,
                      std::size_t inputCount,
                      silveton::StereoBus* outputs,
                      std::size_t outputCount,
                      std::uint32_t frames,
                      const silveton::ProcessorContext&) noexcept override {
        if (inputCount < 2U || outputCount < 1U) return false;
        for (std::uint32_t i = 0U; i < frames; ++i) {
            outputs[0].left[i] = inputs[0].left[i] + inputs[1].left[i];
            outputs[0].right[i] = inputs[0].right[i] + inputs[1].right[i];
        }
        return true;
    }
};

class FourOutputProcessor final : public silveton::IRoutedTrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 1U; }
    std::size_t outputBusCount() const noexcept override { return 4U; }
    bool processBuses(const silveton::ConstStereoBus* inputs,
                      std::size_t inputCount,
                      silveton::StereoBus* outputs,
                      std::size_t outputCount,
                      std::uint32_t frames,
                      const silveton::ProcessorContext&) noexcept override {
        if (inputCount < 1U || outputCount < 4U) return false;
        for (std::size_t b = 0U; b < 4U; ++b) {
            const float g = static_cast<float>(b + 1U);
            for (std::uint32_t i = 0U; i < frames; ++i) {
                outputs[b].left[i] = inputs[0].left[i] * g;
                outputs[b].right[i] = inputs[0].right[i] * g;
            }
        }
        return true;
    }
};


class GeneratorFourOutputProcessor final : public silveton::IRoutedTrackProcessor {
public:
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return 0U; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 0U; }
    std::size_t outputBusCount() const noexcept override { return 4U; }
    bool processBuses(const silveton::ConstStereoBus*, std::size_t inputCount,
                      silveton::StereoBus* outputs, std::size_t outputCount,
                      std::uint32_t frames, const silveton::ProcessorContext&) noexcept override {
        if (inputCount != 0U || outputs == nullptr || outputCount < 4U) return false;
        for (std::size_t b = 0U; b < 4U; ++b) {
            const float v = static_cast<float>(b + 1U) * 0.1F;
            for (std::uint32_t i = 0U; i < frames; ++i) {
                outputs[b].left[i] = v;
                outputs[b].right[i] = -v;
            }
        }
        return true;
    }
};

class DelayedTwoOutputProcessor final : public silveton::IRoutedTrackProcessor {
public:
    explicit DelayedTwoOutputProcessor(std::uint32_t latency) : latency_(latency) {}
    void prepare(double, std::uint32_t maxFrames) override {
        const std::size_t n = static_cast<std::size_t>(latency_) + maxFrames + 1U;
        l_.assign(n, 0.0F); r_.assign(n, 0.0F); write_ = 0U;
    }
    void reset() noexcept override { std::fill(l_.begin(),l_.end(),0.0F); std::fill(r_.begin(),r_.end(),0.0F); write_=0U; }
    std::uint32_t latencySamples() const noexcept override { return latency_; }
    void setLatency(std::uint32_t v) noexcept { latency_ = v; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 1U; }
    std::size_t outputBusCount() const noexcept override { return 2U; }
    bool processBuses(const silveton::ConstStereoBus* inputs, std::size_t inputCount,
                      silveton::StereoBus* outputs, std::size_t outputCount,
                      std::uint32_t frames, const silveton::ProcessorContext&) noexcept override {
        if (inputCount < 1U || outputCount < 2U || l_.empty()) return false;
        const std::size_t size = l_.size();
        for (std::uint32_t i=0;i<frames;++i) {
            const float inL = inputs[0].left ? inputs[0].left[i] : 0.0F;
            const float inR = inputs[0].right ? inputs[0].right[i] : inL;
            l_[write_] = inL; r_[write_] = inR;
            const std::size_t read = (write_ + size - latency_) % size;
            const float dl = latency_ == 0U ? inL : l_[read];
            const float dr = latency_ == 0U ? inR : r_[read];
            outputs[0].left[i] = dl; outputs[0].right[i] = dr;
            outputs[1].left[i] = dl * 2.0F; outputs[1].right[i] = dr * 2.0F;
            write_ = (write_ + 1U) % size;
        }
        return true;
    }
private:
    std::uint32_t latency_ {0U};
    std::vector<float> l_, r_;
    std::size_t write_ {0U};
};


std::string tempPath(const char* leaf);

class MockVst3Instance final : public silveton::IVst3PluginInstance {
public:
    MockVst3Instance(std::string module, std::string cls, bool eventInput = true, int* destroyed = nullptr)
        : module_(std::move(module)), class_(std::move(cls)), eventInput_(eventInput), destroyed_(destroyed) { queued_.reserve(128U); }
    ~MockVst3Instance() override { if (destroyed_ != nullptr) ++*destroyed_; }
    const std::string& modulePath() const noexcept override { return module_; }
    const std::string& classId() const noexcept override { return class_; }
    std::size_t inputBusChannelCount(std::size_t bus) const noexcept override { return bus < 2U ? 2U : 0U; }
    std::size_t outputBusChannelCount(std::size_t bus) const noexcept override { return bus < 4U ? 2U : 0U; }
    bool setComponentState(const std::vector<std::uint8_t>& state) override { component_ = state; return true; }
    bool setControllerState(const std::vector<std::uint8_t>& state) override { controller_ = state; return true; }
    std::vector<std::uint8_t> componentState() const override { return component_; }
    std::vector<std::uint8_t> controllerState() const override { return controller_; }
    bool hasEventInput() const noexcept override { return eventInput_; }
    bool queueMidi(const silveton::Vst3MidiEvent& event) noexcept override {
        if (!eventInput_ || midiQueuedCount_ >= midiQueued_.size()) return false;
        midiQueued_[midiQueuedCount_++] = event;
        return true;
    }
    bool queueParameter(std::uint32_t parameterId, double normalized, std::int32_t frameOffset) noexcept override {
        if (queued_.size() >= queued_.capacity()) return false;
        queued_.push_back({parameterId, frameOffset, normalized});
        return true;
    }
    bool popAutomationGesture(silveton::AutomationGesture& event) noexcept override {
        if (gestureRead_ >= gestures_.size()) return false;
        event = gestures_[gestureRead_++]; return true;
    }
    bool popOutputParameter(silveton::Vst3OutputParameterChange& change) noexcept override {
        if (outputRead_ >= outputs_.size()) return false;
        change = outputs_[outputRead_++]; return true;
    }
    bool popMidiOutput(silveton::Vst3MidiEvent& event) noexcept override {
        if (midiOutputRead_ >= midiOutputs_.size()) return false;
        event = midiOutputs_[midiOutputRead_++]; return true;
    }
    bool syncControllerParameter(std::uint32_t parameterId, double normalized) override {
        syncedParameterId_ = parameterId; syncedParameterValue_ = normalized; return true;
    }
    std::uint32_t consumeRestartFlags() noexcept override { const auto f = restart_; restart_ = 0U; return f; }
    bool serviceParameterValuesChanged() override { ++parameterValueServices_; return true; }
    int parameterValueServiceCount() const noexcept { return parameterValueServices_; }
    void prepare(double, std::uint32_t) override {}
    void reset() noexcept override {}
    std::uint32_t latencySamples() const noexcept override { return latency_; }
    void process(float*, float*, std::uint32_t, const silveton::ProcessorContext&) noexcept override {}
    std::size_t inputBusCount() const noexcept override { return 2U; }
    std::size_t outputBusCount() const noexcept override { return 4U; }
    bool processBuses(const silveton::ConstStereoBus* inputs, std::size_t inputCount,
                      silveton::StereoBus* outputs, std::size_t outputCount,
                      std::uint32_t frames, const silveton::ProcessorContext&) noexcept override {
        if (inputCount == 0U || outputCount == 0U) return false;
        for (std::uint32_t i = 0U; i < frames; ++i) {
            outputs[0].left[i] = inputs[0].left[i]; outputs[0].right[i] = inputs[0].right[i];
        }
        return true;
    }
    void pushGesture(silveton::AutomationGesture e) { gestures_.push_back(e); }
    void pushOutputParameter(silveton::Vst3OutputParameterChange e) { outputs_.push_back(e); }
    void pushMidiOutput(silveton::Vst3MidiEvent e) { midiOutputs_.push_back(e); }
    void setRestart(std::uint32_t f) noexcept { restart_ = f; }
    void setLatency(std::uint32_t l) noexcept { latency_ = l; }
    const std::vector<silveton::Vst3OutputParameterChange>& queued() const noexcept { return queued_; }
    std::size_t midiQueuedCount() const noexcept { return midiQueuedCount_; }
    const silveton::Vst3MidiEvent& midiQueued(std::size_t index) const { return midiQueued_.at(index); }
    std::uint32_t syncedParameterId() const noexcept { return syncedParameterId_; }
    double syncedParameterValue() const noexcept { return syncedParameterValue_; }
private:
    std::string module_, class_;
    bool eventInput_ {true};
    std::vector<std::uint8_t> component_, controller_;
    std::vector<silveton::Vst3OutputParameterChange> queued_;
    std::vector<silveton::AutomationGesture> gestures_;
    std::vector<silveton::Vst3OutputParameterChange> outputs_;
    std::vector<silveton::Vst3MidiEvent> midiOutputs_;
    std::array<silveton::Vst3MidiEvent, 128U> midiQueued_ {};
    std::size_t midiQueuedCount_ {0U};
    std::size_t gestureRead_ {0U}, outputRead_ {0U}, midiOutputRead_ {0U};
    std::uint32_t syncedParameterId_ {0U};
    double syncedParameterValue_ {0.0};
    std::uint32_t restart_ {0U}, latency_ {0U};
    int parameterValueServices_ {0};
    int* destroyed_ {nullptr};
};

class MockFactory final : public silveton::IVst3InstanceFactory {
public:
    std::unique_ptr<silveton::IVst3PluginInstance> create(const std::string& modulePath,
                                                           const std::string& classId,
                                                           std::string& failureReason) override {
        if (modulePath.find("Missing") != std::string::npos) { failureReason = "module missing"; return {}; }
        auto instance = std::make_unique<MockVst3Instance>(modulePath, classId, true, &destroyed);
        lastCreated = instance.get();
        ++created;
        return instance;
    }
    MockVst3Instance* lastCreated {nullptr};
    int created {0};
    int destroyed {0};
};

void testProjectV14RuntimeRestore() {
    silveton::Project p;
    silveton::ProjectTrack track;
    track.name = "VST Track";
    silveton::ProjectPluginSlot slot;
    slot.modulePath = "/Plugins/Good.vst3";
    slot.classId = "GOODCLASS";
    slot.enabled = true;
    slot.latencySnapshot = 32U;
    slot.sidechainSourceNode = 2;
    slot.extraOutputDestinations = {3,4,5};
    slot.midiInputPort = 7;
    slot.componentState = {1U,2U,3U,4U};
    slot.controllerState = {9U,8U,7U};
    silveton::ProjectPluginAutomationLane lane;
    lane.parameterId = 42U;
    lane.mode = silveton::AutomationMode::Touch;
    lane.lane.write(0, 0.1); lane.lane.write(8, 0.8); lane.lane.write(16, 0.4);
    slot.automation.push_back(lane);
    track.pluginSlots.push_back(slot);
    track.outputBus = 0;
    silveton::ProjectSend send;
    send.destinationBus = 0;
    send.gainDb = -6.0F;
    send.enabled = true;
    send.preFader = true;
    send.gainAutomationMode = silveton::AutomationMode::Touch;
    send.gainAutomationDb.add(0, -3.0F);
    send.gainAutomationDb.add(16, -9.0F);
    send.enabledAutomationMode = silveton::AutomationMode::Read;
    send.enabledAutomation.add(4, 0.0F);
    send.enabledAutomation.add(12, 1.0F);
    track.sends.push_back(send);
    track.gainAutomationMode = silveton::AutomationMode::Read;
    track.gainAutomationDb.add(0, 0.0F);
    track.gainAutomationDb.add(16, -6.0F);
    track.panAutomationMode = silveton::AutomationMode::Read;
    track.panAutomation.add(0, -1.0F);
    track.panAutomation.add(16, 1.0F);
    track.muteAutomationMode = silveton::AutomationMode::Read;
    track.muteAutomation.add(8, 1.0F);
    track.muteAutomation.add(12, 0.0F);
    p.tracks.push_back(track);
    silveton::ProjectBus bus;
    bus.name = "FX Bus";
    bus.kind = silveton::ProjectBusKind::FxReturn;
    bus.gainDb = -3.0F;
    bus.outputBus = -1;
    bus.gainAutomationMode = silveton::AutomationMode::Read;
    bus.gainAutomationDb.add(0, -3.0F);
    bus.gainAutomationDb.add(16, 0.0F);
    bus.muteAutomationMode = silveton::AutomationMode::Read;
    bus.muteAutomation.add(10, 1.0F);
    bus.muteAutomation.add(14, 0.0F);
    silveton::ProjectPluginSlot missing = slot;
    missing.modulePath = "/Plugins/Missing.vst3";
    missing.classId = "MISSING";
    missing.midiInputPort = -1;
    bus.pluginSlots.push_back(missing);
    p.buses.push_back(bus);
    silveton::ProjectPluginSlot masterSlot = slot;
    masterSlot.modulePath = "/Plugins/Master.vst3";
    masterSlot.classId = "MASTER";
    masterSlot.midiInputPort = -1;
    masterSlot.sidechainSourceNode = -1;
    masterSlot.extraOutputDestinations.clear();
    p.masterPluginSlots.push_back(masterSlot);
    p.masterFaderAutomationMode = silveton::AutomationMode::Read;
    p.masterFaderAutomationDb.add(0, 0.0F);
    p.masterFaderAutomationDb.add(16, -3.0F);

    const auto path = tempPath("silveton_project_v14_vst3_test.svp");
    p.save(path);
    auto restored = silveton::Project::load(path);
    require(restored.tracks.size() == 1U && restored.buses.size() == 1U, "V15 track/bus state did not round-trip");
    require(restored.tracks[0].outputBus == 0 && restored.tracks[0].sends.size() == 1U, "V15 track routing did not round-trip");
    require(restored.buses[0].kind == silveton::ProjectBusKind::FxReturn && std::abs(restored.buses[0].gainDb + 3.0F) < 1.0e-6F, "V15 bus state did not round-trip");
    require(restored.masterPluginSlots.size() == 1U && restored.masterPluginSlots[0].classId == "MASTER", "V16 master insert state did not round-trip");
    require(restored.tracks[0].sends[0].preFader, "V16 pre-fader send state did not round-trip");
    require(restored.tracks[0].sends[0].gainAutomationDb.points().size() == 2U &&
            restored.tracks[0].sends[0].enabledAutomation.points().size() == 2U,
            "V16 send automation did not round-trip");
    require(restored.tracks[0].gainAutomationDb.points().size() == 2U &&
            restored.tracks[0].panAutomation.points().size() == 2U &&
            restored.tracks[0].muteAutomation.points().size() == 2U,
            "V16 track mixer automation did not round-trip");
    require(restored.buses[0].gainAutomationDb.points().size() == 2U &&
            restored.buses[0].muteAutomation.points().size() == 2U,
            "V16 bus mixer automation did not round-trip");
    require(restored.masterFaderAutomationDb.points().size() == 2U,
            "V16 master fader automation did not round-trip");
    const auto& rs = restored.tracks[0].pluginSlots[0];
    require(rs.modulePath == slot.modulePath && rs.classId == slot.classId, "V14 VST3 identity did not round-trip");
    require(rs.componentState == slot.componentState && rs.controllerState == slot.controllerState, "V14 opaque VST3 state did not round-trip");
    require(rs.sidechainSourceNode == 2 && rs.extraOutputDestinations == slot.extraOutputDestinations, "V14 routed metadata did not round-trip");
    require(rs.midiInputPort == 7, "V14 MIDI destination did not round-trip");
    require(rs.automation.size() == 1U && rs.automation[0].lane.points().size() == 3U, "V14 automation did not round-trip");

    MockFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(restored);
    require(rack.trackSlotStatus(0,0).available, "runtime rack did not create available plugin");
    require(!rack.busSlotStatus(0,0).available, "missing plug-in was not kept unavailable");
    require(rack.masterSlotCount() == 1U && rack.masterSlotStatus(0U).available, "master insert chain was not restored");
    require(restored.buses[0].pluginSlots[0].componentState == missing.componentState, "unavailable slot lost component state");
    require(rack.instanceForMidiPort(7) != nullptr, "VST3 MIDI port was not restored");
    require(factory.lastCreated != nullptr, "mock instance missing");

    // The project now has a real Master insert chain, so the last factory-created
    // instance is no longer necessarily the track plug-in. Resolve the track
    // instance through its actual MIDI binding instead of relying on creation order.
    auto* live = dynamic_cast<MockVst3Instance*>(rack.instanceForMidiPort(7));
    require(live != nullptr, "track VST3 instance was not resolved from MIDI port");
    rack.queueAutomationForBlock(0, 16U);
    require(live->queued().size() >= 2U, "automation block did not reach plugin queue");
    require(live->queued()[0].frameOffset == 0 && std::abs(live->queued()[0].normalized - 0.1) < 1e-12, "automation block start value wrong");
    bool foundSample8 = false;
    for (const auto& q : live->queued()) if (q.frameOffset == 8 && q.parameterId == 42U && std::abs(q.normalized - 0.8) < 1e-12) foundSample8 = true;
    require(foundSample8, "sample-accurate automation point at frame 8 was not queued");

    live->pushGesture({silveton::AutomationGestureType::Begin, 42U, 4, 0.0});
    live->pushGesture({silveton::AutomationGestureType::Value, 42U, 4, 0.55});
    live->pushGesture({silveton::AutomationGestureType::End, 42U, 5, 0.0});
    rack.serviceAutomationGestures(0);
    require(std::abs(restored.tracks[0].pluginSlots[0].automation[0].lane.valueAt(4,0.0) - 0.55) < 1e-12,
            "VST3 Touch gesture did not write project automation lane");
    bool queuedGuiValue = false;
    for (const auto& q : live->queued())
        if (q.parameterId == 42U && q.frameOffset == 0 && std::abs(q.normalized - 0.55) < 1e-12) queuedGuiValue = true;
    require(queuedGuiValue, "VST3 GUI edit was not forwarded to processor parameter queue");

    live->pushOutputParameter({99U, 7, 0.66});
    rack.serviceOutputParameters();
    require(std::abs(rack.trackOutputParameterValue(0U, 0U, 99U, -1.0) - 0.66) < 1e-12,
            "plugin-generated output parameter was not stored in DAW runtime state");
    require(live->syncedParameterId() == 99U && std::abs(live->syncedParameterValue() - 0.66) < 1e-12,
            "plugin-generated output parameter was not synchronized to controller state");

    live->pushMidiOutput({5, 0x90U, 64U, 110U});
    silveton::Vst3MidiEvent midiOut {};
    require(rack.popMidiOutputForPort(7, midiOut), "plugin-generated MIDI output was not exposed by runtime rack");
    require(midiOut.frameOffset == 5 && midiOut.status == 0x90U && midiOut.data1 == 64U && midiOut.data2 == 110U,
            "plugin-generated MIDI output changed in runtime routing");

    live->setLatency(512U);
    live->setRestart(silveton::Vst3RestartLatencyChanged | silveton::Vst3RestartIoChanged | silveton::Vst3RestartParamValuesChanged);
    const auto service = rack.serviceRestartFlags();
    require(service.latencyOrIoChanged && service.graphRebuildRequired,
            "VST3 latency/I/O restart did not request graph/PDC rebuild");
    require(service.parameterValuesChanged && live->parameterValueServiceCount() == 1,
            "VST3 kParamValuesChanged was not serviced on the control thread");
    require(restored.tracks[0].pluginSlots[0].latencySnapshot == 512U,
            "dynamic latency was not committed before graph rebuild");

    // Reload is transactional: the old instance must remain alive until the caller publishes
    // a graph that points at the replacement, and the MIDI port must rebind immediately.
    auto* oldInstance = rack.instanceForMidiPort(7);
    const int destroyedBefore = factory.destroyed;
    live->setRestart(silveton::Vst3RestartReloadComponent);
    const auto reload = rack.serviceRestartFlags();
    require(reload.reloadRequested && reload.reloadPerformed && !reload.reloadFailed && reload.graphRebuildRequired,
            "VST3 transactional reload did not complete");
    require(rack.instanceForMidiPort(7) == oldInstance,
            "VST3 MIDI port moved before replacement graph publication");
    require(factory.destroyed == destroyedBefore, "retired VST3 instance was destroyed before graph publication");
    // Simulate the audio-block boundary that adopts the already-built MIDI map
    // at the same point where the replacement processor graph becomes live.
    rack.adoptPublicationStateAtBlockBoundary();
    rack.releaseRetiredInstances();
    auto* newInstance = rack.instanceForMidiPort(7);
    require(newInstance != nullptr && newInstance != oldInstance, "VST3 MIDI port did not rebind after replacement graph publication");
    require(factory.destroyed == destroyedBefore + 1, "retired VST3 instance was not released after graph publication");

    rack.captureStateToProject();
    (void)std::remove(path.c_str());
}


void testMixerRuntimeCoordinatorServicesVst3Rebuilds() {
    silveton::Project project;
    silveton::ProjectTrack track;
    silveton::ProjectPluginSlot slot;
    slot.modulePath = "/Plugins/Live.vst3";
    slot.classId = "LIVE";
    slot.midiInputPort = 7;
    track.pluginSlots.push_back(slot);
    project.tracks.push_back(track);

    MockFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(project);
    auto initialGraph = silveton::MixerRoutingBuilder::build(project, rack);

    silveton::AudioEngine engine;
    engine.setProcessorGraph(initialGraph.get(), 512U);
    engine.prepare({48000.0, 16U, 0U, 2U});
    silveton::MixerRuntimeCoordinator coordinator(project, rack, engine, 512U);

    auto* live = dynamic_cast<MockVst3Instance*>(rack.instanceForMidiPort(7));
    require(live != nullptr, "coordinator test live VST3 instance missing");
    live->setLatency(64U);
    live->setRestart(silveton::Vst3RestartLatencyChanged);
    const auto latencyUpdate = coordinator.serviceVst3Changes();
    require(latencyUpdate.vst3.graphRebuildRequired && latencyUpdate.graphPublished,
            "latency restart did not publish replacement mixer graph");
    require(engine.processorGraphPublicationPending(),
            "coordinator latency replacement was not pending for block-boundary adoption");

    std::array<float,16> outL {}, outR {};
    float* outputs[2] {outL.data(), outR.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, 16U);
    require(engine.liveProcessorGraphGeneration() == latencyUpdate.graphGeneration,
            "coordinator latency graph did not become live");
    require(engine.processorGraph()->nodeOutputLatency(0U) == 64U,
            "coordinator did not rebuild PDC from new plug-in latency");
    require(coordinator.reclaimRetired() == 1U,
            "coordinator did not reclaim predecessor latency graph");

    auto* oldInstance = rack.instanceForMidiPort(7);
    const int destroyedBefore = factory.destroyed;
    live->setRestart(silveton::Vst3RestartReloadComponent);
    const auto reload = coordinator.serviceVst3Changes();
    require(reload.vst3.reloadPerformed && reload.graphPublished,
            "transactional reload did not publish replacement graph through coordinator");
    require(rack.instanceForMidiPort(7) == oldInstance,
            "MIDI binding moved before reload graph adoption");
    require(factory.destroyed == destroyedBefore,
            "old VST3 instance was destroyed before reload graph adoption");

    engine.adoptPendingRealtimeStateAtBlockBoundary();
    rack.adoptPublicationStateAtBlockBoundary();
    engine.processAudio(nullptr, outputs, 0U, 2U, 16U);
    require(coordinator.reclaimRetired() == 1U,
            "reload predecessor graph was not reclaimed");
    require(factory.destroyed == destroyedBefore + 1,
            "old VST3 instance was not released after safe graph reclamation");
    require(rack.instanceForMidiPort(7) != nullptr && rack.instanceForMidiPort(7) != oldInstance,
            "MIDI binding did not move to replacement instance after safe reclamation");
}

void testMixerRuntimeCoordinatorSafelyReplacesPluginTopology() {
    silveton::Project project;
    silveton::ProjectTrack track;
    silveton::ProjectPluginSlot slot;
    slot.modulePath = "/Plugins/Topology.vst3";
    slot.classId = "OLD";
    slot.midiInputPort = 7;
    track.pluginSlots.push_back(slot);
    project.tracks.push_back(track);

    MockFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(project);
    auto initialGraph = silveton::MixerRoutingBuilder::build(project, rack);

    auto* oldInstance = rack.instanceForMidiPort(7);
    require(oldInstance != nullptr && oldInstance->classId() == "OLD",
            "initial topology VST3 instance missing");

    silveton::AudioEngine engine;
    engine.setProcessorGraph(initialGraph.get(), 512U);
    engine.prepare({48000.0, 16U, 0U, 2U});
    silveton::MixerRuntimeCoordinator coordinator(project, rack, engine, 512U);

    const int destroyedBefore = factory.destroyed;
    project.tracks[0].pluginSlots[0].classId = "NEW";
    const std::uint64_t replacementGeneration = coordinator.publishProjectTopology();
    auto* stagedReplacement = factory.lastCreated;
    require(stagedReplacement != nullptr && stagedReplacement != oldInstance && stagedReplacement->classId() == "NEW",
            "replacement topology VST3 instance was not staged");
    require(engine.processorGraphPublicationPending(),
            "replacement topology graph was not pending for block-boundary adoption");
    require(rack.instanceForMidiPort(7) == oldInstance,
            "MIDI port moved before topology graph adoption");
    require(factory.destroyed == destroyedBefore,
            "old VST3 instance was destroyed before topology graph adoption");
    require(engine.processorGraph()->containsProcessor(oldInstance),
            "live graph stopped referencing old VST3 before block-boundary adoption");

    std::array<float,16> outL {}, outR {};
    float* outputs[2] {outL.data(), outR.data()};
    engine.adoptPendingRealtimeStateAtBlockBoundary();
    rack.adoptPublicationStateAtBlockBoundary();
    engine.processAudio(nullptr, outputs, 0U, 2U, 16U);
    require(engine.liveProcessorGraphGeneration() == replacementGeneration,
            "replacement topology graph did not become live at block boundary");
    require(engine.processorGraph()->containsProcessor(stagedReplacement),
            "live graph did not switch to replacement VST3 instance");
    require(factory.destroyed == destroyedBefore,
            "old VST3 instance was destroyed before predecessor graph reclamation");

    require(coordinator.reclaimRetired() == 1U,
            "predecessor topology graph was not reclaimed");
    require(factory.destroyed == destroyedBefore + 1,
            "old VST3 instance was not released after safe topology reclamation");
    require(rack.instanceForMidiPort(7) == stagedReplacement,
            "MIDI port did not rebind after topology graph reclamation");

    // Exercise vector-invalidating topology removal too. The current runtime
    // state's ProjectPluginSlot pointer becomes invalid immediately after clear(),
    // so the staged publication path must not dereference it before retiring the
    // live instance.
    const int destroyedBeforeRemove = factory.destroyed;
    project.tracks[0].pluginSlots.clear();
    const std::uint64_t removalGeneration = coordinator.publishProjectTopology();
    require(engine.processorGraphPublicationPending(),
            "plug-in removal graph was not pending for block-boundary adoption");
    require(rack.instanceForMidiPort(7) == stagedReplacement,
            "MIDI port moved before removal graph adoption");
    require(factory.destroyed == destroyedBeforeRemove,
            "removed VST3 instance was destroyed before removal graph adoption");

    engine.adoptPendingRealtimeStateAtBlockBoundary();
    rack.adoptPublicationStateAtBlockBoundary();
    engine.processAudio(nullptr, outputs, 0U, 2U, 16U);
    require(engine.liveProcessorGraphGeneration() == removalGeneration,
            "plug-in removal graph did not become live");
    require(!engine.processorGraph()->containsProcessor(stagedReplacement),
            "removed VST3 instance remained in live graph");
    require(coordinator.reclaimRetired() == 1U,
            "plug-in removal predecessor graph was not reclaimed");
    require(factory.destroyed == destroyedBeforeRemove + 1,
            "removed VST3 instance was not released after safe reclamation");
    require(rack.instanceForMidiPort(7) == nullptr,
            "removed VST3 MIDI binding remained after safe reclamation");
}

void testProjectMixerRoutingBuilder() {
    silveton::Project project;
    silveton::ProjectTrack track;
    track.name = "Vocal";
    track.outputBus = 0;
    track.sends.push_back({1, -6.0205999F, true});
    project.tracks.push_back(track);

    silveton::ProjectBus group;
    group.name = "Vocal Group";
    group.kind = silveton::ProjectBusKind::Group;
    group.gainDb = -6.0205999F;
    group.outputBus = -1;
    project.buses.push_back(group);

    silveton::ProjectBus reverb;
    reverb.name = "Reverb Return";
    reverb.kind = silveton::ProjectBusKind::FxReturn;
    reverb.gainDb = 0.0F;
    reverb.outputBus = -1;
    project.buses.push_back(reverb);

    silveton::ProjectPluginSlot master;
    master.modulePath = "/Plugins/Master.vst3";
    master.classId = "MASTER";
    project.masterPluginSlots.push_back(master);

    MockFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(project);
    require(rack.masterSlotCount() == 1U, "master insert was not represented by runtime rack");
    auto* masterInstance = dynamic_cast<MockVst3Instance*>(factory.lastCreated);
    require(masterInstance != nullptr, "master mock instance missing");
    masterInstance->setLatency(7U);

    auto graph = silveton::MixerRoutingBuilder::build(project, rack);
    const auto layout = silveton::MixerRoutingBuilder::layout(project);
    require(layout.nodeCount() == 4U && layout.masterNode() == 3U,
            "mixer graph node layout is wrong");
    graph->prepare(48000.0, 16U, 64U);
    require(graph->nodeOutputLatency(layout.masterNode()) == 7U,
            "master insert latency was not included in mixer graph PDC");

    std::array<float,16> trackL {}, trackR {}, groupL {}, groupR {}, fxL {}, fxR {}, masterL {}, masterR {};
    trackL.fill(1.0F); trackR.fill(1.0F);
    std::array<silveton::ConstStereoBus,4> sources {{
        {trackL.data(), trackR.data()},
        {groupL.data(), groupR.data()},
        {fxL.data(), fxR.data()},
        {nullptr, nullptr}
    }};
    silveton::ProcessorContext context;
    context.sampleRate = 48000.0; context.frames = 16U; context.playing = true;
    graph->process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, 16U, context);
    for (std::size_t i = 0U; i < masterL.size(); ++i)
        require(std::abs(masterL[i] - 1.0F) < 2.0e-5F && std::abs(masterR[i] - 1.0F) < 2.0e-5F,
                "group + FX send did not sum through master correctly");

    project.buses[0].mute = true;
    auto mutedGraph = silveton::MixerRoutingBuilder::build(project, rack);
    mutedGraph->prepare(48000.0, 16U, 64U);
    masterL.fill(0.0F); masterR.fill(0.0F);
    mutedGraph->process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, 16U, context);
    for (std::size_t i = 0U; i < masterL.size(); ++i)
        require(std::abs(masterL[i] - 0.5F) < 2.0e-5F,
                "bus mute did not remove the group path while preserving FX send");

    project.buses[0].mute = false;
    project.buses[0].outputBus = 1;
    project.buses[1].outputBus = 0;
    bool cycleRejected = false;
    try { (void)silveton::MixerRoutingBuilder::build(project, rack); }
    catch (const std::logic_error&) { cycleRejected = true; }
    require(cycleRejected, "mixer bus routing cycle was not rejected");
}

std::string tempPath(const char* leaf) {
    const char* base = std::getenv("TMPDIR");
    std::string result = (base != nullptr && *base != '\0') ? base : "/tmp";
    if (!result.empty() && result.back() != '/') result += '/';
    result += leaf;
    return result;
}

void testBlacklist() {
    const std::string path = tempPath("silveton_vst3_blacklist_test.txt");
    (void)std::remove(path.c_str());
    silveton::Vst3Blacklist b;
    b.add("/A/Bad\\Plugin.vst3", "*", "scanner crash\nexit 139");
    b.add("/B/Plugin.vst3", "0123", "invalid\tstate");
    b.save(path);

    silveton::Vst3Blacklist loaded;
    loaded.load(path);
    require(loaded.contains("/A/Bad\\Plugin.vst3", "ANYCLASS"), "wildcard blacklist entry not restored");
    require(loaded.reason("/A/Bad\\Plugin.vst3", "x") == "scanner crash\nexit 139", "blacklist reason escape roundtrip failed");
    require(loaded.contains("/B/Plugin.vst3", "0123"), "class blacklist entry not restored");
    loaded.add("/B/Plugin.vst3", "0123", "updated");
    require(loaded.reason("/B/Plugin.vst3", "0123") == "updated", "blacklist update failed");
    require(loaded.remove("/B/Plugin.vst3", "0123"), "blacklist remove failed");
    require(!loaded.contains("/B/Plugin.vst3", "0123"), "blacklist remove ineffective");
    (void)std::remove(path.c_str());
}

void testAutomation() {
    silveton::ParameterAutomationLane lane;
    lane.write(8, 0.25);
    lane.write(0, 0.0);
    lane.write(16, 1.0);
    lane.write(8, 0.5);
    require(lane.points().size() == 3U, "same-sample automation did not replace point");
    require(std::abs(lane.valueAt(8, 0.0) - 0.5) < 1.0e-12, "automation replacement value wrong");
    require(std::abs(lane.valueAt(12, 0.0) - 0.75) < 1.0e-12, "automation interpolation wrong");

    silveton::ParameterAutomationLane touchLane;
    silveton::AutomationWriter writer;
    writer.setMode(silveton::AutomationMode::Touch);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 1, 0.1}, touchLane);
    require(touchLane.points().empty(), "Touch wrote without gesture");
    writer.apply({silveton::AutomationGestureType::Begin, 1U, 2, 0.0}, touchLane);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 3, 0.4}, touchLane);
    writer.apply({silveton::AutomationGestureType::End, 1U, 4, 0.0}, touchLane);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 5, 0.8}, touchLane);
    require(touchLane.points().size() == 1U && touchLane.points()[0].sample == 3, "Touch gesture semantics wrong");

    silveton::ParameterAutomationLane latchLane;
    writer.setMode(silveton::AutomationMode::Latch);
    writer.apply({silveton::AutomationGestureType::Begin, 1U, 10, 0.0}, latchLane);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 11, 0.2}, latchLane);
    writer.apply({silveton::AutomationGestureType::End, 1U, 12, 0.0}, latchLane);
    writer.apply({silveton::AutomationGestureType::Value, 1U, 13, 0.7}, latchLane);
    require(latchLane.points().size() == 2U, "Latch did not continue after gesture end");

    silveton::AutomationLane mixerLane;
    writer.setMode(silveton::AutomationMode::Touch);
    writer.apply(silveton::AutomationGestureType::Value, 1, -3.0F, mixerLane);
    require(mixerLane.points().empty(), "mixer Touch wrote without gesture");
    writer.apply(silveton::AutomationGestureType::Begin, 2, 0.0F, mixerLane);
    writer.apply(silveton::AutomationGestureType::Value, 3, -6.0F, mixerLane);
    writer.apply(silveton::AutomationGestureType::End, 4, 0.0F, mixerLane);
    require(mixerLane.points().size() == 1U && std::abs(mixerLane.points()[0].value + 6.0F) < 1.0e-6F,
            "natural-unit mixer automation writer failed");

    silveton::AutomationLane switchLane;
    switchLane.add(4, 1.0F);
    switchLane.add(8, 0.0F);
    require(switchLane.stepValueAt(3, 0.0F) == 0.0F && switchLane.stepValueAt(4, 0.0F) == 1.0F &&
            switchLane.stepValueAt(7, 0.0F) == 1.0F && switchLane.stepValueAt(8, 1.0F) == 0.0F,
            "stepped mute/on-off automation semantics failed");
}

void testSidechainPdc() {
    constexpr std::uint32_t frames = 16U;
    DelayProcessor sideDelay(4U);
    SidechainSumProcessor sum;

    std::vector<silveton::GraphNodeDefinition> nodes(3U);
    nodes[0].processors.push_back({&sideDelay, {}});
    silveton::ProcessorRouting routing;
    routing.sidechainSourceNode = 0;
    nodes[1].processors.push_back({&sum, routing});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{1U, 2U, 1.0F}}, 2U);
    graph.prepare(48000.0, frames, 64U);
    require(graph.nodeOutputLatency(0U) == 4U, "sidechain source latency not propagated");
    require(graph.nodeOutputLatency(1U) == 4U, "main path was not aligned to sidechain latency");

    std::array<float, frames> sideL {}, sideR {}, mainL {}, mainR {}, masterL {}, masterR {};
    sideL[0] = sideR[0] = 1.0F;
    mainL[0] = mainR[0] = 1.0F;
    std::array<silveton::ConstStereoBus, 3U> sources {{{sideL.data(), sideR.data()}, {mainL.data(), mainR.data()}, {nullptr, nullptr}}};
    silveton::ProcessorContext context; context.frames = frames; context.playing = true;
    graph.process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, frames, context);

    for (std::size_t i = 0U; i < frames; ++i) {
        const float expected = i == 4U ? 2.0F : 0.0F;
        require(std::abs(masterL[i] - expected) < 1.0e-6F, "sidechain/main inputs were not PDC-aligned before routed processing");
        require(std::abs(masterR[i] - expected) < 1.0e-6F, "right sidechain PDC mismatch");
    }
}

void testMultiOutput() {
    constexpr std::uint32_t frames = 8U;
    FourOutputProcessor proc;
    std::vector<silveton::GraphNodeDefinition> nodes(5U);
    silveton::ProcessorRouting routing;
    routing.extraOutputDestinations = {1, 2, 3};
    nodes[0].processors.push_back({&proc, routing});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U,4U,1.0F},{1U,4U,1.0F},{2U,4U,1.0F},{3U,4U,1.0F}}, 4U);
    graph.prepare(48000.0, frames, 64U);

    std::array<float, frames> inL {}, inR {}, masterL {}, masterR {};
    inL.fill(0.25F); inR.fill(-0.25F);
    std::array<silveton::ConstStereoBus, 5U> sources {{{inL.data(),inR.data()},{nullptr,nullptr},{nullptr,nullptr},{nullptr,nullptr},{nullptr,nullptr}}};
    silveton::ProcessorContext context; context.frames = frames;
    graph.process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, frames, context);
    for (std::size_t i = 0U; i < frames; ++i) {
        require(std::abs(masterL[i] - 2.5F) < 1.0e-6F, "multi-output buses did not reach DAW destinations");
        require(std::abs(masterR[i] + 2.5F) < 1.0e-6F, "multi-output right routing wrong");
    }
}




void testZeroInputMultiOutputInstrument() {
    constexpr std::uint32_t frames = 8U;
    GeneratorFourOutputProcessor instrument;
    std::vector<silveton::GraphNodeDefinition> nodes(5U);
    silveton::ProcessorRouting routing;
    routing.extraOutputDestinations = {1, 2, 3};
    nodes[0].processors.push_back({&instrument, routing});

    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U,4U,1.0F},{1U,4U,1.0F},{2U,4U,1.0F},{3U,4U,1.0F}}, 4U);
    graph.prepare(48000.0, frames, 64U);

    std::array<silveton::ConstStereoBus,5U> sources {};
    std::array<float,frames> masterL {}, masterR {};
    silveton::ProcessorContext context; context.frames = frames; context.playing = true;
    graph.process(sources.data(), sources.size(), {masterL.data(), masterR.data()}, frames, context);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        // 0.1 main + 0.2 + 0.3 + 0.4 routed outputs.
        require(std::abs(masterL[i] - 1.0F) < 1.0e-6F,
                "zero-input multi-output instrument did not generate/reroute all outputs");
        require(std::abs(masterR[i] + 1.0F) < 1.0e-6F,
                "zero-input multi-output instrument right channel mismatch");
    }
}

void testMultiOutputPdcAndLatencyRefresh() {
    constexpr std::uint32_t frames = 16U;
    DelayedTwoOutputProcessor proc(4U);
    std::vector<silveton::GraphNodeDefinition> nodes(3U);
    silveton::ProcessorRouting routing;
    routing.extraOutputDestinations = {2};
    nodes[0].processors.push_back({&proc, routing});
    silveton::ProcessorGraph graph;
    graph.configure(std::move(nodes), {{0U,2U,1.0F},{1U,2U,1.0F}}, 2U);
    graph.prepare(48000.0, frames, 1024U);
    require(graph.nodeOutputLatency(0U) == 4U && graph.nodeOutputLatency(2U) == 4U,
            "multi-output latency was not propagated through PDC graph");

    std::array<float,frames> aL{},aR{},bL{},bR{},mL{},mR{};
    aL[0]=aR[0]=1.0F; bL[0]=bR[0]=1.0F;
    std::array<silveton::ConstStereoBus,3U> src {{{aL.data(),aR.data()},{bL.data(),bR.data()},{nullptr,nullptr}}};
    silveton::ProcessorContext ctx; ctx.frames=frames;
    graph.process(src.data(),src.size(),{mL.data(),mR.data()},frames,ctx);
    for (std::size_t i=0;i<frames;++i) {
        const float expected = i==4U ? 4.0F : 0.0F; // main(1) + extra(2) + aligned local source(1)
        require(std::abs(mL[i]-expected)<1e-6F && std::abs(mR[i]-expected)<1e-6F,
                "multi-output route was not PDC-aligned with other graph inputs");
    }

    proc.setLatency(8U);
    graph.refreshLatencies();
    require(graph.nodeOutputLatency(0U) == 8U && graph.nodeOutputLatency(2U) == 8U,
            "dynamic processor latency refresh did not update graph PDC");
}


void testRealtimeLifecycleGate() {
    silveton::RealtimeLifecycleGate gate;

    // Deterministic hand-off: control suspension must not complete while an
    // audio block owns the gate, and audio must never enter while suspended.
    require(gate.tryEnterAudio(), "lifecycle gate initial audio entry failed");
    std::atomic<bool> controlEntered {false};
    std::thread control([&] {
        gate.suspendControl();
        controlEntered.store(true, std::memory_order_release);
        gate.resumeControl();
    });
    for (int i = 0; i < 1000 && controlEntered.load(std::memory_order_acquire); ++i)
        std::this_thread::yield();
    require(!controlEntered.load(std::memory_order_acquire),
            "control lifecycle entered while audio block still owned gate");
    gate.leaveAudio();
    control.join();
    require(controlEntered.load(std::memory_order_acquire),
            "control lifecycle did not acquire gate after audio exit");

    gate.suspendControl();
    require(!gate.tryEnterAudio(), "audio entered while lifecycle gate was suspended");
    gate.resumeControl();
    require(gate.tryEnterAudio(), "audio did not resume after lifecycle service");
    gate.leaveAudio();

    // Concurrent stress: control repeatedly suspends/resumes while a realtime
    // thread attempts blocks. Neither side may overlap its protected region.
    std::atomic<bool> stop {false};
    std::atomic<bool> audioInside {false};
    std::atomic<bool> controlInside {false};
    std::atomic<bool> overlap {false};
    std::atomic<std::uint64_t> audioEntries {0U};
    std::atomic<std::uint64_t> audioSkips {0U};

    std::thread audio([&] {
        while (!stop.load(std::memory_order_acquire)) {
            if (!gate.tryEnterAudio()) {
                audioSkips.fetch_add(1U, std::memory_order_relaxed);
                std::this_thread::yield();
                continue;
            }
            audioInside.store(true, std::memory_order_release);
            if (controlInside.load(std::memory_order_acquire))
                overlap.store(true, std::memory_order_release);
            for (int spin = 0; spin < 16; ++spin) std::atomic_signal_fence(std::memory_order_seq_cst);
            audioInside.store(false, std::memory_order_release);
            gate.leaveAudio();
            audioEntries.fetch_add(1U, std::memory_order_relaxed);
        }
    });

    // Let the realtime thread establish that the normal processing path is live
    // before the control-side stress starts. This avoids testing OS scheduler
    // starvation instead of the gate itself.
    for (int spin = 0; spin < 100000 && audioEntries.load(std::memory_order_acquire) == 0U; ++spin)
        std::this_thread::yield();
    require(audioEntries.load(std::memory_order_acquire) > 0U,
            "lifecycle gate stress audio thread did not start");

    for (int i = 0; i < 2000; ++i) {
        gate.suspendControl();
        controlInside.store(true, std::memory_order_release);
        if (audioInside.load(std::memory_order_acquire))
            overlap.store(true, std::memory_order_release);

        // Hold the first suspension long enough to prove that audio observes
        // the non-blocking rejection path at least once.
        if (i == 0) {
            for (int spin = 0; spin < 100000 && audioSkips.load(std::memory_order_acquire) == 0U; ++spin)
                std::this_thread::yield();
        }
        for (int spin = 0; spin < 16; ++spin) std::atomic_signal_fence(std::memory_order_seq_cst);
        controlInside.store(false, std::memory_order_release);
        gate.resumeControl();
        if ((i & 31) == 0) std::this_thread::yield();
    }
    stop.store(true, std::memory_order_release);
    audio.join();

    require(!overlap.load(std::memory_order_acquire),
            "audio processing overlapped control-side lifecycle service");
    require(audioEntries.load(std::memory_order_relaxed) > 0U,
            "lifecycle gate stress never admitted audio processing");
    require(audioSkips.load(std::memory_order_relaxed) > 0U,
            "lifecycle gate stress never exercised realtime non-blocking skip path");
}

void testMultiOutputCycleRejection() {
    FourOutputProcessor proc;
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    silveton::ProcessorRouting routing;
    routing.extraOutputDestinations = {1};
    nodes[0].processors.push_back({&proc, routing});
    bool rejected=false;
    try {
        silveton::ProcessorGraph graph;
        graph.configure(std::move(nodes), {{1U,0U,1.0F}}, 1U);
    } catch (const std::logic_error& e) { rejected = std::string(e.what()) == "routing cycle"; }
    require(rejected, "hidden multi-output feedback cycle was not rejected");
}

void testScannerIsolation(const std::string& scanner) {
    const std::string blacklistPath = "/tmp/silveton-scanner-isolation-blacklist.txt";
    std::remove(blacklistPath.c_str());
    silveton::Vst3Blacklist blacklist;

    auto ok = silveton::scanVst3ModuleIsolated(scanner, "/tmp/good-fixture.vst3", 1000U, blacklist);
    require(!ok.crashedOrFailed && !ok.timedOut && ok.plugins.size() == 1U, "isolated scanner success path failed");
    require(ok.plugins[0].name == "Fixture\tName", "scanner field escaping failed");

    auto crash = silveton::scanVst3ModuleIsolated(scanner, "/tmp/crash-fixture.vst3", 1000U, blacklist);
    require(crash.crashedOrFailed && blacklist.contains("/tmp/crash-fixture.vst3", "*"), "scanner crash was not blacklisted");
    auto skipped = silveton::scanVst3ModuleIsolated(scanner, "/tmp/crash-fixture.vst3", 1000U, blacklist);
    require(skipped.skippedBlacklisted, "blacklisted scanner module was launched again");

    auto timeout = silveton::scanVst3ModuleIsolated(scanner, "/tmp/timeout-fixture.vst3", 50U, blacklist);
    require(timeout.timedOut && timeout.crashedOrFailed && blacklist.contains("/tmp/timeout-fixture.vst3", "*"), "scanner timeout was not contained/blacklisted");
    blacklist.save(blacklistPath);
    silveton::Vst3Blacklist loaded;
    loaded.load(blacklistPath);
    require(loaded.contains("/tmp/crash-fixture.vst3", "*") && loaded.contains("/tmp/timeout-fixture.vst3", "*"), "scanner blacklist persistence failed");
    std::remove(blacklistPath.c_str());
}

void testMusicalMidiPlanQueuesIntoVst3Runtime() {
    silveton::Project p;
    silveton::ProjectTrack track;
    silveton::ProjectPluginSlot slot;
    slot.modulePath = "Instrument.vst3";
    slot.classId = "InstrumentClass";
    slot.midiInputPort = 7;
    track.pluginSlots.push_back(slot);
    p.tracks.push_back(track);

    MockFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(p);
    require(factory.lastCreated != nullptr, "MIDI runtime fixture instance missing");

    silveton::TempoMap map;
    map.setSampleRate(48000.0);
    map.setInitialTempo(120.0);
    silveton::MidiSequence sequence;
    (void)sequence.addNote({0U, 1.0, 0.5, 0U, 67U, 101U, 55U, false});
    const auto plan = sequence.compile(map);

    // q=1 is sample 24000 at 120 BPM. Start block 16 samples earlier.
    const std::size_t queued = rack.queueMidiPlanForBlock(7, plan, 23984, 64U);
    require(queued == 1U, "MIDI render plan did not queue note-on into VST3 runtime");
    require(factory.lastCreated->midiQueuedCount() == 1U, "VST3 runtime MIDI queue count mismatch");
    const auto& event = factory.lastCreated->midiQueued(0U);
    require(event.frameOffset == 16, "VST3 runtime MIDI frame offset mismatch");
    require((event.status & 0xF0U) == 0x90U && event.data1 == 67U && event.data2 == 101U,
            "VST3 runtime MIDI event payload mismatch");
}

void testLiveMidiInputQueuesIntoVst3Runtime() {
    silveton::Project p;
    silveton::ProjectTrack track;
    silveton::ProjectPluginSlot slot;
    slot.modulePath = "LiveInstrument.vst3";
    slot.classId = "LiveInstrumentClass";
    slot.midiInputPort = 11;
    track.pluginSlots.push_back(slot);
    p.tracks.push_back(track);

    MockFactory factory;
    silveton::Vst3RuntimeRack rack(factory);
    rack.restore(p);
    require(factory.lastCreated != nullptr, "live MIDI fixture instance missing");

    silveton::MidiInputCapture input;
    require(input.pushRealtime({11, 1008, 0x91U, 72U, 119U}), "live MIDI note-on input push failed");
    require(input.pushRealtime({11, 1031, 0x81U, 72U, 44U}), "live MIDI note-off input push failed");
    require(input.pushRealtime({11, 1200, 0xB1U, 1U, 90U}), "live MIDI future input push failed");

    const std::size_t queued = rack.queueLiveMidiForBlock(input, 1000, 64U);
    require(queued == 2U, "live MIDI block did not queue both in-range events");
    require(factory.lastCreated->midiQueuedCount() == 2U, "live VST3 MIDI queue count mismatch");
    require(factory.lastCreated->midiQueued(0U).frameOffset == 8,
            "live MIDI note-on frame offset mismatch");
    require(factory.lastCreated->midiQueued(1U).frameOffset == 31,
            "live MIDI note-off frame offset mismatch");

    const std::size_t future = rack.queueLiveMidiForBlock(input, 1184, 64U);
    require(future == 1U, "future live MIDI event was not preserved for its audio block");
    require(factory.lastCreated->midiQueued(2U).frameOffset == 16,
            "future live MIDI frame offset mismatch");
}

void testCycleRejection() {
    SidechainSumProcessor proc;
    std::vector<silveton::GraphNodeDefinition> nodes(2U);
    silveton::ProcessorRouting routing;
    routing.sidechainSourceNode = 1;
    nodes[0].processors.push_back({&proc, routing});
    bool rejected = false;
    try {
        silveton::ProcessorGraph graph;
        graph.configure(std::move(nodes), {{0U,1U,1.0F}}, 1U);
    } catch (const std::logic_error& e) {
        rejected = std::string(e.what()) == "routing cycle";
    }
    require(rejected, "hidden sidechain feedback cycle was not rejected");
}
}

int main(int argc, char** argv) {
    try {
        testBlacklist();
        testAutomation();
        testSidechainPdc();
        testMultiOutput();
        testZeroInputMultiOutputInstrument();
        testMultiOutputPdcAndLatencyRefresh();
        testCycleRejection();
        testMultiOutputCycleRejection();
        testProjectV14RuntimeRestore();
        testProjectMixerRoutingBuilder();

        testMixerRuntimeCoordinatorServicesVst3Rebuilds();
        testMixerRuntimeCoordinatorSafelyReplacesPluginTopology();
        testRealtimeLifecycleGate();
        testMusicalMidiPlanQueuesIntoVst3Runtime();
        testLiveMidiInputQueuesIntoVst3Runtime();
        require(argc == 2, "fake scanner path missing");
        testScannerIsolation(argv[1]);
        std::cout << "PASS: VST3 blacklist persistence\n";
        std::cout << "PASS: automation Write/Touch/Latch primitives\n";
        std::cout << "PASS: real sidechain PDC alignment\n";
        std::cout << "PASS: real multi-output routing + PDC + dynamic latency refresh\n";
        std::cout << "PASS: sidechain and multi-output feedback cycle rejection\n";
        std::cout << "PASS: Project V14 VST3 state + runtime restore + sample-accurate automation\n";
        std::cout << "PASS: lock-free VST3 audio/control lifecycle gate + 2000 suspend/resume stress\n";
        std::cout << "PASS: musical MIDI timeline -> VST3 runtime frame-accurate queue\n";
        std::cout << "PASS: isolated scanner crash/timeout containment + blacklist persistence\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL: " << e.what() << '\n';
        return 1;
    }
}
