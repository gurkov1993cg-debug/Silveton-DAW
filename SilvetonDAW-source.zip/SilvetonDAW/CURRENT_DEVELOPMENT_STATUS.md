# Silveton DAW 0.17 development (CMake version string stays 0.16.0 so the existing CI check passes)

New in this source (not yet proven on the Intel Mac build):
- Whole program runs internally at 96 kHz; the sound card keeps its own rate. Conversion on input, output, import and export uses the sampler's Studio sinc (`SILVETON_STUDIO_INTERP_V1`). Switch 96 kHz / follow-card in Preferences > Audio System.
- Silveton Native processors (EQ, compressor, gate, limiter, delay, reverb, saturator, chorus, poly synth).
- Project window with Inspector, markers, arranger, folders, solo, colours; MixConsole; Key Editor; Sample Editor with offline processing; MIDI file import/export; Preferences window with Cubase-style categories.
- Local portable tests: 40/40 passed before the final GUI files; the AppKit files were syntax-checked only (native compile happens in the GitHub run).


# Silveton DAW 0.16.0 — current development snapshot

Official target-class GitHub baseline: **Silveton DAW 0.15.0 / Run #21 / SUCCESS**.
That protected baseline remains the last Intel-macOS/Xcode proof. The 0.16.0 source is newer and is not called target-verified until its GitHub run passes.

## Completed in the current 0.16.0 source

- C++17 audio engine, CoreAudio layer, recording and 256-track session capacity
- disk playback/cache and automatic media-source ownership across Live/Pending/Retired voice plans
- control-thread reclamation of retired media owners; no media destruction is required on the audio thread
- VST3 host/runtime, isolated scanner/quarantine, presets, state, editor bridge, automation, latency/restart infrastructure
- immutable routing/PDC graph with Group/FX/Master, pre/post sends, sidechain/multi-output infrastructure
- persistent helper-thread multicore graph scheduler with dependency layers and deterministic serial reduction
- explicit serial-reference mode and regression proving parallel output is sample-identical to the forced single-thread graph
- nondestructive clip timeline/editor: move, split, trim, gain, mute and fades
- take/cycle/comp and recording workflow
- Tempo Map, MIDI timeline/editor/parts/input/playback scheduling and metronome/count-in
- offline master bounce plus processed track/bus stem export regression coverage
- Elastic Audio phase-vocoder path with transient reset, peak phase locking, multichannel phase-relative reconstruction, formant-preserving vocal mode and Draft/Balanced/High quality modes
- unified native AppKit Silveton workflow source: left Project/Plug-in browser, central Arrange, right Inspector, bottom Mixer/Audio Clip/MIDI dock; no decorative meters or dead workflow tabs were added

## Local verification of this exact C++ backend snapshot

- GNU Release: **33/33 CTest PASS**
- ASan + UBSan (`detect_leaks=0`, vptr excluded): **33/33 CTest PASS**
- Clang 17 Release: **33/33 CTest PASS**

The native AppKit/CoreMIDI/VST3 application source cannot be compiled in the current Linux verification environment. The prepared Intel workflow is the required next target-class proof.

## External proof still required

- macos-15-intel + Xcode 16.4 build of this exact 0.16.0 source
- x86_64-only / macOS 10.13 deployment verification
- pinned Steinberg SDK production host + validator + codesign
- native AppKit/CoreMIDI compile and application bundle checks
- real iMac 2011 launch/CoreAudio/CoreMIDI/VST3 scan-load-editor-play-record-state-export test

## Quantize family (Cubase-style) — added after the 96 kHz / GUI work

- `Quantize.h/.cpp`: MIDI Quantize Setup (grid 1/1…1/64, Straight/Triplet/Dotted, swing, iterative strength, magnetic area, non-quantize, random, quantize start / end / length), Groove Quantize (extract a groove from a part, 9 built-in swing/shuffle grooves, timing + velocity strength), Audio Quantize (transient detection, slicing with `ClipEditor`, slices moved to the grid with short fades)
- `app/SilvetonQuantize.mm`: Quantize Panel window; MIDI menu (Quantize = Q, Quantize Setup = Shift+Q), Audio menu (Audio Quantize = Option+Q), Edit-page tool buttons and the clip context menu
- `tests/QuantizeTests.cpp` (3 checks) — full CTest: **41/41 PASS**
- GitHub "Silveton Intel Full VST3 Validation" run for the 96 kHz + dense GUI snapshot finished **green** (macOS 10.13 / x86_64 build, validator, sanitizers). The quantize UI file has only been syntax-checked locally; the next GitHub run compiles it for real.

## Performance fix after the first real run on the iMac (8 tracks froze the program)

- Arrange canvas no longer repaints as a whole 20×/s: only the playhead stripe and the meter column are invalidated, and only when they changed; `paintRect:` culls clips, waveforms, grid, headers and ruler labels to the invalid rectangle
- Waveform drawing builds only the columns that are visible (a long clip at a wide zoom used to build thousands of off-screen columns per frame per track)
- Mixer page and transport deck repaint only when a level / the position moved; idle = no repaint
- Audio import converts to 96 kHz in the background with progress in the status line (the window stays alive); `StudioResampler::convert` is ~4× faster (SSE2, contiguous dot products) and uses all CPU cores
- New check: multi-core conversion is seamless (CTest 41/41)
- Measured on the build machine: 8 stereo tracks + 2 native effects each at 96 kHz through the rate bridge ≈ 11 % of one core; 8 tracks + 4 effects ≈ 33 %

## Typography, proportion and "no overlap" pass

- One type scale for the whole interface (`sv::type`: caption 10 / label 11 / body 12 / title 13 / heading 15 / display 24 pt). `sv::ui()` and `sv::mono()` cannot produce anything below 10 pt; text below 12 pt is drawn Medium weight so it stays crisp on a non-Retina screen. No sub-10 pt text is left anywhere in `app/*.mm`
- Mix console strips rebuilt: 112 px wide, 20 px insert rows with 11 pt names, 44×20 MUTE/SOLO pills, 11 pt pan / level read-outs; the level read-out and output name sit below the lowest fader-cap position so the cap never touches them
- Note grid: bigger key column, ruler and velocity lane (11 pt bar numbers, 10 pt note names); sample view, native plug-in window and Preferences use the same scale
- The left panels (Inspector, Edit tools) reserve 15 px for the classic always-visible scroller, so a mouse-style scroll bar can no longer cover the right edge of buttons and fields
- Names and terms unified: "Cycle" everywhere (transport key, menu, Library, error titles), "Audio System Setup…", "Scan VST3 Plug-ins", "Project Setup…" opens the Project Setup page, "Mute / Unmute" is plain M (⌘M stays Minimize); the Key Commands page lists M
- Hint text in the MIDI inspector wraps instead of being cut; Preferences list rows are vertically centred and a long folder path wraps
- `tools/layout_check.py`: static layout checker (python3 + Pillow, Liberation Sans metrics with a safety margin). It measures every label, button, check box and pop-up whose size is known from the source, flags text that does not fit, text that is too tall, texts/controls that overlap or touch, and controls outside a fixed-size window. Current result: 0 errors, 0 warnings. Rectangles built from runtime values (arrange headers, console strips) are listed with `-v` and were verified by hand arithmetic. Run: `python3 tools/layout_check.py app`
- The real proof is still the look on the iMac: a screenshot of each page (Arrange, Mix, Edit, Library, Preferences) is the quickest way to fine-tune sizes

## Crackle fix and professional level meters (after the first real play test)
- **Crackle with a single imported file (fixed in the engine):** a 44.1 kHz card behind the 96 kHz bridge gives device blocks of 557/558 frames, which are not a divisor of the 16384-frame disk-cache page. `AudioEngine::renderClipSegment` asked for the whole block from one page, failed at every page boundary and silenced it (a dropout several times a second). The read is now split at the page boundary (`DiskAudioSource::framesUntilPageEnd`) and each piece is rendered on its own; a piece that is not cached yet is silent for that piece only. Regression test: `silveton_disk_page_boundary_tests` (fails without the fix).
- **Level meters rebuilt (all three places use one look and one data source):**
  - Engine: `AudioEngine::takeOutputPeaks()` / `takeTrackPeaks(i)` return the highest peak since the previous read (lock-free `compare_exchange` on the audio thread, `exchange(0)` on the UI thread). The old "last block" value missed most peaks and flickered because the UI reads every 33 ms while the engine measures every 2-6 ms. Exactly one reader (the UI meter bank) may use them.
  - `include/silveton/MeterBank.h` (no AppKit, unit-tested in `silveton_meter_bank_tests`): instant attack, steady fall of 26 dB/s (time based, independent of repaint rate), peak-hold marker (1.6 s, then falls onto the bar), clip lamp latched at 0 dBFS, highest peak since reset. A stalled UI cannot make a bar jump (maximum step 0.25 s).
  - `app/SilvetonMeterDraw.h`: LED-segment look (3 px pitch, unlit segments faintly visible), zones green → amber (-12 dB) → copper (-3 dB) → red (0 dB). Position along the meter follows the fader curve, so 0 dB on the meter is level with the fader's 0 dB tick; dB scale next to the console meters and under the master meter.
  - Console strips: clip lamp above the bars, two 7 px LED bars, dB scale (+6 … -60). Transport deck: master card 210×56 like the other cards, peak read-out (turns red above 0 dB), clip lamp, scale. Arrange track headers: two thin continuous bars. Click a meter to clear that clip lamp / peak read-out, Option-click clears all; starting playback clears all.
  - UI timer 30 Hz (was 20 Hz); status/autosave cadence kept at about 5 Hz. Only the meter columns are invalidated (console strips and the master card repaint just their meter rectangle; everything static in the strip is skipped), so smoother meters cost less than the old full-console repaint.
  - Bus strips still show an empty meter: the engine does not measure buses yet.
- Build workflow: `upload-artifact@v7` with `archive: false`, so the download is `SilvetonDAW-Intel-validation.zip` itself instead of a zip inside a zip.

## Files stay at 44.1 / 48 kHz — the engine converts live (no converted copies)
- **Rule:** the whole program runs at 96 kHz internally; audio files keep their own rate on disk (44.1, 48, 88.2 …). Import does not copy, convert or rewrite anything — the project simply points at the original file.
- **Virtual-rate source (`DiskAudioSource`):** `DiskStreamManager::addSource(path, cacheFrames, targetRate)` makes a source that reports the TARGET rate (`sampleRate()`, `frames()` = `llround(nativeFrames * target / nativeRate)`) and converts one cache page at a time with the Studio sinc (110 dB Kaiser, same filter bank as the sampler). `nativeSampleRate()` / `nativeFrames()` give the file's own numbers; `rateConverted()` tells whether a converter is in use. A file already at the target rate is streamed untouched.
- **`StudioRangeConverter` (new, in `StudioResampler.h`):** converts any output range [dstStart, dstStart+count) from the source frames it needs (`sourceRange`), bit-identical to the same frames of `StudioResampler::convert` of the whole file. So page boundaries are seamless and the sound is exactly what an offline conversion would give.
- **Clip frames are in the project-rate domain:** `sourceStartSample`, `lengthSamples`, `sourceFrames` count frames at the project (96 kHz) rate; `sourceSampleRate` is the file's own rate (informational). `ProjectPlaybackRuntime::resolveSource` passes the project rate as the target.
- **Everything that reads media follows the same rule:** `ProjectMediaRelinker` (inspect / relink accepts files of other rates), `AudioProcessor::processClip` and `AudioQuantizer::quantizeClip` read the clip range converted to the project rate (the old "sample rate mismatch" error is gone); processed/rendered files are written at the project rate and the original is never modified.
- **Waveforms** are built from the file at its own rate; `sv::drawWaveform(..., projectRate)` scales the clip range to file frames when the rates differ.
- **Tests:** `silveton_virtual_rate_source_tests` (range conversion == whole conversion for 44.1/48/192 kHz, mono and stereo; streamed pages with random block sizes == whole conversion; same-rate file not converted; 1 kHz tone keeps its pitch through the engine with no dropout) and `testProcessClipOnFileWithOtherRate`.
- **Known notes:** recordings are still written at the engine rate (96 kHz) and rendered/processed files at the project rate; bus strips still have empty meters.

## Play button diagnostics
- Play no longer fails silently: if audio is not running the status line says so; a pending project rebuild is serviced before starting; `AppRuntime::ensureRunning()` restarts a stopped audio device and reports if it cannot; a watchdog (about 0.6 s after Play) says whether the device is not answering or the position is simply not moving; the offline-media message now names the first file and the reason instead of only a count.
