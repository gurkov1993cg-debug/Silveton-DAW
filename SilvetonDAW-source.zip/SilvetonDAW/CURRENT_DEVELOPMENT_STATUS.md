# Silveton DAW 0.17 development (CMake version string stays 0.16.0 so the existing CI check passes)

New in this source (not yet proven on the Intel Mac build):
- Whole program runs internally at 96 kHz; the sound card keeps its own rate. Conversion on input, output, import and export uses the sampler's Studio sinc (`SILVETON_STUDIO_INTERP_V1`). Switch 96 kHz / follow-card in Preferences > Audio System.
- Silveton Native processors (EQ, compressor, gate, limiter, delay, reverb, saturator, chorus, poly synth).
- Project window with Inspector, markers, arranger, folders, solo, colours; MixConsole; Key Editor; Sample Editor with offline processing; MIDI file import/export; Preferences window with Cubase-style categories.
- Local portable tests: 40/40 passed before the final GUI files; the AppKit files were syntax-checked only (native compile happens in the GitHub run).


# Silveton DAW 0.16.0 — current development snapshot

Official target-class GitHub baseline: **Silveton DAW 0.15.0 / Run #21 / SUCCESS**.
That protected baseline remains the last Intel-macOS/Xcode proof. The 0.16.0 source is newer and is not called target-verified until its GitHub run passes.

## Completed in the current 0.16.0 source

- C++17 audio engine, CoreAudio layer, recording and 256-track session capacity
- disk playback/cache and automatic media-source ownership across Live/Pending/Retired voice plans
- control-thread reclamation of retired media owners; no media destruction is required on the audio thread
- VST3 host/runtime, isolated scanner/quarantine, presets, state, editor bridge, automation, latency/restart infrastructure
- immutable routing/PDC graph with Group/FX/Master, pre/post sends, sidechain/multi-output infrastructure
- persistent helper-thread multicore graph scheduler with dependency layers and deterministic serial reduction
- explicit serial-reference mode and regression proving parallel output is sample-identical to the forced single-thread graph
- nondestructive clip timeline/editor: move, split, trim, gain, mute and fades
- take/cycle/comp and recording workflow
- Tempo Map, MIDI timeline/editor/parts/input/playback scheduling and metronome/count-in
- offline master bounce plus processed track/bus stem export regression coverage
- Elastic Audio phase-vocoder path with transient reset, peak phase locking, multichannel phase-relative reconstruction, formant-preserving vocal mode and Draft/Balanced/High quality modes
- unified native AppKit Silveton workflow source: left Project/Plug-in browser, central Arrange, right Inspector, bottom Mixer/Audio Clip/MIDI dock; no decorative meters or dead workflow tabs were added

## Local verification of this exact C++ backend snapshot

- GNU Release: **33/33 CTest PASS**
- ASan + UBSan (`detect_leaks=0`, vptr excluded): **33/33 CTest PASS**
- Clang 17 Release: **33/33 CTest PASS**

The native AppKit/CoreMIDI/VST3 application source cannot be compiled in the current Linux verification environment. The prepared Intel workflow is the required next target-class proof.

## External proof still required

- macos-15-intel + Xcode 16.4 build of this exact 0.16.0 source
- x86_64-only / macOS 10.13 deployment verification
- pinned Steinberg SDK production host + validator + codesign
- native AppKit/CoreMIDI compile and application bundle checks
- real iMac 2011 launch/CoreAudio/CoreMIDI/VST3 scan-load-editor-play-record-state-export test

## Quantize family (Cubase-style) — added after the 96 kHz / GUI work

- `Quantize.h/.cpp`: MIDI Quantize Setup (grid 1/1…1/64, Straight/Triplet/Dotted, swing, iterative strength, magnetic area, non-quantize, random, quantize start / end / length), Groove Quantize (extract a groove from a part, 9 built-in swing/shuffle grooves, timing + velocity strength), Audio Quantize (transient detection, slicing with `ClipEditor`, slices moved to the grid with short fades)
- `app/SilvetonQuantize.mm`: Quantize Panel window; MIDI menu (Quantize = Q, Quantize Setup = Shift+Q), Audio menu (Audio Quantize = Option+Q), Edit-page tool buttons and the clip context menu
- `tests/QuantizeTests.cpp` (3 checks) — full CTest: **41/41 PASS**
- GitHub "Silveton Intel Full VST3 Validation" run for the 96 kHz + dense GUI snapshot finished **green** (macOS 10.13 / x86_64 build, validator, sanitizers). The quantize UI file has only been syntax-checked locally; the next GitHub run compiles it for real.

## Performance fix after the first real run on the iMac (8 tracks froze the program)

- Arrange canvas no longer repaints as a whole 20×/s: only the playhead stripe and the meter column are invalidated, and only when they changed; `paintRect:` culls clips, waveforms, grid, headers and ruler labels to the invalid rectangle
- Waveform drawing builds only the columns that are visible (a long clip at a wide zoom used to build thousands of off-screen columns per frame per track)
- Mixer page and transport deck repaint only when a level / the position moved; idle = no repaint
- Audio import converts to 96 kHz in the background with progress in the status line (the window stays alive); `StudioResampler::convert` is ~4× faster (SSE2, contiguous dot products) and uses all CPU cores
- New check: multi-core conversion is seamless (CTest 41/41)
- Measured on the build machine: 8 stereo tracks + 2 native effects each at 96 kHz through the rate bridge ≈ 11 % of one core; 8 tracks + 4 effects ≈ 33 %

## Typography, proportion and "no overlap" pass

- One type scale for the whole interface (`sv::type`: caption 10 / label 11 / body 12 / title 13 / heading 15 / display 24 pt). `sv::ui()` and `sv::mono()` cannot produce anything below 10 pt; text below 12 pt is drawn Medium weight so it stays crisp on a non-Retina screen. No sub-10 pt text is left anywhere in `app/*.mm`
- Mix console strips rebuilt: 112 px wide, 20 px insert rows with 11 pt names, 44×20 MUTE/SOLO pills, 11 pt pan / level read-outs; the level read-out and output name sit below the lowest fader-cap position so the cap never touches them
- Note grid: bigger key column, ruler and velocity lane (11 pt bar numbers, 10 pt note names); sample view, native plug-in window and Preferences use the same scale
- The left panels (Inspector, Edit tools) reserve 15 px for the classic always-visible scroller, so a mouse-style scroll bar can no longer cover the right edge of buttons and fields
- Names and terms unified: "Cycle" everywhere (transport key, menu, Library, error titles), "Audio System Setup…", "Scan VST3 Plug-ins", "Project Setup…" opens the Project Setup page, "Mute / Unmute" is plain M (⌘M stays Minimize); the Key Commands page lists M
- Hint text in the MIDI inspector wraps instead of being cut; Preferences list rows are vertically centred and a long folder path wraps
- `tools/layout_check.py`: static layout checker (python3 + Pillow, Liberation Sans metrics with a safety margin). It measures every label, button, check box and pop-up whose size is known from the source, flags text that does not fit, text that is too tall, texts/controls that overlap or touch, and controls outside a fixed-size window. Current result: 0 errors, 0 warnings. Rectangles built from runtime values (arrange headers, console strips) are listed with `-v` and were verified by hand arithmetic. Run: `python3 tools/layout_check.py app`
- The real proof is still the look on the iMac: a screenshot of each page (Arrange, Mix, Edit, Library, Preferences) is the quickest way to fine-tune sizes
