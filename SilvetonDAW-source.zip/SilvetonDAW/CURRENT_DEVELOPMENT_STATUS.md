# Silveton DAW 0.17 development (CMake version string stays 0.16.0 so the existing CI check passes)

New in this source (not yet proven on the Intel Mac build):
- Whole program runs internally at 96 kHz; the sound card keeps its own rate. Conversion on input, output, import and export uses the sampler's Studio sinc (`SILVETON_STUDIO_INTERP_V1`). Switch 96 kHz / follow-card in Preferences > Audio System.
- Silveton Native processors (EQ, compressor, gate, limiter, delay, reverb, saturator, chorus, poly synth).
- Project window with Inspector, markers, arranger, folders, solo, colours; MixConsole; Key Editor; Sample Editor with offline processing; MIDI file import/export; Preferences window with Cubase-style categories.
- Local portable tests: 40/40 passed before the final GUI files; the AppKit files were syntax-checked only (native compile happens in the GitHub run).


# Silveton DAW 0.16.0 — current development snapshot

Official target-class GitHub baseline: **Silveton DAW 0.15.0 / Run #21 / SUCCESS**.
That protected baseline remains the last Intel-macOS/Xcode proof. The 0.16.0 source is newer and is not called target-verified until its GitHub run passes.

## Completed in the current 0.16.0 source

- C++17 audio engine, CoreAudio layer, recording and 256-track session capacity
- disk playback/cache and automatic media-source ownership across Live/Pending/Retired voice plans
- control-thread reclamation of retired media owners; no media destruction is required on the audio thread
- VST3 host/runtime, isolated scanner/quarantine, presets, state, editor bridge, automation, latency/restart infrastructure
- immutable routing/PDC graph with Group/FX/Master, pre/post sends, sidechain/multi-output infrastructure
- persistent helper-thread multicore graph scheduler with dependency layers and deterministic serial reduction
- explicit serial-reference mode and regression proving parallel output is sample-identical to the forced single-thread graph
- nondestructive clip timeline/editor: move, split, trim, gain, mute and fades
- take/cycle/comp and recording workflow
- Tempo Map, MIDI timeline/editor/parts/input/playback scheduling and metronome/count-in
- offline master bounce plus processed track/bus stem export regression coverage
- Elastic Audio phase-vocoder path with transient reset, peak phase locking, multichannel phase-relative reconstruction, formant-preserving vocal mode and Draft/Balanced/High quality modes
- unified native AppKit Silveton workflow source: left Project/Plug-in browser, central Arrange, right Inspector, bottom Mixer/Audio Clip/MIDI dock; no decorative meters or dead workflow tabs were added

## Local verification of this exact C++ backend snapshot

- GNU Release: **33/33 CTest PASS**
- ASan + UBSan (`detect_leaks=0`, vptr excluded): **33/33 CTest PASS**
- Clang 17 Release: **33/33 CTest PASS**

The native AppKit/CoreMIDI/VST3 application source cannot be compiled in the current Linux verification environment. The prepared Intel workflow is the required next target-class proof.

## External proof still required

- macos-15-intel + Xcode 16.4 build of this exact 0.16.0 source
- x86_64-only / macOS 10.13 deployment verification
- pinned Steinberg SDK production host + validator + codesign
- native AppKit/CoreMIDI compile and application bundle checks
- real iMac 2011 launch/CoreAudio/CoreMIDI/VST3 scan-load-editor-play-record-state-export test

## Quantize family (Cubase-style) — added after the 96 kHz / GUI work

- `Quantize.h/.cpp`: MIDI Quantize Setup (grid 1/1…1/64, Straight/Triplet/Dotted, swing, iterative strength, magnetic area, non-quantize, random, quantize start / end / length), Groove Quantize (extract a groove from a part, 9 built-in swing/shuffle grooves, timing + velocity strength), Audio Quantize (transient detection, slicing with `ClipEditor`, slices moved to the grid with short fades)
- `app/SilvetonQuantize.mm`: Quantize Panel window; MIDI menu (Quantize = Q, Quantize Setup = Shift+Q), Audio menu (Audio Quantize = Option+Q), Edit-page tool buttons and the clip context menu
- `tests/QuantizeTests.cpp` (3 checks) — full CTest: **41/41 PASS**
- GitHub "Silveton Intel Full VST3 Validation" run for the 96 kHz + dense GUI snapshot finished **green** (macOS 10.13 / x86_64 build, validator, sanitizers). The quantize UI file has only been syntax-checked locally; the next GitHub run compiles it for real.

## Performance fix after the first real run on the iMac (8 tracks froze the program)

- Arrange canvas no longer repaints as a whole 20×/s: only the playhead stripe and the meter column are invalidated, and only when they changed; `paintRect:` culls clips, waveforms, grid, headers and ruler labels to the invalid rectangle
- Waveform drawing builds only the columns that are visible (a long clip at a wide zoom used to build thousands of off-screen columns per frame per track)
- Mixer page and transport deck repaint only when a level / the position moved; idle = no repaint
- Audio import converts to 96 kHz in the background with progress in the status line (the window stays alive); `StudioResampler::convert` is ~4× faster (SSE2, contiguous dot products) and uses all CPU cores
- New check: multi-core conversion is seamless (CTest 41/41)
- Measured on the build machine: 8 stereo tracks + 2 native effects each at 96 kHz through the rate bridge ≈ 11 % of one core; 8 tracks + 4 effects ≈ 33 %

## Typography, proportion and "no overlap" pass

- One type scale for the whole interface (`sv::type`: caption 10 / label 11 / body 12 / title 13 / heading 15 / display 24 pt). `sv::ui()` and `sv::mono()` cannot produce anything below 10 pt; text below 12 pt is drawn Medium weight so it stays crisp on a non-Retina screen. No sub-10 pt text is left anywhere in `app/*.mm`
- Mix console strips rebuilt: 112 px wide, 20 px insert rows with 11 pt names, 44×20 MUTE/SOLO pills, 11 pt pan / level read-outs; the level read-out and output name sit below the lowest fader-cap position so the cap never touches them
- Note grid: bigger key column, ruler and velocity lane (11 pt bar numbers, 10 pt note names); sample view, native plug-in window and Preferences use the same scale
- The left panels (Inspector, Edit tools) reserve 15 px for the classic always-visible scroller, so a mouse-style scroll bar can no longer cover the right edge of buttons and fields
- Names and terms unified: "Cycle" everywhere (transport key, menu, Library, error titles), "Audio System Setup…", "Scan VST3 Plug-ins", "Project Setup…" opens the Project Setup page, "Mute / Unmute" is plain M (⌘M stays Minimize); the Key Commands page lists M
- Hint text in the MIDI inspector wraps instead of being cut; Preferences list rows are vertically centred and a long folder path wraps
- `tools/layout_check.py`: static layout checker (python3 + Pillow, Liberation Sans metrics with a safety margin). It measures every label, button, check box and pop-up whose size is known from the source, flags text that does not fit, text that is too tall, texts/controls that overlap or touch, and controls outside a fixed-size window. Current result: 0 errors, 0 warnings. Rectangles built from runtime values (arrange headers, console strips) are listed with `-v` and were verified by hand arithmetic. Run: `python3 tools/layout_check.py app`
- The real proof is still the look on the iMac: a screenshot of each page (Arrange, Mix, Edit, Library, Preferences) is the quickest way to fine-tune sizes

## Crackle fix and professional level meters (after the first real play test)
- **Crackle with a single imported file (fixed in the engine):** a 44.1 kHz card behind the 96 kHz bridge gives device blocks of 557/558 frames, which are not a divisor of the 16384-frame disk-cache page. `AudioEngine::renderClipSegment` asked for the whole block from one page, failed at every page boundary and silenced it (a dropout several times a second). The read is now split at the page boundary (`DiskAudioSource::framesUntilPageEnd`) and each piece is rendered on its own; a piece that is not cached yet is silent for that piece only. Regression test: `silveton_disk_page_boundary_tests` (fails without the fix).
- **Level meters rebuilt (all three places use one look and one data source):**
  - Engine: `AudioEngine::takeOutputPeaks()` / `takeTrackPeaks(i)` return the highest peak since the previous read (lock-free `compare_exchange` on the audio thread, `exchange(0)` on the UI thread). The old "last block" value missed most peaks and flickered because the UI reads every 33 ms while the engine measures every 2-6 ms. Exactly one reader (the UI meter bank) may use them.
  - `include/silveton/MeterBank.h` (no AppKit, unit-tested in `silveton_meter_bank_tests`): instant attack, steady fall of 26 dB/s (time based, independent of repaint rate), peak-hold marker (1.6 s, then falls onto the bar), clip lamp latched at 0 dBFS, highest peak since reset. A stalled UI cannot make a bar jump (maximum step 0.25 s).
  - `app/SilvetonMeterDraw.h`: LED-segment look (3 px pitch, unlit segments faintly visible), zones green → amber (-12 dB) → copper (-3 dB) → red (0 dB). Position along the meter follows the fader curve, so 0 dB on the meter is level with the fader's 0 dB tick; dB scale next to the console meters and under the master meter.
  - Console strips: clip lamp above the bars, two 7 px LED bars, dB scale (+6 … -60). Transport deck: master card 210×56 like the other cards, peak read-out (turns red above 0 dB), clip lamp, scale. Arrange track headers: two thin continuous bars. Click a meter to clear that clip lamp / peak read-out, Option-click clears all; starting playback clears all.
  - UI timer 30 Hz (was 20 Hz); status/autosave cadence kept at about 5 Hz. Only the meter columns are invalidated (console strips and the master card repaint just their meter rectangle; everything static in the strip is skipped), so smoother meters cost less than the old full-console repaint.
  - Bus strips still show an empty meter: the engine does not measure buses yet.
- Build workflow: `upload-artifact@v7` with `archive: false`, so the download is `SilvetonDAW-Intel-validation.zip` itself instead of a zip inside a zip.

## Files stay at 44.1 / 48 kHz — the engine converts live (no converted copies)
- **Rule:** the whole program runs at 96 kHz internally; audio files keep their own rate on disk (44.1, 48, 88.2 …). Import does not copy, convert or rewrite anything — the project simply points at the original file.
- **Virtual-rate source (`DiskAudioSource`):** `DiskStreamManager::addSource(path, cacheFrames, targetRate)` makes a source that reports the TARGET rate (`sampleRate()`, `frames()` = `llround(nativeFrames * target / nativeRate)`) and converts one cache page at a time with the Studio sinc (110 dB Kaiser, same filter bank as the sampler). `nativeSampleRate()` / `nativeFrames()` give the file's own numbers; `rateConverted()` tells whether a converter is in use. A file already at the target rate is streamed untouched.
- **`StudioRangeConverter` (new, in `StudioResampler.h`):** converts any output range [dstStart, dstStart+count) from the source frames it needs (`sourceRange`), bit-identical to the same frames of `StudioResampler::convert` of the whole file. So page boundaries are seamless and the sound is exactly what an offline conversion would give.
- **Clip frames are in the project-rate domain:** `sourceStartSample`, `lengthSamples`, `sourceFrames` count frames at the project (96 kHz) rate; `sourceSampleRate` is the file's own rate (informational). `ProjectPlaybackRuntime::resolveSource` passes the project rate as the target.
- **Everything that reads media follows the same rule:** `ProjectMediaRelinker` (inspect / relink accepts files of other rates), `AudioProcessor::processClip` and `AudioQuantizer::quantizeClip` read the clip range converted to the project rate (the old "sample rate mismatch" error is gone); processed/rendered files are written at the project rate and the original is never modified.
- **Waveforms** are built from the file at its own rate; `sv::drawWaveform(..., projectRate)` scales the clip range to file frames when the rates differ.
- **Tests:** `silveton_virtual_rate_source_tests` (range conversion == whole conversion for 44.1/48/192 kHz, mono and stereo; streamed pages with random block sizes == whole conversion; same-rate file not converted; 1 kHz tone keeps its pitch through the engine with no dropout) and `testProcessClipOnFileWithOtherRate`.
- **Known notes:** recordings are still written at the engine rate (96 kHz) and rendered/processed files at the project rate; bus strips still have empty meters.

## Play button diagnostics
- Play no longer fails silently: if audio is not running the status line says so; a pending project rebuild is serviced before starting; `AppRuntime::ensureRunning()` restarts a stopped audio device and reports if it cannot; a watchdog (about 0.6 s after Play) says whether the device is not answering or the position is simply not moving; the offline-media message now names the first file and the reason instead of only a count.

## Faders and mutes are heard immediately (live mixer values)
- **Cause of "the level does not go down at once":** the routing graph keeps a frozen copy of every node's fader / mute from the moment it was built (`GraphNodeMixControl`). The UI only refreshed the engine's per-track voice state, which the engine ignores whenever the graph handles the fader — so a track fader or mute was heard only after the next unrelated graph rebuild. Bus faders forced a full project rebuild on every mouse event, and the master fader was added on top of the frozen graph value (double gain until the next rebuild).
- **Fix:** `LiveMixNode` (gain dB + mute per graph node) is owned by `AudioEngine`; `AudioEngine::applyLiveMixerState(project)` writes tracks, buses and master (control thread, lock-free). The audio thread passes them to the graph through `ProcessorContext::liveMix`; `applyNodeMix` glides linearly from the previous block's gain to the new one inside the block (no zipper noise; mute = glide to 0). Nodes with automation on gain / mute keep using the automation.
- Values are tagged with the graph generation they were written for, so a freshly built graph (new project, new inserts) is never overridden by old live values. The UI hands the faders over again once a new graph is live (`timerTick:`); the call is refused while a graph is pending or when the track / bus count does not match.
- App: `applyFaderLive` (drag, no new voice plan per mouse event) and `applyMixerLive` (pan / mute / automation changes); bus fader and bus mute no longer rebuild the project; master fader goes through the graph (no more double gain).
- Test: `silveton_live_mixer_tests` (glide is monotonic and ends on the new level, mute / unmute, master, new graph is not overridden, refusal while pending or on layout mismatch). CTest: 45/45.

## Sample Editor rebuilt (powerful audio editor, first of the two editors)
- **What it is now:** the Editor page for an audio clip shows the clip *and the clips that touch it* (the "span", `AudioRangeEdit::span`) as one piece of sound. Time ruler in project time (1-2-5 steps, ms resolution when zoomed in), zoom from the whole span down to 1/32 pixel per sample (trackpad pinch, ⌘/⌥/⌃ + wheel around the mouse, buttons, `+` `-` `0`, Home / End), horizontal scroll, an overview strip (drag to scroll), amplitude scale in dB, stereo channels drawn separately, clipped peaks marked red, clip gain shown in the picture.
- **Single samples:** when the zoom goes past the envelope's resolution (or Zero Snap is on) the cache decodes the whole file in the background (`WaveformCache::requestDetail`, `WaveformDetail`, refused above 768 MiB, released again when the file is no longer shown). Then the line runs through the real samples, with dots and stems from 7 pixels per sample. 44.1 / 48 kHz files are drawn at their own rate against the 96 kHz project (`PieceView::nativePosition`).
- **Selection:** drag to select, click to place the cursor (= playhead), Shift-click to extend, drag a selection edge to adjust, double-click selects the piece under the mouse, ⌘A selects everything, Esc clears. Edges can jump to the nearest zero crossing (Zero Snap, `nearestZeroCrossing`). Auto-scroll while dragging past the window edge. Read-out bar: selection start / end / length / peak, cursor time, level under the mouse, zoom.
- **Range editing (`AudioRangeEdit`, no media file is ever changed):** Cut, Copy, Paste (replaces the selection, or inserts at the cursor), Delete, Duplicate, Crop to Selection. *Ripple* mode (default) closes the gap on cut / delete and pushes the sound after the paste point; with Ripple off a gap stays and paste lays over. Only clips of the span move, never other clips of the track. One undo step per action.
- **Process only the selection:** Normalize, Gain, Fade In / Out, Reverse, Invert, Remove DC, Silence, Mono, Stereo Flip, Time Stretch, Pitch Shift run on the selected part only (each piece gets its own new media file; a length change moves the rest of the span). Without a selection they work on the whole clip as before.
- **Fades:** fade curves and drag handles for every piece (one handle per clip edge); `AudioRangeEdit::fadeGain / fadeGeometry` use the same anchor rule as the engine, so split pieces draw their inherited fade correctly.
- **Routing:** Edit ▸ Cut / Copy / Paste / Delete / Duplicate, Audio ▸ processes, View ▸ Zoom In / Out / to Project act on the selection while the sample editor is open; on the Project window they still act on whole clips. New menu items: Select All, Crop to Selection, Loop Selection (sets the cycle), Zero Crossing Snap, Ripple Edit, Zoom to Selection. Right-click in the waveform shows the same actions.
- **New files:** `include/silveton/AudioRangeEdit.h` + `src/AudioRangeEdit.cpp`, `include/silveton/SampleEditorModel.h` + `src/SampleEditorModel.cpp` (all maths, tested without a window), `app/SilvetonSampleEditor.mm` (window), `app/SilvetonSampleActions.mm` (controller operations). The old display-only `SilvetonSampleView` is gone from `SilvetonEditors.mm`.
- **Tests:** `silveton_audio_range_edit_tests`, `silveton_sample_editor_model_tests`, detail / release block in `silveton_waveform_cache_tests`. CTest: 47/47. The AppKit part is syntax-checked here and compiled for real only by the GitHub macOS workflow.
- **Known limits:** Normalize on a selection that crosses several pieces normalises each piece on its own; the sample view needs the whole file in memory (very long files fall back to the envelope); no spectrum / loudness analysis yet.
- **Next:** the MIDI (Key) Editor gets the same treatment (task #19).

## Normalize asks for the level
- Normalize used to run at a fixed -0.3 dB without asking. It now opens a small dialog (Audio menu, Process panel, clip context menu) for the maximum level in dB (0 = full scale; the last value is offered again; "," or "." both work). It still works on the selected part in the sample editor, otherwise on the whole clip.

## One look for every question + export progress
- `app/SilvetonDialogs.mm`: `SVDialog` — the single dark dialog (header with title and one-line explanation, labelled rows with slider + typed number + unit + quick-value buttons, choice, tick box, text, a live amber note, Cancel/OK; Return = OK, Esc = Cancel; "," or "." accepted).
  Used by Normalize, Gain, Fade In/Out (curve choice), Time Stretch (length in %, quality), Pitch Shift (semitones, formants, quality), Clip Gain, Clip Fades, Export Mixdown format, Audio System Setup and every text question (`promptText:`). Errors and the quit question stay system alerts.
- Process dialogs say what they act on (`processScopeText`): the selected part in the Editor or the whole clip; with nothing to act on they show a clear message instead of doing nothing.
- `SVProgress` (same file): export progress window — bar, percent, time passed, "about … left", Cancel. The render runs on the main thread inside a modal session, so the window redraws and Cancel works; menus are off while it is open (`+isActive`).
- Core: `OfflineBounceOptions::progress` (called ~20×/s, returns false to cancel → `BounceCancelled`); main range = 0..0.97, effect tail = 0.97..1. Stem export slices the bar per stem ("Stem x of n"). A cancelled export deletes the unfinished file(s) and the status line says so. Test: `testExportProgressAndCancel`.

## Track height + Pencil
- Arrange: every track can have its own height (`chosenHeights()` in `SilvetonViews.mm`, session state, reset on New/Open). Drag the bottom edge of a track header (cursor changes), double click the edge = normal, View > Zoom Track (key Z, on/off) fills the window with the selected track, View > Track Height: Small / Normal / Large / Huge / Fill the Window / All Tracks Normal (`setTrackHeight:`, item tag = height). Waveforms, notes and the header meter scale with the row.
- Sample Editor "Pencil" toggle (toolbar): when single samples are shown (>= 2 px per sample) drag in the waveform to draw sample values. The channel under the mouse is drawn; Option draws all channels. Stroke is collected as points, turned into one value per sample on mouse up (`commitStroke`) and written by `AudioRangeEdit::draw` (new `DrawnSamples`); only the pieces under the drawing get a new media file (`AudioProcessor::processClipWith`). One undo step ("Draw Samples"). Test: `testDrawSamples`.

## New look (complete): calm dark metal, wooden side bar, light displays
- **Colours** (`app/SilvetonTheme.h`): blue-grey surfaces (canvas 0x1E2025, panels 0x23262C, keys 0x383C44 / 0x4A4E58). `copper()` is the one bright amber (0xFFB347) and means ON / selected (playing, cycle, selection, playhead, lit keys). `gold()` = wordmark, section titles, lit page keys. Green / yellow / red are muted; meter zones have their own colours. Mute is red, Solo yellow. Helpers: `keyCap` (hardware key, lit keys sink and glow), `lcd` (dark display glass), `wellFill` (sunken slot), `faderCap` (black cap, white line).
- **Window**: walnut side bar on the left (`SilvetonSideBar`: wordmark written downwards, keys PROJECT / MIX / EDIT / LIBRARY / SETUP; SETUP opens Audio System Setup). Transport deck on top (`SilvetonTransportDeck`): POSITION and TEMPO displays, keys (marker back, bar back, stop, play, record, bar forward, marker forward | CYCLE, CLICK, SNAP, + MARK), LOCATORS (cycle range) and PROJECT displays when the window is wide enough, master level display on the right. Status bar along the bottom (`SilvetonPageBar`): message left, project name and sample rate right.
- **Project page** (`SilvetonDock.mm`, `layoutArrangePage` in `SilvetonApp.mm`): Inspector | tool row (SNAP, GRID 1/4..1/32 menu, track HEIGHT S/M/L/XL, ZOOM TRACK, ZOOM slider, switches INSPECTOR / MIXER / LEVEL) over the tracks, a compact mixer under them (`SilvetonConsoleView.compact`: 3 inserts, M/S, pan, fader, level display, strip name), level panel on the right (`SilvetonMeterPanel`: master peak read-out, big stereo meter, details of the selected clip / part / track including file rate -> live rate). View menu: "Mixer Under the Tracks", "Level Panel". All three panels can be switched off.
- **Tracks**: clips and MIDI parts have a dark body, grey title bar with a thin line in the calmed track colour, soft waveform; calmed colours for header stripes, markers and sections; amber playhead and cycle.
- **MixConsole page**: dark strips, black fader caps with a white line, dark slots with an amber lamp for active inserts, round pan knob, light display for the level read-out. Buttons and toggles in all panels are key caps (`SVButton`, `SVToggle`); tables, sample editor and key editor use the same palette.
- **Not done on purpose**: no KEY page (no separate key editor yet, task #19); no tools that do not exist in the program (Trim, Spot, Nudge, groups, Live Loops).

## Tone Editor (Silveton's answer to VariAudio), Key Editor upgrade and mixer details

Not yet compiled on a real Mac — the AppKit files are syntax-checked only; the next GitHub run compiles them.

- **Tone Editor** (Edit page, `WAVE | TONE` switch, shortcut T, clip menu "Open in Tone Editor"). Core, all with tests (`silveton_tone_editor_tests`): pitch tracking (YIN + Viterbi), splitting into notes, per-note pitch/time/formant/volume, drift and vibrato handling, scale detection and scale fit, time warp, PSOLA re-synthesis with formant preservation, MIDI extraction, save inside the project (undoable, relinks with the media). Tools: Select, Time, Cut, Glue, Erase, Draw. The source file is never changed; the edited sound is a separate file next to the project.
- **Key Editor** (note grid rewritten, `silveton_key_editing_tests`): 7 tools (Select, Draw, Erase, Cut, Glue, Mute, Line), rubber band, move/copy with Option, resize, velocity bars, up to 4 controller lanes (velocity, any CC, pitch bend, aftertouch) with the Line tool shapes (line, parabola, sine, triangle, square), reduce lane, chord drawing, fit-to-scale, glue/cut/mute, listen to a note while editing (audition ring in `MidiInput`, never recorded).
- **Bus meters**: Group and FX channels now show real levels (after their fader). `AudioEngine::takeBusPeaks`, `MeterBank::feedBus`, test in `silveton_live_mixer_tests`.
- **DSP load** shown next to the master meter (`DawAudioCallback::dspLoad`).
- **Normalize** works across a selection that spans several pieces (shared peak, same gain for every piece).
- **Automation mode** change rebuilds the graph so Read/Write/Touch/Latch take effect at once.
- **Nudge**: Option+[ and Option+] move the selected clip or MIDI part by one grid step (Edit menu).
- **Type scale** raised: caption 11, label 12, body 13, title 14, heading 16 pt (the smallest text is 11 pt now).
- Recording rate path checked: the recorded file keeps the card's own rate and the engine converts, same as playback.
- Still unknown: why Play sometimes does nothing on the iMac. Needs the text of the bottom-left status line right after pressing Play.

## Lower zone: the editor lives under the tracks (as the Lower Zone of Cubase)

- The Project page has a lower zone under the tracks with two tabs: MIXER (the compact mixer, as before) and EDITOR (Sample / Tone / Key Editor of the selected clip or part). The whole project stays visible above it, so clips can be moved and copied between tracks while editing. The editor follows the selection in the tracks.
- Double-click on a clip / part, Enter and "Open in … Editor" open the editor under the tracks. The EDIT key on the side bar (F4) shows the same editor on a full page; FULL PAGE / IN PROJECT on the editor's strip switches between the two.
- The height of the zone is dragged at its bar (grip in the middle). HIDE closes it; the tool row has INSPECTOR | MIXER | EDITOR | LEVEL keys. View menu: Editor Under the Tracks (Option+E), Mixer Under the Tracks, Hide Lower Zone.
- Delete, Cut, Copy, Paste, Duplicate, Mute and Select All go to the area that was clicked last: the editor under the tracks, or the tracks. (`editorFocused` in `SilvetonApp.mm`.)
- The editor's strip lays itself out for the narrower zone (title, swing, grid, WAVE/TONE, FULL PAGE); the swing control is left out when the strip is narrower than 760 px.

## Project window arranged as in Cubase (after the user's screenshot)

- **Inspector with two tabs**: TRACK (the selected track: fader, routing, inserts, sends, notepad) and EDITOR (the settings of the open editor: Sample / Tone / Key). The tab follows the click — in the tracks → TRACK, in the editor → EDITOR — and can be chosen by hand. The editor's panels moved out of the editor into this column, so the editor under the tracks has the full width.
- **Sections fold**: every inspector section bar (▾ / ▸) folds and opens on a click; what is below moves up (`SVSectionStack` in `SilvetonPanels.mm`, used by all inspector panels).
- **Info line** under the tool row: file, start, end, length, fade in / out, gain, mute, file rate of the selected clip (part: notes, start, end, length, mute, loop). Double-click fades / gain / mute to change them.
- **Lower zone** as in Cubase: a thin splitter above it (drag for the height) and the tabs MIXER | EDITOR along its bottom edge, FULL PAGE and HIDE on the right.
- **Full page editor** (EDIT key / F4): the same inspector column on the left, the editor on the right.
- **Tone Editor**: blocks are coloured by note (as VariAudio segments), the pitch lines are drawn over the blocks (white = sung, amber = corrected), and the sound is drawn faintly behind the grid.
- MIDI parts can be muted from the info line / Mute command (`toggleClipMute:` handles parts too).

## Less on the screen (after "too much, cluttered")

- Transport deck: POSITION, TEMPO, the transport keys, CYCLE, CLICK, LOCATORS and the master meter. The PROJECT block and the SNAP / + MARK keys are gone (SNAP is in the tool row, the project name is in the title bar and the status line, the DSP figure moved to the status line).
- Tool row keys on the right: INSPECTOR | LOWER ZONE | LEVEL (one key for the zone; MIXER / EDITOR are its tabs).
- Quiet defaults: the lower zone and the level panel are hidden until asked for; the editor opens the zone on a double-click.
- Editor strip: title, grid, WAVE / TONE, FULL PAGE — the swing slider is gone (swing is in Quantize Setup, and the iterative quantize uses that).
- Tone Editor under the tracks is compact: no wave strip and no read-out line (the sound is behind the grid; what is under the mouse is written in the strip title). The full page keeps both.
- Inspector sections folded by default: SENDS, NOTEPAD (track); CLIP, QUANTIZE (sample); COLOUR AND LOUDNESS, TIME, MIDI, LISTENING (tone); SELECT AND EDIT, QUANTIZE, FUNCTIONS, TRANSPOSE, VIEW (key).

## One home for everything (`PROGRAM_MAP.md`)

- `PROGRAM_MAP.md` says where every function lives: pages, the parts of the Project page, the three editors, the menus.
- Menus regrouped with submenus: Edit (Nudge ›, Select ›), Audio (Process ›, Clip ›, Sample Editor ›, Tone Editor ›), MIDI (More Quantize ›, Functions ›, Transpose ›, Key Editor ›). The Tone Editor commands are now in the menu bar too.
- Names unified: Key Editor (not "Note Editor"), Mixer (not "MixConsole"), Editor (Full Page).

## Console look (after "like an expensive console")

- New drawing helpers in `SilvetonTheme.h`: `brushedPanel` (dark brushed metal with bevelled edges), `sunkenWell`, `engraved` / `engravedIn` legends, `consoleKey` (grey key with a top highlight and a corner LED; lit = the key's colour glows), `consoleKnob` (chrome knob with a tick scale and the value arc), `consoleFaderCap` (machined cap with ridges and a centre line).
- Mixer strips (`SilvetonEditors.mm`) rebuilt as console channels: colour LED bar and a sunken name plate, INSERTS and SENDS wells with LEDs, the pan knob with L/C/R read-out, MUTE / SOLO keys, fader groove with an engraved dB legend, LED meters in a black window with a scale, gain read-out display, output legend. Strips are 116 px with a 4 px groove between them; the master is the warm panel on the right. The compact mixer under the tracks uses the same drawing with fewer rows.
- Track headers in the Project window use the same language: brushed plates, engraved names, console keys for M / S / ● / I, a small fader with a cap, the level meter in a window.
- The Project page in the same look: the transport deck, tool row, inspector tabs, lower-zone tabs and status line are brushed rails (`sv::rail`), the ruler / markers / arranger rows are brushed with engraved legends, inspector section bars are bevelled plates, clips and parts are filled in the track's colour (dark body, lighter title bar, coloured outline, light waveform).

## Soft console look kept; plug-in menu by vendor

- The Pro Tools restyle was reverted (the user wants the metal console look). The console helpers now draw real gradients (`NSGradient`) instead of 2 px bands, so panels, keys, caps and knobs render smooth on the Mac. Corners are soft: panels 8 px, wells 5–7 px, keys 6 px, fader caps 6 px; strips are 8 px apart with a soft shadow.
- Insert menu (`insertMenuForStrip:`): Silveton Native by category, then VST3 grouped in a submenu per vendor (A-Z, with the count), inside by category (Instruments, EQ & Filter, Dynamics, Reverb, Delay, Modulation, Distortion & Amps, Spatial, Tools, Other) and name; the Library list is sorted the same way.
- The rest of the program follows the soft look: inspector section bars are rounded plates with a gradient, SVButton / SVToggle keys are 6 px round, track headers are rounded panels with a rounded colour bar, clips and parts are 6 px round, the editor strip is a rail.
