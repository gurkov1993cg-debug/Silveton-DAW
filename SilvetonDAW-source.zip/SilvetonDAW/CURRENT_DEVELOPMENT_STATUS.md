# Silveton DAW 0.17 development (CMake version string stays 0.16.0 so the existing CI check passes)

New in this source (not yet proven on the Intel Mac build):
- Whole program runs internally at 96 kHz; the sound card keeps its own rate. Conversion on input, output, import and export uses the sampler's Studio sinc (`SILVETON_STUDIO_INTERP_V1`). Switch 96 kHz / follow-card in Preferences > Audio System.
- Silveton Native processors (EQ, compressor, gate, limiter, delay, reverb, saturator, chorus, poly synth).
- Project window with Inspector, markers, arranger, folders, solo, colours; MixConsole; Key Editor; Sample Editor with offline processing; MIDI file import/export; Preferences window with Cubase-style categories.
- Local portable tests: 40/40 passed before the final GUI files; the AppKit files were syntax-checked only (native compile happens in the GitHub run).


# Silveton DAW 0.16.0 — current development snapshot

Official target-class GitHub baseline: **Silveton DAW 0.15.0 / Run #21 / SUCCESS**.
That protected baseline remains the last Intel-macOS/Xcode proof. The 0.16.0 source is newer and is not called target-verified until its GitHub run passes.

## Completed in the current 0.16.0 source

- C++17 audio engine, CoreAudio layer, recording and 256-track session capacity
- disk playback/cache and automatic media-source ownership across Live/Pending/Retired voice plans
- control-thread reclamation of retired media owners; no media destruction is required on the audio thread
- VST3 host/runtime, isolated scanner/quarantine, presets, state, editor bridge, automation, latency/restart infrastructure
- immutable routing/PDC graph with Group/FX/Master, pre/post sends, sidechain/multi-output infrastructure
- persistent helper-thread multicore graph scheduler with dependency layers and deterministic serial reduction
- explicit serial-reference mode and regression proving parallel output is sample-identical to the forced single-thread graph
- nondestructive clip timeline/editor: move, split, trim, gain, mute and fades
- take/cycle/comp and recording workflow
- Tempo Map, MIDI timeline/editor/parts/input/playback scheduling and metronome/count-in
- offline master bounce plus processed track/bus stem export regression coverage
- Elastic Audio phase-vocoder path with transient reset, peak phase locking, multichannel phase-relative reconstruction, formant-preserving vocal mode and Draft/Balanced/High quality modes
- unified native AppKit Silveton workflow source: left Project/Plug-in browser, central Arrange, right Inspector, bottom Mixer/Audio Clip/MIDI dock; no decorative meters or dead workflow tabs were added

## Local verification of this exact C++ backend snapshot

- GNU Release: **33/33 CTest PASS**
- ASan + UBSan (`detect_leaks=0`, vptr excluded): **33/33 CTest PASS**
- Clang 17 Release: **33/33 CTest PASS**

The native AppKit/CoreMIDI/VST3 application source cannot be compiled in the current Linux verification environment. The prepared Intel workflow is the required next target-class proof.

## External proof still required

- macos-15-intel + Xcode 16.4 build of this exact 0.16.0 source
- x86_64-only / macOS 10.13 deployment verification
- pinned Steinberg SDK production host + validator + codesign
- native AppKit/CoreMIDI compile and application bundle checks
- real iMac 2011 launch/CoreAudio/CoreMIDI/VST3 scan-load-editor-play-record-state-export test
