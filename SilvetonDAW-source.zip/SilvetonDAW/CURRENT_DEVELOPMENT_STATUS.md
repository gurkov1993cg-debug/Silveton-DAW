# Silveton DAW 0.15.0 candidate — current development status

## GitHub-proven baseline
GitHub Actions Run #19 is the latest proven Intel macOS baseline. It proves 0.9.0 on macos-15-intel / Xcode 16.4 / x86_64 / macOS 10.13.

## Current local candidate
The current source tree consolidates the later work into one physical project and passes 22/22 tests in Release, ASan+UBSan and Clang builds.

Implemented in the current candidate:
- audio engine, disk streaming, recording and 256-track capacity foundation
- VST3 host/runtime, live graph replacement, routing and PDC
- Group/FX/Master routing, inserts, sends and mixer automation
- nondestructive audio clips and clip editing
- cycle, take lanes/comp and recording workflow
- Tempo Map and time-signature changes
- MIDI timeline/input and scheduled VST3 MIDI
- metronome/count-in and sample-accurate punch recording
- offline master bounce with preroll/tails and VST3 offline processing mode

Current verification:
- Release: 22/22 PASS
- ASan+UBSan: 22/22 PASS
- Clang: 22/22 PASS

Boundaries:
- this exact candidate is not Intel-macOS verified until a new GitHub run succeeds
- real iMac 2011 host/hardware behavior still requires scan/load/open/play/record/export testing
- StemBounce source is present but is not counted as verified without dedicated regression coverage
- complete multicore scheduling, full MIDI editor/workflow, final elastic-audio quality, full GUI and final recovery/application polish remain future work
