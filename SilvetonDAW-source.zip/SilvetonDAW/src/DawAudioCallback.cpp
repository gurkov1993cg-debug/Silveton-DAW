#include "silveton/DawAudioCallback.h"
#include <algorithm>
namespace silveton {
DawAudioCallback::DawAudioCallback(AudioEngine&e,Vst3RuntimeRack&r,MidiPlaybackScheduler&m,MidiInputCapture&i,RealtimeClockMapper&c) noexcept:engine_(e),rack_(r),midi_(m),input_(i),clock_(c){}
void DawAudioCallback::updateDeviceTime(const AudioDeviceTimeInfo& info) noexcept {if(info.hostTimeValid)pendingHostTime_.store(info.hostTime,std::memory_order_release);}
void DawAudioCallback::processAudio(const float* const* inputs,float* const* outputs,std::uint32_t inputChannels,std::uint32_t outputChannels,std::uint32_t frames) noexcept {
    RealtimeLifecycleAudioGuard lifecycle(lifecycleGate_);
    if (!lifecycle.entered()) {
        if (outputs != nullptr) {
            for (std::uint32_t c=0U;c<outputChannels;++c)
                if (outputs[c] != nullptr) std::fill(outputs[c], outputs[c] + frames, 0.0F);
        }
        return;
    }

    // One block boundary for graph, voice/tempo state and VST3 MIDI ownership.
    // This avoids a one-block window where MIDI could target the instance from
    // the predecessor graph while audio already processes its replacement.
    engine_.adoptPendingRealtimeStateAtBlockBoundary();
    rack_.adoptPublicationStateAtBlockBoundary();

    const std::int64_t blockStart=engine_.transport().positionSamples();
    const std::uint64_t host=pendingHostTime_.exchange(0U,std::memory_order_acq_rel);
    if(host!=0U)clock_.update(host,blockStart,engine_.deviceConfig().sampleRate);
    rack_.queueAutomationForBlock(blockStart,frames);
    (void)midi_.queueBlock(rack_,&input_,blockStart,frames);
    engine_.processAudio(inputs,outputs,inputChannels,outputChannels,frames);
    rack_.serviceOutputParameters();
}
} // namespace silveton
