#include "silveton/CoreMidiInput.h"
#if defined(__APPLE__)
#include <CoreMIDI/CoreMIDI.h>
#include <CoreFoundation/CoreFoundation.h>
#include <mach/mach_time.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <stdexcept>
#include <utility>

namespace silveton { namespace {
std::string cfString(CFStringRef s){if(!s)return{};char b[512]{};return CFStringGetCString(s,b,sizeof(b),kCFStringEncodingUTF8)?std::string(b):std::string();}
std::string endpointName(MIDIEndpointRef e){CFStringRef s=nullptr;std::string r;if(MIDIObjectGetStringProperty(e,kMIDIPropertyDisplayName,&s)==noErr&&s){r=cfString(s);CFRelease(s);}return r;}
}
class CoreMidiInput::Impl{
public:
    static constexpr std::size_t kMaxSources=32U;
    struct Parser { std::uint8_t running{0U},data[2]{0U,0U},needed{0U},count{0U}; };
    Impl(MidiInputCapture& c,RealtimeClockMapper& clock):capture(c),clockMapper(clock){
        mach_timebase_info_data_t tb{};if(mach_timebase_info(&tb)==KERN_SUCCESS&&tb.numer!=0U){const double nsPerTick=static_cast<double>(tb.numer)/static_cast<double>(tb.denom);clockMapper.setHostTicksPerSecond(1.0e9/nsPerTick);} 
        if(MIDIClientCreate(CFSTR("Silveton MIDI"),nullptr,nullptr,&client)!=noErr)throw std::runtime_error("CoreMIDI client creation failed");
        if(MIDIInputPortCreate(client,CFSTR("Silveton Input"),&Impl::readProc,this,&port)!=noErr){MIDIClientDispose(client);client=0;throw std::runtime_error("CoreMIDI input port creation failed");}
    }
    ~Impl(){disconnectAll();if(port)MIDIPortDispose(port);if(client)MIDIClientDispose(client);}
    static std::uint8_t dataCount(std::uint8_t status) noexcept {const auto t=status&0xF0U;return (t==0xC0U||t==0xD0U)?1U:((t>=0x80U&&t<=0xE0U)?2U:0U);}
    void feed(std::size_t source,std::uint8_t byte,std::uint64_t host){if(source>=kMaxSources)return;auto& p=parsers[source];if(byte>=0xF8U)return;if((byte&0x80U)!=0U){if(byte>=0xF0U){p={};return;}p.running=byte;p.needed=dataCount(byte);p.count=0U;return;}if(p.running==0U||p.needed==0U)return;p.data[p.count++]=byte;if(p.count>=p.needed){TimedMidiInputEvent e;e.port=targetPort.load(std::memory_order_acquire);e.sample=std::max<std::int64_t>(0,clockMapper.projectSampleAtHostTime(host));e.status=p.running;e.data1=p.data[0];e.data2=p.needed>1U?p.data[1]:0U;if(e.port>=0)(void)capture.pushRealtime(e);p.count=0U;}}
    static void readProc(const MIDIPacketList* list,void* ref,void* conn){auto*self=static_cast<Impl*>(ref);const std::size_t source=static_cast<std::size_t>(reinterpret_cast<std::uintptr_t>(conn));const MIDIPacket* packet=&list->packet[0];for(UInt32 pi=0;pi<list->numPackets;++pi){const std::uint64_t host=packet->timeStamp==0U?mach_absolute_time():packet->timeStamp;for(UInt16 i=0;i<packet->length;++i)self->feed(source,packet->data[i],host);packet=MIDIPacketNext(packet);}}
    void connectAll(){disconnectAll();const ItemCount n=std::min<ItemCount>(MIDIGetNumberOfSources(),kMaxSources);connected.fill(false);for(ItemCount i=0;i<n;++i){MIDIEndpointRef e=MIDIGetSource(i);if(e&&MIDIPortConnectSource(port,e,reinterpret_cast<void*>(static_cast<std::uintptr_t>(i)))==noErr)connected[static_cast<std::size_t>(i)]=true;}}
    void disconnectAll() noexcept {const ItemCount n=std::min<ItemCount>(MIDIGetNumberOfSources(),kMaxSources);for(ItemCount i=0;i<n;++i)if(connected[static_cast<std::size_t>(i)]){MIDIEndpointRef e=MIDIGetSource(i);if(e)(void)MIDIPortDisconnectSource(port,e);connected[static_cast<std::size_t>(i)]=false;}}
    std::vector<CoreMidiSourceInfo> sources() const {std::vector<CoreMidiSourceInfo> r;const ItemCount n=std::min<ItemCount>(MIDIGetNumberOfSources(),kMaxSources);r.reserve(n);for(ItemCount i=0;i<n;++i){MIDIEndpointRef e=MIDIGetSource(i);r.push_back({static_cast<std::uint32_t>(i),endpointName(e),connected[static_cast<std::size_t>(i)]});}return r;}
    MidiInputCapture& capture;RealtimeClockMapper& clockMapper;MIDIClientRef client{0};MIDIPortRef port{0};std::array<Parser,kMaxSources> parsers{};std::array<bool,kMaxSources> connected{};std::atomic<int> targetPort{-1};
};
CoreMidiInput::CoreMidiInput(MidiInputCapture&c,RealtimeClockMapper&clock):impl_(std::make_unique<Impl>(c,clock)){}
CoreMidiInput::~CoreMidiInput()=default;std::vector<CoreMidiSourceInfo> CoreMidiInput::sources()const{return impl_->sources();}void CoreMidiInput::connectAll(){impl_->connectAll();}void CoreMidiInput::disconnectAll()noexcept{impl_->disconnectAll();}void CoreMidiInput::setTargetPort(int p)noexcept{impl_->targetPort.store(p,std::memory_order_release);}int CoreMidiInput::targetPort()const noexcept{return impl_->targetPort.load(std::memory_order_acquire);}
} // namespace silveton
#endif
