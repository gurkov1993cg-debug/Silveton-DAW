#include "silveton/ToneProject.h"

#include "silveton/ProjectMediaRelinker.h"
#include "silveton/WavFile.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <stdexcept>

namespace silveton {

namespace {

std::string safeName(const std::string& text) {
    std::string out;
    for (const char c : text) {
        const bool ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '-' || c == '_';
        out += ok ? c : '_';
    }
    return out.empty() ? std::string("sound") : out;
}

const ProjectAudioClip* findClip(const Project& project, std::size_t trackIndex, std::uint64_t clipId, const ProjectTrack** trackOut) {
    if (trackIndex >= project.tracks.size()) return nullptr;
    const auto& track = project.tracks[trackIndex];
    for (const auto& c : track.clips)
        if (c.id == clipId) { if (trackOut) *trackOut = &track; return &c; }
    return nullptr;
}

std::uint32_t projectRate(const Project& project) {
    return static_cast<std::uint32_t>(std::llround(project.sampleRate));
}

} // namespace

const ProjectToneRecord* ToneProject::find(const Project& project, const std::string& renderedPath) noexcept {
    if (renderedPath.empty()) return nullptr;
    for (const auto& r : project.toneRecords)
        if (r.renderedPath == renderedPath) return &r;
    return nullptr;
}

bool ToneProject::referenced(const Project& project, const std::string& path) noexcept {
    if (path.empty()) return false;
    for (const auto& track : project.tracks) {
        if (track.clips.empty() && track.audioPath == path) return true;
        for (const auto& c : track.clips) if (c.audioPath == path) return true;
        for (const auto& lane : track.takeLanes)
            for (const auto& c : lane.clips) if (c.audioPath == path) return true;
    }
    return false;
}

ToneSource ToneProject::sourceFor(const Project& project, std::size_t trackIndex, std::uint64_t clipId) {
    const ProjectTrack* track = nullptr;
    const ProjectAudioClip* clip = findClip(project, trackIndex, clipId, &track);
    if (!clip) throw std::invalid_argument("Tone Editor: the clip was not found");
    const std::string path = clip->audioPath.empty() ? track->audioPath : clip->audioPath;
    ToneSource source;
    const ProjectToneRecord* record = find(project, path);
    if (record && record->rate == projectRate(project) && record->originalLength > 0U) {
        source.path = record->originalPath;
        source.start = record->originalStart;
        source.length = record->originalLength;
        source.fromRecord = true;
        source.options.lowestHz = record->lowestHz;
        source.options.highestHz = record->highestHz;
        source.options.sensitivity = record->sensitivity;
        source.options.splitSensitivity = record->splitSensitivity;
        source.options.minBlockMs = record->minBlockMs;
        return source;
    }
    source.path = path;
    source.start = clip->sourceStartSample;
    source.length = clip->lengthSamples;
    return source;
}

bool ToneProject::savedEdit(const Project& project, std::size_t trackIndex, std::uint64_t clipId, ToneEdit& out) {
    const ProjectTrack* track = nullptr;
    const ProjectAudioClip* clip = findClip(project, trackIndex, clipId, &track);
    if (!clip) return false;
    const ProjectToneRecord* record = find(project, clip->audioPath.empty() ? track->audioPath : clip->audioPath);
    if (!record || record->rate != projectRate(project)) return false;
    try {
        out = toneEditFromLines(record->editLines);
    } catch (const std::exception&) {
        return false;
    }
    return true;
}

AudioBuffer ToneProject::readSource(const ToneSource& source, double rate) {
    if (source.path.empty() || source.length == 0U) throw std::runtime_error("Tone Editor: there is no sound to work on");
    std::uint32_t fileRate = 0U;
    const AudioBuffer whole = ProjectMediaRelinker::readWholeSource(source.path, fileRate, rate);
    if (source.start >= whole.frames()) throw std::runtime_error("Tone Editor: the clip lies outside its sound file");
    return AudioEditor::trim(whole, source.start, source.length);
}

std::string ToneProject::writeRendered(const AudioBuffer& rendered, double rate, const std::string& originalPath, const std::string& directory) {
    if (rendered.frames() == 0U) throw std::runtime_error("Tone Editor: the result is empty");
    static std::atomic<std::uint64_t> counter {0U};
    const auto stamp = static_cast<unsigned long long>(
        std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count());
    std::string base = originalPath;
    const auto slash = base.find_last_of("/\\");
    if (slash != std::string::npos) base = base.substr(slash + 1U);
    const auto dot = base.find_last_of('.');
    if (dot != std::string::npos) base = base.substr(0U, dot);
    std::string dir = directory.empty() ? std::string(".") : directory;
    if (dir.back() == '/' || dir.back() == '\\') dir.pop_back();
    const std::string path = dir + "/" + safeName(base) + "_Tone_" + std::to_string(stamp) + "_" + std::to_string(++counter) + ".wav";
    WavFile::writeFloat32(path, static_cast<std::uint32_t>(std::llround(rate)), rendered);
    return path;
}

void ToneProject::commit(Project& project, std::size_t trackIndex, std::uint64_t clipId, const ToneSource& source, const ToneEdit& edit,
                         const std::string& renderedPath, std::uint64_t renderedFrames, std::uint32_t renderedChannels) {
    if (trackIndex >= project.tracks.size()) throw std::out_of_range("Tone Editor: track");
    auto& track = project.tracks[trackIndex];
    if (track.locked) throw std::runtime_error("The track is locked.");
    auto it = std::find_if(track.clips.begin(), track.clips.end(), [&](const ProjectAudioClip& c) { return c.id == clipId; });
    if (it == track.clips.end()) throw std::invalid_argument("Tone Editor: the clip was not found");
    ProjectAudioClip& clip = *it;
    if (renderedPath.empty() || renderedFrames == 0U) throw std::invalid_argument("Tone Editor: nothing was rendered");

    const std::string oldPath = clip.audioPath.empty() ? track.audioPath : clip.audioPath;
    // The clip may already show only a part of an earlier render of this same original; that part stays,
    // because a render always has exactly the length of the original (a time bend never changes it).
    const ProjectToneRecord* old = find(project, oldPath);
    const bool keepView = old != nullptr && old->rate == projectRate(project) && old->originalPath == source.path &&
                          old->originalStart == source.start && old->originalLength == source.length &&
                          renderedFrames == source.length && clip.sourceStartSample < renderedFrames;

    clip.audioPath = renderedPath;
    clip.sourceFrames = renderedFrames;
    clip.sourceChannels = renderedChannels;
    clip.sourceSampleRate = projectRate(project);
    if (keepView) {
        clip.lengthSamples = std::min<std::uint64_t>(clip.lengthSamples, renderedFrames - clip.sourceStartSample);
    } else {
        clip.sourceStartSample = 0U;
        clip.lengthSamples = renderedFrames;
        clip.fadeInAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
        clip.fadeOutAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
    }
    clip.fadeInSamples = std::min(clip.fadeInSamples, clip.lengthSamples);
    clip.fadeOutSamples = std::min(clip.fadeOutSamples, clip.lengthSamples);

    ProjectToneRecord record;
    record.renderedPath = renderedPath;
    record.originalPath = source.path;
    record.originalStart = source.start;
    record.originalLength = source.length;
    record.rate = projectRate(project);
    record.lowestHz = source.options.lowestHz;
    record.highestHz = source.options.highestHz;
    record.sensitivity = source.options.sensitivity;
    record.splitSensitivity = source.options.splitSensitivity;
    record.minBlockMs = source.options.minBlockMs;
    record.editLines = toneEditToLines(edit);
    // The record of the file the clip played before is not needed any more, unless another clip still plays it.
    if (!referenced(project, oldPath)) {
        project.toneRecords.erase(std::remove_if(project.toneRecords.begin(), project.toneRecords.end(),
                                                 [&](const ProjectToneRecord& r) { return r.renderedPath == oldPath; }),
                                  project.toneRecords.end());
    }
    project.toneRecords.push_back(std::move(record));
}

void ToneProject::prune(Project& project) {
    project.toneRecords.erase(std::remove_if(project.toneRecords.begin(), project.toneRecords.end(),
                                             [&](const ProjectToneRecord& r) { return !referenced(project, r.renderedPath); }),
                              project.toneRecords.end());
}

} // namespace silveton
