#include "silveton/MidiTimeline.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace silveton {

void MidiSequence::validateNote(const MusicalMidiNote& note) {
    if (!std::isfinite(note.startQuarterNotes) || note.startQuarterNotes < 0.0)
        throw std::invalid_argument("MIDI note start must be finite and non-negative");
    if (!std::isfinite(note.durationQuarterNotes) || note.durationQuarterNotes <= 0.0)
        throw std::invalid_argument("MIDI note duration must be finite and positive");
    if (note.channel > 15U || note.pitch > 127U || note.velocity > 127U || note.releaseVelocity > 127U)
        throw std::invalid_argument("MIDI note field out of range");
}

void MidiSequence::validateMessage(const MusicalMidiMessage& message) {
    if (!std::isfinite(message.quarterNotes) || message.quarterNotes < 0.0)
        throw std::invalid_argument("MIDI message position must be finite and non-negative");
    const std::uint8_t type = static_cast<std::uint8_t>(message.status & 0xF0U);
    if (type < 0xA0U || type > 0xE0U)
        throw std::invalid_argument("MIDI message type must be a non-note channel message");
    if (message.data1 > 127U || message.data2 > 127U)
        throw std::invalid_argument("MIDI message field out of range");
}

std::uint64_t MidiSequence::addMessage(MusicalMidiMessage message) {
    validateMessage(message);
    if (message.id == 0U) {
        if (nextMessageId_ == 0U) throw std::overflow_error("MIDI message ID space exhausted");
        message.id = nextMessageId_++;
    } else {
        const auto duplicate = std::find_if(messages_.begin(), messages_.end(), [&](const MusicalMidiMessage& m) {
            return m.id == message.id;
        });
        if (duplicate != messages_.end()) throw std::invalid_argument("duplicate MIDI message ID");
        if (message.id >= nextMessageId_) {
            if (message.id == std::numeric_limits<std::uint64_t>::max()) nextMessageId_ = 0U;
            else nextMessageId_ = message.id + 1U;
        }
    }
    messages_.push_back(message);
    std::stable_sort(messages_.begin(), messages_.end(), [](const MusicalMidiMessage& a, const MusicalMidiMessage& b) {
        if (a.quarterNotes != b.quarterNotes) return a.quarterNotes < b.quarterNotes;
        return a.id < b.id;
    });
    return message.id;
}

bool MidiSequence::removeMessage(std::uint64_t id) noexcept {
    const auto oldSize = messages_.size();
    messages_.erase(std::remove_if(messages_.begin(), messages_.end(), [id](const MusicalMidiMessage& message) {
        return message.id == id;
    }), messages_.end());
    return messages_.size() != oldSize;
}

MusicalMidiNote* MidiSequence::find(std::uint64_t id) noexcept {
    auto it = std::find_if(notes_.begin(), notes_.end(), [id](const MusicalMidiNote& note) { return note.id == id; });
    return it == notes_.end() ? nullptr : &*it;
}

std::uint64_t MidiSequence::addNote(MusicalMidiNote note) {
    validateNote(note);
    if (note.id == 0U) {
        if (nextId_ == 0U) throw std::overflow_error("MIDI note ID space exhausted");
        note.id = nextId_++;
    } else {
        if (find(note.id) != nullptr) throw std::invalid_argument("duplicate MIDI note ID");
        if (note.id >= nextId_) {
            if (note.id == std::numeric_limits<std::uint64_t>::max()) nextId_ = 0U;
            else nextId_ = note.id + 1U;
        }
    }
    notes_.push_back(note);
    std::stable_sort(notes_.begin(), notes_.end(), [](const MusicalMidiNote& a, const MusicalMidiNote& b) {
        if (a.startQuarterNotes != b.startQuarterNotes) return a.startQuarterNotes < b.startQuarterNotes;
        return a.id < b.id;
    });
    return note.id;
}

bool MidiSequence::removeNote(std::uint64_t id) noexcept {
    const auto oldSize = notes_.size();
    notes_.erase(std::remove_if(notes_.begin(), notes_.end(), [id](const MusicalMidiNote& note) { return note.id == id; }), notes_.end());
    return notes_.size() != oldSize;
}

bool MidiSequence::moveNote(std::uint64_t id, double startQuarterNotes) {
    MusicalMidiNote* note = find(id);
    if (note == nullptr) return false;
    if (!std::isfinite(startQuarterNotes) || startQuarterNotes < 0.0)
        throw std::invalid_argument("MIDI note start must be finite and non-negative");
    note->startQuarterNotes = startQuarterNotes;
    std::stable_sort(notes_.begin(), notes_.end(), [](const MusicalMidiNote& a, const MusicalMidiNote& b) {
        if (a.startQuarterNotes != b.startQuarterNotes) return a.startQuarterNotes < b.startQuarterNotes;
        return a.id < b.id;
    });
    return true;
}

bool MidiSequence::resizeNote(std::uint64_t id, double durationQuarterNotes) {
    MusicalMidiNote* note = find(id);
    if (note == nullptr) return false;
    if (!std::isfinite(durationQuarterNotes) || durationQuarterNotes <= 0.0)
        throw std::invalid_argument("MIDI note duration must be finite and positive");
    note->durationQuarterNotes = durationQuarterNotes;
    return true;
}

void MidiSequence::quantize(double divisionsPerQuarter, double strength) {
    if (!std::isfinite(divisionsPerQuarter) || divisionsPerQuarter <= 0.0)
        throw std::invalid_argument("MIDI quantize division must be positive");
    if (!std::isfinite(strength) || strength < 0.0 || strength > 1.0)
        throw std::invalid_argument("MIDI quantize strength must be in [0, 1]");
    for (auto& note : notes_) {
        const double target = std::round(note.startQuarterNotes * divisionsPerQuarter) / divisionsPerQuarter;
        note.startQuarterNotes += (target - note.startQuarterNotes) * strength;
        if (note.startQuarterNotes < 0.0) note.startQuarterNotes = 0.0;
    }
    std::stable_sort(notes_.begin(), notes_.end(), [](const MusicalMidiNote& a, const MusicalMidiNote& b) {
        if (a.startQuarterNotes != b.startQuarterNotes) return a.startQuarterNotes < b.startQuarterNotes;
        return a.id < b.id;
    });
}

void MidiSequence::transpose(int semitones) noexcept {
    for (auto& note : notes_) {
        const int pitch = std::clamp(static_cast<int>(note.pitch) + semitones, 0, 127);
        note.pitch = static_cast<std::uint8_t>(pitch);
    }
}

MidiRenderPlan MidiSequence::compile(const TempoMap& tempoMap) const {
    MidiRenderPlan plan;
    if (notes_.size() > plan.events_.max_size() / 2U)
        throw std::length_error("MIDI render plan too large");
    const std::size_t noteEvents = notes_.size() * 2U;
    if (messages_.size() > plan.events_.max_size() - noteEvents)
        throw std::length_error("MIDI render plan too large");
    plan.events_.reserve(noteEvents + messages_.size());
    for (const auto& note : notes_) {
        validateNote(note);
        if (note.muted) continue;
        const std::int64_t on = tempoMap.sampleAtQuarterNotes(note.startQuarterNotes);
        const std::int64_t off = tempoMap.sampleAtQuarterNotes(note.startQuarterNotes + note.durationQuarterNotes);
        if (off <= on) continue;
        const std::uint8_t channel = static_cast<std::uint8_t>(note.channel & 0x0FU);
        plan.events_.push_back({on, 0, static_cast<std::uint8_t>(0x90U | channel), note.pitch, note.velocity});
        plan.events_.push_back({off, 0, static_cast<std::uint8_t>(0x80U | channel), note.pitch, note.releaseVelocity});
    }
    for (const auto& message : messages_) {
        validateMessage(message);
        if (message.muted) continue;
        const std::int64_t sample = tempoMap.sampleAtQuarterNotes(message.quarterNotes);
        plan.events_.push_back({sample, 0, message.status, message.data1, message.data2});
    }
    std::stable_sort(plan.events_.begin(), plan.events_.end(), [](const ScheduledMidiEvent& a, const ScheduledMidiEvent& b) {
        if (a.sample != b.sample) return a.sample < b.sample;
        const auto priority = [](const ScheduledMidiEvent& e) {
            const std::uint8_t type = static_cast<std::uint8_t>(e.status & 0xF0U);
            const bool off = type == 0x80U || (type == 0x90U && e.data2 == 0U);
            if (off) return 0;
            if (type == 0x90U) return 2;
            return 1;
        };
        const int pa = priority(a), pb = priority(b);
        if (pa != pb) return pa < pb; // release -> controller/program -> retrigger
        if (a.status != b.status) return a.status < b.status;
        if (a.data1 != b.data1) return a.data1 < b.data1;
        return a.data2 < b.data2;
    });
    return plan;
}

std::size_t MidiRenderPlan::eventsForBlock(std::int64_t blockStartSample,
                                           std::uint32_t frames,
                                           ScheduledMidiEvent* output,
                                           std::size_t capacity) const noexcept {
    if (frames == 0U || output == nullptr || capacity == 0U) return 0U;
    const std::int64_t blockEnd = blockStartSample + static_cast<std::int64_t>(frames);
    auto it = std::lower_bound(events_.begin(), events_.end(), blockStartSample,
        [](const ScheduledMidiEvent& event, std::int64_t sample) { return event.sample < sample; });
    std::size_t count = 0U;
    for (; it != events_.end() && it->sample < blockEnd && count < capacity; ++it) {
        output[count] = *it;
        output[count].frameOffset = static_cast<std::int32_t>(it->sample - blockStartSample);
        ++count;
    }
    return count;
}

} // namespace silveton
