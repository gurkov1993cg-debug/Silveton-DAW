#include "silveton/MidiTimeline.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace silveton {

void MidiSequence::validateNote(const MusicalMidiNote& note) {
    if (!std::isfinite(note.startQuarterNotes) || note.startQuarterNotes < 0.0)
        throw std::invalid_argument("MIDI note start must be finite and non-negative");
    if (!std::isfinite(note.durationQuarterNotes) || note.durationQuarterNotes <= 0.0)
        throw std::invalid_argument("MIDI note duration must be finite and positive");
    if (note.channel > 15U || note.pitch > 127U || note.velocity > 127U || note.releaseVelocity > 127U)
        throw std::invalid_argument("MIDI note field out of range");
}

void MidiSequence::validateMessage(const MusicalMidiMessage& message) {
    if (!std::isfinite(message.quarterNotes) || message.quarterNotes < 0.0)
        throw std::invalid_argument("MIDI message position must be finite and non-negative");
    const std::uint8_t type = static_cast<std::uint8_t>(message.status & 0xF0U);
    if (type < 0xA0U || type > 0xE0U)
        throw std::invalid_argument("MIDI message type must be a non-note channel message");
    if (message.data1 > 127U || message.data2 > 127U)
        throw std::invalid_argument("MIDI message field out of range");
}

std::uint64_t MidiSequence::addMessage(MusicalMidiMessage message) {
    validateMessage(message);
    if (message.id == 0U) {
        if (nextMessageId_ == 0U) throw std::overflow_error("MIDI message ID space exhausted");
        message.id = nextMessageId_++;
    } else {
        const auto duplicate = std::find_if(messages_.begin(), messages_.end(), [&](const MusicalMidiMessage& m) {
            return m.id == message.id;
        });
        if (duplicate != messages_.end()) throw std::invalid_argument("duplicate MIDI message ID");
        if (message.id >= nextMessageId_) {
            if (message.id == std::numeric_limits<std::uint64_t>::max()) nextMessageId_ = 0U;
            else nextMessageId_ = message.id + 1U;
        }
    }
    messages_.push_back(message);
    std::stable_sort(messages_.begin(), messages_.end(), [](const MusicalMidiMessage& a, const MusicalMidiMessage& b) {
        if (a.quarterNotes != b.quarterNotes) return a.quarterNotes < b.quarterNotes;
        return a.id < b.id;
    });
    return message.id;
}

bool MidiSequence::removeMessage(std::uint64_t id) noexcept {
    const auto oldSize = messages_.size();
    messages_.erase(std::remove_if(messages_.begin(), messages_.end(), [id](const MusicalMidiMessage& message) {
        return message.id == id;
    }), messages_.end());
    return messages_.size() != oldSize;
}

MusicalMidiNote* MidiSequence::find(std::uint64_t id) noexcept {
    auto it = std::find_if(notes_.begin(), notes_.end(), [id](const MusicalMidiNote& note) { return note.id == id; });
    return it == notes_.end() ? nullptr : &*it;
}

MusicalMidiMessage* MidiSequence::findMessage(std::uint64_t id) noexcept {
    auto it = std::find_if(messages_.begin(), messages_.end(), [id](const MusicalMidiMessage& message) { return message.id == id; });
    return it == messages_.end() ? nullptr : &*it;
}

std::uint64_t MidiSequence::addNote(MusicalMidiNote note) {
    validateNote(note);
    if (note.id == 0U) {
        if (nextId_ == 0U) throw std::overflow_error("MIDI note ID space exhausted");
        note.id = nextId_++;
    } else {
        if (find(note.id) != nullptr) throw std::invalid_argument("duplicate MIDI note ID");
        if (note.id >= nextId_) {
            if (note.id == std::numeric_limits<std::uint64_t>::max()) nextId_ = 0U;
            else nextId_ = note.id + 1U;
        }
    }
    notes_.push_back(note);
    std::stable_sort(notes_.begin(), notes_.end(), [](const MusicalMidiNote& a, const MusicalMidiNote& b) {
        if (a.startQuarterNotes != b.startQuarterNotes) return a.startQuarterNotes < b.startQuarterNotes;
        return a.id < b.id;
    });
    return note.id;
}

bool MidiSequence::removeNote(std::uint64_t id) noexcept {
    const auto oldSize = notes_.size();
    notes_.erase(std::remove_if(notes_.begin(), notes_.end(), [id](const MusicalMidiNote& note) { return note.id == id; }), notes_.end());
    return notes_.size() != oldSize;
}

bool MidiSequence::moveNote(std::uint64_t id, double startQuarterNotes) {
    MusicalMidiNote* note = find(id);
    if (note == nullptr) return false;
    if (!std::isfinite(startQuarterNotes) || startQuarterNotes < 0.0)
        throw std::invalid_argument("MIDI note start must be finite and non-negative");
    note->startQuarterNotes = startQuarterNotes;
    std::stable_sort(notes_.begin(), notes_.end(), [](const MusicalMidiNote& a, const MusicalMidiNote& b) {
        if (a.startQuarterNotes != b.startQuarterNotes) return a.startQuarterNotes < b.startQuarterNotes;
        return a.id < b.id;
    });
    return true;
}

std::size_t MidiSequence::placeNotes(const std::vector<NotePlacement>& placements) {
    for (const auto& p : placements) {
        if (!std::isfinite(p.startQuarterNotes) || p.startQuarterNotes < 0.0)
            throw std::invalid_argument("MIDI note start must be finite and non-negative");
        if (p.pitch > 127U) throw std::invalid_argument("MIDI note pitch out of range");
    }
    std::size_t placed = 0U;
    for (const auto& p : placements) {
        MusicalMidiNote* note = find(p.id);
        if (note == nullptr) continue;
        note->startQuarterNotes = p.startQuarterNotes;
        note->pitch = p.pitch;
        ++placed;
    }
    if (placed != 0U) {
        std::stable_sort(notes_.begin(), notes_.end(), [](const MusicalMidiNote& a, const MusicalMidiNote& b) {
            if (a.startQuarterNotes != b.startQuarterNotes) return a.startQuarterNotes < b.startQuarterNotes;
            return a.id < b.id;
        });
    }
    return placed;
}

bool MidiSequence::resizeNote(std::uint64_t id, double durationQuarterNotes) {
    MusicalMidiNote* note = find(id);
    if (note == nullptr) return false;
    if (!std::isfinite(durationQuarterNotes) || durationQuarterNotes <= 0.0)
        throw std::invalid_argument("MIDI note duration must be finite and positive");
    note->durationQuarterNotes = durationQuarterNotes;
    return true;
}

bool MidiSequence::setNoteVelocity(std::uint64_t id, std::uint8_t velocity) noexcept {
    MusicalMidiNote* note = find(id);
    if (note == nullptr || velocity > 127U) return false;
    note->velocity = velocity;
    return true;
}

bool MidiSequence::setNoteReleaseVelocity(std::uint64_t id, std::uint8_t velocity) noexcept {
    MusicalMidiNote* note = find(id);
    if (note == nullptr || velocity > 127U) return false;
    note->releaseVelocity = velocity;
    return true;
}

bool MidiSequence::setNotePitch(std::uint64_t id, std::uint8_t pitch) noexcept {
    MusicalMidiNote* note = find(id);
    if (note == nullptr || pitch > 127U) return false;
    note->pitch = pitch;
    return true;
}

bool MidiSequence::setNoteChannel(std::uint64_t id, std::uint8_t channel) noexcept {
    MusicalMidiNote* note = find(id);
    if (note == nullptr || channel > 15U) return false;
    note->channel = channel;
    return true;
}

bool MidiSequence::setNoteMuted(std::uint64_t id, bool muted) noexcept {
    MusicalMidiNote* note = find(id);
    if (note == nullptr) return false;
    note->muted = muted;
    return true;
}

bool MidiSequence::moveMessage(std::uint64_t id, double quarterNotes) {
    if (!std::isfinite(quarterNotes) || quarterNotes < 0.0)
        throw std::invalid_argument("MIDI message position must be finite and non-negative");
    MusicalMidiMessage* message = findMessage(id);
    if (message == nullptr) return false;
    message->quarterNotes = quarterNotes;
    std::stable_sort(messages_.begin(), messages_.end(), [](const MusicalMidiMessage& a, const MusicalMidiMessage& b) {
        if (a.quarterNotes != b.quarterNotes) return a.quarterNotes < b.quarterNotes;
        return a.id < b.id;
    });
    return true;
}

bool MidiSequence::setMessageData(std::uint64_t id, std::uint8_t status, std::uint8_t data1, std::uint8_t data2) {
    MusicalMidiMessage* message = findMessage(id);
    if (message == nullptr) return false;
    MusicalMidiMessage candidate = *message;
    candidate.status = status; candidate.data1 = data1; candidate.data2 = data2;
    validateMessage(candidate);
    message->status = status; message->data1 = data1; message->data2 = data2;
    return true;
}

bool MidiSequence::setMessageMuted(std::uint64_t id, bool muted) noexcept {
    MusicalMidiMessage* message = findMessage(id);
    if (message == nullptr) return false;
    message->muted = muted;
    return true;
}

void MidiSequence::quantize(double divisionsPerQuarter, double strength) {
    if (!std::isfinite(divisionsPerQuarter) || divisionsPerQuarter <= 0.0)
        throw std::invalid_argument("MIDI quantize division must be positive");
    if (!std::isfinite(strength) || strength < 0.0 || strength > 1.0)
        throw std::invalid_argument("MIDI quantize strength must be in [0, 1]");
    for (auto& note : notes_) {
        const double target = std::round(note.startQuarterNotes * divisionsPerQuarter) / divisionsPerQuarter;
        note.startQuarterNotes += (target - note.startQuarterNotes) * strength;
        if (note.startQuarterNotes < 0.0) note.startQuarterNotes = 0.0;
    }
    std::stable_sort(notes_.begin(), notes_.end(), [](const MusicalMidiNote& a, const MusicalMidiNote& b) {
        if (a.startQuarterNotes != b.startQuarterNotes) return a.startQuarterNotes < b.startQuarterNotes;
        return a.id < b.id;
    });
}

void MidiSequence::transpose(int semitones) noexcept {
    for (auto& note : notes_) {
        const int pitch = std::clamp(static_cast<int>(note.pitch) + semitones, 0, 127);
        note.pitch = static_cast<std::uint8_t>(pitch);
    }
}

MidiRenderPlan MidiSequence::compile(const TempoMap& tempoMap) const {
    MidiRenderPlan plan;
    if (notes_.size() > plan.events_.max_size() / 2U)
        throw std::length_error("MIDI render plan too large");
    const std::size_t noteEvents = notes_.size() * 2U;
    if (messages_.size() > plan.events_.max_size() - noteEvents)
        throw std::length_error("MIDI render plan too large");
    plan.events_.reserve(noteEvents + messages_.size());
    for (const auto& note : notes_) {
        validateNote(note);
        if (note.muted) continue;
        const std::int64_t on = tempoMap.sampleAtQuarterNotes(note.startQuarterNotes);
        const std::int64_t off = tempoMap.sampleAtQuarterNotes(note.startQuarterNotes + note.durationQuarterNotes);
        if (off <= on) continue;
        const std::uint8_t channel = static_cast<std::uint8_t>(note.channel & 0x0FU);
        plan.events_.push_back({on, 0, static_cast<std::uint8_t>(0x90U | channel), note.pitch, note.velocity});
        plan.events_.push_back({off, 0, static_cast<std::uint8_t>(0x80U | channel), note.pitch, note.releaseVelocity});
    }
    for (const auto& message : messages_) {
        validateMessage(message);
        if (message.muted) continue;
        const std::int64_t sample = tempoMap.sampleAtQuarterNotes(message.quarterNotes);
        plan.events_.push_back({sample, 0, message.status, message.data1, message.data2});
    }
    std::stable_sort(plan.events_.begin(), plan.events_.end(), [](const ScheduledMidiEvent& a, const ScheduledMidiEvent& b) {
        if (a.sample != b.sample) return a.sample < b.sample;
        const auto priority = [](const ScheduledMidiEvent& e) {
            const std::uint8_t type = static_cast<std::uint8_t>(e.status & 0xF0U);
            const bool off = type == 0x80U || (type == 0x90U && e.data2 == 0U);
            if (off) return 0;
            if (type == 0x90U) return 2;
            return 1;
        };
        const int pa = priority(a), pb = priority(b);
        if (pa != pb) return pa < pb; // release -> controller/program -> retrigger
        if (a.status != b.status) return a.status < b.status;
        if (a.data1 != b.data1) return a.data1 < b.data1;
        return a.data2 < b.data2;
    });
    return plan;
}

std::size_t MidiRenderPlan::eventsForBlock(std::int64_t blockStartSample,
                                           std::uint32_t frames,
                                           ScheduledMidiEvent* output,
                                           std::size_t capacity) const noexcept {
    if (frames == 0U || output == nullptr || capacity == 0U) return 0U;
    const std::int64_t blockEnd = blockStartSample + static_cast<std::int64_t>(frames);
    auto it = std::lower_bound(events_.begin(), events_.end(), blockStartSample,
        [](const ScheduledMidiEvent& event, std::int64_t sample) { return event.sample < sample; });
    std::size_t count = 0U;
    for (; it != events_.end() && it->sample < blockEnd && count < capacity; ++it) {
        output[count] = *it;
        output[count].frameOffset = static_cast<std::int32_t>(it->sample - blockStartSample);
        ++count;
    }
    return count;
}

} // namespace silveton

namespace silveton {
namespace {
void validateMidiPart(const MidiPart& part) {
    if (part.id == 0U) throw std::invalid_argument("MIDI part id must be non-zero");
    if (!std::isfinite(part.timelineStartQuarterNotes) || part.timelineStartQuarterNotes < 0.0 ||
        !std::isfinite(part.sourceOffsetQuarterNotes) || part.sourceOffsetQuarterNotes < 0.0 ||
        !std::isfinite(part.lengthQuarterNotes) || part.lengthQuarterNotes <= 0.0 ||
        !std::isfinite(part.loopLengthQuarterNotes) || part.loopLengthQuarterNotes <= 0.0)
        throw std::invalid_argument("invalid MIDI part range");
}
}

MidiRenderPlan compileMidiArrangement(const MidiSequence& legacySequence,
                                      const std::vector<MidiPart>& parts,
                                      const TempoMap& tempoMap) {
    if (parts.empty()) return legacySequence.compile(tempoMap);

    MidiSequence merged;
    constexpr std::size_t kMaxExpandedEvents = 1000000U;
    std::size_t expanded = 0U;

    for (const auto& part : parts) {
        validateMidiPart(part);
        if (part.muted) continue;
        const double sourceBegin = part.sourceOffsetQuarterNotes;
        const double sourceEnd = sourceBegin + part.lengthQuarterNotes;
        if (!std::isfinite(sourceEnd)) throw std::overflow_error("MIDI part range overflow");
        const double loop = part.loopLengthQuarterNotes;
        const long long firstLoop = static_cast<long long>(std::floor(sourceBegin / loop)) - 1LL;
        const long long lastLoop = static_cast<long long>(std::ceil(sourceEnd / loop)) + 1LL;
        if (lastLoop < firstLoop || static_cast<unsigned long long>(lastLoop - firstLoop) > 1000000ULL)
            throw std::length_error("MIDI part loop expansion too large");

        for (long long k = firstLoop; k <= lastLoop; ++k) {
            const double loopBase = static_cast<double>(k) * loop;
            for (const auto& note : part.sequence.notes()) {
                if (note.muted) continue;
                const double sourceOn = loopBase + note.startQuarterNotes;
                const double sourceOff = sourceOn + note.durationQuarterNotes;
                if (sourceOff <= sourceBegin || sourceOn >= sourceEnd) continue;
                const double clippedOn = std::max(sourceOn, sourceBegin);
                const double clippedOff = std::min(sourceOff, sourceEnd);
                if (!(clippedOff > clippedOn)) continue;
                MusicalMidiNote copy = note;
                copy.id = 0U;
                copy.startQuarterNotes = part.timelineStartQuarterNotes + (clippedOn - sourceBegin);
                copy.durationQuarterNotes = clippedOff - clippedOn;
                copy.muted = false;
                (void)merged.addNote(copy);
                if (++expanded > kMaxExpandedEvents) throw std::length_error("MIDI arrangement too large");
            }
            for (const auto& message : part.sequence.messages()) {
                if (message.muted) continue;
                const double sourcePosition = loopBase + message.quarterNotes;
                if (sourcePosition < sourceBegin || sourcePosition >= sourceEnd) continue;
                MusicalMidiMessage copy = message;
                copy.id = 0U;
                copy.quarterNotes = part.timelineStartQuarterNotes + (sourcePosition - sourceBegin);
                copy.muted = false;
                (void)merged.addMessage(copy);
                if (++expanded > kMaxExpandedEvents) throw std::length_error("MIDI arrangement too large");
            }
        }
    }
    return merged.compile(tempoMap);
}

} // namespace silveton
