#include "silveton/ClipEditor.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <unordered_set>

namespace silveton {

ClipEditor::ClipEditor(Project& project, std::size_t trackIndex)
    : project_(project), trackIndex_(trackIndex) {
    if (trackIndex_ >= project_.tracks.size()) throw std::out_of_range("clip editor track index");
    std::unordered_set<std::uint64_t> ids;
    for (const auto& clip : track().clips) {
        validate(clip);
        if (!ids.insert(clip.id).second) throw std::invalid_argument("duplicate clip id");
    }
}

ProjectTrack& ClipEditor::track() { return project_.tracks.at(trackIndex_); }
const ProjectTrack& ClipEditor::track() const { return project_.tracks.at(trackIndex_); }

void ClipEditor::validate(const ProjectAudioClip& clip) {
    if (clip.id == 0U) throw std::invalid_argument("clip id must be non-zero");
    if (clip.audioPath.empty()) throw std::invalid_argument("clip audio path is empty");
    if (clip.timelineStartSample < 0) throw std::invalid_argument("clip cannot start before project zero");
    if (clip.sourceFrames == 0U || clip.sourceStartSample >= clip.sourceFrames)
        throw std::invalid_argument("clip source range is invalid");
    if (clip.lengthSamples == 0U || clip.lengthSamples > clip.sourceFrames - clip.sourceStartSample)
        throw std::invalid_argument("clip length is invalid");
    if (clip.lengthSamples > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()) ||
        clip.timelineStartSample > std::numeric_limits<std::int64_t>::max() - static_cast<std::int64_t>(clip.lengthSamples))
        throw std::overflow_error("clip timeline end overflow");
    if (!std::isfinite(clip.gainDb)) throw std::invalid_argument("clip gain is invalid");
    const auto autoAnchor = ProjectAudioClip::kAutoFadeAnchor;
    if ((clip.fadeInAnchorSourceSample != autoAnchor && clip.fadeInAnchorSourceSample > clip.sourceFrames) ||
        (clip.fadeOutAnchorSourceSample != autoAnchor && clip.fadeOutAnchorSourceSample > clip.sourceFrames))
        throw std::invalid_argument("clip fade anchor outside source");
}

ProjectAudioClip& ClipEditor::find(std::uint64_t clipId) {
    auto& clips = track().clips;
    auto it = std::find_if(clips.begin(), clips.end(), [clipId](const auto& c) { return c.id == clipId; });
    if (it == clips.end()) throw std::out_of_range("clip id");
    return *it;
}

std::uint64_t ClipEditor::nextId() const {
    std::uint64_t maximum = 0U;
    for (const auto& clip : track().clips) maximum = std::max(maximum, clip.id);
    if (maximum == std::numeric_limits<std::uint64_t>::max()) throw std::overflow_error("clip id exhausted");
    return maximum + 1U;
}

std::int64_t ClipEditor::snapSample(std::int64_t sample, const ClipSnapSettings& snap) const {
    sample = std::max<std::int64_t>(0, sample);
    if (snap.mode == ClipSnapMode::Off) return sample;
    if (snap.mode == ClipSnapMode::Musical) {
        if (snap.divisionsPerQuarter == 0U) throw std::invalid_argument("musical snap divisions must be non-zero");
        return std::max<std::int64_t>(0, project_.tempoMap.snapSampleToQuarterGrid(sample, snap.divisionsPerQuarter));
    }
    if (snap.sampleStep <= 0) throw std::invalid_argument("sample snap step must be positive");
    const std::int64_t q = sample / snap.sampleStep;
    const std::int64_t r = sample % snap.sampleStep;
    if (r >= snap.sampleStep - r && q < std::numeric_limits<std::int64_t>::max() / snap.sampleStep)
        return (q + 1) * snap.sampleStep;
    return q * snap.sampleStep;
}

void ClipEditor::commit(std::vector<ProjectAudioClip> before) {
    for (const auto& clip : track().clips) validate(clip);
    Command command {std::move(before), track().clips};
    undo_.push_back(std::move(command));
    if (undo_.size() > kMaxUndoSteps) undo_.erase(undo_.begin());
    redo_.clear();
}

std::uint64_t ClipEditor::addClip(ProjectAudioClip clip, const ClipSnapSettings& snap) {
    auto before = track().clips;
    if (clip.id == 0U) clip.id = nextId();
    else if (std::any_of(track().clips.begin(), track().clips.end(), [&](const auto& c) { return c.id == clip.id; }))
        throw std::invalid_argument("duplicate clip id");
    clip.timelineStartSample = snapSample(clip.timelineStartSample, snap);
    validate(clip);
    track().clips.push_back(std::move(clip));
    commit(std::move(before));
    return track().clips.back().id;
}

void ClipEditor::removeClip(std::uint64_t clipId) {
    auto before = track().clips;
    auto& clips = track().clips;
    const auto oldSize = clips.size();
    clips.erase(std::remove_if(clips.begin(), clips.end(), [clipId](const auto& c) { return c.id == clipId; }), clips.end());
    if (clips.size() == oldSize) throw std::out_of_range("clip id");
    commit(std::move(before));
}

void ClipEditor::moveClip(std::uint64_t clipId, std::int64_t timelineStartSample, const ClipSnapSettings& snap) {
    auto before = track().clips;
    find(clipId).timelineStartSample = snapSample(timelineStartSample, snap);
    commit(std::move(before));
}

std::uint64_t ClipEditor::splitClip(std::uint64_t clipId, std::int64_t timelineSample, const ClipSnapSettings& snap) {
    auto before = track().clips;
    ProjectAudioClip& original = find(clipId);
    const std::int64_t split = snapSample(timelineSample, snap);
    const std::int64_t end = original.timelineStartSample + static_cast<std::int64_t>(original.lengthSamples);
    if (split <= original.timelineStartSample || split >= end) throw std::invalid_argument("split outside clip interior");
    const std::uint64_t offset = static_cast<std::uint64_t>(split - original.timelineStartSample);
    const std::uint64_t oldLength = original.lengthSamples;
    const std::uint64_t fadeInAnchor = original.fadeInAnchorSourceSample == ProjectAudioClip::kAutoFadeAnchor
        ? original.sourceStartSample : original.fadeInAnchorSourceSample;
    const std::uint64_t fadeOutAnchor = original.fadeOutAnchorSourceSample == ProjectAudioClip::kAutoFadeAnchor
        ? original.sourceStartSample + original.lengthSamples : original.fadeOutAnchorSourceSample;

    ProjectAudioClip second = original;
    second.id = nextId();
    second.timelineStartSample = split;
    second.sourceStartSample += offset;
    second.lengthSamples = oldLength - offset;
    second.fadeInAnchorSourceSample = fadeInAnchor;
    second.fadeOutAnchorSourceSample = fadeOutAnchor;

    original.lengthSamples = offset;
    original.fadeInAnchorSourceSample = fadeInAnchor;
    original.fadeOutAnchorSourceSample = fadeOutAnchor;
    const std::uint64_t newId = second.id;
    track().clips.push_back(std::move(second));
    commit(std::move(before));
    return newId;
}

void ClipEditor::trimLeft(std::uint64_t clipId, std::int64_t newTimelineStartSample, const ClipSnapSettings& snap) {
    auto before = track().clips;
    ProjectAudioClip& clip = find(clipId);
    const std::int64_t newStart = snapSample(newTimelineStartSample, snap);
    const std::int64_t oldStart = clip.timelineStartSample;
    const std::int64_t oldEnd = oldStart + static_cast<std::int64_t>(clip.lengthSamples);
    if (newStart >= oldEnd) throw std::invalid_argument("left trim removes whole clip");
    const std::int64_t delta = newStart - oldStart;
    if (delta > 0) {
        const auto amount = static_cast<std::uint64_t>(delta);
        clip.sourceStartSample += amount;
        clip.lengthSamples -= amount;
    } else if (delta < 0) {
        const auto amount = static_cast<std::uint64_t>(-delta);
        if (amount > clip.sourceStartSample) throw std::invalid_argument("left trim exceeds source head");
        clip.sourceStartSample -= amount;
        clip.lengthSamples += amount;
    }
    clip.timelineStartSample = newStart;
    commit(std::move(before));
}

void ClipEditor::trimRight(std::uint64_t clipId, std::int64_t newTimelineEndSample, const ClipSnapSettings& snap) {
    auto before = track().clips;
    ProjectAudioClip& clip = find(clipId);
    const std::int64_t newEnd = snapSample(newTimelineEndSample, snap);
    if (newEnd <= clip.timelineStartSample) throw std::invalid_argument("right trim removes whole clip");
    const std::uint64_t newLength = static_cast<std::uint64_t>(newEnd - clip.timelineStartSample);
    if (newLength > clip.sourceFrames - clip.sourceStartSample) throw std::invalid_argument("right trim exceeds source tail");
    clip.lengthSamples = newLength;
    commit(std::move(before));
}

void ClipEditor::setFades(std::uint64_t clipId, std::uint64_t fadeInSamples, std::uint64_t fadeOutSamples) {
    auto before = track().clips;
    ProjectAudioClip& clip = find(clipId);
    clip.fadeInSamples = fadeInSamples;
    clip.fadeOutSamples = fadeOutSamples;
    clip.fadeInAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
    clip.fadeOutAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
    commit(std::move(before));
}

void ClipEditor::setGainDb(std::uint64_t clipId, float gainDb) {
    if (!std::isfinite(gainDb)) throw std::invalid_argument("clip gain is invalid");
    auto before = track().clips;
    find(clipId).gainDb = gainDb;
    commit(std::move(before));
}

void ClipEditor::setMute(std::uint64_t clipId, bool mute) {
    auto before = track().clips;
    find(clipId).mute = mute;
    commit(std::move(before));
}

bool ClipEditor::undo() {
    if (undo_.empty()) return false;
    Command command = std::move(undo_.back());
    undo_.pop_back();
    track().clips = command.before;
    redo_.push_back(std::move(command));
    return true;
}

bool ClipEditor::redo() {
    if (redo_.empty()) return false;
    Command command = std::move(redo_.back());
    redo_.pop_back();
    track().clips = command.after;
    undo_.push_back(std::move(command));
    if (undo_.size() > kMaxUndoSteps) undo_.erase(undo_.begin());
    return true;
}

void ClipEditor::clearHistory() noexcept {
    undo_.clear();
    redo_.clear();
}

} // namespace silveton
