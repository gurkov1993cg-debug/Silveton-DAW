#import <AppKit/AppKit.h>

#include "internal/Vst3EditorBridge.h"
#include "pluginterfaces/base/funknownimpl.h"
#include "pluginterfaces/gui/iplugview.h"
#include "pluginterfaces/vst/ivsteditcontroller.h"

namespace silveton::detail { struct Vst3EditorHandle; }
static void silvetonEditorWindowWillClose(void* opaque) noexcept;

@interface SilvetonVst3WindowDelegate : NSObject <NSWindowDelegate>
@property(nonatomic, assign) void* owner;
@end

@implementation SilvetonVst3WindowDelegate
- (void)windowWillClose:(NSNotification*)notification {
    (void)notification;
    silvetonEditorWindowWillClose(self.owner);
}
@end

namespace silveton::detail {

class CocoaPlugFrame final
    : public Steinberg::U::Implements<Steinberg::U::Directly<Steinberg::IPlugFrame>> {
public:
    explicit CocoaPlugFrame(NSWindow* window) : window_(window) {}

    Steinberg::tresult PLUGIN_API resizeView(Steinberg::IPlugView* view,
                                              Steinberg::ViewRect* newSize) override {
        if (view == nullptr || newSize == nullptr || window_ == nil) return Steinberg::kInvalidArgument;
        const auto width = newSize->getWidth();
        const auto height = newSize->getHeight();
        if (width <= 0 || height <= 0) return Steinberg::kInvalidArgument;
        [window_ setContentSize:NSMakeSize(static_cast<CGFloat>(width), static_cast<CGFloat>(height))];
        return view->onSize(newSize);
    }

    void clearWindow() noexcept { window_ = nil; }

private:
    __weak NSWindow* window_ {nil};
};

struct Vst3EditorHandle {
    __strong NSWindow* window {nil};
    __strong SilvetonVst3WindowDelegate* delegate {nil};
    Steinberg::IPtr<Steinberg::IPlugView> view;
    Steinberg::IPtr<CocoaPlugFrame> frame;
    bool attached {false};
    bool open {false};
};

static void detach(Vst3EditorHandle* handle) noexcept {
    if (handle == nullptr) return;
    if (handle->attached && handle->view) {
        (void)handle->view->removed();
        handle->attached = false;
    }
    if (handle->view) (void)handle->view->setFrame(nullptr);
    if (handle->frame) handle->frame->clearWindow();
    handle->open = false;
}

Vst3EditorHandle* openVst3CocoaEditor(Steinberg::Vst::IEditController* controller) {
    if (controller == nullptr) return nullptr;
    (void)[NSApplication sharedApplication];
    Steinberg::IPlugView* rawView = controller->createView(Steinberg::Vst::ViewType::kEditor);
    if (rawView == nullptr) return nullptr;
    auto view = Steinberg::owned(rawView);
    if (view->isPlatformTypeSupported(Steinberg::kPlatformTypeNSView) != Steinberg::kResultTrue)
        return nullptr;

    Steinberg::ViewRect rect {};
    if (view->getSize(&rect) != Steinberg::kResultTrue || rect.getWidth() <= 0 || rect.getHeight() <= 0)
        return nullptr;

    const auto canResize = view->canResize() == Steinberg::kResultTrue;
    NSWindowStyleMask style = NSWindowStyleMaskTitled | NSWindowStyleMaskClosable;
    if (canResize) style |= NSWindowStyleMaskResizable;

    auto* handle = new Vst3EditorHandle();
    handle->window = [[NSWindow alloc]
        initWithContentRect:NSMakeRect(0.0, 0.0, static_cast<CGFloat>(rect.getWidth()), static_cast<CGFloat>(rect.getHeight()))
                  styleMask:style
                    backing:NSBackingStoreBuffered
                      defer:NO];
    if (handle->window == nil) {
        delete handle;
        return nullptr;
    }
    handle->delegate = [[SilvetonVst3WindowDelegate alloc] init];
    handle->delegate.owner = handle;
    handle->window.delegate = handle->delegate;
    handle->frame = Steinberg::owned(new CocoaPlugFrame(handle->window));
    handle->view = std::move(view);

    if (handle->view->setFrame(handle->frame.get()) != Steinberg::kResultTrue) {
        handle->window.delegate = nil;
        delete handle;
        return nullptr;
    }
    NSView* parent = handle->window.contentView;
    if (parent == nil || handle->view->attached((__bridge void*)parent, Steinberg::kPlatformTypeNSView) != Steinberg::kResultTrue) {
        (void)handle->view->setFrame(nullptr);
        handle->window.delegate = nil;
        delete handle;
        return nullptr;
    }
    handle->attached = true;
    handle->open = true;
    [handle->window center];
    [handle->window makeKeyAndOrderFront:nil];
    return handle;
}

void closeVst3CocoaEditor(Vst3EditorHandle*& handle) noexcept {
    if (handle == nullptr) return;
    auto* current = handle;
    handle = nullptr;
    current->window.delegate = nil;
    detach(current);
    [current->window orderOut:nil];
    [current->window close];
    current->delegate.owner = nullptr;
    current->delegate = nil;
    current->window = nil;
    current->view = nullptr;
    current->frame = nullptr;
    delete current;
}

bool vst3CocoaEditorIsOpen(const Vst3EditorHandle* handle) noexcept {
    return handle != nullptr && handle->open && handle->window != nil;
}

} // namespace silveton::detail

static void silvetonEditorWindowWillClose(void* opaque) noexcept {
    auto* handle = static_cast<silveton::detail::Vst3EditorHandle*>(opaque);
    if (handle == nullptr) return;
    silveton::detail::detach(handle);
}
