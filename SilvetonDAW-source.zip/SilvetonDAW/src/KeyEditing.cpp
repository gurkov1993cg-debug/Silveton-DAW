#include "silveton/KeyEditing.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace silveton {

namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr double kEps = 1.0e-9;

const char* const kNoteNames[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};

struct ControllerName {
    int number;
    const char* name;
};
constexpr ControllerName kControllerNames[] = {
    {0, "Bank Select"}, {1, "Modulation"}, {2, "Breath"}, {4, "Foot"}, {5, "Glide Time"}, {7, "Volume"}, {10, "Pan"},
    {11, "Expression"}, {64, "Sustain"}, {65, "Glide On/Off"}, {66, "Sostenuto"}, {67, "Soft Pedal"}, {71, "Resonance"},
    {72, "Release"}, {73, "Attack"}, {74, "Cutoff"}, {91, "Reverb Send"}, {93, "Chorus Send"},
};

int clampInt(long long v, int lo, int hi) noexcept {
    return static_cast<int>(std::min<long long>(hi, std::max<long long>(lo, v)));
}

double noteEnd(const MusicalMidiNote& n) noexcept { return n.startQuarterNotes + n.durationQuarterNotes; }

} // namespace

// ============================================================================ lanes ==
bool KeyLane::matches(const MusicalMidiMessage& m) const noexcept {
    const auto type = static_cast<std::uint8_t>(m.status & 0xF0U);
    switch (kind) {
        case Kind::Controller: return type == 0xB0U && m.data1 == number;
        case Kind::PitchBend: return type == 0xE0U;
        case Kind::Aftertouch: return type == 0xD0U;
        case Kind::Velocity: break;
    }
    return false;
}

int KeyLane::valueOf(const MusicalMidiMessage& m) const noexcept {
    switch (kind) {
        case Kind::Controller: return m.data2;
        case Kind::PitchBend: return static_cast<int>(m.data1) | (static_cast<int>(m.data2) << 7);
        case Kind::Aftertouch: return m.data1;
        case Kind::Velocity: break;
    }
    return 0;
}

MusicalMidiMessage KeyLane::make(double quarterNotes, int value, std::uint8_t channel) const {
    MusicalMidiMessage m;
    m.quarterNotes = std::max(0.0, quarterNotes);
    const int v = clampInt(value, 0, maxValue());
    const auto ch = static_cast<std::uint8_t>(channel & 0x0FU);
    switch (kind) {
        case Kind::Controller:
            m.status = static_cast<std::uint8_t>(0xB0U | ch);
            m.data1 = number;
            m.data2 = static_cast<std::uint8_t>(v);
            break;
        case Kind::PitchBend:
            m.status = static_cast<std::uint8_t>(0xE0U | ch);
            m.data1 = static_cast<std::uint8_t>(v & 0x7F);
            m.data2 = static_cast<std::uint8_t>((v >> 7) & 0x7F);
            break;
        case Kind::Aftertouch:
            m.status = static_cast<std::uint8_t>(0xD0U | ch);
            m.data1 = static_cast<std::uint8_t>(v);
            m.data2 = 0U;
            break;
        case Kind::Velocity:
            break;
    }
    return m;
}

std::string KeyLane::name() const {
    switch (kind) {
        case Kind::Velocity: return "Velocity";
        case Kind::PitchBend: return "Pitch Bend";
        case Kind::Aftertouch: return "Aftertouch";
        case Kind::Controller: break;
    }
    for (const auto& c : kControllerNames)
        if (c.number == number) return std::string(c.name) + " (CC " + std::to_string(number) + ")";
    return "Controller " + std::to_string(number);
}

// ============================================================================ names ==
const char* KeyEditing::laneShapeName(LaneShape shape) noexcept {
    switch (shape) {
        case LaneShape::Line: return "Line";
        case LaneShape::Parabola: return "Curve";
        case LaneShape::Sine: return "Sine";
        case LaneShape::Triangle: return "Triangle";
        case LaneShape::Square: return "Square";
        case LaneShape::Count: break;
    }
    return "Line";
}

const char* KeyEditing::chordName(ChordKind kind) noexcept {
    switch (kind) {
        case ChordKind::Single: return "Single Note";
        case ChordKind::Octave: return "Octave";
        case ChordKind::PowerChord: return "Power Chord";
        case ChordKind::Major: return "Major";
        case ChordKind::Minor: return "Minor";
        case ChordKind::Diminished: return "Diminished";
        case ChordKind::Augmented: return "Augmented";
        case ChordKind::Sus2: return "Sus 2";
        case ChordKind::Sus4: return "Sus 4";
        case ChordKind::Major7: return "Major 7";
        case ChordKind::Minor7: return "Minor 7";
        case ChordKind::Dominant7: return "Dominant 7";
        case ChordKind::Count: break;
    }
    return "Single Note";
}

std::vector<int> KeyEditing::chordIntervals(ChordKind kind) {
    switch (kind) {
        case ChordKind::Octave: return {0, 12};
        case ChordKind::PowerChord: return {0, 7};
        case ChordKind::Major: return {0, 4, 7};
        case ChordKind::Minor: return {0, 3, 7};
        case ChordKind::Diminished: return {0, 3, 6};
        case ChordKind::Augmented: return {0, 4, 8};
        case ChordKind::Sus2: return {0, 2, 7};
        case ChordKind::Sus4: return {0, 5, 7};
        case ChordKind::Major7: return {0, 4, 7, 11};
        case ChordKind::Minor7: return {0, 3, 7, 10};
        case ChordKind::Dominant7: return {0, 4, 7, 10};
        case ChordKind::Single:
        case ChordKind::Count: break;
    }
    return {0};
}

std::string KeyEditing::noteName(int pitch) {
    const int p = clampInt(pitch, 0, 127);
    return std::string(kNoteNames[p % 12]) + std::to_string(p / 12 - 2);
}

// ============================================================================ notes ==
const MusicalMidiNote* KeyEditing::find(const MidiSequence& seq, std::uint64_t id) noexcept {
    for (const auto& n : seq.notes()) if (n.id == id) return &n;
    return nullptr;
}

const MusicalMidiMessage* KeyEditing::findMessage(const MidiSequence& seq, std::uint64_t id) noexcept {
    for (const auto& m : seq.messages()) if (m.id == id) return &m;
    return nullptr;
}

bool KeyEditing::contains(const Ids& ids, std::uint64_t id) noexcept {
    return std::find(ids.begin(), ids.end(), id) != ids.end();
}

std::vector<MusicalMidiNote> KeyEditing::snapshot(const MidiSequence& seq, const Ids& ids) {
    std::vector<MusicalMidiNote> out;
    out.reserve(ids.size());
    for (const auto& n : seq.notes()) if (contains(ids, n.id)) out.push_back(n);
    return out;
}

NoteClip KeyEditing::copyNotes(const MidiSequence& seq, const Ids& ids) {
    NoteClip clip;
    const auto notes = snapshot(seq, ids);
    if (notes.empty()) return clip;
    double first = std::numeric_limits<double>::max(), last = 0.0;
    for (const auto& n : notes) { first = std::min(first, n.startQuarterNotes); last = std::max(last, noteEnd(n)); }
    for (const auto& n : notes) {
        NoteClip::Item item;
        item.offset = n.startQuarterNotes - first;
        item.duration = n.durationQuarterNotes;
        item.channel = n.channel; item.pitch = n.pitch; item.velocity = n.velocity;
        item.releaseVelocity = n.releaseVelocity; item.muted = n.muted;
        clip.notes.push_back(item);
    }
    clip.span = last - first;
    return clip;
}

KeyEditing::Ids KeyEditing::pasteNotes(MidiSequence& seq, const NoteClip& clip, double atQuarterNotes) {
    Ids ids;
    const double at = std::isfinite(atQuarterNotes) ? std::max(0.0, atQuarterNotes) : 0.0;
    for (const auto& item : clip.notes) {
        MusicalMidiNote n;
        n.startQuarterNotes = at + item.offset;
        n.durationQuarterNotes = std::max(kShortestNote, item.duration);
        n.channel = item.channel; n.pitch = item.pitch; n.velocity = item.velocity;
        n.releaseVelocity = item.releaseVelocity; n.muted = item.muted;
        ids.push_back(seq.addNote(n));
    }
    return ids;
}

KeyEditing::Ids KeyEditing::duplicateNotes(MidiSequence& seq, const Ids& ids, double* shiftOut) {
    const NoteClip clip = copyNotes(seq, ids);
    if (shiftOut) *shiftOut = clip.span;
    if (clip.empty()) return {};
    double first = std::numeric_limits<double>::max();
    for (const auto& n : snapshot(seq, ids)) first = std::min(first, n.startQuarterNotes);
    return pasteNotes(seq, clip, first + clip.span);
}

std::size_t KeyEditing::removeNotes(MidiSequence& seq, const Ids& ids) {
    std::size_t removed = 0U;
    for (const std::uint64_t id : ids) if (seq.removeNote(id)) ++removed;
    return removed;
}

void KeyEditing::moveFrom(MidiSequence& seq, const std::vector<MusicalMidiNote>& original, double deltaQuarter, int deltaPitch,
                          double* appliedQuarter, int* appliedPitch) {
    if (original.empty()) { if (appliedQuarter) *appliedQuarter = 0.0; if (appliedPitch) *appliedPitch = 0; return; }
    double minStart = std::numeric_limits<double>::max();
    int minPitch = 127, maxPitch = 0;
    for (const auto& n : original) {
        minStart = std::min(minStart, n.startQuarterNotes);
        minPitch = std::min<int>(minPitch, n.pitch);
        maxPitch = std::max<int>(maxPitch, n.pitch);
    }
    double dq = std::isfinite(deltaQuarter) ? deltaQuarter : 0.0;
    dq = std::max(dq, -minStart);
    const int dp = clampInt(deltaPitch, -minPitch, 127 - maxPitch);
    std::vector<NotePlacement> placements;
    placements.reserve(original.size());
    for (const auto& n : original)
        placements.push_back({n.id, std::max(0.0, n.startQuarterNotes + dq), static_cast<std::uint8_t>(n.pitch + dp)});
    (void)seq.placeNotes(placements);
    if (appliedQuarter) *appliedQuarter = dq;
    if (appliedPitch) *appliedPitch = dp;
}

void KeyEditing::resizeFrom(MidiSequence& seq, const std::vector<MusicalMidiNote>& original, double deltaQuarter) {
    const double d = std::isfinite(deltaQuarter) ? deltaQuarter : 0.0;
    for (const auto& n : original) (void)seq.resizeNote(n.id, std::max(kShortestNote, n.durationQuarterNotes + d));
}

void KeyEditing::shiftVelocityFrom(MidiSequence& seq, const std::vector<MusicalMidiNote>& original, int delta) {
    for (const auto& n : original) (void)seq.setNoteVelocity(n.id, static_cast<std::uint8_t>(clampInt(static_cast<int>(n.velocity) + delta, 1, 127)));
}

KeyEditing::Ids KeyEditing::splitNote(MidiSequence& seq, std::uint64_t id, double quarter) {
    const MusicalMidiNote* found = find(seq, id);
    if (found == nullptr || !std::isfinite(quarter)) return {};
    const MusicalMidiNote n = *found;
    if (quarter < n.startQuarterNotes + kShortestNote - kEps || quarter > noteEnd(n) - kShortestNote + kEps) return {};
    MusicalMidiNote right = n;
    right.id = 0U;
    right.startQuarterNotes = quarter;
    right.durationQuarterNotes = noteEnd(n) - quarter;
    (void)seq.resizeNote(id, quarter - n.startQuarterNotes);
    const std::uint64_t rightId = seq.addNote(right);
    return {id, rightId};
}

KeyEditing::Ids KeyEditing::splitNotes(MidiSequence& seq, const Ids& ids, double quarter) {
    Ids rights;
    for (const std::uint64_t id : ids) {
        const Ids pair = splitNote(seq, id, quarter);
        if (pair.size() == 2U) rights.push_back(pair[1]);
    }
    return rights;
}

KeyEditing::Ids KeyEditing::glueNotes(MidiSequence& seq, const Ids& ids) {
    auto notes = snapshot(seq, ids);
    std::stable_sort(notes.begin(), notes.end(), [](const MusicalMidiNote& a, const MusicalMidiNote& b) {
        if (a.channel != b.channel) return a.channel < b.channel;
        if (a.pitch != b.pitch) return a.pitch < b.pitch;
        if (a.startQuarterNotes != b.startQuarterNotes) return a.startQuarterNotes < b.startQuarterNotes;
        return a.id < b.id;
    });
    Ids removed;
    std::size_t i = 0U;
    while (i < notes.size()) {
        const MusicalMidiNote head = notes[i];
        double end = noteEnd(head);
        std::size_t j = i + 1U;
        while (j < notes.size() && notes[j].channel == head.channel && notes[j].pitch == head.pitch &&
               notes[j].startQuarterNotes <= end + kEps) {
            end = std::max(end, noteEnd(notes[j]));
            removed.push_back(notes[j].id);
            ++j;
        }
        if (j > i + 1U) (void)seq.resizeNote(head.id, end - head.startQuarterNotes);
        i = j;
    }
    for (const std::uint64_t id : removed) (void)seq.removeNote(id);
    Ids survivors;
    for (const std::uint64_t id : ids) if (!contains(removed, id) && find(seq, id) != nullptr) survivors.push_back(id);
    return survivors;
}

std::uint64_t KeyEditing::glueToNext(MidiSequence& seq, std::uint64_t id) {
    const MusicalMidiNote* found = find(seq, id);
    if (found == nullptr) return 0U;
    const MusicalMidiNote n = *found;
    const MusicalMidiNote* next = nullptr;
    for (const auto& o : seq.notes()) {
        if (o.id == id || o.pitch != n.pitch || o.channel != n.channel) continue;
        if (o.startQuarterNotes < n.startQuarterNotes || (o.startQuarterNotes == n.startQuarterNotes && o.id < id)) continue;
        if (next == nullptr || o.startQuarterNotes < next->startQuarterNotes) next = &o;
    }
    if (next == nullptr) return 0U;
    const double end = std::max(noteEnd(n), noteEnd(*next));
    const std::uint64_t nextId = next->id;
    (void)seq.resizeNote(id, end - n.startQuarterNotes);
    (void)seq.removeNote(nextId);
    return id;
}

std::size_t KeyEditing::muteNotes(MidiSequence& seq, const Ids& ids, int mode) {
    std::size_t changed = 0U;
    for (const auto& n : snapshot(seq, ids)) {
        const bool target = mode == 2 ? !n.muted : mode == 1;
        if (n.muted != target && seq.setNoteMuted(n.id, target)) ++changed;
    }
    return changed;
}

int KeyEditing::pitchInScale(int pitch, const ToneScale& scale) noexcept {
    const int p = clampInt(pitch, 0, 127);
    if (scale.chromatic()) return p;
    int r = clampInt(std::llround(scale.nearest(static_cast<double>(p))), 0, 127);
    while (r > 0 && !scale.contains(r)) --r;
    return r;
}

std::size_t KeyEditing::fitToScale(MidiSequence& seq, const Ids& ids, const ToneScale& scale) {
    if (scale.chromatic()) return 0U;
    std::size_t changed = 0U;
    const Ids use = ids.empty() ? allIds(seq) : ids;
    for (const auto& n : snapshot(seq, use)) {
        const int fitted = pitchInScale(n.pitch, scale);
        if (fitted != n.pitch && seq.setNotePitch(n.id, static_cast<std::uint8_t>(fitted))) ++changed;
    }
    return changed;
}

KeyEditing::Ids KeyEditing::addChord(MidiSequence& seq, const MusicalMidiNote& root, ChordKind kind) {
    Ids ids;
    for (const int interval : chordIntervals(kind)) {
        const int pitch = static_cast<int>(root.pitch) + interval;
        if (pitch > 127) continue;
        MusicalMidiNote n = root;
        n.id = 0U;
        n.pitch = static_cast<std::uint8_t>(pitch);
        ids.push_back(seq.addNote(n));
    }
    return ids;
}

KeyEditing::Ids KeyEditing::allIds(const MidiSequence& seq) {
    Ids ids;
    ids.reserve(seq.notes().size());
    for (const auto& n : seq.notes()) ids.push_back(n.id);
    return ids;
}

KeyEditing::Ids KeyEditing::invertSelection(const MidiSequence& seq, const Ids& ids) {
    Ids out;
    for (const auto& n : seq.notes()) if (!contains(ids, n.id)) out.push_back(n.id);
    return out;
}

KeyEditing::Ids KeyEditing::selectSamePitch(const MidiSequence& seq, const Ids& ids) {
    bool pitches[128] = {};
    for (const auto& n : snapshot(seq, ids)) pitches[n.pitch & 0x7F] = true;
    Ids out;
    for (const auto& n : seq.notes()) if (pitches[n.pitch & 0x7F]) out.push_back(n.id);
    return out;
}

KeyEditing::Ids KeyEditing::selectFrom(const MidiSequence& seq, double quarter) {
    Ids out;
    for (const auto& n : seq.notes()) if (n.startQuarterNotes >= quarter - kEps) out.push_back(n.id);
    return out;
}

KeyEditing::Ids KeyEditing::selectInside(const MidiSequence& seq, double fromQuarter, double toQuarter, int lowPitch, int highPitch) {
    if (fromQuarter > toQuarter) std::swap(fromQuarter, toQuarter);
    if (lowPitch > highPitch) std::swap(lowPitch, highPitch);
    Ids out;
    for (const auto& n : seq.notes()) {
        if (n.pitch < lowPitch || n.pitch > highPitch) continue;
        if (noteEnd(n) < fromQuarter || n.startQuarterNotes > toQuarter) continue;
        out.push_back(n.id);
    }
    return out;
}

// ============================================================================ lanes ==
std::vector<MusicalMidiMessage> KeyEditing::laneMessages(const MidiSequence& seq, const KeyLane& lane) {
    std::vector<MusicalMidiMessage> out;
    for (const auto& m : seq.messages()) if (lane.matches(m)) out.push_back(m);
    return out;
}

std::vector<LanePoint> KeyEditing::shapePoints(LaneShape shape, double fromQuarter, int fromValue, double toQuarter, int toValue,
                                               double step, double period, int maxValue) {
    std::vector<LanePoint> out;
    if (!std::isfinite(fromQuarter) || !std::isfinite(toQuarter)) return out;
    double q0 = std::max(0.0, fromQuarter), q1 = std::max(0.0, toQuarter);
    int v0 = fromValue, v1 = toValue;
    if (q1 < q0) { std::swap(q0, q1); std::swap(v0, v1); }
    const int top = std::max(1, maxValue);
    auto value = [&](double v) { return clampInt(std::llround(v), 0, top); };
    const double span = q1 - q0;
    if (span <= kEps) { out.push_back({q0, value(v0)}); return out; }
    if (!(step > 0.0) || !std::isfinite(step)) step = span / 32.0;
    step = std::max(step, span / 4096.0);
    if (!(period > 0.0) || !std::isfinite(period)) period = 1.0;

    std::vector<double> times;
    for (int i = 0;; ++i) {
        const double t = q0 + static_cast<double>(i) * step;
        if (t >= q1 - step * 1.0e-6) break;
        times.push_back(t);
    }
    times.push_back(q1);
    if (shape == LaneShape::Square) {
        for (int k = 1;; ++k) {
            const double t = q0 + static_cast<double>(k) * period * 0.5;
            if (t >= q1 - kEps) break;
            times.push_back(t);
        }
        std::sort(times.begin(), times.end());
        times.erase(std::unique(times.begin(), times.end(), [](double a, double b) { return std::abs(a - b) < kEps; }), times.end());
    }

    for (std::size_t i = 0U; i < times.size(); ++i) {
        const double t = times[i];
        const double x = (t - q0) / span;
        const double phase = (t - q0) / period;
        const double frac = phase - std::floor(phase + kEps);
        double w = x;
        switch (shape) {
            case LaneShape::Line: w = x; break;
            case LaneShape::Parabola: w = x * x; break;
            case LaneShape::Sine: w = 0.5 - 0.5 * std::cos(2.0 * kPi * phase); break;
            case LaneShape::Triangle: w = frac < 0.5 ? 2.0 * frac : 2.0 * (1.0 - frac); break;
            case LaneShape::Square: w = frac < 0.5 - kEps ? 0.0 : 1.0; break;
            case LaneShape::Count: break;
        }
        const int v = value(static_cast<double>(v0) + static_cast<double>(v1 - v0) * w);
        const bool last = i + 1U == times.size();
        if (out.empty() || last || v != out.back().value) out.push_back({t, v});
    }
    return out;
}

KeyEditing::Ids KeyEditing::writePoints(MidiSequence& seq, const KeyLane& lane, const std::vector<LanePoint>& points, std::uint8_t channel) {
    if (!lane.isMessageLane() || points.empty()) return {};
    double lo = std::numeric_limits<double>::max(), hi = 0.0;
    for (const auto& p : points) { lo = std::min(lo, p.quarterNotes); hi = std::max(hi, p.quarterNotes); }
    (void)eraseRange(seq, lane, lo, hi);
    Ids ids;
    ids.reserve(points.size());
    for (const auto& p : points) ids.push_back(seq.addMessage(lane.make(p.quarterNotes, p.value, channel)));
    return ids;
}

std::size_t KeyEditing::eraseRange(MidiSequence& seq, const KeyLane& lane, double fromQuarter, double toQuarter) {
    if (fromQuarter > toQuarter) std::swap(fromQuarter, toQuarter);
    Ids doomed;
    for (const auto& m : seq.messages())
        if (lane.matches(m) && m.quarterNotes >= fromQuarter - kEps && m.quarterNotes <= toQuarter + kEps) doomed.push_back(m.id);
    return removeMessages(seq, doomed);
}

std::size_t KeyEditing::removeMessages(MidiSequence& seq, const Ids& ids) {
    std::size_t removed = 0U;
    for (const std::uint64_t id : ids) if (seq.removeMessage(id)) ++removed;
    return removed;
}

std::size_t KeyEditing::reduceLane(MidiSequence& seq, const KeyLane& lane, int tolerance) {
    const auto messages = laneMessages(seq, lane);
    if (messages.size() < 3U) return 0U;
    const int tol = std::max(0, tolerance);
    Ids doomed;
    std::size_t prev = 0U;   // the last point that stays
    for (std::size_t i = 1U; i + 1U < messages.size(); ++i) {
        const auto& a = messages[prev];
        const auto& b = messages[i + 1U];
        const double span = b.quarterNotes - a.quarterNotes;
        const double va = lane.valueOf(a), vb = lane.valueOf(b);
        const double t = span > kEps ? (messages[i].quarterNotes - a.quarterNotes) / span : 0.0;
        const double expected = va + (vb - va) * t;
        if (std::abs(static_cast<double>(lane.valueOf(messages[i])) - expected) <= static_cast<double>(tol)) doomed.push_back(messages[i].id);
        else prev = i;
    }
    return removeMessages(seq, doomed);
}

bool KeyEditing::setValue(MidiSequence& seq, const KeyLane& lane, std::uint64_t messageId, int value) {
    const MusicalMidiMessage* m = findMessage(seq, messageId);
    if (m == nullptr || !lane.matches(*m)) return false;
    const MusicalMidiMessage made = lane.make(m->quarterNotes, value, static_cast<std::uint8_t>(m->status & 0x0FU));
    return seq.setMessageData(messageId, made.status, made.data1, made.data2);
}

} // namespace silveton
