#include "silveton/TakeComp.h"
#include <algorithm>
#include <limits>
#include <stdexcept>
#include <unordered_set>

namespace silveton {
namespace {

std::int64_t checkedEnd(std::int64_t start, std::uint64_t length, const char* what) {
    if (start < 0 || length == 0U || length > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()) ||
        start > std::numeric_limits<std::int64_t>::max() - static_cast<std::int64_t>(length))
        throw std::invalid_argument(what);
    return start + static_cast<std::int64_t>(length);
}

bool containsRange(const ProjectAudioClip& clip, std::int64_t start, std::int64_t end) {
    if (end <= start || start < clip.timelineStartSample) return false;
    const std::int64_t clipEnd = checkedEnd(clip.timelineStartSample, clip.lengthSamples, "take clip timeline overflow");
    return end <= clipEnd;
}

} // namespace

std::vector<ProjectTakeLane> TakeLaneBuilder::fromRecordedTimelineSpans(
    const std::string& audioPath,
    std::uint64_t sourceFrames,
    const std::vector<RecordedTimelineSpan>& spans,
    bool spanLogOverflowed,
    std::uint32_t sourceChannels,
    std::uint32_t sourceSampleRate) {
    if (spanLogOverflowed) throw std::runtime_error("recording timeline span log overflowed");
    if (audioPath.empty()) throw std::invalid_argument("take audio path is empty");
    if (sourceFrames == 0U) throw std::invalid_argument("take source has no frames");
    if (spans.empty()) return {};

    std::vector<ProjectTakeLane> lanes;
    std::uint64_t nextLaneId = 1U;
    for (const auto& span : spans) {
        if (span.frames == 0U || span.projectStartSample < 0)
            throw std::invalid_argument("invalid recorded timeline span");
        if (span.recorderFrameStart > sourceFrames ||
            static_cast<std::uint64_t>(span.frames) > sourceFrames - span.recorderFrameStart)
            throw std::invalid_argument("recorded timeline span outside WAV source");
        (void)checkedEnd(span.projectStartSample, span.frames, "recorded timeline span overflow");

        auto laneIt = std::find_if(lanes.begin(), lanes.end(), [&](const ProjectTakeLane& lane) {
            return lane.cyclePass == span.cyclePass;
        });
        if (laneIt == lanes.end()) {
            ProjectTakeLane lane;
            lane.id = nextLaneId++;
            lane.cyclePass = span.cyclePass;
            lane.name = "Take " + std::to_string(lanes.size() + 1U);
            lanes.push_back(std::move(lane));
            laneIt = std::prev(lanes.end());
        }

        ProjectAudioClip clip;
        clip.id = static_cast<std::uint64_t>(laneIt->clips.size()) + 1U;
        clip.audioPath = audioPath;
        clip.timelineStartSample = span.projectStartSample;
        clip.sourceStartSample = span.recorderFrameStart;
        clip.lengthSamples = span.frames;
        clip.sourceFrames = sourceFrames;
        clip.sourceChannels = sourceChannels;
        clip.sourceSampleRate = sourceSampleRate;
        laneIt->clips.push_back(std::move(clip));
    }
    return lanes;
}

CompEditor::CompEditor(Project& project, std::size_t trackIndex)
    : project_(project), trackIndex_(trackIndex) {
    if (trackIndex_ >= project_.tracks.size()) throw std::out_of_range("comp editor track index");
    std::unordered_set<std::uint64_t> laneIds;
    for (const auto& lane : track().takeLanes) {
        validateTakeLane(lane);
        if (!laneIds.insert(lane.id).second) throw std::invalid_argument("duplicate take lane id");
    }
    std::unordered_set<std::uint64_t> sectionIds;
    for (const auto& section : track().compSections) {
        validateCompSection(section);
        if (!sectionIds.insert(section.id).second) throw std::invalid_argument("duplicate comp section id");
        const auto& clip = findTakeClip(section.takeLaneId, section.takeClipId);
        const auto end = checkedEnd(section.timelineStartSample, section.lengthSamples, "comp section overflow");
        if (!containsRange(clip, section.timelineStartSample, end))
            throw std::invalid_argument("comp section outside referenced take clip");
    }
}

ProjectTrack& CompEditor::track() { return project_.tracks.at(trackIndex_); }
const ProjectTrack& CompEditor::track() const { return project_.tracks.at(trackIndex_); }

void CompEditor::validateTakeLane(const ProjectTakeLane& lane) {
    if (lane.id == 0U) throw std::invalid_argument("take lane id must be non-zero");
    std::unordered_set<std::uint64_t> clipIds;
    for (const auto& clip : lane.clips) {
        if (clip.id == 0U || clip.audioPath.empty() || clip.timelineStartSample < 0 || clip.sourceFrames == 0U ||
            clip.sourceStartSample >= clip.sourceFrames || clip.lengthSamples == 0U ||
            clip.lengthSamples > clip.sourceFrames - clip.sourceStartSample)
            throw std::invalid_argument("invalid take clip");
        (void)checkedEnd(clip.timelineStartSample, clip.lengthSamples, "take clip timeline overflow");
        if (!clipIds.insert(clip.id).second) throw std::invalid_argument("duplicate take clip id");
    }
}

void CompEditor::validateCompSection(const ProjectCompSection& section) {
    if (section.id == 0U || section.takeLaneId == 0U || section.takeClipId == 0U ||
        section.timelineStartSample < 0 || section.lengthSamples == 0U)
        throw std::invalid_argument("invalid comp section");
    (void)checkedEnd(section.timelineStartSample, section.lengthSamples, "comp section timeline overflow");
}

const ProjectTakeLane& CompEditor::findLane(std::uint64_t laneId) const {
    const auto& lanes = track().takeLanes;
    const auto it = std::find_if(lanes.begin(), lanes.end(), [laneId](const auto& lane) { return lane.id == laneId; });
    if (it == lanes.end()) throw std::out_of_range("take lane id");
    return *it;
}

const ProjectAudioClip& CompEditor::findTakeClip(std::uint64_t laneId, std::uint64_t clipId) const {
    const auto& lane = findLane(laneId);
    const auto it = std::find_if(lane.clips.begin(), lane.clips.end(), [clipId](const auto& clip) { return clip.id == clipId; });
    if (it == lane.clips.end()) throw std::out_of_range("take clip id");
    return *it;
}

std::uint64_t CompEditor::nextSectionId() const {
    std::uint64_t maximum = 0U;
    for (const auto& section : track().compSections) maximum = std::max(maximum, section.id);
    if (maximum == std::numeric_limits<std::uint64_t>::max()) throw std::overflow_error("comp section id exhausted");
    return maximum + 1U;
}

CompEditor::Snapshot CompEditor::snapshot() const {
    return {track().compSections, track().clips};
}

void CompEditor::restore(Snapshot state) {
    track().compSections = std::move(state.sections);
    track().clips = std::move(state.clips);
}

void CompEditor::commit(Snapshot before) {
    Command command {std::move(before), snapshot()};
    undo_.push_back(std::move(command));
    if (undo_.size() > kMaxUndoSteps) undo_.erase(undo_.begin());
    redo_.clear();
}

std::uint64_t CompEditor::selectRange(std::uint64_t takeLaneId,
                                      std::uint64_t takeClipId,
                                      std::int64_t timelineStartSample,
                                      std::int64_t timelineEndSample,
                                      std::uint64_t crossfadeSamples) {
    if (timelineStartSample < 0 || timelineEndSample <= timelineStartSample)
        throw std::invalid_argument("invalid comp range");
    const auto& source = findTakeClip(takeLaneId, takeClipId);
    if (!containsRange(source, timelineStartSample, timelineEndSample))
        throw std::invalid_argument("comp range outside selected take clip");

    Snapshot before = snapshot();
    std::vector<ProjectCompSection> replacement;
    replacement.reserve(track().compSections.size() + 2U);
    std::uint64_t nextId = nextSectionId();

    for (const auto& section : track().compSections) {
        const std::int64_t sectionEnd = checkedEnd(section.timelineStartSample, section.lengthSamples, "comp section overflow");
        if (sectionEnd <= timelineStartSample || section.timelineStartSample >= timelineEndSample) {
            replacement.push_back(section);
            continue;
        }
        if (section.timelineStartSample < timelineStartSample) {
            ProjectCompSection left = section;
            left.lengthSamples = static_cast<std::uint64_t>(timelineStartSample - section.timelineStartSample);
            replacement.push_back(std::move(left));
        }
        if (sectionEnd > timelineEndSample) {
            ProjectCompSection right = section;
            right.id = nextId++;
            right.timelineStartSample = timelineEndSample;
            right.lengthSamples = static_cast<std::uint64_t>(sectionEnd - timelineEndSample);
            right.crossfadeSamples = crossfadeSamples;
            replacement.push_back(std::move(right));
        }
    }

    ProjectCompSection selected;
    selected.id = nextId++;
    selected.takeLaneId = takeLaneId;
    selected.takeClipId = takeClipId;
    selected.timelineStartSample = timelineStartSample;
    selected.lengthSamples = static_cast<std::uint64_t>(timelineEndSample - timelineStartSample);
    selected.crossfadeSamples = crossfadeSamples;
    replacement.push_back(selected);
    std::sort(replacement.begin(), replacement.end(), [](const auto& a, const auto& b) {
        if (a.timelineStartSample != b.timelineStartSample) return a.timelineStartSample < b.timelineStartSample;
        return a.id < b.id;
    });
    track().compSections = std::move(replacement);
    rebuildActiveComp();
    commit(std::move(before));
    return selected.id;
}

void CompEditor::clearRange(std::int64_t timelineStartSample,
                            std::int64_t timelineEndSample) {
    if (timelineStartSample < 0 || timelineEndSample <= timelineStartSample)
        throw std::invalid_argument("invalid comp clear range");
    Snapshot before = snapshot();
    std::vector<ProjectCompSection> replacement;
    std::uint64_t nextId = nextSectionId();
    for (const auto& section : track().compSections) {
        const std::int64_t sectionEnd = checkedEnd(section.timelineStartSample, section.lengthSamples, "comp section overflow");
        if (sectionEnd <= timelineStartSample || section.timelineStartSample >= timelineEndSample) {
            replacement.push_back(section);
            continue;
        }
        if (section.timelineStartSample < timelineStartSample) {
            ProjectCompSection left = section;
            left.lengthSamples = static_cast<std::uint64_t>(timelineStartSample - section.timelineStartSample);
            replacement.push_back(std::move(left));
        }
        if (sectionEnd > timelineEndSample) {
            ProjectCompSection right = section;
            right.id = nextId++;
            right.timelineStartSample = timelineEndSample;
            right.lengthSamples = static_cast<std::uint64_t>(sectionEnd - timelineEndSample);
            right.crossfadeSamples = 0U;
            replacement.push_back(std::move(right));
        }
    }
    std::sort(replacement.begin(), replacement.end(), [](const auto& a, const auto& b) {
        return a.timelineStartSample < b.timelineStartSample;
    });
    track().compSections = std::move(replacement);
    rebuildActiveComp();
    commit(std::move(before));
}

void CompEditor::clearComp() {
    Snapshot before = snapshot();
    track().compSections.clear();
    track().clips.clear();
    commit(std::move(before));
}

void CompEditor::rebuildActiveComp() {
    auto& active = track().clips;
    active.clear();
    if (track().compSections.empty()) return;

    std::vector<ProjectCompSection> sections = track().compSections;
    std::sort(sections.begin(), sections.end(), [](const auto& a, const auto& b) {
        if (a.timelineStartSample != b.timelineStartSample) return a.timelineStartSample < b.timelineStartSample;
        return a.id < b.id;
    });

    active.reserve(sections.size());
    std::int64_t previousLogicalEnd = -1;
    const ProjectAudioClip* previousTakeClip = nullptr;
    for (const auto& section : sections) {
        validateCompSection(section);
        const auto& takeClip = findTakeClip(section.takeLaneId, section.takeClipId);
        const std::int64_t sectionEnd = checkedEnd(section.timelineStartSample, section.lengthSamples, "comp section overflow");
        if (!containsRange(takeClip, section.timelineStartSample, sectionEnd))
            throw std::invalid_argument("comp section outside referenced take clip");

        ProjectAudioClip clip = takeClip;
        clip.id = section.id;
        clip.timelineStartSample = section.timelineStartSample;
        clip.sourceStartSample = takeClip.sourceStartSample +
            static_cast<std::uint64_t>(section.timelineStartSample - takeClip.timelineStartSample);
        clip.lengthSamples = section.lengthSamples;
        // Section boundaries supersede take-lane fades. Crossfade setup below is
        // then deterministic and sample-identical for hard edits.
        clip.fadeInSamples = 0U;
        clip.fadeOutSamples = 0U;
        clip.fadeInAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
        clip.fadeOutAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;

        if (!active.empty() && previousTakeClip != nullptr && previousLogicalEnd == section.timelineStartSample &&
            section.crossfadeSamples != 0U) {
            ProjectAudioClip& previous = active.back();
            const std::uint64_t requested = section.crossfadeSamples;
            const std::uint64_t currentAvailable = clip.lengthSamples;
            const std::uint64_t previousSourceEnd = previous.sourceStartSample + previous.lengthSamples;
            const std::uint64_t previousTakeEnd = previousTakeClip->sourceStartSample + previousTakeClip->lengthSamples;
            const std::uint64_t previousAvailable = previousSourceEnd <= previousTakeEnd
                ? previousTakeEnd - previousSourceEnd : 0U;
            const std::uint64_t overlap = std::min({requested, currentAvailable, previousAvailable});
            if (overlap != 0U) {
                previous.lengthSamples += overlap;
                previous.fadeOutSamples = overlap;
                previous.fadeOutAnchorSourceSample = previous.sourceStartSample + previous.lengthSamples;
                clip.fadeInSamples = overlap;
                clip.fadeInAnchorSourceSample = clip.sourceStartSample;
            }
        }

        active.push_back(std::move(clip));
        previousLogicalEnd = sectionEnd;
        previousTakeClip = &takeClip;
    }
}

bool CompEditor::undo() {
    if (undo_.empty()) return false;
    Command command = std::move(undo_.back());
    undo_.pop_back();
    restore(command.before);
    redo_.push_back(std::move(command));
    return true;
}

bool CompEditor::redo() {
    if (redo_.empty()) return false;
    Command command = std::move(redo_.back());
    redo_.pop_back();
    restore(command.after);
    undo_.push_back(std::move(command));
    if (undo_.size() > kMaxUndoSteps) undo_.erase(undo_.begin());
    return true;
}

void CompEditor::clearHistory() noexcept {
    undo_.clear();
    redo_.clear();
}

} // namespace silveton
