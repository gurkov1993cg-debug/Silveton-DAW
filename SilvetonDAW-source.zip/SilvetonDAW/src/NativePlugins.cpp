#include "silveton/NativePlugins.h"
#include "internal/NativePluginFactories.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>

#if defined(__x86_64__) || defined(_M_X64) || defined(__SSE2__)
#include <xmmintrin.h>
#define SILVETON_NATIVE_FTZ 1
#endif

namespace silveton {

namespace {
// Flush-to-zero / denormals-are-zero only while native DSP runs, restoring
// the caller's MXCSR afterwards. Reverb/delay tails otherwise decay into
// denormals, which are extremely slow on Intel CPUs such as the iMac 2011.
struct DenormalGuard {
#if defined(SILVETON_NATIVE_FTZ)
    unsigned int saved;
    DenormalGuard() noexcept : saved(_mm_getcsr()) { _mm_setcsr(saved | 0x8040U); }
    ~DenormalGuard() { _mm_setcsr(saved); }
#endif
};
const std::string kNativeModule(kNativeModulePath);
constexpr const char* kStateMagic = "SILVETON_NATIVE_STATE_V1";
constexpr const char* kPresetMagic = "SILVETON_NATIVE_PRESET_V1";
} // namespace

const std::vector<NativePluginInfo>& nativePluginCatalog() {
    static const std::vector<NativePluginInfo> catalog = {
        {"silveton.contour-eq", "Contour EQ", "EQ", false, false},
        {"silveton.press", "Press Compressor", "Dynamics", false, true},
        {"silveton.gate", "Gate", "Dynamics", false, true},
        {"silveton.ceiling", "Ceiling Limiter", "Dynamics", false, false},
        {"silveton.echo", "Echo Delay", "Delay", false, false},
        {"silveton.space", "Space Reverb", "Reverb", false, false},
        {"silveton.drive", "Drive Saturator", "Distortion", false, false},
        {"silveton.chorus", "Ensemble Chorus", "Modulation", false, false},
        {"silveton.poly", "Poly Synth", "Instrument", true, false},
    };
    return catalog;
}

bool isNativeModulePath(const std::string& modulePath) noexcept { return modulePath == kNativeModule; }

NativePlugin::NativePlugin(const NativePluginInfo& info, std::vector<NativeParameterInfo> parameters)
    : info_(info), parameters_(std::move(parameters)) {
    for (std::size_t i = 0U; i < parameters_.size(); ++i) {
        if (parameters_[i].id != i) throw std::logic_error("native parameter ids must be contiguous");
        if (!(parameters_[i].maxValue > parameters_[i].minValue)) throw std::logic_error("native parameter range invalid");
        if (parameters_[i].scale == NativeParamScale::Logarithmic && parameters_[i].minValue <= 0.0)
            throw std::logic_error("logarithmic native parameter requires positive range");
    }
    normalized_ = std::make_unique<std::atomic<double>[]>(parameters_.size());
    current_.resize(parameters_.size());
    lastApplied_.assign(parameters_.size(), std::numeric_limits<double>::quiet_NaN());
    for (std::size_t i = 0U; i < parameters_.size(); ++i) {
        const double n = toNormalized(parameters_[i], parameters_[i].defaultValue);
        normalized_[i].store(n, std::memory_order_relaxed);
        current_[i] = toPlain(parameters_[i], n);
    }
    for (auto& m : meters_) m.store(0.0F, std::memory_order_relaxed);
}

NativePlugin::~NativePlugin() = default;

double NativePlugin::toNormalized(const NativeParameterInfo& p, double plain) noexcept {
    if (!std::isfinite(plain)) plain = p.defaultValue;
    plain = std::clamp(plain, p.minValue, p.maxValue);
    switch (p.scale) {
        case NativeParamScale::Logarithmic:
            return std::log(plain / p.minValue) / std::log(p.maxValue / p.minValue);
        case NativeParamScale::Toggle:
            return plain >= 0.5 * (p.minValue + p.maxValue) ? 1.0 : 0.0;
        default:
            return (plain - p.minValue) / (p.maxValue - p.minValue);
    }
}

double NativePlugin::toPlain(const NativeParameterInfo& p, double normalized) noexcept {
    if (!std::isfinite(normalized)) normalized = toNormalized(p, p.defaultValue);
    normalized = std::clamp(normalized, 0.0, 1.0);
    switch (p.scale) {
        case NativeParamScale::Logarithmic:
            return p.minValue * std::pow(p.maxValue / p.minValue, normalized);
        case NativeParamScale::Toggle:
            return normalized >= 0.5 ? p.maxValue : p.minValue;
        case NativeParamScale::Choice:
        case NativeParamScale::Integer:
            return std::round(p.minValue + normalized * (p.maxValue - p.minValue));
        default:
            return p.minValue + normalized * (p.maxValue - p.minValue);
    }
}

double NativePlugin::normalizedValue(std::uint32_t id) const noexcept {
    if (id >= parameters_.size()) return 0.0;
    return normalized_[id].load(std::memory_order_acquire);
}

double NativePlugin::plainValue(std::uint32_t id) const noexcept {
    if (id >= parameters_.size()) return 0.0;
    return toPlain(parameters_[id], normalizedValue(id));
}

std::string NativePlugin::formatValue(std::uint32_t id) const {
    if (id >= parameters_.size()) return {};
    const auto& info = parameters_[id];
    const double v = plainValue(id);
    std::ostringstream ss;
    if (info.scale == NativeParamScale::Toggle) return v >= 0.5 ? "On" : "Off";
    if (info.scale == NativeParamScale::Choice) {
        const auto index = static_cast<std::size_t>(std::max(0.0, v - info.minValue));
        if (index < info.choices.size()) return info.choices[index];
    }
    if (info.scale == NativeParamScale::Integer) ss << static_cast<long long>(std::llround(v));
    else if (info.units == "Hz" && v >= 1000.0) { ss << std::fixed << std::setprecision(2) << v / 1000.0 << " kHz"; return ss.str(); }
    else if (std::abs(v) >= 100.0) ss << std::fixed << std::setprecision(0) << v;
    else if (std::abs(v) >= 10.0) ss << std::fixed << std::setprecision(1) << v;
    else ss << std::fixed << std::setprecision(2) << v;
    if (!info.units.empty()) ss << ' ' << info.units;
    return ss.str();
}

void NativePlugin::setPlainValue(std::uint32_t id, double plain) noexcept {
    if (id >= parameters_.size()) return;
    normalized_[id].store(toNormalized(parameters_[id], plain), std::memory_order_release);
    uiDirty_.store(true, std::memory_order_release);
}

void NativePlugin::beginEdit(std::uint32_t id) {
    if (id >= parameters_.size()) return;
    std::lock_guard<std::mutex> lock(gestureMutex_);
    gestures_.push_back({AutomationGestureType::Begin, id, -1, normalizedValue(id)});
}

void NativePlugin::setFromEditor(std::uint32_t id, double plain) {
    if (id >= parameters_.size()) return;
    setPlainValue(id, plain);
    std::lock_guard<std::mutex> lock(gestureMutex_);
    gestures_.push_back({AutomationGestureType::Value, id, -1, normalizedValue(id)});
}

void NativePlugin::endEdit(std::uint32_t id) {
    if (id >= parameters_.size()) return;
    std::lock_guard<std::mutex> lock(gestureMutex_);
    gestures_.push_back({AutomationGestureType::End, id, -1, normalizedValue(id)});
}

bool NativePlugin::popAutomationGesture(AutomationGesture& event) noexcept {
    std::lock_guard<std::mutex> lock(gestureMutex_);
    if (gestures_.empty()) return false;
    event = gestures_.front();
    gestures_.pop_front();
    return true;
}

bool NativePlugin::popOutputParameter(Vst3OutputParameterChange&) noexcept { return false; }

std::uint32_t NativePlugin::consumeRestartFlags() noexcept { return restartFlags_.exchange(0U, std::memory_order_acq_rel); }

float NativePlugin::meter(std::size_t index) const noexcept {
    return index < 4U ? meters_[index].load(std::memory_order_acquire) : 0.0F;
}

void NativePlugin::setMeter(std::size_t index, float value) noexcept {
    if (index < 4U) meters_[index].store(value, std::memory_order_release);
}

const std::string& NativePlugin::modulePath() const noexcept { return kNativeModule; }

std::size_t NativePlugin::inputBusChannelCount(std::size_t bus) const noexcept { return bus < inputBusCount() ? 2U : 0U; }
std::size_t NativePlugin::outputBusChannelCount(std::size_t bus) const noexcept { return bus == 0U ? 2U : 0U; }

std::size_t NativePlugin::inputBusCount() const noexcept {
    if (info_.instrument) return 0U;
    return info_.sidechain ? 2U : 1U;
}

std::vector<std::uint8_t> NativePlugin::componentState() const {
    std::ostringstream ss;
    ss << kStateMagic << '\n' << info_.classId << '\n';
    ss << std::setprecision(17);
    for (const auto& p : parameters_) ss << p.id << '\t' << normalizedValue(p.id) << '\n';
    const std::string s = ss.str();
    return std::vector<std::uint8_t>(s.begin(), s.end());
}

bool NativePlugin::setComponentState(const std::vector<std::uint8_t>& state) {
    if (state.empty()) return true;
    std::istringstream ss(std::string(state.begin(), state.end()));
    std::string line;
    if (!std::getline(ss, line) || line != kStateMagic) return false;
    if (!std::getline(ss, line) || line != info_.classId) return false;
    std::vector<double> values(parameters_.size());
    for (std::size_t i = 0U; i < parameters_.size(); ++i) values[i] = normalizedValue(static_cast<std::uint32_t>(i));
    while (std::getline(ss, line)) {
        if (line.empty()) continue;
        std::istringstream ls(line);
        std::uint32_t id = 0U;
        double value = 0.0;
        if (!(ls >> id >> value)) return false;
        // Unknown ids come from a newer Silveton version; ignore them.
        if (id < values.size() && std::isfinite(value)) values[id] = std::clamp(value, 0.0, 1.0);
    }
    for (std::size_t i = 0U; i < values.size(); ++i) normalized_[i].store(values[i], std::memory_order_release);
    uiDirty_.store(true, std::memory_order_release);
    return true;
}

bool NativePlugin::setControllerState(const std::vector<std::uint8_t>&) { return true; }
std::vector<std::uint8_t> NativePlugin::controllerState() const { return {}; }

bool NativePlugin::savePreset(const std::string& path) const {
    std::ofstream out(path.c_str(), std::ios::binary);
    if (!out) return false;
    const auto state = componentState();
    out << kPresetMagic << '\n';
    out.write(reinterpret_cast<const char*>(state.data()), static_cast<std::streamsize>(state.size()));
    return static_cast<bool>(out);
}

bool NativePlugin::loadPreset(const std::string& path) {
    std::ifstream in(path.c_str(), std::ios::binary);
    if (!in) return false;
    std::string magic;
    if (!std::getline(in, magic) || magic != kPresetMagic) return false;
    std::string rest((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    return setComponentState(std::vector<std::uint8_t>(rest.begin(), rest.end()));
}

bool NativePlugin::queueMidi(const Vst3MidiEvent& event) noexcept {
    if (!info_.instrument) return false;
    return midiEvents_.push(event);
}

bool NativePlugin::queueParameter(std::uint32_t parameterId, double normalized, std::int32_t frameOffset) noexcept {
    if (parameterId >= parameters_.size() || !std::isfinite(normalized)) return false;
    normalized = std::clamp(normalized, 0.0, 1.0);
    if (frameOffset <= 0) {
        normalized_[parameterId].store(normalized, std::memory_order_release);
        uiDirty_.store(true, std::memory_order_release);
        return true;
    }
    // Offsets inside the block are produced only by the audio thread
    // (Vst3RuntimeRack::queueAutomationForBlock), keeping this queue SPSC.
    return paramEvents_.push({parameterId, frameOffset, normalized});
}

void NativePlugin::prepare(double sampleRate, std::uint32_t maxFrames) {
    if (!(sampleRate > 0.0) || maxFrames == 0U) throw std::invalid_argument("native plug-in prepare");
    sampleRate_ = sampleRate;
    maxFrames_ = maxFrames;
    silentL_.assign(maxFrames, 0.0F);
    silentR_.assign(maxFrames, 0.0F);
    onPrepare(sampleRate, maxFrames);
    snapshotParameters();
    onParametersChanged();
    onReset();
}

void NativePlugin::reset() noexcept { onReset(); }

std::uint64_t NativePlugin::tailSamples() const noexcept { return computeTailSamples(); }

void NativePlugin::snapshotParameters() noexcept {
    for (std::size_t i = 0U; i < parameters_.size(); ++i)
        current_[i] = toPlain(parameters_[i], normalized_[i].load(std::memory_order_acquire));
}

void NativePlugin::process(float* left, float* right, std::uint32_t frames, const ProcessorContext& context) noexcept {
    // Direct (non-routed) use: in-place stereo. processBuses writes a separate
    // output, so copy the input first.
    if (frames > maxFrames_ || left == nullptr || right == nullptr) return;
    std::copy_n(left, frames, silentL_.data());
    std::copy_n(right, frames, silentR_.data());
    ConstStereoBus in {silentL_.data(), silentR_.data()};
    StereoBus out {left, right};
    (void)processBuses(&in, info_.instrument ? 0U : 1U, &out, 1U, frames, context);
    std::fill(silentL_.begin(), silentL_.end(), 0.0F);
    std::fill(silentR_.begin(), silentR_.end(), 0.0F);
}

void NativePlugin::renderRange(const ConstStereoBus* inputs, std::size_t inputCount, StereoBus out,
                               std::uint32_t start, std::uint32_t count, const ProcessorContext& context) noexcept {
    if (count == 0U) return;
    bool changed = false;
    for (std::size_t i = 0U; i < current_.size(); ++i) {
        if (!(current_[i] == lastApplied_[i])) { changed = true; lastApplied_[i] = current_[i]; }
    }
    if (changed) onParametersChanged();
    RenderIO io;
    const float* zeroL = silentL_.data();
    const float* zeroR = silentR_.data();
    io.inL = (inputCount > 0U && inputs[0].left) ? inputs[0].left + start : zeroL;
    io.inR = (inputCount > 0U && inputs[0].right) ? inputs[0].right + start : zeroR;
    if (inputCount > 1U && inputs[1].left && inputs[1].right) {
        io.sideL = inputs[1].left + start;
        io.sideR = inputs[1].right + start;
    }
    io.outL = out.left + start;
    io.outR = out.right + start;
    io.frames = count;
    ProcessorContext sub = context;
    sub.projectSample = context.projectSample + static_cast<std::int64_t>(start);
    sub.frames = count;
    render(io, sub);
}

bool NativePlugin::processBuses(const ConstStereoBus* inputs, std::size_t inputBusCount,
                                StereoBus* outputs, std::size_t outputBusCount,
                                std::uint32_t frames, const ProcessorContext& context) noexcept {
    if (outputs == nullptr || outputBusCount == 0U || outputs[0].left == nullptr || outputs[0].right == nullptr) return false;
    if (frames == 0U) return true;
    if (frames > maxFrames_) return false;
    const DenormalGuard denormalGuard;
    (void)denormalGuard;

    snapshotParameters();

    std::size_t paramCount = 0U;
    ParamEvent pe;
    while (paramCount < 512U && paramEvents_.pop(pe)) {
        pe.offset = std::clamp<std::int32_t>(pe.offset, 0, static_cast<std::int32_t>(frames) - 1);
        std::size_t j = paramCount++;
        while (j > 0U && blockParams_[j - 1U].offset > pe.offset) { blockParams_[j] = blockParams_[j - 1U]; --j; }
        blockParams_[j] = pe;
    }
    std::size_t midiCount = 0U;
    Vst3MidiEvent me;
    while (midiCount < 1024U && midiEvents_.pop(me)) {
        me.frameOffset = std::clamp<std::int32_t>(me.frameOffset, 0, static_cast<std::int32_t>(frames) - 1);
        std::size_t j = midiCount++;
        while (j > 0U && blockMidi_[j - 1U].frameOffset > me.frameOffset) { blockMidi_[j] = blockMidi_[j - 1U]; --j; }
        blockMidi_[j] = me;
    }

    std::size_t pi = 0U;
    std::size_t mi = 0U;
    std::uint32_t pos = 0U;
    while (pos < frames) {
        // Apply every event scheduled at `pos`.
        while (pi < paramCount && static_cast<std::uint32_t>(blockParams_[pi].offset) <= pos) {
            const auto& e = blockParams_[pi++];
            normalized_[e.id].store(e.normalized, std::memory_order_release);
            current_[e.id] = toPlain(parameters_[e.id], e.normalized);
        }
        while (mi < midiCount && static_cast<std::uint32_t>(blockMidi_[mi].frameOffset) <= pos) onMidi(blockMidi_[mi++]);
        std::uint32_t next = frames;
        if (pi < paramCount) next = std::min(next, static_cast<std::uint32_t>(blockParams_[pi].offset));
        if (mi < midiCount) next = std::min(next, static_cast<std::uint32_t>(blockMidi_[mi].frameOffset));
        if (next <= pos) next = pos + 1U;
        renderRange(inputs, inputBusCount, outputs[0], pos, next - pos, context);
        pos = next;
    }
    uiDirty_.store(false, std::memory_order_release);
    return true;
}

std::unique_ptr<NativePlugin> createNativePlugin(const std::string& classId, std::string& failureReason) {
    std::unique_ptr<NativePlugin> plugin;
    if (classId == "silveton.contour-eq") plugin = native_detail::makeContourEq();
    else if (classId == "silveton.press") plugin = native_detail::makePressCompressor();
    else if (classId == "silveton.gate") plugin = native_detail::makeGate();
    else if (classId == "silveton.ceiling") plugin = native_detail::makeCeilingLimiter();
    else if (classId == "silveton.echo") plugin = native_detail::makeEchoDelay();
    else if (classId == "silveton.space") plugin = native_detail::makeSpaceReverb();
    else if (classId == "silveton.drive") plugin = native_detail::makeDriveSaturator();
    else if (classId == "silveton.chorus") plugin = native_detail::makeEnsembleChorus();
    else if (classId == "silveton.poly") plugin = native_detail::makePolySynth();
    if (!plugin) failureReason = "unknown Silveton Native processor: " + classId;
    return plugin;
}

std::unique_ptr<IVst3PluginInstance> CompositeInstanceFactory::create(const std::string& modulePath,
                                                                      const std::string& classId,
                                                                      std::string& failureReason) {
    if (isNativeModulePath(modulePath)) return createNativePlugin(classId, failureReason);
    if (external_ == nullptr) {
        failureReason = "VST3 hosting is not available in this build";
        return nullptr;
    }
    return external_->create(modulePath, classId, failureReason);
}

} // namespace silveton
