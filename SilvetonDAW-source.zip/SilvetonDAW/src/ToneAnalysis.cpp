// Silveton Tone Editor — scales and the analysis: where is the pitch, and which notes are sung.
//
// Pitch search: YIN (difference function, computed with an FFT) gives up to four possible periods
// for every 5 ms frame; a Viterbi search over the whole recording picks the most believable path
// (a voice moves smoothly, so octave mistakes are expensive) and decides where there is no pitch at
// all. The period of every frame is then refined on the full-rate audio, so the pitch is exact to a
// few hundredths of a cent for steady sounds.
//
// Tone blocks: inside each stretch with pitch, an optimal partition of the pitch curve into flat
// pieces (dynamic programming) finds the notes; wobble (vibrato) is not cut because a piece costs.
// Dips in loudness cut repeated notes of the same pitch.
#include "silveton/ToneEdit.h"
#include "internal/ToneInternal.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <limits>
#include <numeric>

namespace silveton {

using namespace toneinternal;

// ===================================================================== scales ==
namespace {
struct ScaleDef { const char* name; std::uint16_t mask; };
const ScaleDef kScales[] = {
    {"Chromatic", 0x0FFF},
    {"Major", (1U << 0) | (1U << 2) | (1U << 4) | (1U << 5) | (1U << 7) | (1U << 9) | (1U << 11)},
    {"Natural Minor", (1U << 0) | (1U << 2) | (1U << 3) | (1U << 5) | (1U << 7) | (1U << 8) | (1U << 10)},
    {"Harmonic Minor", (1U << 0) | (1U << 2) | (1U << 3) | (1U << 5) | (1U << 7) | (1U << 8) | (1U << 11)},
    {"Melodic Minor", (1U << 0) | (1U << 2) | (1U << 3) | (1U << 5) | (1U << 7) | (1U << 9) | (1U << 11)},
    {"Dorian", (1U << 0) | (1U << 2) | (1U << 3) | (1U << 5) | (1U << 7) | (1U << 9) | (1U << 10)},
    {"Phrygian", (1U << 0) | (1U << 1) | (1U << 3) | (1U << 5) | (1U << 7) | (1U << 8) | (1U << 10)},
    {"Lydian", (1U << 0) | (1U << 2) | (1U << 4) | (1U << 6) | (1U << 7) | (1U << 9) | (1U << 11)},
    {"Mixolydian", (1U << 0) | (1U << 2) | (1U << 4) | (1U << 5) | (1U << 7) | (1U << 9) | (1U << 10)},
    {"Major Pentatonic", (1U << 0) | (1U << 2) | (1U << 4) | (1U << 7) | (1U << 9)},
    {"Minor Pentatonic", (1U << 0) | (1U << 3) | (1U << 5) | (1U << 7) | (1U << 10)},
    {"Blues", (1U << 0) | (1U << 3) | (1U << 5) | (1U << 6) | (1U << 7) | (1U << 10)},
    {"Whole Tone", (1U << 0) | (1U << 2) | (1U << 4) | (1U << 6) | (1U << 8) | (1U << 10)},
};
constexpr const char* kNoteNames[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
} // namespace

const char* ToneScale::kindName(ToneScaleKind kind) noexcept {
    const auto i = static_cast<std::size_t>(kind);
    return i < sizeof(kScales) / sizeof(kScales[0]) ? kScales[i].name : "Chromatic";
}

bool ToneScale::contains(int pitchClass) const noexcept {
    const int rel = (((pitchClass - root) % 12) + 12) % 12;
    const auto i = static_cast<std::size_t>(kind);
    const std::uint16_t mask = i < sizeof(kScales) / sizeof(kScales[0]) ? kScales[i].mask : 0x0FFFU;
    return ((mask >> rel) & 1U) != 0U;
}

double ToneScale::nearest(double midi) const noexcept {
    if (chromatic()) return std::floor(midi + 0.5);
    const double base = std::floor(midi);
    double best = base;
    double bestDistance = std::numeric_limits<double>::max();
    for (int k = -6; k <= 7; ++k) {
        const double candidate = base + static_cast<double>(k);
        if (!contains(static_cast<int>(std::llround(candidate)))) continue;
        const double distance = std::abs(candidate - midi);
        if (distance < bestDistance - 1.0e-9) { bestDistance = distance; best = candidate; }
    }
    return best;
}

std::string ToneScale::name() const {
    if (chromatic()) return "Chromatic";
    return std::string(kNoteNames[((root % 12) + 12) % 12]) + " " + kindName(kind);
}

// ============================================================ small utilities ==
namespace {

class Fft {
public:
    explicit Fft(std::size_t n) : n_(n), twiddle_(n / 2U), reverse_(n) {
        for (std::size_t i = 0U; i < n / 2U; ++i)
            twiddle_[i] = std::polar(1.0, -2.0 * kPi * static_cast<double>(i) / static_cast<double>(n));
        std::size_t bits = 0U;
        while ((static_cast<std::size_t>(1U) << bits) < n) ++bits;
        for (std::size_t i = 0U; i < n; ++i) {
            std::size_t r = 0U;
            for (std::size_t b = 0U; b < bits; ++b) if ((i >> b) & 1U) r |= static_cast<std::size_t>(1U) << (bits - 1U - b);
            reverse_[i] = r;
        }
    }
    [[nodiscard]] std::size_t size() const noexcept { return n_; }
    void transform(std::complex<double>* data, bool inverse) const {
        for (std::size_t i = 0U; i < n_; ++i) if (i < reverse_[i]) std::swap(data[i], data[reverse_[i]]);
        for (std::size_t len = 2U; len <= n_; len <<= 1U) {
            const std::size_t half = len / 2U;
            const std::size_t step = n_ / len;
            for (std::size_t i = 0U; i < n_; i += len) {
                for (std::size_t k = 0U; k < half; ++k) {
                    std::complex<double> w = twiddle_[k * step];
                    if (inverse) w = std::conj(w);
                    const std::complex<double> u = data[i + k];
                    const std::complex<double> v = data[i + k + half] * w;
                    data[i + k] = u + v;
                    data[i + k + half] = u - v;
                }
            }
        }
        if (inverse) {
            const double s = 1.0 / static_cast<double>(n_);
            for (std::size_t i = 0U; i < n_; ++i) data[i] *= s;
        }
    }
private:
    std::size_t n_;
    std::vector<std::complex<double>> twiddle_;
    std::vector<std::size_t> reverse_;
};

std::size_t nextPow2(std::size_t n) { std::size_t p = 1U; while (p < n) p <<= 1U; return p; }

struct Biquad {
    double b0 {1}, b1 {0}, b2 {0}, a1 {0}, a2 {0};
    double z1 {0}, z2 {0};
    static Biquad highpass(double fc, double rate, double q = 0.7071) {
        const double w = 2.0 * kPi * fc / rate, c = std::cos(w), s = std::sin(w), alpha = s / (2.0 * q), a0 = 1.0 + alpha;
        Biquad f;
        f.b0 = (1.0 + c) / 2.0 / a0; f.b1 = -(1.0 + c) / a0; f.b2 = (1.0 + c) / 2.0 / a0;
        f.a1 = -2.0 * c / a0; f.a2 = (1.0 - alpha) / a0;
        return f;
    }
    double process(double x) {
        const double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
};

struct Candidate {
    float lag {0.0F};     // fractional, in samples of the analysis rate
    float cost {0.0F};
    float dip {1.0F};     // normalised difference at the minimum
};

// Frame data from the pitch search.
struct FrameCandidates {
    std::array<Candidate, 4> c {};
    std::uint8_t count {0};
    float rawLag {0.0F};  // best minimum below 0.6, even if the search says "not voiced"
};

double median3(double a, double b, double c) { return std::max(std::min(a, b), std::min(std::max(a, b), c)); }

// Refines a period (in samples of the real rate) on the full-rate signal with a normalised cross-correlation.
double refinePeriod(const std::vector<float>& x, long centre, double period, long spread, double rate) {
    const long n = static_cast<long>(x.size());
    const long window = std::max<long>(std::lround(1.1 * period), std::lround(0.006 * rate));
    const long lagMin = static_cast<long>(std::floor(period)) - spread;
    const long lagMax = static_cast<long>(std::ceil(period)) + spread;
    if (lagMin < 2) return period;
    const long a0 = centre - window, a1 = centre + window;
    if (a0 < 0 || a1 + lagMax >= n) return period;
    double ea = 0.0;
    for (long j = a0; j < a1; ++j) ea += static_cast<double>(x[static_cast<std::size_t>(j)]) * static_cast<double>(x[static_cast<std::size_t>(j)]);
    if (ea < 1.0e-12) return period;
    double eb = 0.0;
    for (long j = a0 + lagMin; j < a1 + lagMin; ++j) eb += static_cast<double>(x[static_cast<std::size_t>(j)]) * static_cast<double>(x[static_cast<std::size_t>(j)]);
    const std::size_t count = static_cast<std::size_t>(lagMax - lagMin + 1);
    std::vector<double> ncc(count, 0.0);
    for (std::size_t li = 0U; li < count; ++li) {
        const long lag = lagMin + static_cast<long>(li);
        const float* p = x.data() + a0;
        const float* q = x.data() + a0 + lag;
        double dot = 0.0;
        const long len = a1 - a0;
        for (long j = 0; j < len; ++j) dot += static_cast<double>(p[j]) * static_cast<double>(q[j]);
        ncc[li] = dot / std::sqrt(ea * std::max(eb, 1.0e-12));
        // slide the energy window one lag further
        const float outS = x[static_cast<std::size_t>(a0 + lag)];
        const float inS = x[static_cast<std::size_t>(a1 + lag)];
        eb += static_cast<double>(inS) * static_cast<double>(inS) - static_cast<double>(outS) * static_cast<double>(outS);
        if (eb < 0.0) eb = 0.0;
    }
    std::size_t best = 0U;
    for (std::size_t i = 1U; i < count; ++i) if (ncc[i] > ncc[best]) best = i;
    double lag = static_cast<double>(lagMin + static_cast<long>(best));
    if (best > 0U && best + 1U < count) {
        const double y0 = ncc[best - 1U], y1 = ncc[best], y2 = ncc[best + 1U];
        const double denom = y0 - 2.0 * y1 + y2;
        if (denom < -1.0e-12) lag += std::clamp(0.5 * (y0 - y2) / denom, -1.0, 1.0);
    }
    if (std::abs(lag - period) > 0.03 * period + 1.0) return period;
    return lag;
}

} // namespace

// ============================================================= heard pitch ==
namespace toneinternal {

bool heardPitch(const ToneFrames& f, std::size_t first, std::size_t last, bool allowRaw, double& midiOut, double& levelDbOut) {
    std::vector<std::pair<double, double>> values;   // (midi, weight)
    double levelSum = 0.0;
    std::size_t levelCount = 0U;
    last = std::min(last, f.size());
    for (std::size_t i = first; i < last; ++i) {
        double hz = f.hz[i];
        if (hz <= 0.0 && allowRaw && i < f.rawHz.size()) hz = f.rawHz[i];
        if (hz <= 0.0) continue;
        values.emplace_back(midiFromHz(hz), std::max(1.0e-5, static_cast<double>(f.level[i])));
        levelSum += static_cast<double>(f.level[i]) * static_cast<double>(f.level[i]);
        ++levelCount;
    }
    if (values.empty()) return false;
    // leave out the outer 15 % on both sides (scoops, glides into the note)
    const std::size_t total = values.size();
    std::size_t skip = total >= 8U ? static_cast<std::size_t>(std::floor(0.15 * static_cast<double>(total))) : 0U;
    std::vector<std::pair<double, double>> core(values.begin() + static_cast<std::ptrdiff_t>(skip), values.end() - static_cast<std::ptrdiff_t>(skip));
    if (core.empty()) core = values;
    std::vector<double> sorted;
    sorted.reserve(core.size());
    for (const auto& v : core) sorted.push_back(v.first);
    std::sort(sorted.begin(), sorted.end());
    const double median = sorted[sorted.size() / 2U];
    double sum = 0.0, weight = 0.0;
    for (const auto& v : core) {
        if (std::abs(v.first - median) > 1.0) continue;
        sum += v.first * v.second;
        weight += v.second;
    }
    midiOut = weight > 0.0 ? sum / weight : median;
    const double rms = levelCount > 0U ? std::sqrt(levelSum / static_cast<double>(levelCount)) : 0.0;
    levelDbOut = 20.0 * std::log10(std::max(1.0e-6, rms));
    return true;
}

void refreshBlock(ToneBlock& block, const ToneAnalysis& analysis, double fallbackPitch) {
    std::size_t first = 0U, last = 0U;
    framesOfRange(analysis.frames, block.start, block.end, first, last);
    double midi = 0.0, db = 0.0;
    if (heardPitch(analysis.frames, first, last, true, midi, db)) {
        block.pitch = static_cast<float>(midi);
        block.levelDb = static_cast<float>(db);
    } else {
        block.pitch = static_cast<float>(fallbackPitch);
    }
}

} // namespace toneinternal

// ================================================================== analysis ==
namespace {

struct Range { std::size_t a; std::size_t b; };   // frames [a, b)

// Splits one stretch with pitch into notes.
std::vector<Range> partitionRun(const std::vector<double>& y, const std::vector<double>& weight, const std::vector<double>& dbLevel,
                                std::size_t minLen, double splitSens, std::size_t base) {
    const std::size_t n = y.size();
    std::vector<Range> out;
    if (n == 0U) return out;
    std::vector<double> s0(n + 1U, 0.0), s1(n + 1U, 0.0), s2(n + 1U, 0.0);
    for (std::size_t i = 0U; i < n; ++i) {
        s0[i + 1U] = s0[i] + weight[i];
        s1[i + 1U] = s1[i] + weight[i] * y[i];
        s2[i + 1U] = s2[i] + weight[i] * y[i] * y[i];
    }
    const auto cost = [&](std::size_t a, std::size_t b) {
        const double w = s0[b] - s0[a];
        if (w <= 0.0) return 0.0;
        const double m1 = s1[b] - s1[a];
        return std::max(0.0, (s2[b] - s2[a]) - m1 * m1 / w);
    };
    const double beta = 3.5 + 11.0 * (1.0 - std::clamp(splitSens, 0.0, 1.0));
    const std::size_t maxLook = 700U;
    std::vector<double> best(n + 1U, std::numeric_limits<double>::max());
    std::vector<std::size_t> from(n + 1U, 0U);
    best[0] = 0.0;
    for (std::size_t b = 1U; b <= n; ++b) {
        if (b < minLen) {
            best[b] = cost(0U, b) + beta; from[b] = 0U;
            continue;
        }
        const std::size_t lo = b > maxLook ? b - maxLook : 0U;
        for (std::size_t a = lo; a + minLen <= b; ++a) {
            if (best[a] == std::numeric_limits<double>::max()) continue;
            const double c = best[a] + cost(a, b) + beta;
            if (c < best[b]) { best[b] = c; from[b] = a; }
        }
        if (best[b] == std::numeric_limits<double>::max()) { best[b] = cost(0U, b) + beta; from[b] = 0U; }
    }
    std::vector<Range> pieces;
    for (std::size_t b = n; b > 0U;) { const std::size_t a = from[b]; pieces.push_back({a, b}); b = a; }
    std::reverse(pieces.begin(), pieces.end());

    // Merge neighbours that are almost the same pitch and have no dip in loudness between them.
    const auto meanOf = [&](const Range& r) { const double w = s0[r.b] - s0[r.a]; return w > 0.0 ? (s1[r.b] - s1[r.a]) / w : 0.0; };
    const auto dipBetween = [&](const Range& left, const Range& right) {
        const std::size_t lo = left.b > 4U + left.a ? left.b - 4U : left.a;
        const std::size_t hi = std::min(right.b, right.a + 4U);
        double minDb = 1.0e9;
        for (std::size_t i = lo; i < hi; ++i) minDb = std::min(minDb, dbLevel[i]);
        double l = 0.0, r = 0.0;
        for (std::size_t i = left.a; i < left.b; ++i) l = std::max(l, dbLevel[i]);
        for (std::size_t i = right.a; i < right.b; ++i) r = std::max(r, dbLevel[i]);
        return std::min(l, r) - minDb;
    };
    const double mergeCents = 0.55 - 0.3 * (std::clamp(splitSens, 0.0, 1.0) - 0.5);
    bool merged = true;
    while (merged && pieces.size() > 1U) {
        merged = false;
        for (std::size_t i = 0U; i + 1U < pieces.size(); ++i) {
            if (std::abs(meanOf(pieces[i]) - meanOf(pieces[i + 1U])) < mergeCents && dipBetween(pieces[i], pieces[i + 1U]) < 6.0) {
                pieces[i].b = pieces[i + 1U].b;
                pieces.erase(pieces.begin() + static_cast<std::ptrdiff_t>(i) + 1);
                merged = true;
                break;
            }
        }
    }

    // Cut at deep dips in loudness (the same note sung again).
    const double dipLimit = 9.0 + 6.0 * (1.0 - std::clamp(splitSens, 0.0, 1.0)) - 3.0;
    std::vector<Range> cut;
    for (const Range& r : pieces) {
        std::size_t start = r.a;
        for (std::size_t i = r.a + minLen; i + minLen <= r.b; ++i) {
            if (!(dbLevel[i] <= dbLevel[i - 1U] && dbLevel[i] < dbLevel[i + 1U < r.b ? i + 1U : i])) continue;
            const std::size_t lo = i > 15U + r.a ? i - 15U : r.a;
            const std::size_t hi = std::min(r.b, i + 16U);
            double l = -1.0e9, rr = -1.0e9;
            for (std::size_t k = lo; k < i; ++k) l = std::max(l, dbLevel[k]);
            for (std::size_t k = i + 1U; k < hi; ++k) rr = std::max(rr, dbLevel[k]);
            if (std::min(l, rr) - dbLevel[i] >= dipLimit && i >= start + minLen) {
                cut.push_back({start, i});
                start = i;
            }
        }
        cut.push_back({start, r.b});
    }
    for (Range& r : cut) { r.a += base; r.b += base; out.push_back(r); }
    return out;
}

} // namespace

ToneAnalysis ToneAnalyzer::analyze(const AudioBuffer& audio, double rate, const ToneAnalysisOptions& options,
                                   const std::atomic<bool>* cancel, std::atomic<float>* progress) {
    ToneAnalysis result;
    result.sampleRate = rate;
    result.options = options;
    const std::size_t length = audio.frames();
    result.length = static_cast<std::int64_t>(length);
    if (audio.channels() == 0U || rate < 8000.0 || static_cast<double>(length) < rate * 0.12) return result;
    const auto cancelled = [&]() { return cancel != nullptr && cancel->load(std::memory_order_relaxed); };
    const auto report = [&](double v) { if (progress != nullptr) progress->store(static_cast<float>(std::clamp(v, 0.0, 1.0)), std::memory_order_relaxed); };

    // ---- mono, decimated copy for the pitch search ----
    std::vector<float> mono(length, 0.0F);
    {
        const float inv = 1.0F / static_cast<float>(audio.channels());
        for (std::size_t c = 0U; c < audio.channels(); ++c) {
            const float* p = audio.channelData(c);
            for (std::size_t i = 0U; i < length; ++i) mono[i] += p[i] * inv;
        }
    }
    const std::size_t D = std::max<std::size_t>(1U, static_cast<std::size_t>(std::llround(rate / 16000.0)));
    const double anaRate = rate / static_cast<double>(D);
    const std::size_t hopAna = std::max<std::size_t>(16U, static_cast<std::size_t>(std::llround(0.005 * anaRate)));
    const std::size_t hop = hopAna * D;
    const std::size_t frameCount = length / hop + 1U;

    std::vector<float> ana((length + D - 1U) / D, 0.0F);
    if (D == 1U) {
        ana = mono;
    } else {
        const long K = static_cast<long>(6U * D);
        std::vector<double> h(static_cast<std::size_t>(2L * K + 1L));
        const double fc = 0.45 / static_cast<double>(D);
        double sum = 0.0;
        for (long k = -K; k <= K; ++k) {
            const double t = static_cast<double>(k);
            const double sinc = k == 0 ? 2.0 * fc : std::sin(2.0 * kPi * fc * t) / (kPi * t);
            const double win = 0.42 + 0.5 * std::cos(kPi * t / static_cast<double>(K + 1)) + 0.08 * std::cos(2.0 * kPi * t / static_cast<double>(K + 1));
            h[static_cast<std::size_t>(k + K)] = sinc * win;
            sum += sinc * win;
        }
        for (double& v : h) v /= sum;
        for (std::size_t j = 0U; j < ana.size(); ++j) {
            const long centre = static_cast<long>(j * D);
            double acc = 0.0;
            for (long k = -K; k <= K; ++k) {
                const long idx = centre + k;
                if (idx < 0 || idx >= static_cast<long>(length)) continue;
                acc += h[static_cast<std::size_t>(k + K)] * static_cast<double>(mono[static_cast<std::size_t>(idx)]);
            }
            ana[j] = static_cast<float>(acc);
        }
    }
    {
        Biquad hp = Biquad::highpass(std::max(30.0, options.lowestHz * 0.7), anaRate);
        for (float& v : ana) v = static_cast<float>(hp.process(static_cast<double>(v)));
    }
    if (cancelled()) { result.cancelled = true; return result; }
    report(0.05);

    // ---- loudness of every frame ----
    ToneFrames& frames = result.frames;
    frames.hop = hop;
    frames.hz.assign(frameCount, 0.0F);
    frames.midi.assign(frameCount, 0.0F);
    frames.rawHz.assign(frameCount, 0.0F);
    frames.level.assign(frameCount, 0.0F);
    {
        std::vector<double> blockEnergy(frameCount, 0.0);
        for (std::size_t i = 0U; i < frameCount; ++i) {
            const long a = static_cast<long>(i * hop) - static_cast<long>(hop / 2U);
            const long b = a + static_cast<long>(hop);
            double e = 0.0;
            for (long j = std::max(0L, a); j < std::min(static_cast<long>(length), b); ++j) e += static_cast<double>(mono[static_cast<std::size_t>(j)]) * static_cast<double>(mono[static_cast<std::size_t>(j)]);
            blockEnergy[i] = e;
        }
        for (std::size_t i = 0U; i < frameCount; ++i) {
            const double l = i > 0U ? blockEnergy[i - 1U] : blockEnergy[i];
            const double r = i + 1U < frameCount ? blockEnergy[i + 1U] : blockEnergy[i];
            const double e = (l + 2.0 * blockEnergy[i] + r) / (4.0 * static_cast<double>(hop));
            frames.level[i] = static_cast<float>(std::sqrt(e));
        }
    }
    float maxLevel = 0.0F;
    for (const float v : frames.level) maxLevel = std::max(maxLevel, v);
    if (maxLevel < 1.0e-5F) return result;   // silence
    const double gateLevel = std::max(static_cast<double>(maxLevel) * std::pow(10.0, -58.0 / 20.0), 3.0e-5);

    // ---- YIN: candidates for every frame ----
    const std::size_t tauMin = std::max<std::size_t>(2U, static_cast<std::size_t>(std::floor(anaRate / std::max(options.highestHz, 100.0))));
    const std::size_t tauMax = static_cast<std::size_t>(std::ceil(anaRate / std::max(options.lowestHz, 30.0))) + 2U;
    const std::size_t W = std::max<std::size_t>(512U, tauMax + 32U);
    const std::size_t blockLen = W + tauMax + 2U;
    const std::size_t N = nextPow2(blockLen);
    const Fft fft(N);
    const long bias = static_cast<long>(std::llround(anaRate / 320.0));
    std::vector<FrameCandidates> cand(frameCount);
    {
        std::vector<std::complex<double>> z(N), spec(N);
        std::vector<double> prefix(blockLen + 1U), d(tauMax + 2U), dn(tauMax + 2U);
        for (std::size_t i = 0U; i < frameCount; ++i) {
            if ((i & 255U) == 0U) {
                if (cancelled()) { result.cancelled = true; return result; }
                report(0.05 + 0.45 * static_cast<double>(i) / static_cast<double>(frameCount));
            }
            if (static_cast<double>(frames.level[i]) < gateLevel) continue;
            const long t0 = static_cast<long>(i * hopAna) - static_cast<long>(W / 2U) - bias;
            for (std::size_t n = 0U; n < N; ++n) {
                double a = 0.0, b = 0.0;
                const long idx = t0 + static_cast<long>(n);
                const double v = (idx >= 0 && idx < static_cast<long>(ana.size())) ? static_cast<double>(ana[static_cast<std::size_t>(idx)]) : 0.0;
                if (n < W) a = v;
                if (n < blockLen) b = v;
                z[n] = {a, b};
                if (n < blockLen) prefix[n + 1U] = prefix[n] + v * v;
            }
            const double e0 = prefix[W];
            if (e0 < 1.0e-9) continue;
            fft.transform(z.data(), false);
            for (std::size_t k = 0U; k < N; ++k) {
                const std::complex<double> zk = z[k];
                const std::complex<double> znk = std::conj(z[(N - k) % N]);
                const std::complex<double> A = 0.5 * (zk + znk);
                const std::complex<double> B = std::complex<double>(0.0, -0.5) * (zk - znk);
                spec[k] = std::conj(A) * B;
            }
            fft.transform(spec.data(), true);
            double running = 0.0;
            dn[0] = 1.0;
            for (std::size_t tau = 1U; tau <= tauMax; ++tau) {
                const double et = prefix[tau + W] - prefix[tau];
                d[tau] = std::max(0.0, e0 + et - 2.0 * spec[tau].real());
                running += d[tau];
                dn[tau] = running > 1.0e-12 ? d[tau] * static_cast<double>(tau) / running : 1.0;
            }
            // local minima
            struct Min { std::size_t tau; double value; };
            std::vector<Min> minima;
            for (std::size_t tau = std::max<std::size_t>(tauMin, 2U); tau + 1U <= tauMax; ++tau) {
                if (dn[tau] < dn[tau - 1U] && dn[tau] <= dn[tau + 1U] && dn[tau] < 0.75) minima.push_back({tau, dn[tau]});
            }
            if (minima.empty()) continue;
            std::sort(minima.begin(), minima.end(), [](const Min& a, const Min& b) { return a.value < b.value; });
            {
                // Keep the deepest minimum and the shortest periods that are nearly as good: for a clean
                // periodic sound every multiple of the period is a deep minimum, and the shortest one is the pitch.
                const double limit = minima.front().value + 0.15;
                std::vector<Min> kept {minima.front()};
                std::vector<Min> others(minima.begin() + 1, minima.end());
                std::sort(others.begin(), others.end(), [](const Min& a, const Min& b) { return a.tau < b.tau; });
                for (const Min& m : others) {
                    if (kept.size() >= 4U) break;
                    if (m.value <= limit) kept.push_back(m);
                }
                minima = kept;
            }
            double refLag = -1.0;
            {
                double smallest = 1.0e9;
                for (const Min& m : minima) if (m.value < 0.35) smallest = std::min(smallest, static_cast<double>(m.tau));
                if (smallest < 1.0e8) refLag = smallest;
            }
            FrameCandidates& fc = cand[i];
            for (const Min& m : minima) {
                if (fc.count >= 4U) break;
                double lag = static_cast<double>(m.tau);
                const double y0 = dn[m.tau - 1U], y1 = dn[m.tau], y2 = dn[m.tau + 1U];
                const double denom = y0 - 2.0 * y1 + y2;
                if (denom > 1.0e-12) lag += std::clamp(0.5 * (y0 - y2) / denom, -1.0, 1.0);
                const double ref = refLag > 0.0 ? std::min(refLag, static_cast<double>(m.tau)) : static_cast<double>(m.tau);
                Candidate c;
                c.lag = static_cast<float>(lag);
                c.dip = static_cast<float>(m.value);
                c.cost = static_cast<float>(m.value / 0.16 + 0.35 * std::log2(static_cast<double>(m.tau) / ref));
                if (static_cast<double>(frames.level[i]) < gateLevel * 3.0) c.cost += 4.0F;
                fc.c[fc.count++] = c;
            }
            {
                // best guess even if the sound is not voiced: the cheapest candidate that is a real minimum
                std::size_t bestIndex = 0U;
                for (std::size_t k = 1U; k < fc.count; ++k) if (fc.c[k].cost < fc.c[bestIndex].cost) bestIndex = k;
                if (fc.count > 0U && fc.c[bestIndex].dip < 0.6F) fc.rawLag = fc.c[bestIndex].lag;
            }
        }
    }
    report(0.5);

    // ---- Viterbi: pitch path and voiced / not voiced ----
    std::vector<int> chosen(frameCount, -1);   // candidate index or -1 = no pitch
    {
        const double unvoicedCost = 0.9 + 1.4 * std::clamp(options.sensitivity, 0.0, 1.0);
        constexpr double switchCost = 1.0;
        std::vector<std::array<std::int8_t, 5>> back(frameCount);
        std::array<double, 5> prev {}, cur {};
        const auto stateCost = [&](std::size_t i, std::size_t s) {
            const FrameCandidates& fc = cand[i];
            if (s < fc.count) return static_cast<double>(fc.c[s].cost);
            return static_cast<double>(frames.level[i]) < gateLevel ? 0.0 : unvoicedCost;
        };
        const std::size_t first = 0U;
        const std::size_t firstStates = static_cast<std::size_t>(cand[first].count) + 1U;
        for (std::size_t s = 0U; s < firstStates; ++s) { prev[s] = stateCost(first, s); back[first][s] = -1; }
        for (std::size_t i = 1U; i < frameCount; ++i) {
            const std::size_t ns = static_cast<std::size_t>(cand[i].count) + 1U;
            const std::size_t ps = static_cast<std::size_t>(cand[i - 1U].count) + 1U;
            for (std::size_t s = 0U; s < ns; ++s) {
                double bestCost = std::numeric_limits<double>::max();
                std::int8_t bestFrom = 0;
                for (std::size_t p = 0U; p < ps; ++p) {
                    double t;
                    const bool sv = s < cand[i].count, pv = p < cand[i - 1U].count;
                    if (sv && pv) {
                        const double st = 12.0 * std::abs(std::log2(static_cast<double>(cand[i].c[s].lag) / static_cast<double>(cand[i - 1U].c[p].lag)));
                        t = 0.6 * std::min(st, 24.0);
                    } else if (sv != pv) {
                        t = switchCost;
                    } else {
                        t = 0.0;
                    }
                    const double c = prev[p] + t;
                    if (c < bestCost) { bestCost = c; bestFrom = static_cast<std::int8_t>(p); }
                }
                cur[s] = bestCost + stateCost(i, s);
                back[i][s] = bestFrom;
            }
            for (std::size_t s = 0U; s < ns; ++s) prev[s] = cur[s];
        }
        std::size_t state = 0U;
        const std::size_t lastStates = static_cast<std::size_t>(cand[frameCount - 1U].count) + 1U;
        for (std::size_t s = 1U; s < lastStates; ++s) if (prev[s] < prev[state]) state = s;
        for (std::size_t i = frameCount; i-- > 0U;) {
            chosen[i] = state < cand[i].count ? static_cast<int>(state) : -1;
            if (i > 0U) state = static_cast<std::size_t>(back[i][state]);
        }
    }
    report(0.55);

    // ---- period from the chosen candidates, refined on the full-rate signal ----
    const long spread = static_cast<long>(D) + 2L;
    for (std::size_t i = 0U; i < frameCount; ++i) {
        if ((i & 255U) == 0U) {
            if (cancelled()) { result.cancelled = true; return result; }
            report(0.55 + 0.3 * static_cast<double>(i) / static_cast<double>(frameCount));
        }
        if (chosen[i] >= 0) {
            double period = static_cast<double>(cand[i].c[static_cast<std::size_t>(chosen[i])].lag) * static_cast<double>(D);
            period = refinePeriod(mono, static_cast<long>(i * hop), period, spread, rate);
            frames.hz[i] = static_cast<float>(rate / period);
        }
        if (cand[i].rawLag > 0.0F) frames.rawHz[i] = static_cast<float>(anaRate / static_cast<double>(cand[i].rawLag));
    }

    // ---- clean up: drop spikes, short runs, fill small gaps ----
    {
        // fill short gaps between frames of nearly the same pitch
        std::size_t i = 0U;
        while (i < frameCount) {
            if (frames.hz[i] > 0.0F) { ++i; continue; }
            std::size_t j = i;
            while (j < frameCount && frames.hz[j] <= 0.0F) ++j;
            if (i > 0U && j < frameCount && j - i <= 3U) {
                const double a = midiFromHz(frames.hz[i - 1U]), b = midiFromHz(frames.hz[j]);
                if (std::abs(a - b) < 1.5) {
                    for (std::size_t k = i; k < j; ++k) {
                        const double t = static_cast<double>(k - i + 1U) / static_cast<double>(j - i + 1U);
                        frames.hz[k] = static_cast<float>(hzFromMidi(a + (b - a) * t));
                    }
                }
            }
            i = j;
        }
        // remove very short runs
        i = 0U;
        while (i < frameCount) {
            if (frames.hz[i] <= 0.0F) { ++i; continue; }
            std::size_t j = i;
            while (j < frameCount && frames.hz[j] > 0.0F) ++j;
            if (j - i < 4U) for (std::size_t k = i; k < j; ++k) frames.hz[k] = 0.0F;
            i = j;
        }
        // median of three on the pitch curve (removes single-frame spikes)
        std::vector<float> m(frameCount, 0.0F);
        for (std::size_t k = 0U; k < frameCount; ++k) if (frames.hz[k] > 0.0F) m[k] = static_cast<float>(midiFromHz(frames.hz[k]));
        std::vector<float> filtered = m;
        for (std::size_t k = 1U; k + 1U < frameCount; ++k) {
            if (m[k - 1U] > 0.0F && m[k] > 0.0F && m[k + 1U] > 0.0F)
                filtered[k] = static_cast<float>(median3(m[k - 1U], m[k], m[k + 1U]));
        }
        for (std::size_t k = 0U; k < frameCount; ++k) {
            if (frames.hz[k] > 0.0F) {
                frames.midi[k] = filtered[k];
                if (std::abs(filtered[k] - m[k]) > 1.0e-6F) frames.hz[k] = static_cast<float>(hzFromMidi(static_cast<double>(filtered[k])));
            }
        }
    }
    report(0.88);

    // ---- tone blocks ----
    {
        const double frameMs = 1000.0 * static_cast<double>(hop) / rate;
        const std::size_t minLen = std::max<std::size_t>(3U, static_cast<std::size_t>(std::llround(options.minBlockMs / frameMs)));
        std::vector<double> dbAll(frameCount);
        for (std::size_t k = 0U; k < frameCount; ++k) dbAll[k] = 20.0 * std::log10(std::max(1.0e-6, static_cast<double>(frames.level[k])));
        ToneEdit& edit = result.initial;
        std::size_t i = 0U;
        while (i < frameCount) {
            if (frames.hz[i] <= 0.0F) { ++i; continue; }
            std::size_t j = i;
            while (j < frameCount && frames.hz[j] > 0.0F) ++j;
            const std::size_t n = j - i;
            std::vector<double> y(n), w(n), db(n);
            double meanLevel = 0.0;
            for (std::size_t k = 0U; k < n; ++k) meanLevel += static_cast<double>(frames.level[i + k]);
            meanLevel = std::max(1.0e-6, meanLevel / static_cast<double>(n));
            for (std::size_t k = 0U; k < n; ++k) {
                y[k] = static_cast<double>(frames.midi[i + k]);
                w[k] = std::clamp(static_cast<double>(frames.level[i + k]) / meanLevel, 0.25, 2.0);
                db[k] = dbAll[i + k];
            }
            // smooth the loudness a little before looking for dips
            std::vector<double> dbs = db;
            for (std::size_t k = 1U; k + 1U < n; ++k) dbs[k] = (db[k - 1U] + db[k] + db[k + 1U]) / 3.0;
            for (const Range& r : partitionRun(y, w, dbs, std::min(minLen, n), options.splitSensitivity, i)) {
                ToneBlock block;
                block.id = edit.nextId++;
                block.start = std::max<std::int64_t>(0, static_cast<std::int64_t>(r.a * hop) - static_cast<std::int64_t>(hop / 2U));
                block.end = std::min<std::int64_t>(result.length, static_cast<std::int64_t>(r.b * hop) - static_cast<std::int64_t>(hop / 2U));
                if (block.end <= block.start) continue;
                double midi = 0.0, level = 0.0;
                if (!heardPitch(frames, r.a, r.b, false, midi, level)) continue;
                block.pitch = static_cast<float>(midi);
                block.levelDb = static_cast<float>(level);
                edit.blocks.push_back(block);
            }
            i = j;
        }
        // blocks that touch each other share one border; make sure they never overlap
        for (std::size_t b = 1U; b < edit.blocks.size(); ++b)
            if (edit.blocks[b].start < edit.blocks[b - 1U].end) edit.blocks[b].start = edit.blocks[b - 1U].end;
    }
    report(1.0);
    return result;
}

} // namespace silveton
