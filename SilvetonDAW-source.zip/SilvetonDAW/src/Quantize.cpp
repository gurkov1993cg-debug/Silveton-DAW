#include "silveton/Quantize.h"

#include "silveton/ClipEditor.h"
#include "silveton/ProjectMediaRelinker.h"

#include <algorithm>
#include <cmath>
#include <random>
#include <stdexcept>

namespace silveton {
namespace {
std::vector<MusicalMidiNote> pick(const MidiSequence& seq, const Quantizer::Selection& s) {
    std::vector<MusicalMidiNote> out;
    for (const auto& n : seq.notes()) {
        if (s.empty() || std::find(s.begin(), s.end(), n.id) != s.end()) out.push_back(n);
    }
    return out;
}
} // namespace

double Quantizer::effectiveGrid(const QuantizeSettings& s) {
    double g = s.gridQuarterNotes;
    if (!(g > 0.0)) throw std::invalid_argument("quantize grid must be positive");
    if (s.type == QuantizeGridType::Triplet) g *= 2.0 / 3.0;
    else if (s.type == QuantizeGridType::Dotted) g *= 1.5;
    return g;
}

double Quantizer::nearestGridPoint(double q, const QuantizeSettings& s) {
    const double grid = effectiveGrid(s);
    const double swing = std::clamp(s.swing, 0.0, 1.0);
    const double pair = grid * 2.0;
    const double base = std::floor(q / pair) * pair;
    const double on = base, off = base + grid + swing * grid / 3.0, next = base + pair;
    double best = on;
    if (std::abs(q - off) < std::abs(q - best)) best = off;
    if (std::abs(q - next) < std::abs(q - best)) best = next;
    return best;
}

std::size_t Quantizer::apply(MidiSequence& seq, const QuantizeSettings& s, const Selection& selection) {
    const double grid = effectiveGrid(s);
    const double strength = std::clamp(s.strength, 0.0, 1.0);
    const double magnet = std::clamp(s.magneticArea, 0.0, 1.0) * grid * 0.5;
    std::mt19937 rng(s.seed);
    std::uniform_real_distribution<double> rnd(-1.0, 1.0);
    auto move = [&](double q) {
        const double t = nearestGridPoint(q, s);
        const double d = std::abs(t - q);
        if (d > magnet + 1.0e-12 && s.magneticArea < 1.0) return q;
        if (d < s.nonQuantizeQuarterNotes) return q;
        double r = q + (t - q) * strength;
        if (s.randomQuarterNotes > 0.0) r += rnd(rng) * s.randomQuarterNotes;
        return r;
    };
    std::size_t changed = 0U;
    for (const auto& n : pick(seq, selection)) {
        double start = n.startQuarterNotes;
        double end = n.startQuarterNotes + n.durationQuarterNotes;
        if (s.quantizeStart) start = move(start);
        if (s.quantizeEnd) end = move(end);
        start = std::max(0.0, start);
        double dur = end - start;
        if (s.quantizeLength) {
            dur = std::max(grid, std::round(n.durationQuarterNotes / grid) * grid);
        } else if (!s.quantizeEnd) {
            dur = n.durationQuarterNotes;
        }
        if (dur <= 1.0e-6) dur = grid;
        bool any = false;
        if (std::abs(start - n.startQuarterNotes) > 1.0e-12) any |= seq.moveNote(n.id, start);
        if (std::abs(dur - n.durationQuarterNotes) > 1.0e-12) any |= seq.resizeNote(n.id, dur);
        if (any) ++changed;
    }
    return changed;
}

GrooveTemplate Quantizer::extractGroove(const MidiSequence& seq, double grid, double pattern, const Selection& selection) {
    if (!(grid > 0.0) || !(pattern >= grid)) throw std::invalid_argument("groove grid/pattern invalid");
    GrooveTemplate g;
    g.name = "Extracted";
    g.gridQuarterNotes = grid;
    g.patternQuarterNotes = pattern;
    const auto slots = static_cast<std::size_t>(std::llround(pattern / grid));
    g.offsetQuarterNotes.assign(slots, 0.0);
    g.velocityScale.assign(slots, 1.0);
    std::vector<double> offSum(slots, 0.0), velSum(slots, 0.0);
    std::vector<std::size_t> count(slots, 0U);
    double velTotal = 0.0;
    std::size_t total = 0U;
    for (const auto& n : pick(seq, selection)) {
        const double slotF = std::round(n.startQuarterNotes / grid);
        const double slotPos = slotF * grid;
        const std::size_t slot = static_cast<std::size_t>(std::llround(slotF)) % slots;
        offSum[slot] += n.startQuarterNotes - slotPos;
        velSum[slot] += n.velocity;
        ++count[slot];
        velTotal += n.velocity;
        ++total;
    }
    const double mean = total ? velTotal / static_cast<double>(total) : 100.0;
    for (std::size_t i = 0U; i < slots; ++i) {
        if (!count[i]) continue;
        g.offsetQuarterNotes[i] = offSum[i] / static_cast<double>(count[i]);
        g.velocityScale[i] = mean > 0.0 ? (velSum[i] / static_cast<double>(count[i])) / mean : 1.0;
    }
    return g;
}

GrooveTemplate Quantizer::swingGroove(double grid, double percent) {
    GrooveTemplate g;
    g.name = "Swing " + std::to_string(static_cast<int>(std::lround(percent))) + "%";
    g.gridQuarterNotes = grid;
    g.patternQuarterNotes = grid * 2.0;
    percent = std::clamp(percent, 50.0, 75.0);
    g.offsetQuarterNotes = {0.0, grid * 2.0 * percent / 100.0 - grid};
    g.velocityScale = {1.0, 1.0};
    return g;
}

std::vector<GrooveTemplate> Quantizer::builtInGrooves() {
    std::vector<GrooveTemplate> out;
    for (double p : {54.0, 58.0, 62.0, 66.0, 71.0}) {
        auto g = swingGroove(0.25, p);
        g.name = "Swing 16th " + std::to_string(static_cast<int>(p)) + "%";
        out.push_back(g);
    }
    for (double p : {54.0, 58.0, 62.0, 66.0}) {
        auto g = swingGroove(0.5, p);
        g.name = "Swing 8th " + std::to_string(static_cast<int>(p)) + "%";
        out.push_back(g);
    }
    auto shuffle = swingGroove(0.5, 66.7);
    shuffle.name = "Shuffle (triplet)";
    out.push_back(shuffle);
    return out;
}

std::size_t Quantizer::applyGroove(MidiSequence& seq, const GrooveTemplate& g, double timing, double velocity, const Selection& selection) {
    if (g.offsetQuarterNotes.empty() || !(g.gridQuarterNotes > 0.0)) throw std::invalid_argument("empty groove");
    timing = std::clamp(timing, 0.0, 1.0);
    velocity = std::clamp(velocity, 0.0, 1.0);
    const auto slots = static_cast<long long>(g.offsetQuarterNotes.size());
    std::size_t changed = 0U;
    for (const auto& n : pick(seq, selection)) {
        const long long slot = std::llround(n.startQuarterNotes / g.gridQuarterNotes);
        const auto idx = static_cast<std::size_t>(((slot % slots) + slots) % slots);
        const double target = std::max(0.0, static_cast<double>(slot) * g.gridQuarterNotes + g.offsetQuarterNotes[idx]);
        const double start = n.startQuarterNotes + (target - n.startQuarterNotes) * timing;
        bool any = false;
        if (std::abs(start - n.startQuarterNotes) > 1.0e-12) any |= seq.moveNote(n.id, start);
        if (velocity > 0.0 && idx < g.velocityScale.size()) {
            const double scaled = n.velocity * (1.0 + (g.velocityScale[idx] - 1.0) * velocity);
            const auto v = static_cast<std::uint8_t>(std::clamp(std::lround(scaled), 1L, 127L));
            if (v != n.velocity) any |= seq.setNoteVelocity(n.id, v);
        }
        if (any) ++changed;
    }
    return changed;
}

// --------------------------------------------------------------- audio ----
std::vector<std::uint64_t> AudioQuantizer::detectTransients(const AudioBuffer& audio, double sampleRate, double sensitivity) {
    std::vector<std::uint64_t> out;
    if (audio.channels() == 0U || audio.frames() < 64U || !(sampleRate > 0.0)) return out;
    const std::size_t hop = std::max<std::size_t>(16U, static_cast<std::size_t>(sampleRate * 0.002));
    const std::size_t bins = audio.frames() / hop;
    if (bins < 12U) return out;
    std::vector<double> env(bins, 0.0);
    for (std::size_t b = 0U; b < bins; ++b) {
        double peak = 0.0;
        for (std::size_t c = 0U; c < audio.channels(); ++c) {
            const float* x = audio.channelData(c) + b * hop;
            for (std::size_t i = 0U; i < hop; ++i) peak = std::max(peak, static_cast<double>(std::abs(x[i])));
        }
        env[b] = peak;
    }
    sensitivity = std::clamp(sensitivity, 0.0, 1.0);
    const double thresholdDb = 14.0 - 10.0 * sensitivity;           // 14 dB (strict) .. 4 dB (loose)
    const std::size_t minGap = std::max<std::size_t>(1U, static_cast<std::size_t>(0.060 / 0.002));
    const double floorLevel = 1.0e-4;
    std::size_t last = 0U;
    bool haveLast = false;
    for (std::size_t b = 0U; b < bins; ++b) {
        double mean = 0.0;
        for (std::size_t k = 1U; k <= 8U; ++k) mean += (b >= k) ? env[b - k] : 0.0;   // before the start counts as silence
        mean = std::max(mean / 8.0, floorLevel);
        const double now = std::max(env[b], floorLevel);
        const double rise = 20.0 * std::log10(now / mean);
        if (rise < thresholdDb || env[b] < 0.01) continue;
        if (haveLast && b - last < minGap) continue;
        // walk back to where the rise started
        std::size_t start = b;
        while (start > 0U && env[start - 1U] < env[start] && env[start - 1U] > floorLevel * 4.0 && b - start < 6U) --start;
        out.push_back(static_cast<std::uint64_t>(start) * hop);
        last = b;
        haveLast = true;
    }
    return out;
}

std::size_t AudioQuantizer::quantizeClip(Project& project, std::size_t trackIndex, std::uint64_t clipId,
                                         const QuantizeSettings& settings, const AudioQuantizeOptions& options) {
    if (trackIndex >= project.tracks.size()) throw std::out_of_range("audio quantize track");
    auto& clips = project.tracks[trackIndex].clips;
    auto it = std::find_if(clips.begin(), clips.end(), [&](const ProjectAudioClip& c) { return c.id == clipId; });
    if (it == clips.end()) throw std::invalid_argument("audio quantize: clip not found");
    const ProjectAudioClip clip = *it;
    std::uint32_t fileRate = 0U;
    const AudioBuffer whole = ProjectMediaRelinker::readWholeSource(clip.audioPath, fileRate);
    if (whole.frames() == 0U || fileRate == 0U) throw std::runtime_error("audio quantize: cannot read the audio file");
    // Project media is conformed to the project rate on import, so one source
    // frame is one timeline sample; the analysis uses the file's own rate.
    const auto s0 = static_cast<std::size_t>(clip.sourceStartSample);
    const auto s1 = std::min<std::size_t>(whole.frames(), static_cast<std::size_t>(clip.sourceStartSample + clip.lengthSamples));
    if (s1 <= s0 + 64U) return 0U;
    AudioBuffer part(whole.channels(), s1 - s0);
    for (std::size_t c = 0U; c < whole.channels(); ++c) std::copy(whole.channelData(c) + s0, whole.channelData(c) + s1, part.channelData(c));
    const auto onsets = detectTransients(part, static_cast<double>(fileRate), options.sensitivity);

    // Timeline positions of the slice starts (project frames).
    std::vector<std::int64_t> cut;
    for (const auto o : onsets) {
        const auto rel = static_cast<std::int64_t>(o);
        if (rel > 64 && rel < static_cast<std::int64_t>(clip.lengthSamples) - 64) cut.push_back(clip.timelineStartSample + rel);
    }
    if (cut.empty()) return 0U;

    ClipEditor editor(project, trackIndex);
    std::vector<std::uint64_t> ids {clipId};
    for (const auto t : cut) ids.push_back(editor.splitClip(ids.back(), t));
    const std::size_t n = ids.size();

    // New slice starts.
    const auto& tempo = project.tempoMap;
    std::vector<std::int64_t> oldStart(n), newStart(n);
    oldStart[0] = clip.timelineStartSample;
    for (std::size_t i = 1U; i < n; ++i) oldStart[i] = cut[i - 1U];
    newStart[0] = oldStart[0];
    const double strength = std::clamp(options.strength, 0.0, 1.0);
    for (std::size_t i = 1U; i < n; ++i) {
        const double q = tempo.quarterNotesAtSample(oldStart[i]);
        const double tq = Quantizer::nearestGridPoint(q, settings);
        const auto target = tempo.sampleAtQuarterNotes(tq);
        newStart[i] = std::max<std::int64_t>(newStart[i - 1U] + 32, oldStart[i] + static_cast<std::int64_t>(std::llround(static_cast<double>(target - oldStart[i]) * strength)));
    }
    const std::int64_t clipEnd = clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples);
    const auto fade = static_cast<std::uint64_t>(std::max(0.0, options.fadeMilliseconds) * 0.001 * project.sampleRate);
    for (std::size_t i = 0U; i < n; ++i) {
        auto cit = std::find_if(clips.begin(), clips.end(), [&](const ProjectAudioClip& c) { return c.id == ids[i]; });
        ProjectAudioClip& c = *cit;
        const std::int64_t origLen = static_cast<std::int64_t>(c.lengthSamples);
        c.timelineStartSample = newStart[i];
        // End at the next slice's start (extends into the source or trims the tail).
        std::int64_t end = (i + 1U < n) ? newStart[i + 1U] : newStart[i] + origLen;
        std::int64_t len = end - newStart[i];
        const auto room = static_cast<std::int64_t>(c.sourceFrames - c.sourceStartSample);
        len = std::clamp<std::int64_t>(len, 1, room);
        c.lengthSamples = static_cast<std::uint64_t>(len);
        c.fadeInSamples = i == 0U ? clip.fadeInSamples : std::min<std::uint64_t>(fade, c.lengthSamples / 2U);
        c.fadeOutSamples = i + 1U == n ? clip.fadeOutSamples : std::min<std::uint64_t>(fade, c.lengthSamples / 2U);
        c.fadeInAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
        c.fadeOutAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
    }
    (void)clipEnd;
    return n;
}

} // namespace silveton
