#include "silveton/Transport.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace silveton {

void Transport::setSampleRate(double sampleRate) {
    if (!std::isfinite(sampleRate) || sampleRate <= 0.0) throw std::invalid_argument("sample rate must be positive");
    sampleRate_.store(sampleRate, std::memory_order_release);
}

void Transport::seekSamples(std::int64_t samplePosition) noexcept {
    positionSamples_.store(std::max<std::int64_t>(0, samplePosition), std::memory_order_release);
    cyclePass_.store(0U, std::memory_order_release);
}

void Transport::seekSeconds(double seconds) noexcept {
    const double sr = sampleRate_.load(std::memory_order_acquire);
    const double clamped = std::max(0.0, std::isfinite(seconds) ? seconds : 0.0);
    seekSamples(static_cast<std::int64_t>(std::llround(clamped * sr)));
}

double Transport::positionSeconds() const noexcept {
    const double sr = sampleRate_.load(std::memory_order_acquire);
    return sr > 0.0 ? static_cast<double>(positionSamples()) / sr : 0.0;
}

void Transport::setCycleRange(bool enabled, std::int64_t startSample, std::int64_t endSample) {
    if (enabled && (startSample < 0 || endSample <= startSample))
        throw std::invalid_argument("invalid cycle range");
    if (enabled) {
        cycleStartSample_.store(startSample, std::memory_order_release);
        cycleEndSample_.store(endSample, std::memory_order_release);
    }
    cyclePass_.store(0U, std::memory_order_release);
    cycleEnabled_.store(enabled, std::memory_order_release);
}

void Transport::advance(std::uint32_t frames) noexcept {
    if (!isPlaying()) return;
    std::int64_t position = positionSamples_.load(std::memory_order_acquire);
    const bool cycle = cycleEnabled_.load(std::memory_order_acquire);
    if (!cycle) {
        positionSamples_.store(position + static_cast<std::int64_t>(frames), std::memory_order_release);
        return;
    }

    const std::int64_t start = cycleStartSample_.load(std::memory_order_acquire);
    const std::int64_t end = cycleEndSample_.load(std::memory_order_acquire);
    const std::int64_t length = end - start;
    if (length <= 0) return;
    if (position >= end) position = start + ((position - start) % length);

    std::uint64_t wraps = 0U;
    std::uint64_t remaining = frames;
    while (remaining != 0U) {
        const std::uint64_t untilEnd = position < end
            ? static_cast<std::uint64_t>(end - position)
            : 0U;
        if (untilEnd == 0U) {
            position = start;
            ++wraps;
            continue;
        }
        if (remaining < untilEnd) {
            position += static_cast<std::int64_t>(remaining);
            remaining = 0U;
        } else {
            remaining -= untilEnd;
            position = start;
            ++wraps;
        }
    }
    positionSamples_.store(position, std::memory_order_release);
    if (wraps != 0U) cyclePass_.fetch_add(wraps, std::memory_order_release);
}

} // namespace silveton
