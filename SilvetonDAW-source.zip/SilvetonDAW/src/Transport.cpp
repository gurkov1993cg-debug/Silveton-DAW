#include "silveton/Transport.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace silveton {

void Transport::setSampleRate(double sampleRate) {
    if (!std::isfinite(sampleRate) || sampleRate <= 0.0) throw std::invalid_argument("sample rate must be positive");
    sampleRate_.store(sampleRate, std::memory_order_release);
}

void Transport::seekSamples(std::int64_t samplePosition) noexcept {
    positionSamples_.store(std::max<std::int64_t>(0, samplePosition), std::memory_order_release);
}

void Transport::seekSeconds(double seconds) noexcept {
    const double sr = sampleRate_.load(std::memory_order_acquire);
    const double clamped = std::max(0.0, std::isfinite(seconds) ? seconds : 0.0);
    seekSamples(static_cast<std::int64_t>(std::llround(clamped * sr)));
}

double Transport::positionSeconds() const noexcept {
    const double sr = sampleRate_.load(std::memory_order_acquire);
    return sr > 0.0 ? static_cast<double>(positionSamples()) / sr : 0.0;
}

void Transport::advance(std::uint32_t frames) noexcept {
    if (!isPlaying()) return;
    positionSamples_.fetch_add(static_cast<std::int64_t>(frames), std::memory_order_release);
}

} // namespace silveton
