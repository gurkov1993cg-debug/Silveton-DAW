#include "silveton/MixerRouting.h"
#include "silveton/MixMath.h"
#include <cmath>
#include <stdexcept>
#include <utility>
#include <vector>

namespace silveton {
namespace {
constexpr std::size_t kMaxProjectBuses = 256U;

[[nodiscard]] float gainFromDb(float db) {
    if (!std::isfinite(db)) throw std::invalid_argument("non-finite mixer gain");
    return static_cast<float>(MixMath::dbToLinear(static_cast<double>(db)));
}

[[nodiscard]] std::size_t resolveOutputNode(int outputBus, const MixerGraphLayout& layout) {
    if (outputBus == -1) return layout.masterNode();
    if (outputBus < 0 || static_cast<std::size_t>(outputBus) >= layout.busCount)
        throw std::out_of_range("mixer output bus");
    return layout.busNode(static_cast<std::size_t>(outputBus));
}

[[nodiscard]] bool laneActive(AutomationMode mode, const AutomationLane& lane) noexcept {
    return mode != AutomationMode::Off && !lane.points().empty();
}

void addSendRoutes(std::vector<MainRouteDefinition>& routes,
                   std::size_t sourceNode,
                   const std::vector<ProjectSend>& sends,
                   const MixerGraphLayout& layout) {
    for (const auto& send : sends) {
        const bool gainAutomated = laneActive(send.gainAutomationMode, send.gainAutomationDb);
        const bool enabledAutomated = laneActive(send.enabledAutomationMode, send.enabledAutomation);
        if (!send.enabled && !enabledAutomated) continue;
        if (send.destinationBus < 0 || static_cast<std::size_t>(send.destinationBus) >= layout.busCount)
            throw std::out_of_range("mixer send destination bus");

        MainRouteDefinition route;
        route.from = sourceNode;
        route.to = layout.busNode(static_cast<std::size_t>(send.destinationBus));
        route.tap = send.preFader ? MainRouteTap::PreFader : MainRouteTap::PostFader;
        route.enabledFallback = send.enabled;
        if (gainAutomated) {
            route.gain = 1.0F;
            route.gainAutomationDb = std::make_shared<AutomationLane>(send.gainAutomationDb);
            route.gainAutomationFallbackDb = send.gainDb;
        } else {
            route.gain = gainFromDb(send.gainDb);
        }
        if (enabledAutomated) route.enabledAutomation = std::make_shared<AutomationLane>(send.enabledAutomation);
        routes.push_back(route);
    }
}
}

std::size_t MixerGraphLayout::trackNode(std::size_t track) const {
    if (track >= trackCount) throw std::out_of_range("mixer track node");
    return track;
}

std::size_t MixerGraphLayout::busNode(std::size_t bus) const {
    if (bus >= busCount) throw std::out_of_range("mixer bus node");
    return trackCount + bus;
}

MixerGraphLayout MixerRoutingBuilder::layout(const Project& project) noexcept {
    return {project.tracks.size(), project.buses.size()};
}

namespace {
std::unique_ptr<ProcessorGraph> buildMixerGraph(const Project& project,
                                                const Vst3RuntimeRack& rack,
                                                bool staged) {
    if (project.tracks.size() > Project::kMaxTracks)
        throw std::length_error("Silveton project track limit is 256");
    if (project.buses.size() > kMaxProjectBuses)
        throw std::length_error("Silveton project bus limit is 256");

    const MixerGraphLayout graphLayout = MixerRoutingBuilder::layout(project);
    std::vector<GraphNodeDefinition> nodes(graphLayout.nodeCount());
    for (std::size_t i = 0U; i < graphLayout.trackCount; ++i) {
        nodes[graphLayout.trackNode(i)] = rack.trackNodeDefinition(i, staged);
        const auto& track = project.tracks[i];
        auto& mix = nodes[graphLayout.trackNode(i)].mix;
        mix.enabled = true;
        mix.gainDb = track.gainDb;
        mix.mute = track.mute;
        if (laneActive(track.gainAutomationMode, track.gainAutomationDb))
            mix.gainAutomationDb = std::make_shared<AutomationLane>(track.gainAutomationDb);
        if (laneActive(track.muteAutomationMode, track.muteAutomation))
            mix.muteAutomation = std::make_shared<AutomationLane>(track.muteAutomation);
        // Track pan is intentionally evaluated by AudioEngine before the graph,
        // where the source's mono/stereo layout is known exactly.
    }
    for (std::size_t i = 0U; i < graphLayout.busCount; ++i) {
        nodes[graphLayout.busNode(i)] = rack.busNodeDefinition(i, staged);
        const auto& bus = project.buses[i];
        auto& mix = nodes[graphLayout.busNode(i)].mix;
        mix.enabled = true;
        mix.gainDb = bus.gainDb;
        mix.mute = bus.mute;
        if (laneActive(bus.gainAutomationMode, bus.gainAutomationDb))
            mix.gainAutomationDb = std::make_shared<AutomationLane>(bus.gainAutomationDb);
        if (laneActive(bus.muteAutomationMode, bus.muteAutomation))
            mix.muteAutomation = std::make_shared<AutomationLane>(bus.muteAutomation);
    }
    nodes[graphLayout.masterNode()] = rack.masterNodeDefinition(staged);
    {
        auto& mix = nodes[graphLayout.masterNode()].mix;
        mix.enabled = true;
        mix.gainDb = project.masterFaderDb;
        if (laneActive(project.masterFaderAutomationMode, project.masterFaderAutomationDb))
            mix.gainAutomationDb = std::make_shared<AutomationLane>(project.masterFaderAutomationDb);
    }

    std::vector<MainRouteDefinition> routes;
    std::size_t routeReserve = graphLayout.trackCount + graphLayout.busCount;
    for (const auto& track : project.tracks) routeReserve += track.sends.size();
    for (const auto& bus : project.buses) routeReserve += bus.sends.size();
    routes.reserve(routeReserve);

    // Track inserts run first. The graph's node mix control applies volume/mute
    // after inserts, giving sends a real choice between pre- and post-fader taps.
    for (std::size_t i = 0U; i < graphLayout.trackCount; ++i) {
        const auto& track = project.tracks[i];
        const std::size_t source = graphLayout.trackNode(i);
        MainRouteDefinition mainRoute;
        mainRoute.from = source;
        mainRoute.to = resolveOutputNode(track.outputBus, graphLayout);
        mainRoute.tap = MainRouteTap::PostFader;
        routes.push_back(mainRoute);
        addSendRoutes(routes, source, track.sends, graphLayout);
    }

    // Bus inserts also run before the bus fader. Main output is post-fader;
    // each send independently chooses its pre/post tap.
    for (std::size_t i = 0U; i < graphLayout.busCount; ++i) {
        const auto& bus = project.buses[i];
        const std::size_t source = graphLayout.busNode(i);
        MainRouteDefinition mainRoute;
        mainRoute.from = source;
        mainRoute.to = resolveOutputNode(bus.outputBus, graphLayout);
        mainRoute.tap = MainRouteTap::PostFader;
        routes.push_back(mainRoute);
        addSendRoutes(routes, source, bus.sends, graphLayout);
    }

    auto graph = std::make_unique<ProcessorGraph>();
    graph->configure(std::move(nodes), std::move(routes), graphLayout.masterNode());
    return graph;
}
} // namespace

std::unique_ptr<ProcessorGraph> MixerRoutingBuilder::build(const Project& project,
                                                           const Vst3RuntimeRack& rack) {
    return buildMixerGraph(project, rack, false);
}

std::unique_ptr<ProcessorGraph> MixerRoutingBuilder::buildStaged(const Project& project,
                                                                 const Vst3RuntimeRack& rack) {
    if (!rack.stagedProjectReady()) throw std::logic_error("VST3 staged mixer graph requested without staged project");
    return buildMixerGraph(project, rack, true);
}

} // namespace silveton
