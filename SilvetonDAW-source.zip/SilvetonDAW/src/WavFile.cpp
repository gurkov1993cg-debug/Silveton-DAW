#include "silveton/WavFile.h"
#include <array>
#include <cstring>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <string>

namespace silveton {
namespace {

template <typename T>
void writeLE(std::ofstream& out, T value) {
    out.write(reinterpret_cast<const char*>(&value), sizeof(T));
}

template <typename T>
T readLE(std::ifstream& in) {
    T value{};
    in.read(reinterpret_cast<char*>(&value), sizeof(T));
    if (!in) throw std::runtime_error("Unexpected EOF");
    return value;
}

std::string readTag(std::ifstream& in) {
    std::array<char, 4> tag{};
    in.read(tag.data(), 4);
    if (!in) throw std::runtime_error("Unexpected EOF");
    return std::string(tag.data(), tag.size());
}

void writeWaveHeader(std::ofstream& out,
                     std::uint16_t channels,
                     std::uint32_t sampleRate,
                     std::uint64_t frames,
                     std::uint64_t dataSize) {
    constexpr std::uint16_t bitsPerSample = 32U;
    const std::uint64_t blockAlign64 = static_cast<std::uint64_t>(channels) * sizeof(float);
    if (blockAlign64 > std::numeric_limits<std::uint16_t>::max())
        throw std::invalid_argument("invalid WAV block alignment");
    const auto blockAlign = static_cast<std::uint16_t>(blockAlign64);

    const std::uint64_t byteRate64 = static_cast<std::uint64_t>(sampleRate) * blockAlign;
    if (byteRate64 > std::numeric_limits<std::uint32_t>::max())
        throw std::invalid_argument("invalid WAV byte rate");
    const auto byteRate = static_cast<std::uint32_t>(byteRate64);

    // 80-byte layout reserves a 28-byte JUNK chunk so a normal RIFF file can
    // be converted to RF64 in-place without moving sample data.
    constexpr std::uint64_t headerBytes = 80U;
    const std::uint64_t riffSize64 = (headerBytes - 8U) + dataSize;
    const bool rf64 = riffSize64 > std::numeric_limits<std::uint32_t>::max() ||
                      dataSize > std::numeric_limits<std::uint32_t>::max();

    if (rf64) {
        out.write("RF64", 4);
        writeLE(out, std::uint32_t{0xFFFFFFFFU});
        out.write("WAVE", 4);
        out.write("ds64", 4);
        writeLE(out, std::uint32_t{28U});
        writeLE(out, riffSize64);
        writeLE(out, dataSize);
        writeLE(out, frames);
        writeLE(out, std::uint32_t{0U});
    } else {
        out.write("RIFF", 4);
        writeLE(out, static_cast<std::uint32_t>(riffSize64));
        out.write("WAVE", 4);
        out.write("JUNK", 4);
        writeLE(out, std::uint32_t{28U});
        writeLE(out, std::uint64_t{0U});
        writeLE(out, std::uint64_t{0U});
        writeLE(out, std::uint64_t{0U});
        writeLE(out, std::uint32_t{0U});
    }

    out.write("fmt ", 4);
    writeLE(out, std::uint32_t{16U});
    writeLE(out, std::uint16_t{3U});
    writeLE(out, channels);
    writeLE(out, sampleRate);
    writeLE(out, byteRate);
    writeLE(out, blockAlign);
    writeLE(out, bitsPerSample);
    out.write("data", 4);
    writeLE(out, rf64 ? std::uint32_t{0xFFFFFFFFU} : static_cast<std::uint32_t>(dataSize));
}

} // namespace

void WavFile::writeFloat32(const std::string& path, std::uint32_t sampleRate, const AudioBuffer& buffer) {
    if (buffer.channels() == 0U || buffer.channels() > std::numeric_limits<std::uint16_t>::max())
        throw std::invalid_argument("invalid channel count");
    if (sampleRate == 0U) throw std::invalid_argument("invalid sample rate");

    const auto channels = static_cast<std::uint16_t>(buffer.channels());
    const std::uint64_t blockAlign = static_cast<std::uint64_t>(channels) * sizeof(float);
    const std::uint64_t dataSize = static_cast<std::uint64_t>(buffer.frames()) * blockAlign;

    std::ofstream out(path.c_str(), std::ios::binary | std::ios::trunc);
    if (!out) throw std::runtime_error("Cannot open WAV for writing");

    writeWaveHeader(out, channels, sampleRate, static_cast<std::uint64_t>(buffer.frames()), dataSize);

    for (std::size_t f = 0; f < buffer.frames(); ++f)
        for (std::size_t c = 0; c < buffer.channels(); ++c)
            writeLE(out, buffer.sample(c, f));

    if (!out) throw std::runtime_error("WAV write failed");
}

WavData WavFile::read(const std::string& path) {
    std::ifstream in(path.c_str(), std::ios::binary);
    if (!in) throw std::runtime_error("Cannot open WAV for reading");

    const auto containerTag = readTag(in);
    const bool rf64 = containerTag == "RF64";
    if (!rf64 && containerTag != "RIFF") throw std::runtime_error("Not RIFF/RF64");
    (void)readLE<std::uint32_t>(in);
    if (readTag(in) != "WAVE") throw std::runtime_error("Not WAVE");

    std::uint16_t format = 0U, channels = 0U, bits = 0U, blockAlign = 0U;
    std::uint32_t sampleRate = 0U;
    std::uint64_t dataSize = 0U;
    std::uint64_t rf64DataSize = 0U;
    std::streampos dataPos {};
    bool haveFmt = false;
    bool haveData = false;
    bool haveDs64 = false;

    while (in && !(haveFmt && haveData)) {
        const auto tag = readTag(in);
        const auto chunkSize32 = readLE<std::uint32_t>(in);
        std::uint64_t chunkSize = chunkSize32;

        if (tag == "ds64") {
            if (chunkSize32 < 28U) throw std::runtime_error("Invalid RF64 ds64 chunk");
            (void)readLE<std::uint64_t>(in); // RIFF size
            rf64DataSize = readLE<std::uint64_t>(in);
            (void)readLE<std::uint64_t>(in); // sample count
            const auto tableLength = readLE<std::uint32_t>(in);
            const std::uint64_t consumed = 28U;
            const std::uint64_t remaining = chunkSize - consumed;
            if (tableLength > 0U && remaining < static_cast<std::uint64_t>(tableLength) * 12U)
                throw std::runtime_error("Invalid RF64 ds64 table");
            if (remaining > 0U) in.seekg(static_cast<std::streamoff>(remaining), std::ios::cur);
            haveDs64 = true;
        } else if (tag == "fmt ") {
            if (chunkSize32 < 16U) throw std::runtime_error("Invalid fmt chunk");
            format = readLE<std::uint16_t>(in);
            channels = readLE<std::uint16_t>(in);
            sampleRate = readLE<std::uint32_t>(in);
            (void)readLE<std::uint32_t>(in);
            blockAlign = readLE<std::uint16_t>(in);
            bits = readLE<std::uint16_t>(in);
            if (chunkSize32 > 16U) in.seekg(static_cast<std::streamoff>(chunkSize32 - 16U), std::ios::cur);
            haveFmt = true;
        } else if (tag == "data") {
            if (rf64 && chunkSize32 == 0xFFFFFFFFU) {
                if (!haveDs64) throw std::runtime_error("RF64 data chunk missing ds64");
                chunkSize = rf64DataSize;
            }
            dataSize = chunkSize;
            dataPos = in.tellg();
            haveData = true;
            if (haveFmt) break;
            in.seekg(static_cast<std::streamoff>(chunkSize), std::ios::cur);
        } else {
            in.seekg(static_cast<std::streamoff>(chunkSize), std::ios::cur);
        }

        if ((chunkSize & 1U) != 0U) in.seekg(1, std::ios::cur);
    }

    if (!haveFmt || !haveData || channels == 0U || blockAlign == 0U)
        throw std::runtime_error("Incomplete WAV");
    if (dataSize % blockAlign != 0U) throw std::runtime_error("WAV data is not frame-aligned");

    const std::uint64_t frames64 = dataSize / blockAlign;
    if (frames64 > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
        throw std::runtime_error("WAV is too large for this process");
    const auto frames = static_cast<std::size_t>(frames64);

    AudioBuffer audio(channels, frames);
    in.clear();
    in.seekg(dataPos);

    const auto expectedAlign = static_cast<std::uint64_t>(channels) * (bits / 8U);
    if ((bits % 8U) != 0U || expectedAlign != blockAlign)
        throw std::runtime_error("Unsupported WAV block alignment");

    if (format == 3U && bits == 32U) {
        for (std::size_t f = 0; f < frames; ++f)
            for (std::size_t c = 0; c < channels; ++c)
                audio.sample(c, f) = readLE<float>(in);
    } else if (format == 1U && bits == 16U) {
        for (std::size_t f = 0; f < frames; ++f)
            for (std::size_t c = 0; c < channels; ++c)
                audio.sample(c, f) = static_cast<float>(readLE<std::int16_t>(in)) / 32768.0F;
    } else if (format == 1U && bits == 24U) {
        for (std::size_t f = 0; f < frames; ++f) {
            for (std::size_t c = 0; c < channels; ++c) {
                std::array<unsigned char, 3> bytes{};
                in.read(reinterpret_cast<char*>(bytes.data()), 3);
                if (!in) throw std::runtime_error("Unexpected EOF");
                std::uint32_t raw = static_cast<std::uint32_t>(bytes[0]) |
                                    (static_cast<std::uint32_t>(bytes[1]) << 8U) |
                                    (static_cast<std::uint32_t>(bytes[2]) << 16U);
                if ((raw & 0x00800000U) != 0U) raw |= 0xFF000000U;
                const auto value = static_cast<std::int32_t>(raw);
                audio.sample(c, f) = static_cast<float>(static_cast<double>(value) / 8388608.0);
            }
        }
    } else if (format == 1U && bits == 32U) {
        for (std::size_t f = 0; f < frames; ++f)
            for (std::size_t c = 0; c < channels; ++c)
                audio.sample(c, f) = static_cast<float>(static_cast<double>(readLE<std::int32_t>(in)) / 2147483648.0);
    } else {
        throw std::runtime_error("Unsupported WAV format (supports PCM16/24/32 and Float32)");
    }

    return {sampleRate, std::move(audio)};
}

} // namespace silveton
