#include "silveton/MidiPartEditor.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <utility>

namespace silveton {

void MidiPartEditor::validate(const MidiPart& part) const {
    if (!std::isfinite(part.timelineStartQuarterNotes) || part.timelineStartQuarterNotes < 0.0 ||
        !std::isfinite(part.sourceOffsetQuarterNotes) || part.sourceOffsetQuarterNotes < 0.0 ||
        !std::isfinite(part.lengthQuarterNotes) || part.lengthQuarterNotes <= 0.0 ||
        !std::isfinite(part.loopLengthQuarterNotes) || part.loopLengthQuarterNotes <= 0.0)
        throw std::invalid_argument("invalid MIDI part");
}

MidiPart* MidiPartEditor::find(std::uint64_t id) noexcept {
    auto it = std::find_if(parts_.begin(), parts_.end(), [id](const MidiPart& p){ return p.id == id; });
    return it == parts_.end() ? nullptr : &*it;
}

std::uint64_t MidiPartEditor::nextId() const {
    std::uint64_t maximum = 0U;
    for (const auto& p : parts_) maximum = std::max(maximum, p.id);
    if (maximum == std::numeric_limits<std::uint64_t>::max()) throw std::overflow_error("MIDI part id exhausted");
    return maximum + 1U;
}

void MidiPartEditor::push(std::vector<MidiPart> before) {
    undo_.push_back({std::move(before), parts_});
    if (undo_.size() > kMaxUndoSteps) undo_.erase(undo_.begin());
    redo_.clear();
}

std::uint64_t MidiPartEditor::add(MidiPart part) {
    validate(part);
    if (part.id == 0U) part.id = nextId();
    if (find(part.id) != nullptr) throw std::invalid_argument("duplicate MIDI part id");
    auto before = parts_;
    const auto id = part.id;
    parts_.push_back(std::move(part));
    std::stable_sort(parts_.begin(), parts_.end(), [](const auto& a, const auto& b){
        if (a.timelineStartQuarterNotes != b.timelineStartQuarterNotes) return a.timelineStartQuarterNotes < b.timelineStartQuarterNotes;
        return a.id < b.id;
    });
    push(std::move(before));
    return id;
}

bool MidiPartEditor::remove(std::uint64_t id) {
    auto before = parts_;
    const auto old = parts_.size();
    parts_.erase(std::remove_if(parts_.begin(), parts_.end(), [id](const auto& p){ return p.id == id; }), parts_.end());
    if (parts_.size() == old) return false;
    push(std::move(before)); return true;
}

bool MidiPartEditor::move(std::uint64_t id, double qn) {
    if (!std::isfinite(qn) || qn < 0.0) throw std::invalid_argument("invalid MIDI part position");
    MidiPart* part = find(id); if (!part) return false;
    auto before = parts_; part->timelineStartQuarterNotes = qn;
    std::stable_sort(parts_.begin(), parts_.end(), [](const auto& a, const auto& b){ return a.timelineStartQuarterNotes < b.timelineStartQuarterNotes; });
    push(std::move(before)); return true;
}

bool MidiPartEditor::trimLeft(std::uint64_t id, double amount) {
    if (!std::isfinite(amount) || amount < 0.0) throw std::invalid_argument("invalid MIDI part trim");
    MidiPart* part = find(id); if (!part) return false;
    if (!(amount < part->lengthQuarterNotes)) throw std::invalid_argument("MIDI part trim removes entire part");
    auto before = parts_;
    part->timelineStartQuarterNotes += amount;
    part->sourceOffsetQuarterNotes += amount;
    part->lengthQuarterNotes -= amount;
    push(std::move(before)); return true;
}

bool MidiPartEditor::trimRight(std::uint64_t id, double length) {
    if (!std::isfinite(length) || length <= 0.0) throw std::invalid_argument("invalid MIDI part length");
    MidiPart* part = find(id); if (!part) return false;
    auto before = parts_; part->lengthQuarterNotes = length; push(std::move(before)); return true;
}

bool MidiPartEditor::setLoopLength(std::uint64_t id, double loop) {
    if (!std::isfinite(loop) || loop <= 0.0) throw std::invalid_argument("invalid MIDI loop length");
    MidiPart* part = find(id); if (!part) return false;
    auto before = parts_; part->loopLengthQuarterNotes = loop; push(std::move(before)); return true;
}

bool MidiPartEditor::setMuted(std::uint64_t id, bool muted) {
    MidiPart* part = find(id); if (!part) return false;
    auto before = parts_; part->muted = muted; push(std::move(before)); return true;
}

std::uint64_t MidiPartEditor::duplicate(std::uint64_t id, double newStart) {
    MidiPart* part = find(id); if (!part) return 0U;
    MidiPart copy = *part; copy.id = 0U; copy.timelineStartQuarterNotes = newStart; return add(std::move(copy));
}

std::uint64_t MidiPartEditor::split(std::uint64_t id, double timelineQn) {
    MidiPart* part = find(id); if (!part) return 0U;
    const double offset = timelineQn - part->timelineStartQuarterNotes;
    if (!(offset > 0.0 && offset < part->lengthQuarterNotes)) throw std::invalid_argument("split outside MIDI part");
    auto before = parts_;
    MidiPart right = *part;
    right.id = nextId();
    const std::uint64_t rightId = right.id;
    right.timelineStartQuarterNotes = timelineQn;
    right.sourceOffsetQuarterNotes += offset;
    right.lengthQuarterNotes -= offset;
    part = find(id);
    part->lengthQuarterNotes = offset;
    parts_.push_back(std::move(right));
    std::stable_sort(parts_.begin(), parts_.end(), [](const auto& a, const auto& b){ return a.timelineStartQuarterNotes < b.timelineStartQuarterNotes; });
    push(std::move(before));
    return rightId;
}

bool MidiPartEditor::undo() {
    if (undo_.empty()) return false;
    Command command = std::move(undo_.back()); undo_.pop_back();
    parts_ = command.before; redo_.push_back(std::move(command)); return true;
}

bool MidiPartEditor::redo() {
    if (redo_.empty()) return false;
    Command command = std::move(redo_.back()); redo_.pop_back();
    parts_ = command.after; undo_.push_back(std::move(command));
    if (undo_.size() > kMaxUndoSteps) undo_.erase(undo_.begin());
    return true;
}

} // namespace silveton
