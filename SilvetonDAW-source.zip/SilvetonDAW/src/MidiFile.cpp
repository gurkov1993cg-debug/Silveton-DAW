#include "silveton/MidiFile.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <map>
#include <random>
#include <stdexcept>
#include <tuple>

namespace silveton {

namespace {

class Reader {
public:
    Reader(const std::uint8_t* data, std::size_t size) : d_(data), n_(size) {}
    bool eof() const noexcept { return p_ >= n_; }
    std::size_t pos() const noexcept { return p_; }
    std::uint8_t u8() { if (p_ >= n_) throw std::runtime_error("MIDI file truncated"); return d_[p_++]; }
    std::uint8_t peek() const { if (p_ >= n_) throw std::runtime_error("MIDI file truncated"); return d_[p_]; }
    std::uint16_t u16() { const auto a = u8(); return static_cast<std::uint16_t>((a << 8U) | u8()); }
    std::uint32_t u32() { std::uint32_t v = 0U; for (int i = 0; i < 4; ++i) v = (v << 8U) | u8(); return v; }
    std::uint32_t vlq() {
        std::uint32_t v = 0U;
        for (int i = 0; i < 4; ++i) {
            const auto b = u8();
            v = (v << 7U) | (b & 0x7FU);
            if (!(b & 0x80U)) return v;
        }
        throw std::runtime_error("MIDI variable-length quantity too long");
    }
    void skip(std::size_t k) { if (k > n_ - p_) throw std::runtime_error("MIDI file truncated"); p_ += k; }
    const std::uint8_t* here() const noexcept { return d_ + p_; }
private:
    const std::uint8_t* d_;
    std::size_t n_;
    std::size_t p_ {0U};
};

struct TimedMeta {
    std::uint64_t tick;
    bool tempo;
    double bpm;
    std::uint16_t num, den;
};

struct RawEvent { std::uint64_t tick; std::uint8_t status, d1, d2; };

void buildTempoMap(TempoMap& map, std::vector<TimedMeta> metas, std::uint16_t ppq) {
    std::stable_sort(metas.begin(), metas.end(), [](const TimedMeta& a, const TimedMeta& b) { return a.tick < b.tick; });
    for (const auto& m : metas) {
        const double q = static_cast<double>(m.tick) / ppq;
        if (m.tick == 0U) {
            if (m.tempo) map.setInitialTempo(m.bpm);
            else map.setInitialTimeSignature(m.num, m.den);
            continue;
        }
        const std::int64_t sample = map.sampleAtQuarterNotes(q);
        if (m.tempo) map.addTempoChange(sample, m.bpm);
        else map.addTimeSignatureChange(sample, m.num, m.den);
    }
}

void appendEvents(MidiSequence& seq, std::vector<RawEvent>& events, std::uint16_t ppq, std::uint64_t endTick) {
    std::stable_sort(events.begin(), events.end(), [](const RawEvent& a, const RawEvent& b) { return a.tick < b.tick; });
    std::map<std::pair<int, int>, std::vector<std::pair<std::uint64_t, std::uint8_t>>> open;  // (ch,pitch) -> FIFO of (tick, vel)
    auto closeNote = [&](int ch, int pitch, std::uint64_t offTick, std::uint8_t releaseVel) {
        auto it = open.find({ch, pitch});
        if (it == open.end() || it->second.empty()) return;
        const auto [onTick, vel] = it->second.front();
        it->second.erase(it->second.begin());
        MusicalMidiNote n;
        n.channel = static_cast<std::uint8_t>(ch);
        n.pitch = static_cast<std::uint8_t>(pitch);
        n.velocity = vel;
        n.releaseVelocity = releaseVel;
        n.startQuarterNotes = static_cast<double>(onTick) / ppq;
        const std::uint64_t len = offTick > onTick ? offTick - onTick : 1U;
        n.durationQuarterNotes = static_cast<double>(len) / ppq;
        (void)seq.addNote(n);
    };
    for (const auto& e : events) {
        const std::uint8_t type = e.status & 0xF0U;
        const int ch = e.status & 0x0F;
        if (type == 0x90U && e.d2 > 0U) open[{ch, e.d1}].push_back({e.tick, e.d2});
        else if (type == 0x80U || type == 0x90U) closeNote(ch, e.d1, e.tick, type == 0x80U ? e.d2 : 64U);
        else {
            MusicalMidiMessage m;
            m.quarterNotes = static_cast<double>(e.tick) / ppq;
            m.status = e.status; m.data1 = e.d1; m.data2 = e.d2;
            (void)seq.addMessage(m);
        }
    }
    for (auto& [key, list] : open)
        while (!list.empty()) closeNote(key.first, key.second, std::max<std::uint64_t>(endTick, list.front().first + 1U), 64U);
}

} // namespace

SmfImportResult StandardMidiFile::read(const std::string& path, double sampleRate, bool splitChannels) {
    std::ifstream in(path.c_str(), std::ios::binary);
    if (!in) throw std::runtime_error("cannot open MIDI file: " + path);
    std::vector<std::uint8_t> bytes((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    return parse(bytes, sampleRate, splitChannels);
}

SmfImportResult StandardMidiFile::parse(const std::vector<std::uint8_t>& bytes, double sampleRate, bool splitChannels) {
    Reader r(bytes.data(), bytes.size());
    if (r.u32() != 0x4D546864U) throw std::runtime_error("not a Standard MIDI File (missing MThd)");
    const std::uint32_t headerLen = r.u32();
    if (headerLen < 6U) throw std::runtime_error("MIDI header too short");
    SmfImportResult result;
    result.format = r.u16();
    const std::uint16_t trackCount = r.u16();
    const std::uint16_t division = r.u16();
    r.skip(headerLen - 6U);
    if (result.format > 1U) throw std::runtime_error("MIDI format 2 (pattern) files are not supported");
    if (division & 0x8000U) throw std::runtime_error("SMPTE-timed MIDI files are not supported");
    if (division == 0U) throw std::runtime_error("MIDI division is zero");
    result.ticksPerQuarter = division;
    result.tempoMap.setSampleRate(sampleRate);

    std::vector<TimedMeta> metas;
    std::uint64_t globalEnd = 0U;
    struct Parsed { std::string name; std::vector<RawEvent> events; std::uint64_t end {0U}; };
    std::vector<Parsed> parsed;
    for (std::uint16_t t = 0U; t < trackCount && !r.eof(); ++t) {
        const std::uint32_t id = r.u32();
        const std::uint32_t len = r.u32();
        if (id != 0x4D54726BU) { r.skip(len); continue; }  // unknown chunk
        if (len > bytes.size() - r.pos()) throw std::runtime_error("MIDI track chunk truncated");
        Reader tr(r.here(), len);
        r.skip(len);
        Parsed p;
        std::uint64_t tick = 0U;
        std::uint8_t running = 0U;
        while (!tr.eof()) {
            tick += tr.vlq();
            std::uint8_t status = tr.peek();
            if (status & 0x80U) { tr.u8(); } else {
                if (!running) throw std::runtime_error("MIDI running status without status byte");
                status = running;
            }
            if (status == 0xFFU) {
                const std::uint8_t type = tr.u8();
                const std::uint32_t mlen = tr.vlq();
                if (mlen > len) throw std::runtime_error("MIDI meta event too long");
                const std::uint8_t* data = tr.here();
                tr.skip(mlen);
                if (type == 0x2FU) break;
                if (type == 0x03U && p.name.empty()) p.name.assign(reinterpret_cast<const char*>(data), mlen);
                if (type == 0x51U && mlen == 3U) {
                    const std::uint32_t us = (std::uint32_t(data[0]) << 16U) | (std::uint32_t(data[1]) << 8U) | data[2];
                    if (us > 0U) metas.push_back({tick, true, 60000000.0 / us, 4U, 4U});
                }
                if (type == 0x58U && mlen >= 2U && data[1] < 8U)
                    metas.push_back({tick, false, 0.0, data[0], static_cast<std::uint16_t>(1U << data[1])});
                continue;
            }
            if (status == 0xF0U || status == 0xF7U) { tr.skip(tr.vlq()); running = 0U; continue; }
            if (status >= 0xF8U) continue;                     // realtime bytes
            if (status >= 0xF1U) throw std::runtime_error("unexpected system common message in MIDI file");
            running = status;
            const std::uint8_t type = status & 0xF0U;
            const std::uint8_t d1 = tr.u8() & 0x7FU;
            const std::uint8_t d2 = (type == 0xC0U || type == 0xD0U) ? 0U : (tr.u8() & 0x7FU);
            p.events.push_back({tick, status, d1, d2});
        }
        p.end = tick;
        globalEnd = std::max(globalEnd, tick);
        parsed.push_back(std::move(p));
    }

    buildTempoMap(result.tempoMap, metas, division);

    auto emit = [&](std::string name, std::vector<RawEvent> events, std::uint64_t end) {
        if (events.empty()) return;
        SmfTrackData data;
        data.name = std::move(name);
        data.firstChannel = events.front().status & 0x0F;
        appendEvents(data.sequence, events, division, std::max(end, globalEnd));
        result.tracks.push_back(std::move(data));
    };
    for (auto& p : parsed) {
        if (splitChannels && result.format == 0U) {
            std::map<int, std::vector<RawEvent>> byChannel;
            for (const auto& e : p.events) byChannel[e.status & 0x0F].push_back(e);
            for (auto& [ch, ev] : byChannel)
                emit((p.name.empty() ? std::string("Channel") : p.name) + " " + std::to_string(ch + 1), std::move(ev), p.end);
        } else {
            emit(p.name, std::move(p.events), p.end);
        }
    }
    return result;
}

namespace {
void putVlq(std::vector<std::uint8_t>& out, std::uint32_t v) {
    std::uint8_t buf[5];
    int n = 0;
    buf[n++] = v & 0x7FU;
    while (v >>= 7U) buf[n++] = static_cast<std::uint8_t>((v & 0x7FU) | 0x80U);
    while (n) out.push_back(buf[--n]);
}
void put32(std::vector<std::uint8_t>& o, std::uint32_t v) { for (int s = 24; s >= 0; s -= 8) o.push_back(static_cast<std::uint8_t>(v >> s)); }
void put16(std::vector<std::uint8_t>& o, std::uint16_t v) { o.push_back(static_cast<std::uint8_t>(v >> 8U)); o.push_back(static_cast<std::uint8_t>(v)); }

struct OutEvent { std::uint64_t tick; int order; std::vector<std::uint8_t> bytes; };

void writeTrack(std::vector<std::uint8_t>& out, std::vector<OutEvent> events) {
    std::stable_sort(events.begin(), events.end(), [](const OutEvent& a, const OutEvent& b) {
        return std::tie(a.tick, a.order) < std::tie(b.tick, b.order);
    });
    std::vector<std::uint8_t> body;
    std::uint64_t last = 0U;
    for (const auto& e : events) {
        putVlq(body, static_cast<std::uint32_t>(e.tick - last));
        last = e.tick;
        body.insert(body.end(), e.bytes.begin(), e.bytes.end());
    }
    body.insert(body.end(), {0x00, 0xFF, 0x2F, 0x00});
    put32(out, 0x4D54726BU);
    put32(out, static_cast<std::uint32_t>(body.size()));
    out.insert(out.end(), body.begin(), body.end());
}

std::uint64_t toTick(double q, std::uint16_t ppq) { return static_cast<std::uint64_t>(std::llround(std::max(0.0, q) * ppq)); }
} // namespace

std::vector<std::uint8_t> StandardMidiFile::serialize(const std::vector<SmfExportTrack>& tracks,
                                                      const TempoMap& tempoMap, std::uint16_t ppq) {
    if (ppq == 0U || ppq > 0x7FFFU) throw std::invalid_argument("MIDI ticks per quarter must be 1..32767");
    std::vector<std::uint8_t> out;
    put32(out, 0x4D546864U); put32(out, 6U); put16(out, 1U);
    put16(out, static_cast<std::uint16_t>(tracks.size() + 1U)); put16(out, ppq);

    std::vector<OutEvent> conductor;
    auto tempoEvent = [&](std::uint64_t tick, double bpm) {
        const auto us = static_cast<std::uint32_t>(std::llround(60000000.0 / bpm));
        conductor.push_back({tick, 0, {0xFF, 0x51, 0x03, static_cast<std::uint8_t>(us >> 16U), static_cast<std::uint8_t>(us >> 8U), static_cast<std::uint8_t>(us)}});
    };
    auto meterEvent = [&](std::uint64_t tick, std::uint16_t num, std::uint16_t den) {
        std::uint8_t pow2 = 0U;
        while ((1U << pow2) < den && pow2 < 7U) ++pow2;
        conductor.push_back({tick, 0, {0xFF, 0x58, 0x04, static_cast<std::uint8_t>(num), pow2, 24, 8}});
    };
    tempoEvent(0U, tempoMap.initialTempo());
    meterEvent(0U, tempoMap.initialNumerator(), tempoMap.initialDenominator());
    for (const auto& c : tempoMap.changes()) {
        const auto tick = toTick(tempoMap.quarterNotesAtSample(c.sample), ppq);
        if (c.changesTempo) tempoEvent(tick, c.bpm);
        if (c.changesTimeSignature) meterEvent(tick, c.numerator, c.denominator);
    }
    writeTrack(out, std::move(conductor));

    for (const auto& t : tracks) {
        std::vector<OutEvent> ev;
        if (!t.name.empty()) {
            std::vector<std::uint8_t> meta {0xFF, 0x03};
            std::vector<std::uint8_t> len;
            putVlq(len, static_cast<std::uint32_t>(t.name.size()));
            meta.insert(meta.end(), len.begin(), len.end());
            meta.insert(meta.end(), t.name.begin(), t.name.end());
            ev.push_back({0U, -1, meta});
        }
        if (t.sequence) {
            for (const auto& n : t.sequence->notes()) {
                if (n.muted) continue;
                const auto on = toTick(n.startQuarterNotes, ppq);
                const auto off = std::max(on + 1U, toTick(n.startQuarterNotes + n.durationQuarterNotes, ppq));
                ev.push_back({on, 2, {static_cast<std::uint8_t>(0x90U | n.channel), n.pitch, std::max<std::uint8_t>(1U, n.velocity)}});
                ev.push_back({off, 0, {static_cast<std::uint8_t>(0x80U | n.channel), n.pitch, n.releaseVelocity}});
            }
            for (const auto& m : t.sequence->messages()) {
                if (m.muted) continue;
                const std::uint8_t type = m.status & 0xF0U;
                if (type == 0xC0U || type == 0xD0U) ev.push_back({toTick(m.quarterNotes, ppq), 1, {m.status, m.data1}});
                else ev.push_back({toTick(m.quarterNotes, ppq), 1, {m.status, m.data1, m.data2}});
            }
        }
        writeTrack(out, std::move(ev));
    }
    return out;
}

void StandardMidiFile::write(const std::string& path, const std::vector<SmfExportTrack>& tracks,
                             const TempoMap& tempoMap, std::uint16_t ppq) {
    const auto bytes = serialize(tracks, tempoMap, ppq);
    std::ofstream out(path.c_str(), std::ios::binary);
    if (!out) throw std::runtime_error("cannot write MIDI file: " + path);
    out.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!out) throw std::runtime_error("MIDI file write failed: " + path);
}

MidiSequence sequenceFromRenderPlan(const MidiRenderPlan& plan, const TempoMap& tempoMap) {
    MidiSequence out;
    std::map<std::pair<int, int>, std::vector<std::pair<double, std::uint8_t>>> open;
    for (const auto& e : plan.events()) {
        const std::uint8_t type = e.status & 0xF0U;
        const int ch = e.status & 0x0F;
        const double q = tempoMap.quarterNotesAtSample(e.sample);
        if (type == 0x90U && e.data2 > 0U) { open[{ch, e.data1}].push_back({q, e.data2}); continue; }
        if (type == 0x80U || type == 0x90U) {
            auto it = open.find({ch, e.data1});
            if (it == open.end() || it->second.empty()) continue;
            const auto on = it->second.front();
            it->second.erase(it->second.begin());
            MusicalMidiNote n;
            n.channel = static_cast<std::uint8_t>(ch); n.pitch = e.data1; n.velocity = on.second;
            n.startQuarterNotes = std::max(0.0, on.first);
            n.durationQuarterNotes = std::max(1.0e-4, q - on.first);
            (void)out.addNote(n);
            continue;
        }
        if (type >= 0xA0U && type <= 0xE0U) {
            MusicalMidiMessage m;
            m.quarterNotes = std::max(0.0, q); m.status = e.status; m.data1 = e.data1; m.data2 = e.data2;
            (void)out.addMessage(m);
        }
    }
    return out;
}

// ---------------------------------------------------------------- functions --
namespace {
bool selected(const MidiFunctions::Selection& s, std::uint64_t id) {
    return s.empty() || std::find(s.begin(), s.end(), id) != s.end();
}
std::vector<MusicalMidiNote> snapshot(const MidiSequence& seq, const MidiFunctions::Selection& s) {
    std::vector<MusicalMidiNote> out;
    for (const auto& n : seq.notes()) if (selected(s, n.id)) out.push_back(n);
    std::stable_sort(out.begin(), out.end(), [](const MusicalMidiNote& a, const MusicalMidiNote& b) { return a.startQuarterNotes < b.startQuarterNotes; });
    return out;
}
std::uint8_t clampVel(double v) { return static_cast<std::uint8_t>(std::clamp<long>(std::lround(v), 1L, 127L)); }
} // namespace

std::size_t MidiFunctions::legato(MidiSequence& seq, double overlap, const Selection& s) {
    const auto notes = snapshot(seq, s);
    std::size_t changed = 0U;
    for (std::size_t i = 0U; i < notes.size(); ++i) {
        const MusicalMidiNote* next = nullptr;
        for (std::size_t j = i + 1U; j < notes.size(); ++j)
            if (notes[j].startQuarterNotes > notes[i].startQuarterNotes + 1.0e-9) { next = &notes[j]; break; }
        if (!next) continue;
        const double len = next->startQuarterNotes - notes[i].startQuarterNotes + overlap;
        if (len > 1.0e-6 && seq.resizeNote(notes[i].id, len)) ++changed;
    }
    return changed;
}

std::size_t MidiFunctions::fixedLength(MidiSequence& seq, double length, const Selection& s) {
    if (!(length > 0.0)) throw std::invalid_argument("fixed length must be positive");
    std::size_t changed = 0U;
    for (const auto& n : snapshot(seq, s)) if (seq.resizeNote(n.id, length)) ++changed;
    return changed;
}

std::size_t MidiFunctions::fixedVelocity(MidiSequence& seq, std::uint8_t velocity, const Selection& s) {
    std::size_t changed = 0U;
    for (const auto& n : snapshot(seq, s)) if (seq.setNoteVelocity(n.id, clampVel(velocity))) ++changed;
    return changed;
}

std::size_t MidiFunctions::scaleVelocity(MidiSequence& seq, double scale, int offset, const Selection& s) {
    std::size_t changed = 0U;
    for (const auto& n : snapshot(seq, s)) if (seq.setNoteVelocity(n.id, clampVel(n.velocity * scale + offset))) ++changed;
    return changed;
}

std::size_t MidiFunctions::compressVelocity(MidiSequence& seq, double ratio, const Selection& s) {
    const auto notes = snapshot(seq, s);
    if (notes.empty()) return 0U;
    double mean = 0.0;
    for (const auto& n : notes) mean += n.velocity;
    mean /= static_cast<double>(notes.size());
    std::size_t changed = 0U;
    for (const auto& n : notes) if (seq.setNoteVelocity(n.id, clampVel(mean + (n.velocity - mean) * ratio))) ++changed;
    return changed;
}

std::size_t MidiFunctions::quantize(MidiSequence& seq, double grid, double swing, double strength, bool ends, const Selection& s) {
    if (!(grid > 0.0)) throw std::invalid_argument("quantize grid must be positive");
    swing = std::clamp(swing, 0.0, 1.0);
    strength = std::clamp(strength, 0.0, 1.0);
    auto target = [&](double q) {
        const double pair = grid * 2.0;
        const double base = std::floor(q / pair) * pair;
        const double onBeat = base, offBeat = base + grid + swing * grid / 3.0, nextOn = base + pair;
        double best = onBeat;
        if (std::abs(q - offBeat) < std::abs(q - best)) best = offBeat;
        if (std::abs(q - nextOn) < std::abs(q - best)) best = nextOn;
        return best;
    };
    std::size_t changed = 0U;
    for (const auto& n : snapshot(seq, s)) {
        const double start = n.startQuarterNotes + (target(n.startQuarterNotes) - n.startQuarterNotes) * strength;
        double end = n.startQuarterNotes + n.durationQuarterNotes;
        if (ends) end = end + (target(end) - end) * strength;
        const double newStart = std::max(0.0, start);
        double dur = end - newStart;
        if (dur <= 1.0e-6) dur = ends ? grid : n.durationQuarterNotes;
        bool any = false;
        if (std::abs(newStart - n.startQuarterNotes) > 1.0e-12) any |= seq.moveNote(n.id, newStart);
        if (std::abs(dur - n.durationQuarterNotes) > 1.0e-12) any |= seq.resizeNote(n.id, dur);
        if (any) ++changed;
    }
    return changed;
}

std::size_t MidiFunctions::humanize(MidiSequence& seq, double timing, int velRange, std::uint32_t seed, const Selection& s) {
    std::mt19937 rng(seed);
    std::uniform_real_distribution<double> t(-std::abs(timing), std::abs(timing));
    std::uniform_int_distribution<int> v(-std::abs(velRange), std::abs(velRange));
    std::size_t changed = 0U;
    for (const auto& n : snapshot(seq, s)) {
        const double start = std::max(0.0, n.startQuarterNotes + (timing != 0.0 ? t(rng) : 0.0));
        const int vel = n.velocity + (velRange != 0 ? v(rng) : 0);
        bool any = seq.moveNote(n.id, start);
        any |= seq.setNoteVelocity(n.id, clampVel(vel));
        if (any) ++changed;
    }
    return changed;
}

std::size_t MidiFunctions::deleteDoubles(MidiSequence& seq) {
    const auto notes = snapshot(seq, {});
    std::vector<std::uint64_t> remove;
    for (std::size_t i = 0U; i < notes.size(); ++i)
        for (std::size_t j = 0U; j < i; ++j)
            if (notes[j].pitch == notes[i].pitch && notes[j].channel == notes[i].channel &&
                std::abs(notes[j].startQuarterNotes - notes[i].startQuarterNotes) < 1.0e-6 &&
                std::find(remove.begin(), remove.end(), notes[j].id) == remove.end()) {
                remove.push_back(notes[i].id);
                break;
            }
    for (auto id : remove) (void)seq.removeNote(id);
    return remove.size();
}

std::size_t MidiFunctions::deleteOverlaps(MidiSequence& seq) {
    const auto notes = snapshot(seq, {});
    std::size_t changed = 0U;
    for (std::size_t i = 0U; i < notes.size(); ++i) {
        for (std::size_t j = i + 1U; j < notes.size(); ++j) {
            if (notes[j].pitch != notes[i].pitch || notes[j].channel != notes[i].channel) continue;
            if (notes[j].startQuarterNotes <= notes[i].startQuarterNotes + 1.0e-9) continue;
            const double end = notes[i].startQuarterNotes + notes[i].durationQuarterNotes;
            if (end > notes[j].startQuarterNotes && seq.resizeNote(notes[i].id, notes[j].startQuarterNotes - notes[i].startQuarterNotes)) ++changed;
            break;
        }
    }
    return changed;
}

std::size_t MidiFunctions::reverse(MidiSequence& seq, double a, double b, const Selection& s) {
    if (!(b > a) || a < 0.0) throw std::invalid_argument("reverse range is empty");
    std::size_t changed = 0U;
    for (const auto& n : snapshot(seq, s)) {
        const double end = n.startQuarterNotes + n.durationQuarterNotes;
        if (n.startQuarterNotes < a || end > b) continue;
        const double start = a + (b - end);
        if (seq.moveNote(n.id, start)) ++changed;
    }
    return changed;
}

std::size_t MidiFunctions::invert(MidiSequence& seq, int axis, const Selection& s) {
    std::size_t changed = 0U;
    for (const auto& n : snapshot(seq, s)) {
        const int p = std::clamp(2 * axis - static_cast<int>(n.pitch), 0, 127);
        if (seq.setNotePitch(n.id, static_cast<std::uint8_t>(p))) ++changed;
    }
    return changed;
}

std::size_t MidiFunctions::deleteShortOrSoft(MidiSequence& seq, double minLen, std::uint8_t minVel) {
    std::vector<std::uint64_t> remove;
    for (const auto& n : seq.notes()) if (n.durationQuarterNotes < minLen || n.velocity < minVel) remove.push_back(n.id);
    for (auto id : remove) (void)seq.removeNote(id);
    return remove.size();
}

} // namespace silveton
