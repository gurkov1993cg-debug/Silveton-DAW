#include "silveton/AudioProcessing.h"
#include "silveton/Arrangement.h"
#include "silveton/ProjectMediaRelinker.h"
#include "silveton/StemBounce.h"
#include "silveton/WavFile.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <fstream>
#include <stdexcept>

namespace silveton {

const char* AudioProcessor::name(AudioProcess p) noexcept {
    switch (p) {
        case AudioProcess::Normalize: return "Normalize";
        case AudioProcess::Gain: return "Gain";
        case AudioProcess::Reverse: return "Reverse";
        case AudioProcess::InvertPhase: return "Invert Phase";
        case AudioProcess::RemoveDc: return "Remove DC Offset";
        case AudioProcess::Silence: return "Silence";
        case AudioProcess::FadeIn: return "Fade In";
        case AudioProcess::FadeOut: return "Fade Out";
        case AudioProcess::StereoFlip: return "Stereo Flip";
        case AudioProcess::MonoSum: return "Mono Sum";
        case AudioProcess::TimeStretch: return "Time Stretch";
        case AudioProcess::PitchShift: return "Pitch Shift";
    }
    return "Process";
}

float AudioProcessor::peak(const AudioBuffer& b) noexcept {
    float m = 0.0F;
    for (std::size_t c = 0U; c < b.channels(); ++c)
        for (std::size_t i = 0U; i < b.frames(); ++i) m = std::max(m, std::abs(b.channelData(c)[i]));
    return m;
}

namespace {
double fadeGain(FadeShape shape, double x) noexcept {
    x = std::clamp(x, 0.0, 1.0);
    switch (shape) {
        case FadeShape::Linear: return x;
        case FadeShape::Exponential: return x * x * x;
        default: return std::sin(x * 1.5707963267948966);
    }
}
std::string fileSafe(std::string s) {
    for (auto& c : s) if (c == ' ' || c == '/' || c == ':' || c == '\\') c = '_';
    return s;
}
} // namespace

AudioBuffer AudioProcessor::apply(const AudioBuffer& in, AudioProcess process, const AudioProcessOptions& o) {
    if (in.channels() == 0U) throw std::invalid_argument("audio process needs audio");
    const std::size_t n = in.frames();
    AudioBuffer out = in;
    switch (process) {
        case AudioProcess::Normalize: {
            const float pk = peak(in);
            if (pk <= 0.0F) return out;
            const auto g = static_cast<float>(std::pow(10.0, o.normalizeTargetDb / 20.0) / pk);
            for (std::size_t c = 0U; c < out.channels(); ++c) for (std::size_t i = 0U; i < n; ++i) out.channelData(c)[i] *= g;
            return out;
        }
        case AudioProcess::Gain: {
            const auto g = static_cast<float>(std::pow(10.0, o.gainDb / 20.0));
            for (std::size_t c = 0U; c < out.channels(); ++c) for (std::size_t i = 0U; i < n; ++i) out.channelData(c)[i] *= g;
            return out;
        }
        case AudioProcess::Reverse: return AudioEditor::reverse(in);
        case AudioProcess::InvertPhase:
            for (std::size_t c = 0U; c < out.channels(); ++c) for (std::size_t i = 0U; i < n; ++i) out.channelData(c)[i] = -out.channelData(c)[i];
            return out;
        case AudioProcess::RemoveDc:
            for (std::size_t c = 0U; c < out.channels(); ++c) {
                double mean = 0.0;
                for (std::size_t i = 0U; i < n; ++i) mean += out.channelData(c)[i];
                mean /= static_cast<double>(std::max<std::size_t>(1U, n));
                for (std::size_t i = 0U; i < n; ++i) out.channelData(c)[i] = static_cast<float>(out.channelData(c)[i] - mean);
            }
            return out;
        case AudioProcess::Silence: out.clear(); return out;
        case AudioProcess::FadeIn:
        case AudioProcess::FadeOut:
            for (std::size_t i = 0U; i < n; ++i) {
                const double x = n > 1U ? static_cast<double>(i) / static_cast<double>(n - 1U) : 1.0;
                const auto g = static_cast<float>(fadeGain(o.fadeShape, process == AudioProcess::FadeIn ? x : 1.0 - x));
                for (std::size_t c = 0U; c < out.channels(); ++c) out.channelData(c)[i] *= g;
            }
            return out;
        case AudioProcess::StereoFlip:
            if (out.channels() >= 2U) std::swap_ranges(out.channelData(0U), out.channelData(0U) + n, out.channelData(1U));
            return out;
        case AudioProcess::MonoSum:
            if (out.channels() >= 2U)
                for (std::size_t i = 0U; i < n; ++i) {
                    const float m = 0.5F * (out.channelData(0U)[i] + out.channelData(1U)[i]);
                    out.channelData(0U)[i] = m; out.channelData(1U)[i] = m;
                }
            return out;
        case AudioProcess::TimeStretch:
            if (!(o.stretchRatio >= 0.25 && o.stretchRatio <= 4.0)) throw std::invalid_argument("time stretch ratio must be 0.25..4");
            return AudioEditor::timeStretch(in, o.stretchRatio, o.quality);
        case AudioProcess::PitchShift:
            if (!(std::abs(o.semitones) <= 24.0)) throw std::invalid_argument("pitch shift must be within +/-24 semitones");
            return o.preserveFormants ? AudioEditor::pitchShiftFormantPreserving(in, o.semitones, o.quality)
                                      : AudioEditor::pitchShift(in, o.semitones, o.quality);
    }
    return out;
}

AudioProcessResult AudioProcessor::processClip(Project& project, std::size_t trackIndex, std::uint64_t clipId,
                                               AudioProcess process, const AudioProcessOptions& options,
                                               const std::string& outputDirectory) {
    return processClipWith(project, trackIndex, clipId, name(process),
                           [&](const AudioBuffer& region) { return apply(region, process, options); }, outputDirectory);
}

AudioProcessResult AudioProcessor::processClipWith(Project& project, std::size_t trackIndex, std::uint64_t clipId,
                                                   const char* label, const Transform& transform,
                                                   const std::string& outputDirectory) {
    if (trackIndex >= project.tracks.size()) throw std::out_of_range("audio process track");
    auto& track = project.tracks[trackIndex];
    if (track.locked) throw std::runtime_error("track is locked");
    auto it = std::find_if(track.clips.begin(), track.clips.end(), [&](const ProjectAudioClip& c) { return c.id == clipId; });
    if (it == track.clips.end()) throw std::invalid_argument("audio process clip not found");
    ProjectAudioClip& clip = *it;
    const std::string sourcePath = clip.audioPath.empty() ? track.audioPath : clip.audioPath;
    std::uint32_t rate = 0U;
    // Frames come back at the project rate (a 44.1/48 kHz file is converted with the
    // same Studio sinc that plays it), so clip ranges line up. The file is not changed.
    const AudioBuffer whole = ProjectMediaRelinker::readWholeSource(sourcePath, rate, project.sampleRate);
    if (clip.sourceStartSample >= whole.frames()) throw std::runtime_error("clip range lies outside its media");
    const AudioBuffer region = AudioEditor::trim(whole, clip.sourceStartSample, clip.lengthSamples);
    AudioProcessResult result;
    result.peakBefore = peak(region);
    const AudioBuffer processed = transform(region);
    if (processed.frames() == 0U) throw std::runtime_error("audio process produced no audio");
    result.peakAfter = peak(processed);

    static std::atomic<std::uint64_t> counter {0U};
    const auto stamp = static_cast<unsigned long long>(
        std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count());
    std::string base = sourcePath;
    const auto slash = base.find_last_of("/\\");
    if (slash != std::string::npos) base = base.substr(slash + 1U);
    const auto dot = base.find_last_of('.');
    if (dot != std::string::npos) base = base.substr(0U, dot);
    std::string dir = outputDirectory.empty() ? std::string(".") : outputDirectory;
    if (dir.back() == '/' || dir.back() == '\\') dir.pop_back();
    result.newPath = dir + "/" + fileSafe(base) + "_" + fileSafe(label) + "_" + std::to_string(stamp) + "_" +
                     std::to_string(++counter) + ".wav";
    WavFile::writeFloat32(result.newPath, static_cast<std::uint32_t>(std::llround(project.sampleRate)), processed);
    result.frames = processed.frames();

    clip.audioPath = result.newPath;
    clip.sourceStartSample = 0U;
    clip.lengthSamples = processed.frames();
    clip.sourceFrames = processed.frames();
    clip.sourceChannels = static_cast<std::uint32_t>(processed.channels());
    clip.sourceSampleRate = static_cast<std::uint32_t>(std::llround(project.sampleRate));
    clip.fadeInSamples = std::min(clip.fadeInSamples, clip.lengthSamples);
    clip.fadeOutSamples = std::min(clip.fadeOutSamples, clip.lengthSamples);
    clip.fadeInAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
    clip.fadeOutAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
    return result;
}

AudioProcessor::RenderInPlaceResult AudioProcessor::renderInPlace(Project& project, AudioEngine& engine, Vst3RuntimeRack* rack,
                                                                 std::size_t trackIndex, std::int64_t start, std::int64_t end,
                                                                 const std::string& outputDirectory, bool muteSource) {
    if (trackIndex >= project.tracks.size()) throw std::out_of_range("render in place track");
    if (start < 0 || end <= start) throw std::invalid_argument("render in place range is empty");
    std::string dir = outputDirectory.empty() ? std::string(".") : outputDirectory;
    if (dir.back() == '/' || dir.back() == '\\') dir.pop_back();
    static std::atomic<std::uint64_t> counter {0U};
    const auto stamp = static_cast<unsigned long long>(
        std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count());
    TrackStemRequest request;
    request.trackIndices = {trackIndex};
    request.path = dir + "/" + fileSafe(project.tracks[trackIndex].name.empty() ? std::string("Track") : project.tracks[trackIndex].name) +
                   "_Rendered_" + std::to_string(stamp) + "_" + std::to_string(++counter) + ".wav";
    OfflineBounceOptions options;
    options.startSample = start;
    options.endSample = end;
    options.tailMode = BounceTailMode::Automatic;
    options.preRollSamples = static_cast<std::uint64_t>(project.sampleRate * 0.1);
    OfflineBounceFileOptions file;
    file.container = BounceContainer::Wav;
    file.sampleFormat = BounceSampleFormat::Float32;
    const auto results = StemBounce::renderTrackStems(project, engine, rack, options, file, {request});
    if (results.empty() || results.front().bounce.writtenFrames == 0U) throw std::runtime_error("render in place produced no audio");
    const auto& bounce = results.front().bounce;

    ProjectTrack rendered;
    rendered.name = project.tracks[trackIndex].name + " (Rendered)";
    rendered.audioPath = request.path;
    rendered.outputBus = -1;
    ProjectAudioClip clip;
    clip.id = 1U;
    clip.audioPath = request.path;
    clip.timelineStartSample = start;
    clip.lengthSamples = bounce.writtenFrames;
    clip.sourceFrames = bounce.writtenFrames;
    clip.sourceChannels = 2U;
    clip.sourceSampleRate = static_cast<std::uint32_t>(std::llround(project.sampleRate));
    rendered.clips.push_back(clip);
    if (muteSource) project.tracks[trackIndex].mute = true;
    TrackTools::insertTrack(project, trackIndex + 1U, std::move(rendered));
    return {trackIndex + 1U, request.path, bounce.peak};
}

} // namespace silveton
