// Silveton Tone Editor — the changes the user can make to tone blocks (cut, glue, move, snap, bend time),
// the time map, scale detection and the text form that goes into the project file.
#include "silveton/ToneEdit.h"
#include "internal/ToneInternal.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <locale>
#include <sstream>
#include <stdexcept>

namespace silveton {

using namespace toneinternal;

// ================================================================== ToneEdit ==
ToneBlock* ToneEdit::find(std::uint32_t id) noexcept {
    for (auto& b : blocks) if (b.id == id) return &b;
    return nullptr;
}
const ToneBlock* ToneEdit::find(std::uint32_t id) const noexcept {
    for (const auto& b : blocks) if (b.id == id) return &b;
    return nullptr;
}
bool ToneEdit::anyChange() const noexcept {
    for (const auto& b : blocks) if (!b.bypass && b.touched()) return true;
    for (const auto& w : warp) if (w.source != w.target) return true;
    return false;
}

// ================================================================== time map ==
ToneTimeMap::ToneTimeMap(const std::vector<ToneWarpPoint>& points, std::int64_t length) {
    std::vector<ToneWarpPoint> anchors;
    anchors.push_back({0, 0});
    for (const auto& p : points) {
        if (p.source <= anchors.back().source || p.target <= anchors.back().target) continue;
        if (p.source >= length || p.target >= length) continue;
        anchors.push_back(p);
    }
    anchors.push_back({length, length});
    identity_ = true;
    for (std::size_t i = 0U; i + 1U < anchors.size(); ++i) {
        Piece piece {static_cast<double>(anchors[i].source), static_cast<double>(anchors[i + 1U].source),
                     static_cast<double>(anchors[i].target), static_cast<double>(anchors[i + 1U].target)};
        if (piece.s1 <= piece.s0 || piece.t1 <= piece.t0) continue;
        if (anchors[i].source != anchors[i].target || anchors[i + 1U].source != anchors[i + 1U].target) identity_ = false;
        pieces_.push_back(piece);
    }
}

double ToneTimeMap::forward(double s) const noexcept {
    if (pieces_.empty() || s <= pieces_.front().s0) return s;
    if (s >= pieces_.back().s1) return s - pieces_.back().s1 + pieces_.back().t1;
    std::size_t lo = 0U, hi = pieces_.size() - 1U;
    while (lo < hi) {
        const std::size_t mid = (lo + hi + 1U) / 2U;
        if (pieces_[mid].s0 <= s) lo = mid; else hi = mid - 1U;
    }
    const Piece& p = pieces_[lo];
    return p.t0 + (s - p.s0) * (p.t1 - p.t0) / (p.s1 - p.s0);
}

double ToneTimeMap::inverse(double t) const noexcept {
    if (pieces_.empty() || t <= pieces_.front().t0) return t;
    if (t >= pieces_.back().t1) return t - pieces_.back().t1 + pieces_.back().s1;
    std::size_t lo = 0U, hi = pieces_.size() - 1U;
    while (lo < hi) {
        const std::size_t mid = (lo + hi + 1U) / 2U;
        if (pieces_[mid].t0 <= t) lo = mid; else hi = mid - 1U;
    }
    const Piece& p = pieces_[lo];
    return p.s0 + (t - p.t0) * (p.s1 - p.s0) / (p.t1 - p.t0);
}

// ============================================================ target pitches ==
double toneBlockTargetPitch(const ToneBlock& block, const ToneEdit& edit) noexcept {
    const double base = static_cast<double>(block.pitch) + static_cast<double>(block.moveCents) / 100.0;
    const double snapped = edit.snapToScale ? edit.scale.nearest(base) : std::floor(base + 0.5);
    return base + static_cast<double>(block.snap) * (snapped - base);
}

double toneFrameTargetPitch(const ToneBlock& block, const ToneEdit& edit, const ToneAnalysis& analysis, std::size_t frame) noexcept {
    const ToneFrames& f = analysis.frames;
    const double target = toneBlockTargetPitch(block, edit);
    double m = static_cast<double>(block.pitch);
    if (frame < f.size()) {
        if (f.hz[frame] > 0.0F) m = static_cast<double>(f.midi[frame]);
        else if (frame < f.rawHz.size() && f.rawHz[frame] > 0.0F) m = midiFromHz(static_cast<double>(f.rawHz[frame]));
    }
    const double drift = m - static_cast<double>(block.pitch);
    const double keep = (1.0 - static_cast<double>(block.flatten)) * static_cast<double>(block.vibrato);
    double tilt = 0.0;
    if (block.tiltCents != 0.0F && f.hop > 0U) {
        const double centre = 0.5 * static_cast<double>(block.start + block.end) / static_cast<double>(f.hop);
        const double half = std::max(1.0, 0.5 * static_cast<double>(block.end - block.start) / static_cast<double>(f.hop));
        tilt = static_cast<double>(block.tiltCents) / 100.0 * std::clamp((static_cast<double>(frame) - centre) / half, -1.0, 1.0);
    }
    return target + keep * drift + tilt;
}

// ================================================================ block edits ==
namespace {
std::int64_t minBlockLength(const ToneAnalysis& a) { return static_cast<std::int64_t>(std::max<std::size_t>(3U, 3U * a.frames.hop)); }

std::size_t indexOf(const ToneEdit& e, std::uint32_t id) {
    for (std::size_t i = 0U; i < e.blocks.size(); ++i) if (e.blocks[i].id == id) return i;
    return e.blocks.size();
}

template <class F>
void forBlocks(ToneEdit& edit, const std::vector<std::uint32_t>& ids, F&& f) {
    if (ids.empty()) { for (auto& b : edit.blocks) f(b); return; }
    for (const std::uint32_t id : ids) if (ToneBlock* b = edit.find(id)) f(*b);
}
} // namespace

std::uint32_t ToneEditing::split(ToneEdit& edit, const ToneAnalysis& analysis, std::uint32_t id, std::int64_t at) {
    const std::size_t i = indexOf(edit, id);
    if (i >= edit.blocks.size()) return 0U;
    const std::int64_t minLen = minBlockLength(analysis);
    ToneBlock left = edit.blocks[i];
    if (at < left.start + minLen || at > left.end - minLen) return 0U;
    ToneBlock right = left;
    right.id = edit.nextId++;
    right.start = at;
    left.end = at;
    refreshBlock(left, analysis, left.pitch);
    refreshBlock(right, analysis, right.pitch);
    edit.blocks[i] = left;
    edit.blocks.insert(edit.blocks.begin() + static_cast<std::ptrdiff_t>(i) + 1, right);
    return left.id;
}

std::uint32_t ToneEditing::glue(ToneEdit& edit, const ToneAnalysis& analysis, std::uint32_t firstId, std::uint32_t secondId) {
    const std::size_t i = indexOf(edit, firstId), j = indexOf(edit, secondId);
    if (i >= edit.blocks.size() || j >= edit.blocks.size() || j != i + 1U) return 0U;
    ToneBlock merged = edit.blocks[i];
    merged.end = edit.blocks[j].end;
    refreshBlock(merged, analysis, merged.pitch);
    edit.blocks[i] = merged;
    edit.blocks.erase(edit.blocks.begin() + static_cast<std::ptrdiff_t>(j));
    return merged.id;
}

bool ToneEditing::remove(ToneEdit& edit, std::uint32_t id) {
    const std::size_t i = indexOf(edit, id);
    if (i >= edit.blocks.size()) return false;
    edit.blocks.erase(edit.blocks.begin() + static_cast<std::ptrdiff_t>(i));
    return true;
}

std::uint32_t ToneEditing::add(ToneEdit& edit, const ToneAnalysis& analysis, std::int64_t start, std::int64_t end, double fallbackPitch) {
    start = std::max<std::int64_t>(0, start);
    end = std::min<std::int64_t>(analysis.length, end);
    std::int64_t lo = start, hi = end;
    for (const auto& b : edit.blocks) {
        if (b.end <= lo || b.start >= hi) continue;
        if (b.start <= lo) lo = b.end; else hi = b.start;
    }
    if (hi - lo < minBlockLength(analysis)) return 0U;
    ToneBlock block;
    block.id = edit.nextId++;
    block.start = lo;
    block.end = hi;
    block.pitch = static_cast<float>(fallbackPitch);
    refreshBlock(block, analysis, fallbackPitch);
    const auto it = std::find_if(edit.blocks.begin(), edit.blocks.end(), [&](const ToneBlock& b) { return b.start >= block.start; });
    edit.blocks.insert(it, block);
    return block.id;
}

bool ToneEditing::setEdges(ToneEdit& edit, const ToneAnalysis& analysis, std::uint32_t id, std::int64_t start, std::int64_t end) {
    const std::size_t i = indexOf(edit, id);
    if (i >= edit.blocks.size()) return false;
    const std::int64_t minLen = minBlockLength(analysis);
    const std::int64_t lo = i > 0U ? edit.blocks[i - 1U].end : 0;
    const std::int64_t hi = i + 1U < edit.blocks.size() ? edit.blocks[i + 1U].start : analysis.length;
    start = std::clamp(start, lo, hi - minLen);
    end = std::clamp(end, start + minLen, hi);
    if (end - start < minLen) return false;
    ToneBlock& b = edit.blocks[i];
    b.start = start;
    b.end = end;
    refreshBlock(b, analysis, b.pitch);
    return true;
}

bool ToneEditing::moveBorder(ToneEdit& edit, const ToneAnalysis& analysis, std::uint32_t leftId, std::uint32_t rightId, std::int64_t position) {
    const std::size_t i = indexOf(edit, leftId), j = indexOf(edit, rightId);
    if (i >= edit.blocks.size() || j != i + 1U) return false;
    if (edit.blocks[i].end != edit.blocks[j].start) return false;
    const std::int64_t minLen = minBlockLength(analysis);
    position = std::clamp(position, edit.blocks[i].start + minLen, edit.blocks[j].end - minLen);
    if (edit.blocks[i].start + minLen > edit.blocks[j].end - minLen) return false;
    edit.blocks[i].end = position;
    edit.blocks[j].start = position;
    refreshBlock(edit.blocks[i], analysis, edit.blocks[i].pitch);
    refreshBlock(edit.blocks[j], analysis, edit.blocks[j].pitch);
    return true;
}

void ToneEditing::resetBlock(ToneEdit& edit, std::uint32_t id) {
    if (ToneBlock* b = edit.find(id)) {
        b->moveCents = 0.0F; b->snap = 0.0F; b->flatten = 0.0F; b->vibrato = 1.0F;
        b->tiltCents = 0.0F; b->formantCents = 0.0F; b->gainDb = 0.0F; b->bypass = false;
    }
}

void ToneEditing::resetAll(ToneEdit& edit, const ToneAnalysis& analysis) {
    const ToneScale scale = edit.scale;
    const bool snapToScale = edit.snapToScale;
    const float transition = edit.transitionMs;
    edit = analysis.initial;
    edit.scale = scale;
    edit.snapToScale = snapToScale;
    edit.transitionMs = transition;
}

void ToneEditing::setSnap(ToneEdit& edit, const std::vector<std::uint32_t>& ids, float amount) {
    amount = std::clamp(amount, 0.0F, 1.0F);
    forBlocks(edit, ids, [&](ToneBlock& b) { b.snap = amount; });
}
void ToneEditing::setFlatten(ToneEdit& edit, const std::vector<std::uint32_t>& ids, float amount) {
    amount = std::clamp(amount, 0.0F, 1.0F);
    forBlocks(edit, ids, [&](ToneBlock& b) { b.flatten = amount; });
}
void ToneEditing::setVibrato(ToneEdit& edit, const std::vector<std::uint32_t>& ids, float amount) {
    amount = std::clamp(amount, 0.0F, 2.0F);
    forBlocks(edit, ids, [&](ToneBlock& b) { b.vibrato = amount; });
}

void ToneEditing::setTargetPitch(ToneEdit& edit, std::uint32_t id, double midi) {
    ToneBlock* b = edit.find(id);
    if (b == nullptr) return;
    b->moveCents = static_cast<float>((midi - static_cast<double>(b->pitch)) * 100.0);
    const double snapped = edit.snapToScale ? edit.scale.nearest(midi) : std::floor(midi + 0.5);
    if (std::abs(snapped - midi) > 1.0e-6) b->snap = 0.0F;
}

void ToneEditing::transpose(ToneEdit& edit, const std::vector<std::uint32_t>& ids, double semitones) {
    forBlocks(edit, ids, [&](ToneBlock& b) { b.moveCents += static_cast<float>(semitones * 100.0); });
}

// --------------------------------------------------------------------- time ---
bool ToneEditing::setBlockTime(ToneEdit& edit, std::uint32_t id, std::int64_t newStart, std::int64_t newEnd, std::int64_t total,
                               std::int64_t minLength) {
    const ToneBlock* block = edit.find(id);
    if (block == nullptr || total <= 0) return false;
    const std::int64_t s0 = block->start, s1 = block->end;
    constexpr std::int64_t kGap = 32;
    minLength = std::max<std::int64_t>(minLength, kGap);
    ToneWarpPoint prev {0, 0}, next {total, total};
    for (const auto& w : edit.warp) {
        if (w.source < s0) prev = w;
        else if (w.source > s1 && next.source == total && next.target == total) { next = w; break; }
    }
    const std::int64_t lo = prev.target + kGap, hi = next.target - kGap;
    if (s0 <= 0) newStart = 0;
    if (s1 >= total) newEnd = total;
    newStart = std::max(newStart, lo);
    newEnd = std::min(newEnd, hi);
    if (newEnd - newStart < minLength) {
        newEnd = newStart + minLength;
        if (newEnd > hi) { newEnd = hi; newStart = newEnd - minLength; }
        if (newStart < lo) return false;
    }
    std::vector<ToneWarpPoint> points;
    for (const auto& w : edit.warp) if (w.source < s0 || w.source > s1) points.push_back(w);
    if (s0 > 0) points.push_back({s0, newStart});
    if (s1 < total) points.push_back({s1, newEnd});
    std::sort(points.begin(), points.end(), [](const ToneWarpPoint& a, const ToneWarpPoint& b) { return a.source < b.source; });
    edit.warp = points;
    return true;
}

bool ToneEditing::movePoint(ToneEdit& edit, std::int64_t source, std::int64_t newTarget, std::int64_t total, std::int64_t minGap) {
    if (total <= 0 || source <= 0 || source >= total) return false;
    minGap = std::max<std::int64_t>(minGap, 8);
    std::size_t existing = edit.warp.size();
    for (std::size_t i = 0U; i < edit.warp.size(); ++i)
        if (std::llabs(edit.warp[i].source - source) <= 2) { existing = i; break; }
    ToneWarpPoint prev {0, 0}, next {total, total};
    for (std::size_t i = 0U; i < edit.warp.size(); ++i) {
        if (i == existing) continue;
        if (edit.warp[i].source < source) prev = edit.warp[i];
        else if (next.source == total && next.target == total) next = edit.warp[i];
    }
    newTarget = std::clamp(newTarget, prev.target + minGap, next.target - minGap);
    if (newTarget <= prev.target || newTarget >= next.target) return false;
    if (existing < edit.warp.size()) edit.warp[existing].target = newTarget;
    else {
        edit.warp.push_back({source, newTarget});
        std::sort(edit.warp.begin(), edit.warp.end(), [](const ToneWarpPoint& a, const ToneWarpPoint& b) { return a.source < b.source; });
    }
    return true;
}

bool ToneEditing::removeWarpPoint(ToneEdit& edit, std::size_t index) {
    if (index >= edit.warp.size()) return false;
    edit.warp.erase(edit.warp.begin() + static_cast<std::ptrdiff_t>(index));
    return true;
}

void ToneEditing::snapTiming(ToneEdit& edit, const std::vector<std::uint32_t>& ids, double gridSamples, double phaseSamples, float amount,
                             std::int64_t totalLength, std::int64_t minLength) {
    if (gridSamples < 1.0) return;
    amount = std::clamp(amount, 0.0F, 1.0F);
    std::vector<std::uint32_t> order;
    for (const auto& b : edit.blocks)
        if (ids.empty() || std::find(ids.begin(), ids.end(), b.id) != ids.end()) order.push_back(b.id);
    for (const std::uint32_t id : order) {
        const ToneBlock* b = edit.find(id);
        if (b == nullptr) continue;
        const ToneTimeMap map(edit.warp, totalLength);
        const double curStart = map.forward(static_cast<double>(b->start));
        const double curEnd = map.forward(static_cast<double>(b->end));
        const double line = std::floor((curStart - phaseSamples) / gridSamples + 0.5) * gridSamples + phaseSamples;
        const double start = curStart + static_cast<double>(amount) * (line - curStart);
        const auto ns = static_cast<std::int64_t>(std::llround(start));
        const auto ne = static_cast<std::int64_t>(std::llround(start + (curEnd - curStart)));
        (void)setBlockTime(edit, id, ns, ne, totalLength, minLength);
    }
}

void ToneEditing::clearTiming(ToneEdit& edit) { edit.warp.clear(); }

// ------------------------------------------------------------------- scales ---
ToneScale ToneEditing::detectScale(const ToneEdit& edit, double* coveragePercent) {
    double weight[12] = {};
    double total = 0.0;
    for (const auto& b : edit.blocks) {
        const int pc = ((static_cast<int>(std::floor(static_cast<double>(b.pitch) + 0.5)) % 12) + 12) % 12;
        const double w = static_cast<double>(std::max<std::int64_t>(1, b.end - b.start));
        weight[pc] += w;
        total += w;
    }
    ToneScale best;
    double bestScore = -1.0, bestCoverage = 0.0;
    if (total <= 0.0) { if (coveragePercent != nullptr) *coveragePercent = 0.0; return best; }
    for (const ToneScaleKind kind : {ToneScaleKind::Major, ToneScaleKind::NaturalMinor}) {
        for (int root = 0; root < 12; ++root) {
            ToneScale s;
            s.kind = kind;
            s.root = root;
            double covered = 0.0;
            for (int pc = 0; pc < 12; ++pc) if (s.contains(pc)) covered += weight[pc];
            const double coverage = covered / total;
            const double score = coverage + 0.06 * weight[root] / total + 0.03 * weight[(root + 7) % 12] / total;
            if (score > bestScore) { bestScore = score; best = s; bestCoverage = coverage; }
        }
    }
    if (coveragePercent != nullptr) *coveragePercent = 100.0 * bestCoverage;
    return best;
}

// =================================================================== saving ==
std::vector<std::string> toneEditToLines(const ToneEdit& edit) {
    std::vector<std::string> lines;
    const auto stream = []() { std::ostringstream o; o.imbue(std::locale::classic()); o << std::setprecision(9); return o; };
    {
        auto o = stream();
        o << "TONE\t" << (edit.snapToScale ? 1 : 0) << '\t' << static_cast<int>(edit.scale.kind) << '\t' << edit.scale.root << '\t'
          << edit.transitionMs << '\t' << edit.nextId;
        lines.push_back(o.str());
    }
    for (const auto& b : edit.blocks) {
        auto o = stream();
        o << "BLOCK\t" << b.id << '\t' << b.start << '\t' << b.end << '\t' << b.pitch << '\t' << b.levelDb << '\t' << b.moveCents << '\t'
          << b.snap << '\t' << b.flatten << '\t' << b.vibrato << '\t' << b.tiltCents << '\t' << b.formantCents << '\t' << b.gainDb << '\t'
          << (b.bypass ? 1 : 0);
        lines.push_back(o.str());
    }
    for (const auto& w : edit.warp) {
        auto o = stream();
        o << "WARP\t" << w.source << '\t' << w.target;
        lines.push_back(o.str());
    }
    return lines;
}

ToneEdit toneEditFromLines(const std::vector<std::string>& lines) {
    ToneEdit edit;
    bool header = false;
    for (const std::string& line : lines) {
        std::istringstream in(line);
        in.imbue(std::locale::classic());
        std::string tag;
        std::getline(in, tag, '\t');
        if (tag == "TONE") {
            int snap = 0, kind = 0;
            if (!(in >> snap >> kind >> edit.scale.root >> edit.transitionMs >> edit.nextId)) throw std::runtime_error("tone edit: bad header");
            if (kind < 0 || kind >= static_cast<int>(ToneScaleKind::Count) || edit.scale.root < 0 || edit.scale.root > 11)
                throw std::runtime_error("tone edit: bad scale");
            edit.snapToScale = snap != 0;
            edit.scale.kind = static_cast<ToneScaleKind>(kind);
            header = true;
        } else if (tag == "BLOCK") {
            ToneBlock b;
            int bypass = 0;
            if (!(in >> b.id >> b.start >> b.end >> b.pitch >> b.levelDb >> b.moveCents >> b.snap >> b.flatten >> b.vibrato >> b.tiltCents >>
                  b.formantCents >> b.gainDb >> bypass))
                throw std::runtime_error("tone edit: bad block");
            if (b.end <= b.start || b.start < 0 || !std::isfinite(b.pitch)) throw std::runtime_error("tone edit: block range");
            b.bypass = bypass != 0;
            if (!edit.blocks.empty() && b.start < edit.blocks.back().end) throw std::runtime_error("tone edit: blocks overlap");
            edit.blocks.push_back(b);
        } else if (tag == "WARP") {
            ToneWarpPoint w;
            if (!(in >> w.source >> w.target)) throw std::runtime_error("tone edit: bad warp point");
            edit.warp.push_back(w);
        }
    }
    if (!header) throw std::runtime_error("tone edit: missing header");
    return edit;
}

} // namespace silveton
