#include "silveton/AutomationRuntime.h"
#include <cmath>

namespace silveton {
void AutomationLane::add(std::int64_t sample, float value) {
    if (!std::isfinite(value)) throw std::invalid_argument("automation value must be finite");
    auto it = std::lower_bound(points_.begin(), points_.end(), sample,
                               [](const auto& p, std::int64_t s) { return p.sample < s; });
    if (it != points_.end() && it->sample == sample) {
        it->value = value;
        return;
    }
    points_.insert(it, {sample, value});
}

bool AutomationLane::removeAt(std::int64_t sample) noexcept {
    const auto it = std::lower_bound(points_.begin(), points_.end(), sample,
        [](const AutomationPoint& point, std::int64_t target) { return point.sample < target; });
    if (it == points_.end() || it->sample != sample) return false;
    points_.erase(it);
    return true;
}

bool AutomationLane::movePoint(std::int64_t oldSample, std::int64_t newSample, float newValue) {
    if (newSample < 0 || !std::isfinite(newValue)) throw std::invalid_argument("invalid automation point");
    const auto it = std::lower_bound(points_.begin(), points_.end(), oldSample,
        [](const AutomationPoint& point, std::int64_t target) { return point.sample < target; });
    if (it == points_.end() || it->sample != oldSample) return false;
    points_.erase(it);
    add(newSample, newValue);
    return true;
}

void AutomationLane::replacePoints(std::vector<AutomationPoint> points) {
    for (const auto& point : points)
        if (point.sample < 0 || !std::isfinite(point.value)) throw std::invalid_argument("invalid automation point");
    std::sort(points.begin(), points.end(), [](const auto& a, const auto& b) { return a.sample < b.sample; });
    for (std::size_t i = 1U; i < points.size(); ++i)
        if (points[i - 1U].sample == points[i].sample) throw std::invalid_argument("duplicate automation point");
    points_.swap(points);
}

float AutomationLane::valueAt(std::int64_t sample, float fallback) const noexcept {
    if (points_.empty()) return fallback;
    if (sample <= points_.front().sample) return points_.front().value;
    if (sample >= points_.back().sample) return points_.back().value;
    auto it = std::upper_bound(points_.begin(), points_.end(), sample,
                               [](std::int64_t s, const auto& p) { return s < p.sample; });
    const auto& a = *(it - 1);
    const auto& b = *it;
    const double t = static_cast<double>(sample - a.sample) / static_cast<double>(b.sample - a.sample);
    return static_cast<float>(static_cast<double>(a.value) +
                              (static_cast<double>(b.value) - static_cast<double>(a.value)) * t);
}

float AutomationLane::stepValueAt(std::int64_t sample, float fallback) const noexcept {
    if (points_.empty() || sample < points_.front().sample) return fallback;
    auto it = std::upper_bound(points_.begin(), points_.end(), sample,
                               [](std::int64_t s, const auto& p) { return s < p.sample; });
    if (it == points_.begin()) return fallback;
    return (it - 1)->value;
}

void ParameterAutomationLane::write(std::int64_t sample, double normalized) {
    if (!std::isfinite(normalized) || normalized < 0.0 || normalized > 1.0)
        throw std::invalid_argument("automation normalized value must be in [0,1]");
    auto it = std::lower_bound(points_.begin(), points_.end(), sample,
                               [](const auto& p, std::int64_t s) { return p.sample < s; });
    if (it != points_.end() && it->sample == sample) {
        it->normalized = normalized;
        return;
    }
    points_.insert(it, {sample, normalized});
}

bool ParameterAutomationLane::removeAt(std::int64_t sample) noexcept {
    const auto it = std::lower_bound(points_.begin(), points_.end(), sample,
        [](const ParameterAutomationPoint& point, std::int64_t target) { return point.sample < target; });
    if (it == points_.end() || it->sample != sample) return false;
    points_.erase(it);
    return true;
}

bool ParameterAutomationLane::movePoint(std::int64_t oldSample, std::int64_t newSample, double normalized) {
    if (newSample < 0 || !std::isfinite(normalized) || normalized < 0.0 || normalized > 1.0)
        throw std::invalid_argument("invalid parameter automation point");
    const auto it = std::lower_bound(points_.begin(), points_.end(), oldSample,
        [](const ParameterAutomationPoint& point, std::int64_t target) { return point.sample < target; });
    if (it == points_.end() || it->sample != oldSample) return false;
    points_.erase(it);
    write(newSample, normalized);
    return true;
}

void ParameterAutomationLane::replacePoints(std::vector<ParameterAutomationPoint> points) {
    for (const auto& point : points)
        if (point.sample < 0 || !std::isfinite(point.normalized) || point.normalized < 0.0 || point.normalized > 1.0)
            throw std::invalid_argument("invalid parameter automation point");
    std::sort(points.begin(), points.end(), [](const auto& a, const auto& b) { return a.sample < b.sample; });
    for (std::size_t i = 1U; i < points.size(); ++i)
        if (points[i - 1U].sample == points[i].sample) throw std::invalid_argument("duplicate parameter automation point");
    points_.swap(points);
}

double ParameterAutomationLane::valueAt(std::int64_t sample, double fallback) const noexcept {
    if (points_.empty()) return fallback;
    if (sample <= points_.front().sample) return points_.front().normalized;
    if (sample >= points_.back().sample) return points_.back().normalized;
    auto it = std::upper_bound(points_.begin(), points_.end(), sample,
                               [](std::int64_t s, const auto& p) { return s < p.sample; });
    const auto& a = *(it - 1);
    const auto& b = *it;
    const double t = static_cast<double>(sample - a.sample) / static_cast<double>(b.sample - a.sample);
    return a.normalized + (b.normalized - a.normalized) * t;
}

void AutomationWriter::setMode(AutomationMode mode) noexcept {
    mode_ = mode;
    if (mode_ != AutomationMode::Touch && mode_ != AutomationMode::Latch) gestureActive_ = false;
    if (mode_ != AutomationMode::Latch) latchActive_ = false;
}

void AutomationWriter::apply(const AutomationGesture& event, ParameterAutomationLane& lane) {
    switch (event.type) {
        case AutomationGestureType::Begin:
            gestureActive_ = true;
            if (mode_ == AutomationMode::Latch) latchActive_ = true;
            return;
        case AutomationGestureType::End:
            gestureActive_ = false;
            if (mode_ != AutomationMode::Latch) latchActive_ = false;
            return;
        case AutomationGestureType::Value:
            break;
    }

    const bool shouldWrite = mode_ == AutomationMode::Write ||
                             (mode_ == AutomationMode::Touch && gestureActive_) ||
                             (mode_ == AutomationMode::Latch && (gestureActive_ || latchActive_));
    if (shouldWrite) lane.write(event.sample, event.normalized);
}

void AutomationWriter::apply(AutomationGestureType type,
                             std::int64_t sample,
                             float value,
                             AutomationLane& lane) {
    if (!std::isfinite(value)) throw std::invalid_argument("automation value must be finite");
    if (type == AutomationGestureType::Begin) {
        gestureActive_ = true;
        if (mode_ == AutomationMode::Latch) latchActive_ = true;
        return;
    }
    if (type == AutomationGestureType::End) {
        gestureActive_ = false;
        if (mode_ != AutomationMode::Latch) latchActive_ = false;
        return;
    }
    const bool shouldWrite = mode_ == AutomationMode::Write ||
                             (mode_ == AutomationMode::Touch && gestureActive_) ||
                             (mode_ == AutomationMode::Latch && (gestureActive_ || latchActive_));
    if (shouldWrite) lane.add(sample, value);
}

} // namespace silveton
