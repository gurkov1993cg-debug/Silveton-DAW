#include "silveton/AutomationRuntime.h"
#include <cmath>

namespace silveton {
void AutomationLane::add(std::int64_t sample, float value) {
    if (!std::isfinite(value)) throw std::invalid_argument("automation value must be finite");
    auto it = std::lower_bound(points_.begin(), points_.end(), sample,
                               [](const auto& p, std::int64_t s) { return p.sample < s; });
    if (it != points_.end() && it->sample == sample) {
        it->value = value;
        return;
    }
    points_.insert(it, {sample, value});
}

float AutomationLane::valueAt(std::int64_t sample, float fallback) const noexcept {
    if (points_.empty()) return fallback;
    if (sample <= points_.front().sample) return points_.front().value;
    if (sample >= points_.back().sample) return points_.back().value;
    auto it = std::upper_bound(points_.begin(), points_.end(), sample,
                               [](std::int64_t s, const auto& p) { return s < p.sample; });
    const auto& a = *(it - 1);
    const auto& b = *it;
    const double t = static_cast<double>(sample - a.sample) / static_cast<double>(b.sample - a.sample);
    return static_cast<float>(static_cast<double>(a.value) +
                              (static_cast<double>(b.value) - static_cast<double>(a.value)) * t);
}

float AutomationLane::stepValueAt(std::int64_t sample, float fallback) const noexcept {
    if (points_.empty() || sample < points_.front().sample) return fallback;
    auto it = std::upper_bound(points_.begin(), points_.end(), sample,
                               [](std::int64_t s, const auto& p) { return s < p.sample; });
    if (it == points_.begin()) return fallback;
    return (it - 1)->value;
}

void ParameterAutomationLane::write(std::int64_t sample, double normalized) {
    if (!std::isfinite(normalized) || normalized < 0.0 || normalized > 1.0)
        throw std::invalid_argument("automation normalized value must be in [0,1]");
    auto it = std::lower_bound(points_.begin(), points_.end(), sample,
                               [](const auto& p, std::int64_t s) { return p.sample < s; });
    if (it != points_.end() && it->sample == sample) {
        it->normalized = normalized;
        return;
    }
    points_.insert(it, {sample, normalized});
}

double ParameterAutomationLane::valueAt(std::int64_t sample, double fallback) const noexcept {
    if (points_.empty()) return fallback;
    if (sample <= points_.front().sample) return points_.front().normalized;
    if (sample >= points_.back().sample) return points_.back().normalized;
    auto it = std::upper_bound(points_.begin(), points_.end(), sample,
                               [](std::int64_t s, const auto& p) { return s < p.sample; });
    const auto& a = *(it - 1);
    const auto& b = *it;
    const double t = static_cast<double>(sample - a.sample) / static_cast<double>(b.sample - a.sample);
    return a.normalized + (b.normalized - a.normalized) * t;
}

void AutomationWriter::setMode(AutomationMode mode) noexcept {
    mode_ = mode;
    if (mode_ != AutomationMode::Touch && mode_ != AutomationMode::Latch) gestureActive_ = false;
    if (mode_ != AutomationMode::Latch) latchActive_ = false;
}

void AutomationWriter::apply(const AutomationGesture& event, ParameterAutomationLane& lane) {
    switch (event.type) {
        case AutomationGestureType::Begin:
            gestureActive_ = true;
            if (mode_ == AutomationMode::Latch) latchActive_ = true;
            return;
        case AutomationGestureType::End:
            gestureActive_ = false;
            if (mode_ != AutomationMode::Latch) latchActive_ = false;
            return;
        case AutomationGestureType::Value:
            break;
    }

    const bool shouldWrite = mode_ == AutomationMode::Write ||
                             (mode_ == AutomationMode::Touch && gestureActive_) ||
                             (mode_ == AutomationMode::Latch && (gestureActive_ || latchActive_));
    if (shouldWrite) lane.write(event.sample, event.normalized);
}

void AutomationWriter::apply(AutomationGestureType type,
                             std::int64_t sample,
                             float value,
                             AutomationLane& lane) {
    if (!std::isfinite(value)) throw std::invalid_argument("automation value must be finite");
    if (type == AutomationGestureType::Begin) {
        gestureActive_ = true;
        if (mode_ == AutomationMode::Latch) latchActive_ = true;
        return;
    }
    if (type == AutomationGestureType::End) {
        gestureActive_ = false;
        if (mode_ != AutomationMode::Latch) latchActive_ = false;
        return;
    }
    const bool shouldWrite = mode_ == AutomationMode::Write ||
                             (mode_ == AutomationMode::Touch && gestureActive_) ||
                             (mode_ == AutomationMode::Latch && (gestureActive_ || latchActive_));
    if (shouldWrite) lane.add(sample, value);
}

} // namespace silveton
