#include "silveton/AudioDevice.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace silveton {

ManualAudioDevice::ManualAudioDevice(AudioDeviceConfig config) : config_(config) {
    if (!std::isfinite(config_.sampleRate) || config_.sampleRate <= 0.0) throw std::invalid_argument("invalid device sample rate");
    if (config_.blockSize == 0U) throw std::invalid_argument("invalid device block size");
    if (config_.outputChannels == 0U) throw std::invalid_argument("device needs output channels");

    inputs_.assign(config_.inputChannels, std::vector<float>(config_.blockSize, 0.0F));
    outputs_.assign(config_.outputChannels, std::vector<float>(config_.blockSize, 0.0F));
    inputPtrs_.resize(config_.inputChannels);
    outputPtrs_.resize(config_.outputChannels);

    for (std::size_t c = 0; c < inputs_.size(); ++c) inputPtrs_[c] = inputs_[c].data();
    for (std::size_t c = 0; c < outputs_.size(); ++c) outputPtrs_[c] = outputs_[c].data();
}

float* ManualAudioDevice::inputChannelData(std::size_t channel) {
    if (channel >= inputs_.size()) throw std::out_of_range("input channel");
    return inputs_[channel].data();
}

void ManualAudioDevice::start(IAudioDeviceCallback& callback) {
    if (callback_ != nullptr) throw std::logic_error("audio device already running");
    callback_ = &callback;
}

void ManualAudioDevice::stop() noexcept { callback_ = nullptr; }

void ManualAudioDevice::pump() {
    if (callback_ == nullptr) throw std::logic_error("audio device is not running");
    for (auto& channel : outputs_) std::fill(channel.begin(), channel.end(), 0.0F);
    AudioDeviceTimeInfo time;
    time.sampleTime = sampleTime_;
    time.sampleTimeValid = true;
    callback_->updateDeviceTime(time);
    callback_->processAudio(inputPtrs_.empty() ? nullptr : inputPtrs_.data(),
                            outputPtrs_.data(),
                            config_.inputChannels,
                            config_.outputChannels,
                            config_.blockSize);
    sampleTime_ += static_cast<double>(config_.blockSize);
}

} // namespace silveton
