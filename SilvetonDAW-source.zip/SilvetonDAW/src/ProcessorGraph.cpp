#include "silveton/ProcessorGraph.h"
#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <cmath>
#include <cstring>
#include <limits>
#include <mutex>
#include <queue>
#include <thread>
#include <utility>

namespace silveton {
namespace {
constexpr std::size_t kMaxGraphNodes = 1024U;
constexpr std::size_t kMaxProcessorsPerNode = 32U;
constexpr std::size_t kMaxExtraOutputBuses = 31U;
constexpr std::size_t kMaxRoutedBuses = 32U;

struct StereoDelayLine {
    std::vector<float> left;
    std::vector<float> right;
    std::size_t writeIndex {0U};
    std::uint32_t delaySamples {0U};

    void prepare(std::uint32_t maxDelay, std::uint32_t maxFrames) {
        const std::size_t size = static_cast<std::size_t>(maxDelay) + static_cast<std::size_t>(maxFrames) + 1U;
        left.assign(std::max<std::size_t>(size, 1U), 0.0F);
        right.assign(std::max<std::size_t>(size, 1U), 0.0F);
        writeIndex = 0U;
    }

    void setDelay(std::uint32_t delay) {
        if (delay >= left.size()) throw std::length_error("processor graph delay exceeds prepared capacity");
        delaySamples = delay;
    }

    void reset() noexcept {
        std::fill(left.begin(), left.end(), 0.0F);
        std::fill(right.begin(), right.end(), 0.0F);
        writeIndex = 0U;
    }

    void add(const float* inL,
             const float* inR,
             float* outL,
             float* outR,
             std::uint32_t frames,
             float gain = 1.0F) noexcept {
        if (inL == nullptr || inR == nullptr) return;
        if (delaySamples == 0U) {
            for (std::uint32_t i = 0U; i < frames; ++i) {
                outL[i] += inL[i] * gain;
                outR[i] += inR[i] * gain;
            }
            return;
        }
        const std::size_t size = left.size();
        for (std::uint32_t i = 0U; i < frames; ++i) {
            left[writeIndex] = inL[i];
            right[writeIndex] = inR[i];
            const std::size_t readIndex = (writeIndex + size - delaySamples) % size;
            outL[i] += left[readIndex] * gain;
            outR[i] += right[readIndex] * gain;
            writeIndex = (writeIndex + 1U) % size;
        }
    }

    void addRoute(const float* inL,
                  const float* inR,
                  float* outL,
                  float* outR,
                  std::uint32_t frames,
                  const MainRouteDefinition& route,
                  std::int64_t projectSample) noexcept {
        if (inL == nullptr || inR == nullptr) return;
        const bool dynamic = route.gainAutomationDb != nullptr || route.enabledAutomation != nullptr;
        if (!dynamic) {
            if (route.enabledFallback) add(inL, inR, outL, outR, frames, route.gain);
            return;
        }

        const std::size_t size = left.size();
        for (std::uint32_t i = 0U; i < frames; ++i) {
            float sampleL = inL[i];
            float sampleR = inR[i];
            if (delaySamples != 0U) {
                left[writeIndex] = sampleL;
                right[writeIndex] = sampleR;
                const std::size_t readIndex = (writeIndex + size - delaySamples) % size;
                sampleL = left[readIndex];
                sampleR = right[readIndex];
                writeIndex = (writeIndex + 1U) % size;
            }
            const std::int64_t absoluteSample = projectSample + static_cast<std::int64_t>(i);
            const bool enabled = route.enabledAutomation == nullptr
                ? route.enabledFallback
                : route.enabledAutomation->stepValueAt(absoluteSample, route.enabledFallback ? 1.0F : 0.0F) >= 0.5F;
            if (!enabled) continue;
            float gain = route.gain;
            if (route.gainAutomationDb != nullptr) {
                const float db = route.gainAutomationDb->valueAt(absoluteSample, route.gainAutomationFallbackDb);
                gain *= static_cast<float>(MixMath::dbToLinear(static_cast<double>(db)));
            }
            outL[i] += sampleL * gain;
            outR[i] += sampleR * gain;
        }
    }

    void copy(const float* inL,
              const float* inR,
              float* outL,
              float* outR,
              std::uint32_t frames) noexcept {
        std::fill_n(outL, frames, 0.0F);
        std::fill_n(outR, frames, 0.0F);
        add(inL, inR, outL, outR, frames, 1.0F);
    }
};

struct RouteRuntime {
    MainRouteDefinition definition;
    std::uint32_t delay {0U};
    StereoDelayLine delayLine;
};

struct ExtraRouteRuntime {
    std::size_t ownerNode {0U};
    std::size_t processorIndex {0U};
    std::size_t outputBusIndex {1U};
    std::size_t destinationNode {0U};
    std::uint32_t sourceLatency {0U};
    std::uint32_t delay {0U};
    StereoDelayLine delayLine;
};

struct ProcessorRuntime {
    ITrackProcessor* processor {nullptr};
    IRoutedTrackProcessor* routed {nullptr};
    ProcessorRouting routing;
    std::uint32_t mainAlignmentDelay {0U};
    std::uint32_t sidechainAlignmentDelay {0U};
    std::uint32_t outputLatency {0U};
    StereoDelayLine mainDelay;
    StereoDelayLine sidechainDelay;
    std::vector<float> sideL;
    std::vector<float> sideR;
    std::vector<std::vector<float>> extraL;
    std::vector<std::vector<float>> extraR;
};

struct NodeRuntime {
    GraphNodeDefinition definition;
    std::vector<ProcessorRuntime> processors;
    std::uint32_t inputLatency {0U};
    std::uint32_t outputLatency {0U};
    std::uint32_t localSourceDelay {0U};
    StereoDelayLine sourceDelay;
    std::vector<float> aL;
    std::vector<float> aR;
    std::vector<float> bL;
    std::vector<float> bR;
    std::vector<float> postL;
    std::vector<float> postR;
    float* currentL {nullptr};
    float* currentR {nullptr};
    const float* preFaderL {nullptr};
    const float* preFaderR {nullptr};
    const float* postFaderL {nullptr};
    const float* postFaderR {nullptr};
};

struct IncomingRef {
    enum class Kind { Main, Extra } kind {Kind::Main};
    std::size_t index {0U};
    std::uint32_t latency {0U};
};
}

class ProcessorGraph::Impl {
public:
    ~Impl() { stopWorkerThreads(); }
    std::vector<NodeRuntime> nodes;
    std::vector<RouteRuntime> mainRoutes;
    std::vector<ExtraRouteRuntime> extraRoutes;
    std::vector<std::size_t> topoOrder;
    std::vector<std::vector<std::size_t>> executionLayers;
    std::vector<std::thread> workers;
    std::uint32_t workerLimit {4U};
    std::mutex workerSleepMutex;
    std::condition_variable workerCv;
    std::atomic<bool> stopWorkers {false};
    std::atomic<std::size_t> workersReady {0U};
    std::atomic<std::uint64_t> workGeneration {0U};
    std::atomic<std::size_t> nextWorkIndex {0U};
    std::atomic<std::size_t> remainingWork {0U};
    // High bit = audio thread is publishing a new work descriptor. Low bits =
    // helper threads briefly reading/claiming from the current descriptor.
    std::atomic<std::uint32_t> workClaimState {0U};
    const std::vector<std::size_t>* activeLayer {nullptr};
    const ConstStereoBus* workSources {nullptr};
    std::size_t workSourceCount {0U};
    std::uint32_t workFrames {0U};
    ProcessorContext workContext {};
    const std::uint8_t* workNodeEnabled {nullptr};
    std::size_t workNodeEnabledCount {0U};
    std::size_t masterNode {0U};
    double sampleRate {0.0};
    std::uint32_t maxFrames {0U};
    std::uint32_t maxCompensation {0U};
    bool isPrepared {false};

    void validateDefinitions(const std::vector<GraphNodeDefinition>& defs,
                             const std::vector<MainRouteDefinition>& routes,
                             std::size_t master) const {
        if (defs.empty() || defs.size() > kMaxGraphNodes) throw std::invalid_argument("invalid processor graph node count");
        if (master >= defs.size()) throw std::out_of_range("processor graph master node");
        for (const auto& route : routes) {
            if (route.from >= defs.size() || route.to >= defs.size() || route.from == route.to)
                throw std::invalid_argument("invalid main processor route");
            if (!std::isfinite(route.gain)) throw std::invalid_argument("invalid route gain");
        }
        for (std::size_t node = 0U; node < defs.size(); ++node) {
            const auto& mix = defs[node].mix;
            if (!std::isfinite(mix.gainDb) || !std::isfinite(mix.pan) ||
                !std::isfinite(mix.stereoLeftPan) || !std::isfinite(mix.stereoRightPan))
                throw std::invalid_argument("invalid graph node mix control");
            if (defs[node].processors.size() > kMaxProcessorsPerNode)
                throw std::length_error("too many processors on graph node");
            for (const auto& slot : defs[node].processors) {
                if (slot.processor == nullptr) throw std::invalid_argument("null processor slot");
                const auto* routed = dynamic_cast<IRoutedTrackProcessor*>(slot.processor);
                const bool hasRouting = slot.routing.sidechainSourceNode >= 0 || !slot.routing.extraOutputDestinations.empty();
                if (hasRouting && routed == nullptr)
                    throw std::invalid_argument("routing metadata requires IRoutedTrackProcessor");
                if (slot.routing.sidechainSourceNode >= static_cast<int>(defs.size()))
                    throw std::out_of_range("sidechain source node");
                if (slot.routing.sidechainSourceNode == static_cast<int>(node))
                    throw std::logic_error("routing cycle");
                if (slot.routing.extraOutputDestinations.size() > kMaxExtraOutputBuses)
                    throw std::length_error("too many extra processor outputs");
                for (const int dest : slot.routing.extraOutputDestinations) {
                    if (dest < -1 || dest >= static_cast<int>(defs.size()))
                        throw std::out_of_range("extra output destination node");
                    if (dest == static_cast<int>(node)) throw std::logic_error("routing cycle");
                }
                if (routed != nullptr) {
                    // VST3 instruments are allowed to be generators with zero audio inputs.
                    // A routed processor must always expose at least one audio output bus,
                    // but an input bus is not required.
                    if (routed->outputBusCount() == 0U)
                        throw std::invalid_argument("routed processor requires at least one output bus");
                    if (routed->inputBusCount() > kMaxRoutedBuses || routed->outputBusCount() > kMaxRoutedBuses)
                        throw std::length_error("routed processor bus count exceeds realtime graph limit");
                    if (slot.routing.sidechainSourceNode >= 0 && routed->inputBusCount() < 2U)
                        throw std::invalid_argument("processor has no sidechain input bus");
                    if (slot.routing.extraOutputDestinations.size() + 1U > routed->outputBusCount())
                        throw std::invalid_argument("processor has fewer output buses than routed destinations");
                }
            }
        }
    }

    std::vector<std::size_t> buildTopologicalOrder(const std::vector<GraphNodeDefinition>& defs,
                                                    const std::vector<MainRouteDefinition>& routes) const {
        std::vector<std::vector<std::size_t>> edges(defs.size());
        std::vector<std::size_t> indegree(defs.size(), 0U);
        const auto addEdge = [&](std::size_t from, std::size_t to) {
            auto& v = edges[from];
            if (std::find(v.begin(), v.end(), to) != v.end()) return;
            v.push_back(to);
            ++indegree[to];
        };
        for (const auto& r : routes) addEdge(r.from, r.to);
        for (std::size_t owner = 0U; owner < defs.size(); ++owner) {
            for (const auto& slot : defs[owner].processors) {
                if (slot.routing.sidechainSourceNode >= 0)
                    addEdge(static_cast<std::size_t>(slot.routing.sidechainSourceNode), owner);
                for (const int dest : slot.routing.extraOutputDestinations)
                    if (dest >= 0) addEdge(owner, static_cast<std::size_t>(dest));
            }
        }
        std::queue<std::size_t> q;
        for (std::size_t i = 0U; i < indegree.size(); ++i) if (indegree[i] == 0U) q.push(i);
        std::vector<std::size_t> order;
        order.reserve(defs.size());
        while (!q.empty()) {
            const auto n = q.front(); q.pop();
            order.push_back(n);
            for (const auto dest : edges[n]) if (--indegree[dest] == 0U) q.push(dest);
        }
        if (order.size() != defs.size()) throw std::logic_error("routing cycle");
        return order;
    }

    std::vector<std::vector<std::size_t>> buildExecutionLayers(
        const std::vector<GraphNodeDefinition>& defs,
        const std::vector<MainRouteDefinition>& routes) const {
        std::vector<std::vector<std::size_t>> edges(defs.size());
        std::vector<std::size_t> indegree(defs.size(), 0U);
        const auto addEdge = [&](std::size_t from, std::size_t to) {
            auto& v = edges[from];
            if (std::find(v.begin(), v.end(), to) != v.end()) return;
            v.push_back(to);
            ++indegree[to];
        };
        for (const auto& r : routes) addEdge(r.from, r.to);
        for (std::size_t owner = 0U; owner < defs.size(); ++owner) {
            for (const auto& slot : defs[owner].processors) {
                if (slot.routing.sidechainSourceNode >= 0)
                    addEdge(static_cast<std::size_t>(slot.routing.sidechainSourceNode), owner);
                for (const int dest : slot.routing.extraOutputDestinations)
                    if (dest >= 0) addEdge(owner, static_cast<std::size_t>(dest));
            }
        }

        std::vector<std::size_t> ready;
        for (std::size_t i = 0U; i < indegree.size(); ++i)
            if (indegree[i] == 0U) ready.push_back(i);

        std::vector<std::vector<std::size_t>> layers;
        std::size_t visited = 0U;
        while (!ready.empty()) {
            std::sort(ready.begin(), ready.end());
            layers.push_back(ready);
            visited += ready.size();
            std::vector<std::size_t> next;
            for (const auto node : ready) {
                for (const auto dest : edges[node]) {
                    if (--indegree[dest] == 0U) next.push_back(dest);
                }
            }
            ready = std::move(next);
        }
        if (visited != defs.size()) throw std::logic_error("routing cycle");
        return layers;
    }

    void stopWorkerThreads() noexcept {
        if (workers.empty()) return;
        stopWorkers.store(true, std::memory_order_release);
        workGeneration.fetch_add(1U, std::memory_order_acq_rel);
        workerCv.notify_all();
        for (auto& worker : workers) {
            if (worker.joinable()) worker.join();
        }
        workers.clear();
        workersReady.store(0U, std::memory_order_relaxed);
        stopWorkers.store(false, std::memory_order_relaxed);
        activeLayer = nullptr;
        remainingWork.store(0U, std::memory_order_relaxed);
    }

    static void cpuRelax() noexcept {
#if defined(__i386__) || defined(__x86_64__) || defined(_M_IX86) || defined(_M_X64)
#if defined(_MSC_VER)
        _mm_pause();
#else
        __builtin_ia32_pause();
#endif
#else
        std::atomic_signal_fence(std::memory_order_seq_cst);
#endif
    }

    static constexpr std::uint32_t kPublishingWork = 0x80000000U;
    static constexpr std::uint32_t kClaimCountMask = 0x7FFFFFFFU;

    bool acquireWorkClaim() noexcept {
        std::uint32_t state = workClaimState.load(std::memory_order_acquire);
        for (;;) {
            if ((state & kPublishingWork) != 0U) return false;
            if ((state & kClaimCountMask) == kClaimCountMask) return false;
            if (workClaimState.compare_exchange_weak(state, state + 1U,
                                                     std::memory_order_acquire,
                                                     std::memory_order_relaxed))
                return true;
        }
    }

    void releaseWorkClaim() noexcept {
        workClaimState.fetch_sub(1U, std::memory_order_release);
    }

    void beginWorkPublication() noexcept {
        std::uint32_t expected = 0U;
        while (!workClaimState.compare_exchange_weak(expected, kPublishingWork,
                                                      std::memory_order_acquire,
                                                      std::memory_order_relaxed)) {
            expected = 0U;
            cpuRelax();
        }
    }

    void endWorkPublication() noexcept {
        workClaimState.store(0U, std::memory_order_release);
    }

    void workerLoop() noexcept {
        std::uint64_t observed = workGeneration.load(std::memory_order_acquire);
        workersReady.fetch_add(1U, std::memory_order_release);
        while (!stopWorkers.load(std::memory_order_acquire)) {
            {
                std::unique_lock<std::mutex> lock(workerSleepMutex);
                workerCv.wait(lock, [&] {
                    return stopWorkers.load(std::memory_order_acquire) ||
                           workGeneration.load(std::memory_order_acquire) != observed;
                });
            }
            if (stopWorkers.load(std::memory_order_acquire)) break;

            for (;;) {
                if (!acquireWorkClaim()) {
                    cpuRelax();
                    continue;
                }

                const std::uint64_t generation = workGeneration.load(std::memory_order_relaxed);
                const auto* layer = activeLayer;
                const std::size_t index = nextWorkIndex.fetch_add(1U, std::memory_order_relaxed);
                const ConstStereoBus* sources = workSources;
                const std::size_t sourceCount = workSourceCount;
                const std::uint32_t frames = workFrames;
                const ProcessorContext context = workContext;
                const std::uint8_t* nodeEnabled = workNodeEnabled;
                const std::size_t nodeEnabledCount = workNodeEnabledCount;
                const bool valid = generation != observed && layer != nullptr && index < layer->size();
                const std::size_t node = valid ? (*layer)[index] : 0U;
                releaseWorkClaim();

                if (generation == observed) break;
                if (!valid) {
                    observed = generation;
                    break;
                }

                processNode(node, sources, sourceCount, frames, context, nodeEnabled, nodeEnabledCount);
                remainingWork.fetch_sub(1U, std::memory_order_release);
            }
        }
    }

    void startWorkerThreads() {
        stopWorkerThreads();
        if (nodes.size() < 2U || workerLimit == 0U) return;
        const unsigned hw = std::thread::hardware_concurrency();
        if (hw <= 1U) return;
        const std::size_t helpers = std::min<std::size_t>(static_cast<std::size_t>(workerLimit),
                                                         static_cast<std::size_t>(hw - 1U));
        workers.reserve(helpers);
        workersReady.store(0U, std::memory_order_relaxed);
        try {
            for (std::size_t i = 0U; i < helpers; ++i)
                workers.emplace_back([this] { workerLoop(); });
            // This runs on the control thread during graph preparation. Do not
            // expose the graph to the audio callback until every helper has
            // reached its wait loop, otherwise the first block can miss all
            // workers simply because thread startup has not completed yet.
            while (workersReady.load(std::memory_order_acquire) < helpers)
                std::this_thread::yield();
        } catch (...) {
            stopWorkerThreads();
            throw;
        }
    }

    void configure(std::vector<GraphNodeDefinition> defs,
                   std::vector<MainRouteDefinition> routes,
                   std::size_t master) {
        stopWorkerThreads();
        validateDefinitions(defs, routes, master);
        const auto order = buildTopologicalOrder(defs, routes);
        const auto layers = buildExecutionLayers(defs, routes);

        std::vector<NodeRuntime> newNodes(defs.size());
        for (std::size_t n = 0U; n < defs.size(); ++n) {
            newNodes[n].definition = defs[n];
            newNodes[n].processors.reserve(defs[n].processors.size());
            for (const auto& slot : defs[n].processors) {
                ProcessorRuntime runtime;
                runtime.processor = slot.processor;
                runtime.routed = dynamic_cast<IRoutedTrackProcessor*>(slot.processor);
                runtime.routing = slot.routing;
                newNodes[n].processors.push_back(std::move(runtime));
            }
        }

        std::vector<RouteRuntime> newRoutes;
        newRoutes.reserve(routes.size());
        for (const auto& r : routes) {
            RouteRuntime rr;
            rr.definition = r;
            newRoutes.push_back(std::move(rr));
        }

        std::vector<ExtraRouteRuntime> newExtra;
        for (std::size_t owner = 0U; owner < defs.size(); ++owner) {
            for (std::size_t pi = 0U; pi < defs[owner].processors.size(); ++pi) {
                const auto& destinations = defs[owner].processors[pi].routing.extraOutputDestinations;
                for (std::size_t i = 0U; i < destinations.size(); ++i) {
                    if (destinations[i] < 0) continue;
                    ExtraRouteRuntime er;
                    er.ownerNode = owner;
                    er.processorIndex = pi;
                    er.outputBusIndex = i + 1U;
                    er.destinationNode = static_cast<std::size_t>(destinations[i]);
                    newExtra.push_back(std::move(er));
                }
            }
        }

        nodes = std::move(newNodes);
        mainRoutes = std::move(newRoutes);
        extraRoutes = std::move(newExtra);
        topoOrder = order;
        executionLayers = layers;
        masterNode = master;
        isPrepared = false;
    }

    [[nodiscard]] bool nodeUsesMixControl(std::size_t node) const noexcept {
        return node < nodes.size() && nodes[node].definition.mix.enabled;
    }

    [[nodiscard]] std::uint64_t maximumTailSamples() const noexcept {
        std::uint64_t total = 0U;
        for (const auto& node : nodes) {
            for (const auto& slot : node.processors) {
                const std::uint64_t tail = slot.processor != nullptr ? slot.processor->tailSamples() : 0U;
                if (tail == std::numeric_limits<std::uint64_t>::max())
                    return std::numeric_limits<std::uint64_t>::max();
                if (std::numeric_limits<std::uint64_t>::max() - total < tail)
                    return std::numeric_limits<std::uint64_t>::max();
                total += tail;
            }
        }
        if (!nodes.empty()) {
            const std::uint64_t latency = nodes[masterNode].outputLatency;
            if (std::numeric_limits<std::uint64_t>::max() - total < latency)
                return std::numeric_limits<std::uint64_t>::max();
            total += latency;
        }
        return total;
    }

    bool setRunMode(ProcessorRunMode mode) {
        std::vector<ITrackProcessor*> visited;
        for (auto& node : nodes) {
            for (auto& slot : node.processors) {
                if (slot.processor == nullptr) continue;
                if (std::find(visited.begin(), visited.end(), slot.processor) != visited.end()) continue;
                visited.push_back(slot.processor);
                if (!slot.processor->setRunMode(mode)) return false;
            }
        }
        return true;
    }

    bool copyNodePostFader(std::size_t nodeIndex, StereoBus output, std::uint32_t frames) const noexcept {
        if (!isPrepared || nodeIndex >= nodes.size() || frames > maxFrames ||
            output.left == nullptr || output.right == nullptr) return false;
        const auto& node = nodes[nodeIndex];
        if (node.postFaderL == nullptr || node.postFaderR == nullptr) return false;
        std::copy_n(node.postFaderL, frames, output.left);
        std::copy_n(node.postFaderR, frames, output.right);
        return true;
    }

    [[nodiscard]] bool containsProcessor(const ITrackProcessor* processor) const noexcept {
        if (processor == nullptr) return false;
        for (const auto& node : nodes) {
            for (const auto& slot : node.processors) {
                if (slot.processor == processor) return true;
            }
        }
        return false;
    }

    void resetGraphOwnedState() noexcept {
        for (auto& node : nodes) {
            node.sourceDelay.reset();
            std::fill(node.aL.begin(), node.aL.end(), 0.0F);
            std::fill(node.aR.begin(), node.aR.end(), 0.0F);
            std::fill(node.bL.begin(), node.bL.end(), 0.0F);
            std::fill(node.bR.begin(), node.bR.end(), 0.0F);
            std::fill(node.postL.begin(), node.postL.end(), 0.0F);
            std::fill(node.postR.begin(), node.postR.end(), 0.0F);
            node.currentL = nullptr;
            node.currentR = nullptr;
            node.preFaderL = nullptr;
            node.preFaderR = nullptr;
            node.postFaderL = nullptr;
            node.postFaderR = nullptr;
            for (auto& slot : node.processors) {
                slot.mainDelay.reset();
                slot.sidechainDelay.reset();
                std::fill(slot.sideL.begin(), slot.sideL.end(), 0.0F);
                std::fill(slot.sideR.begin(), slot.sideR.end(), 0.0F);
                for (auto& bus : slot.extraL) std::fill(bus.begin(), bus.end(), 0.0F);
                for (auto& bus : slot.extraR) std::fill(bus.begin(), bus.end(), 0.0F);
            }
        }
        for (auto& r : mainRoutes) r.delayLine.reset();
        for (auto& r : extraRoutes) r.delayLine.reset();
    }

    void prepare(double sr,
                 std::uint32_t frames,
                 std::uint32_t maxDelay,
                 const ProcessorGraph* predecessor) {
        if (!(sr > 0.0) || !std::isfinite(sr)) throw std::invalid_argument("invalid graph sample rate");
        if (frames == 0U) throw std::invalid_argument("invalid graph block size");
        sampleRate = sr;
        maxFrames = frames;
        maxCompensation = maxDelay;

        for (auto& node : nodes) {
            node.aL.assign(maxFrames, 0.0F); node.aR.assign(maxFrames, 0.0F);
            node.bL.assign(maxFrames, 0.0F); node.bR.assign(maxFrames, 0.0F);
            node.postL.assign(maxFrames, 0.0F); node.postR.assign(maxFrames, 0.0F);
            node.sourceDelay.prepare(maxCompensation, maxFrames);
            for (auto& slot : node.processors) {
                const bool reusedLiveProcessor = predecessor != nullptr && predecessor->containsProcessor(slot.processor);
                if (!reusedLiveProcessor) {
                    slot.processor->prepare(sampleRate, maxFrames);
                    if (predecessor != nullptr) slot.processor->reset();
                }
                slot.mainDelay.prepare(maxCompensation, maxFrames);
                slot.sidechainDelay.prepare(maxCompensation, maxFrames);
                slot.sideL.assign(maxFrames, 0.0F);
                slot.sideR.assign(maxFrames, 0.0F);
                const std::size_t extraCount = slot.routed == nullptr ? 0U : (slot.routed->outputBusCount() - 1U);
                slot.extraL.assign(extraCount, std::vector<float>(maxFrames, 0.0F));
                slot.extraR.assign(extraCount, std::vector<float>(maxFrames, 0.0F));
            }
        }
        for (auto& r : mainRoutes) r.delayLine.prepare(maxCompensation, maxFrames);
        for (auto& r : extraRoutes) r.delayLine.prepare(maxCompensation, maxFrames);

        rebuildLatencyPlan();
        resetGraphOwnedState();
        if (predecessor == nullptr) {
            for (auto& node : nodes) {
                for (auto& slot : node.processors) slot.processor->reset();
            }
        }
        isPrepared = true;
        startWorkerThreads();
    }

    void rebuildLatencyPlan() {
        for (auto& n : nodes) { n.inputLatency = 0U; n.outputLatency = 0U; n.localSourceDelay = 0U; }
        for (auto& r : mainRoutes) { r.delay = 0U; }
        for (auto& r : extraRoutes) { r.delay = 0U; r.sourceLatency = 0U; }

        for (const std::size_t nodeIndex : topoOrder) {
            auto& node = nodes[nodeIndex];
            std::uint32_t inputTarget = 0U;
            for (const auto& r : mainRoutes) {
                if (r.definition.to == nodeIndex) inputTarget = std::max(inputTarget, nodes[r.definition.from].outputLatency);
            }
            for (const auto& er : extraRoutes) {
                if (er.destinationNode != nodeIndex) continue;
                const auto& ownerSlot = nodes[er.ownerNode].processors[er.processorIndex];
                inputTarget = std::max(inputTarget, ownerSlot.outputLatency);
            }
            node.inputLatency = inputTarget;
            node.localSourceDelay = inputTarget;
            if (node.localSourceDelay > maxCompensation) throw std::length_error("local source PDC exceeds capacity");
            node.sourceDelay.setDelay(node.localSourceDelay);

            for (auto& r : mainRoutes) {
                if (r.definition.to != nodeIndex) continue;
                const auto src = nodes[r.definition.from].outputLatency;
                r.delay = inputTarget - src;
                if (r.delay > maxCompensation) throw std::length_error("main route PDC exceeds capacity");
                r.delayLine.setDelay(r.delay);
            }
            for (auto& er : extraRoutes) {
                if (er.destinationNode != nodeIndex) continue;
                const auto& ownerSlot = nodes[er.ownerNode].processors[er.processorIndex];
                er.sourceLatency = ownerSlot.outputLatency;
                er.delay = inputTarget - er.sourceLatency;
                if (er.delay > maxCompensation) throw std::length_error("extra route PDC exceeds capacity");
                er.delayLine.setDelay(er.delay);
            }

            std::uint32_t currentLatency = inputTarget;
            for (auto& slot : node.processors) {
                std::uint32_t sideLatency = currentLatency;
                if (slot.routing.sidechainSourceNode >= 0)
                    sideLatency = nodes[static_cast<std::size_t>(slot.routing.sidechainSourceNode)].outputLatency;
                const std::uint32_t alignTarget = std::max(currentLatency, sideLatency);
                slot.mainAlignmentDelay = alignTarget - currentLatency;
                slot.sidechainAlignmentDelay = alignTarget - sideLatency;
                if (slot.mainAlignmentDelay > maxCompensation || slot.sidechainAlignmentDelay > maxCompensation)
                    throw std::length_error("processor sidechain PDC exceeds capacity");
                slot.mainDelay.setDelay(slot.mainAlignmentDelay);
                slot.sidechainDelay.setDelay(slot.sidechainAlignmentDelay);
                const std::uint32_t latency = slot.processor->latencySamples();
                if (std::numeric_limits<std::uint32_t>::max() - alignTarget < latency)
                    throw std::overflow_error("processor graph latency overflow");
                slot.outputLatency = alignTarget + latency;
                currentLatency = slot.outputLatency;
            }
            node.outputLatency = currentLatency;
        }
    }

    void reset() noexcept {
        for (auto& node : nodes) {
            node.sourceDelay.reset();
            for (auto& slot : node.processors) {
                slot.processor->reset();
                slot.mainDelay.reset();
                slot.sidechainDelay.reset();
            }
        }
        for (auto& r : mainRoutes) r.delayLine.reset();
        for (auto& r : extraRoutes) r.delayLine.reset();
    }

    void applyNodeMix(NodeRuntime& node, std::uint32_t frames, const ProcessorContext& context) noexcept {
        node.preFaderL = node.currentL;
        node.preFaderR = node.currentR;
        if (!node.definition.mix.enabled || node.currentL == nullptr || node.currentR == nullptr) {
            node.postFaderL = node.currentL;
            node.postFaderR = node.currentR;
            return;
        }

        const auto& mix = node.definition.mix;
        for (std::uint32_t i = 0U; i < frames; ++i) {
            const std::int64_t sample = context.projectSample + static_cast<std::int64_t>(i);
            const bool muted = mix.muteAutomation == nullptr
                ? mix.mute
                : mix.muteAutomation->stepValueAt(sample, mix.mute ? 1.0F : 0.0F) >= 0.5F;
            if (muted) {
                node.postL[i] = 0.0F;
                node.postR[i] = 0.0F;
                continue;
            }

            const float gainDb = mix.gainAutomationDb == nullptr
                ? mix.gainDb
                : mix.gainAutomationDb->valueAt(sample, mix.gainDb);
            const double gain = MixMath::dbToLinear(static_cast<double>(gainDb));
            float pan = mix.pan;
            if (mix.panAutomation != nullptr && !mix.useDualStereoPan)
                pan = std::clamp(mix.panAutomation->valueAt(sample, mix.pan), -1.0F, 1.0F);

            if (mix.monoSource) {
                const auto p = MixMath::monoPan(pan, mix.panDepth);
                const double x = static_cast<double>(node.currentL[i]) * gain;
                node.postL[i] = static_cast<float>(x * p.left);
                node.postR[i] = static_cast<float>(x * p.right);
            } else if (mix.useDualStereoPan) {
                const auto leftPan = MixMath::monoPan(mix.stereoLeftPan, mix.panDepth);
                const auto rightPan = MixMath::monoPan(mix.stereoRightPan, mix.panDepth);
                const double l = static_cast<double>(node.currentL[i]) * gain;
                const double r = static_cast<double>(node.currentR[i]) * gain;
                node.postL[i] = static_cast<float>(l * leftPan.left + r * rightPan.left);
                node.postR[i] = static_cast<float>(l * leftPan.right + r * rightPan.right);
            } else {
                const auto balance = MixMath::stereoBalance(pan);
                node.postL[i] = static_cast<float>(static_cast<double>(node.currentL[i]) * gain * balance.left);
                node.postR[i] = static_cast<float>(static_cast<double>(node.currentR[i]) * gain * balance.right);
            }
        }
        node.postFaderL = node.postL.data();
        node.postFaderR = node.postR.data();
    }

    void processNode(std::size_t nodeIndex,
                     const ConstStereoBus* sources,
                     std::size_t sourceCount,
                     std::uint32_t frames,
                     const ProcessorContext& context,
                     const std::uint8_t* nodeEnabled,
                     std::size_t nodeEnabledCount) noexcept {
        auto& node = nodes[nodeIndex];
        std::fill_n(node.aL.data(), frames, 0.0F);
        std::fill_n(node.aR.data(), frames, 0.0F);

        const bool enabled = nodeEnabled == nullptr || nodeIndex >= nodeEnabledCount || nodeEnabled[nodeIndex] != 0U;
        if (!enabled) {
            std::fill_n(node.bL.data(), frames, 0.0F);
            std::fill_n(node.bR.data(), frames, 0.0F);
            std::fill_n(node.postL.data(), frames, 0.0F);
            std::fill_n(node.postR.data(), frames, 0.0F);
            for (auto& slot : node.processors) {
                for (auto& extra : slot.extraL) std::fill_n(extra.data(), frames, 0.0F);
                for (auto& extra : slot.extraR) std::fill_n(extra.data(), frames, 0.0F);
            }
            node.currentL = node.aL.data();
            node.currentR = node.aR.data();
            node.preFaderL = node.aL.data();
            node.preFaderR = node.aR.data();
            node.postFaderL = node.postL.data();
            node.postFaderR = node.postR.data();
            return;
        }

        if (sources != nullptr && nodeIndex < sourceCount) {
            node.sourceDelay.add(sources[nodeIndex].left, sources[nodeIndex].right,
                                 node.aL.data(), node.aR.data(), frames, 1.0F);
        }
        for (auto& r : mainRoutes) {
            if (r.definition.to != nodeIndex) continue;
            const auto& src = nodes[r.definition.from];
            const float* routeL = r.definition.tap == MainRouteTap::PreFader ? src.preFaderL : src.postFaderL;
            const float* routeR = r.definition.tap == MainRouteTap::PreFader ? src.preFaderR : src.postFaderR;
            r.delayLine.addRoute(routeL, routeR, node.aL.data(), node.aR.data(), frames,
                                 r.definition, context.projectSample);
        }
        for (auto& er : extraRoutes) {
            if (er.destinationNode != nodeIndex) continue;
            auto& ownerSlot = nodes[er.ownerNode].processors[er.processorIndex];
            const std::size_t extraIndex = er.outputBusIndex - 1U;
            if (extraIndex >= ownerSlot.extraL.size()) continue;
            er.delayLine.add(ownerSlot.extraL[extraIndex].data(), ownerSlot.extraR[extraIndex].data(),
                             node.aL.data(), node.aR.data(), frames, 1.0F);
        }

        node.currentL = node.aL.data();
        node.currentR = node.aR.data();
        bool currentIsA = true;

        for (auto& slot : node.processors) {
            float* alignedL = currentIsA ? node.bL.data() : node.aL.data();
            float* alignedR = currentIsA ? node.bR.data() : node.aR.data();
            slot.mainDelay.copy(node.currentL, node.currentR, alignedL, alignedR, frames);

            if (slot.routed == nullptr) {
                slot.processor->process(alignedL, alignedR, frames, context);
                node.currentL = alignedL;
                node.currentR = alignedR;
                currentIsA = !currentIsA;
                continue;
            }

            const std::size_t inputCount = slot.routed->inputBusCount();
            const std::size_t outputCount = slot.routed->outputBusCount();
            ConstStereoBus inputBuses[32] {};
            StereoBus outputBuses[32] {};
            if (inputCount > 0U) inputBuses[0] = {alignedL, alignedR};

            if (inputCount > 1U) {
                const int sideNode = slot.routing.sidechainSourceNode;
                const float* sideSrcL = nullptr;
                const float* sideSrcR = nullptr;
                if (sideNode >= 0) {
                    const auto& side = nodes[static_cast<std::size_t>(sideNode)];
                    sideSrcL = side.currentL;
                    sideSrcR = side.currentR;
                }
                slot.sidechainDelay.copy(sideSrcL, sideSrcR, slot.sideL.data(), slot.sideR.data(), frames);
                inputBuses[1] = {slot.sideL.data(), slot.sideR.data()};
            }

            float* outMainL = currentIsA ? node.aL.data() : node.bL.data();
            float* outMainR = currentIsA ? node.aR.data() : node.bR.data();
            outputBuses[0] = {outMainL, outMainR};
            for (std::size_t b = 1U; b < outputCount && b <= slot.extraL.size(); ++b) {
                outputBuses[b] = {slot.extraL[b - 1U].data(), slot.extraR[b - 1U].data()};
                std::fill_n(outputBuses[b].left, frames, 0.0F);
                std::fill_n(outputBuses[b].right, frames, 0.0F);
            }
            std::fill_n(outMainL, frames, 0.0F);
            std::fill_n(outMainR, frames, 0.0F);

            const bool ok = slot.routed->processBuses(inputBuses, inputCount, outputBuses, outputCount, frames, context);
            if (!ok) {
                std::copy_n(alignedL, frames, outMainL);
                std::copy_n(alignedR, frames, outMainR);
                for (std::size_t b = 1U; b < outputCount && b <= slot.extraL.size(); ++b) {
                    std::fill_n(slot.extraL[b - 1U].data(), frames, 0.0F);
                    std::fill_n(slot.extraR[b - 1U].data(), frames, 0.0F);
                }
            }
            node.currentL = outMainL;
            node.currentR = outMainR;
            currentIsA = (outMainL == node.aL.data());
        }
        applyNodeMix(node, frames, context);
    }

    void processLayer(const std::vector<std::size_t>& layer,
                      const ConstStereoBus* sources,
                      std::size_t sourceCount,
                      std::uint32_t frames,
                      const ProcessorContext& context,
                      const std::uint8_t* nodeEnabled,
                      std::size_t nodeEnabledCount) noexcept {
        if (layer.empty()) return;
        if (workers.empty() || layer.size() == 1U) {
            for (const auto node : layer)
                processNode(node, sources, sourceCount, frames, context, nodeEnabled, nodeEnabledCount);
            return;
        }

        beginWorkPublication();
        workSources = sources;
        workSourceCount = sourceCount;
        workFrames = frames;
        workContext = context;
        workNodeEnabled = nodeEnabled;
        workNodeEnabledCount = nodeEnabledCount;
        nextWorkIndex.store(0U, std::memory_order_relaxed);
        remainingWork.store(layer.size(), std::memory_order_relaxed);
        activeLayer = &layer;
        workGeneration.fetch_add(1U, std::memory_order_relaxed);
        endWorkPublication();
        workerCv.notify_all();

        for (;;) {
            const std::size_t index = nextWorkIndex.fetch_add(1U, std::memory_order_relaxed);
            if (index >= layer.size()) break;
            processNode(layer[index], sources, sourceCount, frames, context, nodeEnabled, nodeEnabledCount);
            remainingWork.fetch_sub(1U, std::memory_order_release);
        }
        while (remainingWork.load(std::memory_order_acquire) != 0U) cpuRelax();
    }

    void process(const ConstStereoBus* sources,
                 std::size_t sourceCount,
                 StereoBus masterOut,
                 std::uint32_t frames,
                 const ProcessorContext& context,
                 const std::uint8_t* nodeEnabled,
                 std::size_t nodeEnabledCount) noexcept {
        if (!isPrepared || frames > maxFrames || masterOut.left == nullptr || masterOut.right == nullptr) {
            if (masterOut.left != nullptr) std::fill_n(masterOut.left, frames, 0.0F);
            if (masterOut.right != nullptr) std::fill_n(masterOut.right, frames, 0.0F);
            return;
        }

        for (const auto& layer : executionLayers) {
            processLayer(layer, sources, sourceCount, frames, context, nodeEnabled, nodeEnabledCount);
        }

        const auto& master = nodes[masterNode];
        if (master.postFaderL == nullptr || master.postFaderR == nullptr) {
            std::fill_n(masterOut.left, frames, 0.0F);
            std::fill_n(masterOut.right, frames, 0.0F);
            return;
        }
        std::copy_n(master.postFaderL, frames, masterOut.left);
        std::copy_n(master.postFaderR, frames, masterOut.right);
    }
};

ProcessorGraph::ProcessorGraph() : impl_(new Impl) {}
ProcessorGraph::~ProcessorGraph() = default;
ProcessorGraph::ProcessorGraph(ProcessorGraph&&) noexcept = default;
ProcessorGraph& ProcessorGraph::operator=(ProcessorGraph&&) noexcept = default;

void ProcessorGraph::configure(std::vector<GraphNodeDefinition> nodes,
                               std::vector<MainRouteDefinition> routes,
                               std::size_t masterNode) {
    impl_->configure(std::move(nodes), std::move(routes), masterNode);
}

void ProcessorGraph::prepare(double sampleRate, std::uint32_t maxFrames, std::uint32_t maxCompensationSamples) {
    impl_->prepare(sampleRate, maxFrames, maxCompensationSamples, nullptr);
}

void ProcessorGraph::prepareForPublication(double sampleRate,
                                           std::uint32_t maxFrames,
                                           std::uint32_t maxCompensationSamples,
                                           const ProcessorGraph* predecessor) {
    impl_->prepare(sampleRate, maxFrames, maxCompensationSamples, predecessor);
}

void ProcessorGraph::reset() noexcept { impl_->reset(); }
void ProcessorGraph::refreshLatencies() {
    if (!impl_->isPrepared) throw std::logic_error("processor graph is not prepared");
    impl_->rebuildLatencyPlan();
}
std::size_t ProcessorGraph::nodeCount() const noexcept { return impl_->nodes.size(); }
std::uint32_t ProcessorGraph::nodeOutputLatency(std::size_t node) const {
    if (node >= impl_->nodes.size()) throw std::out_of_range("processor graph node latency");
    return impl_->nodes[node].outputLatency;
}
std::uint64_t ProcessorGraph::maximumTailSamples() const noexcept { return impl_->maximumTailSamples(); }
bool ProcessorGraph::setRunMode(ProcessorRunMode mode) { return impl_->setRunMode(mode); }
bool ProcessorGraph::copyNodePostFader(std::size_t node, StereoBus output, std::uint32_t frames) const noexcept {
    return impl_->copyNodePostFader(node, output, frames);
}
bool ProcessorGraph::prepared() const noexcept { return impl_->isPrepared; }
bool ProcessorGraph::containsProcessor(const ITrackProcessor* processor) const noexcept {
    return impl_->containsProcessor(processor);
}
bool ProcessorGraph::nodeUsesMixControl(std::size_t node) const noexcept {
    return impl_->nodeUsesMixControl(node);
}
void ProcessorGraph::setParallelWorkerLimit(std::uint32_t maxHelpers) {
    if (impl_->isPrepared) throw std::logic_error("parallel worker limit must be set before graph prepare");
    impl_->workerLimit = std::min<std::uint32_t>(maxHelpers, 64U);
}
std::uint32_t ProcessorGraph::parallelWorkerLimit() const noexcept { return impl_->workerLimit; }
std::uint32_t ProcessorGraph::parallelWorkerCount() const noexcept {
    return static_cast<std::uint32_t>(impl_->workers.size());
}
std::size_t ProcessorGraph::executionLayerCount() const noexcept {
    return impl_->executionLayers.size();
}
std::unique_ptr<ProcessorGraph> ProcessorGraph::cloneDefinition() const {
    std::vector<GraphNodeDefinition> definitions;
    definitions.reserve(impl_->nodes.size());
    for (const auto& node : impl_->nodes) definitions.push_back(node.definition);

    std::vector<MainRouteDefinition> routes;
    routes.reserve(impl_->mainRoutes.size());
    for (const auto& route : impl_->mainRoutes) routes.push_back(route.definition);

    auto graph = std::make_unique<ProcessorGraph>();
    graph->setParallelWorkerLimit(impl_->workerLimit);
    graph->configure(std::move(definitions), std::move(routes), impl_->masterNode);
    return graph;
}
void ProcessorGraph::process(const ConstStereoBus* nodeSources,
                             std::size_t sourceCount,
                             StereoBus masterOutput,
                             std::uint32_t frames,
                             const ProcessorContext& context,
                             const std::uint8_t* nodeEnabled,
                             std::size_t nodeEnabledCount) noexcept {
    impl_->process(nodeSources, sourceCount, masterOutput, frames, context, nodeEnabled, nodeEnabledCount);
}

} // namespace silveton
