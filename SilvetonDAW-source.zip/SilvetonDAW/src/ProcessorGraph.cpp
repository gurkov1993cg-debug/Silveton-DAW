#include "silveton/ProcessorGraph.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <queue>
#include <utility>

namespace silveton {
namespace {
constexpr std::size_t kMaxGraphNodes = 256U;
constexpr std::size_t kMaxProcessorsPerNode = 32U;
constexpr std::size_t kMaxExtraOutputBuses = 31U;
constexpr std::size_t kMaxRoutedBuses = 32U;

struct StereoDelayLine {
    std::vector<float> left;
    std::vector<float> right;
    std::size_t writeIndex {0U};
    std::uint32_t delaySamples {0U};

    void prepare(std::uint32_t maxDelay, std::uint32_t maxFrames) {
        const std::size_t size = static_cast<std::size_t>(maxDelay) + static_cast<std::size_t>(maxFrames) + 1U;
        left.assign(std::max<std::size_t>(size, 1U), 0.0F);
        right.assign(std::max<std::size_t>(size, 1U), 0.0F);
        writeIndex = 0U;
    }

    void setDelay(std::uint32_t delay) {
        if (delay >= left.size()) throw std::length_error("processor graph delay exceeds prepared capacity");
        delaySamples = delay;
    }

    void reset() noexcept {
        std::fill(left.begin(), left.end(), 0.0F);
        std::fill(right.begin(), right.end(), 0.0F);
        writeIndex = 0U;
    }

    void add(const float* inL,
             const float* inR,
             float* outL,
             float* outR,
             std::uint32_t frames,
             float gain = 1.0F) noexcept {
        if (inL == nullptr || inR == nullptr) return;
        if (delaySamples == 0U) {
            for (std::uint32_t i = 0U; i < frames; ++i) {
                outL[i] += inL[i] * gain;
                outR[i] += inR[i] * gain;
            }
            return;
        }
        const std::size_t size = left.size();
        for (std::uint32_t i = 0U; i < frames; ++i) {
            left[writeIndex] = inL[i];
            right[writeIndex] = inR[i];
            const std::size_t readIndex = (writeIndex + size - delaySamples) % size;
            outL[i] += left[readIndex] * gain;
            outR[i] += right[readIndex] * gain;
            writeIndex = (writeIndex + 1U) % size;
        }
    }

    void copy(const float* inL,
              const float* inR,
              float* outL,
              float* outR,
              std::uint32_t frames) noexcept {
        std::fill_n(outL, frames, 0.0F);
        std::fill_n(outR, frames, 0.0F);
        add(inL, inR, outL, outR, frames, 1.0F);
    }
};

struct RouteRuntime {
    MainRouteDefinition definition;
    std::uint32_t delay {0U};
    StereoDelayLine delayLine;
};

struct ExtraRouteRuntime {
    std::size_t ownerNode {0U};
    std::size_t processorIndex {0U};
    std::size_t outputBusIndex {1U};
    std::size_t destinationNode {0U};
    std::uint32_t sourceLatency {0U};
    std::uint32_t delay {0U};
    StereoDelayLine delayLine;
};

struct ProcessorRuntime {
    ITrackProcessor* processor {nullptr};
    IRoutedTrackProcessor* routed {nullptr};
    ProcessorRouting routing;
    std::uint32_t mainAlignmentDelay {0U};
    std::uint32_t sidechainAlignmentDelay {0U};
    std::uint32_t outputLatency {0U};
    StereoDelayLine mainDelay;
    StereoDelayLine sidechainDelay;
    std::vector<float> sideL;
    std::vector<float> sideR;
    std::vector<std::vector<float>> extraL;
    std::vector<std::vector<float>> extraR;
};

struct NodeRuntime {
    GraphNodeDefinition definition;
    std::vector<ProcessorRuntime> processors;
    std::uint32_t inputLatency {0U};
    std::uint32_t outputLatency {0U};
    std::uint32_t localSourceDelay {0U};
    StereoDelayLine sourceDelay;
    std::vector<float> aL;
    std::vector<float> aR;
    std::vector<float> bL;
    std::vector<float> bR;
    float* currentL {nullptr};
    float* currentR {nullptr};
};

struct IncomingRef {
    enum class Kind { Main, Extra } kind {Kind::Main};
    std::size_t index {0U};
    std::uint32_t latency {0U};
};
}

class ProcessorGraph::Impl {
public:
    std::vector<NodeRuntime> nodes;
    std::vector<RouteRuntime> mainRoutes;
    std::vector<ExtraRouteRuntime> extraRoutes;
    std::vector<std::size_t> topoOrder;
    std::size_t masterNode {0U};
    double sampleRate {0.0};
    std::uint32_t maxFrames {0U};
    std::uint32_t maxCompensation {0U};
    bool isPrepared {false};

    void validateDefinitions(const std::vector<GraphNodeDefinition>& defs,
                             const std::vector<MainRouteDefinition>& routes,
                             std::size_t master) const {
        if (defs.empty() || defs.size() > kMaxGraphNodes) throw std::invalid_argument("invalid processor graph node count");
        if (master >= defs.size()) throw std::out_of_range("processor graph master node");
        for (const auto& route : routes) {
            if (route.from >= defs.size() || route.to >= defs.size() || route.from == route.to)
                throw std::invalid_argument("invalid main processor route");
            if (!std::isfinite(route.gain)) throw std::invalid_argument("invalid route gain");
        }
        for (std::size_t node = 0U; node < defs.size(); ++node) {
            if (defs[node].processors.size() > kMaxProcessorsPerNode)
                throw std::length_error("too many processors on graph node");
            for (const auto& slot : defs[node].processors) {
                if (slot.processor == nullptr) throw std::invalid_argument("null processor slot");
                const auto* routed = dynamic_cast<IRoutedTrackProcessor*>(slot.processor);
                const bool hasRouting = slot.routing.sidechainSourceNode >= 0 || !slot.routing.extraOutputDestinations.empty();
                if (hasRouting && routed == nullptr)
                    throw std::invalid_argument("routing metadata requires IRoutedTrackProcessor");
                if (slot.routing.sidechainSourceNode >= static_cast<int>(defs.size()))
                    throw std::out_of_range("sidechain source node");
                if (slot.routing.sidechainSourceNode == static_cast<int>(node))
                    throw std::logic_error("routing cycle");
                if (slot.routing.extraOutputDestinations.size() > kMaxExtraOutputBuses)
                    throw std::length_error("too many extra processor outputs");
                for (const int dest : slot.routing.extraOutputDestinations) {
                    if (dest < -1 || dest >= static_cast<int>(defs.size()))
                        throw std::out_of_range("extra output destination node");
                    if (dest == static_cast<int>(node)) throw std::logic_error("routing cycle");
                }
                if (routed != nullptr) {
                    // VST3 instruments are allowed to be generators with zero audio inputs.
                    // A routed processor must always expose at least one audio output bus,
                    // but an input bus is not required.
                    if (routed->outputBusCount() == 0U)
                        throw std::invalid_argument("routed processor requires at least one output bus");
                    if (routed->inputBusCount() > kMaxRoutedBuses || routed->outputBusCount() > kMaxRoutedBuses)
                        throw std::length_error("routed processor bus count exceeds realtime graph limit");
                    if (slot.routing.sidechainSourceNode >= 0 && routed->inputBusCount() < 2U)
                        throw std::invalid_argument("processor has no sidechain input bus");
                    if (slot.routing.extraOutputDestinations.size() + 1U > routed->outputBusCount())
                        throw std::invalid_argument("processor has fewer output buses than routed destinations");
                }
            }
        }
    }

    std::vector<std::size_t> buildTopologicalOrder(const std::vector<GraphNodeDefinition>& defs,
                                                    const std::vector<MainRouteDefinition>& routes) const {
        std::vector<std::vector<std::size_t>> edges(defs.size());
        std::vector<std::size_t> indegree(defs.size(), 0U);
        const auto addEdge = [&](std::size_t from, std::size_t to) {
            auto& v = edges[from];
            if (std::find(v.begin(), v.end(), to) != v.end()) return;
            v.push_back(to);
            ++indegree[to];
        };
        for (const auto& r : routes) addEdge(r.from, r.to);
        for (std::size_t owner = 0U; owner < defs.size(); ++owner) {
            for (const auto& slot : defs[owner].processors) {
                if (slot.routing.sidechainSourceNode >= 0)
                    addEdge(static_cast<std::size_t>(slot.routing.sidechainSourceNode), owner);
                for (const int dest : slot.routing.extraOutputDestinations)
                    if (dest >= 0) addEdge(owner, static_cast<std::size_t>(dest));
            }
        }
        std::queue<std::size_t> q;
        for (std::size_t i = 0U; i < indegree.size(); ++i) if (indegree[i] == 0U) q.push(i);
        std::vector<std::size_t> order;
        order.reserve(defs.size());
        while (!q.empty()) {
            const auto n = q.front(); q.pop();
            order.push_back(n);
            for (const auto dest : edges[n]) if (--indegree[dest] == 0U) q.push(dest);
        }
        if (order.size() != defs.size()) throw std::logic_error("routing cycle");
        return order;
    }

    void configure(std::vector<GraphNodeDefinition> defs,
                   std::vector<MainRouteDefinition> routes,
                   std::size_t master) {
        validateDefinitions(defs, routes, master);
        const auto order = buildTopologicalOrder(defs, routes);

        std::vector<NodeRuntime> newNodes(defs.size());
        for (std::size_t n = 0U; n < defs.size(); ++n) {
            newNodes[n].definition = defs[n];
            newNodes[n].processors.reserve(defs[n].processors.size());
            for (const auto& slot : defs[n].processors) {
                ProcessorRuntime runtime;
                runtime.processor = slot.processor;
                runtime.routed = dynamic_cast<IRoutedTrackProcessor*>(slot.processor);
                runtime.routing = slot.routing;
                newNodes[n].processors.push_back(std::move(runtime));
            }
        }

        std::vector<RouteRuntime> newRoutes;
        newRoutes.reserve(routes.size());
        for (const auto& r : routes) {
            RouteRuntime rr;
            rr.definition = r;
            newRoutes.push_back(std::move(rr));
        }

        std::vector<ExtraRouteRuntime> newExtra;
        for (std::size_t owner = 0U; owner < defs.size(); ++owner) {
            for (std::size_t pi = 0U; pi < defs[owner].processors.size(); ++pi) {
                const auto& destinations = defs[owner].processors[pi].routing.extraOutputDestinations;
                for (std::size_t i = 0U; i < destinations.size(); ++i) {
                    if (destinations[i] < 0) continue;
                    ExtraRouteRuntime er;
                    er.ownerNode = owner;
                    er.processorIndex = pi;
                    er.outputBusIndex = i + 1U;
                    er.destinationNode = static_cast<std::size_t>(destinations[i]);
                    newExtra.push_back(std::move(er));
                }
            }
        }

        nodes = std::move(newNodes);
        mainRoutes = std::move(newRoutes);
        extraRoutes = std::move(newExtra);
        topoOrder = order;
        masterNode = master;
        isPrepared = false;
    }

    void prepare(double sr, std::uint32_t frames, std::uint32_t maxDelay) {
        if (!(sr > 0.0) || !std::isfinite(sr)) throw std::invalid_argument("invalid graph sample rate");
        if (frames == 0U) throw std::invalid_argument("invalid graph block size");
        sampleRate = sr;
        maxFrames = frames;
        maxCompensation = maxDelay;

        for (auto& node : nodes) {
            node.aL.assign(maxFrames, 0.0F); node.aR.assign(maxFrames, 0.0F);
            node.bL.assign(maxFrames, 0.0F); node.bR.assign(maxFrames, 0.0F);
            node.sourceDelay.prepare(maxCompensation, maxFrames);
            for (auto& slot : node.processors) {
                slot.processor->prepare(sampleRate, maxFrames);
                slot.mainDelay.prepare(maxCompensation, maxFrames);
                slot.sidechainDelay.prepare(maxCompensation, maxFrames);
                slot.sideL.assign(maxFrames, 0.0F);
                slot.sideR.assign(maxFrames, 0.0F);
                const std::size_t extraCount = slot.routed == nullptr ? 0U : (slot.routed->outputBusCount() - 1U);
                slot.extraL.assign(extraCount, std::vector<float>(maxFrames, 0.0F));
                slot.extraR.assign(extraCount, std::vector<float>(maxFrames, 0.0F));
            }
        }
        for (auto& r : mainRoutes) r.delayLine.prepare(maxCompensation, maxFrames);
        for (auto& r : extraRoutes) r.delayLine.prepare(maxCompensation, maxFrames);

        rebuildLatencyPlan();
        reset();
        isPrepared = true;
    }

    void rebuildLatencyPlan() {
        for (auto& n : nodes) { n.inputLatency = 0U; n.outputLatency = 0U; n.localSourceDelay = 0U; }
        for (auto& r : mainRoutes) { r.delay = 0U; }
        for (auto& r : extraRoutes) { r.delay = 0U; r.sourceLatency = 0U; }

        for (const std::size_t nodeIndex : topoOrder) {
            auto& node = nodes[nodeIndex];
            std::uint32_t inputTarget = 0U;
            for (const auto& r : mainRoutes) {
                if (r.definition.to == nodeIndex) inputTarget = std::max(inputTarget, nodes[r.definition.from].outputLatency);
            }
            for (const auto& er : extraRoutes) {
                if (er.destinationNode != nodeIndex) continue;
                const auto& ownerSlot = nodes[er.ownerNode].processors[er.processorIndex];
                inputTarget = std::max(inputTarget, ownerSlot.outputLatency);
            }
            node.inputLatency = inputTarget;
            node.localSourceDelay = inputTarget;
            if (node.localSourceDelay > maxCompensation) throw std::length_error("local source PDC exceeds capacity");
            node.sourceDelay.setDelay(node.localSourceDelay);

            for (auto& r : mainRoutes) {
                if (r.definition.to != nodeIndex) continue;
                const auto src = nodes[r.definition.from].outputLatency;
                r.delay = inputTarget - src;
                if (r.delay > maxCompensation) throw std::length_error("main route PDC exceeds capacity");
                r.delayLine.setDelay(r.delay);
            }
            for (auto& er : extraRoutes) {
                if (er.destinationNode != nodeIndex) continue;
                const auto& ownerSlot = nodes[er.ownerNode].processors[er.processorIndex];
                er.sourceLatency = ownerSlot.outputLatency;
                er.delay = inputTarget - er.sourceLatency;
                if (er.delay > maxCompensation) throw std::length_error("extra route PDC exceeds capacity");
                er.delayLine.setDelay(er.delay);
            }

            std::uint32_t currentLatency = inputTarget;
            for (auto& slot : node.processors) {
                std::uint32_t sideLatency = currentLatency;
                if (slot.routing.sidechainSourceNode >= 0)
                    sideLatency = nodes[static_cast<std::size_t>(slot.routing.sidechainSourceNode)].outputLatency;
                const std::uint32_t alignTarget = std::max(currentLatency, sideLatency);
                slot.mainAlignmentDelay = alignTarget - currentLatency;
                slot.sidechainAlignmentDelay = alignTarget - sideLatency;
                if (slot.mainAlignmentDelay > maxCompensation || slot.sidechainAlignmentDelay > maxCompensation)
                    throw std::length_error("processor sidechain PDC exceeds capacity");
                slot.mainDelay.setDelay(slot.mainAlignmentDelay);
                slot.sidechainDelay.setDelay(slot.sidechainAlignmentDelay);
                const std::uint32_t latency = slot.processor->latencySamples();
                if (std::numeric_limits<std::uint32_t>::max() - alignTarget < latency)
                    throw std::overflow_error("processor graph latency overflow");
                slot.outputLatency = alignTarget + latency;
                currentLatency = slot.outputLatency;
            }
            node.outputLatency = currentLatency;
        }
    }

    void reset() noexcept {
        for (auto& node : nodes) {
            node.sourceDelay.reset();
            for (auto& slot : node.processors) {
                slot.processor->reset();
                slot.mainDelay.reset();
                slot.sidechainDelay.reset();
            }
        }
        for (auto& r : mainRoutes) r.delayLine.reset();
        for (auto& r : extraRoutes) r.delayLine.reset();
    }

    void process(const ConstStereoBus* sources,
                 std::size_t sourceCount,
                 StereoBus masterOut,
                 std::uint32_t frames,
                 const ProcessorContext& context) noexcept {
        if (!isPrepared || frames > maxFrames || masterOut.left == nullptr || masterOut.right == nullptr) {
            if (masterOut.left != nullptr) std::fill_n(masterOut.left, frames, 0.0F);
            if (masterOut.right != nullptr) std::fill_n(masterOut.right, frames, 0.0F);
            return;
        }

        for (const std::size_t nodeIndex : topoOrder) {
            auto& node = nodes[nodeIndex];
            std::fill_n(node.aL.data(), frames, 0.0F);
            std::fill_n(node.aR.data(), frames, 0.0F);

            if (sources != nullptr && nodeIndex < sourceCount) {
                node.sourceDelay.add(sources[nodeIndex].left, sources[nodeIndex].right,
                                     node.aL.data(), node.aR.data(), frames, 1.0F);
            }
            for (auto& r : mainRoutes) {
                if (r.definition.to != nodeIndex) continue;
                const auto& src = nodes[r.definition.from];
                r.delayLine.add(src.currentL, src.currentR, node.aL.data(), node.aR.data(), frames, r.definition.gain);
            }
            for (auto& er : extraRoutes) {
                if (er.destinationNode != nodeIndex) continue;
                auto& ownerSlot = nodes[er.ownerNode].processors[er.processorIndex];
                const std::size_t extraIndex = er.outputBusIndex - 1U;
                if (extraIndex >= ownerSlot.extraL.size()) continue;
                er.delayLine.add(ownerSlot.extraL[extraIndex].data(), ownerSlot.extraR[extraIndex].data(),
                                 node.aL.data(), node.aR.data(), frames, 1.0F);
            }

            node.currentL = node.aL.data();
            node.currentR = node.aR.data();
            bool currentIsA = true;

            for (auto& slot : node.processors) {
                float* alignedL = currentIsA ? node.bL.data() : node.aL.data();
                float* alignedR = currentIsA ? node.bR.data() : node.aR.data();
                slot.mainDelay.copy(node.currentL, node.currentR, alignedL, alignedR, frames);

                if (slot.routed == nullptr) {
                    slot.processor->process(alignedL, alignedR, frames, context);
                    node.currentL = alignedL;
                    node.currentR = alignedR;
                    currentIsA = !currentIsA;
                    continue;
                }

                const std::size_t inputCount = slot.routed->inputBusCount();
                const std::size_t outputCount = slot.routed->outputBusCount();
                ConstStereoBus inputBuses[32] {};
                StereoBus outputBuses[32] {};
                if (inputCount > 0U) inputBuses[0] = {alignedL, alignedR};

                if (inputCount > 1U) {
                    const int sideNode = slot.routing.sidechainSourceNode;
                    const float* sideSrcL = nullptr;
                    const float* sideSrcR = nullptr;
                    if (sideNode >= 0) {
                        const auto& side = nodes[static_cast<std::size_t>(sideNode)];
                        sideSrcL = side.currentL;
                        sideSrcR = side.currentR;
                    }
                    slot.sidechainDelay.copy(sideSrcL, sideSrcR, slot.sideL.data(), slot.sideR.data(), frames);
                    inputBuses[1] = {slot.sideL.data(), slot.sideR.data()};
                }

                float* outMainL = currentIsA ? node.aL.data() : node.bL.data();
                float* outMainR = currentIsA ? node.aR.data() : node.bR.data();
                outputBuses[0] = {outMainL, outMainR};
                for (std::size_t b = 1U; b < outputCount && b <= slot.extraL.size(); ++b) {
                    outputBuses[b] = {slot.extraL[b - 1U].data(), slot.extraR[b - 1U].data()};
                    std::fill_n(outputBuses[b].left, frames, 0.0F);
                    std::fill_n(outputBuses[b].right, frames, 0.0F);
                }
                std::fill_n(outMainL, frames, 0.0F);
                std::fill_n(outMainR, frames, 0.0F);

                const bool ok = slot.routed->processBuses(inputBuses, inputCount, outputBuses, outputCount, frames, context);
                if (!ok) {
                    std::copy_n(alignedL, frames, outMainL);
                    std::copy_n(alignedR, frames, outMainR);
                    for (std::size_t b = 1U; b < outputCount && b <= slot.extraL.size(); ++b) {
                        std::fill_n(slot.extraL[b - 1U].data(), frames, 0.0F);
                        std::fill_n(slot.extraR[b - 1U].data(), frames, 0.0F);
                    }
                }
                node.currentL = outMainL;
                node.currentR = outMainR;
                // After the routed process the output is in the same side that was input before the alignment copy.
                // Toggle according to where outMain was written.
                currentIsA = (outMainL == node.aL.data());
            }
        }

        const auto& master = nodes[masterNode];
        if (master.currentL == nullptr || master.currentR == nullptr) {
            std::fill_n(masterOut.left, frames, 0.0F);
            std::fill_n(masterOut.right, frames, 0.0F);
            return;
        }
        std::copy_n(master.currentL, frames, masterOut.left);
        std::copy_n(master.currentR, frames, masterOut.right);
    }
};

ProcessorGraph::ProcessorGraph() : impl_(new Impl) {}
ProcessorGraph::~ProcessorGraph() = default;
ProcessorGraph::ProcessorGraph(ProcessorGraph&&) noexcept = default;
ProcessorGraph& ProcessorGraph::operator=(ProcessorGraph&&) noexcept = default;

void ProcessorGraph::configure(std::vector<GraphNodeDefinition> nodes,
                               std::vector<MainRouteDefinition> routes,
                               std::size_t masterNode) {
    impl_->configure(std::move(nodes), std::move(routes), masterNode);
}

void ProcessorGraph::prepare(double sampleRate, std::uint32_t maxFrames, std::uint32_t maxCompensationSamples) {
    impl_->prepare(sampleRate, maxFrames, maxCompensationSamples);
}

void ProcessorGraph::reset() noexcept { impl_->reset(); }
void ProcessorGraph::refreshLatencies() {
    if (!impl_->isPrepared) throw std::logic_error("processor graph is not prepared");
    impl_->rebuildLatencyPlan();
}
std::size_t ProcessorGraph::nodeCount() const noexcept { return impl_->nodes.size(); }
std::uint32_t ProcessorGraph::nodeOutputLatency(std::size_t node) const {
    if (node >= impl_->nodes.size()) throw std::out_of_range("processor graph node latency");
    return impl_->nodes[node].outputLatency;
}
bool ProcessorGraph::prepared() const noexcept { return impl_->isPrepared; }
void ProcessorGraph::process(const ConstStereoBus* nodeSources,
                             std::size_t sourceCount,
                             StereoBus masterOutput,
                             std::uint32_t frames,
                             const ProcessorContext& context) noexcept {
    impl_->process(nodeSources, sourceCount, masterOutput, frames, context);
}

} // namespace silveton
