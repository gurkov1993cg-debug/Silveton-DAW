#include "silveton/EngineRateBridge.h"

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace silveton {

void EngineRateBridge::prepare(const AudioDeviceConfig& deviceConfig, double engineRate, IAudioDeviceCallback& inner) {
    if (!(engineRate > 0.0) || !(deviceConfig.sampleRate > 0.0) || deviceConfig.blockSize == 0U)
        throw std::invalid_argument("EngineRateBridge: invalid configuration");
    deviceConfig_ = deviceConfig;
    engineConfig_ = deviceConfig;
    engineConfig_.sampleRate = engineRate;
    const double ratio = engineRate / deviceConfig.sampleRate;
    // One engine block covers one device block (rounded up to a multiple of 32).
    engineBlock_ = static_cast<std::uint32_t>(std::ceil(static_cast<double>(deviceConfig.blockSize) * ratio));
    engineBlock_ = std::max<std::uint32_t>(32U, (engineBlock_ + 31U) / 32U * 32U);
    engineConfig_.blockSize = engineBlock_;

    const std::uint32_t inCh = std::max<std::uint32_t>(1U, deviceConfig.inputChannels);
    const std::uint32_t outCh = std::max<std::uint32_t>(1U, deviceConfig.outputChannels);
    up_.prepare(deviceConfig.sampleRate, engineRate, inCh, deviceConfig.blockSize, engineBlock_);
    down_.prepare(engineRate, deviceConfig.sampleRate, outCh, engineBlock_, deviceConfig.blockSize);

    engineIn_.assign(inCh, std::vector<float>(engineBlock_, 0.0F));
    engineOut_.assign(outCh, std::vector<float>(engineBlock_, 0.0F));
    engineInPtrs_.resize(inCh);
    engineOutPtrs_.resize(outCh);
    upPushPtrs_.resize(inCh);
    upPullPtrs_.resize(inCh);
    downPushPtrs_.resize(outCh);
    downPullPtrs_.resize(outCh);
    for (std::uint32_t c = 0U; c < inCh; ++c) { engineInPtrs_[c] = engineIn_[c].data(); upPullPtrs_[c] = engineIn_[c].data(); }
    for (std::uint32_t c = 0U; c < outCh; ++c) { engineOutPtrs_[c] = engineOut_[c].data(); downPushPtrs_[c] = engineOut_[c].data(); }
    // Pre-roll silence into the input converter so an engine block never has
    // to be padded mid-stream (that would be a dropout). Worst case the engine
    // must run one block ahead of the device (engine block in device frames)
    // plus the look-ahead of both kernels; the cost is that much input latency.
    const double engineBlockDevice = static_cast<double>(engineBlock_) / ratio;
    const double downDevice = static_cast<double>(down_.latencySourceFrames()) / ratio;
    preRoll_ = static_cast<std::uint32_t>(std::ceil(engineBlockDevice) + std::ceil(downDevice)) + up_.latencySourceFrames() + 1U;
    up_.push(nullptr, preRoll_);
    paddedFrames_ = 0U;
    inner_ = &inner;
}

std::uint32_t EngineRateBridge::addedLatencyDeviceFrames() const noexcept {
    if (inner_ == nullptr) return 0U;
    // Both converters map destination frame n to source time n * ratio with the
    // kernel centred there, so neither shifts the signal; the only delay is the
    // silence pre-rolled into the input converter in prepare().
    return preRoll_;
}

void EngineRateBridge::updateDeviceTime(const AudioDeviceTimeInfo& info) noexcept {
    if (inner_ != nullptr) inner_->updateDeviceTime(info);
}

void EngineRateBridge::runEngineBlock() noexcept {
    // Engine input: whatever has been raised so far; the first block(s) of a
    // stream are padded with silence instead of waiting.
    const std::uint32_t got = up_.pull(upPullPtrs_.data(), engineBlock_);
    paddedFrames_ += engineBlock_ - got;
    for (auto& ch : engineIn_) std::fill(ch.begin() + got, ch.end(), 0.0F);
    for (auto& ch : engineOut_) std::fill(ch.begin(), ch.end(), 0.0F);
    inner_->processAudio(engineInPtrs_.data(), engineOutPtrs_.data(),
                         deviceConfig_.inputChannels, deviceConfig_.outputChannels, engineBlock_);
    down_.push(downPushPtrs_.data(), engineBlock_);
}

void EngineRateBridge::processAudio(const float* const* inputs, float* const* outputs,
                                    std::uint32_t inputChannels, std::uint32_t outputChannels,
                                    std::uint32_t frames) noexcept {
    if (inner_ == nullptr || frames == 0U) return;
    if (frames > deviceConfig_.blockSize) {
        // Larger than prepared: output silence rather than overrun the rings.
        for (std::uint32_t c = 0U; c < outputChannels; ++c)
            if (outputs != nullptr && outputs[c] != nullptr) std::fill(outputs[c], outputs[c] + frames, 0.0F);
        return;
    }
    const std::uint32_t inCh = static_cast<std::uint32_t>(upPushPtrs_.size());
    for (std::uint32_t c = 0U; c < inCh; ++c)
        upPushPtrs_[c] = (inputs != nullptr && c < inputChannels) ? inputs[c] : nullptr;
    up_.push(upPushPtrs_.data(), frames);

    // Produce engine blocks until the output converter can deliver this block.
    for (int guard = 0; guard < 8 && down_.available() < frames; ++guard) runEngineBlock();

    const std::uint32_t outCh = static_cast<std::uint32_t>(downPullPtrs_.size());
    for (std::uint32_t c = 0U; c < outCh; ++c)
        downPullPtrs_[c] = (outputs != nullptr && c < outputChannels) ? outputs[c] : nullptr;
    const std::uint32_t got = down_.pull(downPullPtrs_.data(), frames);
    for (std::uint32_t c = 0U; c < outputChannels; ++c) {
        if (outputs == nullptr || outputs[c] == nullptr) continue;
        if (c >= outCh) std::fill(outputs[c], outputs[c] + frames, 0.0F);
        else if (got < frames) std::fill(outputs[c] + got, outputs[c] + frames, 0.0F);
    }
}

} // namespace silveton
