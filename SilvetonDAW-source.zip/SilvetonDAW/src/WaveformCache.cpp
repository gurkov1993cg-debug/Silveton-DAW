#include "silveton/WaveformCache.h"
#include "silveton/DiskStream.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <thread>

namespace silveton {

namespace {

struct WaveformAudioFile {
    std::uint32_t sampleRate {0U};
    AudioBuffer audio;
};

WaveformAudioFile readWaveformAudioFile(const std::string& path) {
    constexpr std::uint32_t kCacheFrames = 32768U;
    constexpr std::uint32_t kReadFrames = 8192U;
    constexpr unsigned kRetriesPerBlock = 5000U;

    DiskStreamManager manager(1U);
    DiskAudioSource& source = manager.addSource(path, kCacheFrames);
    if (source.channels() == 0U || source.channels() > 2U)
        throw std::runtime_error("waveform cache supports mono/stereo audio");
    if (source.frames() > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
        throw std::length_error("waveform source is too large for this process");

    AudioBuffer audio(source.channels(), static_cast<std::size_t>(source.frames()));
    manager.start();
    try {
        std::uint64_t frame = 0U;
        while (frame < source.frames()) {
            const std::uint32_t count = static_cast<std::uint32_t>(
                std::min<std::uint64_t>(kReadFrames, source.frames() - frame));
            source.request(frame);
            DiskBlockView view;
            bool acquired = false;
            for (unsigned retry = 0U; retry < kRetriesPerBlock; ++retry) {
                if (source.acquire(frame, count, view)) { acquired = true; break; }
                if (source.status().ioError) throw std::runtime_error("waveform audio read failed");
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
            if (!acquired) throw std::runtime_error("waveform audio read timed out");

            for (std::uint32_t i = 0U; i < count; ++i) {
                const std::size_t dst = static_cast<std::size_t>(frame + i);
                const std::size_t src = static_cast<std::size_t>(view.frameOffset + i) * view.channels;
                for (std::uint32_t c = 0U; c < source.channels(); ++c)
                    audio.sample(c, dst) = view.interleaved[src + c];
            }
            source.release(view);
            frame += count;
        }
    } catch (...) {
        manager.stop();
        throw;
    }
    manager.stop();
    return {source.sampleRate(), std::move(audio)};
}

} // namespace

WaveformOverview buildWaveformOverview(const AudioBuffer& audio,
                                       std::uint32_t sampleRate,
                                       std::size_t maxPeaks) {
    if (sampleRate == 0U) throw std::invalid_argument("waveform sample rate must be non-zero");
    if (maxPeaks == 0U) throw std::invalid_argument("waveform maxPeaks must be non-zero");
    if (audio.channels() > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max()))
        throw std::overflow_error("waveform channel count overflow");

    WaveformOverview out;
    out.sampleRate = sampleRate;
    out.channels = static_cast<std::uint32_t>(audio.channels());
    out.frames = audio.frames();
    if (out.channels == 0U || out.frames == 0U) return out;

    out.framesPerPeak = std::max<std::uint64_t>(
        1U, (out.frames + static_cast<std::uint64_t>(maxPeaks) - 1U) /
                static_cast<std::uint64_t>(maxPeaks));
    const std::uint64_t peakCount64 = (out.frames + out.framesPerPeak - 1U) / out.framesPerPeak;
    if (peakCount64 > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
        throw std::overflow_error("waveform peak count overflow");
    const auto peakCount = static_cast<std::size_t>(peakCount64);
    out.peaks.resize(out.channels);
    for (auto& channel : out.peaks) channel.resize(peakCount);

    for (std::size_t c = 0U; c < audio.channels(); ++c) {
        const float* src = audio.channelData(c);
        for (std::size_t pi = 0U; pi < peakCount; ++pi) {
            const std::uint64_t first = static_cast<std::uint64_t>(pi) * out.framesPerPeak;
            const std::uint64_t last = std::min<std::uint64_t>(out.frames, first + out.framesPerPeak);
            float minimum = 0.0F;
            float maximum = 0.0F;
            bool have = false;
            for (std::uint64_t frame = first; frame < last; ++frame) {
                const float sample = src[static_cast<std::size_t>(frame)];
                if (!std::isfinite(sample)) continue;
                if (!have) {
                    minimum = maximum = sample;
                    have = true;
                } else {
                    minimum = std::min(minimum, sample);
                    maximum = std::max(maximum, sample);
                }
            }
            if (!have) minimum = maximum = 0.0F;
            out.peaks[c][pi] = WaveformPeak{minimum, maximum};
        }
    }
    return out;
}

WaveformCache::WaveformCache(std::size_t defaultMaxPeaks)
    : defaultMaxPeaks_(defaultMaxPeaks) {
    if (defaultMaxPeaks_ == 0U) throw std::invalid_argument("waveform cache maxPeaks must be non-zero");
    worker_ = std::thread(&WaveformCache::workerLoop, this);
}

WaveformCache::~WaveformCache() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        stop_ = true;
    }
    workCv_.notify_all();
    readyCv_.notify_all();
    if (worker_.joinable()) worker_.join();
}

void WaveformCache::request(const std::string& audioPath, std::size_t maxPeaks) {
    if (audioPath.empty()) return;
    if (maxPeaks == 0U) maxPeaks = defaultMaxPeaks_;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(audioPath);
        if (it != entries_.end()) {
            if (it->second.state == State::Ready && it->second.maxPeaks >= maxPeaks) return;
            if ((it->second.state == State::Queued || it->second.state == State::Loading) &&
                it->second.maxPeaks >= maxPeaks) return;
        }
        Entry entry;
        entry.state = State::Queued;
        entry.maxPeaks = maxPeaks;
        entries_[audioPath] = std::move(entry);
        jobs_.push_back(Job{audioPath, maxPeaks});
    }
    workCv_.notify_one();
}

std::shared_ptr<const WaveformOverview> WaveformCache::find(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = entries_.find(audioPath);
    if (it == entries_.end() || it->second.state != State::Ready) return {};
    return it->second.overview;
}

bool WaveformCache::failed(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = entries_.find(audioPath);
    return it != entries_.end() && it->second.state == State::Failed;
}

std::string WaveformCache::error(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = entries_.find(audioPath);
    return it == entries_.end() ? std::string{} : it->second.error;
}

bool WaveformCache::waitUntilReady(const std::string& audioPath, std::uint32_t timeoutMs) const {
    std::unique_lock<std::mutex> lock(mutex_);
    const auto done = [&]() {
        const auto it = entries_.find(audioPath);
        return stop_ || (it != entries_.end() &&
                         (it->second.state == State::Ready || it->second.state == State::Failed));
    };
    if (!readyCv_.wait_for(lock, std::chrono::milliseconds(timeoutMs), done)) return false;
    const auto it = entries_.find(audioPath);
    return it != entries_.end() && it->second.state == State::Ready;
}

void WaveformCache::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    entries_.clear();
    jobs_.clear();
}

void WaveformCache::workerLoop() noexcept {
    for (;;) {
        Job job;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            workCv_.wait(lock, [&] { return stop_ || !jobs_.empty(); });
            if (stop_) return;
            job = std::move(jobs_.front());
            jobs_.pop_front();
            const auto it = entries_.find(job.path);
            if (it == entries_.end() || it->second.maxPeaks != job.maxPeaks ||
                it->second.state != State::Queued) continue;
            it->second.state = State::Loading;
        }

        std::shared_ptr<const WaveformOverview> overview;
        std::string failure;
        try {
            auto decoded = readWaveformAudioFile(job.path);
            overview = std::make_shared<const WaveformOverview>(
                buildWaveformOverview(decoded.audio, decoded.sampleRate, job.maxPeaks));
        } catch (const std::exception& e) {
            failure = e.what();
        } catch (...) {
            failure = "unknown waveform cache error";
        }

        {
            std::lock_guard<std::mutex> lock(mutex_);
            const auto it = entries_.find(job.path);
            if (it != entries_.end() && it->second.maxPeaks == job.maxPeaks &&
                it->second.state == State::Loading) {
                if (overview) {
                    it->second.overview = std::move(overview);
                    it->second.error.clear();
                    it->second.state = State::Ready;
                } else {
                    it->second.overview.reset();
                    it->second.error = std::move(failure);
                    it->second.state = State::Failed;
                }
            }
        }
        readyCv_.notify_all();
    }
}

} // namespace silveton
