#include "silveton/WaveformCache.h"
#include "silveton/WavFile.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace silveton {

WaveformOverview buildWaveformOverview(const AudioBuffer& audio,
                                       std::uint32_t sampleRate,
                                       std::size_t maxPeaks) {
    if (sampleRate == 0U) throw std::invalid_argument("waveform sample rate must be non-zero");
    if (maxPeaks == 0U) throw std::invalid_argument("waveform maxPeaks must be non-zero");
    if (audio.channels() > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max()))
        throw std::overflow_error("waveform channel count overflow");

    WaveformOverview out;
    out.sampleRate = sampleRate;
    out.channels = static_cast<std::uint32_t>(audio.channels());
    out.frames = audio.frames();
    if (out.channels == 0U || out.frames == 0U) return out;

    out.framesPerPeak = std::max<std::uint64_t>(
        1U, (out.frames + static_cast<std::uint64_t>(maxPeaks) - 1U) /
                static_cast<std::uint64_t>(maxPeaks));
    const std::uint64_t peakCount64 = (out.frames + out.framesPerPeak - 1U) / out.framesPerPeak;
    if (peakCount64 > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
        throw std::overflow_error("waveform peak count overflow");
    const auto peakCount = static_cast<std::size_t>(peakCount64);
    out.peaks.resize(out.channels);
    for (auto& channel : out.peaks) channel.resize(peakCount);

    for (std::size_t c = 0U; c < audio.channels(); ++c) {
        const float* src = audio.channelData(c);
        for (std::size_t pi = 0U; pi < peakCount; ++pi) {
            const std::uint64_t first = static_cast<std::uint64_t>(pi) * out.framesPerPeak;
            const std::uint64_t last = std::min<std::uint64_t>(out.frames, first + out.framesPerPeak);
            float minimum = 0.0F;
            float maximum = 0.0F;
            bool have = false;
            for (std::uint64_t frame = first; frame < last; ++frame) {
                const float sample = src[static_cast<std::size_t>(frame)];
                if (!std::isfinite(sample)) continue;
                if (!have) {
                    minimum = maximum = sample;
                    have = true;
                } else {
                    minimum = std::min(minimum, sample);
                    maximum = std::max(maximum, sample);
                }
            }
            if (!have) minimum = maximum = 0.0F;
            out.peaks[c][pi] = WaveformPeak{minimum, maximum};
        }
    }
    return out;
}

WaveformCache::WaveformCache(std::size_t defaultMaxPeaks)
    : defaultMaxPeaks_(defaultMaxPeaks) {
    if (defaultMaxPeaks_ == 0U) throw std::invalid_argument("waveform cache maxPeaks must be non-zero");
    worker_ = std::thread(&WaveformCache::workerLoop, this);
}

WaveformCache::~WaveformCache() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        stop_ = true;
    }
    workCv_.notify_all();
    readyCv_.notify_all();
    if (worker_.joinable()) worker_.join();
}

void WaveformCache::request(const std::string& audioPath, std::size_t maxPeaks) {
    if (audioPath.empty()) return;
    if (maxPeaks == 0U) maxPeaks = defaultMaxPeaks_;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(audioPath);
        if (it != entries_.end()) {
            if (it->second.state == State::Ready && it->second.maxPeaks >= maxPeaks) return;
            if ((it->second.state == State::Queued || it->second.state == State::Loading) &&
                it->second.maxPeaks >= maxPeaks) return;
        }
        Entry entry;
        entry.state = State::Queued;
        entry.maxPeaks = maxPeaks;
        entries_[audioPath] = std::move(entry);
        jobs_.push_back(Job{audioPath, maxPeaks});
    }
    workCv_.notify_one();
}

std::shared_ptr<const WaveformOverview> WaveformCache::find(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = entries_.find(audioPath);
    if (it == entries_.end() || it->second.state != State::Ready) return {};
    return it->second.overview;
}

bool WaveformCache::failed(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = entries_.find(audioPath);
    return it != entries_.end() && it->second.state == State::Failed;
}

std::string WaveformCache::error(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = entries_.find(audioPath);
    return it == entries_.end() ? std::string{} : it->second.error;
}

bool WaveformCache::waitUntilReady(const std::string& audioPath, std::uint32_t timeoutMs) const {
    std::unique_lock<std::mutex> lock(mutex_);
    const auto done = [&]() {
        const auto it = entries_.find(audioPath);
        return stop_ || (it != entries_.end() &&
                         (it->second.state == State::Ready || it->second.state == State::Failed));
    };
    if (!readyCv_.wait_for(lock, std::chrono::milliseconds(timeoutMs), done)) return false;
    const auto it = entries_.find(audioPath);
    return it != entries_.end() && it->second.state == State::Ready;
}

void WaveformCache::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    entries_.clear();
    jobs_.clear();
}

void WaveformCache::workerLoop() noexcept {
    for (;;) {
        Job job;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            workCv_.wait(lock, [&] { return stop_ || !jobs_.empty(); });
            if (stop_) return;
            job = std::move(jobs_.front());
            jobs_.pop_front();
            const auto it = entries_.find(job.path);
            if (it == entries_.end() || it->second.maxPeaks != job.maxPeaks ||
                it->second.state != State::Queued) continue;
            it->second.state = State::Loading;
        }

        std::shared_ptr<const WaveformOverview> overview;
        std::string failure;
        try {
            auto wav = WavFile::read(job.path);
            overview = std::make_shared<const WaveformOverview>(
                buildWaveformOverview(wav.audio, wav.sampleRate, job.maxPeaks));
        } catch (const std::exception& e) {
            failure = e.what();
        } catch (...) {
            failure = "unknown waveform cache error";
        }

        {
            std::lock_guard<std::mutex> lock(mutex_);
            const auto it = entries_.find(job.path);
            if (it != entries_.end() && it->second.maxPeaks == job.maxPeaks &&
                it->second.state == State::Loading) {
                if (overview) {
                    it->second.overview = std::move(overview);
                    it->second.error.clear();
                    it->second.state = State::Ready;
                } else {
                    it->second.overview.reset();
                    it->second.error = std::move(failure);
                    it->second.state = State::Failed;
                }
            }
        }
        readyCv_.notify_all();
    }
}

} // namespace silveton
