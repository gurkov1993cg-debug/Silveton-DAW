#include "silveton/WaveformCache.h"
#include "silveton/DiskStream.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <thread>

namespace silveton {

namespace {

struct WaveformAudioFile {
    std::uint32_t sampleRate {0U};
    AudioBuffer audio;
};

WaveformAudioFile readWaveformAudioFile(const std::string& path, std::size_t maxBytes = 0U) {
    constexpr std::uint32_t kCacheFrames = 32768U;
    constexpr std::uint32_t kReadFrames = 8192U;
    constexpr unsigned kRetriesPerBlock = 5000U;

    DiskStreamManager manager(1U);
    DiskAudioSource& source = manager.addSource(path, kCacheFrames);
    if (source.channels() == 0U || source.channels() > 2U)
        throw std::runtime_error("waveform cache supports mono/stereo audio");
    if (source.frames() > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
        throw std::length_error("waveform source is too large for this process");

    if (maxBytes != 0U &&
        static_cast<double>(source.frames()) * static_cast<double>(source.channels()) * sizeof(float) > static_cast<double>(maxBytes))
        throw std::length_error("the file is too long to show sample by sample");
    AudioBuffer audio(source.channels(), static_cast<std::size_t>(source.frames()));
    manager.start();
    try {
        std::uint64_t frame = 0U;
        while (frame < source.frames()) {
            const std::uint32_t count = static_cast<std::uint32_t>(
                std::min<std::uint64_t>(kReadFrames, source.frames() - frame));
            source.request(frame);
            DiskBlockView view;
            bool acquired = false;
            for (unsigned retry = 0U; retry < kRetriesPerBlock; ++retry) {
                if (source.acquire(frame, count, view)) { acquired = true; break; }
                if (source.status().ioError) throw std::runtime_error("waveform audio read failed");
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
            if (!acquired) throw std::runtime_error("waveform audio read timed out");

            for (std::uint32_t i = 0U; i < count; ++i) {
                const std::size_t dst = static_cast<std::size_t>(frame + i);
                const std::size_t src = static_cast<std::size_t>(view.frameOffset + i) * view.channels;
                for (std::uint32_t c = 0U; c < source.channels(); ++c)
                    audio.sample(c, dst) = view.interleaved[src + c];
            }
            source.release(view);
            frame += count;
        }
    } catch (...) {
        manager.stop();
        throw;
    }
    manager.stop();
    return {source.sampleRate(), std::move(audio)};
}

// A range of a file, decoded sample by sample (the same reader as above, only `frames` from `startFrame`).
WaveformAudioFile readWaveformAudioRange(const std::string& path, std::uint64_t startFrame, std::uint64_t frames) {
    constexpr std::uint32_t kCacheFrames = 32768U;
    constexpr std::uint32_t kReadFrames = 8192U;
    constexpr unsigned kRetriesPerBlock = 5000U;

    DiskStreamManager manager(1U);
    DiskAudioSource& source = manager.addSource(path, kCacheFrames);
    if (source.channels() == 0U || source.channels() > 2U)
        throw std::runtime_error("waveform cache supports mono/stereo audio");
    if (startFrame >= source.frames()) throw std::out_of_range("waveform window starts after the end of the file");
    frames = std::min<std::uint64_t>(frames, source.frames() - startFrame);
    if (frames == 0U || frames > 64U * 1024U * 1024U) throw std::length_error("waveform window length is invalid");
    AudioBuffer audio(source.channels(), static_cast<std::size_t>(frames));
    manager.start();
    try {
        std::uint64_t frame = startFrame;
        const std::uint64_t end = startFrame + frames;
        while (frame < end) {
            const std::uint32_t count = static_cast<std::uint32_t>(std::min<std::uint64_t>(kReadFrames, end - frame));
            source.request(frame);
            DiskBlockView view;
            bool acquired = false;
            for (unsigned retry = 0U; retry < kRetriesPerBlock; ++retry) {
                if (source.acquire(frame, count, view)) { acquired = true; break; }
                if (source.status().ioError) throw std::runtime_error("waveform audio read failed");
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
            if (!acquired) throw std::runtime_error("waveform audio read timed out");
            for (std::uint32_t i = 0U; i < count; ++i) {
                const std::size_t dst = static_cast<std::size_t>(frame - startFrame + i);
                const std::size_t src = static_cast<std::size_t>(view.frameOffset + i) * view.channels;
                for (std::uint32_t c = 0U; c < source.channels(); ++c)
                    audio.sample(c, dst) = view.interleaved[src + c];
            }
            source.release(view);
            frame += count;
        }
    } catch (...) {
        manager.stop();
        throw;
    }
    manager.stop();
    return {source.sampleRate(), std::move(audio)};
}

} // namespace

WaveformOverview buildWaveformOverview(const AudioBuffer& audio,
                                       std::uint32_t sampleRate,
                                       std::size_t maxPeaks) {
    if (sampleRate == 0U) throw std::invalid_argument("waveform sample rate must be non-zero");
    if (maxPeaks == 0U) throw std::invalid_argument("waveform maxPeaks must be non-zero");
    if (audio.channels() > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max()))
        throw std::overflow_error("waveform channel count overflow");

    WaveformOverview out;
    out.sampleRate = sampleRate;
    out.channels = static_cast<std::uint32_t>(audio.channels());
    out.frames = audio.frames();
    if (out.channels == 0U || out.frames == 0U) return out;

    out.framesPerPeak = std::max<std::uint64_t>(
        1U, (out.frames + static_cast<std::uint64_t>(maxPeaks) - 1U) /
                static_cast<std::uint64_t>(maxPeaks));
    const std::uint64_t peakCount64 = (out.frames + out.framesPerPeak - 1U) / out.framesPerPeak;
    if (peakCount64 > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
        throw std::overflow_error("waveform peak count overflow");
    const auto peakCount = static_cast<std::size_t>(peakCount64);
    out.peaks.resize(out.channels);
    for (auto& channel : out.peaks) channel.resize(peakCount);

    auto build = [&](std::vector<std::vector<WaveformPeak>>& into, std::uint64_t perPeak, std::size_t count) {
        for (std::size_t c = 0U; c < audio.channels(); ++c) {
            const float* src = audio.channelData(c);
            for (std::size_t pi = 0U; pi < count; ++pi) {
                const std::uint64_t first = static_cast<std::uint64_t>(pi) * perPeak;
                const std::uint64_t last = std::min<std::uint64_t>(out.frames, first + perPeak);
                float minimum = 0.0F;
                float maximum = 0.0F;
                bool have = false;
                for (std::uint64_t frame = first; frame < last; ++frame) {
                    const float sample = src[static_cast<std::size_t>(frame)];
                    if (!std::isfinite(sample)) continue;
                    if (!have) {
                        minimum = maximum = sample;
                        have = true;
                    } else {
                        minimum = std::min(minimum, sample);
                        maximum = std::max(maximum, sample);
                    }
                }
                if (!have) minimum = maximum = 0.0F;
                into[c][pi] = WaveformPeak{minimum, maximum};
            }
        }
    };
    build(out.peaks, out.framesPerPeak, peakCount);

    // the fine envelope, only where it is finer than the coarse one
    if (out.framesPerPeak > WaveformOverview::kFineFramesPerPeak) {
        out.fineFramesPerPeak = WaveformOverview::kFineFramesPerPeak;
        const std::uint64_t fineCount64 = (out.frames + out.fineFramesPerPeak - 1U) / out.fineFramesPerPeak;
        const auto fineCount = static_cast<std::size_t>(fineCount64);
        out.finePeaks.resize(out.channels);
        for (auto& channel : out.finePeaks) channel.resize(fineCount);
        build(out.finePeaks, out.fineFramesPerPeak, fineCount);
    }
    return out;
}

WaveformCache::WaveformCache(std::size_t defaultMaxPeaks)
    : defaultMaxPeaks_(defaultMaxPeaks) {
    if (defaultMaxPeaks_ == 0U) throw std::invalid_argument("waveform cache maxPeaks must be non-zero");
    worker_ = std::thread(&WaveformCache::workerLoop, this);
}

WaveformCache::~WaveformCache() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        stop_ = true;
    }
    workCv_.notify_all();
    readyCv_.notify_all();
    if (worker_.joinable()) worker_.join();
}

void WaveformCache::request(const std::string& audioPath, std::size_t maxPeaks) {
    if (audioPath.empty()) return;
    if (maxPeaks == 0U) maxPeaks = defaultMaxPeaks_;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(audioPath);
        if (it != entries_.end()) {
            if (it->second.state == State::Ready && it->second.maxPeaks >= maxPeaks) return;
            if ((it->second.state == State::Queued || it->second.state == State::Loading) &&
                it->second.maxPeaks >= maxPeaks) return;
        }
        Entry entry;
        entry.state = State::Queued;
        entry.maxPeaks = maxPeaks;
        entries_[audioPath] = std::move(entry);
        jobs_.push_back(Job{audioPath, maxPeaks});
    }
    workCv_.notify_one();
}

void WaveformCache::requestDetail(const std::string& audioPath) {
    if (audioPath.empty()) return;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        const auto it = details_.find(audioPath);
        if (it != details_.end() && it->second.state != State::Failed) return;   // queued, loading or ready
        if (it != details_.end()) return;                                         // failed once: do not retry endlessly
        details_[audioPath] = DetailEntry {};
        jobs_.push_back(Job{audioPath, 0U, true});
    }
    workCv_.notify_one();
}

void WaveformCache::requestWindow(const std::string& audioPath, std::uint64_t startFrame, std::uint64_t frames) {
    if (audioPath.empty() || frames == 0U) return;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = windows_.find(audioPath);
        if (it != windows_.end()) {
            WindowEntry& e = it->second;
            if (e.wantStart == startFrame && e.wantFrames == frames && e.state != State::Failed) return;   // the same piece is on its way or here
            if (e.window && e.window->covers(startFrame, frames) && e.state != State::Loading) { e.wantStart = startFrame; e.wantFrames = frames; return; }
            e.wantStart = startFrame;
            e.wantFrames = frames;
            e.serial = ++windowSerial_;
            if (e.state == State::Loading) return;   // the worker re-queues the newest request when it finishes
            e.state = State::Queued;
        } else {
            if (windows_.size() >= 48U) {   // keep the cache small: drop the oldest finished piece
                auto oldest = windows_.end();
                for (auto w = windows_.begin(); w != windows_.end(); ++w)
                    if (w->second.state != State::Loading && w->second.state != State::Queued && (oldest == windows_.end() || w->second.serial < oldest->second.serial)) oldest = w;
                if (oldest != windows_.end()) windows_.erase(oldest);
            }
            WindowEntry e;
            e.wantStart = startFrame;
            e.wantFrames = frames;
            e.serial = ++windowSerial_;
            windows_[audioPath] = std::move(e);
        }
        Job job;
        job.path = audioPath;
        job.window = true;
        job.windowStart = startFrame;
        job.windowFrames = frames;
        jobs_.push_front(std::move(job));   // what is on screen comes before long envelope builds
    }
    workCv_.notify_one();
}

std::shared_ptr<const WaveformWindow> WaveformCache::findWindow(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = windows_.find(audioPath);
    return it == windows_.end() ? std::shared_ptr<const WaveformWindow> {} : it->second.window;
}

std::shared_ptr<const WaveformDetail> WaveformCache::findDetail(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = details_.find(audioPath);
    if (it == details_.end() || it->second.state != State::Ready) return {};
    return it->second.detail;
}

bool WaveformCache::detailFailed(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = details_.find(audioPath);
    return it != details_.end() && it->second.state == State::Failed;
}

bool WaveformCache::waitUntilDetailReady(const std::string& audioPath, std::uint32_t timeoutMs) const {
    std::unique_lock<std::mutex> lock(mutex_);
    const auto done = [&]() {
        const auto it = details_.find(audioPath);
        return stop_ || (it != details_.end() &&
                         (it->second.state == State::Ready || it->second.state == State::Failed));
    };
    if (!readyCv_.wait_for(lock, std::chrono::milliseconds(timeoutMs), done)) return false;
    const auto it = details_.find(audioPath);
    return it != details_.end() && it->second.state == State::Ready;
}

void WaveformCache::releaseDetailsExcept(const std::vector<std::string>& keep) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto it = details_.begin(); it != details_.end();) {
        const bool finished = it->second.state == State::Ready || it->second.state == State::Failed;
        if (finished && std::find(keep.begin(), keep.end(), it->first) == keep.end()) it = details_.erase(it);
        else ++it;
    }
}

std::shared_ptr<const WaveformOverview> WaveformCache::find(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = entries_.find(audioPath);
    if (it == entries_.end() || it->second.state != State::Ready) return {};
    return it->second.overview;
}

bool WaveformCache::failed(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = entries_.find(audioPath);
    return it != entries_.end() && it->second.state == State::Failed;
}

std::string WaveformCache::error(const std::string& audioPath) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = entries_.find(audioPath);
    return it == entries_.end() ? std::string{} : it->second.error;
}

bool WaveformCache::waitUntilReady(const std::string& audioPath, std::uint32_t timeoutMs) const {
    std::unique_lock<std::mutex> lock(mutex_);
    const auto done = [&]() {
        const auto it = entries_.find(audioPath);
        return stop_ || (it != entries_.end() &&
                         (it->second.state == State::Ready || it->second.state == State::Failed));
    };
    if (!readyCv_.wait_for(lock, std::chrono::milliseconds(timeoutMs), done)) return false;
    const auto it = entries_.find(audioPath);
    return it != entries_.end() && it->second.state == State::Ready;
}

void WaveformCache::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    entries_.clear();
    details_.clear();
    windows_.clear();
    jobs_.clear();
}

void WaveformCache::workerLoop() noexcept {
    for (;;) {
        Job job;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            workCv_.wait(lock, [&] { return stop_ || !jobs_.empty(); });
            if (stop_) return;
            job = std::move(jobs_.front());
            jobs_.pop_front();
            if (job.window) {
                const auto it = windows_.find(job.path);
                if (it == windows_.end() || it->second.state != State::Queued) continue;
                it->second.state = State::Loading;
                job.windowStart = it->second.wantStart;
                job.windowFrames = it->second.wantFrames;
            } else if (job.detail) {
                const auto it = details_.find(job.path);
                if (it == details_.end() || it->second.state != State::Queued) continue;
                it->second.state = State::Loading;
            } else {
                const auto it = entries_.find(job.path);
                if (it == entries_.end() || it->second.maxPeaks != job.maxPeaks ||
                    it->second.state != State::Queued) continue;
                it->second.state = State::Loading;
            }
        }

        if (job.window) {
            std::shared_ptr<const WaveformWindow> window;
            try {
                auto decoded = readWaveformAudioRange(job.path, job.windowStart, job.windowFrames);
                auto out = std::make_shared<WaveformWindow>();
                out->sampleRate = decoded.sampleRate;
                out->startFrame = job.windowStart;
                out->audio = std::move(decoded.audio);
                window = std::move(out);
            } catch (...) {
                window.reset();
            }
            bool again = false;
            {
                std::lock_guard<std::mutex> lock(mutex_);
                const auto it = windows_.find(job.path);
                if (it != windows_.end() && it->second.state == State::Loading) {
                    if (window) it->second.window = std::move(window);
                    it->second.state = window || it->second.window ? State::Ready : State::Failed;
                    if (it->second.state == State::Ready && !it->second.window->covers(it->second.wantStart, it->second.wantFrames) &&
                        (it->second.wantStart != job.windowStart || it->second.wantFrames != job.windowFrames)) {
                        it->second.state = State::Queued;   // a newer piece was asked for meanwhile
                        again = true;
                    }
                }
                if (again) { Job next; next.path = job.path; next.window = true; jobs_.push_front(std::move(next)); }
            }
            readyCv_.notify_all();
            continue;
        }
        if (job.detail) {
            std::shared_ptr<const WaveformDetail> detail;
            std::string failure;
            try {
                auto decoded = readWaveformAudioFile(job.path, kMaxDetailBytes);
                auto out = std::make_shared<WaveformDetail>();
                out->sampleRate = decoded.sampleRate;
                out->audio = std::move(decoded.audio);
                detail = std::move(out);
            } catch (const std::exception& e) {
                failure = e.what();
            } catch (...) {
                failure = "unknown waveform detail error";
            }
            {
                std::lock_guard<std::mutex> lock(mutex_);
                const auto it = details_.find(job.path);
                if (it != details_.end() && it->second.state == State::Loading) {
                    if (detail) {
                        it->second.detail = std::move(detail);
                        it->second.error.clear();
                        it->second.state = State::Ready;
                    } else {
                        it->second.detail.reset();
                        it->second.error = std::move(failure);
                        it->second.state = State::Failed;
                    }
                }
            }
            readyCv_.notify_all();
            continue;
        }

        std::shared_ptr<const WaveformOverview> overview;
        std::string failure;
        try {
            auto decoded = readWaveformAudioFile(job.path);
            overview = std::make_shared<const WaveformOverview>(
                buildWaveformOverview(decoded.audio, decoded.sampleRate, job.maxPeaks));
        } catch (const std::exception& e) {
            failure = e.what();
        } catch (...) {
            failure = "unknown waveform cache error";
        }

        {
            std::lock_guard<std::mutex> lock(mutex_);
            const auto it = entries_.find(job.path);
            if (it != entries_.end() && it->second.maxPeaks == job.maxPeaks &&
                it->second.state == State::Loading) {
                if (overview) {
                    it->second.overview = std::move(overview);
                    it->second.error.clear();
                    it->second.state = State::Ready;
                } else {
                    it->second.overview.reset();
                    it->second.error = std::move(failure);
                    it->second.state = State::Failed;
                }
            }
        }
        readyCv_.notify_all();
    }
}

} // namespace silveton
