#include "silveton/Vst3Runtime.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <utility>
#include <unordered_map>

namespace silveton {

struct Vst3RuntimeRack::RuntimeSlot {
    ProjectPluginSlot* state {nullptr};
    std::unique_ptr<IVst3PluginInstance> instance;
    std::string failureReason;
    std::vector<AutomationWriter> writers;
    std::unordered_map<std::uint32_t, double> outputParameterValues;
};

struct Vst3RuntimeRack::Chain {
    std::vector<RuntimeSlot> slots;
};

Vst3RuntimeRack::Vst3RuntimeRack(IVst3InstanceFactory& factory) : factory_(factory) {}
Vst3RuntimeRack::~Vst3RuntimeRack() = default;

void Vst3RuntimeRack::clear() noexcept {
    midiPorts_.clear();
    trackChains_.clear();
    busChains_.clear();
    retiredInstances_.clear();
    project_ = nullptr;
}

void Vst3RuntimeRack::restoreChain(std::vector<ProjectPluginSlot>& stateSlots, Chain& chain) {
    chain.slots.clear();
    chain.slots.reserve(stateSlots.size());
    for (auto& state : stateSlots) {
        RuntimeSlot runtime;
        runtime.state = &state;
        runtime.writers.resize(state.automation.size());
        for (std::size_t i = 0U; i < state.automation.size(); ++i)
            runtime.writers[i].setMode(state.automation[i].mode);

        std::string reason;
        auto instance = factory_.create(state.modulePath, state.classId, reason);
        if (instance == nullptr) {
            runtime.failureReason = reason.empty() ? "plug-in unavailable" : reason;
            chain.slots.push_back(std::move(runtime));
            continue;
        }
        if (!state.componentState.empty() && !instance->setComponentState(state.componentState)) {
            runtime.failureReason = "component state restore failed";
            chain.slots.push_back(std::move(runtime));
            continue;
        }
        if (!state.controllerState.empty() && !instance->setControllerState(state.controllerState)) {
            runtime.failureReason = "controller state restore failed";
            chain.slots.push_back(std::move(runtime));
            continue;
        }
        if (state.enabled && state.midiInputPort >= 0) {
            if (!instance->hasEventInput()) {
                runtime.failureReason = "plug-in has no event input bus";
                chain.slots.push_back(std::move(runtime));
                continue;
            }
            if (midiPorts_.find(state.midiInputPort) != midiPorts_.end())
                throw std::logic_error("duplicate VST3 MIDI input port");
            midiPorts_[state.midiInputPort] = instance.get();
        }
        runtime.instance = std::move(instance);
        chain.slots.push_back(std::move(runtime));
    }
}

void Vst3RuntimeRack::restore(Project& project) {
    clear();
    project_ = &project;
    trackChains_.resize(project.tracks.size());
    for (std::size_t i = 0U; i < project.tracks.size(); ++i)
        restoreChain(project.tracks[i].pluginSlots, trackChains_[i]);
    busChains_.resize(project.buses.size());
    for (std::size_t i = 0U; i < project.buses.size(); ++i)
        restoreChain(project.buses[i].pluginSlots, busChains_[i]);
}

std::size_t Vst3RuntimeRack::trackSlotCount(std::size_t track) const {
    if (track >= trackChains_.size()) throw std::out_of_range("VST3 track chain");
    return trackChains_[track].slots.size();
}
std::size_t Vst3RuntimeRack::busSlotCount(std::size_t bus) const {
    if (bus >= busChains_.size()) throw std::out_of_range("VST3 bus chain");
    return busChains_[bus].slots.size();
}

Vst3RuntimeSlotStatus Vst3RuntimeRack::trackSlotStatus(std::size_t track, std::size_t slot) const {
    if (track >= trackChains_.size() || slot >= trackChains_[track].slots.size()) throw std::out_of_range("VST3 track slot");
    const auto& s = trackChains_[track].slots[slot];
    return {s.instance != nullptr, s.state != nullptr && s.state->enabled, s.failureReason};
}
Vst3RuntimeSlotStatus Vst3RuntimeRack::busSlotStatus(std::size_t bus, std::size_t slot) const {
    if (bus >= busChains_.size() || slot >= busChains_[bus].slots.size()) throw std::out_of_range("VST3 bus slot");
    const auto& s = busChains_[bus].slots[slot];
    return {s.instance != nullptr, s.state != nullptr && s.state->enabled, s.failureReason};
}

IVst3PluginInstance* Vst3RuntimeRack::instanceForMidiPort(int port) const noexcept {
    const auto it = midiPorts_.find(port);
    return it == midiPorts_.end() ? nullptr : it->second;
}

bool Vst3RuntimeRack::popMidiOutputForPort(int port, Vst3MidiEvent& event) noexcept {
    auto* instance = instanceForMidiPort(port);
    return instance != nullptr && instance->popMidiOutput(event);
}

double Vst3RuntimeRack::trackOutputParameterValue(std::size_t track, std::size_t slot, std::uint32_t parameterId, double fallback) const noexcept {
    if (track >= trackChains_.size() || slot >= trackChains_[track].slots.size()) return fallback;
    const auto& values = trackChains_[track].slots[slot].outputParameterValues;
    const auto it = values.find(parameterId);
    return it == values.end() ? fallback : it->second;
}

double Vst3RuntimeRack::busOutputParameterValue(std::size_t bus, std::size_t slot, std::uint32_t parameterId, double fallback) const noexcept {
    if (bus >= busChains_.size() || slot >= busChains_[bus].slots.size()) return fallback;
    const auto& values = busChains_[bus].slots[slot].outputParameterValues;
    const auto it = values.find(parameterId);
    return it == values.end() ? fallback : it->second;
}

GraphNodeDefinition Vst3RuntimeRack::nodeDefinition(const Chain& chain) {
    GraphNodeDefinition out;
    out.processors.reserve(chain.slots.size());
    for (const auto& slot : chain.slots) {
        if (slot.instance == nullptr || slot.state == nullptr || !slot.state->enabled) continue;
        ProcessorRouting routing;
        routing.sidechainSourceNode = slot.state->sidechainSourceNode;
        routing.extraOutputDestinations = slot.state->extraOutputDestinations;
        out.processors.push_back({slot.instance.get(), std::move(routing)});
    }
    return out;
}

GraphNodeDefinition Vst3RuntimeRack::trackNodeDefinition(std::size_t track) const {
    if (track >= trackChains_.size()) throw std::out_of_range("VST3 track chain");
    return nodeDefinition(trackChains_[track]);
}
GraphNodeDefinition Vst3RuntimeRack::busNodeDefinition(std::size_t bus) const {
    if (bus >= busChains_.size()) throw std::out_of_range("VST3 bus chain");
    return nodeDefinition(busChains_[bus]);
}

void Vst3RuntimeRack::queueChainAutomation(Chain& chain,
                                           std::int64_t projectSample,
                                           std::uint32_t frames) noexcept {
    const std::int64_t blockEnd = projectSample + static_cast<std::int64_t>(frames);
    for (auto& slot : chain.slots) {
        if (slot.instance == nullptr || slot.state == nullptr || !slot.state->enabled) continue;
        for (const auto& automation : slot.state->automation) {
            if (automation.mode == AutomationMode::Off || automation.lane.points().empty()) continue;
            const double start = automation.lane.valueAt(projectSample, automation.lane.points().front().normalized);
            (void)slot.instance->queueParameter(automation.parameterId, start, 0);
            for (const auto& point : automation.lane.points()) {
                if (point.sample <= projectSample || point.sample >= blockEnd) continue;
                const auto offset = static_cast<std::int32_t>(point.sample - projectSample);
                (void)slot.instance->queueParameter(automation.parameterId, point.normalized, offset);
            }
        }
    }
}

void Vst3RuntimeRack::queueAutomationForBlock(std::int64_t projectSample, std::uint32_t frames) noexcept {
    for (auto& chain : trackChains_) queueChainAutomation(chain, projectSample, frames);
    for (auto& chain : busChains_) queueChainAutomation(chain, projectSample, frames);
}

void Vst3RuntimeRack::serviceChainGestures(Chain& chain, std::int64_t defaultSample) {
    for (auto& slot : chain.slots) {
        if (slot.instance == nullptr || slot.state == nullptr) continue;
        AutomationGesture event;
        while (slot.instance->popAutomationGesture(event)) {
            if (event.sample < 0) event.sample = defaultSample;
            if (event.type == AutomationGestureType::Value)
                (void)slot.instance->queueParameter(event.parameterId, event.normalized, 0);
            auto it = std::find_if(slot.state->automation.begin(), slot.state->automation.end(), [&](const auto& lane) {
                return lane.parameterId == event.parameterId;
            });
            if (it == slot.state->automation.end()) continue;
            const std::size_t index = static_cast<std::size_t>(std::distance(slot.state->automation.begin(), it));
            if (index >= slot.writers.size()) continue;
            slot.writers[index].setMode(it->mode);
            slot.writers[index].apply(event, it->lane);
        }
    }
}

void Vst3RuntimeRack::serviceAutomationGestures(std::int64_t defaultSample) {
    for (auto& chain : trackChains_) serviceChainGestures(chain, defaultSample);
    for (auto& chain : busChains_) serviceChainGestures(chain, defaultSample);
}

void Vst3RuntimeRack::serviceChainOutputParameters(Chain& chain) noexcept {
    for (auto& slot : chain.slots) {
        if (slot.instance == nullptr || slot.state == nullptr) continue;
        Vst3OutputParameterChange change;
        while (slot.instance->popOutputParameter(change)) {
            if (!std::isfinite(change.normalized) || change.normalized < 0.0 || change.normalized > 1.0) continue;
            slot.outputParameterValues[change.parameterId] = change.normalized;
            (void)slot.instance->syncControllerParameter(change.parameterId, change.normalized);
        }
    }
}
void Vst3RuntimeRack::serviceOutputParameters() noexcept {
    for (auto& chain : trackChains_) serviceChainOutputParameters(chain);
    for (auto& chain : busChains_) serviceChainOutputParameters(chain);
}

Vst3RuntimeServiceResult Vst3RuntimeRack::serviceRestartFlags() noexcept {
    Vst3RuntimeServiceResult result;
    const auto service = [&](Chain& chain) {
        for (auto& slot : chain.slots) {
            if (slot.instance == nullptr || slot.state == nullptr) continue;
            const std::uint32_t flags = slot.instance->consumeRestartFlags();

            if ((flags & Vst3RestartParamValuesChanged) != 0U) {
                result.parameterValuesChanged = true;
                (void)slot.instance->serviceParameterValuesChanged();
            }

            if ((flags & Vst3RestartMidiMappingChanged) != 0U)
                (void)slot.instance->serviceMidiMappingChanged();

            if ((flags & Vst3RestartLatencyChanged) != 0U) {
                result.latencyOrIoChanged = true;
                if (slot.instance->serviceLatencyChange()) {
                    slot.state->latencySnapshot = slot.instance->latencySamples();
                    result.graphRebuildRequired = true;
                }
            }

            if ((flags & Vst3RestartIoChanged) != 0U) {
                result.latencyOrIoChanged = true;
                if (slot.instance->reconfigureAfterIoChange()) {
                    slot.state->latencySnapshot = slot.instance->latencySamples();
                    result.graphRebuildRequired = true;
                }
            }

            if ((flags & Vst3RestartReloadComponent) == 0U) continue;
            result.reloadRequested = true;

            // Transactional reload: keep the currently published instance alive until a
            // replacement has been fully created/restored and a new graph can be published.
            try {
                const auto componentState = slot.instance->componentState();
                const auto controllerState = slot.instance->controllerState();
                std::string reason;
                auto replacement = factory_.create(slot.state->modulePath, slot.state->classId, reason);
                if (replacement == nullptr ||
                    (!componentState.empty() && !replacement->setComponentState(componentState)) ||
                    (!controllerState.empty() && !replacement->setControllerState(controllerState)) ||
                    (slot.state->midiInputPort >= 0 && !replacement->hasEventInput())) {
                    slot.failureReason = reason.empty() ? "VST3 transactional reload failed" : reason;
                    result.reloadFailed = true;
                    continue;
                }

                slot.state->componentState = componentState;
                slot.state->controllerState = controllerState;
                retiredInstances_.push_back(std::move(slot.instance));
                slot.instance = std::move(replacement);
                slot.failureReason.clear();
                result.reloadPerformed = true;
                result.graphRebuildRequired = true;
            } catch (...) {
                result.reloadFailed = true;
            }
        }
    };
    for (auto& chain : trackChains_) service(chain);
    for (auto& chain : busChains_) service(chain);
    return result;
}

void Vst3RuntimeRack::releaseRetiredInstances() noexcept {
    // Publication boundary: after the caller swaps in the new immutable graph, MIDI may
    // safely follow the replacement instances. Until here it intentionally targets the
    // retired instances still referenced by the old realtime plan.
    midiPorts_.clear();
    const auto rebuild = [&](const Chain& chain) {
        for (const auto& slot : chain.slots) {
            if (slot.instance == nullptr || slot.state == nullptr || !slot.state->enabled || slot.state->midiInputPort < 0) continue;
            midiPorts_[slot.state->midiInputPort] = slot.instance.get();
        }
    };
    for (const auto& chain : trackChains_) rebuild(chain);
    for (const auto& chain : busChains_) rebuild(chain);
    retiredInstances_.clear();
}

void Vst3RuntimeRack::captureChainState(Chain& chain, std::vector<ProjectPluginSlot>& stateSlots) {
    if (chain.slots.size() != stateSlots.size()) throw std::logic_error("VST3 runtime/project slot count mismatch");
    for (std::size_t i = 0U; i < chain.slots.size(); ++i) {
        auto& runtime = chain.slots[i];
        auto& state = stateSlots[i];
        if (runtime.instance == nullptr) continue;
        state.componentState = runtime.instance->componentState();
        state.controllerState = runtime.instance->controllerState();
        state.latencySnapshot = runtime.instance->latencySamples();
    }
}

void Vst3RuntimeRack::captureStateToProject() {
    if (project_ == nullptr) return;
    for (std::size_t i = 0U; i < trackChains_.size(); ++i)
        captureChainState(trackChains_[i], project_->tracks[i].pluginSlots);
    for (std::size_t i = 0U; i < busChains_.size(); ++i)
        captureChainState(busChains_[i], project_->buses[i].pluginSlots);
}

} // namespace silveton
