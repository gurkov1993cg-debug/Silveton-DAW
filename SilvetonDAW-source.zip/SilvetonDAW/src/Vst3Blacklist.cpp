#include "silveton/Vst3Blacklist.h"
#include <algorithm>
#include <cstdio>
#include <fstream>
#include <stdexcept>

namespace silveton {
namespace {
std::string escapeField(const std::string& value) {
    std::string out;
    out.reserve(value.size());
    for (const char c : value) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '\t': out += "\\t"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            default: out += c; break;
        }
    }
    return out;
}

bool unescapeField(const std::string& value, std::string& out) {
    out.clear();
    out.reserve(value.size());
    for (std::size_t i = 0; i < value.size(); ++i) {
        if (value[i] != '\\') {
            out += value[i];
            continue;
        }
        if (++i >= value.size()) return false;
        switch (value[i]) {
            case '\\': out += '\\'; break;
            case 't': out += '\t'; break;
            case 'n': out += '\n'; break;
            case 'r': out += '\r'; break;
            default: return false;
        }
    }
    return true;
}

std::size_t findUnescapedTab(const std::string& line, std::size_t from) noexcept {
    bool escaped = false;
    for (std::size_t i = from; i < line.size(); ++i) {
        const char c = line[i];
        if (escaped) {
            escaped = false;
            continue;
        }
        if (c == '\\') {
            escaped = true;
            continue;
        }
        if (c == '\t') return i;
    }
    return std::string::npos;
}

bool entryMatches(const Vst3BlacklistEntry& e,
                  const std::string& modulePath,
                  const std::string& classId) noexcept {
    return e.modulePath == modulePath && (e.classId == classId || e.classId == "*");
}
}

void Vst3Blacklist::load(const std::string& path) {
    entries_.clear();
    std::ifstream in(path.c_str(), std::ios::binary);
    if (!in) return;

    std::string line;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#') continue;
        const auto a = findUnescapedTab(line, 0U);
        if (a == std::string::npos) continue;
        const auto b = findUnescapedTab(line, a + 1U);
        if (b == std::string::npos) continue;

        Vst3BlacklistEntry e;
        if (!unescapeField(line.substr(0U, a), e.modulePath) ||
            !unescapeField(line.substr(a + 1U, b - a - 1U), e.classId) ||
            !unescapeField(line.substr(b + 1U), e.reason)) {
            continue;
        }
        if (e.modulePath.empty() || e.classId.empty()) continue;
        add(std::move(e.modulePath), std::move(e.classId), std::move(e.reason));
    }
}

void Vst3Blacklist::save(const std::string& path) const {
    const std::string temp = path + ".tmp";
    {
        std::ofstream out(temp.c_str(), std::ios::binary | std::ios::trunc);
        if (!out) throw std::runtime_error("cannot write VST3 blacklist temp file");
        out << "# Silveton VST3 blacklist v1\n";
        for (const auto& e : entries_) {
            out << escapeField(e.modulePath) << '\t'
                << escapeField(e.classId) << '\t'
                << escapeField(e.reason) << '\n';
        }
        out.flush();
        if (!out) throw std::runtime_error("failed writing VST3 blacklist");
    }
    (void)std::remove(path.c_str());
    if (std::rename(temp.c_str(), path.c_str()) != 0) {
        (void)std::remove(temp.c_str());
        throw std::runtime_error("cannot atomically replace VST3 blacklist");
    }
}

void Vst3Blacklist::add(std::string modulePath, std::string classId, std::string reason) {
    if (modulePath.empty() || classId.empty()) throw std::invalid_argument("invalid VST3 blacklist entry");
    for (auto& e : entries_) {
        if (e.modulePath == modulePath && e.classId == classId) {
            e.reason = std::move(reason);
            return;
        }
    }
    entries_.push_back({std::move(modulePath), std::move(classId), std::move(reason)});
}

bool Vst3Blacklist::remove(const std::string& modulePath, const std::string& classId) {
    const auto oldSize = entries_.size();
    entries_.erase(std::remove_if(entries_.begin(), entries_.end(), [&](const auto& e) {
        return e.modulePath == modulePath && e.classId == classId;
    }), entries_.end());
    return entries_.size() != oldSize;
}

bool Vst3Blacklist::contains(const std::string& modulePath, const std::string& classId) const noexcept {
    return std::any_of(entries_.begin(), entries_.end(), [&](const auto& e) {
        return entryMatches(e, modulePath, classId);
    });
}

std::string Vst3Blacklist::reason(const std::string& modulePath, const std::string& classId) const {
    for (const auto& e : entries_) {
        if (entryMatches(e, modulePath, classId)) return e.reason;
    }
    return {};
}

} // namespace silveton
