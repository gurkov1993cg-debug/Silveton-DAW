#include "silveton/TempoMap.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace silveton {
namespace {
constexpr double kBoundaryTolerance = 1.0e-8;

bool isPowerOfTwo(std::uint16_t value) noexcept {
    return value != 0U && (value & static_cast<std::uint16_t>(value - 1U)) == 0U;
}
}

TempoMap::TempoMap() { rebuild(); }

void TempoMap::validateTempo(double bpm) {
    if (!std::isfinite(bpm) || bpm <= 0.0 || bpm > 1000.0)
        throw std::invalid_argument("tempo must be finite and in (0, 1000]");
}

void TempoMap::validateTimeSignature(std::uint16_t numerator, std::uint16_t denominator) {
    if (numerator == 0U || numerator > 64U || !isPowerOfTwo(denominator) || denominator > 64U)
        throw std::invalid_argument("invalid time signature");
}

void TempoMap::setSampleRate(double sampleRate) {
    if (!std::isfinite(sampleRate) || sampleRate <= 0.0)
        throw std::invalid_argument("invalid tempo-map sample rate");
    sampleRate_ = sampleRate;
    rebuild();
}

void TempoMap::setInitialTempo(double bpm) {
    validateTempo(bpm);
    initialTempo_ = bpm;
    rebuild();
}

void TempoMap::setInitialTimeSignature(std::uint16_t numerator, std::uint16_t denominator) {
    validateTimeSignature(numerator, denominator);
    initialNumerator_ = numerator;
    initialDenominator_ = denominator;
    rebuild();
}

void TempoMap::clearChanges() {
    changes_.clear();
    rebuild();
}

void TempoMap::upsertChange(const TempoMapChange& incoming) {
    if (incoming.sample < 0) throw std::invalid_argument("tempo-map change sample cannot be negative");
    auto it = std::lower_bound(changes_.begin(), changes_.end(), incoming.sample,
        [](const TempoMapChange& value, std::int64_t sample) { return value.sample < sample; });
    if (it == changes_.end() || it->sample != incoming.sample) {
        changes_.insert(it, incoming);
        return;
    }
    if (incoming.changesTempo) {
        it->changesTempo = true;
        it->bpm = incoming.bpm;
    }
    if (incoming.changesTimeSignature) {
        it->changesTimeSignature = true;
        it->numerator = incoming.numerator;
        it->denominator = incoming.denominator;
    }
}

void TempoMap::addTempoChange(std::int64_t sample, double bpm) {
    validateTempo(bpm);
    TempoMapChange change;
    change.sample = sample;
    change.changesTempo = true;
    change.bpm = bpm;
    upsertChange(change);
    rebuild();
}

void TempoMap::addTimeSignatureChange(std::int64_t sample,
                                      std::uint16_t numerator,
                                      std::uint16_t denominator) {
    validateTimeSignature(numerator, denominator);
    TempoMapChange change;
    change.sample = sample;
    change.changesTimeSignature = true;
    change.numerator = numerator;
    change.denominator = denominator;
    upsertChange(change);
    rebuild();
}

void TempoMap::rebuild() {
    validateTempo(initialTempo_);
    validateTimeSignature(initialNumerator_, initialDenominator_);
    std::sort(changes_.begin(), changes_.end(), [](const TempoMapChange& a, const TempoMapChange& b) {
        return a.sample < b.sample;
    });

    segments_.clear();
    segments_.reserve(changes_.size() + 1U);

    Segment current;
    current.startSample = 0;
    current.startQuarterNotes = 0.0;
    current.bpm = initialTempo_;
    current.numerator = initialNumerator_;
    current.denominator = initialDenominator_;
    current.meterAnchorQuarterNotes = 0.0;
    current.meterAnchorBarZeroBased = 0;

    for (const TempoMapChange& change : changes_) {
        if (change.sample < 0) throw std::invalid_argument("tempo-map change sample cannot be negative");
        if (change.changesTempo) validateTempo(change.bpm);
        if (change.changesTimeSignature) validateTimeSignature(change.numerator, change.denominator);

        if (change.sample == current.startSample) {
            if (change.changesTimeSignature) {
                current.numerator = change.numerator;
                current.denominator = change.denominator;
                current.meterAnchorQuarterNotes = current.startQuarterNotes;
            }
            if (change.changesTempo) current.bpm = change.bpm;
            continue;
        }

        segments_.push_back(current);
        const double elapsedSamples = static_cast<double>(change.sample - current.startSample);
        const double qAtChange = current.startQuarterNotes +
            elapsedSamples * current.bpm / (60.0 * sampleRate_);

        Segment next = current;
        next.startSample = change.sample;
        next.startQuarterNotes = qAtChange;

        if (change.changesTimeSignature) {
            const double quarterPerBeat = 4.0 / static_cast<double>(current.denominator);
            const double quarterPerBar = static_cast<double>(current.numerator) * quarterPerBeat;
            const double barsFromAnchor = (qAtChange - current.meterAnchorQuarterNotes) / quarterPerBar;
            const double roundedBars = std::round(barsFromAnchor);
            if (std::abs(barsFromAnchor - roundedBars) > kBoundaryTolerance)
                throw std::invalid_argument("time-signature change must be on a bar boundary");
            next.meterAnchorBarZeroBased = current.meterAnchorBarZeroBased +
                static_cast<std::int64_t>(roundedBars);
            next.meterAnchorQuarterNotes = qAtChange;
            next.numerator = change.numerator;
            next.denominator = change.denominator;
        }
        if (change.changesTempo) next.bpm = change.bpm;
        current = next;
    }
    segments_.push_back(current);
}

const TempoMap::Segment& TempoMap::segmentAtSample(std::int64_t sample) const noexcept {
    if (segments_.size() == 1U || sample <= segments_.front().startSample) return segments_.front();
    auto it = std::upper_bound(segments_.begin(), segments_.end(), sample,
        [](std::int64_t value, const Segment& segment) { return value < segment.startSample; });
    if (it == segments_.begin()) return segments_.front();
    return *(it - 1);
}

const TempoMap::Segment& TempoMap::segmentAtQuarterNotes(double quarterNotes) const noexcept {
    if (segments_.size() == 1U || quarterNotes <= segments_.front().startQuarterNotes) return segments_.front();
    auto it = std::upper_bound(segments_.begin(), segments_.end(), quarterNotes,
        [](double value, const Segment& segment) { return value < segment.startQuarterNotes; });
    if (it == segments_.begin()) return segments_.front();
    return *(it - 1);
}

double TempoMap::tempoAtSample(std::int64_t sample) const noexcept {
    return segmentAtSample(sample).bpm;
}

std::uint16_t TempoMap::numeratorAtSample(std::int64_t sample) const noexcept {
    return segmentAtSample(sample).numerator;
}

std::uint16_t TempoMap::denominatorAtSample(std::int64_t sample) const noexcept {
    return segmentAtSample(sample).denominator;
}

double TempoMap::quarterNotesAtSample(std::int64_t sample) const noexcept {
    const Segment& segment = segmentAtSample(sample);
    return segment.startQuarterNotes +
        static_cast<double>(sample - segment.startSample) * segment.bpm / (60.0 * sampleRate_);
}

std::int64_t TempoMap::sampleAtQuarterNotes(double quarterNotes) const noexcept {
    if (!std::isfinite(quarterNotes)) return 0;
    const Segment& segment = segmentAtQuarterNotes(quarterNotes);
    const double samples = static_cast<double>(segment.startSample) +
        (quarterNotes - segment.startQuarterNotes) * (60.0 * sampleRate_) / segment.bpm;
    if (samples <= static_cast<double>(std::numeric_limits<std::int64_t>::min()))
        return std::numeric_limits<std::int64_t>::min();
    if (samples >= static_cast<double>(std::numeric_limits<std::int64_t>::max()))
        return std::numeric_limits<std::int64_t>::max();
    return static_cast<std::int64_t>(std::llround(samples));
}

TempoMapPosition TempoMap::positionAtSample(std::int64_t sample) const noexcept {
    const Segment& segment = segmentAtSample(sample);
    TempoMapPosition result;
    result.quarterNotes = quarterNotesAtSample(sample);
    result.bpm = segment.bpm;
    result.numerator = segment.numerator;
    result.denominator = segment.denominator;

    const double quarterPerBeat = 4.0 / static_cast<double>(segment.denominator);
    const double quarterPerBar = static_cast<double>(segment.numerator) * quarterPerBeat;
    const double fromAnchor = result.quarterNotes - segment.meterAnchorQuarterNotes;
    const double barFloat = fromAnchor / quarterPerBar;
    const auto completedBars = static_cast<std::int64_t>(std::floor(barFloat + kBoundaryTolerance));
    double insideBar = fromAnchor - static_cast<double>(completedBars) * quarterPerBar;
    if (insideBar < 0.0) insideBar = 0.0;
    const double beatFloat = insideBar / quarterPerBeat;
    auto beatZero = static_cast<std::uint16_t>(std::floor(beatFloat + kBoundaryTolerance));
    if (beatZero >= segment.numerator) beatZero = static_cast<std::uint16_t>(segment.numerator - 1U);

    result.barStartQuarterNotes = segment.meterAnchorQuarterNotes +
        static_cast<double>(completedBars) * quarterPerBar;
    result.bar = segment.meterAnchorBarZeroBased + completedBars + 1;
    result.beat = static_cast<std::uint16_t>(beatZero + 1U);
    result.beatFraction = std::max(0.0, beatFloat - static_cast<double>(beatZero));
    return result;
}

std::int64_t TempoMap::snapSampleToQuarterGrid(std::int64_t sample, std::uint32_t divisionsPerQuarter) const noexcept {
    if (divisionsPerQuarter == 0U) return sample;
    const double q = quarterNotesAtSample(sample);
    const double scaled = q * static_cast<double>(divisionsPerQuarter);
    const double snappedQ = std::round(scaled) / static_cast<double>(divisionsPerQuarter);
    return sampleAtQuarterNotes(snappedQ);
}

std::int64_t TempoMap::nextChangeSampleAfter(std::int64_t sample) const noexcept {
    auto it = std::upper_bound(changes_.begin(), changes_.end(), sample,
        [](std::int64_t value, const TempoMapChange& change) { return value < change.sample; });
    return it == changes_.end() ? std::numeric_limits<std::int64_t>::max() : it->sample;
}

} // namespace silveton
