#include "silveton/RealtimeClockMapper.h"
#include <cmath>
#include <limits>

namespace silveton {

void RealtimeClockMapper::setHostTicksPerSecond(double ticksPerSecond) noexcept {
    if (std::isfinite(ticksPerSecond) && ticksPerSecond > 0.0)
        hostTicksPerSecond_.store(ticksPerSecond, std::memory_order_release);
}

void RealtimeClockMapper::update(std::uint64_t hostTime,
                                 std::int64_t projectSample,
                                 double sampleRate) noexcept {
    if (hostTime == 0U || !std::isfinite(sampleRate) || sampleRate <= 0.0) return;
    generation_.fetch_add(1U, std::memory_order_acq_rel); // odd while writing
    hostTime_.store(hostTime, std::memory_order_relaxed);
    projectSample_.store(projectSample, std::memory_order_relaxed);
    sampleRate_.store(sampleRate, std::memory_order_relaxed);
    generation_.fetch_add(1U, std::memory_order_release); // even/stable
}

bool RealtimeClockMapper::valid() const noexcept {
    return hostTime_.load(std::memory_order_acquire) != 0U &&
           hostTicksPerSecond_.load(std::memory_order_acquire) > 0.0;
}

std::int64_t RealtimeClockMapper::projectSampleAtHostTime(std::uint64_t hostTime) const noexcept {
    for (unsigned attempt = 0U; attempt < 4U; ++attempt) {
        const std::uint64_t g1 = generation_.load(std::memory_order_acquire);
        if ((g1 & 1U) != 0U) continue;
        const std::uint64_t anchorHost = hostTime_.load(std::memory_order_relaxed);
        const std::int64_t anchorSample = projectSample_.load(std::memory_order_relaxed);
        const double rate = sampleRate_.load(std::memory_order_relaxed);
        const double ticks = hostTicksPerSecond_.load(std::memory_order_relaxed);
        const std::uint64_t g2 = generation_.load(std::memory_order_acquire);
        if (g1 != g2 || (g2 & 1U) != 0U) continue;
        if (anchorHost == 0U || !(ticks > 0.0) || !(rate > 0.0)) return anchorSample;
        const long double deltaTicks = hostTime >= anchorHost
            ? static_cast<long double>(hostTime - anchorHost)
            : -static_cast<long double>(anchorHost - hostTime);
        const long double deltaSamples = deltaTicks * static_cast<long double>(rate) / static_cast<long double>(ticks);
        long double resolved = static_cast<long double>(anchorSample) + deltaSamples;
        if (resolved > static_cast<long double>(std::numeric_limits<std::int64_t>::max()))
            return std::numeric_limits<std::int64_t>::max();
        if (resolved < static_cast<long double>(std::numeric_limits<std::int64_t>::min()))
            return std::numeric_limits<std::int64_t>::min();
        return static_cast<std::int64_t>(std::llround(resolved));
    }
    return projectSample_.load(std::memory_order_acquire);
}

} // namespace silveton
