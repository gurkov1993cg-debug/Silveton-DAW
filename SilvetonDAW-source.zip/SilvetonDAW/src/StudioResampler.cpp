#include "silveton/StudioResampler.h"

#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <thread>
#if defined(__SSE2__)
#include <emmintrin.h>
#endif

namespace silveton {
namespace {

constexpr double kPi = 3.14159265358979323846264338327950288;

double exactSinc(double x) noexcept {
    if (std::abs(x) < 1.0e-12) return 1.0;
    const double px = kPi * x;
    return std::sin(px) / px;
}

// Same series as the sampler's besselI0().
double besselI0(double x) noexcept {
    double sum = 1.0, term = 1.0;
    const double q = x * x * 0.25;
    for (int k = 1; k < 200; ++k) {
        term *= q / (static_cast<double>(k) * static_cast<double>(k));
        sum += term;
        if (term < sum * 1.0e-17) break;
    }
    return sum;
}

// Kaiser estimate: N = (A - 7.95) / (14.36 * transition[cycles/sample]).
int tapsFor(double transition) noexcept {
    const double n = (StudioResampler::kRejectDb - 7.95) / (14.36 * std::max(1.0e-6, transition));
    int t = static_cast<int>(std::ceil(n / 4.0)) * 4;
    return std::clamp(t, StudioResampler::kMinTaps, StudioResampler::kMaxTaps);
}
double transitionFor(int taps) noexcept {
    return (StudioResampler::kRejectDb - 7.95) / (14.36 * static_cast<double>(taps));
}

std::size_t roundUpPow2(std::size_t v) noexcept {
    std::size_t p = 1U;
    while (p < v) p <<= 1U;
    return p;
}

} // namespace

void StudioResampler::designKernel(double sourceRate, double destinationRate) {
    // Frequencies in cycles per SOURCE sample. 0.455 is the sampler's
    // "top of the recording" (20 kHz of a 44.1 kHz file).
    constexpr double kContentTop = 0.455;
    const double pass = std::min(kContentTop, kAudibleHz / sourceRate);
    double stop;
    if (destinationRate < sourceRate) {
        // Downsampling: anything above (destination - 20 kHz) folds into the
        // audible band after the destination rate wraps it.
        stop = std::max(pass + 1.0e-3, (destinationRate - kAudibleHz) / sourceRate);
        stop = std::min(stop, 0.5);
    } else {
        // Upsampling: every image of the source sits above the source Nyquist.
        stop = 0.5;
    }
    taps_ = tapsFor(stop - pass);
    const double tr = transitionFor(taps_);
    double p = pass;
    const double sEdge = std::min(stop, pass + tr);
    if (sEdge - p < tr) p = std::max(0.25 * stop, sEdge - tr);   // longest kernel still too short: duller, never aliasing
    const double fc = 0.5 * (p + sEdge);

    design_.taps = taps_;
    design_.passbandHz = p * sourceRate;
    design_.stopbandHz = sEdge * sourceRate;
    design_.cutoff = fc;

    const double beta = 0.1102 * (kRejectDb - 8.7);
    const double i0Beta = besselI0(beta);
    const int half = taps_ / 2;
    table_.assign(static_cast<std::size_t>((kPhases + 1) * taps_), 0.0F);
    std::vector<double> w(static_cast<std::size_t>(taps_));
    for (int ph = 0; ph <= kPhases; ++ph) {
        const double frac = static_cast<double>(ph) / kPhases;
        double sum = 0.0;
        for (int k = 0; k < taps_; ++k) {
            const double t = static_cast<double>(k - half + 1) - frac;
            const double x = t / static_cast<double>(half);
            const double win = (std::abs(x) >= 1.0) ? 0.0 : besselI0(beta * std::sqrt(1.0 - x * x)) / i0Beta;
            const double v = 2.0 * fc * exactSinc(2.0 * fc * t) * win;
            w[static_cast<std::size_t>(k)] = v;
            sum += v;
        }
        const double inv = std::abs(sum) < 1.0e-12 ? 0.0 : 1.0 / sum;
        float* row = table_.data() + static_cast<std::size_t>(ph * taps_);
        for (int k = 0; k < taps_; ++k) row[k] = static_cast<float>(w[static_cast<std::size_t>(k)] * inv);
    }
}

void StudioResampler::prepare(double sourceRate, double destinationRate, std::uint32_t channels,
                              std::uint32_t maxPushFrames, std::uint32_t maxPullFrames) {
    if (!(sourceRate > 0.0) || !(destinationRate > 0.0) || !std::isfinite(sourceRate) || !std::isfinite(destinationRate))
        throw std::invalid_argument("StudioResampler: sample rates must be positive");
    if (channels == 0U || channels > 32U) throw std::invalid_argument("StudioResampler: channel count");
    if (maxPushFrames == 0U || maxPullFrames == 0U) throw std::invalid_argument("StudioResampler: block sizes");
    ratio_ = sourceRate / destinationRate;
    channels_ = channels;
    designKernel(sourceRate, destinationRate);
    const double pulledSource = static_cast<double>(maxPullFrames) * ratio_;
    const std::size_t need = static_cast<std::size_t>(maxPushFrames) * 2U +
                             static_cast<std::size_t>(std::ceil(pulledSource)) * 2U +
                             static_cast<std::size_t>(taps_) * 2U + 64U;
    const std::size_t size = roundUpPow2(need);
    ring_.assign(channels_, std::vector<float>(size, 0.0F));
    mask_ = size - 1U;
    reset();
}

void StudioResampler::reset() noexcept {
    for (auto& ch : ring_) std::fill(ch.begin(), ch.end(), 0.0F);
    written_ = 0U;
    position_ = 0.0;
}

std::uint32_t StudioResampler::latencyDestinationFrames() const noexcept {
    if (taps_ == 0) return 0U;
    return static_cast<std::uint32_t>(std::ceil(static_cast<double>(taps_ / 2) / ratio_));
}

void StudioResampler::push(const float* const* source, std::uint32_t frames) noexcept {
    if (taps_ == 0 || frames == 0U) return;
    for (std::uint32_t c = 0U; c < channels_; ++c) {
        float* ring = ring_[c].data();
        const float* in = source != nullptr ? source[c] : nullptr;
        for (std::uint32_t i = 0U; i < frames; ++i)
            ring[(written_ + i) & mask_] = in != nullptr ? in[i] : 0.0F;
    }
    written_ += frames;
}

std::uint32_t StudioResampler::available() const noexcept {
    if (taps_ == 0 || written_ == 0U) return 0U;
    const int half = taps_ / 2;
    // The destination frame at `position_` needs source frames up to floor(position_) + half.
    const double lastUsable = static_cast<double>(written_) - 1.0 - static_cast<double>(half);
    const double span = lastUsable - std::floor(position_);
    if (span < 0.0) return 0U;
    return static_cast<std::uint32_t>(std::floor(span / ratio_)) + 1U;
}

void StudioResampler::renderFrame(float* const* destination, std::uint32_t frameIndex) noexcept {
    const int half = taps_ / 2;
    const double base = std::floor(position_);
    const double frac = position_ - base;
    const auto i1 = static_cast<std::int64_t>(base);
    const double scaled = frac * kPhases;
    int p = static_cast<int>(scaled);
    p = std::clamp(p, 0, kPhases - 1);
    const float mix = static_cast<float>(scaled - static_cast<double>(p));
    const float* a = table_.data() + static_cast<std::size_t>(p * taps_);
    const float* b = a + taps_;
    const std::int64_t first = i1 - half + 1;
    for (std::uint32_t c = 0U; c < channels_; ++c) {
        if (destination[c] == nullptr) continue;
        const float* ring = ring_[c].data();
        float acc0 = 0.0F, acc1 = 0.0F, acc2 = 0.0F, acc3 = 0.0F;
        for (int k = 0; k < taps_; k += 4) {
            const std::uint64_t idx = static_cast<std::uint64_t>(first + k);
            const float w0 = a[k] + (b[k] - a[k]) * mix;
            const float w1 = a[k + 1] + (b[k + 1] - a[k + 1]) * mix;
            const float w2 = a[k + 2] + (b[k + 2] - a[k + 2]) * mix;
            const float w3 = a[k + 3] + (b[k + 3] - a[k + 3]) * mix;
            acc0 += ring[(idx) & mask_] * w0;
            acc1 += ring[(idx + 1U) & mask_] * w1;
            acc2 += ring[(idx + 2U) & mask_] * w2;
            acc3 += ring[(idx + 3U) & mask_] * w3;
        }
        destination[c][frameIndex] = (acc0 + acc1) + (acc2 + acc3);
    }
}

std::uint32_t StudioResampler::pull(float* const* destination, std::uint32_t maxFrames) noexcept {
    if (taps_ == 0 || destination == nullptr) return 0U;
    const std::uint32_t count = std::min(maxFrames, available());
    for (std::uint32_t n = 0U; n < count; ++n) {
        // Frames before source index 0 read the zero-initialised ring; the
        // ring is sized so a pushed frame is never overwritten before use.
        if (position_ < 0.0) position_ = 0.0;
        renderFrame(destination, n);
        position_ += ratio_;
    }
    return count;
}

namespace {
// Dot product of `n` (multiple of 4) floats; SSE2 on x86_64 (always present on
// the supported Macs), plain loop elsewhere. Two accumulators hide latency.
inline float dotProduct(const float* a, const float* b, int n) noexcept {
#if defined(__SSE2__)
    __m128 acc0 = _mm_setzero_ps(), acc1 = _mm_setzero_ps();
    int k = 0;
    for (; k + 8 <= n; k += 8) {
        acc0 = _mm_add_ps(acc0, _mm_mul_ps(_mm_loadu_ps(a + k), _mm_loadu_ps(b + k)));
        acc1 = _mm_add_ps(acc1, _mm_mul_ps(_mm_loadu_ps(a + k + 4), _mm_loadu_ps(b + k + 4)));
    }
    for (; k < n; k += 4) acc0 = _mm_add_ps(acc0, _mm_mul_ps(_mm_loadu_ps(a + k), _mm_loadu_ps(b + k)));
    acc0 = _mm_add_ps(acc0, acc1);
    alignas(16) float lane[4];
    _mm_store_ps(lane, acc0);
    return (lane[0] + lane[1]) + (lane[2] + lane[3]);
#else
    float s0 = 0.0F, s1 = 0.0F, s2 = 0.0F, s3 = 0.0F;
    for (int k = 0; k < n; k += 4) { s0 += a[k] * b[k]; s1 += a[k + 1] * b[k + 1]; s2 += a[k + 2] * b[k + 2]; s3 += a[k + 3] * b[k + 3]; }
    return (s0 + s1) + (s2 + s3);
#endif
}
inline void blendRows(const float* a, const float* b, float mix, float* out, int n) noexcept {
#if defined(__SSE2__)
    const __m128 m = _mm_set1_ps(mix);
    for (int k = 0; k < n; k += 4) {
        const __m128 va = _mm_loadu_ps(a + k);
        _mm_storeu_ps(out + k, _mm_add_ps(va, _mm_mul_ps(_mm_sub_ps(_mm_loadu_ps(b + k), va), m)));
    }
#else
    for (int k = 0; k < n; ++k) out[k] = a[k] + (b[k] - a[k]) * mix;
#endif
}
} // namespace

// Whole-buffer conversion: same kernel and the same polyphase+blend maths as
// the streaming path, but on a zero-padded copy so the inner loop is a plain
// contiguous dot product (SSE2) and the work is split over all CPU cores.
AudioBuffer StudioResampler::convert(const AudioBuffer& source, double sourceRate, double destinationRate) {
    if (source.channels() == 0U) return AudioBuffer {};
    if (std::abs(sourceRate - destinationRate) < 1.0e-9) return source;
    const std::uint64_t outFrames = static_cast<std::uint64_t>(
        std::llround(static_cast<long double>(source.frames()) * destinationRate / sourceRate));
    const auto channels = static_cast<std::size_t>(source.channels());
    StudioResampler rs;
    rs.ratio_ = sourceRate / destinationRate;
    rs.designKernel(sourceRate, destinationRate);
    const int taps = rs.taps_;
    const int half = taps / 2;
    const std::size_t lead = static_cast<std::size_t>(half) + 1U;
    const std::size_t frames = source.frames();

    // Zero-padded copies: [lead zeros][signal][tail zeros].
    const std::size_t padded = lead + frames + static_cast<std::size_t>(taps) + 16U;
    std::vector<std::vector<float>> pad(channels, std::vector<float>(padded, 0.0F));
    for (std::size_t c = 0U; c < channels; ++c) std::copy_n(source.channelData(c), frames, pad[c].begin() + static_cast<std::ptrdiff_t>(lead));

    AudioBuffer out(source.channels(), static_cast<std::size_t>(outFrames));
    const double ratio = rs.ratio_;
    const float* table = rs.table_.data();
    auto work = [&](std::uint64_t n0, std::uint64_t n1) {
        std::vector<float> w(static_cast<std::size_t>(taps) + 4U);
        for (std::uint64_t n = n0; n < n1; ++n) {
            const double position = static_cast<double>(n) * ratio;
            const double base = std::floor(position);
            const double scaled = (position - base) * kPhases;
            const int p = std::clamp(static_cast<int>(scaled), 0, kPhases - 1);
            const float mix = static_cast<float>(scaled - static_cast<double>(p));
            const float* a = table + static_cast<std::size_t>(p) * static_cast<std::size_t>(taps);
            blendRows(a, a + taps, mix, w.data(), taps);
            // first source index = base - half + 1; the pad shifts it by `lead`.
            const std::size_t start = static_cast<std::size_t>(static_cast<std::int64_t>(base) - half + 1 + static_cast<std::int64_t>(lead));
            for (std::size_t c = 0U; c < channels; ++c) out.channelData(c)[n] = dotProduct(w.data(), pad[c].data() + start, taps);
        }
    };
    unsigned threads = std::max(1U, std::min(8U, std::thread::hardware_concurrency()));
    if (outFrames < 400000U) threads = 1U;
    if (threads == 1U) {
        work(0U, outFrames);
    } else {
        std::vector<std::thread> pool;
        const std::uint64_t chunk = (outFrames + threads - 1U) / threads;
        for (unsigned t = 0U; t < threads; ++t) {
            const std::uint64_t n0 = std::min<std::uint64_t>(outFrames, static_cast<std::uint64_t>(t) * chunk);
            const std::uint64_t n1 = std::min<std::uint64_t>(outFrames, n0 + chunk);
            if (n0 < n1) pool.emplace_back(work, n0, n1);
        }
        for (auto& th : pool) th.join();
    }
    return out;
}

void StudioRangeConverter::prepare(double sourceRate, double destinationRate) {
    if (!(sourceRate > 0.0) || !(destinationRate > 0.0) || !std::isfinite(sourceRate) || !std::isfinite(destinationRate))
        throw std::invalid_argument("StudioRangeConverter: sample rates must be positive");
    rs_ = StudioResampler {};
    rs_.ratio_ = sourceRate / destinationRate;
    rs_.designKernel(sourceRate, destinationRate);
}

std::uint64_t StudioRangeConverter::destinationFrames(std::uint64_t sourceFrames, double sourceRate, double destinationRate) noexcept {
    return static_cast<std::uint64_t>(std::llround(static_cast<long double>(sourceFrames) * destinationRate / sourceRate));
}

void StudioRangeConverter::sourceRange(std::uint64_t dstStart, std::uint32_t count, std::int64_t& first, std::uint32_t& length) const noexcept {
    first = 0;
    length = 0U;
    if (rs_.taps_ == 0 || count == 0U) return;
    const std::int64_t half = rs_.taps_ / 2;
    const auto baseFirst = static_cast<std::int64_t>(std::floor(static_cast<double>(dstStart) * rs_.ratio_));
    const auto baseLast = static_cast<std::int64_t>(std::floor(static_cast<double>(dstStart + count - 1U) * rs_.ratio_));
    first = baseFirst - half + 1;
    length = static_cast<std::uint32_t>(baseLast + half - first + 1);
}

void StudioRangeConverter::render(const float* const* source, std::uint32_t channels, std::int64_t first,
                                  std::uint64_t dstStart, std::uint32_t count, float* out, float* weights) const noexcept {
    if (rs_.taps_ == 0 || source == nullptr || out == nullptr || weights == nullptr) return;
    const int taps = rs_.taps_;
    const std::int64_t half = taps / 2;
    const float* table = rs_.table_.data();
    // The common 48 -> 96 kHz case only ever hits phases 0 and 1/2.
    // Use the already designed, unchanged sinc coefficient rows directly:
    // no intermediate conversion, allocations or repeated weight blending.
    // Output is sample-for-sample identical to the generic polyphase path.
    if (rs_.ratio_ == 0.5) {
        const float* phase[2] = {table, table + static_cast<std::size_t>(StudioResampler::kPhases / 2) * taps};
        for (std::uint32_t i = 0U; i < count; ++i) {
            const std::uint64_t frame = dstStart + i;
            const std::int64_t base = static_cast<std::int64_t>(frame / 2U);
            const auto start = static_cast<std::size_t>(base - half + 1 - first);
            const float* weights2x = phase[static_cast<std::size_t>(frame & 1U)];
            for (std::uint32_t c = 0U; c < channels; ++c)
                out[static_cast<std::size_t>(i) * channels + c] = dotProduct(weights2x, source[c] + start, taps);
        }
        return;
    }
    for (std::uint32_t i = 0U; i < count; ++i) {
        const double position = static_cast<double>(dstStart + i) * rs_.ratio_;
        const double base = std::floor(position);
        const double scaled = (position - base) * StudioResampler::kPhases;
        const int p = std::clamp(static_cast<int>(scaled), 0, StudioResampler::kPhases - 1);
        const float mix = static_cast<float>(scaled - static_cast<double>(p));
        const float* a = table + static_cast<std::size_t>(p) * static_cast<std::size_t>(taps);
        blendRows(a, a + taps, mix, weights, taps);
        const auto start = static_cast<std::size_t>(static_cast<std::int64_t>(base) - half + 1 - first);
        for (std::uint32_t c = 0U; c < channels; ++c)
            out[static_cast<std::size_t>(i) * channels + c] = dotProduct(weights, source[c] + start, taps);
    }
}

} // namespace silveton
