#include "silveton/Metronome.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace silveton {

std::size_t MetronomeClock::eventsForBlock(const TempoMap& tempoMap,
                                           std::int64_t blockStartSample,
                                           std::uint32_t frames,
                                           MetronomeBeatEvent* output,
                                           std::size_t capacity) noexcept {
    if (frames == 0U || output == nullptr || capacity == 0U) return 0U;
    const std::int64_t blockEnd = blockStartSample > std::numeric_limits<std::int64_t>::max() - static_cast<std::int64_t>(frames)
        ? std::numeric_limits<std::int64_t>::max()
        : blockStartSample + static_cast<std::int64_t>(frames);

    std::size_t count = 0U;
    std::int64_t segmentStart = blockStartSample;
    std::int64_t lastEventSample = std::numeric_limits<std::int64_t>::min();
    constexpr double epsilon = 1.0e-10;

    while (segmentStart < blockEnd && count < capacity) {
        const auto position = tempoMap.positionAtSample(segmentStart);
        const double quarterPerBeat = 4.0 / static_cast<double>(position.denominator);
        const double qStart = position.quarterNotes;
        const double relative = (qStart - position.barStartQuarterNotes) / quarterPerBeat;
        double beatIndex = std::ceil(relative - epsilon);
        if (beatIndex < 0.0) beatIndex = 0.0;
        double qBeat = position.barStartQuarterNotes + beatIndex * quarterPerBeat;

        const std::int64_t nextChange = tempoMap.nextChangeSampleAfter(segmentStart);
        const std::int64_t segmentEnd = std::min(blockEnd, nextChange);
        for (;;) {
            const std::int64_t beatSample = tempoMap.sampleAtQuarterNotes(qBeat);
            if (beatSample >= segmentEnd) break;
            if (beatSample >= segmentStart && beatSample >= blockStartSample && beatSample != lastEventSample) {
                const auto beatPosition = tempoMap.positionAtSample(beatSample);
                const std::int64_t frameOffset64 = beatSample - blockStartSample;
                if (frameOffset64 >= 0 && frameOffset64 <= std::numeric_limits<std::int32_t>::max()) {
                    output[count++] = {static_cast<std::int32_t>(frameOffset64),
                                       beatPosition.bar,
                                       beatPosition.beat,
                                       beatPosition.beat == 1U};
                    lastEventSample = beatSample;
                    if (count >= capacity) return count;
                }
            }
            qBeat += quarterPerBeat;
        }

        if (nextChange == std::numeric_limits<std::int64_t>::max() || nextChange >= blockEnd) break;
        segmentStart = nextChange;
    }
    return count;
}

std::int64_t CountInPlanner::startSample(const TempoMap& tempoMap,
                                         std::int64_t recordStartSample,
                                         std::uint32_t bars) noexcept {
    if (bars == 0U || recordStartSample <= 0) return std::max<std::int64_t>(0, recordStartSample);
    const TempoMapPosition recordPosition = tempoMap.positionAtSample(recordStartSample);
    const double recordQuarter = recordPosition.quarterNotes;
    double barStartQuarter = recordPosition.barStartQuarterNotes;
    std::int64_t barStartSample = tempoMap.sampleAtQuarterNotes(barStartQuarter);

    for (std::uint32_t i = 0U; i < bars; ++i) {
        if (barStartSample <= 0) return 0;
        const TempoMapPosition previous = tempoMap.positionAtSample(barStartSample - 1);
        const double previousBarStartQuarter = previous.barStartQuarterNotes;
        const std::int64_t previousBarStartSample = tempoMap.sampleAtQuarterNotes(previousBarStartQuarter);
        if (previousBarStartSample >= barStartSample) return 0;
        barStartQuarter = previousBarStartQuarter;
        barStartSample = previousBarStartSample;
    }

    const double currentBarStartQuarter = recordPosition.barStartQuarterNotes;
    const double barsQuarterSpan = currentBarStartQuarter - barStartQuarter;
    const double targetQuarter = recordQuarter - barsQuarterSpan;
    return std::max<std::int64_t>(0, tempoMap.sampleAtQuarterNotes(targetQuarter));
}

} // namespace silveton
