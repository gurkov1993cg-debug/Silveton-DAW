#include "silveton/RecordingWorkflow.h"
#include "silveton/TakeComp.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace silveton {

RecordingWorkflow::RecordingWorkflow(AudioEngine& engine, Project& project, std::size_t trackIndex)
    : engine_(engine), project_(project), trackIndex_(trackIndex) {
    if (trackIndex_ >= project_.tracks.size()) throw std::out_of_range("recording workflow track index");
}

RecordingWorkflow::~RecordingWorkflow() {
    if (active_) {
        engine_.detachRecorderAndWait();
        recorder_.stop();
        restorePunchState();
    }
}

ProjectTrack& RecordingWorkflow::track() { return project_.tracks.at(trackIndex_); }

void RecordingWorkflow::startRecorder(const std::string& audioPath,
                                      std::uint32_t channels,
                                      std::uint32_t ringCapacityFrames) {
    if (active_) throw std::logic_error("recording workflow already active");
    if (audioPath.empty()) throw std::invalid_argument("recording path is empty");
    const double sampleRate = engine_.deviceConfig().sampleRate;
    if (!std::isfinite(sampleRate) || sampleRate <= 0.0 ||
        sampleRate > static_cast<double>(std::numeric_limits<std::uint32_t>::max()))
        throw std::invalid_argument("recording sample rate cannot be represented");
    const auto integerRate = static_cast<std::uint32_t>(std::llround(sampleRate));
    if (std::abs(sampleRate - static_cast<double>(integerRate)) > 1.0e-6)
        throw std::invalid_argument("recorder requires an integer sample rate");

    recorder_.prepare(channels, integerRate, ringCapacityFrames);
    recorder_.start(audioPath);
    audioPath_ = audioPath;
    engine_.setRecorder(&recorder_);
    active_ = true;
}

void RecordingWorkflow::start(const std::string& audioPath,
                              std::uint32_t channels,
                              std::uint32_t ringCapacityFrames) {
    countInArmed_ = false;
    countInStartSample_ = 0;
    scheduledRecordStartSample_ = 0;
    restorePunchOnStop_ = false;
    startRecorder(audioPath, channels, ringCapacityFrames);
}

void RecordingWorkflow::startWithCountIn(const std::string& audioPath,
                                         std::uint32_t channels,
                                         std::int64_t recordStartSample,
                                         std::int64_t recordEndSample,
                                         std::uint32_t countInBars,
                                         std::uint32_t ringCapacityFrames) {
    if (active_) throw std::logic_error("recording workflow already active");
    if (recordStartSample < 0 || recordEndSample <= recordStartSample)
        throw std::invalid_argument("invalid scheduled recording range");

    previousPunchEnabled_ = engine_.punchEnabled();
    previousPunchIn_ = engine_.punchInSample();
    previousPunchOut_ = engine_.punchOutSample();
    restorePunchOnStop_ = true;
    countInStartSample_ = CountInPlanner::startSample(project_.tempoMap, recordStartSample, countInBars);
    scheduledRecordStartSample_ = recordStartSample;
    countInArmed_ = countInStartSample_ < recordStartSample;

    try {
        engine_.setPunchRange(true, recordStartSample, recordEndSample);
        engine_.transport().seekSamples(countInStartSample_);
        startRecorder(audioPath, channels, ringCapacityFrames);
        engine_.transport().play();
    } catch (...) {
        restorePunchState();
        countInArmed_ = false;
        throw;
    }
}

void RecordingWorkflow::restorePunchState() noexcept {
    if (!restorePunchOnStop_) return;
    try {
        if (previousPunchEnabled_)
            engine_.setPunchRange(true, previousPunchIn_, previousPunchOut_);
        else
            engine_.setPunchRange(false, 0, 0);
    } catch (...) {
        // Previous punch values came from AudioEngine itself and were valid.
        // Keep destruction/stop noexcept even if future validation changes.
    }
    restorePunchOnStop_ = false;
    countInArmed_ = false;
}

std::vector<std::uint64_t> RecordingWorkflow::stopAndCommitTakes() {
    if (!active_) throw std::logic_error("recording workflow is not active");
    engine_.detachRecorderAndWait();
    recorder_.stop();
    active_ = false;
    restorePunchState();

    const RecorderStatus recorderStatus = recorder_.status();
    if (recorderStatus.faulted || recorderStatus.writerError || recorderStatus.overflowed)
        throw std::runtime_error("recording take is faulted and was not committed");
    if (recorderStatus.framesAccepted != recorderStatus.framesWritten)
        throw std::runtime_error("recording take was not fully written");

    const auto spans = engine_.recordedTimelineSpans();
    auto lanes = TakeLaneBuilder::fromRecordedTimelineSpans(
        audioPath_, recorderStatus.framesWritten, spans, engine_.recordedTimelineSpanOverflowed(),
        recorder_.channels(), recorder_.sampleRate());
    if (lanes.empty()) return {};

    std::uint64_t maximumLaneId = 0U;
    for (const auto& lane : track().takeLanes) maximumLaneId = std::max(maximumLaneId, lane.id);
    if (maximumLaneId > std::numeric_limits<std::uint64_t>::max() - lanes.size())
        throw std::overflow_error("take lane id exhausted");

    std::vector<std::uint64_t> committedIds;
    committedIds.reserve(lanes.size());
    for (auto& lane : lanes) {
        lane.id = ++maximumLaneId;
        lane.name = "Take " + std::to_string(track().takeLanes.size() + 1U);
        committedIds.push_back(lane.id);
        track().takeLanes.push_back(std::move(lane));
    }
    return committedIds;
}

void RecordingWorkflow::promoteTakeToComp(std::uint64_t takeLaneId,
                                          std::uint64_t crossfadeSamples) {
    if (active_) throw std::logic_error("cannot comp while recording is active");
    const auto laneIt = std::find_if(track().takeLanes.begin(), track().takeLanes.end(),
                                     [takeLaneId](const auto& lane) { return lane.id == takeLaneId; });
    if (laneIt == track().takeLanes.end()) throw std::out_of_range("take lane id");
    CompEditor editor(project_, trackIndex_);
    for (const auto& clip : laneIt->clips) {
        if (clip.lengthSamples > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()) ||
            clip.timelineStartSample > std::numeric_limits<std::int64_t>::max() - static_cast<std::int64_t>(clip.lengthSamples))
            throw std::overflow_error("take clip timeline overflow");
        const std::int64_t end = clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples);
        (void)editor.selectRange(laneIt->id, clip.id, clip.timelineStartSample, end, crossfadeSamples);
    }
}

} // namespace silveton
