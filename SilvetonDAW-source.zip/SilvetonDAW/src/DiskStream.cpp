#include "silveton/DiskStream.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <utility>
#if !defined(_WIN32)
#include <sys/types.h>
#include <sys/resource.h>
#endif

namespace silveton {
namespace {

template <typename T>
T readLEFile(std::FILE* file) {
    T value {};
    if (std::fread(&value, sizeof(T), 1U, file) != 1U) throw std::runtime_error("unexpected WAV EOF");
    return value;
}

std::uint32_t readTag(std::FILE* file) {
    std::uint8_t b[4] {};
    if (std::fread(b, 1U, 4U, file) != 4U) throw std::runtime_error("unexpected WAV EOF");
    return static_cast<std::uint32_t>(b[0]) |
           (static_cast<std::uint32_t>(b[1]) << 8U) |
           (static_cast<std::uint32_t>(b[2]) << 16U) |
           (static_cast<std::uint32_t>(b[3]) << 24U);
}

constexpr std::uint32_t tag4(char a, char b, char c, char d) noexcept {
    return static_cast<std::uint32_t>(static_cast<unsigned char>(a)) |
           (static_cast<std::uint32_t>(static_cast<unsigned char>(b)) << 8U) |
           (static_cast<std::uint32_t>(static_cast<unsigned char>(c)) << 16U) |
           (static_cast<std::uint32_t>(static_cast<unsigned char>(d)) << 24U);
}

bool seek64(std::FILE* file, std::uint64_t offset) noexcept {
#if defined(_WIN32)
    return _fseeki64(file, static_cast<__int64>(offset), SEEK_SET) == 0;
#else
    if (offset > static_cast<std::uint64_t>(std::numeric_limits<off_t>::max())) return false;
    return fseeko(file, static_cast<off_t>(offset), SEEK_SET) == 0;
#endif
}

} // namespace

DiskAudioSource::DiskAudioSource(std::string path,
                                 std::uint32_t sampleRate,
                                 std::uint32_t channels,
                                 std::uint16_t formatTag,
                                 std::uint16_t bitsPerSample,
                                 std::uint16_t blockAlign,
                                 std::uint64_t dataOffset,
                                 std::uint64_t dataBytes,
                                 std::uint32_t cacheFrames)
    : path_(std::move(path)),
      sampleRate_(sampleRate),
      channels_(channels),
      formatTag_(formatTag),
      bitsPerSample_(bitsPerSample),
      blockAlign_(blockAlign),
      dataOffset_(dataOffset),
      totalFrames_(blockAlign == 0U ? 0U : dataBytes / blockAlign),
      cacheFrames_(cacheFrames) {
    if (cacheFrames_ == 0U) throw std::invalid_argument("disk cache must contain frames");
    if (channels_ == 0U || totalFrames_ == 0U) throw std::invalid_argument("disk source has no audio frames");
    const std::uint64_t samples = static_cast<std::uint64_t>(cacheFrames_) * channels_;
    if (samples > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
        throw std::length_error("disk cache size overflow");
    for (auto& page : pages_) page.interleaved.assign(static_cast<std::size_t>(samples), 0.0F);
}

bool DiskAudioSource::pageContains(std::uint32_t pageIndex,
                                   std::uint64_t sourceFrame,
                                   std::uint32_t frames) const noexcept {
    if (pageIndex >= pages_.size()) return false;
    const auto& page = pages_[pageIndex];
    if (!page.valid.load(std::memory_order_acquire)) return false;
    const std::uint64_t start = page.startFrame.load(std::memory_order_acquire);
    const std::uint64_t validFrames = page.validFrames.load(std::memory_order_acquire);
    const std::uint64_t end = start + validFrames;
    const std::uint64_t requestedEnd = sourceFrame + static_cast<std::uint64_t>(frames);
    return sourceFrame >= start && requestedEnd >= sourceFrame && requestedEnd <= end;
}

void DiskAudioSource::request(std::uint64_t sourceFrame) noexcept {
    const std::uint64_t clamped = totalFrames_ == 0U ? 0U : std::min(sourceFrame, totalFrames_ - 1U);
    requestedFrame_.store(clamped, std::memory_order_release);
}

bool DiskAudioSource::acquire(std::uint64_t sourceFrame,
                              std::uint32_t frames,
                              DiskBlockView& view) noexcept {
    view = {};
    if (frames == 0U) return true;
    if (sourceFrame >= totalFrames_ || static_cast<std::uint64_t>(frames) > totalFrames_ - sourceFrame) {
        underflowBlocks_.fetch_add(1U, std::memory_order_relaxed);
        underflowFrames_.fetch_add(frames, std::memory_order_relaxed);
        return false;
    }

    request(sourceFrame);
    const std::uint32_t active = activePage_.load(std::memory_order_acquire) % static_cast<std::uint32_t>(pages_.size());
    const std::array<std::uint32_t, 3U> order {{active, static_cast<std::uint32_t>((active + 1U) % 3U), static_cast<std::uint32_t>((active + 2U) % 3U)}};

    for (const std::uint32_t index : order) {
        auto& page = pages_[index];
        if (!pageContains(index, sourceFrame, frames)) continue;

        page.readers.fetch_add(1U, std::memory_order_acq_rel);
        if (!pageContains(index, sourceFrame, frames)) {
            page.readers.fetch_sub(1U, std::memory_order_acq_rel);
            continue;
        }

        const std::uint64_t pageStart = page.startFrame.load(std::memory_order_acquire);
        view.interleaved = page.interleaved.data();
        view.channels = channels_;
        view.frames = frames;
        view.frameOffset = static_cast<std::uint32_t>(sourceFrame - pageStart);
        view.pageIndex = index;
        view.acquired = true;
        if (index != active) activePage_.store(index, std::memory_order_release);
        return true;
    }

    underflowBlocks_.fetch_add(1U, std::memory_order_relaxed);
    underflowFrames_.fetch_add(frames, std::memory_order_relaxed);
    return false;
}

void DiskAudioSource::release(DiskBlockView& view) noexcept {
    if (!view.acquired || view.pageIndex >= pages_.size()) {
        view = {};
        return;
    }
    pages_[view.pageIndex].readers.fetch_sub(1U, std::memory_order_acq_rel);
    view = {};
}

DiskStreamStatus DiskAudioSource::status() const noexcept {
    return {
        ioError_.load(std::memory_order_acquire),
        cacheLoads_.load(std::memory_order_acquire),
        underflowBlocks_.load(std::memory_order_acquire),
        underflowFrames_.load(std::memory_order_acquire)
    };
}

void DiskAudioSource::clearUnderflowCounters() noexcept {
    underflowBlocks_.store(0U, std::memory_order_release);
    underflowFrames_.store(0U, std::memory_order_release);
}

DiskStreamManager::DiskStreamManager(std::size_t maxOpenFiles) {
    std::size_t safeAutomaticLimit = 192U;
#if !defined(_WIN32)
    struct rlimit limit {};
    if (getrlimit(RLIMIT_NOFILE, &limit) == 0) {
        rlim_t desired = limit.rlim_cur;
        const rlim_t target = static_cast<rlim_t>(1024U);
        if (desired < target) {
            desired = limit.rlim_max == RLIM_INFINITY ? target : std::min(limit.rlim_max, target);
            struct rlimit raised {desired, limit.rlim_max};
            (void)setrlimit(RLIMIT_NOFILE, &raised);
            (void)getrlimit(RLIMIT_NOFILE, &limit);
        }
        if (limit.rlim_cur != RLIM_INFINITY) {
            const std::size_t current = static_cast<std::size_t>(limit.rlim_cur);
            safeAutomaticLimit = current > 64U ? current - 32U : std::max<std::size_t>(8U, current / 2U);
        } else {
            safeAutomaticLimit = 512U;
        }
    }
#endif
    maxOpenFiles_ = maxOpenFiles == 0U
        ? std::max<std::size_t>(1U, std::min<std::size_t>(512U, safeAutomaticLimit))
        : std::max<std::size_t>(1U, maxOpenFiles);
    openFiles_.reserve(maxOpenFiles_);
    sources_.reserve(kMaxSources);
}

DiskStreamManager::~DiskStreamManager() {
    stop();
    closeFiles();
}

DiskStreamManager::WavMeta DiskStreamManager::inspectWav(const std::string& path) {
    std::FILE* file = std::fopen(path.c_str(), "rb");
    if (file == nullptr) throw std::runtime_error("cannot open WAV for disk streaming");
    try {
        const std::uint32_t container = readTag(file);
        if (container != tag4('R','I','F','F') && container != tag4('R','F','6','4'))
            throw std::runtime_error("disk stream requires RIFF/RF64 WAV");
        (void)readLEFile<std::uint32_t>(file);
        if (readTag(file) != tag4('W','A','V','E')) throw std::runtime_error("disk stream file is not WAVE");

        std::uint64_t rf64DataBytes = 0U;
        WavMeta meta;
        bool haveFmt = false;
        bool haveData = false;

        for (int chunk = 0; chunk < 128 && !(haveFmt && haveData); ++chunk) {
            const std::uint32_t id = readTag(file);
            const std::uint32_t size32 = readLEFile<std::uint32_t>(file);
            const auto chunkData = static_cast<std::uint64_t>(
#if defined(_WIN32)
                _ftelli64(file)
#else
                ftello(file)
#endif
            );

            if (id == tag4('d','s','6','4')) {
                if (size32 < 28U) throw std::runtime_error("invalid RF64 ds64 chunk");
                (void)readLEFile<std::uint64_t>(file);
                rf64DataBytes = readLEFile<std::uint64_t>(file);
                (void)readLEFile<std::uint64_t>(file);
                (void)readLEFile<std::uint32_t>(file);
            } else if (id == tag4('f','m','t',' ')) {
                if (size32 < 16U) throw std::runtime_error("invalid WAV fmt chunk");
                meta.formatTag = readLEFile<std::uint16_t>(file);
                meta.channels = readLEFile<std::uint16_t>(file);
                meta.sampleRate = readLEFile<std::uint32_t>(file);
                (void)readLEFile<std::uint32_t>(file);
                meta.blockAlign = readLEFile<std::uint16_t>(file);
                meta.bitsPerSample = readLEFile<std::uint16_t>(file);
                haveFmt = true;
            } else if (id == tag4('d','a','t','a')) {
                meta.dataOffset = chunkData;
                meta.dataBytes = size32 == 0xFFFFFFFFU ? rf64DataBytes : size32;
                haveData = true;
            }

            std::uint64_t skipBytes = size32;
            if (id == tag4('d','a','t','a') && size32 == 0xFFFFFFFFU) skipBytes = meta.dataBytes;
            const std::uint64_t next = chunkData + skipBytes + (skipBytes & 1U);
            if (!seek64(file, next)) {
                if (!(haveFmt && haveData)) throw std::runtime_error("WAV chunk seek failed");
            }
        }

        if (!haveFmt || !haveData || meta.channels == 0U || meta.sampleRate == 0U || meta.blockAlign == 0U || meta.dataBytes == 0U)
            throw std::runtime_error("incomplete WAV for disk streaming");
        const bool float32 = meta.formatTag == 3U && meta.bitsPerSample == 32U;
        const bool pcm16 = meta.formatTag == 1U && meta.bitsPerSample == 16U;
        if (!float32 && !pcm16) throw std::runtime_error("disk streaming supports Float32 and PCM16 WAV");
        const std::uint32_t expectedAlign = meta.channels * (meta.bitsPerSample / 8U);
        if (meta.blockAlign != expectedAlign) throw std::runtime_error("unsupported WAV block alignment");

        std::fclose(file);
        return meta;
    } catch (...) {
        std::fclose(file);
        throw;
    }
}

DiskAudioSource& DiskStreamManager::addSource(const std::string& path, std::uint32_t cacheFrames) {
    if (running()) throw std::logic_error("cannot add disk source while streaming manager is running");
    if (path.empty()) throw std::invalid_argument("disk source path is empty");
    if (sources_.size() >= kMaxSources) throw std::length_error("Silveton session disk-source limit is 256");
    const auto meta = inspectWav(path);
    auto source = std::unique_ptr<DiskAudioSource>(new DiskAudioSource(path,
                                                                      meta.sampleRate,
                                                                      meta.channels,
                                                                      meta.formatTag,
                                                                      meta.bitsPerSample,
                                                                      meta.blockAlign,
                                                                      meta.dataOffset,
                                                                      meta.dataBytes,
                                                                      cacheFrames));
    DiskAudioSource& ref = *source;
    sources_.push_back(std::move(source));
    return ref;
}

void DiskStreamManager::clearSources() {
    if (running()) throw std::logic_error("cannot clear disk sources while streaming manager is running");
    sources_.clear();
    closeFiles();
}

DiskAudioSource& DiskStreamManager::source(std::size_t index) {
    if (index >= sources_.size()) throw std::out_of_range("disk source index");
    return *sources_[index];
}

const DiskAudioSource& DiskStreamManager::source(std::size_t index) const {
    if (index >= sources_.size()) throw std::out_of_range("disk source index");
    return *sources_[index];
}

std::FILE* DiskStreamManager::acquireFile(const std::string& path) noexcept {
    ++fileUseCounter_;
    for (auto& entry : openFiles_) {
        if (entry.path == path && entry.file != nullptr) {
            entry.lastUse = fileUseCounter_;
            return entry.file;
        }
    }

    std::FILE* opened = std::fopen(path.c_str(), "rb");
    if (opened == nullptr) return nullptr;

    if (openFiles_.size() < maxOpenFiles_) {
        openFiles_.push_back({path, opened, fileUseCounter_});
        return opened;
    }

    auto lru = std::min_element(openFiles_.begin(), openFiles_.end(), [](const OpenFile& a, const OpenFile& b) {
        return a.lastUse < b.lastUse;
    });
    if (lru == openFiles_.end()) {
        std::fclose(opened);
        return nullptr;
    }
    if (lru->file != nullptr) std::fclose(lru->file);
    *lru = {path, opened, fileUseCounter_};
    return opened;
}

void DiskStreamManager::closeFiles() noexcept {
    for (auto& entry : openFiles_) {
        if (entry.file != nullptr) std::fclose(entry.file);
        entry.file = nullptr;
    }
    openFiles_.clear();
}

std::uint32_t DiskStreamManager::chooseFillPage(const DiskAudioSource& source,
                                                std::uint32_t avoidPage) const noexcept {
    const std::uint32_t active = source.activePage_.load(std::memory_order_acquire) % 3U;
    for (std::uint32_t i = 0U; i < 3U; ++i) {
        if (i == active || i == avoidPage) continue;
        if (!source.pages_[i].valid.load(std::memory_order_acquire)) return i;
    }
    for (std::uint32_t i = 0U; i < 3U; ++i) {
        if (i != active && i != avoidPage) return i;
    }
    return (active + 1U) % 3U;
}

bool DiskStreamManager::fillPage(DiskAudioSource& source,
                                 std::uint32_t pageIndex,
                                 std::uint64_t startFrame) noexcept {
    if (pageIndex >= source.pages_.size() || startFrame >= source.totalFrames_) return false;
    auto& page = source.pages_[pageIndex];

    page.valid.store(false, std::memory_order_release);
    while (page.readers.load(std::memory_order_acquire) != 0U && !stopRequested_.load(std::memory_order_acquire))
        std::this_thread::yield();
    if (stopRequested_.load(std::memory_order_acquire)) return false;

    const std::uint64_t remaining = source.totalFrames_ - startFrame;
    const std::uint32_t frames = static_cast<std::uint32_t>(std::min<std::uint64_t>(source.cacheFrames_, remaining));
    const std::uint64_t byteOffset = source.dataOffset_ + startFrame * source.blockAlign_;
    std::FILE* file = acquireFile(source.path_);
    if (file == nullptr || !seek64(file, byteOffset)) {
        source.ioError_.store(true, std::memory_order_release);
        return false;
    }

    const std::size_t samples = static_cast<std::size_t>(frames) * source.channels_;
    if (source.formatTag_ == 3U && source.bitsPerSample_ == 32U) {
        if (std::fread(page.interleaved.data(), sizeof(float), samples, file) != samples) {
            source.ioError_.store(true, std::memory_order_release);
            return false;
        }
    } else if (source.formatTag_ == 1U && source.bitsPerSample_ == 16U) {
        const std::size_t bytes = samples * sizeof(std::int16_t);
        if (readScratch_.size() < bytes) readScratch_.resize(bytes);
        if (std::fread(readScratch_.data(), 1U, bytes, file) != bytes) {
            source.ioError_.store(true, std::memory_order_release);
            return false;
        }
        const auto* input = reinterpret_cast<const std::int16_t*>(readScratch_.data());
        for (std::size_t i = 0U; i < samples; ++i) page.interleaved[i] = static_cast<float>(input[i]) / 32768.0F;
    } else {
        source.ioError_.store(true, std::memory_order_release);
        return false;
    }

    page.startFrame.store(startFrame, std::memory_order_relaxed);
    page.validFrames.store(frames, std::memory_order_relaxed);
    page.valid.store(true, std::memory_order_release);
    source.cacheLoads_.fetch_add(1U, std::memory_order_relaxed);
    return true;
}

void DiskStreamManager::service(DiskAudioSource& source) noexcept {
    if (source.ioError_.load(std::memory_order_acquire) || source.totalFrames_ == 0U) return;
    const std::uint64_t request = source.requestedFrame_.load(std::memory_order_acquire);

    std::uint32_t containing = 3U;
    for (std::uint32_t i = 0U; i < 3U; ++i) {
        if (source.pageContains(i, request, 1U)) {
            containing = i;
            break;
        }
    }

    if (containing == 3U) {
        const std::uint64_t aligned = (request / source.cacheFrames_) * source.cacheFrames_;
        const std::uint32_t target = chooseFillPage(source, 3U);
        (void)fillPage(source, target, aligned);
        containing = target;
    }

    if (containing < 3U && source.pages_[containing].valid.load(std::memory_order_acquire)) {
        const std::uint64_t start = source.pages_[containing].startFrame.load(std::memory_order_acquire);
        const std::uint64_t count = source.pages_[containing].validFrames.load(std::memory_order_acquire);
        const std::uint64_t nextStart = start + count;
        if (count != 0U && nextStart < source.totalFrames_) {
            bool haveNext = false;
            for (std::uint32_t i = 0U; i < 3U; ++i) {
                if (source.pageContains(i, nextStart, 1U)) {
                    haveNext = true;
                    break;
                }
            }
            if (!haveNext) {
                const std::uint32_t target = chooseFillPage(source, containing);
                (void)fillPage(source, target, nextStart);
            }
        }
    }
}

void DiskStreamManager::workerLoop() noexcept {
    while (!stopRequested_.load(std::memory_order_acquire)) {
        bool didWork = false;
        for (auto& source : sources_) {
            const auto before = source->cacheLoads_.load(std::memory_order_relaxed);
            service(*source);
            didWork = didWork || source->cacheLoads_.load(std::memory_order_relaxed) != before;
            if (stopRequested_.load(std::memory_order_acquire)) break;
        }
        if (!didWork) std::this_thread::sleep_for(std::chrono::microseconds(250));
    }
}

void DiskStreamManager::start() {
    if (running()) throw std::logic_error("disk streaming manager already running");
    stopRequested_.store(false, std::memory_order_release);
    running_.store(true, std::memory_order_release);
    try {
        worker_ = std::thread(&DiskStreamManager::workerLoop, this);
    } catch (...) {
        running_.store(false, std::memory_order_release);
        throw;
    }
}

void DiskStreamManager::stop() noexcept {
    stopRequested_.store(true, std::memory_order_release);
    if (worker_.joinable()) worker_.join();
    running_.store(false, std::memory_order_release);
    closeFiles();
}

bool DiskStreamManager::prime(std::uint64_t sourceFrame, std::uint32_t timeoutMilliseconds) {
    if (!running()) throw std::logic_error("disk streaming manager is not running");
    for (auto& source : sources_) source->request(sourceFrame);

    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMilliseconds);
    for (;;) {
        bool ready = true;
        for (auto& source : sources_) {
            if (source->ioError_.load(std::memory_order_acquire)) return false;
            bool sourceReady = false;
            if (sourceFrame < source->totalFrames_) {
                for (std::uint32_t i = 0U; i < 3U; ++i) {
                    if (source->pageContains(i, sourceFrame, 1U)) {
                        sourceReady = true;
                        break;
                    }
                }
            }
            ready = ready && sourceReady;
        }
        if (ready) return true;
        if (std::chrono::steady_clock::now() >= deadline) return false;
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

} // namespace silveton
