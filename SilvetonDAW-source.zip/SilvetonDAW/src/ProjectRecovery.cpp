#include "silveton/ProjectRecovery.h"
#include <cerrno>
#include <cstdio>
#include <fstream>
#include <stdexcept>
#include <utility>

namespace silveton {
namespace {

bool fileExists(const std::string& path) noexcept {
    std::ifstream in(path.c_str(), std::ios::binary);
    return static_cast<bool>(in);
}

void replaceFileWithValidatedProject(const Project& project,
                                     const std::string& target,
                                     const std::string* backup) {
    if (target.empty()) throw std::invalid_argument("project target path is empty");
    const std::string temp = target + ".tmp";
    (void)std::remove(temp.c_str());

    project.save(temp);
    try {
        (void)Project::load(temp);
    } catch (...) {
        (void)std::remove(temp.c_str());
        throw;
    }

    bool rotated = false;
    if (backup != nullptr && fileExists(target)) {
        (void)std::remove(backup->c_str());
        if (std::rename(target.c_str(), backup->c_str()) != 0) {
            (void)std::remove(temp.c_str());
            throw std::runtime_error("cannot rotate project backup");
        }
        rotated = true;
    } else {
        (void)std::remove(target.c_str());
    }

    if (std::rename(temp.c_str(), target.c_str()) != 0) {
        const int renameError = errno;
        (void)std::remove(temp.c_str());
        if (rotated && backup != nullptr) {
            (void)std::rename(backup->c_str(), target.c_str());
        }
        throw std::runtime_error("cannot replace project file, errno=" + std::to_string(renameError));
    }
}

} // namespace

std::string ProjectRecovery::backupPath(const std::string& projectPath) {
    if (projectPath.empty()) throw std::invalid_argument("project path is empty");
    return projectPath + ".bak";
}

std::string ProjectRecovery::autosavePath(const std::string& projectPath) {
    if (projectPath.empty()) throw std::invalid_argument("project path is empty");
    return projectPath + ".autosave";
}

void ProjectRecovery::safeSave(const Project& project, const std::string& projectPath) {
    const std::string backup = backupPath(projectPath);
    replaceFileWithValidatedProject(project, projectPath, &backup);
}

void ProjectRecovery::autosave(const Project& project, const std::string& projectPath) {
    const std::string autosaveFile = autosavePath(projectPath);
    replaceFileWithValidatedProject(project, autosaveFile, nullptr);
}

ProjectRecoveryResult ProjectRecovery::loadBestAvailable(const std::string& projectPath) {
    if (projectPath.empty()) throw std::invalid_argument("project path is empty");
    const std::string autosaveFile = autosavePath(projectPath);
    const std::string backupFile = backupPath(projectPath);

    struct Candidate { const std::string* path; ProjectRecoverySource source; };
    const Candidate candidates[] = {
        {&projectPath, ProjectRecoverySource::Primary},
        {&autosaveFile, ProjectRecoverySource::Autosave},
        {&backupFile, ProjectRecoverySource::Backup}
    };

    std::string lastError;
    for (const auto& candidate : candidates) {
        if (!fileExists(*candidate.path)) continue;
        try {
            ProjectRecoveryResult result;
            result.project = Project::load(*candidate.path);
            result.source = candidate.source;
            result.path = *candidate.path;
            return result;
        } catch (const std::exception& e) {
            lastError = e.what();
        }
    }
    throw std::runtime_error(lastError.empty() ? "no recoverable project file" : "no recoverable project file: " + lastError);
}

} // namespace silveton
