// Silveton Native effects: Contour EQ, Press Compressor, Gate, Ceiling Limiter,
// Echo Delay, Space Reverb, Drive Saturator, Ensemble Chorus.
//
// All processing is double precision internally, allocation-free in render(),
// and every buffer is sized in onPrepare().
#include "internal/NativePluginFactories.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <vector>

namespace silveton::native_detail {
namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr double kTwoPi = 2.0 * kPi;

inline double dbToGain(double db) noexcept { return std::pow(10.0, db / 20.0); }
inline double gainToDb(double g) noexcept { return 20.0 * std::log10(std::max(g, 1.0e-12)); }
inline double timeCoef(double seconds, double sr) noexcept {
    return seconds <= 0.0 ? 0.0 : std::exp(-1.0 / (seconds * sr));
}
inline bool isOn(double v) noexcept { return v >= 0.5; }

NativeParameterInfo lin(std::uint32_t id, const char* name, const char* units, double mn, double mx, double def) {
    NativeParameterInfo p; p.id = id; p.name = name; p.units = units; p.minValue = mn; p.maxValue = mx; p.defaultValue = def;
    p.scale = NativeParamScale::Linear; return p;
}
NativeParameterInfo logp(std::uint32_t id, const char* name, const char* units, double mn, double mx, double def) {
    NativeParameterInfo p = lin(id, name, units, mn, mx, def); p.scale = NativeParamScale::Logarithmic; return p;
}
NativeParameterInfo toggle(std::uint32_t id, const char* name, bool def) {
    NativeParameterInfo p = lin(id, name, "", 0.0, 1.0, def ? 1.0 : 0.0); p.scale = NativeParamScale::Toggle; return p;
}
NativeParameterInfo choice(std::uint32_t id, const char* name, std::vector<std::string> choices, std::size_t def) {
    NativeParameterInfo p = lin(id, name, "", 0.0, static_cast<double>(choices.size() - 1U), static_cast<double>(def));
    p.scale = NativeParamScale::Choice; p.choices = std::move(choices); return p;
}
NativeParameterInfo integer(std::uint32_t id, const char* name, const char* units, double mn, double mx, double def) {
    NativeParameterInfo p = lin(id, name, units, mn, mx, def); p.scale = NativeParamScale::Integer; return p;
}

const NativePluginInfo& infoFor(const char* classId) {
    for (const auto& i : nativePluginCatalog()) if (i.classId == classId) return i;
    throw std::logic_error("native catalog entry missing");
}

// ---------------------------------------------------------------- biquads --
struct BiquadCoeffs { double b0 {1.0}, b1 {0.0}, b2 {0.0}, a1 {0.0}, a2 {0.0}; };

BiquadCoeffs normalize(double b0, double b1, double b2, double a0, double a1, double a2) noexcept {
    return {b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0};
}
double clampFreq(double f, double sr) noexcept { return std::clamp(f, 5.0, sr * 0.49); }

BiquadCoeffs peaking(double f, double q, double gainDb, double sr) noexcept {
    const double A = std::pow(10.0, gainDb / 40.0);
    const double w0 = kTwoPi * clampFreq(f, sr) / sr;
    const double cw = std::cos(w0), alpha = std::sin(w0) / (2.0 * q);
    return normalize(1.0 + alpha * A, -2.0 * cw, 1.0 - alpha * A, 1.0 + alpha / A, -2.0 * cw, 1.0 - alpha / A);
}
BiquadCoeffs lowShelf(double f, double gainDb, double sr) noexcept {
    const double A = std::pow(10.0, gainDb / 40.0);
    const double w0 = kTwoPi * clampFreq(f, sr) / sr;
    const double cw = std::cos(w0), alpha = std::sin(w0) / 2.0 * std::sqrt(2.0), sA = 2.0 * std::sqrt(A) * alpha;
    return normalize(A * ((A + 1.0) - (A - 1.0) * cw + sA), 2.0 * A * ((A - 1.0) - (A + 1.0) * cw),
                     A * ((A + 1.0) - (A - 1.0) * cw - sA), (A + 1.0) + (A - 1.0) * cw + sA,
                     -2.0 * ((A - 1.0) + (A + 1.0) * cw), (A + 1.0) + (A - 1.0) * cw - sA);
}
BiquadCoeffs highShelf(double f, double gainDb, double sr) noexcept {
    const double A = std::pow(10.0, gainDb / 40.0);
    const double w0 = kTwoPi * clampFreq(f, sr) / sr;
    const double cw = std::cos(w0), alpha = std::sin(w0) / 2.0 * std::sqrt(2.0), sA = 2.0 * std::sqrt(A) * alpha;
    return normalize(A * ((A + 1.0) + (A - 1.0) * cw + sA), -2.0 * A * ((A - 1.0) + (A + 1.0) * cw),
                     A * ((A + 1.0) + (A - 1.0) * cw - sA), (A + 1.0) - (A - 1.0) * cw + sA,
                     2.0 * ((A - 1.0) - (A + 1.0) * cw), (A + 1.0) - (A - 1.0) * cw - sA);
}
BiquadCoeffs highpass(double f, double q, double sr) noexcept {
    const double w0 = kTwoPi * clampFreq(f, sr) / sr;
    const double cw = std::cos(w0), alpha = std::sin(w0) / (2.0 * q);
    return normalize((1.0 + cw) / 2.0, -(1.0 + cw), (1.0 + cw) / 2.0, 1.0 + alpha, -2.0 * cw, 1.0 - alpha);
}
BiquadCoeffs lowpass(double f, double q, double sr) noexcept {
    const double w0 = kTwoPi * clampFreq(f, sr) / sr;
    const double cw = std::cos(w0), alpha = std::sin(w0) / (2.0 * q);
    return normalize((1.0 - cw) / 2.0, 1.0 - cw, (1.0 - cw) / 2.0, 1.0 + alpha, -2.0 * cw, 1.0 - alpha);
}

struct Biquad {
    BiquadCoeffs c;
    double s1[2] {0.0, 0.0};
    double s2[2] {0.0, 0.0};
    void reset() noexcept { s1[0] = s1[1] = s2[0] = s2[1] = 0.0; }
    inline double run(int ch, double x) noexcept {
        const double y = c.b0 * x + s1[ch];
        s1[ch] = c.b1 * x - c.a1 * y + s2[ch];
        s2[ch] = c.b2 * x - c.a2 * y;
        return y;
    }
};

double butterworthQ(int stage, int stages) noexcept {
    const int order = 2 * stages;
    return 1.0 / (2.0 * std::sin((2.0 * stage + 1.0) * kPi / (2.0 * order)));
}

struct OnePoleLP {
    double a {1.0};
    double z[2] {0.0, 0.0};
    void set(double fc, double sr) noexcept { a = 1.0 - std::exp(-kTwoPi * clampFreq(fc, sr) / sr); }
    void reset() noexcept { z[0] = z[1] = 0.0; }
    inline double run(int ch, double x) noexcept { z[ch] += a * (x - z[ch]); return z[ch]; }
};

// Fixed-size stereo delay line with fractional (Hermite) read.
struct DelayLine {
    std::vector<double> buf;
    std::size_t mask {0U};
    std::size_t w {0U};
    void allocate(std::size_t minimum) {
        std::size_t size = 1U;
        while (size < minimum + 4U) size <<= 1U;
        buf.assign(size, 0.0);
        mask = size - 1U;
        w = 0U;
    }
    void reset() noexcept { std::fill(buf.begin(), buf.end(), 0.0); w = 0U; }
    inline void push(double x) noexcept { buf[w] = x; w = (w + 1U) & mask; }
    // delay >= 1 sample behind the most recently pushed sample (delay 0 = newest).
    inline double readInt(std::size_t delay) const noexcept { return buf[(w - 1U - delay) & mask]; }
    inline double readFrac(double delay) const noexcept {
        delay = std::max(0.0, delay);
        const auto di = static_cast<std::size_t>(delay);
        const double f = delay - static_cast<double>(di);
        const double xm1 = readInt(di == 0U ? 0U : di - 1U);
        const double x0 = readInt(di);
        const double x1 = readInt(di + 1U);
        const double x2 = readInt(di + 2U);
        const double c0 = x0;
        const double c1 = 0.5 * (x1 - xm1);
        const double c2 = xm1 - 2.5 * x0 + 2.0 * x1 - 0.5 * x2;
        const double c3 = 0.5 * (x2 - xm1) + 1.5 * (x0 - x1);
        return ((c3 * f + c2) * f + c1) * f + c0;
    }
};

// ============================================================ Contour EQ ==
class ContourEq final : public NativePlugin {
public:
    enum : std::uint32_t { Output, LowCutOn, LowCutFreq, LowCutSlope, LowShelfGain, LowShelfFreq,
                           Mid1Gain, Mid1Freq, Mid1Q, Mid2Gain, Mid2Freq, Mid2Q,
                           HighShelfGain, HighShelfFreq, HighCutOn, HighCutFreq, HighCutSlope, Count };
    ContourEq() : NativePlugin(infoFor("silveton.contour-eq"), {
        lin(Output, "Output", "dB", -24.0, 24.0, 0.0),
        toggle(LowCutOn, "Low Cut", false),
        logp(LowCutFreq, "Low Cut Freq", "Hz", 20.0, 1000.0, 80.0),
        choice(LowCutSlope, "Low Cut Slope", {"12 dB/oct", "24 dB/oct", "36 dB/oct", "48 dB/oct"}, 1U),
        lin(LowShelfGain, "Low Shelf Gain", "dB", -18.0, 18.0, 0.0),
        logp(LowShelfFreq, "Low Shelf Freq", "Hz", 20.0, 1000.0, 100.0),
        lin(Mid1Gain, "Low Mid Gain", "dB", -18.0, 18.0, 0.0),
        logp(Mid1Freq, "Low Mid Freq", "Hz", 40.0, 8000.0, 500.0),
        logp(Mid1Q, "Low Mid Q", "", 0.2, 12.0, 0.9),
        lin(Mid2Gain, "High Mid Gain", "dB", -18.0, 18.0, 0.0),
        logp(Mid2Freq, "High Mid Freq", "Hz", 200.0, 16000.0, 2500.0),
        logp(Mid2Q, "High Mid Q", "", 0.2, 12.0, 0.9),
        lin(HighShelfGain, "High Shelf Gain", "dB", -18.0, 18.0, 0.0),
        logp(HighShelfFreq, "High Shelf Freq", "Hz", 1000.0, 18000.0, 8000.0),
        toggle(HighCutOn, "High Cut", false),
        logp(HighCutFreq, "High Cut Freq", "Hz", 1000.0, 20000.0, 16000.0),
        choice(HighCutSlope, "High Cut Slope", {"12 dB/oct", "24 dB/oct", "36 dB/oct", "48 dB/oct"}, 1U),
    }) {}

protected:
    void onPrepare(double, std::uint32_t) override {}
    void onReset() noexcept override {
        for (auto& b : lowCut_) b.reset();
        for (auto& b : highCut_) b.reset();
        ls_.reset(); m1_.reset(); m2_.reset(); hs_.reset();
        snap_ = true;
    }
    void render(const RenderIO& io, const ProcessorContext&) noexcept override {
        const double sr = sampleRate();
        const double chunkCoef = 1.0 - std::exp(-32.0 / (0.020 * sr));
        std::uint32_t done = 0U;
        while (done < io.frames) {
            const std::uint32_t n = std::min<std::uint32_t>(32U, io.frames - done);
            updateSmoothing(snap_ ? 1.0 : chunkCoef);
            snap_ = false;
            const int lcStages = static_cast<int>(p(LowCutSlope)) + 1;
            const int hcStages = static_cast<int>(p(HighCutSlope)) + 1;
            const bool lcOn = isOn(p(LowCutOn));
            const bool hcOn = isOn(p(HighCutOn));
            const double out = dbToGain(sm_[0]);
            for (std::uint32_t i = done; i < done + n; ++i) {
                for (int ch = 0; ch < 2; ++ch) {
                    double x = ch == 0 ? io.inL[i] : io.inR[i];
                    if (lcOn) for (int s = 0; s < lcStages; ++s) x = lowCut_[s].run(ch, x);
                    x = ls_.run(ch, x);
                    x = m1_.run(ch, x);
                    x = m2_.run(ch, x);
                    x = hs_.run(ch, x);
                    if (hcOn) for (int s = 0; s < hcStages; ++s) x = highCut_[s].run(ch, x);
                    (ch == 0 ? io.outL : io.outR)[i] = static_cast<float>(x * out);
                }
            }
            done += n;
        }
    }

private:
    // Smoothed: output dB, LC f, LS g, LS f, M1 g, M1 f, M1 q, M2 g, M2 f, M2 q, HS g, HS f, HC f
    void updateSmoothing(double k) noexcept {
        const std::array<double, 13> target {p(Output), std::log(p(LowCutFreq)), p(LowShelfGain), std::log(p(LowShelfFreq)),
                                             p(Mid1Gain), std::log(p(Mid1Freq)), std::log(p(Mid1Q)),
                                             p(Mid2Gain), std::log(p(Mid2Freq)), std::log(p(Mid2Q)),
                                             p(HighShelfGain), std::log(p(HighShelfFreq)), std::log(p(HighCutFreq))};
        bool changed = false;
        for (std::size_t i = 0U; i < target.size(); ++i) {
            const double next = sm_[i] + (target[i] - sm_[i]) * k;
            const double v = std::abs(target[i] - next) < 1.0e-7 ? target[i] : next;
            if (v != sm_[i]) { sm_[i] = v; changed = true; }
        }
        const int lcStages = static_cast<int>(p(LowCutSlope)) + 1;
        const int hcStages = static_cast<int>(p(HighCutSlope)) + 1;
        if (lcStages != lcStagesApplied_ || hcStages != hcStagesApplied_) changed = true;
        if (!changed && !firstCoeffs_) return;
        firstCoeffs_ = false;
        lcStagesApplied_ = lcStages; hcStagesApplied_ = hcStages;
        const double sr = sampleRate();
        for (int s = 0; s < lcStages; ++s) lowCut_[s].c = highpass(std::exp(sm_[1]), butterworthQ(s, lcStages), sr);
        ls_.c = lowShelf(std::exp(sm_[3]), sm_[2], sr);
        m1_.c = peaking(std::exp(sm_[5]), std::exp(sm_[6]), sm_[4], sr);
        m2_.c = peaking(std::exp(sm_[8]), std::exp(sm_[9]), sm_[7], sr);
        hs_.c = highShelf(std::exp(sm_[11]), sm_[10], sr);
        for (int s = 0; s < hcStages; ++s) highCut_[s].c = lowpass(std::exp(sm_[12]), butterworthQ(s, hcStages), sr);
    }

    Biquad lowCut_[4];
    Biquad highCut_[4];
    Biquad ls_, m1_, m2_, hs_;
    std::array<double, 13> sm_ {};
    bool snap_ {true};
    bool firstCoeffs_ {true};
    int lcStagesApplied_ {0};
    int hcStagesApplied_ {0};
};

// ====================================================== Press Compressor ==
class PressCompressor final : public NativePlugin {
public:
    enum : std::uint32_t { Threshold, Ratio, Knee, Attack, Release, Makeup, AutoMakeup, Mix, Sidechain, Detector, ScLowCut, Count };
    PressCompressor() : NativePlugin(infoFor("silveton.press"), {
        lin(Threshold, "Threshold", "dB", -60.0, 0.0, -18.0),
        logp(Ratio, "Ratio", ":1", 1.0, 20.0, 4.0),
        lin(Knee, "Knee", "dB", 0.0, 24.0, 6.0),
        logp(Attack, "Attack", "ms", 0.05, 200.0, 10.0),
        logp(Release, "Release", "ms", 5.0, 2000.0, 120.0),
        lin(Makeup, "Makeup", "dB", -12.0, 24.0, 0.0),
        toggle(AutoMakeup, "Auto Makeup", false),
        lin(Mix, "Mix", "%", 0.0, 100.0, 100.0),
        toggle(Sidechain, "Sidechain", false),
        choice(Detector, "Detector", {"Peak", "RMS"}, 0U),
        logp(ScLowCut, "SC Low Cut", "Hz", 20.0, 1000.0, 20.0),
    }) {}

    // Static gain computer (dB in -> dB out), exposed for the unit tests.
    static double gainComputer(double x, double t, double r, double w) noexcept {
        if (w > 0.0 && 2.0 * std::abs(x - t) <= w) {
            const double d = x - t + w / 2.0;
            return x + (1.0 / r - 1.0) * d * d / (2.0 * w);
        }
        if (x <= t) return x;
        return t + (x - t) / r;
    }

protected:
    void onPrepare(double, std::uint32_t) override {}
    void onReset() noexcept override { env_ = 0.0; rms_ = 0.0; scHp_.reset(); }
    void onParametersChanged() noexcept override {
        const double sr = sampleRate();
        attack_ = timeCoef(p(Attack) / 1000.0, sr);
        release_ = timeCoef(p(Release) / 1000.0, sr);
        rmsCoef_ = timeCoef(0.010, sr);
        scHp_.c = highpass(p(ScLowCut), 0.7071, sr);
        const double t = p(Threshold), r = p(Ratio);
        makeup_ = p(Makeup) + (isOn(p(AutoMakeup)) ? -0.5 * (gainComputer(0.0, t, r, p(Knee))) : 0.0);
    }
    void render(const RenderIO& io, const ProcessorContext&) noexcept override {
        const double t = p(Threshold), r = p(Ratio), w = p(Knee);
        const double mix = p(Mix) / 100.0;
        const bool useSide = isOn(p(Sidechain)) && io.sideL != nullptr;
        const bool rms = p(Detector) >= 0.5;
        const bool hp = p(ScLowCut) > 20.5;
        double maxGr = 0.0;
        for (std::uint32_t i = 0U; i < io.frames; ++i) {
            double sL = useSide ? io.sideL[i] : io.inL[i];
            double sR = useSide ? io.sideR[i] : io.inR[i];
            if (hp) { sL = scHp_.run(0, sL); sR = scHp_.run(1, sR); }
            double level = std::max(std::abs(sL), std::abs(sR));
            if (rms) { rms_ = rmsCoef_ * rms_ + (1.0 - rmsCoef_) * level * level; level = std::sqrt(rms_ * 2.0); }
            const double x = gainToDb(level);
            const double gr = gainComputer(x, t, r, w) - x;
            env_ = gr < env_ ? attack_ * env_ + (1.0 - attack_) * gr : release_ * env_ + (1.0 - release_) * gr;
            maxGr = std::min(maxGr, env_);
            const double g = dbToGain(env_ + makeup_);
            const double wet = g * mix + (1.0 - mix);
            io.outL[i] = static_cast<float>(io.inL[i] * wet);
            io.outR[i] = static_cast<float>(io.inR[i] * wet);
        }
        setMeter(0U, static_cast<float>(maxGr));
    }

private:
    double env_ {0.0}, rms_ {0.0}, attack_ {0.0}, release_ {0.0}, rmsCoef_ {0.0}, makeup_ {0.0};
    Biquad scHp_;
};

// ================================================================= Gate ==
class GateProcessor final : public NativePlugin {
public:
    enum : std::uint32_t { Threshold, Range, Attack, Hold, Release, Hysteresis, Sidechain, Count };
    GateProcessor() : NativePlugin(infoFor("silveton.gate"), {
        lin(Threshold, "Threshold", "dB", -80.0, 0.0, -40.0),
        lin(Range, "Range", "dB", -90.0, 0.0, -80.0),
        logp(Attack, "Attack", "ms", 0.01, 50.0, 0.5),
        lin(Hold, "Hold", "ms", 0.0, 500.0, 20.0),
        logp(Release, "Release", "ms", 5.0, 2000.0, 150.0),
        lin(Hysteresis, "Hysteresis", "dB", 0.0, 12.0, 3.0),
        toggle(Sidechain, "Sidechain", false),
    }) {}
protected:
    void onPrepare(double, std::uint32_t) override {}
    void onReset() noexcept override { env_ = 0.0; gain_ = dbToGain(p(Range)); open_ = false; holdLeft_ = 0U; }
    void onParametersChanged() noexcept override {
        const double sr = sampleRate();
        attack_ = timeCoef(p(Attack) / 1000.0, sr);
        release_ = timeCoef(p(Release) / 1000.0, sr);
        envDecay_ = timeCoef(0.005, sr);
        holdSamples_ = static_cast<std::uint32_t>(p(Hold) / 1000.0 * sr);
    }
    void render(const RenderIO& io, const ProcessorContext&) noexcept override {
        const double openLin = dbToGain(p(Threshold));
        const double closeLin = dbToGain(p(Threshold) - p(Hysteresis));
        const double floor = dbToGain(p(Range));
        const bool useSide = isOn(p(Sidechain)) && io.sideL != nullptr;
        for (std::uint32_t i = 0U; i < io.frames; ++i) {
            const double sL = useSide ? io.sideL[i] : io.inL[i];
            const double sR = useSide ? io.sideR[i] : io.inR[i];
            const double level = std::max(std::abs(sL), std::abs(sR));
            env_ = std::max(level, env_ * envDecay_);
            if (env_ >= openLin) { open_ = true; holdLeft_ = holdSamples_; }
            else if (open_ && env_ < closeLin) {
                if (holdLeft_ > 0U) --holdLeft_; else open_ = false;
            }
            const double target = open_ ? 1.0 : floor;
            gain_ = target > gain_ ? attack_ * gain_ + (1.0 - attack_) * target
                                   : release_ * gain_ + (1.0 - release_) * target;
            io.outL[i] = static_cast<float>(io.inL[i] * gain_);
            io.outR[i] = static_cast<float>(io.inR[i] * gain_);
        }
        setMeter(0U, static_cast<float>(gainToDb(gain_)));
    }
private:
    double env_ {0.0}, gain_ {0.0}, attack_ {0.0}, release_ {0.0}, envDecay_ {0.0};
    bool open_ {false};
    std::uint32_t holdLeft_ {0U}, holdSamples_ {0U};
};

// ======================================================= Ceiling Limiter ==
// Lookahead brickwall: sliding-window minimum of the required gain, release
// smoothing with instantaneous attack, then a box average of the lookahead
// length. The box average of values that each cover the delayed sample is
// provably <= the gain that sample requires, so the output never exceeds the
// ceiling (a final guard clamp only absorbs floating-point rounding).
class CeilingLimiter final : public NativePlugin {
public:
    enum : std::uint32_t { InputGain, Ceiling, Release, Count };
    CeilingLimiter() : NativePlugin(infoFor("silveton.ceiling"), {
        lin(InputGain, "Input Gain", "dB", 0.0, 24.0, 0.0),
        lin(Ceiling, "Ceiling", "dB", -12.0, 0.0, -0.3),
        logp(Release, "Release", "ms", 1.0, 1000.0, 80.0),
    }) {}
    static constexpr double kLookaheadSeconds = 0.0015;
protected:
    void onPrepare(double sr, std::uint32_t) override {
        look_ = std::max<std::size_t>(1U, static_cast<std::size_t>(std::llround(kLookaheadSeconds * sr)));
        size_ = look_ + 1U;
        dl_.assign(size_, 0.0); dr_.assign(size_, 0.0); box_.assign(size_, 1.0);
        dqVal_.assign(size_ + 1U, 1.0); dqIdx_.assign(size_ + 1U, 0U);
        setLatency(static_cast<std::uint32_t>(look_));
    }
    void onReset() noexcept override {
        std::fill(dl_.begin(), dl_.end(), 0.0); std::fill(dr_.begin(), dr_.end(), 0.0);
        std::fill(box_.begin(), box_.end(), 1.0);
        sum_ = static_cast<double>(size_); y_ = 1.0; pos_ = 0U; n_ = 0U; dqHead_ = dqTail_ = 0U;
    }
    void onParametersChanged() noexcept override { rel_ = timeCoef(p(Release) / 1000.0, sampleRate()); }
    void render(const RenderIO& io, const ProcessorContext&) noexcept override {
        const double inGain = dbToGain(p(InputGain));
        const double ceil = dbToGain(p(Ceiling));
        const std::size_t cap = size_ + 1U;
        double minG = 1.0;
        for (std::uint32_t i = 0U; i < io.frames; ++i) {
            const double xL = io.inL[i] * inGain, xR = io.inR[i] * inGain;
            const double peak = std::max(std::abs(xL), std::abs(xR));
            const double req = peak > ceil ? ceil / peak : 1.0;
            // monotonic deque (ascending values from head)
            while (dqTail_ != dqHead_ && dqVal_[(dqTail_ + cap - 1U) % cap] >= req) dqTail_ = (dqTail_ + cap - 1U) % cap;
            dqVal_[dqTail_] = req; dqIdx_[dqTail_] = n_; dqTail_ = (dqTail_ + 1U) % cap;
            while (dqIdx_[dqHead_] + size_ <= n_) dqHead_ = (dqHead_ + 1U) % cap;
            const double m = dqVal_[dqHead_];
            y_ = m < y_ ? m : m + (y_ - m) * rel_;
            sum_ += y_ - box_[pos_];
            box_[pos_] = y_;
            dl_[pos_] = xL; dr_[pos_] = xR;
            const std::size_t oldest = (pos_ + 1U) % size_;
            const double g = std::min(1.0, sum_ / static_cast<double>(size_));
            minG = std::min(minG, g);
            io.outL[i] = static_cast<float>(std::clamp(dl_[oldest] * g, -ceil, ceil));
            io.outR[i] = static_cast<float>(std::clamp(dr_[oldest] * g, -ceil, ceil));
            pos_ = oldest;
            ++n_;
            if (pos_ == 0U) { double s = 0.0; for (double v : box_) s += v; sum_ = s; }
        }
        setMeter(0U, static_cast<float>(gainToDb(minG)));
    }
private:
    std::size_t look_ {1U}, size_ {2U}, pos_ {0U}, dqHead_ {0U}, dqTail_ {0U};
    std::uint64_t n_ {0U};
    std::vector<double> dl_, dr_, box_, dqVal_;
    std::vector<std::uint64_t> dqIdx_;
    double sum_ {0.0}, y_ {1.0}, rel_ {0.0};
};

// ============================================================ Echo Delay ==
class EchoDelay final : public NativePlugin {
public:
    enum : std::uint32_t { Sync, Note, TimeMs, Feedback, PingPong, LowCut, HighCut, Mix, Width, Count };
    static constexpr double kMaxSeconds = 4.0;
    EchoDelay() : NativePlugin(infoFor("silveton.echo"), {
        toggle(Sync, "Tempo Sync", true),
        choice(Note, "Note", {"1/32", "1/16T", "1/16", "1/16D", "1/8T", "1/8", "1/8D", "1/4T", "1/4", "1/4D", "1/2", "1/1"}, 6U),
        logp(TimeMs, "Time", "ms", 1.0, 2000.0, 375.0),
        lin(Feedback, "Feedback", "%", 0.0, 95.0, 35.0),
        toggle(PingPong, "Ping-Pong", false),
        logp(LowCut, "Low Cut", "Hz", 20.0, 2000.0, 120.0),
        logp(HighCut, "High Cut", "Hz", 1000.0, 20000.0, 8000.0),
        lin(Mix, "Mix", "%", 0.0, 100.0, 25.0),
        lin(Width, "Width", "%", 0.0, 100.0, 100.0),
    }) {}
    static double noteQuarters(int index) noexcept {
        static const double q[] = {0.125, 1.0 / 6.0, 0.25, 0.375, 1.0 / 3.0, 0.5, 0.75, 2.0 / 3.0, 1.0, 1.5, 2.0, 4.0};
        return q[std::clamp(index, 0, 11)];
    }
protected:
    void onPrepare(double sr, std::uint32_t) override {
        const auto n = static_cast<std::size_t>(std::ceil(kMaxSeconds * sr)) + 8U;
        l_.allocate(n); r_.allocate(n);
    }
    void onReset() noexcept override { l_.reset(); r_.reset(); lp_.reset(); hp_.reset(); snap_ = true; }
    void onParametersChanged() noexcept override {
        lp_.set(p(HighCut), sampleRate());
        hp_.set(p(LowCut), sampleRate());
    }
    double targetDelay(const ProcessorContext& ctx) const noexcept {
        double seconds = p(TimeMs) / 1000.0;
        if (isOn(p(Sync))) {
            const double bpm = ctx.tempo > 1.0 ? ctx.tempo : 120.0;
            seconds = noteQuarters(static_cast<int>(p(Note))) * 60.0 / bpm;
        }
        return std::clamp(seconds * sampleRate(), 1.0, kMaxSeconds * sampleRate());
    }
    void render(const RenderIO& io, const ProcessorContext& ctx) noexcept override {
        const double target = targetDelay(ctx);
        if (snap_) { d_ = target; snap_ = false; }
        const double k = 1.0 - std::exp(-1.0 / (0.05 * sampleRate()));
        const double fb = p(Feedback) / 100.0;
        const double mix = p(Mix) / 100.0;
        const double width = p(Width) / 100.0;
        const bool ping = isOn(p(PingPong));
        const bool hpOn = p(LowCut) > 20.5;
        for (std::uint32_t i = 0U; i < io.frames; ++i) {
            d_ += (target - d_) * k;
            // read before write: a delay of D samples reads index D-1 behind the newest.
            double wl = l_.readFrac(d_ - 1.0);
            double wr = r_.readFrac(d_ - 1.0);
            wl = lp_.run(0, wl); wr = lp_.run(1, wr);
            if (hpOn) { wl -= hp_.run(0, wl); wr -= hp_.run(1, wr); }
            const double inL = io.inL[i], inR = io.inR[i];
            if (ping) { l_.push(0.5 * (inL + inR) + wr * fb); r_.push(wl * fb); }
            else { l_.push(inL + wl * fb); r_.push(inR + wr * fb); }
            const double mid = 0.5 * (wl + wr), side = 0.5 * (wl - wr) * width;
            io.outL[i] = static_cast<float>(inL * (1.0 - mix) + (mid + side) * mix);
            io.outR[i] = static_cast<float>(inR * (1.0 - mix) + (mid - side) * mix);
        }
    }
    std::uint64_t computeTailSamples() const noexcept override {
        const double sr = sampleRate();
        double seconds = plainValue(TimeMs) / 1000.0;
        if (plainValue(Sync) >= 0.5) seconds = noteQuarters(static_cast<int>(plainValue(Note))) * 0.5; // 120 BPM reference
        const double fb = plainValue(Feedback) / 100.0;
        const double repeats = fb < 1.0e-3 ? 1.0 : 1.0 + std::log(1.0e-4) / std::log(fb);
        return static_cast<std::uint64_t>(std::min(60.0, seconds * std::max(1.0, repeats) + 0.05) * sr);
    }
private:
    DelayLine l_, r_;
    OnePoleLP lp_, hp_;
    double d_ {1.0};
    bool snap_ {true};
};

// =========================================================== Space Reverb ==
// 8-line feedback delay network (Householder mixing) with per-line absorbent
// filters derived from low/high RT60, input diffusion, pre-delay and slow
// read-position modulation.
class SpaceReverb final : public NativePlugin {
public:
    enum : std::uint32_t { PreDelay, Decay, Size, Damping, LowCut, HighCut, Width, Mix, Modulation, Count };
    static constexpr int kLines = 8;
    SpaceReverb() : NativePlugin(infoFor("silveton.space"), {
        lin(PreDelay, "Pre-Delay", "ms", 0.0, 250.0, 10.0),
        logp(Decay, "Decay", "s", 0.2, 20.0, 2.2),
        lin(Size, "Size", "%", 10.0, 100.0, 60.0),
        lin(Damping, "Damping", "%", 0.0, 100.0, 45.0),
        logp(LowCut, "Low Cut", "Hz", 20.0, 1000.0, 80.0),
        logp(HighCut, "High Cut", "Hz", 1000.0, 20000.0, 12000.0),
        lin(Width, "Width", "%", 0.0, 100.0, 100.0),
        lin(Mix, "Mix", "%", 0.0, 100.0, 25.0),
        lin(Modulation, "Modulation", "%", 0.0, 100.0, 20.0),
    }) {}
protected:
    void onPrepare(double sr, std::uint32_t) override {
        pre_.allocate(static_cast<std::size_t>(0.26 * sr));
        for (int i = 0; i < kLines; ++i) lines_[i].allocate(static_cast<std::size_t>(kBaseMs[i] * 1.45 * sr / 1000.0) + 64U);
        for (int i = 0; i < 4; ++i) diff_[i].allocate(static_cast<std::size_t>(kDiffMs[i] * sr / 1000.0) + 4U);
    }
    void onReset() noexcept override {
        pre_.reset();
        for (auto& l : lines_) l.reset();
        for (auto& d : diff_) d.reset();
        for (auto& z : damp_) z = 0.0;
        inLp_.reset(); inHp_.reset();
        phase_ = 0.0;
    }
    void onParametersChanged() noexcept override {
        const double sr = sampleRate();
        const double scale = 0.35 + (p(Size) / 100.0) * 1.05;
        const double rtLow = p(Decay);
        const double rtHigh = std::max(0.05, rtLow * (1.0 - 0.9 * p(Damping) / 100.0));
        for (int i = 0; i < kLines; ++i) {
            len_[i] = std::max(8.0, kBaseMs[i] * scale * sr / 1000.0);
            const double g = std::pow(10.0, -3.0 * len_[i] / (rtLow * sr));
            const double gh = std::pow(10.0, -3.0 * len_[i] / (rtHigh * sr));
            dampB_[i] = (g - gh) / (g + gh);
            dampG_[i] = g * (1.0 - dampB_[i]);
        }
        for (int i = 0; i < 4; ++i) diffLen_[i] = std::max<std::size_t>(1U, static_cast<std::size_t>(kDiffMs[i] * sr / 1000.0));
        preSamples_ = static_cast<std::size_t>(p(PreDelay) / 1000.0 * sr);
        inLp_.set(p(HighCut), sr);
        inHp_.set(p(LowCut), sr);
        modDepth_ = p(Modulation) / 100.0 * 0.0012 * sr;
        phaseInc_ = kTwoPi * 0.7 / sr;
    }
    void render(const RenderIO& io, const ProcessorContext&) noexcept override {
        const double mix = p(Mix) / 100.0;
        const double width = p(Width) / 100.0;
        const bool hp = p(LowCut) > 20.5;
        for (std::uint32_t i = 0U; i < io.frames; ++i) {
            double x = 0.5 * (io.inL[i] + io.inR[i]);
            x = inLp_.run(0, x);
            if (hp) x -= inHp_.run(1, x);
            pre_.push(x);
            double v = preSamples_ == 0U ? x : pre_.readInt(preSamples_);
            for (int d = 0; d < 4; ++d) {
                const double delayed = diff_[d].readInt(diffLen_[d] - 1U);
                const double w = v + 0.7 * delayed;
                diff_[d].push(w);
                v = delayed - 0.7 * w;
            }
            phase_ += phaseInc_;
            if (phase_ > kTwoPi) phase_ -= kTwoPi;
            double out[kLines];
            double sum = 0.0;
            for (int k = 0; k < kLines; ++k) {
                double len = len_[k] - 1.0;
                if (k == 0 || k == 3 || k == 5) len += modDepth_ * std::sin(phase_ + k * 1.3);
                const double raw = lines_[k].readFrac(len);
                damp_[k] = dampG_[k] * raw + dampB_[k] * damp_[k];
                out[k] = damp_[k];
                sum += out[k];
            }
            const double h = sum * (2.0 / kLines);
            static const double inSign[kLines] = {1, -1, 1, -1, 1, -1, 1, -1};
            for (int k = 0; k < kLines; ++k) lines_[k].push(out[k] - h + v * inSign[k] * 0.35);
            const double wl = (out[0] - out[1] + out[2] - out[3] + out[4] - out[5] + out[6] - out[7]) * 0.35;
            const double wr = (out[0] + out[1] - out[2] - out[3] + out[4] + out[5] - out[6] - out[7]) * 0.35;
            const double mid = 0.5 * (wl + wr), side = 0.5 * (wl - wr) * width;
            io.outL[i] = static_cast<float>(io.inL[i] * (1.0 - mix) + (mid + side) * mix);
            io.outR[i] = static_cast<float>(io.inR[i] * (1.0 - mix) + (mid - side) * mix);
        }
    }
    std::uint64_t computeTailSamples() const noexcept override {
        return static_cast<std::uint64_t>((plainValue(Decay) * 1.5 + plainValue(PreDelay) / 1000.0 + 0.1) * sampleRate());
    }
private:
    static constexpr double kBaseMs[kLines] = {31.71, 37.11, 41.13, 43.71, 47.37, 53.93, 59.33, 67.17};
    static constexpr double kDiffMs[4] = {4.771, 3.595, 12.73, 9.307};
    DelayLine pre_;
    DelayLine lines_[kLines];
    DelayLine diff_[4];
    double len_[kLines] {};
    double dampG_[kLines] {};
    double dampB_[kLines] {};
    double damp_[kLines] {};
    std::size_t diffLen_[4] {1U, 1U, 1U, 1U};
    std::size_t preSamples_ {0U};
    OnePoleLP inLp_, inHp_;
    double modDepth_ {0.0}, phase_ {0.0}, phaseInc_ {0.0};
};

// ========================================================= Drive Saturator ==
// First-order antiderivative anti-aliasing (ADAA) of the transfer curve, so
// harmonics are generated without the aliasing of a naive waveshaper.
class DriveSaturator final : public NativePlugin {
public:
    enum : std::uint32_t { Drive, Character, Tone, Output, Mix, Count };
    DriveSaturator() : NativePlugin(infoFor("silveton.drive"), {
        lin(Drive, "Drive", "dB", 0.0, 36.0, 6.0),
        choice(Character, "Character", {"Tape", "Tube", "Hard"}, 0U),
        lin(Tone, "Tone", "%", -100.0, 100.0, 0.0),
        lin(Output, "Output", "dB", -24.0, 12.0, 0.0),
        lin(Mix, "Mix", "%", 0.0, 100.0, 100.0),
    }) {}
    static double logcosh(double x) noexcept { const double a = std::abs(x); return a + std::log1p(std::exp(-2.0 * a)) - std::log(2.0); }
    static double shape(int c, double x) noexcept {
        switch (c) {
            case 1: return std::tanh(x + kBias) - std::tanh(kBias);
            case 2: return std::clamp(x, -1.0, 1.0);
            default: return std::tanh(x);
        }
    }
    static double antideriv(int c, double x) noexcept {
        switch (c) {
            case 1: return logcosh(x + kBias) - std::tanh(kBias) * x;
            case 2: return std::abs(x) <= 1.0 ? 0.5 * x * x : std::abs(x) - 0.5;
            default: return logcosh(x);
        }
    }
protected:
    static constexpr double kBias = 0.25;
    void onPrepare(double, std::uint32_t) override {}
    void onReset() noexcept override { prev_[0] = prev_[1] = 0.0; dc_[0] = dc_[1] = 0.0; dcX_[0] = dcX_[1] = 0.0; tilt_.reset(); }
    void onParametersChanged() noexcept override { tilt_.set(1000.0, sampleRate()); dcR_ = 1.0 - kTwoPi * 10.0 / sampleRate(); }
    void render(const RenderIO& io, const ProcessorContext&) noexcept override {
        const double drive = dbToGain(p(Drive));
        const int c = static_cast<int>(p(Character));
        const double t = p(Tone) / 100.0;
        const double lowG = dbToGain(-6.0 * t), highG = dbToGain(6.0 * t);
        const double out = dbToGain(p(Output)) / drive;
        const double mix = p(Mix) / 100.0;
        for (std::uint32_t i = 0U; i < io.frames; ++i) {
            for (int ch = 0; ch < 2; ++ch) {
                const double in = ch == 0 ? io.inL[i] : io.inR[i];
                const double x = in * drive;
                const double dx = x - prev_[ch];
                double y = std::abs(dx) < 1.0e-6 ? shape(c, 0.5 * (x + prev_[ch]))
                                                 : (antideriv(c, x) - antideriv(c, prev_[ch])) / dx;
                prev_[ch] = x;
                // DC blocker (needed for the asymmetric tube curve).
                const double blocked = y - dcX_[ch] + dcR_ * dc_[ch];
                dcX_[ch] = y; dc_[ch] = blocked; y = blocked;
                const double lo = tilt_.run(ch, y);
                y = lo * lowG + (y - lo) * highG;
                const double wet = y * out;
                (ch == 0 ? io.outL : io.outR)[i] = static_cast<float>(in * (1.0 - mix) + wet * mix);
            }
        }
    }
private:
    double prev_[2] {0.0, 0.0}, dc_[2] {0.0, 0.0}, dcX_[2] {0.0, 0.0}, dcR_ {0.999};
    OnePoleLP tilt_;
};

// ======================================================== Ensemble Chorus ==
class EnsembleChorus final : public NativePlugin {
public:
    enum : std::uint32_t { Rate, Depth, DelayMs, Voices, Mix, Width, Feedback, Count };
    EnsembleChorus() : NativePlugin(infoFor("silveton.chorus"), {
        logp(Rate, "Rate", "Hz", 0.05, 5.0, 0.6),
        lin(Depth, "Depth", "ms", 0.0, 10.0, 3.0),
        lin(DelayMs, "Delay", "ms", 1.0, 30.0, 12.0),
        integer(Voices, "Voices", "", 1.0, 4.0, 2.0),
        lin(Mix, "Mix", "%", 0.0, 100.0, 50.0),
        lin(Width, "Width", "%", 0.0, 100.0, 100.0),
        lin(Feedback, "Feedback", "%", 0.0, 70.0, 0.0),
    }) {}
protected:
    void onPrepare(double sr, std::uint32_t) override {
        const auto n = static_cast<std::size_t>(0.045 * sr) + 8U;
        l_.allocate(n); r_.allocate(n);
    }
    void onReset() noexcept override { l_.reset(); r_.reset(); phase_ = 0.0; fbL_ = fbR_ = 0.0; }
    void render(const RenderIO& io, const ProcessorContext&) noexcept override {
        const double sr = sampleRate();
        const double inc = kTwoPi * p(Rate) / sr;
        const double base = p(DelayMs) / 1000.0 * sr;
        const double depth = p(Depth) / 1000.0 * sr * 0.5;
        const int voices = std::clamp(static_cast<int>(p(Voices)), 1, 4);
        const double mix = p(Mix) / 100.0, width = p(Width) / 100.0, fb = p(Feedback) / 100.0;
        for (std::uint32_t i = 0U; i < io.frames; ++i) {
            l_.push(io.inL[i] + fbL_ * fb);
            r_.push(io.inR[i] + fbR_ * fb);
            phase_ += inc; if (phase_ > kTwoPi) phase_ -= kTwoPi;
            double wl = 0.0, wr = 0.0;
            for (int v = 0; v < voices; ++v) {
                const double ph = phase_ + kTwoPi * v / voices;
                const double dl = base + depth * (1.0 + std::sin(ph));
                const double dr = base + depth * (1.0 + std::sin(ph + kPi * 0.5));
                const double pan = voices == 1 ? 0.0 : (2.0 * v / (voices - 1) - 1.0) * width;
                wl += l_.readFrac(dl) * (0.5 - 0.5 * pan);
                wr += r_.readFrac(dr) * (0.5 + 0.5 * pan);
            }
            wl /= voices; wr /= voices;
            fbL_ = wl; fbR_ = wr;
            io.outL[i] = static_cast<float>(io.inL[i] * (1.0 - mix) + wl * mix * 2.0);
            io.outR[i] = static_cast<float>(io.inR[i] * (1.0 - mix) + wr * mix * 2.0);
        }
    }
private:
    DelayLine l_, r_;
    double phase_ {0.0}, fbL_ {0.0}, fbR_ {0.0};
};

} // namespace

std::unique_ptr<NativePlugin> makeContourEq() { return std::make_unique<ContourEq>(); }
std::unique_ptr<NativePlugin> makePressCompressor() { return std::make_unique<PressCompressor>(); }
std::unique_ptr<NativePlugin> makeGate() { return std::make_unique<GateProcessor>(); }
std::unique_ptr<NativePlugin> makeCeilingLimiter() { return std::make_unique<CeilingLimiter>(); }
std::unique_ptr<NativePlugin> makeEchoDelay() { return std::make_unique<EchoDelay>(); }
std::unique_ptr<NativePlugin> makeSpaceReverb() { return std::make_unique<SpaceReverb>(); }
std::unique_ptr<NativePlugin> makeDriveSaturator() { return std::make_unique<DriveSaturator>(); }
std::unique_ptr<NativePlugin> makeEnsembleChorus() { return std::make_unique<EnsembleChorus>(); }

} // namespace silveton::native_detail
