#include "silveton/Vst3Host.h"

#include "public.sdk/source/vst/hosting/eventlist.h"
#include "public.sdk/source/vst/hosting/hostclasses.h"
#include "public.sdk/source/vst/hosting/module.h"
#include "public.sdk/source/vst/hosting/plugprovider.h"
#include "public.sdk/source/vst/hosting/processdata.h"
#include "public.sdk/source/vst/utility/memoryibstream.h"
#include "public.sdk/source/vst/utility/stringconvert.h"
#include "public.sdk/source/vst/utility/uid.h"
#include "public.sdk/source/vst/vstpresetfile.h"
#include "pluginterfaces/base/funknownimpl.h"
#include "pluginterfaces/vst/ivstaudioprocessor.h"
#include "pluginterfaces/vst/ivsteditcontroller.h"
#include "pluginterfaces/vst/ivstevents.h"
#include "pluginterfaces/vst/ivstmidicontrollers.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "pluginterfaces/vst/vstspeaker.h"

#if defined(__APPLE__)
#include "internal/Vst3EditorBridge.h"
#endif

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstring>
#include <limits>
#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace silveton {
namespace {

constexpr std::size_t kMaxAudioBuses = 32U;
constexpr std::size_t kMaxChannelsPerBus = 64U;
constexpr std::size_t kMaxChannelsPerDirection = 256U;
constexpr std::size_t kMaxParameterCount = 8192U;
constexpr std::size_t kMaxParamPointsPerBlock = 64U;
constexpr std::size_t kMidiQueueCapacity = 4096U;
constexpr std::size_t kParameterInputQueueCapacity = kMaxParameterCount + 1U;
constexpr std::size_t kOutputParamQueueCapacity = 4096U;
constexpr std::size_t kGestureQueueCapacity = 2048U;
constexpr std::size_t kBusRequestQueueCapacity = 128U;
constexpr Steinberg::int32 kMaxVstEventsPerBlock = 4096;
constexpr std::size_t kMidiControllerMapSize = static_cast<std::size_t>(Steinberg::Vst::kSystemActiveSensing) + 1U;

using Steinberg::Vst::BusDirection;
using Steinberg::Vst::BusInfo;
using Steinberg::Vst::IComponent;
using Steinberg::Vst::IEditController;
using Steinberg::Vst::IAudioProcessor;
using Steinberg::Vst::IMidiMapping;
using Steinberg::Vst::ParamID;
using Steinberg::Vst::ParamValue;

// Process-lifetime host context. It intentionally remains alive until process exit because
// Steinberg's PluginContextFactory stores a raw pointer shared by all PlugProvider instances.
Steinberg::Vst::HostApplication* sharedHostApplication() {
    static Steinberg::Vst::HostApplication* app = [] {
        auto* p = new Steinberg::Vst::HostApplication();
        Steinberg::Vst::PluginContextFactory::instance().setPluginContext(p);
        return p;
    }();
    return app;
}

template <typename T, std::size_t Capacity>
class FixedSpscQueue {
public:
    bool push(const T& item) noexcept {
        const auto write = write_.load(std::memory_order_relaxed);
        const auto next = increment(write);
        if (next == read_.load(std::memory_order_acquire)) return false;
        data_[write] = item;
        write_.store(next, std::memory_order_release);
        return true;
    }

    bool pop(T& item) noexcept {
        const auto read = read_.load(std::memory_order_relaxed);
        if (read == write_.load(std::memory_order_acquire)) return false;
        item = data_[read];
        read_.store(increment(read), std::memory_order_release);
        return true;
    }

    void clear() noexcept {
        read_.store(0U, std::memory_order_relaxed);
        write_.store(0U, std::memory_order_relaxed);
    }

private:
    static constexpr std::size_t increment(std::size_t i) noexcept { return (i + 1U) % Capacity; }
    static_assert(Capacity >= 2U, "SPSC queue capacity must include an empty sentinel slot");
    std::array<T, Capacity> data_ {};
    std::atomic<std::size_t> read_ {0U};
    std::atomic<std::size_t> write_ {0U};
};

class FixedParamValueQueue final
    : public Steinberg::U::ImplementsNonDestroyable<Steinberg::U::Directly<Steinberg::Vst::IParamValueQueue>> {
public:
    struct Point { Steinberg::int32 offset {0}; ParamValue value {0.0}; };

    explicit FixedParamValueQueue(ParamID id) : id_(id) {}
    ParamID PLUGIN_API getParameterId() override { return id_; }
    Steinberg::int32 PLUGIN_API getPointCount() override { return static_cast<Steinberg::int32>(count_); }

    Steinberg::tresult PLUGIN_API getPoint(Steinberg::int32 index,
                                           Steinberg::int32& sampleOffset,
                                           ParamValue& value) override {
        if (index < 0 || static_cast<std::size_t>(index) >= count_) return Steinberg::kInvalidArgument;
        const auto& p = points_[static_cast<std::size_t>(index)];
        sampleOffset = p.offset;
        value = p.value;
        return Steinberg::kResultTrue;
    }

    Steinberg::tresult PLUGIN_API addPoint(Steinberg::int32 sampleOffset,
                                           ParamValue value,
                                           Steinberg::int32& index) override {
        if (sampleOffset < 0 || !std::isfinite(value) || value < 0.0 || value > 1.0)
            return Steinberg::kInvalidArgument;
        // Replace an existing point at the same sample offset.
        for (std::size_t i = 0U; i < count_; ++i) {
            if (points_[i].offset == sampleOffset) {
                points_[i].value = value;
                index = static_cast<Steinberg::int32>(i);
                return Steinberg::kResultTrue;
            }
        }
        if (count_ >= points_.size()) return Steinberg::kResultFalse;
        std::size_t pos = count_;
        while (pos > 0U && points_[pos - 1U].offset > sampleOffset) {
            points_[pos] = points_[pos - 1U];
            --pos;
        }
        points_[pos] = {sampleOffset, value};
        ++count_;
        index = static_cast<Steinberg::int32>(pos);
        return Steinberg::kResultTrue;
    }

    void clear() noexcept { count_ = 0U; active_ = false; }
    void setActive(bool active) noexcept { active_ = active; }
    [[nodiscard]] bool active() const noexcept { return active_; }

private:
    ParamID id_ {0U};
    std::array<Point, kMaxParamPointsPerBlock> points_ {};
    std::size_t count_ {0U};
    bool active_ {false};
};

class FixedParameterChanges final
    : public Steinberg::U::ImplementsNonDestroyable<Steinberg::U::Directly<Steinberg::Vst::IParameterChanges>> {
public:
    bool configure(std::vector<ParamID> ids) {
        if (ids.size() > kMaxParameterCount) return false;
        std::sort(ids.begin(), ids.end());
        ids.erase(std::unique(ids.begin(), ids.end()), ids.end());
        queues_.clear();
        queues_.reserve(ids.size());
        for (const auto id : ids) queues_.push_back(std::make_unique<FixedParamValueQueue>(id));
        active_.clear();
        active_.reserve(ids.size());
        return true;
    }

    void clear() noexcept {
        for (auto index : active_) queues_[index]->clear();
        active_.clear();
    }

    bool addPoint(ParamID id, Steinberg::int32 offset, ParamValue value) noexcept {
        Steinberg::int32 activeIndex = 0;
        auto* queue = addParameterData(id, activeIndex);
        if (queue == nullptr) return false;
        Steinberg::int32 pointIndex = 0;
        return queue->addPoint(offset, value, pointIndex) == Steinberg::kResultTrue;
    }

    Steinberg::int32 PLUGIN_API getParameterCount() override {
        return static_cast<Steinberg::int32>(active_.size());
    }

    Steinberg::Vst::IParamValueQueue* PLUGIN_API getParameterData(Steinberg::int32 index) override {
        if (index < 0 || static_cast<std::size_t>(index) >= active_.size()) return nullptr;
        return queues_[active_[static_cast<std::size_t>(index)]].get();
    }

    Steinberg::Vst::IParamValueQueue* PLUGIN_API addParameterData(const ParamID& id,
                                                                  Steinberg::int32& index) override {
        const auto it = std::lower_bound(queues_.begin(), queues_.end(), id,
            [](const auto& q, ParamID value) { return q->getParameterId() < value; });
        if (it == queues_.end() || (*it)->getParameterId() != id) return nullptr;
        const auto queueIndex = static_cast<std::size_t>(std::distance(queues_.begin(), it));
        auto* queue = it->get();
        if (!queue->active()) {
            if (active_.size() >= active_.capacity()) return nullptr;
            queue->setActive(true);
            active_.push_back(queueIndex);
        }
        const auto activeIt = std::find(active_.begin(), active_.end(), queueIndex);
        index = activeIt == active_.end() ? -1 : static_cast<Steinberg::int32>(std::distance(active_.begin(), activeIt));
        return queue;
    }

private:
    std::vector<std::unique_ptr<FixedParamValueQueue>> queues_;
    std::vector<std::size_t> active_;
};

struct BusActivationRequest {
    Steinberg::Vst::MediaType type {Steinberg::Vst::kAudio};
    Steinberg::Vst::BusDirection direction {Steinberg::Vst::kInput};
    Steinberg::int32 index {0};
    Steinberg::TBool active {false};
};

class HostComponentHandler final
    : public Steinberg::U::Implements<
          Steinberg::U::Directly<Steinberg::Vst::IComponentHandler,
                                 Steinberg::Vst::IComponentHandlerBusActivation>> {
public:
    void setComponent(IComponent* component) noexcept { component_ = component; }

    Steinberg::tresult PLUGIN_API beginEdit(ParamID id) override {
        return gestures_.push({AutomationGestureType::Begin, id, -1, 0.0}) ? Steinberg::kResultTrue : Steinberg::kResultFalse;
    }
    Steinberg::tresult PLUGIN_API performEdit(ParamID id, ParamValue valueNormalized) override {
        if (!std::isfinite(valueNormalized) || valueNormalized < 0.0 || valueNormalized > 1.0)
            return Steinberg::kInvalidArgument;
        return gestures_.push({AutomationGestureType::Value, id, -1, valueNormalized}) ? Steinberg::kResultTrue : Steinberg::kResultFalse;
    }
    Steinberg::tresult PLUGIN_API endEdit(ParamID id) override {
        return gestures_.push({AutomationGestureType::End, id, -1, 0.0}) ? Steinberg::kResultTrue : Steinberg::kResultFalse;
    }
    Steinberg::tresult PLUGIN_API restartComponent(Steinberg::int32 flags) override {
        std::uint32_t translated = 0U;
        if ((flags & Steinberg::Vst::kReloadComponent) != 0) translated |= Vst3RestartReloadComponent;
        if ((flags & Steinberg::Vst::kIoChanged) != 0) translated |= Vst3RestartIoChanged;
        if ((flags & Steinberg::Vst::kParamValuesChanged) != 0) translated |= Vst3RestartParamValuesChanged;
        if ((flags & Steinberg::Vst::kLatencyChanged) != 0) translated |= Vst3RestartLatencyChanged;
        if ((flags & Steinberg::Vst::kMidiCCAssignmentChanged) != 0) translated |= Vst3RestartMidiMappingChanged;
        restartFlags_.fetch_or(translated, std::memory_order_release);
        return Steinberg::kResultTrue;
    }
    Steinberg::tresult PLUGIN_API requestBusActivation(Steinberg::Vst::MediaType type,
                                                       Steinberg::Vst::BusDirection dir,
                                                       Steinberg::int32 index,
                                                       Steinberg::TBool state) override {
        BusActivationRequest request {type, dir, index, state};
        return busRequests_.push(request) ? Steinberg::kResultTrue : Steinberg::kResultFalse;
    }

    bool popGesture(AutomationGesture& event) noexcept { return gestures_.pop(event); }
    bool popAppliedBusRequest(BusActivationRequest& request) noexcept { return appliedBusRequests_.pop(request); }

    std::uint32_t consumeRestartFlagsAndServiceBuses() noexcept {
        bool busChanged = false;
        BusActivationRequest request;
        while (busRequests_.pop(request)) {
            if (component_ != nullptr && component_->activateBus(request.type, request.direction, request.index, request.active) == Steinberg::kResultTrue) {
                busChanged = true;
                (void)appliedBusRequests_.push(request);
            }
        }
        auto result = restartFlags_.exchange(0U, std::memory_order_acq_rel);
        if (busChanged) result |= Vst3RestartIoChanged;
        return result;
    }

private:
    IComponent* component_ {nullptr};
    FixedSpscQueue<AutomationGesture, kGestureQueueCapacity> gestures_;
    FixedSpscQueue<BusActivationRequest, kBusRequestQueueCapacity> busRequests_;
    FixedSpscQueue<BusActivationRequest, kBusRequestQueueCapacity> appliedBusRequests_;
    std::atomic<std::uint32_t> restartFlags_ {0U};
};

struct AudioBusScratch {
    Steinberg::int32 channels {0};
    std::vector<std::vector<float>> channelData;
};

std::string busName(const Steinberg::Vst::BusInfo& info) {
    return Steinberg::Vst::StringConvert::convert(info.name, 128U);
}

Vst3BusDescriptor makeBusDescriptor(const Steinberg::Vst::BusInfo& info, bool input, bool event, Steinberg::int32 index) {
    Vst3BusDescriptor d;
    d.input = input;
    d.event = event;
    d.main = info.busType == Steinberg::Vst::kMain;
    d.defaultActive = (info.flags & Steinberg::Vst::BusInfo::kDefaultActive) != 0U;
    d.index = index;
    d.channels = info.channelCount;
    d.name = busName(info);
    return d;
}

class Vst3PluginInstance final : public IVst3PluginInstance {
public:
    Vst3PluginInstance(VST3::Hosting::Module::Ptr module,
                       VST3::Hosting::ClassInfo classInfo,
                       std::string modulePath,
                       std::string classId,
                       std::string& failureReason)
        : module_(std::move(module)), classInfo_(std::move(classInfo)), modulePath_(std::move(modulePath)), classId_(std::move(classId)) {
        auto* host = sharedHostApplication();
        module_->getFactory().setHostContext(host);
        Steinberg::Vst::PluginContextFactory::instance().setPluginContext(host);

        provider_ = Steinberg::owned(new Steinberg::Vst::PlugProvider(module_->getFactory(), classInfo_, false));
        if (!provider_->initialize()) {
            failureReason = "PlugProvider initialization failed";
            return;
        }
        component_ = provider_->getComponentPtr();
        controller_ = provider_->getControllerPtr();
        if (!component_ || !controller_) {
            failureReason = "plug-in component/controller unavailable";
            return;
        }
        processor_ = Steinberg::FUnknownPtr<IAudioProcessor>(component_);
        if (!processor_) {
            failureReason = "plug-in does not implement IAudioProcessor";
            return;
        }
        midiMapping_ = Steinberg::FUnknownPtr<IMidiMapping>(controller_);
        handler_ = Steinberg::owned(new HostComponentHandler());
        handler_->setComponent(component_.get());
        if (controller_->setComponentHandler(handler_.get()) != Steinberg::kResultTrue) {
            failureReason = "setComponentHandler failed";
            return;
        }
        if (!enumerateBuses(failureReason) || !enumerateParameters(failureReason)) return;
        buildMidiMapping();
        valid_ = true;
    }

    ~Vst3PluginInstance() override {
        closeEditor();
        if (processing_ && processor_) (void)processor_->setProcessing(false);
        if (active_ && component_) (void)component_->setActive(false);
        if (controller_) (void)controller_->setComponentHandler(nullptr);
        if (handler_) handler_->setComponent(nullptr);
        processData_.unprepare();
        provider_ = nullptr;
        component_ = nullptr;
        controller_ = nullptr;
        processor_ = nullptr;
        midiMapping_ = nullptr;
        handler_ = nullptr;
    }

    [[nodiscard]] bool valid() const noexcept { return valid_; }
    [[nodiscard]] const Vst3InstanceInfo& info() const noexcept { return info_; }

    const std::string& modulePath() const noexcept override { return modulePath_; }
    const std::string& classId() const noexcept override { return classId_; }
    std::size_t inputBusChannelCount(std::size_t bus) const noexcept override {
        return bus < audioInputBuses_.size() ? static_cast<std::size_t>(std::max<Steinberg::int32>(0, audioInputBuses_[bus].channelCount)) : 0U;
    }
    std::size_t outputBusChannelCount(std::size_t bus) const noexcept override {
        return bus < audioOutputBuses_.size() ? static_cast<std::size_t>(std::max<Steinberg::int32>(0, audioOutputBuses_[bus].channelCount)) : 0U;
    }

    void prepare(double sampleRate, std::uint32_t maxFrames) override {
        if (!valid_ || sampleRate <= 0.0 || maxFrames == 0U) throw std::invalid_argument("invalid VST3 prepare arguments");
        prepared_ = false;
        if (processing_) { (void)processor_->setProcessing(false); processing_ = false; }
        if (active_) { (void)component_->setActive(false); active_ = false; }

        negotiateMainStereo();
        refreshAudioBusInfoAfterNegotiation();
        activateRequiredBuses();

        Steinberg::Vst::ProcessSetup setup {};
        setup.processMode = Steinberg::Vst::kRealtime;
        setup.symbolicSampleSize = Steinberg::Vst::kSample32;
        setup.maxSamplesPerBlock = static_cast<Steinberg::int32>(maxFrames);
        setup.sampleRate = sampleRate;
        if (processor_->canProcessSampleSize(Steinberg::Vst::kSample32) != Steinberg::kResultTrue)
            throw std::runtime_error("VST3 plug-in does not support Float32 processing");
        if (processor_->setupProcessing(setup) != Steinberg::kResultTrue)
            throw std::runtime_error("VST3 setupProcessing failed");
        processData_.unprepare();
        if (!processData_.prepare(*component_, 0, Steinberg::Vst::kSample32))
            throw std::runtime_error("VST3 HostProcessData prepare failed");

        allocateScratch(maxFrames);
        maxFrames_ = maxFrames;
        sampleRate_ = sampleRate;
        if (component_->setActive(true) != Steinberg::kResultTrue)
            throw std::runtime_error("VST3 setActive(true) failed");
        active_ = true;
        if (processor_->setProcessing(true) != Steinberg::kResultTrue) {
            (void)component_->setActive(false);
            active_ = false;
            throw std::runtime_error("VST3 setProcessing(true) failed");
        }
        processing_ = true;
        prepared_ = true;
        clearRtQueues();
    }

    void reset() noexcept override {
        clearRtQueues();
        if (!processor_ || !active_) return;
        if (processing_) (void)processor_->setProcessing(false);
        processing_ = processor_->setProcessing(true) == Steinberg::kResultTrue;
    }

    std::uint32_t latencySamples() const noexcept override {
        return processor_ ? processor_->getLatencySamples() : 0U;
    }

    void process(float* left, float* right, std::uint32_t frames, const ProcessorContext& context) noexcept override {
        ConstStereoBus input {left, right};
        StereoBus output {left, right};
        (void)processBuses(&input, 1U, &output, 1U, frames, context);
    }

    std::size_t inputBusCount() const noexcept override { return audioInputBuses_.size(); }
    std::size_t outputBusCount() const noexcept override { return audioOutputBuses_.size(); }

    bool processBuses(const ConstStereoBus* inputs,
                      std::size_t inputBusCount,
                      StereoBus* outputs,
                      std::size_t outputBusCount,
                      std::uint32_t frames,
                      const ProcessorContext& context) noexcept override {
        if (!prepared_ || !processing_ || frames > maxFrames_ || outputs == nullptr || outputBusCount == 0U) return false;
        inputParamChanges_.clear();
        outputParamChanges_.clear();
        inputEvents_.clear();
        outputEvents_.clear();

        drainParameterQueue(frames);
        drainMidiQueue(frames, context);
        prepareProcessContext(context);

        processData_.numSamples = static_cast<Steinberg::int32>(frames);
        processData_.processMode = Steinberg::Vst::kRealtime;
        processData_.symbolicSampleSize = Steinberg::Vst::kSample32;
        processData_.inputParameterChanges = &inputParamChanges_;
        processData_.outputParameterChanges = &outputParamChanges_;
        processData_.inputEvents = &inputEvents_;
        processData_.outputEvents = &outputEvents_;
        processData_.processContext = &processContext_;

        mapInputBuffers(inputs, inputBusCount, frames);
        mapOutputBuffers(outputs, outputBusCount, frames);
        const auto result = processor_->process(processData_);
        captureOutputParameters();
        captureOutputEvents();
        duplicateMonoOutputs(outputs, outputBusCount, frames);
        detachBuffers();
        return result == Steinberg::kResultTrue || result == Steinberg::kResultOk;
    }

    bool setComponentState(const std::vector<std::uint8_t>& state) override {
        if (!component_ || !controller_) return false;
        Steinberg::ResizableMemoryIBStream stream(state.size());
        if (!writeStream(stream, state)) return false;
        stream.rewind();
        if (component_->setState(&stream) != Steinberg::kResultTrue) return false;
        stream.rewind();
        return controller_->setComponentState(&stream) == Steinberg::kResultTrue;
    }

    bool setControllerState(const std::vector<std::uint8_t>& state) override {
        if (!controller_) return false;
        Steinberg::ResizableMemoryIBStream stream(state.size());
        if (!writeStream(stream, state)) return false;
        stream.rewind();
        return controller_->setState(&stream) == Steinberg::kResultTrue;
    }

    std::vector<std::uint8_t> componentState() const override {
        if (!component_) return {};
        Steinberg::ResizableMemoryIBStream stream;
        if (component_->getState(&stream) != Steinberg::kResultTrue) return {};
        auto data = stream.take();
        return {data.begin(), data.end()};
    }

    std::vector<std::uint8_t> controllerState() const override {
        if (!controller_) return {};
        Steinberg::ResizableMemoryIBStream stream;
        if (controller_->getState(&stream) != Steinberg::kResultTrue) return {};
        auto data = stream.take();
        return {data.begin(), data.end()};
    }

    bool savePreset(const std::string& path) const override {
        if (!component_ || !controller_ || path.empty()) return false;
        Steinberg::IPtr<Steinberg::IBStream> stream = Steinberg::owned(Steinberg::Vst::FileStream::open(path.c_str(), "wb"));
        if (!stream) return false;
        const auto classUid = Steinberg::FUID::fromTUID(classInfo_.ID().data());
        return Steinberg::Vst::PresetFile::savePreset(stream.get(), classUid, component_.get(), controller_.get());
    }

    bool loadPreset(const std::string& path) override {
        if (!component_ || !controller_ || path.empty()) return false;
        Steinberg::IPtr<Steinberg::IBStream> stream = Steinberg::owned(Steinberg::Vst::FileStream::open(path.c_str(), "rb"));
        if (!stream) return false;
        const auto classUid = Steinberg::FUID::fromTUID(classInfo_.ID().data());
        return Steinberg::Vst::PresetFile::loadPreset(stream.get(), classUid, component_.get(), controller_.get());
    }

    bool hasEventInput() const noexcept override { return eventInputBusCount_ > 0; }
    bool queueMidi(const Vst3MidiEvent& event) noexcept override { return midiInputQueue_.push(event); }
    bool queueParameter(std::uint32_t parameterId, double normalized, std::int32_t frameOffset) noexcept override {
        if (!std::isfinite(normalized) || normalized < 0.0 || normalized > 1.0 || frameOffset < 0) return false;
        return parameterInputQueue_.push({parameterId, frameOffset, normalized});
    }
    bool popAutomationGesture(AutomationGesture& event) noexcept override { return handler_ && handler_->popGesture(event); }
    bool popOutputParameter(Vst3OutputParameterChange& change) noexcept override { return outputParameterQueue_.pop(change); }
    bool popMidiOutput(Vst3MidiEvent& event) noexcept override { return midiOutputQueue_.pop(event); }
    bool syncControllerParameter(std::uint32_t parameterId, double normalized) override {
        if (!controller_ || !std::isfinite(normalized) || normalized < 0.0 || normalized > 1.0) return false;
        return controller_->setParamNormalized(parameterId, normalized) == Steinberg::kResultTrue;
    }
    std::uint32_t consumeRestartFlags() noexcept override {
        if (!handler_) return 0U;
        const auto flags = handler_->consumeRestartFlagsAndServiceBuses();
        BusActivationRequest request;
        while (handler_->popAppliedBusRequest(request)) rememberBusActivation(request);
        return flags;
    }

    bool serviceParameterValuesChanged() override {
        if (!controller_) return false;
        // This is a control-thread operation. The SPSC queue is preallocated to
        // hold at least one point for every accepted plug-in parameter.
        for (const auto& parameter : info_.parameters) {
            const double value = controller_->getParamNormalized(parameter.id);
            if (!std::isfinite(value) || value < 0.0 || value > 1.0) return false;
            if (!parameterInputQueue_.push({parameter.id, 0, value})) return false;
        }
        return true;
    }

    bool serviceMidiMappingChanged() override {
        buildMidiMapping();
        return true;
    }

    bool serviceLatencyChange() override {
        if (!valid_ || !prepared_ || !component_ || !processor_) return valid_;
        const bool wasProcessing = processing_;
        if (wasProcessing) {
            if (processor_->setProcessing(false) != Steinberg::kResultTrue) return false;
            processing_ = false;
        }
        if (active_) {
            if (component_->setActive(false) != Steinberg::kResultTrue) return false;
            active_ = false;
        }
        if (component_->setActive(true) != Steinberg::kResultTrue) return false;
        active_ = true;
        if (wasProcessing) {
            if (processor_->setProcessing(true) != Steinberg::kResultTrue) return false;
            processing_ = true;
        }
        return true;
    }

    bool reconfigureAfterIoChange() override {
        if (!valid_) return false;
        const double sr = sampleRate_;
        const std::uint32_t frames = maxFrames_;
        if (processing_ && processor_) { (void)processor_->setProcessing(false); processing_ = false; }
        if (active_ && component_) { (void)component_->setActive(false); active_ = false; }
        prepared_ = false;
        std::string reason;
        if (!enumerateBuses(reason)) return false;
        if (sr <= 0.0 || frames == 0U) return true;
        try {
            prepare(sr, frames);
            return true;
        } catch (...) {
            return false;
        }
    }

    bool openEditor() override {
#if defined(__APPLE__)
        if (!controller_) return false;
        if (editorHandle_ != nullptr) {
            if (detail::vst3CocoaEditorIsOpen(editorHandle_)) return true;
            detail::closeVst3CocoaEditor(editorHandle_);
        }
        editorHandle_ = detail::openVst3CocoaEditor(controller_.get());
        return editorHandle_ != nullptr;
#else
        return false;
#endif
    }
    void closeEditor() noexcept override {
#if defined(__APPLE__)
        detail::closeVst3CocoaEditor(editorHandle_);
#endif
    }
    bool editorOpen() const noexcept override {
#if defined(__APPLE__)
        return detail::vst3CocoaEditorIsOpen(editorHandle_);
#else
        return false;
#endif
    }

private:
    struct QueuedParameter { std::uint32_t id {0U}; std::int32_t offset {0}; double value {0.0}; };
    struct MidiMapEntry { bool valid {false}; ParamID id {0U}; };

    bool enumerateBuses(std::string& failureReason) {
        const auto enumerate = [&](Steinberg::Vst::MediaType media, BusDirection dir,
                                   std::vector<BusInfo>& raw, std::vector<Vst3BusDescriptor>& publicList) -> bool {
            const Steinberg::int32 count = component_->getBusCount(media, dir);
            if (count < 0 || static_cast<std::size_t>(count) > kMaxAudioBuses) {
                failureReason = "VST3 bus count exceeds Silveton safety limit";
                return false;
            }
            raw.resize(static_cast<std::size_t>(count));
            std::size_t totalChannels = 0U;
            for (Steinberg::int32 i = 0; i < count; ++i) {
                BusInfo info {};
                if (component_->getBusInfo(media, dir, i, info) != Steinberg::kResultTrue) {
                    failureReason = "VST3 getBusInfo failed";
                    return false;
                }
                if (info.channelCount < 0 || static_cast<std::size_t>(info.channelCount) > kMaxChannelsPerBus) {
                    failureReason = "VST3 channel count exceeds Silveton safety limit";
                    return false;
                }
                totalChannels += static_cast<std::size_t>(info.channelCount);
                if (media == Steinberg::Vst::kAudio && totalChannels > kMaxChannelsPerDirection) {
                    failureReason = "VST3 total channel count exceeds Silveton safety limit";
                    return false;
                }
                raw[static_cast<std::size_t>(i)] = info;
                publicList.push_back(makeBusDescriptor(info, dir == Steinberg::Vst::kInput,
                                                       media == Steinberg::Vst::kEvent, i));
            }
            return true;
        };
        info_.audioBuses.clear();
        info_.eventBuses.clear();
        if (!enumerate(Steinberg::Vst::kAudio, Steinberg::Vst::kInput, audioInputBuses_, info_.audioBuses)) return false;
        if (!enumerate(Steinberg::Vst::kAudio, Steinberg::Vst::kOutput, audioOutputBuses_, info_.audioBuses)) return false;
        if (!enumerate(Steinberg::Vst::kEvent, Steinberg::Vst::kInput, eventInputBuses_, info_.eventBuses)) return false;
        if (!enumerate(Steinberg::Vst::kEvent, Steinberg::Vst::kOutput, eventOutputBuses_, info_.eventBuses)) return false;
        eventInputBusCount_ = static_cast<int>(eventInputBuses_.size());
        return true;
    }

    bool enumerateParameters(std::string& failureReason) {
        const Steinberg::int32 count = controller_->getParameterCount();
        if (count < 0 || static_cast<std::size_t>(count) > kMaxParameterCount) {
            failureReason = "VST3 parameter count exceeds Silveton safety limit";
            return false;
        }
        std::vector<ParamID> ids;
        ids.reserve(static_cast<std::size_t>(count));
        info_.parameters.clear();
        info_.parameters.reserve(static_cast<std::size_t>(count));
        for (Steinberg::int32 i = 0; i < count; ++i) {
            Steinberg::Vst::ParameterInfo p {};
            if (controller_->getParameterInfo(i, p) != Steinberg::kResultTrue) {
                failureReason = "VST3 getParameterInfo failed";
                return false;
            }
            ids.push_back(p.id);
            info_.parameters.push_back({p.id,
                                        Steinberg::Vst::StringConvert::convert(p.title, 128U),
                                        Steinberg::Vst::StringConvert::convert(p.shortTitle, 128U),
                                        Steinberg::Vst::StringConvert::convert(p.units, 128U),
                                        p.stepCount, p.defaultNormalizedValue, p.flags});
        }
        if (!inputParamChanges_.configure(ids) || !outputParamChanges_.configure(std::move(ids))) {
            failureReason = "VST3 parameter queue configuration failed";
            return false;
        }
        return true;
    }

    void negotiateMainStereo() noexcept {
        const auto inCount = static_cast<Steinberg::int32>(audioInputBuses_.size());
        const auto outCount = static_cast<Steinberg::int32>(audioOutputBuses_.size());
        if (inCount == 0 && outCount == 0) return;
        std::vector<Steinberg::Vst::SpeakerArrangement> inputs(static_cast<std::size_t>(inCount));
        std::vector<Steinberg::Vst::SpeakerArrangement> outputs(static_cast<std::size_t>(outCount));
        bool complete = true;
        for (Steinberg::int32 i = 0; i < inCount; ++i)
            complete = complete && processor_->getBusArrangement(Steinberg::Vst::kInput, i, inputs[static_cast<std::size_t>(i)]) == Steinberg::kResultTrue;
        for (Steinberg::int32 i = 0; i < outCount; ++i)
            complete = complete && processor_->getBusArrangement(Steinberg::Vst::kOutput, i, outputs[static_cast<std::size_t>(i)]) == Steinberg::kResultTrue;
        if (!complete) return;
        if (inCount > 0 && audioInputBuses_[0].busType == Steinberg::Vst::kMain) inputs[0] = Steinberg::Vst::SpeakerArr::kStereo;
        if (outCount > 0 && audioOutputBuses_[0].busType == Steinberg::Vst::kMain) outputs[0] = Steinberg::Vst::SpeakerArr::kStereo;
        // A false result is explicitly allowed by VST3: the plug-in may keep/fall back to its default.
        (void)processor_->setBusArrangements(inputs.data(), inCount, outputs.data(), outCount);
    }

    void refreshAudioBusInfoAfterNegotiation() {
        auto refresh = [&](BusDirection dir, std::vector<BusInfo>& buses) {
            std::size_t totalChannels = 0U;
            for (Steinberg::int32 i = 0; i < static_cast<Steinberg::int32>(buses.size()); ++i) {
                BusInfo info {};
                if (component_->getBusInfo(Steinberg::Vst::kAudio, dir, i, info) != Steinberg::kResultTrue)
                    throw std::runtime_error("VST3 getBusInfo failed after bus negotiation");
                if (info.channelCount < 0 || static_cast<std::size_t>(info.channelCount) > kMaxChannelsPerBus)
                    throw std::runtime_error("VST3 negotiated channel count exceeds Silveton safety limit");
                totalChannels += static_cast<std::size_t>(info.channelCount);
                if (totalChannels > kMaxChannelsPerDirection)
                    throw std::runtime_error("VST3 negotiated total channel count exceeds Silveton safety limit");
                buses[static_cast<std::size_t>(i)] = info;
            }
        };
        refresh(Steinberg::Vst::kInput, audioInputBuses_);
        refresh(Steinberg::Vst::kOutput, audioOutputBuses_);

        info_.audioBuses.clear();
        for (std::size_t i = 0U; i < audioInputBuses_.size(); ++i)
            info_.audioBuses.push_back(makeBusDescriptor(audioInputBuses_[i], true, false, static_cast<Steinberg::int32>(i)));
        for (std::size_t i = 0U; i < audioOutputBuses_.size(); ++i)
            info_.audioBuses.push_back(makeBusDescriptor(audioOutputBuses_[i], false, false, static_cast<Steinberg::int32>(i)));
    }

    void rememberBusActivation(const BusActivationRequest& request) noexcept {
        if (request.index < 0 || static_cast<std::size_t>(request.index) >= kMaxAudioBuses) return;
        const auto i = static_cast<std::size_t>(request.index);
        auto set = [&](auto& known, auto& states) { known[i] = true; states[i] = request.active != 0; };
        if (request.type == Steinberg::Vst::kAudio && request.direction == Steinberg::Vst::kInput) set(audioInputOverrideKnown_, audioInputActive_);
        else if (request.type == Steinberg::Vst::kAudio && request.direction == Steinberg::Vst::kOutput) set(audioOutputOverrideKnown_, audioOutputActive_);
        else if (request.type == Steinberg::Vst::kEvent && request.direction == Steinberg::Vst::kInput) set(eventInputOverrideKnown_, eventInputActive_);
        else if (request.type == Steinberg::Vst::kEvent && request.direction == Steinberg::Vst::kOutput) set(eventOutputOverrideKnown_, eventOutputActive_);
    }

    void activateRequiredBuses() {
        const auto activate = [&](Steinberg::Vst::MediaType type, BusDirection dir, Steinberg::int32 count,
                                  auto& known, auto& states, bool requireAll) {
            for (Steinberg::int32 i = 0; i < count; ++i) {
                const auto index = static_cast<std::size_t>(i);
                const bool desired = known[index] ? states[index] : true;
                const auto result = component_->activateBus(type, dir, i, desired ? 1 : 0);
                if (result != Steinberg::kResultTrue && (requireAll || i == 0))
                    throw std::runtime_error("VST3 bus activation failed");
                states[index] = desired;
            }
        };
        activate(Steinberg::Vst::kAudio, Steinberg::Vst::kInput, static_cast<Steinberg::int32>(audioInputBuses_.size()),
                 audioInputOverrideKnown_, audioInputActive_, true);
        activate(Steinberg::Vst::kAudio, Steinberg::Vst::kOutput, static_cast<Steinberg::int32>(audioOutputBuses_.size()),
                 audioOutputOverrideKnown_, audioOutputActive_, true);
        activate(Steinberg::Vst::kEvent, Steinberg::Vst::kInput, static_cast<Steinberg::int32>(eventInputBuses_.size()),
                 eventInputOverrideKnown_, eventInputActive_, false);
        activate(Steinberg::Vst::kEvent, Steinberg::Vst::kOutput, static_cast<Steinberg::int32>(eventOutputBuses_.size()),
                 eventOutputOverrideKnown_, eventOutputActive_, false);
    }

    void allocateScratch(std::uint32_t maxFrames) {
        const auto makeScratch = [maxFrames](const std::vector<BusInfo>& buses) {
            std::vector<AudioBusScratch> result;
            result.resize(buses.size());
            for (std::size_t b = 0U; b < buses.size(); ++b) {
                result[b].channels = buses[b].channelCount;
                result[b].channelData.resize(static_cast<std::size_t>(std::max<Steinberg::int32>(0, buses[b].channelCount)));
                for (auto& channel : result[b].channelData) channel.assign(maxFrames, 0.0F);
            }
            return result;
        };
        inputScratch_ = makeScratch(audioInputBuses_);
        outputDiscard_ = makeScratch(audioOutputBuses_);
    }

    void clearRtQueues() noexcept {
        midiInputQueue_.clear();
        parameterInputQueue_.clear();
        outputParameterQueue_.clear();
        inputParamChanges_.clear();
        outputParamChanges_.clear();
        inputEvents_.clear();
        outputEvents_.clear();
    }

    void drainParameterQueue(std::uint32_t frames) noexcept {
        QueuedParameter p;
        while (parameterInputQueue_.pop(p)) {
            const auto offset = std::min<std::int32_t>(p.offset, static_cast<std::int32_t>(frames > 0U ? frames - 1U : 0U));
            (void)inputParamChanges_.addPoint(p.id, offset, p.value);
        }
    }

    void buildMidiMapping() {
        for (auto& row : midiControllerMap_)
            for (auto& entry : row) entry = {};
        if (!midiMapping_) return;
        for (Steinberg::int32 channel = 0; channel < 16; ++channel) {
            for (std::size_t c = 0U; c < kMidiControllerMapSize; ++c) {
                ParamID id = 0U;
                const auto control = static_cast<Steinberg::Vst::CtrlNumber>(c);
                if (midiMapping_->getMidiControllerAssignment(0, static_cast<Steinberg::int16>(channel), control, id) == Steinberg::kResultTrue)
                    midiControllerMap_[static_cast<std::size_t>(channel)][c] = {true, id};
            }
        }
    }

    void addMappedMidiParameter(Steinberg::int32 channel, Steinberg::Vst::CtrlNumber control,
                                double value, Steinberg::int32 offset) noexcept {
        if (channel < 0 || channel >= 16) return;
        const auto c = static_cast<std::size_t>(control);
        if (c >= kMidiControllerMapSize) return;
        const auto& entry = midiControllerMap_[static_cast<std::size_t>(channel)][c];
        if (entry.valid) (void)inputParamChanges_.addPoint(entry.id, offset, std::clamp(value, 0.0, 1.0));
    }

    void drainMidiQueue(std::uint32_t frames, const ProcessorContext& context) noexcept {
        Vst3MidiEvent midi;
        while (midiInputQueue_.pop(midi)) {
            const auto status = static_cast<std::uint8_t>(midi.status & 0xF0U);
            const auto channel = static_cast<Steinberg::int16>(midi.status & 0x0FU);
            const auto offset = std::clamp<Steinberg::int32>(midi.frameOffset, 0,
                static_cast<Steinberg::int32>(frames > 0U ? frames - 1U : 0U));
            Steinberg::Vst::Event event {};
            event.busIndex = 0;
            event.sampleOffset = offset;
            event.ppqPosition = context.projectQuarterNotes +
                (context.sampleRate > 0.0 ? (static_cast<double>(offset) * context.tempo / (60.0 * context.sampleRate)) : 0.0);
            event.flags = 0;
            if (status == 0x90U && midi.data2 != 0U) {
                event.type = Steinberg::Vst::Event::kNoteOnEvent;
                event.noteOn.channel = channel;
                event.noteOn.pitch = static_cast<Steinberg::int16>(midi.data1 & 0x7FU);
                event.noteOn.tuning = 0.0F;
                event.noteOn.velocity = static_cast<float>(midi.data2 & 0x7FU) / 127.0F;
                event.noteOn.length = 0;
                event.noteOn.noteId = -1;
                (void)inputEvents_.addEvent(event);
            } else if (status == 0x80U || (status == 0x90U && midi.data2 == 0U)) {
                event.type = Steinberg::Vst::Event::kNoteOffEvent;
                event.noteOff.channel = channel;
                event.noteOff.pitch = static_cast<Steinberg::int16>(midi.data1 & 0x7FU);
                event.noteOff.velocity = static_cast<float>(midi.data2 & 0x7FU) / 127.0F;
                event.noteOff.noteId = -1;
                event.noteOff.tuning = 0.0F;
                (void)inputEvents_.addEvent(event);
            } else if (status == 0xA0U) {
                event.type = Steinberg::Vst::Event::kPolyPressureEvent;
                event.polyPressure.channel = channel;
                event.polyPressure.pitch = static_cast<Steinberg::int16>(midi.data1 & 0x7FU);
                event.polyPressure.pressure = static_cast<float>(midi.data2 & 0x7FU) / 127.0F;
                event.polyPressure.noteId = -1;
                (void)inputEvents_.addEvent(event);
            } else if (status == 0xB0U) {
                addMappedMidiParameter(channel, static_cast<Steinberg::Vst::CtrlNumber>(midi.data1 & 0x7FU),
                                       static_cast<double>(midi.data2 & 0x7FU) / 127.0, offset);
            } else if (status == 0xC0U) {
                addMappedMidiParameter(channel, Steinberg::Vst::kCtrlProgramChange,
                                       static_cast<double>(midi.data1 & 0x7FU) / 127.0, offset);
            } else if (status == 0xD0U) {
                addMappedMidiParameter(channel, Steinberg::Vst::kAfterTouch,
                                       static_cast<double>(midi.data1 & 0x7FU) / 127.0, offset);
            } else if (status == 0xE0U) {
                const auto bend = static_cast<unsigned>(midi.data1 & 0x7FU) | (static_cast<unsigned>(midi.data2 & 0x7FU) << 7U);
                addMappedMidiParameter(channel, Steinberg::Vst::kPitchBend, static_cast<double>(bend) / 16383.0, offset);
            }
        }
    }

    void prepareProcessContext(const ProcessorContext& c) noexcept {
        processContext_ = {};
        processContext_.sampleRate = c.sampleRate;
        processContext_.projectTimeSamples = c.projectSample;
        processContext_.projectTimeMusic = c.projectQuarterNotes;
        processContext_.tempo = c.tempo;
        processContext_.state = Steinberg::Vst::ProcessContext::kProjectTimeMusicValid |
                                Steinberg::Vst::ProcessContext::kTempoValid;
        if (c.playing) processContext_.state |= Steinberg::Vst::ProcessContext::kPlaying;
        if (c.recording) processContext_.state |= Steinberg::Vst::ProcessContext::kRecording;
        if (c.cycleActive) {
            processContext_.state |= Steinberg::Vst::ProcessContext::kCycleActive |
                                     Steinberg::Vst::ProcessContext::kCycleValid;
            processContext_.cycleStartMusic = c.cycleStartQuarterNotes;
            processContext_.cycleEndMusic = c.cycleEndQuarterNotes;
        }
    }

    static void copyInputToBus(AudioBusScratch& scratch, ConstStereoBus source, std::uint32_t frames) noexcept {
        if (scratch.channelData.empty()) return;
        auto& c0 = scratch.channelData[0];
        if (scratch.channelData.size() == 1U) {
            for (std::uint32_t i = 0U; i < frames; ++i) {
                const float l = source.left ? source.left[i] : 0.0F;
                const float r = source.right ? source.right[i] : l;
                c0[i] = 0.5F * (l + r);
            }
        } else {
            auto& c1 = scratch.channelData[1];
            for (std::uint32_t i = 0U; i < frames; ++i) {
                c0[i] = source.left ? source.left[i] : 0.0F;
                c1[i] = source.right ? source.right[i] : c0[i];
            }
            for (std::size_t c = 2U; c < scratch.channelData.size(); ++c)
                std::fill_n(scratch.channelData[c].data(), frames, 0.0F);
        }
    }

    void mapInputBuffers(const ConstStereoBus* inputs, std::size_t count, std::uint32_t frames) noexcept {
        for (std::size_t b = 0U; b < inputScratch_.size(); ++b) {
            const ConstStereoBus source = (inputs != nullptr && b < count) ? inputs[b] : ConstStereoBus {};
            copyInputToBus(inputScratch_[b], source, frames);
            for (std::size_t c = 0U; c < inputScratch_[b].channelData.size(); ++c)
                (void)processData_.setChannelBuffer(Steinberg::Vst::kInput, static_cast<Steinberg::int32>(b),
                                                    static_cast<Steinberg::int32>(c), inputScratch_[b].channelData[c].data());
        }
    }

    void mapOutputBuffers(StereoBus* outputs, std::size_t count, std::uint32_t frames) noexcept {
        for (std::size_t b = 0U; b < outputDiscard_.size(); ++b) {
            auto& scratch = outputDiscard_[b];
            for (auto& channel : scratch.channelData) std::fill_n(channel.data(), frames, 0.0F);
            const bool supplied = outputs != nullptr && b < count;
            for (std::size_t c = 0U; c < scratch.channelData.size(); ++c) {
                float* target = scratch.channelData[c].data();
                if (supplied && c == 0U && outputs[b].left != nullptr) target = outputs[b].left;
                else if (supplied && c == 1U && outputs[b].right != nullptr) target = outputs[b].right;
                (void)processData_.setChannelBuffer(Steinberg::Vst::kOutput, static_cast<Steinberg::int32>(b),
                                                    static_cast<Steinberg::int32>(c), target);
            }
        }
    }

    void duplicateMonoOutputs(StereoBus* outputs, std::size_t count, std::uint32_t frames) noexcept {
        if (outputs == nullptr) return;
        const auto n = std::min(count, audioOutputBuses_.size());
        for (std::size_t b = 0U; b < n; ++b) {
            if (audioOutputBuses_[b].channelCount == 1 && outputs[b].left && outputs[b].right && outputs[b].left != outputs[b].right)
                std::copy_n(outputs[b].left, frames, outputs[b].right);
        }
    }

    void detachBuffers() noexcept {
        for (std::size_t b = 0U; b < inputScratch_.size(); ++b)
            for (std::size_t c = 0U; c < inputScratch_[b].channelData.size(); ++c)
                (void)processData_.setChannelBuffer(Steinberg::Vst::kInput, static_cast<Steinberg::int32>(b),
                                                    static_cast<Steinberg::int32>(c), nullptr);
        for (std::size_t b = 0U; b < outputDiscard_.size(); ++b)
            for (std::size_t c = 0U; c < outputDiscard_[b].channelData.size(); ++c)
                (void)processData_.setChannelBuffer(Steinberg::Vst::kOutput, static_cast<Steinberg::int32>(b),
                                                    static_cast<Steinberg::int32>(c), nullptr);
    }

    void captureOutputParameters() noexcept {
        const auto count = outputParamChanges_.getParameterCount();
        for (Steinberg::int32 q = 0; q < count; ++q) {
            auto* queue = outputParamChanges_.getParameterData(q);
            if (queue == nullptr) continue;
            const auto pointCount = queue->getPointCount();
            for (Steinberg::int32 p = 0; p < pointCount; ++p) {
                Steinberg::int32 offset = 0;
                ParamValue value = 0.0;
                if (queue->getPoint(p, offset, value) == Steinberg::kResultTrue)
                    (void)outputParameterQueue_.push({queue->getParameterId(), offset, value});
            }
        }
    }

    void captureOutputEvents() noexcept {
        const auto count = outputEvents_.getEventCount();
        for (Steinberg::int32 i = 0; i < count; ++i) {
            Steinberg::Vst::Event e {};
            if (outputEvents_.getEvent(i, e) != Steinberg::kResultTrue) continue;
            Vst3MidiEvent out {};
            out.frameOffset = e.sampleOffset;
            if (e.type == Steinberg::Vst::Event::kNoteOnEvent) {
                out.status = static_cast<std::uint8_t>(0x90U | (e.noteOn.channel & 0x0F));
                out.data1 = static_cast<std::uint8_t>(std::clamp<int>(e.noteOn.pitch, 0, 127));
                out.data2 = static_cast<std::uint8_t>(std::clamp<int>(static_cast<int>(std::lround(e.noteOn.velocity * 127.0F)), 0, 127));
            } else if (e.type == Steinberg::Vst::Event::kNoteOffEvent) {
                out.status = static_cast<std::uint8_t>(0x80U | (e.noteOff.channel & 0x0F));
                out.data1 = static_cast<std::uint8_t>(std::clamp<int>(e.noteOff.pitch, 0, 127));
                out.data2 = static_cast<std::uint8_t>(std::clamp<int>(static_cast<int>(std::lround(e.noteOff.velocity * 127.0F)), 0, 127));
            } else if (e.type == Steinberg::Vst::Event::kPolyPressureEvent) {
                out.status = static_cast<std::uint8_t>(0xA0U | (e.polyPressure.channel & 0x0F));
                out.data1 = static_cast<std::uint8_t>(std::clamp<int>(e.polyPressure.pitch, 0, 127));
                out.data2 = static_cast<std::uint8_t>(std::clamp<int>(static_cast<int>(std::lround(e.polyPressure.pressure * 127.0F)), 0, 127));
            } else if (e.type == Steinberg::Vst::Event::kLegacyMIDICCOutEvent) {
                const auto& m = e.midiCCOut;
                const auto ch = static_cast<std::uint8_t>(m.channel & 0x0F);
                if (m.controlNumber <= 127) {
                    out.status = static_cast<std::uint8_t>(0xB0U | ch);
                    out.data1 = static_cast<std::uint8_t>(m.controlNumber & 0x7F);
                    out.data2 = static_cast<std::uint8_t>(m.value & 0x7F);
                } else if (m.controlNumber == Steinberg::Vst::kAfterTouch) {
                    out.status = static_cast<std::uint8_t>(0xD0U | ch);
                    out.data1 = static_cast<std::uint8_t>(m.value & 0x7F);
                } else if (m.controlNumber == Steinberg::Vst::kPitchBend) {
                    out.status = static_cast<std::uint8_t>(0xE0U | ch);
                    out.data1 = static_cast<std::uint8_t>(m.value & 0x7F);
                    out.data2 = static_cast<std::uint8_t>(m.value2 & 0x7F);
                } else if (m.controlNumber == Steinberg::Vst::kCtrlProgramChange) {
                    out.status = static_cast<std::uint8_t>(0xC0U | ch);
                    out.data1 = static_cast<std::uint8_t>(m.value & 0x7F);
                } else if (m.controlNumber == Steinberg::Vst::kCtrlPolyPressure) {
                    out.status = static_cast<std::uint8_t>(0xA0U | ch);
                    out.data1 = static_cast<std::uint8_t>(m.value & 0x7F);
                    out.data2 = static_cast<std::uint8_t>(m.value2 & 0x7F);
                } else if (m.controlNumber == Steinberg::Vst::kCtrlQuarterFrame) {
                    out.status = 0xF1U; out.data1 = static_cast<std::uint8_t>(m.value & 0x7F);
                } else if (m.controlNumber == Steinberg::Vst::kSystemSongSelect) {
                    out.status = 0xF3U; out.data1 = static_cast<std::uint8_t>(m.value & 0x7F);
                } else if (m.controlNumber == Steinberg::Vst::kSystemSongPointer) {
                    out.status = 0xF2U; out.data1 = static_cast<std::uint8_t>(m.value & 0x7F);
                    out.data2 = static_cast<std::uint8_t>(m.value2 & 0x7F);
                } else if (m.controlNumber == Steinberg::Vst::kSystemTuneRequest) {
                    out.status = 0xF6U;
                } else if (m.controlNumber == Steinberg::Vst::kSystemMidiClockStart) {
                    out.status = 0xFAU;
                } else if (m.controlNumber == Steinberg::Vst::kSystemMidiClockContinue) {
                    out.status = 0xFBU;
                } else if (m.controlNumber == Steinberg::Vst::kSystemMidiClockStop) {
                    out.status = 0xFCU;
                } else if (m.controlNumber == Steinberg::Vst::kSystemActiveSensing) {
                    out.status = 0xFEU;
                } else {
                    continue;
                }
            } else {
                continue;
            }
            (void)midiOutputQueue_.push(out);
        }
    }

    static bool writeStream(Steinberg::ResizableMemoryIBStream& stream, const std::vector<std::uint8_t>& state) {
        if (state.empty()) return true;
        if (state.size() > static_cast<std::size_t>(std::numeric_limits<Steinberg::int32>::max())) return false;
        Steinberg::int32 written = 0;
        return stream.write(const_cast<std::uint8_t*>(state.data()), static_cast<Steinberg::int32>(state.size()), &written) == Steinberg::kResultTrue &&
               written == static_cast<Steinberg::int32>(state.size());
    }

    VST3::Hosting::Module::Ptr module_;
    VST3::Hosting::ClassInfo classInfo_;
    std::string modulePath_;
    std::string classId_;
    Vst3InstanceInfo info_;
    Steinberg::IPtr<Steinberg::Vst::PlugProvider> provider_;
    Steinberg::IPtr<IComponent> component_;
    Steinberg::IPtr<IEditController> controller_;
    Steinberg::FUnknownPtr<IAudioProcessor> processor_;
    Steinberg::FUnknownPtr<IMidiMapping> midiMapping_;
    std::array<std::array<MidiMapEntry, kMidiControllerMapSize>, 16U> midiControllerMap_ {};
    Steinberg::IPtr<HostComponentHandler> handler_;
    std::vector<BusInfo> audioInputBuses_;
    std::vector<BusInfo> audioOutputBuses_;
    std::vector<BusInfo> eventInputBuses_;
    std::vector<BusInfo> eventOutputBuses_;
    std::array<bool, kMaxAudioBuses> audioInputOverrideKnown_ {};
    std::array<bool, kMaxAudioBuses> audioOutputOverrideKnown_ {};
    std::array<bool, kMaxAudioBuses> eventInputOverrideKnown_ {};
    std::array<bool, kMaxAudioBuses> eventOutputOverrideKnown_ {};
    std::array<bool, kMaxAudioBuses> audioInputActive_ {};
    std::array<bool, kMaxAudioBuses> audioOutputActive_ {};
    std::array<bool, kMaxAudioBuses> eventInputActive_ {};
    std::array<bool, kMaxAudioBuses> eventOutputActive_ {};
    int eventInputBusCount_ {0};
    Steinberg::Vst::HostProcessData processData_;
    FixedParameterChanges inputParamChanges_;
    FixedParameterChanges outputParamChanges_;
    Steinberg::Vst::EventList inputEvents_ {kMaxVstEventsPerBlock};
    Steinberg::Vst::EventList outputEvents_ {kMaxVstEventsPerBlock};
    Steinberg::Vst::ProcessContext processContext_ {};
    std::vector<AudioBusScratch> inputScratch_;
    std::vector<AudioBusScratch> outputDiscard_;
    FixedSpscQueue<Vst3MidiEvent, kMidiQueueCapacity> midiInputQueue_;
    FixedSpscQueue<Vst3MidiEvent, kMidiQueueCapacity> midiOutputQueue_;
    FixedSpscQueue<QueuedParameter, kParameterInputQueueCapacity> parameterInputQueue_;
    FixedSpscQueue<Vst3OutputParameterChange, kOutputParamQueueCapacity> outputParameterQueue_;
    double sampleRate_ {0.0};
    std::uint32_t maxFrames_ {0U};
    bool valid_ {false};
    bool prepared_ {false};
    bool active_ {false};
    bool processing_ {false};
#if defined(__APPLE__)
    detail::Vst3EditorHandle* editorHandle_ {nullptr};
#endif
};

Vst3PluginDescriptor descriptorFromClassInfo(const std::string& modulePath,
                                             const VST3::Hosting::ClassInfo& ci) {
    Vst3PluginDescriptor d;
    d.modulePath = modulePath;
    d.classId = ci.ID().toString();
    d.name = ci.name();
    d.vendor = ci.vendor();
    d.version = ci.version();
    d.sdkVersion = ci.sdkVersion();
    d.subCategories = ci.subCategories();
    return d;
}

} // namespace

std::vector<Vst3PluginDescriptor> scanVst3ModuleDirect(const std::string& modulePath,
                                                       std::string& failureReason) {
    failureReason.clear();
    std::string error;
    auto module = VST3::Hosting::Module::create(modulePath, error);
    if (!module) {
        failureReason = error.empty() ? "VST3 module load failed" : error;
        return {};
    }
    std::vector<Vst3PluginDescriptor> out;
    for (const auto& ci : module->getFactory().classInfos()) {
        if (ci.category() != kVstAudioEffectClass) continue;
        out.push_back(descriptorFromClassInfo(modulePath, ci));
    }
    return out;
}

class Vst3Host::Impl {
public:
    Impl() { (void)sharedHostApplication(); }
};

Vst3Host::Vst3Host() : impl_(std::make_unique<Impl>()) {}
Vst3Host::~Vst3Host() = default;

std::vector<Vst3PluginDescriptor> Vst3Host::scanModule(const std::string& modulePath,
                                                       std::string& failureReason) const {
    return scanVst3ModuleDirect(modulePath, failureReason);
}

std::vector<std::string> Vst3Host::installedModulePaths() const {
    return VST3::Hosting::Module::getModulePaths();
}

std::unique_ptr<IVst3PluginInstance> Vst3Host::create(const std::string& modulePath,
                                                      const std::string& classId,
                                                      std::string& failureReason) {
    failureReason.clear();
    std::string error;
    auto module = VST3::Hosting::Module::create(modulePath, error);
    if (!module) {
        failureReason = error.empty() ? "VST3 module load failed" : error;
        return nullptr;
    }
    const auto classes = module->getFactory().classInfos();
    const auto it = std::find_if(classes.begin(), classes.end(), [&](const auto& ci) {
        return ci.category() == kVstAudioEffectClass && ci.ID().toString() == classId;
    });
    if (it == classes.end()) {
        failureReason = "VST3 class not found in module";
        return nullptr;
    }
    auto instance = std::make_unique<Vst3PluginInstance>(module, *it, modulePath, classId, failureReason);
    if (!instance->valid()) return nullptr;
    return instance;
}

} // namespace silveton
