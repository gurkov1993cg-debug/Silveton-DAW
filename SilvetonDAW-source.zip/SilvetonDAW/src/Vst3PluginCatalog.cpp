#include "silveton/Vst3PluginCatalog.h"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <unordered_set>

namespace silveton {
namespace {
std::string lower(std::string s) { for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c))); return s; }
std::string joinCategories(const std::vector<std::string>& v) { std::string out; for(std::size_t i=0;i<v.size();++i){ if(i) out += '\n'; out += v[i]; } return out; }
std::vector<std::string> splitCategories(const std::string& s) { std::vector<std::string> out; std::size_t a=0; while(a<=s.size()){ auto b=s.find('\n',a); if(b==std::string::npos)b=s.size(); if(b>a)out.push_back(s.substr(a,b-a)); if(b==s.size())break; a=b+1;} return out; }
std::vector<std::string> tabs(const std::string& line) { std::vector<std::string> out; std::size_t a=0; bool esc=false; for(std::size_t i=0;i<line.size();++i){ if(esc){esc=false;continue;} if(line[i]=='\\'){esc=true;continue;} if(line[i]=='\t'){out.push_back(line.substr(a,i-a));a=i+1;} } out.push_back(line.substr(a)); return out; }
}

void Vst3PluginCatalog::replaceModule(const std::string& modulePath, const std::vector<Vst3ScanRecord>& records) {
    if (modulePath.empty()) throw std::invalid_argument("catalog module path empty");
    std::vector<Vst3CatalogEntry> replacements;
    std::unordered_set<std::string> ids;
    for (const auto& r : records) {
        if (r.modulePath != modulePath || r.classId.empty()) throw std::invalid_argument("invalid scanner record");
        if (!ids.insert(r.classId).second) throw std::invalid_argument("duplicate scanner class id");
        replacements.push_back({r.modulePath,r.classId,r.name,r.vendor,r.version,r.sdkVersion,r.subCategories});
    }
    auto next = entries_;
    next.erase(std::remove_if(next.begin(), next.end(), [&](const auto& e){ return e.modulePath == modulePath; }), next.end());
    next.insert(next.end(), replacements.begin(), replacements.end());
    std::sort(next.begin(), next.end(), [](const auto& a,const auto& b){ if(a.vendor!=b.vendor)return a.vendor<b.vendor; if(a.name!=b.name)return a.name<b.name; return a.classId<b.classId; });
    entries_.swap(next);
}

std::vector<Vst3CatalogEntry> Vst3PluginCatalog::search(const std::string& text, const Vst3Blacklist* blacklist) const {
    const std::string q = lower(text); std::vector<Vst3CatalogEntry> out;
    for (const auto& e : entries_) {
        if (blacklist && blacklist->contains(e.modulePath,e.classId)) continue;
        std::string hay = e.name + "\n" + e.vendor + "\n" + e.modulePath + "\n" + e.version;
        for (const auto& c : e.subCategories) hay += "\n" + c;
        if (q.empty() || lower(hay).find(q) != std::string::npos) out.push_back(e);
    }
    return out;
}

void Vst3PluginCatalog::save(const std::string& path) const {
    const std::string tmp=path+".tmp"; std::ofstream out(tmp.c_str(),std::ios::binary|std::ios::trunc); if(!out)throw std::runtime_error("cannot write plugin cache");
    out << "SILVETON_VST3_CATALOG_V1\n";
    for(const auto& e:entries_) out << encodeVst3ScanField(e.modulePath)<<'\t'<<encodeVst3ScanField(e.classId)<<'\t'<<encodeVst3ScanField(e.name)<<'\t'<<encodeVst3ScanField(e.vendor)<<'\t'<<encodeVst3ScanField(e.version)<<'\t'<<encodeVst3ScanField(e.sdkVersion)<<'\t'<<encodeVst3ScanField(joinCategories(e.subCategories))<<'\n';
    out.flush(); if(!out)throw std::runtime_error("plugin cache write failed"); out.close(); (void)std::remove(path.c_str()); if(std::rename(tmp.c_str(),path.c_str())!=0){(void)std::remove(tmp.c_str());throw std::runtime_error("cannot replace plugin cache");}
}

void Vst3PluginCatalog::load(const std::string& path) {
    std::ifstream in(path.c_str(),std::ios::binary); if(!in)return; std::string line; if(!std::getline(in,line)||line!="SILVETON_VST3_CATALOG_V1")throw std::runtime_error("invalid plugin cache");
    std::vector<Vst3CatalogEntry> next; std::unordered_set<std::string> keys;
    while(std::getline(in,line)){ if(line.empty())continue; auto f=tabs(line); if(f.size()!=7U)throw std::runtime_error("invalid plugin cache row"); Vst3CatalogEntry e; std::string cats; if(!decodeVst3ScanField(f[0],e.modulePath)||!decodeVst3ScanField(f[1],e.classId)||!decodeVst3ScanField(f[2],e.name)||!decodeVst3ScanField(f[3],e.vendor)||!decodeVst3ScanField(f[4],e.version)||!decodeVst3ScanField(f[5],e.sdkVersion)||!decodeVst3ScanField(f[6],cats)||e.modulePath.empty()||e.classId.empty())throw std::runtime_error("invalid plugin cache field"); e.subCategories=splitCategories(cats); const std::string key=e.modulePath+"\n"+e.classId; if(!keys.insert(key).second)throw std::runtime_error("duplicate plugin cache entry"); next.push_back(std::move(e)); }
    entries_.swap(next);
}

Vst3PluginBrowserService::Vst3PluginBrowserService(std::string scanner, std::string cache, std::string quarantine, std::uint32_t timeout)
    :scannerExecutable_(std::move(scanner)),cachePath_(std::move(cache)),quarantinePath_(std::move(quarantine)),timeoutMs_(timeout){ if(scannerExecutable_.empty()||cachePath_.empty()||quarantinePath_.empty()||timeoutMs_==0U)throw std::invalid_argument("invalid plugin browser configuration"); }
void Vst3PluginBrowserService::load(){ catalog_.load(cachePath_); quarantine_.load(quarantinePath_); }
void Vst3PluginBrowserService::save() const { catalog_.save(cachePath_); quarantine_.save(quarantinePath_); }
Vst3IsolatedScanResult Vst3PluginBrowserService::scanModule(const std::string& modulePath){ auto r=scanVst3ModuleIsolated(scannerExecutable_,modulePath,timeoutMs_,quarantine_); if(!r.crashedOrFailed&&!r.skippedBlacklisted){catalog_.replaceModule(modulePath,r.plugins);} return r; }
Vst3BatchScanSummary Vst3PluginBrowserService::scanModules(const std::vector<std::string>& modulePaths, bool persistAfterScan) {
    Vst3BatchScanSummary summary;
    std::unordered_set<std::string> seen;
    for (const auto& module : modulePaths) {
        if (module.empty() || !seen.insert(module).second) continue;
        ++summary.requestedModules;
        const auto result = scanModule(module);
        if (result.skippedBlacklisted) {
            ++summary.skippedQuarantined;
            continue;
        }
        if (result.crashedOrFailed || result.timedOut) {
            ++summary.failedModules;
            continue;
        }
        ++summary.scannedModules;
        summary.discoveredClasses += result.plugins.size();
    }
    if (persistAfterScan) save();
    return summary;
}
void Vst3PluginBrowserService::quarantineClass(const std::string& m,const std::string& c,const std::string& reason){quarantine_.add(m,c,reason);}
bool Vst3PluginBrowserService::removeFromQuarantine(const std::string& m,const std::string& c){return quarantine_.remove(m,c);}
std::vector<Vst3CatalogEntry> Vst3PluginBrowserService::search(const std::string& text) const {return catalog_.search(text,&quarantine_);}

} // namespace silveton
