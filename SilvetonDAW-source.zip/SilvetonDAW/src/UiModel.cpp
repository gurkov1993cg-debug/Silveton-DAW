#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <functional>
#include <sstream>

namespace silveton {

int instrumentTrackForPort(const Project& project, int port) noexcept {
    if (port < 0) return -1;
    for (std::size_t i = 0U; i < project.tracks.size(); ++i)
        for (const auto& slot : project.tracks[i].pluginSlots)
            if (slot.midiInputPort == port) return static_cast<int>(i);
    return -1;
}

int nextFreeMidiPort(const Project& project) noexcept {
    int next = 0;
    auto scan = [&](const std::vector<ProjectPluginSlot>& slots) {
        for (const auto& s : slots) if (s.midiInputPort >= next) next = s.midiInputPort + 1;
    };
    for (const auto& t : project.tracks) scan(t.pluginSlots);
    for (const auto& b : project.buses) scan(b.pluginSlots);
    scan(project.masterPluginSlots);
    for (const auto& m : project.midiTracks) if (m.outputPort >= next) next = m.outputPort + 1;
    return next;
}

std::vector<ArrangeRow> buildArrangeRows(const Project& p) {
    std::vector<ArrangeRow> rows;
    std::vector<std::vector<std::size_t>> midiFor(p.tracks.size());
    std::vector<char> midiDone(p.midiTracks.size(), 0);
    std::vector<char> audioDone(p.tracks.size(), 0);
    for (std::size_t m = 0U; m < p.midiTracks.size(); ++m) {
        const int inst = instrumentTrackForPort(p, p.midiTracks[m].outputPort);
        if (inst >= 0) midiFor[static_cast<std::size_t>(inst)].push_back(m);
    }
    auto folderIndex = [&](int id) -> int {
        for (std::size_t i = 0U; i < p.folders.size(); ++i) if (p.folders[i].id == id) return static_cast<int>(i);
        return -1;
    };
    auto emitAudio = [&](std::size_t i, int depth, bool visible) {
        if (audioDone[i]) return;
        audioDone[i] = 1;
        if (visible) rows.push_back({ArrangeRowKind::Audio, i, depth, false});
        for (auto m : midiFor[i]) {
            if (midiDone[m]) continue;
            midiDone[m] = 1;
            if (visible) rows.push_back({ArrangeRowKind::Midi, m, depth, true});
        }
    };
    std::vector<char> folderDone(p.folders.size(), 0);
    std::function<void(std::size_t, int, bool)> emitFolder = [&](std::size_t fi, int depth, bool visible) {
        if (folderDone[fi]) return;
        folderDone[fi] = 1;
        const auto& f = p.folders[fi];
        if (visible) rows.push_back({ArrangeRowKind::Folder, fi, depth, false});
        const bool childVisible = visible && !f.collapsed;
        for (std::size_t c = 0U; c < p.folders.size(); ++c)
            if (p.folders[c].parent == f.id && c != fi) emitFolder(c, depth + 1, childVisible);
        for (std::size_t t = 0U; t < p.tracks.size(); ++t)
            if (p.tracks[t].folder == f.id) emitAudio(t, depth + 1, childVisible);
        for (std::size_t m = 0U; m < p.midiTracks.size(); ++m)
            if (p.midiTracks[m].folder == f.id && !midiDone[m]) {
                midiDone[m] = 1;
                if (childVisible) rows.push_back({ArrangeRowKind::Midi, m, depth + 1, false});
            }
    };
    for (std::size_t fi = 0U; fi < p.folders.size(); ++fi)
        if (folderIndex(p.folders[fi].parent) < 0) emitFolder(fi, 0, true);
    // Folders whose parent chain loops are still shown at top level.
    for (std::size_t fi = 0U; fi < p.folders.size(); ++fi) if (!folderDone[fi]) emitFolder(fi, 0, true);
    for (std::size_t t = 0U; t < p.tracks.size(); ++t) emitAudio(t, 0, true);
    for (std::size_t m = 0U; m < p.midiTracks.size(); ++m)
        if (!midiDone[m]) { midiDone[m] = 1; rows.push_back({ArrangeRowKind::Midi, m, 0, false}); }
    return rows;
}

double TimelineMapping::xForSample(std::int64_t sample) const noexcept {
    const double sr = sampleRate > 0.0 ? sampleRate : 48000.0;
    return originX + (static_cast<double>(sample) / sr - scrollSeconds) * pixelsPerSecond;
}

std::int64_t TimelineMapping::sampleForX(double x) const noexcept {
    const double sr = sampleRate > 0.0 ? sampleRate : 48000.0;
    const double pps = pixelsPerSecond > 0.0 ? pixelsPerSecond : 1.0;
    return static_cast<std::int64_t>(std::llround(((x - originX) / pps + scrollSeconds) * sr));
}

std::vector<GridLine> buildGrid(const TempoMap& tempo, const TimelineMapping& map, double width, double minPixels) {
    std::vector<GridLine> out;
    if (width <= 0.0 || map.pixelsPerSecond <= 0.0) return out;
    const std::int64_t startSample = std::max<std::int64_t>(0, map.sampleForX(map.originX));
    const std::int64_t endSample = std::max<std::int64_t>(startSample + 1, map.sampleForX(map.originX + width));
    const double endQ = tempo.quarterNotesAtSample(endSample);
    const auto first = tempo.positionAtSample(startSample);
    double barQ = first.barStartQuarterNotes;
    std::int64_t bar = first.bar;
    const double pxPerQ = map.pixelsPerSecond * 60.0 / std::max(1.0, tempo.tempoAtSample(startSample));
    const double barPx = pxPerQ * first.numerator * 4.0 / first.denominator;
    std::int64_t labelEvery = 1;
    while (barPx * static_cast<double>(labelEvery) < 34.0 && labelEvery < 4096) labelEvery *= 2;
    for (int guard = 0; barQ <= endQ && guard < 200000; ++guard) {
        const std::int64_t s = tempo.sampleAtQuarterNotes(barQ);
        const auto num = tempo.numeratorAtSample(s);
        const auto den = tempo.denominatorAtSample(s);
        const double barLen = num * 4.0 / den;
        const double beatLen = 4.0 / den;
        const double localPxQ = map.pixelsPerSecond * 60.0 / std::max(1.0, tempo.tempoAtSample(s));
        const bool labelled = ((bar - 1) % labelEvery) == 0;
        if (labelled || barPx >= minPixels) out.push_back({s, 0, labelled ? std::to_string(bar) : std::string()});
        if (beatLen * localPxQ >= minPixels) {
            const double sub = 0.25;
            const bool sixteenths = sub * localPxQ >= minPixels;
            const double step = sixteenths ? sub : beatLen;
            for (double q = step; q < barLen - 1.0e-9; q += step) {
                const double beatPos = q / beatLen;
                const bool onBeat = std::abs(beatPos - std::round(beatPos)) < 1.0e-9;
                out.push_back({tempo.sampleAtQuarterNotes(barQ + q), onBeat ? 1 : 2, std::string()});
            }
        }
        barQ += barLen;
        ++bar;
    }
    return out;
}

std::string formatBarsBeats(const TempoMap& tempo, std::int64_t sample) {
    const auto pos = tempo.positionAtSample(std::max<std::int64_t>(0, sample));
    const double ticksPerBeat = 960.0 * 4.0 / pos.denominator;
    long tick = std::lround(pos.beatFraction * ticksPerBeat);
    std::int64_t bar = pos.bar;
    long beat = pos.beat;
    if (tick >= static_cast<long>(ticksPerBeat)) { tick = 0; ++beat; }
    if (beat > pos.numerator) { beat = 1; ++bar; }
    return std::to_string(bar) + "." + std::to_string(beat) + "." + std::to_string(tick);
}

std::string formatClock(double seconds) {
    if (!std::isfinite(seconds) || seconds < 0.0) seconds = 0.0;
    const auto totalMs = static_cast<long long>(std::llround(seconds * 1000.0));
    const long long h = totalMs / 3600000LL, m = (totalMs / 60000LL) % 60LL, s = (totalMs / 1000LL) % 60LL, ms = totalMs % 1000LL;
    char buf[48];
    if (h > 0) std::snprintf(buf, sizeof buf, "%lld:%02lld:%02lld.%03lld", h, m, s, ms);
    else std::snprintf(buf, sizeof buf, "%02lld:%02lld.%03lld", m, s, ms);
    return buf;
}

bool parseBarsBeats(const TempoMap& tempo, const std::string& text, std::int64_t& sample) {
    long long parts[3] = {1, 1, 0};
    int count = 0;
    std::string cur;
    auto flush = [&]() -> bool {
        if (cur.empty() || count >= 3) return false;
        for (char c : cur) if (c < '0' || c > '9') return false;
        parts[count++] = std::stoll(cur);
        cur.clear();
        return true;
    };
    for (char c : text) {
        if (c == ' ') continue;
        if (c == '.' || c == ':' || c == '|') { if (!flush()) return false; }
        else cur += c;
    }
    if (!flush()) return false;
    if (parts[0] < 1 || parts[1] < 1 || parts[2] < 0 || parts[0] > 100000) return false;
    double q = 0.0;
    for (long long b = 1; b < parts[0]; ++b) {
        const std::int64_t s = tempo.sampleAtQuarterNotes(q);
        q += tempo.numeratorAtSample(s) * 4.0 / tempo.denominatorAtSample(s);
    }
    const std::int64_t barSample = tempo.sampleAtQuarterNotes(q);
    const auto num = tempo.numeratorAtSample(barSample);
    const auto den = tempo.denominatorAtSample(barSample);
    if (parts[1] > num || parts[2] >= static_cast<long long>(960.0 * 4.0 / den)) return false;
    q += static_cast<double>(parts[1] - 1) * 4.0 / den + static_cast<double>(parts[2]) / 960.0;
    sample = tempo.sampleAtQuarterNotes(q);
    return true;
}

double faderPositionForDb(double db) noexcept {
    if (!std::isfinite(db) || db <= -96.0) return 0.0;
    db = std::min(db, 12.0);
    if (db >= 0.0) return 0.75 + db / 12.0 * 0.25;
    if (db >= -30.0) return 0.25 + (db + 30.0) / 30.0 * 0.5;
    return std::max(0.0, (db + 96.0) / 66.0 * 0.25);
}

double dbForFaderPosition(double p) noexcept {
    if (!std::isfinite(p) || p <= 0.0) return -96.0;
    p = std::min(p, 1.0);
    if (p >= 0.75) return (p - 0.75) / 0.25 * 12.0;
    if (p >= 0.25) return -30.0 + (p - 0.25) / 0.5 * 30.0;
    return -96.0 + p / 0.25 * 66.0;
}

} // namespace silveton
