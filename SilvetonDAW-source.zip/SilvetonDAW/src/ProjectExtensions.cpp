#include "internal/ProjectExtensionsIO.h"

#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace silveton {

std::string escapeProjectText(const std::string& text) {
    std::string out;
    out.reserve(text.size());
    static const char* hex = "0123456789ABCDEF";
    for (const unsigned char c : text) {
        if (c == '%' || c == '\t' || c == '\n' || c == '\r' || c < 32U) {
            out += '%';
            out += hex[c >> 4U];
            out += hex[c & 15U];
        } else {
            out += static_cast<char>(c);
        }
    }
    return out;
}

std::string unescapeProjectText(const std::string& text) {
    std::string out;
    out.reserve(text.size());
    auto nibble = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        return -1;
    };
    for (std::size_t i = 0U; i < text.size(); ++i) {
        if (text[i] == '%' && i + 2U < text.size() + 0U && nibble(text[i + 1U]) >= 0 && nibble(text[i + 2U]) >= 0) {
            out += static_cast<char>(nibble(text[i + 1U]) * 16 + nibble(text[i + 2U]));
            i += 2U;
        } else {
            out += text[i];
        }
    }
    return out;
}

namespace {

std::vector<std::string> splitTabs(const std::string& line) {
    std::vector<std::string> fields;
    std::string cur;
    for (const char c : line) {
        if (c == '\t') { fields.push_back(cur); cur.clear(); }
        else cur += c;
    }
    fields.push_back(cur);
    return fields;
}

long long toInt(const std::string& s) {
    std::size_t used = 0U;
    const long long v = std::stoll(s, &used);
    if (used != s.size()) throw std::runtime_error("project extension: invalid integer");
    return v;
}
unsigned long long toUInt(const std::string& s) {
    if (!s.empty() && s[0] == '-') throw std::runtime_error("project extension: negative value");
    std::size_t used = 0U;
    const unsigned long long v = std::stoull(s, &used);
    if (used != s.size()) throw std::runtime_error("project extension: invalid integer");
    return v;
}
bool toBool(const std::string& s) { return toInt(s) != 0; }

void need(const std::vector<std::string>& f, std::size_t n) {
    if (f.size() < n) throw std::runtime_error("project extension: truncated " + (f.empty() ? std::string() : f[0]));
}

} // namespace

void writeProjectExtensions(std::ostream& f, const Project& p) {
    f << "EXT_BEGIN\n";
    f << "NOTES\t" << escapeProjectText(p.notes) << '\n';
    for (std::size_t i = 0U; i < p.tracks.size(); ++i) {
        const auto& t = p.tracks[i];
        f << "TRACKMETA\t" << i << '\t' << t.color << '\t' << t.solo << '\t' << t.soloDefeat << '\t' << t.recordArm
          << '\t' << t.monitor << '\t' << t.locked << '\t' << t.folder << '\t' << escapeProjectText(t.notes) << '\n';
    }
    for (std::size_t i = 0U; i < p.midiTracks.size(); ++i) {
        const auto& t = p.midiTracks[i];
        f << "MIDIMETA\t" << i << '\t' << t.color << '\t' << t.mute << '\t' << t.solo << '\t' << t.folder
          << '\t' << t.transpose << '\t' << t.velocityShift << '\n';
    }
    for (std::size_t i = 0U; i < p.buses.size(); ++i)
        f << "BUSMETA\t" << i << '\t' << p.buses[i].color << '\t' << p.buses[i].solo << '\n';
    for (const auto& folder : p.folders)
        f << "FOLDER\t" << folder.id << '\t' << folder.parent << '\t' << folder.collapsed << '\t' << folder.color
          << '\t' << escapeProjectText(folder.name) << '\n';
    for (const auto& m : p.markers)
        f << "MARKER\t" << m.id << '\t' << m.sample << '\t' << m.cycle << '\t' << m.endSample << '\t' << m.color
          << '\t' << escapeProjectText(m.name) << '\n';
    for (const auto& s : p.arrangerSections)
        f << "SECTION\t" << s.id << '\t' << s.startSample << '\t' << s.endSample << '\t' << s.color
          << '\t' << escapeProjectText(s.name) << '\n';
    for (const auto& c : p.arrangerChain) f << "CHAIN\t" << c.sectionId << '\t' << c.repeats << '\n';
    f << "EXT_END\n";
}

void readProjectExtensions(std::istream& in, Project& p) {
    std::string line;
    while (std::getline(in, line)) {
        if (line == "EXT_END") return;
        if (line.empty()) continue;
        const auto f = splitTabs(line);
        const std::string& tag = f[0];
        if (tag == "NOTES") {
            need(f, 2U);
            p.notes = unescapeProjectText(f[1]);
        } else if (tag == "TRACKMETA") {
            need(f, 10U);
            const auto i = static_cast<std::size_t>(toUInt(f[1]));
            if (i >= p.tracks.size()) throw std::runtime_error("project extension: track index");
            auto& t = p.tracks[i];
            t.color = static_cast<std::uint32_t>(toUInt(f[2]) & 0xFFFFFFU);
            t.solo = toBool(f[3]); t.soloDefeat = toBool(f[4]); t.recordArm = toBool(f[5]);
            t.monitor = toBool(f[6]); t.locked = toBool(f[7]); t.folder = static_cast<int>(toInt(f[8]));
            t.notes = unescapeProjectText(f[9]);
        } else if (tag == "MIDIMETA") {
            need(f, 8U);
            const auto i = static_cast<std::size_t>(toUInt(f[1]));
            if (i >= p.midiTracks.size()) throw std::runtime_error("project extension: MIDI track index");
            auto& t = p.midiTracks[i];
            t.color = static_cast<std::uint32_t>(toUInt(f[2]) & 0xFFFFFFU);
            t.mute = toBool(f[3]); t.solo = toBool(f[4]); t.folder = static_cast<int>(toInt(f[5]));
            t.transpose = static_cast<int>(toInt(f[6]));
            t.velocityShift = static_cast<int>(toInt(f[7]));
            if (t.transpose < -48 || t.transpose > 48 || t.velocityShift < -127 || t.velocityShift > 127)
                throw std::runtime_error("project extension: MIDI modifier out of range");
        } else if (tag == "BUSMETA") {
            need(f, 4U);
            const auto i = static_cast<std::size_t>(toUInt(f[1]));
            if (i >= p.buses.size()) throw std::runtime_error("project extension: bus index");
            p.buses[i].color = static_cast<std::uint32_t>(toUInt(f[2]) & 0xFFFFFFU);
            p.buses[i].solo = toBool(f[3]);
        } else if (tag == "FOLDER") {
            need(f, 6U);
            ProjectFolder folder;
            folder.id = static_cast<int>(toInt(f[1])); folder.parent = static_cast<int>(toInt(f[2]));
            folder.collapsed = toBool(f[3]); folder.color = static_cast<std::uint32_t>(toUInt(f[4]) & 0xFFFFFFU);
            folder.name = unescapeProjectText(f[5]);
            p.folders.push_back(std::move(folder));
        } else if (tag == "MARKER") {
            need(f, 7U);
            ProjectMarker m;
            m.id = toUInt(f[1]); m.sample = toInt(f[2]); m.cycle = toBool(f[3]); m.endSample = toInt(f[4]);
            m.color = static_cast<std::uint32_t>(toUInt(f[5]) & 0xFFFFFFU); m.name = unescapeProjectText(f[6]);
            if (m.sample < 0 || (m.cycle && m.endSample <= m.sample)) throw std::runtime_error("project extension: marker range");
            p.markers.push_back(std::move(m));
        } else if (tag == "SECTION") {
            need(f, 6U);
            ArrangerSection s;
            s.id = toUInt(f[1]); s.startSample = toInt(f[2]); s.endSample = toInt(f[3]);
            s.color = static_cast<std::uint32_t>(toUInt(f[4]) & 0xFFFFFFU); s.name = unescapeProjectText(f[5]);
            if (s.startSample < 0 || s.endSample <= s.startSample) throw std::runtime_error("project extension: section range");
            p.arrangerSections.push_back(std::move(s));
        } else if (tag == "CHAIN") {
            need(f, 3U);
            ArrangerChainStep c;
            c.sectionId = toUInt(f[1]);
            c.repeats = static_cast<std::uint32_t>(toUInt(f[2]));
            if (c.repeats == 0U || c.repeats > 999U) throw std::runtime_error("project extension: chain repeats");
            p.arrangerChain.push_back(c);
        }
        // Unknown tags are ignored for forward compatibility.
    }
    throw std::runtime_error("project extension block missing EXT_END");
}

} // namespace silveton
