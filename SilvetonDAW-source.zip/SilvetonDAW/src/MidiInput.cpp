#include "silveton/MidiInput.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace silveton {
namespace {
struct ActiveNote {
    bool active {false};
    std::int64_t startSample {0};
    std::uint8_t velocity {0U};
};

bool isNoteOn(const TimedMidiInputEvent& e) noexcept {
    return (e.status & 0xF0U) == 0x90U && e.data2 != 0U;
}
bool isNoteOff(const TimedMidiInputEvent& e) noexcept {
    const auto type = e.status & 0xF0U;
    return type == 0x80U || (type == 0x90U && e.data2 == 0U);
}
}

bool MidiInputCapture::validEvent(const TimedMidiInputEvent& event) noexcept {
    if (event.port < 0 || event.sample < 0 || event.data1 > 127U || event.data2 > 127U) return false;
    const std::uint8_t type = static_cast<std::uint8_t>(event.status & 0xF0U);
    return type >= 0x80U && type <= 0xE0U;
}

bool MidiInputCapture::push(Ring& ring, const TimedMidiInputEvent& event) noexcept {
    const std::size_t write = ring.write.load(std::memory_order_relaxed);
    const std::size_t next = (write + 1U) % kCapacity;
    if (next == ring.read.load(std::memory_order_acquire)) return false;
    ring.events[write] = event;
    ring.write.store(next, std::memory_order_release);
    return true;
}

bool MidiInputCapture::peek(const Ring& ring, TimedMidiInputEvent& event) noexcept {
    const std::size_t read = ring.read.load(std::memory_order_relaxed);
    if (read == ring.write.load(std::memory_order_acquire)) return false;
    event = ring.events[read];
    return true;
}

bool MidiInputCapture::pop(Ring& ring, TimedMidiInputEvent& event) noexcept {
    const std::size_t read = ring.read.load(std::memory_order_relaxed);
    if (read == ring.write.load(std::memory_order_acquire)) return false;
    event = ring.events[read];
    ring.read.store((read + 1U) % kCapacity, std::memory_order_release);
    return true;
}

void MidiInputCapture::clear(Ring& ring) noexcept {
    const std::size_t write = ring.write.load(std::memory_order_acquire);
    ring.read.store(write, std::memory_order_release);
}

bool MidiInputCapture::pushRealtime(const TimedMidiInputEvent& event) noexcept {
    if (!validEvent(event)) return false;
    const bool thruOk = push(thru_, event);
    if (!thruOk) thruOverflow_.store(true, std::memory_order_release);
    bool recordOk = true;
    if (recording_.load(std::memory_order_acquire)) {
        recordOk = push(record_, event);
        if (!recordOk) recordOverflow_.store(true, std::memory_order_release);
    }
    return thruOk && recordOk;
}

std::size_t MidiInputCapture::eventsForBlock(std::int64_t blockStartSample,
                                             std::uint32_t frames,
                                             TimedMidiInputEvent* output,
                                             std::size_t capacity) noexcept {
    if (output == nullptr || capacity == 0U || frames == 0U || blockStartSample < 0) return 0U;
    const std::int64_t blockEnd = blockStartSample + static_cast<std::int64_t>(frames);
    std::size_t count = 0U;
    while (count < capacity) {
        TimedMidiInputEvent event;
        if (!peek(thru_, event)) break;
        if (event.sample >= blockEnd) break;
        (void)pop(thru_, event);
        if (event.sample < blockStartSample) event.sample = blockStartSample;
        output[count++] = event;
    }
    return count;
}

void MidiInputCapture::beginRecording() noexcept {
    recording_.store(false, std::memory_order_release);
    clear(record_);
    recordOverflow_.store(false, std::memory_order_release);
    recording_.store(true, std::memory_order_release);
}

std::size_t MidiInputCapture::stopAndCommit(MidiSequence& destination,
                                            const TempoMap& tempoMap,
                                            std::int64_t stopSample) {
    if (stopSample < 0) throw std::invalid_argument("MIDI record stop sample must be non-negative");
    recording_.store(false, std::memory_order_release);
    if (recordOverflow_.load(std::memory_order_acquire))
        throw std::runtime_error("MIDI recording input buffer overflow");

    std::array<std::array<ActiveNote, 128U>, 16U> active {};
    std::size_t committed = 0U;
    auto commit = [&](std::uint8_t channel,
                            std::uint8_t pitch,
                            const ActiveNote& note,
                            std::int64_t endSample,
                            std::uint8_t releaseVelocity) {
        if (!note.active) return;
        const std::int64_t safeEnd = std::max<std::int64_t>(endSample, note.startSample + 1);
        const double startQ = tempoMap.quarterNotesAtSample(note.startSample);
        const double endQ = tempoMap.quarterNotesAtSample(safeEnd);
        const double durationQ = endQ - startQ;
        if (!(durationQ > 0.0) || !std::isfinite(durationQ)) return;
        MusicalMidiNote out;
        out.startQuarterNotes = startQ;
        out.durationQuarterNotes = durationQ;
        out.channel = channel;
        out.pitch = pitch;
        out.velocity = note.velocity;
        out.releaseVelocity = releaseVelocity;
        (void)destination.addNote(out);
        ++committed;
    };

    TimedMidiInputEvent event;
    while (pop(record_, event)) {
        if (event.sample > stopSample) continue;
        const std::uint8_t channel = static_cast<std::uint8_t>(event.status & 0x0FU);
        const std::uint8_t pitch = event.data1;
        if (isNoteOn(event)) {
            auto& slot = active[channel][pitch];
            if (slot.active) commit(channel, pitch, slot, event.sample, 64U);
            slot = {true, event.sample, event.data2};
        } else if (isNoteOff(event)) {
            auto& slot = active[channel][pitch];
            if (slot.active) {
                commit(channel, pitch, slot, event.sample, event.data2);
                slot.active = false;
            }
        } else {
            MusicalMidiMessage message;
            message.quarterNotes = tempoMap.quarterNotesAtSample(event.sample);
            message.status = event.status;
            message.data1 = event.data1;
            message.data2 = event.data2;
            (void)destination.addMessage(message);
            ++committed;
        }
    }

    for (std::size_t channel = 0U; channel < active.size(); ++channel) {
        for (std::size_t pitch = 0U; pitch < active[channel].size(); ++pitch) {
            auto& slot = active[channel][pitch];
            if (slot.active) {
                commit(static_cast<std::uint8_t>(channel), static_cast<std::uint8_t>(pitch),
                       slot, stopSample, 64U);
                slot.active = false;
            }
        }
    }
    return committed;
}

void MidiInputCapture::clearOverflowFlags() noexcept {
    thruOverflow_.store(false, std::memory_order_release);
    recordOverflow_.store(false, std::memory_order_release);
}

} // namespace silveton
