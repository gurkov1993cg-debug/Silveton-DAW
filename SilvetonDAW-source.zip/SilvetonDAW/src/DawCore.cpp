#include "silveton/DawCore.h"
#include <queue>
#include <sstream>
#include <chrono>
#include <limits>
#include <unordered_set>
#include <thread>
#include <cerrno>
#include <cstdlib>
#include <complex>
#include <vector>
#if defined(_WIN32)
#include <direct.h>
#else
#include <sys/stat.h>
#endif
namespace silveton {
void MidiTrack::add(MidiEvent e){e_.push_back(e);std::sort(e_.begin(),e_.end(),[](auto&a,auto&b){return a.sample<b.sample;});}
std::vector<MidiEvent> MidiTrack::range(std::int64_t a,std::int64_t b)const{std::vector<MidiEvent>o;for(auto&e:e_)if(e.sample>=a&&e.sample<b)o.push_back(e);return o;}
AudioBuffer AudioEditor::trim(const AudioBuffer&x,std::uint64_t s,std::uint64_t n){if(s>x.frames())throw std::out_of_range("trim");n=std::min<std::uint64_t>(n,x.frames()-s);AudioBuffer o(x.channels(),n);for(size_t c=0;c<x.channels();++c)std::copy_n(x.channelData(c)+s,n,o.channelData(c));return o;}
AudioBuffer AudioEditor::reverse(const AudioBuffer&x){AudioBuffer o(x.channels(),x.frames());for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<x.frames();++i)o.channelData(c)[i]=x.channelData(c)[x.frames()-1-i];return o;}
void AudioEditor::fadeIn(AudioBuffer&x,std::uint64_t n){n=std::min<std::uint64_t>(n,x.frames());for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<n;++i)x.channelData(c)[i]*=n<=1?1.f:float(i)/float(n-1);}
void AudioEditor::fadeOut(AudioBuffer&x,std::uint64_t n){n=std::min<std::uint64_t>(n,x.frames());for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<n;++i)x.channelData(c)[x.frames()-n+i]*=n<=1?0.f:1.f-float(i)/float(n-1);}
AudioBuffer AudioEditor::resampleLinear(const AudioBuffer&x,double ratio){if(!(ratio>0)||!std::isfinite(ratio))throw std::invalid_argument("ratio");size_t nf=std::max<size_t>(1,size_t(std::llround(x.frames()*ratio)));AudioBuffer o(x.channels(),nf);for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<nf;++i){double p=double(i)/ratio;size_t a=std::min<size_t>(size_t(p),x.frames()-1),b=std::min(a+1,x.frames()-1);double t=p-a;o.channelData(c)[i]=float(x.channelData(c)[a]*(1-t)+x.channelData(c)[b]*t);}return o;}
namespace {
constexpr double kPi = 3.141592653589793238462643383279502884;

void fft(std::vector<std::complex<double>>& data, bool inverse) {
    const std::size_t n = data.size();
    for (std::size_t i = 1U, j = 0U; i < n; ++i) {
        std::size_t bit = n >> 1U;
        for (; (j & bit) != 0U; bit >>= 1U) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(data[i], data[j]);
    }

    for (std::size_t len = 2U; len <= n; len <<= 1U) {
        const double angle = (inverse ? 2.0 : -2.0) * kPi / static_cast<double>(len);
        const std::complex<double> wlen(std::cos(angle), std::sin(angle));
        for (std::size_t i = 0U; i < n; i += len) {
            std::complex<double> w(1.0, 0.0);
            const std::size_t half = len >> 1U;
            for (std::size_t j = 0U; j < half; ++j) {
                const std::complex<double> u = data[i + j];
                const std::complex<double> v = data[i + j + half] * w;
                data[i + j] = u + v;
                data[i + j + half] = u - v;
                w *= wlen;
            }
        }
    }

    if (inverse) {
        const double scale = 1.0 / static_cast<double>(n);
        for (auto& value : data) value *= scale;
    }
}

double wrapPhase(double phase) noexcept {
    while (phase > kPi) phase -= 2.0 * kPi;
    while (phase < -kPi) phase += 2.0 * kPi;
    return phase;
}

std::size_t phaseVocoderWindowFor(std::size_t frames) noexcept {
    if (frames >= 2048U) return 1024U;
    if (frames >= 1024U) return 512U;
    if (frames >= 512U) return 256U;
    if (frames >= 256U) return 128U;
    return 64U;
}
}

AudioBuffer AudioEditor::timeStretch(const AudioBuffer& x, double ratio) {
    if (!(ratio > 0.0) || !std::isfinite(ratio)) throw std::invalid_argument("ratio");
    if (x.channels() == 0U || x.frames() == 0U) return AudioBuffer(x.channels(), 0U);
    if (x.frames() < 64U) return resampleLinear(x, ratio);

    const std::size_t fftSize = phaseVocoderWindowFor(x.frames());
    const std::size_t analysisHop = fftSize / 4U;
    const std::size_t synthesisHop = std::max<std::size_t>(1U,
        static_cast<std::size_t>(std::llround(static_cast<double>(analysisHop) * ratio)));
    const std::size_t targetFrames = std::max<std::size_t>(1U,
        static_cast<std::size_t>(std::llround(static_cast<double>(x.frames()) * ratio)));
    const std::size_t workFrames = targetFrames + fftSize * 2U;

    AudioBuffer output(x.channels(), workFrames);
    std::vector<double> normalization(workFrames, 0.0);
    std::vector<double> window(fftSize, 0.0);
    for (std::size_t i = 0U; i < fftSize; ++i) {
        window[i] = 0.5 - 0.5 * std::cos((2.0 * kPi * static_cast<double>(i)) /
                                        static_cast<double>(fftSize - 1U));
    }

    for (std::size_t channel = 0U; channel < x.channels(); ++channel) {
        std::vector<std::complex<double>> spectrum(fftSize);
        std::vector<double> previousPhase(fftSize / 2U + 1U, 0.0);
        std::vector<double> synthesisPhase(fftSize / 2U + 1U, 0.0);
        bool firstFrame = true;
        std::size_t synthesisPosition = 0U;

        for (std::size_t analysisPosition = 0U;
             analysisPosition < x.frames() && synthesisPosition < workFrames;
             analysisPosition += analysisHop, synthesisPosition += synthesisHop) {
            for (std::size_t i = 0U; i < fftSize; ++i) {
                const std::size_t sourceIndex = analysisPosition + i;
                const double sample = sourceIndex < x.frames()
                    ? static_cast<double>(x.sample(channel, sourceIndex))
                    : 0.0;
                spectrum[i] = std::complex<double>(sample * window[i], 0.0);
            }

            fft(spectrum, false);
            const std::size_t bins = fftSize / 2U + 1U;
            for (std::size_t bin = 0U; bin < bins; ++bin) {
                const double magnitude = std::abs(spectrum[bin]);
                const double phase = std::arg(spectrum[bin]);
                const double expectedAdvance = 2.0 * kPi * static_cast<double>(bin) *
                                               static_cast<double>(analysisHop) /
                                               static_cast<double>(fftSize);
                if (firstFrame) {
                    synthesisPhase[bin] = phase;
                } else {
                    const double deviation = wrapPhase(phase - previousPhase[bin] - expectedAdvance);
                    const double trueAdvance = expectedAdvance + deviation;
                    synthesisPhase[bin] += trueAdvance *
                        (static_cast<double>(synthesisHop) / static_cast<double>(analysisHop));
                }
                previousPhase[bin] = phase;
                spectrum[bin] = std::polar(magnitude, synthesisPhase[bin]);
            }

            for (std::size_t bin = 1U; bin < fftSize / 2U; ++bin) {
                spectrum[fftSize - bin] = std::conj(spectrum[bin]);
            }
            spectrum[0] = std::complex<double>(spectrum[0].real(), 0.0);
            spectrum[fftSize / 2U] = std::complex<double>(spectrum[fftSize / 2U].real(), 0.0);
            fft(spectrum, true);

            const std::size_t writable = std::min<std::size_t>(fftSize, workFrames - synthesisPosition);
            for (std::size_t i = 0U; i < writable; ++i) {
                const double w = window[i];
                output.sample(channel, synthesisPosition + i) +=
                    static_cast<float>(spectrum[i].real() * w);
                if (channel == 0U) normalization[synthesisPosition + i] += w * w;
            }
            firstFrame = false;
        }
    }

    for (std::size_t frame = 0U; frame < targetFrames; ++frame) {
        const double norm = normalization[frame];
        if (norm <= 1.0e-12) continue;
        const float inverse = static_cast<float>(1.0 / norm);
        for (std::size_t channel = 0U; channel < output.channels(); ++channel) {
            output.sample(channel, frame) *= inverse;
        }
    }
    return trim(output, 0U, targetFrames);
}

AudioBuffer AudioEditor::pitchShift(const AudioBuffer& x, double semitones) {
    if (!std::isfinite(semitones)) throw std::invalid_argument("semitones");
    const double pitchRatio = std::pow(2.0, semitones / 12.0);
    auto resampled = resampleLinear(x, 1.0 / pitchRatio);
    auto shifted = timeStretch(resampled, pitchRatio);

    // Keep pitch-shift duration exactly equal to the source duration.
    if (shifted.frames() == x.frames()) return shifted;
    if (shifted.frames() > x.frames()) return trim(shifted, 0U, x.frames());

    AudioBuffer result(x.channels(), x.frames());
    for (std::size_t channel = 0U; channel < x.channels(); ++channel) {
        std::copy_n(shifted.channelData(channel), shifted.frames(), result.channelData(channel));
    }
    return result;
}
void RoutingGraph::setNodeCount(size_t n){n_=n;r_.clear();}
void RoutingGraph::addRoute(Route r){if(r.from>=n_||r.to>=n_||r.from==r.to)throw std::invalid_argument("route");r_.push_back(r);(void)topologicalOrder();}
std::vector<size_t> RoutingGraph::topologicalOrder()const{std::vector<size_t>d(n_);for(auto&r:r_)++d[r.to];std::queue<size_t>q;for(size_t i=0;i<n_;++i)if(!d[i])q.push(i);std::vector<size_t>o;while(!q.empty()){auto u=q.front();q.pop();o.push_back(u);for(auto&r:r_)if(r.from==u&&!--d[r.to])q.push(r.to);}if(o.size()!=n_)throw std::logic_error("routing cycle");return o;}
void DelayCompensator::setLatencies(const std::vector<uint32_t>&l){max_=0;for(auto x:l)max_=std::max(max_,x);d_.resize(l.size());for(size_t i=0;i<l.size();++i)d_[i]=max_-l[i];}
uint32_t DelayCompensator::delayFor(size_t i)const{if(i>=d_.size())throw std::out_of_range("pdc");return d_[i];}
static std::string esc(std::string s){for(auto&c:s)if(c=='\t'||c=='\n'||c=='\r')c=' ';return s;}

static int panDepthCode(PanDepth d) noexcept {
    switch (d) {
        case PanDepth::Minus2_5dB: return 25;
        case PanDepth::Minus3dB: return 30;
        case PanDepth::Minus4_5dB: return 45;
        case PanDepth::Minus6dB: return 60;
    }
    return 30;
}

static PanDepth panDepthFromCode(int code) {
    switch (code) {
        case 25: return PanDepth::Minus2_5dB;
        case 30: return PanDepth::Minus3dB;
        case 45: return PanDepth::Minus4_5dB;
        case 60: return PanDepth::Minus6dB;
        default: throw std::runtime_error("unsupported pan depth");
    }
}

static int automationModeCode(AutomationMode mode) noexcept {
    return static_cast<int>(mode);
}

static AutomationMode automationModeFromCode(int code) {
    if (code < static_cast<int>(AutomationMode::Off) || code > static_cast<int>(AutomationMode::Latch))
        throw std::runtime_error("unsupported automation mode");
    return static_cast<AutomationMode>(code);
}

static char hexDigit(unsigned value) noexcept { return value < 10U ? static_cast<char>('0' + value) : static_cast<char>('A' + (value - 10U)); }
static int hexValue(char c) noexcept {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return 10 + c - 'A';
    if (c >= 'a' && c <= 'f') return 10 + c - 'a';
    return -1;
}

static std::string encodeBlob(const std::vector<std::uint8_t>& data) {
    std::string out;
    out.resize(data.size() * 2U);
    for (std::size_t i = 0U; i < data.size(); ++i) {
        out[i * 2U] = hexDigit(data[i] >> 4U);
        out[i * 2U + 1U] = hexDigit(data[i] & 0x0FU);
    }
    return out;
}

static std::vector<std::uint8_t> decodeBlob(const std::string& text) {
    if ((text.size() & 1U) != 0U) throw std::runtime_error("invalid project blob");
    std::vector<std::uint8_t> out(text.size() / 2U);
    for (std::size_t i = 0U; i < out.size(); ++i) {
        const int hi = hexValue(text[i * 2U]);
        const int lo = hexValue(text[i * 2U + 1U]);
        if (hi < 0 || lo < 0) throw std::runtime_error("invalid project blob");
        out[i] = static_cast<std::uint8_t>((hi << 4) | lo);
    }
    return out;
}

static std::string encodeDestinations(const std::vector<int>& values) {
    std::ostringstream ss;
    for (std::size_t i = 0U; i < values.size(); ++i) {
        if (i != 0U) ss << ',';
        ss << values[i];
    }
    return ss.str();
}

static std::vector<int> decodeDestinations(const std::string& text, std::size_t expected) {
    std::vector<int> out;
    if (!text.empty()) {
        std::istringstream ss(text);
        std::string token;
        while (std::getline(ss, token, ',')) {
            if (token.empty()) throw std::runtime_error("invalid project extra output route");
            std::istringstream value(token);
            int v = 0;
            if (!(value >> v) || !value.eof()) throw std::runtime_error("invalid project extra output route");
            out.push_back(v);
        }
    }
    if (out.size() != expected) throw std::runtime_error("project extra output count mismatch");
    return out;
}

static std::string encodeAutomationPoints(const ParameterAutomationLane& lane) {
    std::ostringstream ss;
    ss.precision(17);
    const auto& points = lane.points();
    for (std::size_t i = 0U; i < points.size(); ++i) {
        if (i != 0U) ss << ';';
        ss << points[i].sample << ':' << points[i].normalized;
    }
    return ss.str();
}

static void decodeAutomationPoints(const std::string& text,
                                   std::size_t expected,
                                   ParameterAutomationLane& lane) {
    std::size_t count = 0U;
    if (!text.empty()) {
        std::istringstream ss(text);
        std::string token;
        while (std::getline(ss, token, ';')) {
            const auto colon = token.find(':');
            if (colon == std::string::npos) throw std::runtime_error("invalid automation point");
            std::int64_t sample = 0;
            double value = 0.0;
            std::istringstream a(token.substr(0U, colon));
            std::istringstream b(token.substr(colon + 1U));
            if (!(a >> sample) || !a.eof() || !(b >> value) || !b.eof()) throw std::runtime_error("invalid automation point");
            lane.write(sample, value);
            ++count;
        }
    }
    if (count != expected) throw std::runtime_error("project automation point count mismatch");
}

static std::string encodeMixerAutomationPoints(const AutomationLane& lane) {
    std::ostringstream ss;
    ss.precision(9);
    const auto& points = lane.points();
    for (std::size_t i = 0U; i < points.size(); ++i) {
        if (i != 0U) ss << ';';
        ss << points[i].sample << ':' << points[i].value;
    }
    return ss.str();
}

static void decodeMixerAutomationPoints(const std::string& text,
                                        std::size_t expected,
                                        AutomationLane& lane) {
    std::size_t count = 0U;
    if (!text.empty()) {
        std::istringstream ss(text);
        std::string token;
        while (std::getline(ss, token, ';')) {
            const auto colon = token.find(':');
            if (colon == std::string::npos) throw std::runtime_error("invalid mixer automation point");
            std::int64_t sample = 0;
            float value = 0.0F;
            std::istringstream a(token.substr(0U, colon));
            std::istringstream b(token.substr(colon + 1U));
            if (!(a >> sample) || !a.eof() || !(b >> value) || !b.eof())
                throw std::runtime_error("invalid mixer automation point");
            lane.add(sample, value);
            ++count;
        }
    }
    if (count != expected) throw std::runtime_error("mixer automation point count mismatch");
}

static void writeMixerAutomation(std::ofstream& f,
                                 const char* tag,
                                 AutomationMode firstMode, const AutomationLane& first,
                                 AutomationMode secondMode, const AutomationLane& second,
                                 AutomationMode thirdMode, const AutomationLane& third) {
    f << tag << '\t'
      << automationModeCode(firstMode) << '\t' << first.points().size() << '\t' << encodeMixerAutomationPoints(first) << '\t'
      << automationModeCode(secondMode) << '\t' << second.points().size() << '\t' << encodeMixerAutomationPoints(second) << '\t'
      << automationModeCode(thirdMode) << '\t' << third.points().size() << '\t' << encodeMixerAutomationPoints(third) << '\n';
}

static void readMixerAutomationLine(const std::string& line,
                                    const char* expectedTag,
                                    AutomationMode& firstMode, AutomationLane& first,
                                    AutomationMode& secondMode, AutomationLane& second,
                                    AutomationMode& thirdMode, AutomationLane& third) {
    std::istringstream fields(line);
    std::vector<std::string> values;
    std::string value;
    while (std::getline(fields, value, '\t')) values.push_back(value);
    if (!line.empty() && line.back() == '\t') values.emplace_back();
    if (values.size() != 10U || values[0] != expectedTag)
        throw std::runtime_error("invalid mixer automation line");

    int mode1 = 0, mode2 = 0, mode3 = 0;
    std::size_t count1 = 0U, count2 = 0U, count3 = 0U;
    std::istringstream a(values[1]), b(values[2]), c(values[4]), d(values[5]), e(values[7]), g(values[8]);
    if (!(a >> mode1) || !(b >> count1) || !(c >> mode2) || !(d >> count2) || !(e >> mode3) || !(g >> count3))
        throw std::runtime_error("invalid mixer automation numbers");
    firstMode = automationModeFromCode(mode1);
    secondMode = automationModeFromCode(mode2);
    thirdMode = automationModeFromCode(mode3);
    decodeMixerAutomationPoints(values[3], count1, first);
    decodeMixerAutomationPoints(values[6], count2, second);
    decodeMixerAutomationPoints(values[9], count3, third);
}

static void writePluginSlots(std::ofstream& f, const std::vector<ProjectPluginSlot>& slots) {
    f << "SLOTS\t" << slots.size() << '\n';
    for (const auto& slot : slots) {
        f << "SLOT\t" << esc(slot.modulePath) << '\t' << esc(slot.classId) << '\t'
          << slot.enabled << '\t' << slot.latencySnapshot << '\t' << slot.sidechainSourceNode << '\t'
          << slot.midiInputPort << '\t' << slot.extraOutputDestinations.size() << '\t'
          << encodeDestinations(slot.extraOutputDestinations) << '\t'
          << encodeBlob(slot.componentState) << '\t' << encodeBlob(slot.controllerState) << '\t'
          << slot.automation.size() << '\n';
        for (const auto& lane : slot.automation) {
            f << "AUTO\t" << lane.parameterId << '\t' << automationModeCode(lane.mode) << '\t'
              << lane.lane.points().size() << '\t' << encodeAutomationPoints(lane.lane) << '\n';
        }
    }
}

static std::vector<ProjectPluginSlot> readPluginSlots(std::ifstream& f) {
    std::string line;
    if (!std::getline(f, line)) throw std::runtime_error("missing project slots section");
    std::istringstream header(line);
    std::string tag;
    std::size_t slotCount = 0U;
    if (!std::getline(header, tag, '\t') || tag != "SLOTS" || !(header >> slotCount))
        throw std::runtime_error("invalid project slots section");
    std::vector<ProjectPluginSlot> slots;
    slots.reserve(slotCount);
    for (std::size_t si = 0U; si < slotCount; ++si) {
        if (!std::getline(f, line)) throw std::runtime_error("missing project slot");
        std::istringstream ss(line);
        std::string field;
        if (!std::getline(ss, field, '\t') || field != "SLOT") throw std::runtime_error("invalid project slot");
        ProjectPluginSlot slot;
        std::string enabled, latency, side, midi, extraCountText, extraText, component, controller, automationCountText;
        if (!std::getline(ss, slot.modulePath, '\t') || !std::getline(ss, slot.classId, '\t') ||
            !std::getline(ss, enabled, '\t') || !std::getline(ss, latency, '\t') ||
            !std::getline(ss, side, '\t') || !std::getline(ss, midi, '\t') ||
            !std::getline(ss, extraCountText, '\t') || !std::getline(ss, extraText, '\t') ||
            !std::getline(ss, component, '\t') || !std::getline(ss, controller, '\t') ||
            !std::getline(ss, automationCountText)) throw std::runtime_error("invalid project slot fields");
        std::size_t extraCount = 0U, automationCount = 0U;
        {
            std::istringstream a(enabled), b(latency), c(side), d(midi), e(extraCountText), g(automationCountText);
            int enabledInt = 0;
            if (!(a >> enabledInt) || !(b >> slot.latencySnapshot) || !(c >> slot.sidechainSourceNode) ||
                !(d >> slot.midiInputPort) || !(e >> extraCount) || !(g >> automationCount))
                throw std::runtime_error("invalid project slot numbers");
            slot.enabled = enabledInt != 0;
        }
        slot.extraOutputDestinations = decodeDestinations(extraText, extraCount);
        slot.componentState = decodeBlob(component);
        slot.controllerState = decodeBlob(controller);
        slot.automation.reserve(automationCount);
        for (std::size_t ai = 0U; ai < automationCount; ++ai) {
            if (!std::getline(f, line)) throw std::runtime_error("missing project automation lane");
            std::istringstream as(line);
            std::string laneTag, param, mode, pointCountText, points;
            if (!std::getline(as, laneTag, '\t') || laneTag != "AUTO" ||
                !std::getline(as, param, '\t') || !std::getline(as, mode, '\t') ||
                !std::getline(as, pointCountText, '\t') || !std::getline(as, points))
                throw std::runtime_error("invalid project automation lane");
            ProjectPluginAutomationLane lane;
            int modeCode = 0;
            std::size_t pointCount = 0U;
            std::istringstream p(param), m(mode), pc(pointCountText);
            if (!(p >> lane.parameterId) || !(m >> modeCode) || !(pc >> pointCount))
                throw std::runtime_error("invalid project automation lane numbers");
            lane.mode = automationModeFromCode(modeCode);
            decodeAutomationPoints(points, pointCount, lane.lane);
            slot.automation.push_back(std::move(lane));
        }
        slots.push_back(std::move(slot));
    }
    return slots;
}

static int busKindCode(ProjectBusKind kind) noexcept {
    return kind == ProjectBusKind::FxReturn ? 1 : 0;
}

static ProjectBusKind busKindFromCode(int code) {
    if (code == 0) return ProjectBusKind::Group;
    if (code == 1) return ProjectBusKind::FxReturn;
    throw std::runtime_error("invalid project bus kind");
}

static void writeSends(std::ofstream& f, const std::vector<ProjectSend>& sends) {
    f << "SENDS\t" << sends.size() << '\n';
    for (const auto& send : sends) {
        f << "SEND\t" << send.destinationBus << '\t' << send.gainDb << '\t' << send.enabled << '\t'
          << send.preFader << '\t'
          << automationModeCode(send.gainAutomationMode) << '\t' << send.gainAutomationDb.points().size() << '\t'
          << encodeMixerAutomationPoints(send.gainAutomationDb) << '\t'
          << automationModeCode(send.enabledAutomationMode) << '\t' << send.enabledAutomation.points().size() << '\t'
          << encodeMixerAutomationPoints(send.enabledAutomation) << '\n';
    }
}

static std::vector<ProjectSend> readSends(std::ifstream& f, bool v16) {
    std::string line;
    if (!std::getline(f, line)) throw std::runtime_error("missing project sends section");
    std::istringstream header(line);
    std::string tag;
    std::size_t count = 0U;
    if (!std::getline(header, tag, '\t') || tag != "SENDS" || !(header >> count))
        throw std::runtime_error("invalid project sends section");
    std::vector<ProjectSend> sends;
    sends.reserve(count);
    for (std::size_t i = 0U; i < count; ++i) {
        if (!std::getline(f, line)) throw std::runtime_error("missing project send");
        std::istringstream fields(line);
        std::vector<std::string> values;
        std::string value;
        while (std::getline(fields, value, '\t')) values.push_back(value);
        if (!line.empty() && line.back() == '\t') values.emplace_back();
        if ((!v16 && values.size() != 4U) || (v16 && values.size() != 11U) || values[0] != "SEND")
            throw std::runtime_error("invalid project send fields");

        ProjectSend send;
        int enabled = 0;
        std::istringstream dest(values[1]), gain(values[2]), en(values[3]);
        if (!(dest >> send.destinationBus) || !(gain >> send.gainDb) || !(en >> enabled))
            throw std::runtime_error("invalid project send numbers");
        send.enabled = enabled != 0;

        if (v16) {
            int pre = 0, gainMode = 0, enabledMode = 0;
            std::size_t gainCount = 0U, enabledCount = 0U;
            std::istringstream preStream(values[4]), gm(values[5]), gc(values[6]), em(values[8]), ec(values[9]);
            if (!(preStream >> pre) || !(gm >> gainMode) || !(gc >> gainCount) ||
                !(em >> enabledMode) || !(ec >> enabledCount))
                throw std::runtime_error("invalid V16 send automation numbers");
            send.preFader = pre != 0;
            send.gainAutomationMode = automationModeFromCode(gainMode);
            send.enabledAutomationMode = automationModeFromCode(enabledMode);
            decodeMixerAutomationPoints(values[7], gainCount, send.gainAutomationDb);
            decodeMixerAutomationPoints(values[10], enabledCount, send.enabledAutomation);
        }
        sends.push_back(std::move(send));
    }
    return sends;
}

static void writeTempoMap(std::ofstream& f, const Project& project) {
    TempoMap map = project.tempoMap;
    map.setSampleRate(project.sampleRate);
    if (map.changes().empty()) map.setInitialTempo(project.tempo);
    f << "TEMPO_MAP\t" << map.initialTempo() << '\t'
      << map.initialNumerator() << '\t' << map.initialDenominator() << '\t'
      << map.changes().size() << '\n';
    for (const auto& change : map.changes()) {
        f << "TEMPO\t" << change.sample << '\t' << change.changesTempo << '\t' << change.bpm
          << '\t' << change.changesTimeSignature << '\t' << change.numerator << '\t' << change.denominator << '\n';
    }
}

static TempoMap readTempoMap(std::ifstream& f, double sampleRate) {
    std::string line;
    if (!std::getline(f, line)) throw std::runtime_error("missing tempo map section");
    std::istringstream header(line);
    std::string tag;
    double initialTempo = 120.0;
    unsigned initialNumerator = 4U, initialDenominator = 4U;
    std::size_t count = 0U;
    if (!std::getline(header, tag, '\t') || tag != "TEMPO_MAP" ||
        !(header >> initialTempo >> initialNumerator >> initialDenominator >> count))
        throw std::runtime_error("invalid tempo map section");
    if (count > 100000U) throw std::runtime_error("tempo map is unreasonably large");

    TempoMap map;
    map.setSampleRate(sampleRate);
    map.setInitialTempo(initialTempo);
    map.setInitialTimeSignature(static_cast<std::uint16_t>(initialNumerator),
                                static_cast<std::uint16_t>(initialDenominator));
    for (std::size_t i = 0U; i < count; ++i) {
        if (!std::getline(f, line)) throw std::runtime_error("missing tempo map change");
        std::istringstream row(line);
        std::string rowTag;
        std::int64_t sample = 0;
        int changesTempo = 0, changesSignature = 0;
        double bpm = 120.0;
        unsigned numerator = 4U, denominator = 4U;
        if (!std::getline(row, rowTag, '\t') || rowTag != "TEMPO" ||
            !(row >> sample >> changesTempo >> bpm >> changesSignature >> numerator >> denominator))
            throw std::runtime_error("invalid tempo map change");
        if (changesTempo) map.addTempoChange(sample, bpm);
        if (changesSignature) map.addTimeSignatureChange(sample,
                                                         static_cast<std::uint16_t>(numerator),
                                                         static_cast<std::uint16_t>(denominator));
    }
    return map;
}

static void writeMidiTracks(std::ofstream& f, const std::vector<ProjectMidiTrack>& tracks) {
    f << "MIDI_TRACKS\t" << tracks.size() << '\n';
    for (const auto& track : tracks) {
        f << "MIDI_TRACK\t" << esc(track.name) << '\t' << track.outputPort << '\n';
        const auto& notes = track.sequence.notes();
        f << "MIDI_NOTES\t" << notes.size() << '\n';
        for (const auto& note : notes) {
            f << "MIDI_NOTE\t" << note.id << '\t' << note.startQuarterNotes << '\t'
              << note.durationQuarterNotes << '\t' << static_cast<unsigned>(note.channel) << '\t'
              << static_cast<unsigned>(note.pitch) << '\t' << static_cast<unsigned>(note.velocity) << '\t'
              << static_cast<unsigned>(note.releaseVelocity) << '\t' << note.muted << '\n';
        }
        const auto& messages = track.sequence.messages();
        f << "MIDI_MESSAGES\t" << messages.size() << '\n';
        for (const auto& message : messages) {
            f << "MIDI_MESSAGE\t" << message.id << '\t' << message.quarterNotes << '\t'
              << static_cast<unsigned>(message.status) << '\t' << static_cast<unsigned>(message.data1) << '\t'
              << static_cast<unsigned>(message.data2) << '\t' << message.muted << '\n';
        }
    }
}

static std::vector<ProjectMidiTrack> readMidiTracks(std::ifstream& f, bool withMessages) {
    std::string line;
    if (!std::getline(f, line)) throw std::runtime_error("missing MIDI tracks section");
    std::istringstream header(line);
    std::string tag;
    std::size_t count = 0U;
    if (!std::getline(header, tag, '\t') || tag != "MIDI_TRACKS" || !(header >> count) || count > Project::kMaxTracks)
        throw std::runtime_error("invalid MIDI tracks section");
    std::vector<ProjectMidiTrack> tracks;
    tracks.reserve(count);
    for (std::size_t i = 0U; i < count; ++i) {
        if (!std::getline(f, line)) throw std::runtime_error("missing MIDI track");
        std::istringstream trackLine(line);
        std::string trackTag;
        ProjectMidiTrack track;
        if (!std::getline(trackLine, trackTag, '\t') || trackTag != "MIDI_TRACK" ||
            !std::getline(trackLine, track.name, '\t') || !(trackLine >> track.outputPort))
            throw std::runtime_error("invalid MIDI track");

        if (!std::getline(f, line)) throw std::runtime_error("missing MIDI notes section");
        std::istringstream notesHeader(line);
        std::string notesTag;
        std::size_t noteCount = 0U;
        if (!std::getline(notesHeader, notesTag, '\t') || notesTag != "MIDI_NOTES" || !(notesHeader >> noteCount) || noteCount > 1000000U)
            throw std::runtime_error("invalid MIDI notes section");
        for (std::size_t n = 0U; n < noteCount; ++n) {
            if (!std::getline(f, line)) throw std::runtime_error("missing MIDI note");
            std::istringstream noteLine(line);
            std::string noteTag;
            MusicalMidiNote note;
            unsigned channel = 0U, pitch = 0U, velocity = 0U, releaseVelocity = 0U;
            int muted = 0;
            if (!std::getline(noteLine, noteTag, '\t') || noteTag != "MIDI_NOTE" ||
                !(noteLine >> note.id >> note.startQuarterNotes >> note.durationQuarterNotes >>
                  channel >> pitch >> velocity >> releaseVelocity >> muted))
                throw std::runtime_error("invalid MIDI note");
            if (channel > 15U || pitch > 127U || velocity > 127U || releaseVelocity > 127U)
                throw std::runtime_error("MIDI note field out of range");
            note.channel = static_cast<std::uint8_t>(channel);
            note.pitch = static_cast<std::uint8_t>(pitch);
            note.velocity = static_cast<std::uint8_t>(velocity);
            note.releaseVelocity = static_cast<std::uint8_t>(releaseVelocity);
            note.muted = muted != 0;
            (void)track.sequence.addNote(note);
        }
        if (withMessages) {
            if (!std::getline(f, line)) throw std::runtime_error("missing MIDI messages section");
            std::istringstream messagesHeader(line);
            std::string messagesTag;
            std::size_t messageCount = 0U;
            if (!std::getline(messagesHeader, messagesTag, '\t') || messagesTag != "MIDI_MESSAGES" ||
                !(messagesHeader >> messageCount) || messageCount > 1000000U)
                throw std::runtime_error("invalid MIDI messages section");
            for (std::size_t m = 0U; m < messageCount; ++m) {
                if (!std::getline(f, line)) throw std::runtime_error("missing MIDI message");
                std::istringstream messageLine(line);
                std::string messageTag;
                MusicalMidiMessage message;
                unsigned status = 0U, data1 = 0U, data2 = 0U;
                int muted = 0;
                if (!std::getline(messageLine, messageTag, '\t') || messageTag != "MIDI_MESSAGE" ||
                    !(messageLine >> message.id >> message.quarterNotes >> status >> data1 >> data2 >> muted))
                    throw std::runtime_error("invalid MIDI message");
                if (status > 255U || data1 > 127U || data2 > 127U)
                    throw std::runtime_error("MIDI message field out of range");
                message.status = static_cast<std::uint8_t>(status);
                message.data1 = static_cast<std::uint8_t>(data1);
                message.data2 = static_cast<std::uint8_t>(data2);
                message.muted = muted != 0;
                (void)track.sequence.addMessage(message);
            }
        }
        tracks.push_back(std::move(track));
    }
    return tracks;
}


static void validateProjectAudioClip(const ProjectAudioClip& clip) {
    if (clip.id == 0U) throw std::runtime_error("project clip id must be non-zero");
    if (clip.audioPath.empty()) throw std::runtime_error("project clip audio path is empty");
    if (clip.timelineStartSample < 0) throw std::runtime_error("project clip starts before zero");
    if (clip.sourceFrames == 0U || clip.sourceStartSample >= clip.sourceFrames)
        throw std::runtime_error("project clip source range invalid");
    if (clip.lengthSamples == 0U || clip.lengthSamples > clip.sourceFrames - clip.sourceStartSample)
        throw std::runtime_error("project clip length invalid");
    if (clip.lengthSamples > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()) ||
        clip.timelineStartSample > std::numeric_limits<std::int64_t>::max() - static_cast<std::int64_t>(clip.lengthSamples))
        throw std::runtime_error("project clip timeline overflow");
    if (!std::isfinite(clip.gainDb)) throw std::runtime_error("project clip gain invalid");
    const auto automatic = ProjectAudioClip::kAutoFadeAnchor;
    if ((clip.fadeInAnchorSourceSample != automatic && clip.fadeInAnchorSourceSample > clip.sourceFrames) ||
        (clip.fadeOutAnchorSourceSample != automatic && clip.fadeOutAnchorSourceSample > clip.sourceFrames))
        throw std::runtime_error("project clip fade anchor invalid");
}

static void writeProjectAudioClips(std::ofstream& f, const std::vector<ProjectAudioClip>& clips) {
    std::unordered_set<std::uint64_t> ids;
    f << "CLIPS\t" << clips.size() << '\n';
    for (const auto& clip : clips) {
        validateProjectAudioClip(clip);
        if (!ids.insert(clip.id).second) throw std::runtime_error("duplicate project clip id");
        f << "CLIP\t" << clip.id << '\t' << esc(clip.audioPath) << '\t'
          << clip.timelineStartSample << '\t' << clip.sourceStartSample << '\t'
          << clip.lengthSamples << '\t' << clip.sourceFrames << '\t'
          << clip.gainDb << '\t' << clip.mute << '\t'
          << clip.fadeInSamples << '\t' << clip.fadeOutSamples << '\t'
          << clip.fadeInAnchorSourceSample << '\t' << clip.fadeOutAnchorSourceSample << '\n';
    }
}

static std::vector<ProjectAudioClip> readProjectAudioClips(std::ifstream& f) {
    std::string line;
    if (!std::getline(f, line)) throw std::runtime_error("missing project clips section");
    std::istringstream header(line);
    std::string tag;
    std::size_t count = 0U;
    if (!std::getline(header, tag, '\t') || tag != "CLIPS" || !(header >> count) || count > 1000000U)
        throw std::runtime_error("invalid project clips section");
    std::vector<ProjectAudioClip> clips;
    clips.reserve(count);
    std::unordered_set<std::uint64_t> ids;
    for (std::size_t i = 0U; i < count; ++i) {
        if (!std::getline(f, line)) throw std::runtime_error("missing project clip");
        std::istringstream ss(line);
        std::string clipTag;
        ProjectAudioClip clip;
        if (!std::getline(ss, clipTag, '\t') || clipTag != "CLIP" ||
            !(ss >> clip.id) || ss.get() != '\t' || !std::getline(ss, clip.audioPath, '\t') ||
            !(ss >> clip.timelineStartSample >> clip.sourceStartSample >> clip.lengthSamples >> clip.sourceFrames
                 >> clip.gainDb >> clip.mute >> clip.fadeInSamples >> clip.fadeOutSamples
                 >> clip.fadeInAnchorSourceSample >> clip.fadeOutAnchorSourceSample))
            throw std::runtime_error("invalid project clip");
        validateProjectAudioClip(clip);
        if (!ids.insert(clip.id).second) throw std::runtime_error("duplicate project clip id");
        clips.push_back(std::move(clip));
    }
    return clips;
}

static void writeTakeLanes(std::ofstream& f, const std::vector<ProjectTakeLane>& lanes) {
    std::unordered_set<std::uint64_t> laneIds;
    f << "TAKE_LANES\t" << lanes.size() << '\n';
    for (const auto& lane : lanes) {
        if (lane.id == 0U || !laneIds.insert(lane.id).second)
            throw std::runtime_error("invalid or duplicate take lane id");
        f << "TAKE_LANE\t" << lane.id << '\t' << lane.cyclePass << '\t' << esc(lane.name) << '\n';
        writeProjectAudioClips(f, lane.clips);
    }
}

static std::vector<ProjectTakeLane> readTakeLanes(std::ifstream& f) {
    std::string line;
    if (!std::getline(f, line)) throw std::runtime_error("missing take lanes section");
    std::istringstream header(line);
    std::string tag;
    std::size_t count = 0U;
    if (!std::getline(header, tag, '\t') || tag != "TAKE_LANES" || !(header >> count) || count > 1000000U)
        throw std::runtime_error("invalid take lanes section");
    std::vector<ProjectTakeLane> lanes;
    lanes.reserve(count);
    std::unordered_set<std::uint64_t> ids;
    for (std::size_t i = 0U; i < count; ++i) {
        if (!std::getline(f, line)) throw std::runtime_error("missing take lane");
        std::istringstream ss(line);
        std::string laneTag;
        ProjectTakeLane lane;
        if (!std::getline(ss, laneTag, '\t') || laneTag != "TAKE_LANE" ||
            !(ss >> lane.id >> lane.cyclePass) || ss.get() != '\t' || !std::getline(ss, lane.name))
            throw std::runtime_error("invalid take lane");
        if (lane.id == 0U || !ids.insert(lane.id).second)
            throw std::runtime_error("invalid or duplicate take lane id");
        lane.clips = readProjectAudioClips(f);
        lanes.push_back(std::move(lane));
    }
    return lanes;
}

static const ProjectAudioClip* findTakeClipForComp(const std::vector<ProjectTakeLane>& lanes,
                                                   std::uint64_t laneId,
                                                   std::uint64_t clipId) {
    for (const auto& lane : lanes) {
        if (lane.id != laneId) continue;
        for (const auto& clip : lane.clips) if (clip.id == clipId) return &clip;
        return nullptr;
    }
    return nullptr;
}

static void validateCompSectionForProject(const ProjectCompSection& section,
                                          const std::vector<ProjectTakeLane>& lanes) {
    if (section.id == 0U || section.takeLaneId == 0U || section.takeClipId == 0U ||
        section.timelineStartSample < 0 || section.lengthSamples == 0U ||
        section.lengthSamples > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()) ||
        section.timelineStartSample > std::numeric_limits<std::int64_t>::max() - static_cast<std::int64_t>(section.lengthSamples))
        throw std::runtime_error("invalid comp section");
    const auto* clip = findTakeClipForComp(lanes, section.takeLaneId, section.takeClipId);
    if (clip == nullptr) throw std::runtime_error("comp section references missing take clip");
    const std::int64_t sectionEnd = section.timelineStartSample + static_cast<std::int64_t>(section.lengthSamples);
    const std::int64_t clipEnd = clip->timelineStartSample + static_cast<std::int64_t>(clip->lengthSamples);
    if (section.timelineStartSample < clip->timelineStartSample || sectionEnd > clipEnd)
        throw std::runtime_error("comp section outside take clip");
}

static void writeCompSections(std::ofstream& f,
                              const std::vector<ProjectCompSection>& sections,
                              const std::vector<ProjectTakeLane>& lanes) {
    std::unordered_set<std::uint64_t> ids;
    f << "COMP\t" << sections.size() << '\n';
    for (const auto& section : sections) {
        validateCompSectionForProject(section, lanes);
        if (!ids.insert(section.id).second) throw std::runtime_error("duplicate comp section id");
        f << "COMP_SECTION\t" << section.id << '\t' << section.takeLaneId << '\t' << section.takeClipId
          << '\t' << section.timelineStartSample << '\t' << section.lengthSamples
          << '\t' << section.crossfadeSamples << '\n';
    }
}

static std::vector<ProjectCompSection> readCompSections(std::ifstream& f,
                                                        const std::vector<ProjectTakeLane>& lanes) {
    std::string line;
    if (!std::getline(f, line)) throw std::runtime_error("missing comp section");
    std::istringstream header(line);
    std::string tag;
    std::size_t count = 0U;
    if (!std::getline(header, tag, '\t') || tag != "COMP" || !(header >> count) || count > 1000000U)
        throw std::runtime_error("invalid comp section header");
    std::vector<ProjectCompSection> sections;
    sections.reserve(count);
    std::unordered_set<std::uint64_t> ids;
    for (std::size_t i = 0U; i < count; ++i) {
        if (!std::getline(f, line)) throw std::runtime_error("missing comp section row");
        std::istringstream ss(line);
        std::string rowTag;
        ProjectCompSection section;
        if (!std::getline(ss, rowTag, '\t') || rowTag != "COMP_SECTION" ||
            !(ss >> section.id >> section.takeLaneId >> section.takeClipId >> section.timelineStartSample
                 >> section.lengthSamples >> section.crossfadeSamples))
            throw std::runtime_error("invalid comp section row");
        validateCompSectionForProject(section, lanes);
        if (!ids.insert(section.id).second) throw std::runtime_error("duplicate comp section id");
        sections.push_back(section);
    }
    return sections;
}

void Project::addTrack(ProjectTrack track) {
    if (tracks.size() >= kMaxTracks) throw std::length_error("Silveton project track limit is 256");
    tracks.push_back(std::move(track));
}

void Project::save(const std::string&p) const {
    if (tracks.size() > kMaxTracks) throw std::length_error("Silveton project track limit is 256");
    std::ofstream f(p.c_str());
    if(!f) throw std::runtime_error("project write");
    f << "SILVETON_PROJECT_V22\n" << sampleRate << '\t' << tempo << '\t' << panDepthCode(panDepth) << '\t' << masterFaderDb << '\n';
    writeTempoMap(f, *this);
    f << "TRACKS\t" << tracks.size() << '\n';
    for (const auto& t : tracks) {
        f << "TRACK\t" << esc(t.name) << '\t' << esc(t.audioPath) << '\t' << t.gainDb << '\t' << t.pan << '\t' << t.mute
          << '\t' << t.useDualStereoPan << '\t' << t.stereoLeftPan << '\t' << t.stereoRightPan
          << '\t' << t.timelineStartSample << '\t' << t.sourceStartSample
          << '\t' << t.voiceEnabled << '\t' << t.voicePriority << '\t' << t.outputBus << '\n';
        writeProjectAudioClips(f, t.clips);
        writeTakeLanes(f, t.takeLanes);
        writeCompSections(f, t.compSections, t.takeLanes);
        writePluginSlots(f, t.pluginSlots);
        writeSends(f, t.sends);
        writeMixerAutomation(f, "TRACKAUTO",
                             t.gainAutomationMode, t.gainAutomationDb,
                             t.panAutomationMode, t.panAutomation,
                             t.muteAutomationMode, t.muteAutomation);
    }
    writeMidiTracks(f, midiTracks);
    f << "BUSES\t" << buses.size() << '\n';
    for (const auto& bus : buses) {
        f << "BUS\t" << esc(bus.name) << '\t' << busKindCode(bus.kind) << '\t'
          << bus.gainDb << '\t' << bus.mute << '\t' << bus.outputBus << '\n';
        writePluginSlots(f, bus.pluginSlots);
        writeSends(f, bus.sends);
        AutomationLane empty;
        writeMixerAutomation(f, "BUSAUTO",
                             bus.gainAutomationMode, bus.gainAutomationDb,
                             bus.muteAutomationMode, bus.muteAutomation,
                             AutomationMode::Off, empty);
    }
    f << "MASTER\n";
    writePluginSlots(f, masterPluginSlots);
    AutomationLane emptyMaster;
    writeMixerAutomation(f, "MASTERAUTO",
                         masterFaderAutomationMode, masterFaderAutomationDb,
                         AutomationMode::Off, emptyMaster,
                         AutomationMode::Off, emptyMaster);
    f << "END\n";
    if(!f) throw std::runtime_error("project write failed");
}

Project Project::load(const std::string&p) {
    std::ifstream f(p.c_str());
    std::string line;
    if(!std::getline(f,line)) throw std::runtime_error("project format");
    const bool v1 = line=="SILVETON_PROJECT_V1";
    const bool v2 = line=="SILVETON_PROJECT_V2";
    const bool v3 = line=="SILVETON_PROJECT_V3";
    const bool v4 = line=="SILVETON_PROJECT_V4";
    const bool v14 = line=="SILVETON_PROJECT_V14";
    const bool v15 = line=="SILVETON_PROJECT_V15";
    const bool v16 = line=="SILVETON_PROJECT_V16";
    const bool v17 = line=="SILVETON_PROJECT_V17";
    const bool v18 = line=="SILVETON_PROJECT_V18";
    const bool v19 = line=="SILVETON_PROJECT_V19";
    const bool v20 = line=="SILVETON_PROJECT_V20";
    const bool v21 = line=="SILVETON_PROJECT_V21";
    const bool v22 = line=="SILVETON_PROJECT_V22";
    if(!v1 && !v2 && !v3 && !v4 && !v14 && !v15 && !v16 && !v17 && !v18 && !v19 && !v20 && !v21 && !v22) throw std::runtime_error("project format");

    Project o;
    if(!std::getline(f,line)) throw std::runtime_error("project header");
    {
        std::istringstream ss(line);
        if(v1) {
            if(!(ss>>o.sampleRate>>o.tempo)) throw std::runtime_error("project header");
            o.panDepth=PanDepth::Minus3dB;
            o.masterFaderDb=0.0F;
        } else if(v2) {
            int pd=30;
            if(!(ss>>o.sampleRate>>o.tempo>>pd)) throw std::runtime_error("project header");
            o.panDepth=panDepthFromCode(pd);
            o.masterFaderDb=0.0F;
        } else {
            int pd=30;
            if(!(ss>>o.sampleRate>>o.tempo>>pd>>o.masterFaderDb)) throw std::runtime_error("project header");
            o.panDepth=panDepthFromCode(pd);
        }
    }

    if (v18 || v19 || v20 || v21 || v22) {
        o.tempoMap = readTempoMap(f, o.sampleRate);
        o.tempo = o.tempoMap.tempoAtSample(0);
    } else {
        o.tempoMap.setSampleRate(o.sampleRate);
        o.tempoMap.setInitialTempo(o.tempo);
    }

    if (v14 || v15 || v16 || v17 || v18 || v19 || v20 || v21 || v22) {
        if (!std::getline(f, line)) throw std::runtime_error("missing project tracks section");
        std::istringstream th(line);
        std::string tag;
        std::size_t trackCount = 0U;
        if (!std::getline(th, tag, '\t') || tag != "TRACKS" || !(th >> trackCount) || trackCount > kMaxTracks)
            throw std::runtime_error("invalid project tracks section");
        o.tracks.reserve(trackCount);
        for (std::size_t ti = 0U; ti < trackCount; ++ti) {
            if (!std::getline(f, line)) throw std::runtime_error("missing project track");
            std::istringstream ss(line);
            std::string trackTag;
            ProjectTrack t;
            if (!std::getline(ss, trackTag, '\t') || trackTag != "TRACK" ||
                !std::getline(ss, t.name, '\t') || !std::getline(ss, t.audioPath, '\t') ||
                !(ss >> t.gainDb >> t.pan >> t.mute >> t.useDualStereoPan >> t.stereoLeftPan >> t.stereoRightPan
                     >> t.timelineStartSample >> t.sourceStartSample >> t.voiceEnabled >> t.voicePriority))
                throw std::runtime_error("project track");
            if ((v15 || v16 || v17 || v18 || v19 || v20 || v21 || v22) && !(ss >> t.outputBus)) throw std::runtime_error("project track output");
            if (v20 || v21 || v22) t.clips = readProjectAudioClips(f);
            if (v21 || v22) {
                t.takeLanes = readTakeLanes(f);
                t.compSections = readCompSections(f, t.takeLanes);
            }
            t.pluginSlots = readPluginSlots(f);
            if (v15 || v16 || v17 || v18 || v19 || v20 || v21 || v22) t.sends = readSends(f, v16 || v17 || v18 || v19 || v20 || v21 || v22);
            if (v16 || v17 || v18 || v19 || v20 || v21 || v22) {
                if (!std::getline(f, line)) throw std::runtime_error("missing track automation");
                readMixerAutomationLine(line, "TRACKAUTO",
                                        t.gainAutomationMode, t.gainAutomationDb,
                                        t.panAutomationMode, t.panAutomation,
                                        t.muteAutomationMode, t.muteAutomation);
            }
            o.tracks.push_back(std::move(t));
        }
        if (v19 || v20 || v21 || v22) o.midiTracks = readMidiTracks(f, v22);
        if (!std::getline(f, line)) throw std::runtime_error("missing project buses section");
        std::istringstream bh(line);
        std::string busTag;
        std::size_t busCount = 0U;
        if (!std::getline(bh, busTag, '\t') || busTag != "BUSES" || !(bh >> busCount))
            throw std::runtime_error("invalid project buses section");
        o.buses.reserve(busCount);
        for (std::size_t bi = 0U; bi < busCount; ++bi) {
            if (!std::getline(f, line)) throw std::runtime_error("missing project bus");
            std::istringstream bs(line);
            std::string tagText;
            ProjectBus bus;
            if (!std::getline(bs, tagText, '\t') || tagText != "BUS" || !std::getline(bs, bus.name, (v15 || v16 || v17 || v18 || v19 || v20 || v21 || v22) ? '\t' : '\n'))
                throw std::runtime_error("invalid project bus");
            if (v15 || v16 || v17 || v18 || v19 || v20 || v21 || v22) {
                int kind = 0;
                if (!(bs >> kind >> bus.gainDb >> bus.mute >> bus.outputBus))
                    throw std::runtime_error("invalid project bus state");
                bus.kind = busKindFromCode(kind);
            }
            bus.pluginSlots = readPluginSlots(f);
            if (v15 || v16 || v17 || v18 || v19 || v20 || v21 || v22) bus.sends = readSends(f, v16 || v17 || v18 || v19 || v20 || v21 || v22);
            if (v16 || v17 || v18 || v19 || v20 || v21 || v22) {
                if (!std::getline(f, line)) throw std::runtime_error("missing bus automation");
                AutomationMode unusedModeA = AutomationMode::Off;
                AutomationLane unusedA;
                readMixerAutomationLine(line, "BUSAUTO",
                                        bus.gainAutomationMode, bus.gainAutomationDb,
                                        bus.muteAutomationMode, bus.muteAutomation,
                                        unusedModeA, unusedA);
            }
            o.buses.push_back(std::move(bus));
        }
        if (v15 || v16 || v17 || v18 || v19 || v20 || v21 || v22) {
            if (!std::getline(f, line) || line != "MASTER") throw std::runtime_error("project missing MASTER");
            o.masterPluginSlots = readPluginSlots(f);
            if (v16 || v17 || v18 || v19 || v20 || v21 || v22) {
                if (!std::getline(f, line)) throw std::runtime_error("missing master automation");
                AutomationMode unusedModeA = AutomationMode::Off, unusedModeB = AutomationMode::Off;
                AutomationLane unusedA, unusedB;
                readMixerAutomationLine(line, "MASTERAUTO",
                                        o.masterFaderAutomationMode, o.masterFaderAutomationDb,
                                        unusedModeA, unusedA,
                                        unusedModeB, unusedB);
            }
        }
        if (!std::getline(f, line) || line != "END") throw std::runtime_error("project missing END");
        return o;
    }

    while(std::getline(f,line)) {
        if(line.empty()) continue;
        if(o.tracks.size() >= kMaxTracks) throw std::length_error("Silveton project track limit is 256");
        std::istringstream ss(line);
        ProjectTrack t;
        std::getline(ss,t.name,'\t');
        std::getline(ss,t.audioPath,'\t');
        if(!(ss>>t.gainDb>>t.pan>>t.mute)) throw std::runtime_error("project track");
        if(v2 || v3 || v4) {
            if(!(ss>>t.useDualStereoPan>>t.stereoLeftPan>>t.stereoRightPan)) throw std::runtime_error("project stereo pan state");
        }
        if(v4) {
            if(!(ss>>t.timelineStartSample>>t.sourceStartSample>>t.voiceEnabled>>t.voicePriority))
                throw std::runtime_error("project timeline/voice state");
        }
        o.tracks.push_back(std::move(t));
    }
    return o;
}
namespace {
template <typename T>
void recorderWriteLE(std::ofstream& out, T value) {
    out.write(reinterpret_cast<const char*>(&value), sizeof(T));
}
constexpr std::uint64_t recorderHeaderBytes = 80U;
static void createDirectoryCompat(const std::string& path) {
    if (path.empty() || path == "/" || path == ".") return;
#if defined(_WIN32)
    if (_mkdir(path.c_str()) != 0 && errno != EEXIST)
        throw std::runtime_error("cannot create recorder directory");
#else
    if (::mkdir(path.c_str(), 0775) != 0 && errno != EEXIST)
        throw std::runtime_error("cannot create recorder directory");
#endif
}

static void createParentDirectoriesCompat(const std::string& filePath) {
    const auto slash = filePath.find_last_of("/\\");
    if (slash == std::string::npos) return;
    const std::string parent = filePath.substr(0, slash);
    if (parent.empty()) return;

    std::string current;
    std::size_t i = 0U;
    if (parent[0] == '/') { current = "/"; i = 1U; }
#if defined(_WIN32)
    if (parent.size() >= 2U && parent[1] == ':') { current = parent.substr(0, 2U); i = 2U; }
#endif
    while (i <= parent.size()) {
        const auto next = parent.find_first_of("/\\", i);
        const auto end = next == std::string::npos ? parent.size() : next;
        if (end > i) {
            if (!current.empty() && current.back() != '/' && current.back() != '\\') current += '/';
            current.append(parent, i, end - i);
            createDirectoryCompat(current);
        }
        if (next == std::string::npos) break;
        i = next + 1U;
    }
}

static std::string recorderTempPath(std::uint64_t ticks, std::uint64_t id) {
    const char* env = std::getenv("TMPDIR");
#if defined(_WIN32)
    if (env == nullptr || *env == '\0') env = std::getenv("TEMP");
#endif
    std::string base = (env != nullptr && *env != '\0') ? std::string(env) : std::string("/tmp");
    if (!base.empty() && base.back() != '/' && base.back() != '\\') base += '/';
    return base + "silveton_recording_" + std::to_string(ticks) + "_" + std::to_string(id) + ".wav";
}

}

Recorder::~Recorder() { stop(); }

void Recorder::prepare(std::uint32_t channels,
                       std::uint32_t sampleRate,
                       std::uint32_t ringCapacityFrames) {
    if (recording() || writerThread_.joinable()) throw std::logic_error("cannot prepare recorder while active");
    if (channels == 0U) throw std::invalid_argument("recorder channels must be positive");
    if (sampleRate == 0U) throw std::invalid_argument("recorder sample rate must be positive");
    if (ringCapacityFrames < 2U) throw std::invalid_argument("recorder ring capacity is too small");

    const std::size_t channelCount = static_cast<std::size_t>(channels);
    const std::size_t frameCount = static_cast<std::size_t>(ringCapacityFrames);
    const std::size_t maxFloats = std::vector<float>().max_size();
    if (channelCount != 0U && frameCount > maxFloats / channelCount)
        throw std::length_error("recorder ring capacity is too large");

    ch_ = channels;
    sampleRate_ = sampleRate;
    ringCapacityFrames_ = ringCapacityFrames;
    ring_.assign(frameCount * channelCount, 0.0F);

    writeFrame_.store(0U, std::memory_order_relaxed);
    readFrame_.store(0U, std::memory_order_relaxed);
    framesAccepted_.store(0U, std::memory_order_relaxed);
    framesWritten_.store(0U, std::memory_order_relaxed);
    droppedFrames_.store(0U, std::memory_order_relaxed);
    activePushes_.store(0U, std::memory_order_relaxed);
    recording_.store(false, std::memory_order_relaxed);
    writerStop_.store(false, std::memory_order_relaxed);
    faulted_.store(false, std::memory_order_relaxed);
    overflowed_.store(false, std::memory_order_relaxed);
    writerError_.store(false, std::memory_order_relaxed);
    dataBytesWritten_ = 0U;
    path_.clear();
    captureCache_.resize(0U, 0U);
    captureCacheValid_ = false;
}

void Recorder::writePlaceholderHeader() {
    if (!out_) throw std::runtime_error("recorder output is not open");
    out_.seekp(0, std::ios::beg);

    out_.write("RIFF", 4);
    recorderWriteLE(out_, std::uint32_t{0U});
    out_.write("WAVE", 4);
    out_.write("JUNK", 4);
    recorderWriteLE(out_, std::uint32_t{28U});
    recorderWriteLE(out_, std::uint64_t{0U});
    recorderWriteLE(out_, std::uint64_t{0U});
    recorderWriteLE(out_, std::uint64_t{0U});
    recorderWriteLE(out_, std::uint32_t{0U});

    out_.write("fmt ", 4);
    recorderWriteLE(out_, std::uint32_t{16U});
    recorderWriteLE(out_, std::uint16_t{3U});

    const std::uint64_t blockAlign64 = static_cast<std::uint64_t>(ch_) * sizeof(float);
    if (ch_ > std::numeric_limits<std::uint16_t>::max() ||
        blockAlign64 > std::numeric_limits<std::uint16_t>::max())
        throw std::runtime_error("recorder channel count exceeds WAV format limit");

    recorderWriteLE(out_, static_cast<std::uint16_t>(ch_));
    recorderWriteLE(out_, sampleRate_);
    const auto blockAlign = static_cast<std::uint16_t>(blockAlign64);
    const std::uint64_t byteRate64 = static_cast<std::uint64_t>(sampleRate_) * blockAlign;
    if (byteRate64 > std::numeric_limits<std::uint32_t>::max())
        throw std::runtime_error("recorder WAV byte rate exceeds format limit");
    recorderWriteLE(out_, static_cast<std::uint32_t>(byteRate64));
    recorderWriteLE(out_, blockAlign);
    recorderWriteLE(out_, std::uint16_t{32U});
    out_.write("data", 4);
    recorderWriteLE(out_, std::uint32_t{0U});

    if (!out_ || static_cast<std::uint64_t>(out_.tellp()) != recorderHeaderBytes)
        throw std::runtime_error("recorder WAV header write failed");
}

void Recorder::start(const std::string& path) {
    if (ch_ == 0U || sampleRate_ == 0U || ring_.empty()) throw std::logic_error("recorder is not prepared");
    if (recording() || writerThread_.joinable() || out_.is_open()) throw std::logic_error("recorder is already active");
    if (path.empty()) throw std::invalid_argument("recorder output path is empty");

    createParentDirectoriesCompat(path);
    path_ = path;
    captureCacheValid_ = false;
    captureCache_.resize(0U, 0U);
    writeFrame_.store(0U, std::memory_order_relaxed);
    readFrame_.store(0U, std::memory_order_relaxed);
    framesAccepted_.store(0U, std::memory_order_relaxed);
    framesWritten_.store(0U, std::memory_order_relaxed);
    droppedFrames_.store(0U, std::memory_order_relaxed);
    activePushes_.store(0U, std::memory_order_relaxed);
    faulted_.store(false, std::memory_order_relaxed);
    overflowed_.store(false, std::memory_order_relaxed);
    writerError_.store(false, std::memory_order_relaxed);
    writerStop_.store(false, std::memory_order_relaxed);
    dataBytesWritten_ = 0U;

    out_.open(path_.c_str(), std::ios::binary | std::ios::trunc);
    if (!out_) throw std::runtime_error("cannot open recorder WAV for writing");
    try {
        writePlaceholderHeader();
        out_.flush();
        if (!out_) throw std::runtime_error("recorder WAV header flush failed");
        recording_.store(true, std::memory_order_release);
        writerThread_ = std::thread(&Recorder::writerLoop, this);
    } catch (...) {
        recording_.store(false, std::memory_order_release);
        writerStop_.store(true, std::memory_order_release);
        if (writerThread_.joinable()) writerThread_.join();
        out_.close();
        throw;
    }
}

void Recorder::start() {
    static std::atomic<std::uint64_t> sequence {0U};
    const auto id = sequence.fetch_add(1U, std::memory_order_relaxed);
    const auto ticks = static_cast<std::uint64_t>(std::chrono::steady_clock::now().time_since_epoch().count());
    start(recorderTempPath(ticks, id));
}

void Recorder::markFault(bool writerError) noexcept {
    faulted_.store(true, std::memory_order_release);
    if (writerError) writerError_.store(true, std::memory_order_release);
}

bool Recorder::push(const float* const* in,
                    std::uint32_t channels,
                    std::uint32_t frames) noexcept {
    if (!recording_.load(std::memory_order_acquire)) return false;

    activePushes_.fetch_add(1U, std::memory_order_acq_rel);
    if (!recording_.load(std::memory_order_acquire)) {
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return false;
    }

    if (frames == 0U) {
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return true;
    }
    if (in == nullptr || channels < ch_) {
        droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
        markFault(false);
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return false;
    }
    for (std::uint32_t c = 0U; c < ch_; ++c) {
        if (in[c] == nullptr) {
            droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
            markFault(false);
            activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
            return false;
        }
    }

    const std::uint64_t write = writeFrame_.load(std::memory_order_relaxed);
    const std::uint64_t read = readFrame_.load(std::memory_order_acquire);
    const std::uint64_t used = write - read;
    const std::uint64_t freeFrames = used < ringCapacityFrames_ ? ringCapacityFrames_ - used : 0U;
    if (static_cast<std::uint64_t>(frames) > freeFrames) {
        droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
        overflowed_.store(true, std::memory_order_release);
        markFault(false);
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return false;
    }

    for (std::uint32_t f = 0U; f < frames; ++f) {
        const std::uint64_t ringFrame = (write + f) % ringCapacityFrames_;
        float* dst = ring_.data() + static_cast<std::size_t>(ringFrame) * ch_;
        for (std::uint32_t c = 0U; c < ch_; ++c) dst[c] = in[c][f];
    }

    writeFrame_.store(write + frames, std::memory_order_release);
    framesAccepted_.fetch_add(frames, std::memory_order_relaxed);
    activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
    return true;
}

void Recorder::writerLoop() noexcept {
    for (;;) {
        const std::uint64_t read = readFrame_.load(std::memory_order_relaxed);
        const std::uint64_t write = writeFrame_.load(std::memory_order_acquire);
        const std::uint64_t available = write - read;

        if (available == 0U) {
            if (writerStop_.load(std::memory_order_acquire)) break;
            std::this_thread::sleep_for(std::chrono::microseconds(500));
            continue;
        }

        const std::uint64_t ringFrame = read % ringCapacityFrames_;
        const std::uint64_t contiguous = std::min<std::uint64_t>(available, ringCapacityFrames_ - ringFrame);
        const std::uint64_t samples = contiguous * ch_;
        const std::uint64_t bytes = samples * sizeof(float);

        out_.write(reinterpret_cast<const char*>(ring_.data() + static_cast<std::size_t>(ringFrame) * ch_),
                   static_cast<std::streamsize>(bytes));
        if (!out_) {
            markFault(true);
            recording_.store(false, std::memory_order_release);
            writerStop_.store(true, std::memory_order_release);
            break;
        }

        dataBytesWritten_ += bytes;
        framesWritten_.fetch_add(contiguous, std::memory_order_relaxed);
        readFrame_.store(read + contiguous, std::memory_order_release);
    }
}

void Recorder::finalizeHeader() {
    if (!out_.is_open()) return;
    out_.flush();
    if (!out_) throw std::runtime_error("recorder WAV data flush failed");

    const std::uint64_t frames = framesWritten_.load(std::memory_order_acquire);
    const std::uint64_t riffSize64 = (recorderHeaderBytes - 8U) + dataBytesWritten_;
    const bool needsRf64 = riffSize64 > std::numeric_limits<std::uint32_t>::max() ||
                           dataBytesWritten_ > std::numeric_limits<std::uint32_t>::max();

    out_.seekp(0, std::ios::beg);
    if (needsRf64) {
        out_.write("RF64", 4);
        recorderWriteLE(out_, std::uint32_t{0xFFFFFFFFU});
        out_.write("WAVE", 4);
        out_.write("ds64", 4);
        recorderWriteLE(out_, std::uint32_t{28U});
        recorderWriteLE(out_, riffSize64);
        recorderWriteLE(out_, dataBytesWritten_);
        recorderWriteLE(out_, frames);
        recorderWriteLE(out_, std::uint32_t{0U});
        out_.seekp(76, std::ios::beg);
        recorderWriteLE(out_, std::uint32_t{0xFFFFFFFFU});
    } else {
        out_.write("RIFF", 4);
        recorderWriteLE(out_, static_cast<std::uint32_t>(riffSize64));
        out_.write("WAVE", 4);
        out_.write("JUNK", 4);
        out_.seekp(76, std::ios::beg);
        recorderWriteLE(out_, static_cast<std::uint32_t>(dataBytesWritten_));
    }
    out_.flush();
    if (!out_) throw std::runtime_error("recorder WAV finalization failed");
}

void Recorder::stop() noexcept {
    recording_.store(false, std::memory_order_release);
    while (activePushes_.load(std::memory_order_acquire) != 0U) std::this_thread::yield();

    writerStop_.store(true, std::memory_order_release);
    if (writerThread_.joinable()) writerThread_.join();

    if (out_.is_open()) {
        try {
            finalizeHeader();
        } catch (...) {
            markFault(true);
        }
        out_.close();
    }
}

RecorderStatus Recorder::status() const noexcept {
    RecorderStatus s;
    s.recording = recording_.load(std::memory_order_acquire);
    s.faulted = faulted_.load(std::memory_order_acquire);
    s.overflowed = overflowed_.load(std::memory_order_acquire);
    s.writerError = writerError_.load(std::memory_order_acquire);
    s.framesAccepted = framesAccepted_.load(std::memory_order_acquire);
    s.framesWritten = framesWritten_.load(std::memory_order_acquire);
    s.droppedFrames = droppedFrames_.load(std::memory_order_acquire);
    return s;
}

const AudioBuffer& Recorder::captured() const {
    if (recording()) throw std::logic_error("cannot load captured audio while recorder is running");
    if (path_.empty()) throw std::logic_error("recorder has no take");
    if (!captureCacheValid_) {
        auto wav = WavFile::read(path_);
        if (wav.sampleRate != sampleRate_) throw std::runtime_error("recorded WAV sample rate mismatch");
        if (wav.audio.channels() != ch_) throw std::runtime_error("recorded WAV channel count mismatch");
        captureCache_ = std::move(wav.audio);
        captureCacheValid_ = true;
    }
    return captureCache_;
}

}
