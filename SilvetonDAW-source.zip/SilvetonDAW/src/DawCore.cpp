#include "silveton/DawCore.h"
#include <queue>
#include <sstream>
#include <chrono>
#include <limits>
#include <thread>
#include <cerrno>
#include <cstdlib>
#include <complex>
#include <vector>
#if defined(_WIN32)
#include <direct.h>
#else
#include <sys/stat.h>
#endif
namespace silveton {
void AutomationLane::add(std::int64_t s,float v){p_.push_back({s,v});std::sort(p_.begin(),p_.end(),[](auto&a,auto&b){return a.sample<b.sample;});}
float AutomationLane::valueAt(std::int64_t s,float f)const noexcept{if(p_.empty())return f;if(s<=p_.front().sample)return p_.front().value;if(s>=p_.back().sample)return p_.back().value;auto it=std::upper_bound(p_.begin(),p_.end(),s,[](auto x,const auto&p){return x<p.sample;});auto&a=*(it-1);auto&b=*it;double t=double(s-a.sample)/double(b.sample-a.sample);return float(a.value+(b.value-a.value)*t);}
void MidiTrack::add(MidiEvent e){e_.push_back(e);std::sort(e_.begin(),e_.end(),[](auto&a,auto&b){return a.sample<b.sample;});}
std::vector<MidiEvent> MidiTrack::range(std::int64_t a,std::int64_t b)const{std::vector<MidiEvent>o;for(auto&e:e_)if(e.sample>=a&&e.sample<b)o.push_back(e);return o;}
AudioBuffer AudioEditor::trim(const AudioBuffer&x,std::uint64_t s,std::uint64_t n){if(s>x.frames())throw std::out_of_range("trim");n=std::min<std::uint64_t>(n,x.frames()-s);AudioBuffer o(x.channels(),n);for(size_t c=0;c<x.channels();++c)std::copy_n(x.channelData(c)+s,n,o.channelData(c));return o;}
AudioBuffer AudioEditor::reverse(const AudioBuffer&x){AudioBuffer o(x.channels(),x.frames());for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<x.frames();++i)o.channelData(c)[i]=x.channelData(c)[x.frames()-1-i];return o;}
void AudioEditor::fadeIn(AudioBuffer&x,std::uint64_t n){n=std::min<std::uint64_t>(n,x.frames());for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<n;++i)x.channelData(c)[i]*=n<=1?1.f:float(i)/float(n-1);}
void AudioEditor::fadeOut(AudioBuffer&x,std::uint64_t n){n=std::min<std::uint64_t>(n,x.frames());for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<n;++i)x.channelData(c)[x.frames()-n+i]*=n<=1?0.f:1.f-float(i)/float(n-1);}
AudioBuffer AudioEditor::resampleLinear(const AudioBuffer&x,double ratio){if(!(ratio>0)||!std::isfinite(ratio))throw std::invalid_argument("ratio");size_t nf=std::max<size_t>(1,size_t(std::llround(x.frames()*ratio)));AudioBuffer o(x.channels(),nf);for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<nf;++i){double p=double(i)/ratio;size_t a=std::min<size_t>(size_t(p),x.frames()-1),b=std::min(a+1,x.frames()-1);double t=p-a;o.channelData(c)[i]=float(x.channelData(c)[a]*(1-t)+x.channelData(c)[b]*t);}return o;}
namespace {
constexpr double kPi = 3.141592653589793238462643383279502884;

void fft(std::vector<std::complex<double>>& data, bool inverse) {
    const std::size_t n = data.size();
    for (std::size_t i = 1U, j = 0U; i < n; ++i) {
        std::size_t bit = n >> 1U;
        for (; (j & bit) != 0U; bit >>= 1U) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(data[i], data[j]);
    }

    for (std::size_t len = 2U; len <= n; len <<= 1U) {
        const double angle = (inverse ? 2.0 : -2.0) * kPi / static_cast<double>(len);
        const std::complex<double> wlen(std::cos(angle), std::sin(angle));
        for (std::size_t i = 0U; i < n; i += len) {
            std::complex<double> w(1.0, 0.0);
            const std::size_t half = len >> 1U;
            for (std::size_t j = 0U; j < half; ++j) {
                const std::complex<double> u = data[i + j];
                const std::complex<double> v = data[i + j + half] * w;
                data[i + j] = u + v;
                data[i + j + half] = u - v;
                w *= wlen;
            }
        }
    }

    if (inverse) {
        const double scale = 1.0 / static_cast<double>(n);
        for (auto& value : data) value *= scale;
    }
}

double wrapPhase(double phase) noexcept {
    while (phase > kPi) phase -= 2.0 * kPi;
    while (phase < -kPi) phase += 2.0 * kPi;
    return phase;
}

std::size_t phaseVocoderWindowFor(std::size_t frames) noexcept {
    if (frames >= 2048U) return 1024U;
    if (frames >= 1024U) return 512U;
    if (frames >= 512U) return 256U;
    if (frames >= 256U) return 128U;
    return 64U;
}
}

AudioBuffer AudioEditor::timeStretch(const AudioBuffer& x, double ratio) {
    if (!(ratio > 0.0) || !std::isfinite(ratio)) throw std::invalid_argument("ratio");
    if (x.channels() == 0U || x.frames() == 0U) return AudioBuffer(x.channels(), 0U);
    if (x.frames() < 64U) return resampleLinear(x, ratio);

    const std::size_t fftSize = phaseVocoderWindowFor(x.frames());
    const std::size_t analysisHop = fftSize / 4U;
    const std::size_t synthesisHop = std::max<std::size_t>(1U,
        static_cast<std::size_t>(std::llround(static_cast<double>(analysisHop) * ratio)));
    const std::size_t targetFrames = std::max<std::size_t>(1U,
        static_cast<std::size_t>(std::llround(static_cast<double>(x.frames()) * ratio)));
    const std::size_t workFrames = targetFrames + fftSize * 2U;

    AudioBuffer output(x.channels(), workFrames);
    std::vector<double> normalization(workFrames, 0.0);
    std::vector<double> window(fftSize, 0.0);
    for (std::size_t i = 0U; i < fftSize; ++i) {
        window[i] = 0.5 - 0.5 * std::cos((2.0 * kPi * static_cast<double>(i)) /
                                        static_cast<double>(fftSize - 1U));
    }

    for (std::size_t channel = 0U; channel < x.channels(); ++channel) {
        std::vector<std::complex<double>> spectrum(fftSize);
        std::vector<double> previousPhase(fftSize / 2U + 1U, 0.0);
        std::vector<double> synthesisPhase(fftSize / 2U + 1U, 0.0);
        bool firstFrame = true;
        std::size_t synthesisPosition = 0U;

        for (std::size_t analysisPosition = 0U;
             analysisPosition < x.frames() && synthesisPosition < workFrames;
             analysisPosition += analysisHop, synthesisPosition += synthesisHop) {
            for (std::size_t i = 0U; i < fftSize; ++i) {
                const std::size_t sourceIndex = analysisPosition + i;
                const double sample = sourceIndex < x.frames()
                    ? static_cast<double>(x.sample(channel, sourceIndex))
                    : 0.0;
                spectrum[i] = std::complex<double>(sample * window[i], 0.0);
            }

            fft(spectrum, false);
            const std::size_t bins = fftSize / 2U + 1U;
            for (std::size_t bin = 0U; bin < bins; ++bin) {
                const double magnitude = std::abs(spectrum[bin]);
                const double phase = std::arg(spectrum[bin]);
                const double expectedAdvance = 2.0 * kPi * static_cast<double>(bin) *
                                               static_cast<double>(analysisHop) /
                                               static_cast<double>(fftSize);
                if (firstFrame) {
                    synthesisPhase[bin] = phase;
                } else {
                    const double deviation = wrapPhase(phase - previousPhase[bin] - expectedAdvance);
                    const double trueAdvance = expectedAdvance + deviation;
                    synthesisPhase[bin] += trueAdvance *
                        (static_cast<double>(synthesisHop) / static_cast<double>(analysisHop));
                }
                previousPhase[bin] = phase;
                spectrum[bin] = std::polar(magnitude, synthesisPhase[bin]);
            }

            for (std::size_t bin = 1U; bin < fftSize / 2U; ++bin) {
                spectrum[fftSize - bin] = std::conj(spectrum[bin]);
            }
            spectrum[0] = std::complex<double>(spectrum[0].real(), 0.0);
            spectrum[fftSize / 2U] = std::complex<double>(spectrum[fftSize / 2U].real(), 0.0);
            fft(spectrum, true);

            const std::size_t writable = std::min<std::size_t>(fftSize, workFrames - synthesisPosition);
            for (std::size_t i = 0U; i < writable; ++i) {
                const double w = window[i];
                output.sample(channel, synthesisPosition + i) +=
                    static_cast<float>(spectrum[i].real() * w);
                if (channel == 0U) normalization[synthesisPosition + i] += w * w;
            }
            firstFrame = false;
        }
    }

    for (std::size_t frame = 0U; frame < targetFrames; ++frame) {
        const double norm = normalization[frame];
        if (norm <= 1.0e-12) continue;
        const float inverse = static_cast<float>(1.0 / norm);
        for (std::size_t channel = 0U; channel < output.channels(); ++channel) {
            output.sample(channel, frame) *= inverse;
        }
    }
    return trim(output, 0U, targetFrames);
}

AudioBuffer AudioEditor::pitchShift(const AudioBuffer& x, double semitones) {
    if (!std::isfinite(semitones)) throw std::invalid_argument("semitones");
    const double pitchRatio = std::pow(2.0, semitones / 12.0);
    auto resampled = resampleLinear(x, 1.0 / pitchRatio);
    auto shifted = timeStretch(resampled, pitchRatio);

    // Keep pitch-shift duration exactly equal to the source duration.
    if (shifted.frames() == x.frames()) return shifted;
    if (shifted.frames() > x.frames()) return trim(shifted, 0U, x.frames());

    AudioBuffer result(x.channels(), x.frames());
    for (std::size_t channel = 0U; channel < x.channels(); ++channel) {
        std::copy_n(shifted.channelData(channel), shifted.frames(), result.channelData(channel));
    }
    return result;
}
void RoutingGraph::setNodeCount(size_t n){n_=n;r_.clear();}
void RoutingGraph::addRoute(Route r){if(r.from>=n_||r.to>=n_||r.from==r.to)throw std::invalid_argument("route");r_.push_back(r);(void)topologicalOrder();}
std::vector<size_t> RoutingGraph::topologicalOrder()const{std::vector<size_t>d(n_);for(auto&r:r_)++d[r.to];std::queue<size_t>q;for(size_t i=0;i<n_;++i)if(!d[i])q.push(i);std::vector<size_t>o;while(!q.empty()){auto u=q.front();q.pop();o.push_back(u);for(auto&r:r_)if(r.from==u&&!--d[r.to])q.push(r.to);}if(o.size()!=n_)throw std::logic_error("routing cycle");return o;}
void DelayCompensator::setLatencies(const std::vector<uint32_t>&l){max_=0;for(auto x:l)max_=std::max(max_,x);d_.resize(l.size());for(size_t i=0;i<l.size();++i)d_[i]=max_-l[i];}
uint32_t DelayCompensator::delayFor(size_t i)const{if(i>=d_.size())throw std::out_of_range("pdc");return d_[i];}
static std::string esc(std::string s){for(auto&c:s)if(c=='\t'||c=='\n'||c=='\r')c=' ';return s;}

static int panDepthCode(PanDepth d) noexcept {
    switch (d) {
        case PanDepth::Minus2_5dB: return 25;
        case PanDepth::Minus3dB: return 30;
        case PanDepth::Minus4_5dB: return 45;
        case PanDepth::Minus6dB: return 60;
    }
    return 30;
}

static PanDepth panDepthFromCode(int code) {
    switch (code) {
        case 25: return PanDepth::Minus2_5dB;
        case 30: return PanDepth::Minus3dB;
        case 45: return PanDepth::Minus4_5dB;
        case 60: return PanDepth::Minus6dB;
        default: throw std::runtime_error("unsupported pan depth");
    }
}

static int automationModeCode(AutomationMode mode) noexcept {
    return static_cast<int>(mode);
}

static AutomationMode automationModeFromCode(int code) {
    if (code < static_cast<int>(AutomationMode::Off) || code > static_cast<int>(AutomationMode::Latch))
        throw std::runtime_error("unsupported automation mode");
    return static_cast<AutomationMode>(code);
}

static char hexDigit(unsigned value) noexcept { return value < 10U ? static_cast<char>('0' + value) : static_cast<char>('A' + (value - 10U)); }
static int hexValue(char c) noexcept {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return 10 + c - 'A';
    if (c >= 'a' && c <= 'f') return 10 + c - 'a';
    return -1;
}

static std::string encodeBlob(const std::vector<std::uint8_t>& data) {
    std::string out;
    out.resize(data.size() * 2U);
    for (std::size_t i = 0U; i < data.size(); ++i) {
        out[i * 2U] = hexDigit(data[i] >> 4U);
        out[i * 2U + 1U] = hexDigit(data[i] & 0x0FU);
    }
    return out;
}

static std::vector<std::uint8_t> decodeBlob(const std::string& text) {
    if ((text.size() & 1U) != 0U) throw std::runtime_error("invalid project blob");
    std::vector<std::uint8_t> out(text.size() / 2U);
    for (std::size_t i = 0U; i < out.size(); ++i) {
        const int hi = hexValue(text[i * 2U]);
        const int lo = hexValue(text[i * 2U + 1U]);
        if (hi < 0 || lo < 0) throw std::runtime_error("invalid project blob");
        out[i] = static_cast<std::uint8_t>((hi << 4) | lo);
    }
    return out;
}

static std::string encodeDestinations(const std::vector<int>& values) {
    std::ostringstream ss;
    for (std::size_t i = 0U; i < values.size(); ++i) {
        if (i != 0U) ss << ',';
        ss << values[i];
    }
    return ss.str();
}

static std::vector<int> decodeDestinations(const std::string& text, std::size_t expected) {
    std::vector<int> out;
    if (!text.empty()) {
        std::istringstream ss(text);
        std::string token;
        while (std::getline(ss, token, ',')) {
            if (token.empty()) throw std::runtime_error("invalid project extra output route");
            std::istringstream value(token);
            int v = 0;
            if (!(value >> v) || !value.eof()) throw std::runtime_error("invalid project extra output route");
            out.push_back(v);
        }
    }
    if (out.size() != expected) throw std::runtime_error("project extra output count mismatch");
    return out;
}

static std::string encodeAutomationPoints(const ParameterAutomationLane& lane) {
    std::ostringstream ss;
    ss.precision(17);
    const auto& points = lane.points();
    for (std::size_t i = 0U; i < points.size(); ++i) {
        if (i != 0U) ss << ';';
        ss << points[i].sample << ':' << points[i].normalized;
    }
    return ss.str();
}

static void decodeAutomationPoints(const std::string& text,
                                   std::size_t expected,
                                   ParameterAutomationLane& lane) {
    std::size_t count = 0U;
    if (!text.empty()) {
        std::istringstream ss(text);
        std::string token;
        while (std::getline(ss, token, ';')) {
            const auto colon = token.find(':');
            if (colon == std::string::npos) throw std::runtime_error("invalid automation point");
            std::int64_t sample = 0;
            double value = 0.0;
            std::istringstream a(token.substr(0U, colon));
            std::istringstream b(token.substr(colon + 1U));
            if (!(a >> sample) || !a.eof() || !(b >> value) || !b.eof()) throw std::runtime_error("invalid automation point");
            lane.write(sample, value);
            ++count;
        }
    }
    if (count != expected) throw std::runtime_error("project automation point count mismatch");
}

static void writePluginSlots(std::ofstream& f, const std::vector<ProjectPluginSlot>& slots) {
    f << "SLOTS\t" << slots.size() << '\n';
    for (const auto& slot : slots) {
        f << "SLOT\t" << esc(slot.modulePath) << '\t' << esc(slot.classId) << '\t'
          << slot.enabled << '\t' << slot.latencySnapshot << '\t' << slot.sidechainSourceNode << '\t'
          << slot.midiInputPort << '\t' << slot.extraOutputDestinations.size() << '\t'
          << encodeDestinations(slot.extraOutputDestinations) << '\t'
          << encodeBlob(slot.componentState) << '\t' << encodeBlob(slot.controllerState) << '\t'
          << slot.automation.size() << '\n';
        for (const auto& lane : slot.automation) {
            f << "AUTO\t" << lane.parameterId << '\t' << automationModeCode(lane.mode) << '\t'
              << lane.lane.points().size() << '\t' << encodeAutomationPoints(lane.lane) << '\n';
        }
    }
}

static std::vector<ProjectPluginSlot> readPluginSlots(std::ifstream& f) {
    std::string line;
    if (!std::getline(f, line)) throw std::runtime_error("missing project slots section");
    std::istringstream header(line);
    std::string tag;
    std::size_t slotCount = 0U;
    if (!std::getline(header, tag, '\t') || tag != "SLOTS" || !(header >> slotCount))
        throw std::runtime_error("invalid project slots section");
    std::vector<ProjectPluginSlot> slots;
    slots.reserve(slotCount);
    for (std::size_t si = 0U; si < slotCount; ++si) {
        if (!std::getline(f, line)) throw std::runtime_error("missing project slot");
        std::istringstream ss(line);
        std::string field;
        if (!std::getline(ss, field, '\t') || field != "SLOT") throw std::runtime_error("invalid project slot");
        ProjectPluginSlot slot;
        std::string enabled, latency, side, midi, extraCountText, extraText, component, controller, automationCountText;
        if (!std::getline(ss, slot.modulePath, '\t') || !std::getline(ss, slot.classId, '\t') ||
            !std::getline(ss, enabled, '\t') || !std::getline(ss, latency, '\t') ||
            !std::getline(ss, side, '\t') || !std::getline(ss, midi, '\t') ||
            !std::getline(ss, extraCountText, '\t') || !std::getline(ss, extraText, '\t') ||
            !std::getline(ss, component, '\t') || !std::getline(ss, controller, '\t') ||
            !std::getline(ss, automationCountText)) throw std::runtime_error("invalid project slot fields");
        std::size_t extraCount = 0U, automationCount = 0U;
        {
            std::istringstream a(enabled), b(latency), c(side), d(midi), e(extraCountText), g(automationCountText);
            int enabledInt = 0;
            if (!(a >> enabledInt) || !(b >> slot.latencySnapshot) || !(c >> slot.sidechainSourceNode) ||
                !(d >> slot.midiInputPort) || !(e >> extraCount) || !(g >> automationCount))
                throw std::runtime_error("invalid project slot numbers");
            slot.enabled = enabledInt != 0;
        }
        slot.extraOutputDestinations = decodeDestinations(extraText, extraCount);
        slot.componentState = decodeBlob(component);
        slot.controllerState = decodeBlob(controller);
        slot.automation.reserve(automationCount);
        for (std::size_t ai = 0U; ai < automationCount; ++ai) {
            if (!std::getline(f, line)) throw std::runtime_error("missing project automation lane");
            std::istringstream as(line);
            std::string laneTag, param, mode, pointCountText, points;
            if (!std::getline(as, laneTag, '\t') || laneTag != "AUTO" ||
                !std::getline(as, param, '\t') || !std::getline(as, mode, '\t') ||
                !std::getline(as, pointCountText, '\t') || !std::getline(as, points))
                throw std::runtime_error("invalid project automation lane");
            ProjectPluginAutomationLane lane;
            int modeCode = 0;
            std::size_t pointCount = 0U;
            std::istringstream p(param), m(mode), pc(pointCountText);
            if (!(p >> lane.parameterId) || !(m >> modeCode) || !(pc >> pointCount))
                throw std::runtime_error("invalid project automation lane numbers");
            lane.mode = automationModeFromCode(modeCode);
            decodeAutomationPoints(points, pointCount, lane.lane);
            slot.automation.push_back(std::move(lane));
        }
        slots.push_back(std::move(slot));
    }
    return slots;
}

void Project::addTrack(ProjectTrack track) {
    if (tracks.size() >= kMaxTracks) throw std::length_error("Silveton project track limit is 256");
    tracks.push_back(std::move(track));
}

void Project::save(const std::string&p) const {
    if (tracks.size() > kMaxTracks) throw std::length_error("Silveton project track limit is 256");
    std::ofstream f(p.c_str());
    if(!f) throw std::runtime_error("project write");
    f << "SILVETON_PROJECT_V14\n" << sampleRate << '\t' << tempo << '\t' << panDepthCode(panDepth) << '\t' << masterFaderDb << '\n';
    f << "TRACKS\t" << tracks.size() << '\n';
    for (const auto& t : tracks) {
        f << "TRACK\t" << esc(t.name) << '\t' << esc(t.audioPath) << '\t' << t.gainDb << '\t' << t.pan << '\t' << t.mute
          << '\t' << t.useDualStereoPan << '\t' << t.stereoLeftPan << '\t' << t.stereoRightPan
          << '\t' << t.timelineStartSample << '\t' << t.sourceStartSample
          << '\t' << t.voiceEnabled << '\t' << t.voicePriority << '\n';
        writePluginSlots(f, t.pluginSlots);
    }
    f << "BUSES\t" << buses.size() << '\n';
    for (const auto& bus : buses) {
        f << "BUS\t" << esc(bus.name) << '\n';
        writePluginSlots(f, bus.pluginSlots);
    }
    f << "END\n";
    if(!f) throw std::runtime_error("project write failed");
}

Project Project::load(const std::string&p) {
    std::ifstream f(p.c_str());
    std::string line;
    if(!std::getline(f,line)) throw std::runtime_error("project format");
    const bool v1 = line=="SILVETON_PROJECT_V1";
    const bool v2 = line=="SILVETON_PROJECT_V2";
    const bool v3 = line=="SILVETON_PROJECT_V3";
    const bool v4 = line=="SILVETON_PROJECT_V4";
    const bool v14 = line=="SILVETON_PROJECT_V14";
    if(!v1 && !v2 && !v3 && !v4 && !v14) throw std::runtime_error("project format");

    Project o;
    if(!std::getline(f,line)) throw std::runtime_error("project header");
    {
        std::istringstream ss(line);
        if(v1) {
            if(!(ss>>o.sampleRate>>o.tempo)) throw std::runtime_error("project header");
            o.panDepth=PanDepth::Minus3dB;
            o.masterFaderDb=0.0F;
        } else if(v2) {
            int pd=30;
            if(!(ss>>o.sampleRate>>o.tempo>>pd)) throw std::runtime_error("project header");
            o.panDepth=panDepthFromCode(pd);
            o.masterFaderDb=0.0F;
        } else {
            int pd=30;
            if(!(ss>>o.sampleRate>>o.tempo>>pd>>o.masterFaderDb)) throw std::runtime_error("project header");
            o.panDepth=panDepthFromCode(pd);
        }
    }

    if (v14) {
        if (!std::getline(f, line)) throw std::runtime_error("missing project tracks section");
        std::istringstream th(line);
        std::string tag;
        std::size_t trackCount = 0U;
        if (!std::getline(th, tag, '\t') || tag != "TRACKS" || !(th >> trackCount) || trackCount > kMaxTracks)
            throw std::runtime_error("invalid project tracks section");
        o.tracks.reserve(trackCount);
        for (std::size_t ti = 0U; ti < trackCount; ++ti) {
            if (!std::getline(f, line)) throw std::runtime_error("missing project track");
            std::istringstream ss(line);
            std::string trackTag;
            ProjectTrack t;
            if (!std::getline(ss, trackTag, '\t') || trackTag != "TRACK" ||
                !std::getline(ss, t.name, '\t') || !std::getline(ss, t.audioPath, '\t') ||
                !(ss >> t.gainDb >> t.pan >> t.mute >> t.useDualStereoPan >> t.stereoLeftPan >> t.stereoRightPan
                     >> t.timelineStartSample >> t.sourceStartSample >> t.voiceEnabled >> t.voicePriority))
                throw std::runtime_error("project track");
            t.pluginSlots = readPluginSlots(f);
            o.tracks.push_back(std::move(t));
        }
        if (!std::getline(f, line)) throw std::runtime_error("missing project buses section");
        std::istringstream bh(line);
        std::string busTag;
        std::size_t busCount = 0U;
        if (!std::getline(bh, busTag, '\t') || busTag != "BUSES" || !(bh >> busCount))
            throw std::runtime_error("invalid project buses section");
        o.buses.reserve(busCount);
        for (std::size_t bi = 0U; bi < busCount; ++bi) {
            if (!std::getline(f, line)) throw std::runtime_error("missing project bus");
            std::istringstream bs(line);
            std::string tagText;
            ProjectBus bus;
            if (!std::getline(bs, tagText, '\t') || tagText != "BUS" || !std::getline(bs, bus.name))
                throw std::runtime_error("invalid project bus");
            bus.pluginSlots = readPluginSlots(f);
            o.buses.push_back(std::move(bus));
        }
        if (!std::getline(f, line) || line != "END") throw std::runtime_error("project missing END");
        return o;
    }

    while(std::getline(f,line)) {
        if(line.empty()) continue;
        if(o.tracks.size() >= kMaxTracks) throw std::length_error("Silveton project track limit is 256");
        std::istringstream ss(line);
        ProjectTrack t;
        std::getline(ss,t.name,'\t');
        std::getline(ss,t.audioPath,'\t');
        if(!(ss>>t.gainDb>>t.pan>>t.mute)) throw std::runtime_error("project track");
        if(v2 || v3 || v4) {
            if(!(ss>>t.useDualStereoPan>>t.stereoLeftPan>>t.stereoRightPan)) throw std::runtime_error("project stereo pan state");
        }
        if(v4) {
            if(!(ss>>t.timelineStartSample>>t.sourceStartSample>>t.voiceEnabled>>t.voicePriority))
                throw std::runtime_error("project timeline/voice state");
        }
        o.tracks.push_back(std::move(t));
    }
    return o;
}
namespace {
template <typename T>
void recorderWriteLE(std::ofstream& out, T value) {
    out.write(reinterpret_cast<const char*>(&value), sizeof(T));
}
constexpr std::uint64_t recorderHeaderBytes = 80U;
static void createDirectoryCompat(const std::string& path) {
    if (path.empty() || path == "/" || path == ".") return;
#if defined(_WIN32)
    if (_mkdir(path.c_str()) != 0 && errno != EEXIST)
        throw std::runtime_error("cannot create recorder directory");
#else
    if (::mkdir(path.c_str(), 0775) != 0 && errno != EEXIST)
        throw std::runtime_error("cannot create recorder directory");
#endif
}

static void createParentDirectoriesCompat(const std::string& filePath) {
    const auto slash = filePath.find_last_of("/\\");
    if (slash == std::string::npos) return;
    const std::string parent = filePath.substr(0, slash);
    if (parent.empty()) return;

    std::string current;
    std::size_t i = 0U;
    if (parent[0] == '/') { current = "/"; i = 1U; }
#if defined(_WIN32)
    if (parent.size() >= 2U && parent[1] == ':') { current = parent.substr(0, 2U); i = 2U; }
#endif
    while (i <= parent.size()) {
        const auto next = parent.find_first_of("/\\", i);
        const auto end = next == std::string::npos ? parent.size() : next;
        if (end > i) {
            if (!current.empty() && current.back() != '/' && current.back() != '\\') current += '/';
            current.append(parent, i, end - i);
            createDirectoryCompat(current);
        }
        if (next == std::string::npos) break;
        i = next + 1U;
    }
}

static std::string recorderTempPath(std::uint64_t ticks, std::uint64_t id) {
    const char* env = std::getenv("TMPDIR");
#if defined(_WIN32)
    if (env == nullptr || *env == '\0') env = std::getenv("TEMP");
#endif
    std::string base = (env != nullptr && *env != '\0') ? std::string(env) : std::string("/tmp");
    if (!base.empty() && base.back() != '/' && base.back() != '\\') base += '/';
    return base + "silveton_recording_" + std::to_string(ticks) + "_" + std::to_string(id) + ".wav";
}

}

Recorder::~Recorder() { stop(); }

void Recorder::prepare(std::uint32_t channels,
                       std::uint32_t sampleRate,
                       std::uint32_t ringCapacityFrames) {
    if (recording() || writerThread_.joinable()) throw std::logic_error("cannot prepare recorder while active");
    if (channels == 0U) throw std::invalid_argument("recorder channels must be positive");
    if (sampleRate == 0U) throw std::invalid_argument("recorder sample rate must be positive");
    if (ringCapacityFrames < 2U) throw std::invalid_argument("recorder ring capacity is too small");

    const std::size_t channelCount = static_cast<std::size_t>(channels);
    const std::size_t frameCount = static_cast<std::size_t>(ringCapacityFrames);
    const std::size_t maxFloats = std::vector<float>().max_size();
    if (channelCount != 0U && frameCount > maxFloats / channelCount)
        throw std::length_error("recorder ring capacity is too large");

    ch_ = channels;
    sampleRate_ = sampleRate;
    ringCapacityFrames_ = ringCapacityFrames;
    ring_.assign(frameCount * channelCount, 0.0F);

    writeFrame_.store(0U, std::memory_order_relaxed);
    readFrame_.store(0U, std::memory_order_relaxed);
    framesAccepted_.store(0U, std::memory_order_relaxed);
    framesWritten_.store(0U, std::memory_order_relaxed);
    droppedFrames_.store(0U, std::memory_order_relaxed);
    activePushes_.store(0U, std::memory_order_relaxed);
    recording_.store(false, std::memory_order_relaxed);
    writerStop_.store(false, std::memory_order_relaxed);
    faulted_.store(false, std::memory_order_relaxed);
    overflowed_.store(false, std::memory_order_relaxed);
    writerError_.store(false, std::memory_order_relaxed);
    dataBytesWritten_ = 0U;
    path_.clear();
    captureCache_.resize(0U, 0U);
    captureCacheValid_ = false;
}

void Recorder::writePlaceholderHeader() {
    if (!out_) throw std::runtime_error("recorder output is not open");
    out_.seekp(0, std::ios::beg);

    out_.write("RIFF", 4);
    recorderWriteLE(out_, std::uint32_t{0U});
    out_.write("WAVE", 4);
    out_.write("JUNK", 4);
    recorderWriteLE(out_, std::uint32_t{28U});
    recorderWriteLE(out_, std::uint64_t{0U});
    recorderWriteLE(out_, std::uint64_t{0U});
    recorderWriteLE(out_, std::uint64_t{0U});
    recorderWriteLE(out_, std::uint32_t{0U});

    out_.write("fmt ", 4);
    recorderWriteLE(out_, std::uint32_t{16U});
    recorderWriteLE(out_, std::uint16_t{3U});

    const std::uint64_t blockAlign64 = static_cast<std::uint64_t>(ch_) * sizeof(float);
    if (ch_ > std::numeric_limits<std::uint16_t>::max() ||
        blockAlign64 > std::numeric_limits<std::uint16_t>::max())
        throw std::runtime_error("recorder channel count exceeds WAV format limit");

    recorderWriteLE(out_, static_cast<std::uint16_t>(ch_));
    recorderWriteLE(out_, sampleRate_);
    const auto blockAlign = static_cast<std::uint16_t>(blockAlign64);
    const std::uint64_t byteRate64 = static_cast<std::uint64_t>(sampleRate_) * blockAlign;
    if (byteRate64 > std::numeric_limits<std::uint32_t>::max())
        throw std::runtime_error("recorder WAV byte rate exceeds format limit");
    recorderWriteLE(out_, static_cast<std::uint32_t>(byteRate64));
    recorderWriteLE(out_, blockAlign);
    recorderWriteLE(out_, std::uint16_t{32U});
    out_.write("data", 4);
    recorderWriteLE(out_, std::uint32_t{0U});

    if (!out_ || static_cast<std::uint64_t>(out_.tellp()) != recorderHeaderBytes)
        throw std::runtime_error("recorder WAV header write failed");
}

void Recorder::start(const std::string& path) {
    if (ch_ == 0U || sampleRate_ == 0U || ring_.empty()) throw std::logic_error("recorder is not prepared");
    if (recording() || writerThread_.joinable() || out_.is_open()) throw std::logic_error("recorder is already active");
    if (path.empty()) throw std::invalid_argument("recorder output path is empty");

    createParentDirectoriesCompat(path);
    path_ = path;
    captureCacheValid_ = false;
    captureCache_.resize(0U, 0U);
    writeFrame_.store(0U, std::memory_order_relaxed);
    readFrame_.store(0U, std::memory_order_relaxed);
    framesAccepted_.store(0U, std::memory_order_relaxed);
    framesWritten_.store(0U, std::memory_order_relaxed);
    droppedFrames_.store(0U, std::memory_order_relaxed);
    activePushes_.store(0U, std::memory_order_relaxed);
    faulted_.store(false, std::memory_order_relaxed);
    overflowed_.store(false, std::memory_order_relaxed);
    writerError_.store(false, std::memory_order_relaxed);
    writerStop_.store(false, std::memory_order_relaxed);
    dataBytesWritten_ = 0U;

    out_.open(path_.c_str(), std::ios::binary | std::ios::trunc);
    if (!out_) throw std::runtime_error("cannot open recorder WAV for writing");
    try {
        writePlaceholderHeader();
        out_.flush();
        if (!out_) throw std::runtime_error("recorder WAV header flush failed");
        recording_.store(true, std::memory_order_release);
        writerThread_ = std::thread(&Recorder::writerLoop, this);
    } catch (...) {
        recording_.store(false, std::memory_order_release);
        writerStop_.store(true, std::memory_order_release);
        if (writerThread_.joinable()) writerThread_.join();
        out_.close();
        throw;
    }
}

void Recorder::start() {
    static std::atomic<std::uint64_t> sequence {0U};
    const auto id = sequence.fetch_add(1U, std::memory_order_relaxed);
    const auto ticks = static_cast<std::uint64_t>(std::chrono::steady_clock::now().time_since_epoch().count());
    start(recorderTempPath(ticks, id));
}

void Recorder::markFault(bool writerError) noexcept {
    faulted_.store(true, std::memory_order_release);
    if (writerError) writerError_.store(true, std::memory_order_release);
}

bool Recorder::push(const float* const* in,
                    std::uint32_t channels,
                    std::uint32_t frames) noexcept {
    if (!recording_.load(std::memory_order_acquire)) return false;

    activePushes_.fetch_add(1U, std::memory_order_acq_rel);
    if (!recording_.load(std::memory_order_acquire)) {
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return false;
    }

    if (frames == 0U) {
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return true;
    }
    if (in == nullptr || channels < ch_) {
        droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
        markFault(false);
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return false;
    }
    for (std::uint32_t c = 0U; c < ch_; ++c) {
        if (in[c] == nullptr) {
            droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
            markFault(false);
            activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
            return false;
        }
    }

    const std::uint64_t write = writeFrame_.load(std::memory_order_relaxed);
    const std::uint64_t read = readFrame_.load(std::memory_order_acquire);
    const std::uint64_t used = write - read;
    const std::uint64_t freeFrames = used < ringCapacityFrames_ ? ringCapacityFrames_ - used : 0U;
    if (static_cast<std::uint64_t>(frames) > freeFrames) {
        droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
        overflowed_.store(true, std::memory_order_release);
        markFault(false);
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return false;
    }

    for (std::uint32_t f = 0U; f < frames; ++f) {
        const std::uint64_t ringFrame = (write + f) % ringCapacityFrames_;
        float* dst = ring_.data() + static_cast<std::size_t>(ringFrame) * ch_;
        for (std::uint32_t c = 0U; c < ch_; ++c) dst[c] = in[c][f];
    }

    writeFrame_.store(write + frames, std::memory_order_release);
    framesAccepted_.fetch_add(frames, std::memory_order_relaxed);
    activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
    return true;
}

void Recorder::writerLoop() noexcept {
    for (;;) {
        const std::uint64_t read = readFrame_.load(std::memory_order_relaxed);
        const std::uint64_t write = writeFrame_.load(std::memory_order_acquire);
        const std::uint64_t available = write - read;

        if (available == 0U) {
            if (writerStop_.load(std::memory_order_acquire)) break;
            std::this_thread::sleep_for(std::chrono::microseconds(500));
            continue;
        }

        const std::uint64_t ringFrame = read % ringCapacityFrames_;
        const std::uint64_t contiguous = std::min<std::uint64_t>(available, ringCapacityFrames_ - ringFrame);
        const std::uint64_t samples = contiguous * ch_;
        const std::uint64_t bytes = samples * sizeof(float);

        out_.write(reinterpret_cast<const char*>(ring_.data() + static_cast<std::size_t>(ringFrame) * ch_),
                   static_cast<std::streamsize>(bytes));
        if (!out_) {
            markFault(true);
            recording_.store(false, std::memory_order_release);
            writerStop_.store(true, std::memory_order_release);
            break;
        }

        dataBytesWritten_ += bytes;
        framesWritten_.fetch_add(contiguous, std::memory_order_relaxed);
        readFrame_.store(read + contiguous, std::memory_order_release);
    }
}

void Recorder::finalizeHeader() {
    if (!out_.is_open()) return;
    out_.flush();
    if (!out_) throw std::runtime_error("recorder WAV data flush failed");

    const std::uint64_t frames = framesWritten_.load(std::memory_order_acquire);
    const std::uint64_t riffSize64 = (recorderHeaderBytes - 8U) + dataBytesWritten_;
    const bool needsRf64 = riffSize64 > std::numeric_limits<std::uint32_t>::max() ||
                           dataBytesWritten_ > std::numeric_limits<std::uint32_t>::max();

    out_.seekp(0, std::ios::beg);
    if (needsRf64) {
        out_.write("RF64", 4);
        recorderWriteLE(out_, std::uint32_t{0xFFFFFFFFU});
        out_.write("WAVE", 4);
        out_.write("ds64", 4);
        recorderWriteLE(out_, std::uint32_t{28U});
        recorderWriteLE(out_, riffSize64);
        recorderWriteLE(out_, dataBytesWritten_);
        recorderWriteLE(out_, frames);
        recorderWriteLE(out_, std::uint32_t{0U});
        out_.seekp(76, std::ios::beg);
        recorderWriteLE(out_, std::uint32_t{0xFFFFFFFFU});
    } else {
        out_.write("RIFF", 4);
        recorderWriteLE(out_, static_cast<std::uint32_t>(riffSize64));
        out_.write("WAVE", 4);
        out_.write("JUNK", 4);
        out_.seekp(76, std::ios::beg);
        recorderWriteLE(out_, static_cast<std::uint32_t>(dataBytesWritten_));
    }
    out_.flush();
    if (!out_) throw std::runtime_error("recorder WAV finalization failed");
}

void Recorder::stop() noexcept {
    recording_.store(false, std::memory_order_release);
    while (activePushes_.load(std::memory_order_acquire) != 0U) std::this_thread::yield();

    writerStop_.store(true, std::memory_order_release);
    if (writerThread_.joinable()) writerThread_.join();

    if (out_.is_open()) {
        try {
            finalizeHeader();
        } catch (...) {
            markFault(true);
        }
        out_.close();
    }
}

RecorderStatus Recorder::status() const noexcept {
    RecorderStatus s;
    s.recording = recording_.load(std::memory_order_acquire);
    s.faulted = faulted_.load(std::memory_order_acquire);
    s.overflowed = overflowed_.load(std::memory_order_acquire);
    s.writerError = writerError_.load(std::memory_order_acquire);
    s.framesAccepted = framesAccepted_.load(std::memory_order_acquire);
    s.framesWritten = framesWritten_.load(std::memory_order_acquire);
    s.droppedFrames = droppedFrames_.load(std::memory_order_acquire);
    return s;
}

const AudioBuffer& Recorder::captured() const {
    if (recording()) throw std::logic_error("cannot load captured audio while recorder is running");
    if (path_.empty()) throw std::logic_error("recorder has no take");
    if (!captureCacheValid_) {
        auto wav = WavFile::read(path_);
        if (wav.sampleRate != sampleRate_) throw std::runtime_error("recorded WAV sample rate mismatch");
        if (wav.audio.channels() != ch_) throw std::runtime_error("recorded WAV channel count mismatch");
        captureCache_ = std::move(wav.audio);
        captureCacheValid_ = true;
    }
    return captureCache_;
}

}
