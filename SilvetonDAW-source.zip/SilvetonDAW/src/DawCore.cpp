#include "silveton/DawCore.h"
#include <queue>
#include <sstream>
#include <chrono>
#include <limits>
#include <thread>
#include <cerrno>
#include <cstdlib>
#if defined(_WIN32)
#include <direct.h>
#else
#include <sys/stat.h>
#endif
namespace silveton {
void AutomationLane::add(std::int64_t s,float v){p_.push_back({s,v});std::sort(p_.begin(),p_.end(),[](auto&a,auto&b){return a.sample<b.sample;});}
float AutomationLane::valueAt(std::int64_t s,float f)const noexcept{if(p_.empty())return f;if(s<=p_.front().sample)return p_.front().value;if(s>=p_.back().sample)return p_.back().value;auto it=std::upper_bound(p_.begin(),p_.end(),s,[](auto x,const auto&p){return x<p.sample;});auto&a=*(it-1);auto&b=*it;double t=double(s-a.sample)/double(b.sample-a.sample);return float(a.value+(b.value-a.value)*t);}
void MidiTrack::add(MidiEvent e){e_.push_back(e);std::sort(e_.begin(),e_.end(),[](auto&a,auto&b){return a.sample<b.sample;});}
std::vector<MidiEvent> MidiTrack::range(std::int64_t a,std::int64_t b)const{std::vector<MidiEvent>o;for(auto&e:e_)if(e.sample>=a&&e.sample<b)o.push_back(e);return o;}
AudioBuffer AudioEditor::trim(const AudioBuffer&x,std::uint64_t s,std::uint64_t n){if(s>x.frames())throw std::out_of_range("trim");n=std::min<std::uint64_t>(n,x.frames()-s);AudioBuffer o(x.channels(),n);for(size_t c=0;c<x.channels();++c)std::copy_n(x.channelData(c)+s,n,o.channelData(c));return o;}
AudioBuffer AudioEditor::reverse(const AudioBuffer&x){AudioBuffer o(x.channels(),x.frames());for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<x.frames();++i)o.channelData(c)[i]=x.channelData(c)[x.frames()-1-i];return o;}
void AudioEditor::fadeIn(AudioBuffer&x,std::uint64_t n){n=std::min<std::uint64_t>(n,x.frames());for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<n;++i)x.channelData(c)[i]*=n<=1?1.f:float(i)/float(n-1);}
void AudioEditor::fadeOut(AudioBuffer&x,std::uint64_t n){n=std::min<std::uint64_t>(n,x.frames());for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<n;++i)x.channelData(c)[x.frames()-n+i]*=n<=1?0.f:1.f-float(i)/float(n-1);}
AudioBuffer AudioEditor::resampleLinear(const AudioBuffer&x,double ratio){if(!(ratio>0)||!std::isfinite(ratio))throw std::invalid_argument("ratio");size_t nf=std::max<size_t>(1,size_t(std::llround(x.frames()*ratio)));AudioBuffer o(x.channels(),nf);for(size_t c=0;c<x.channels();++c)for(size_t i=0;i<nf;++i){double p=double(i)/ratio;size_t a=std::min<size_t>(size_t(p),x.frames()-1),b=std::min(a+1,x.frames()-1);double t=p-a;o.channelData(c)[i]=float(x.channelData(c)[a]*(1-t)+x.channelData(c)[b]*t);}return o;}
AudioBuffer AudioEditor::timeStretch(const AudioBuffer&x,double ratio){if(!(ratio>0)||!std::isfinite(ratio))throw std::invalid_argument("ratio");if(x.frames()<32)return resampleLinear(x,ratio);const size_t win=256,hopIn=64,hopOut=std::max<size_t>(1,size_t(std::llround(hopIn*ratio)));size_t nf=std::max<size_t>(win,size_t(x.frames()*ratio)+win);AudioBuffer o(x.channels(),nf);std::vector<float>norm(nf);for(size_t pos=0,out=0;pos+win<=x.frames()&&out+win<=nf;pos+=hopIn,out+=hopOut)for(size_t j=0;j<win;++j){float w=0.5f-0.5f*std::cos(float(2.0*3.14159265358979323846*j/(win-1)));norm[out+j]+=w*w;for(size_t c=0;c<x.channels();++c)o.channelData(c)[out+j]+=x.channelData(c)[pos+j]*w*w;}for(size_t i=0;i<nf;++i)if(norm[i]>1e-8f)for(size_t c=0;c<x.channels();++c)o.channelData(c)[i]/=norm[i];return trim(o,0,std::max<size_t>(1,size_t(std::llround(x.frames()*ratio))));}
AudioBuffer AudioEditor::pitchShift(const AudioBuffer&x,double semi){double p=std::pow(2.0,semi/12.0);auto r=resampleLinear(x,1.0/p);return timeStretch(r,p);}
void RoutingGraph::setNodeCount(size_t n){n_=n;r_.clear();}
void RoutingGraph::addRoute(Route r){if(r.from>=n_||r.to>=n_||r.from==r.to)throw std::invalid_argument("route");r_.push_back(r);(void)topologicalOrder();}
std::vector<size_t> RoutingGraph::topologicalOrder()const{std::vector<size_t>d(n_);for(auto&r:r_)++d[r.to];std::queue<size_t>q;for(size_t i=0;i<n_;++i)if(!d[i])q.push(i);std::vector<size_t>o;while(!q.empty()){auto u=q.front();q.pop();o.push_back(u);for(auto&r:r_)if(r.from==u&&!--d[r.to])q.push(r.to);}if(o.size()!=n_)throw std::logic_error("routing cycle");return o;}
void DelayCompensator::setLatencies(const std::vector<uint32_t>&l){max_=0;for(auto x:l)max_=std::max(max_,x);d_.resize(l.size());for(size_t i=0;i<l.size();++i)d_[i]=max_-l[i];}
uint32_t DelayCompensator::delayFor(size_t i)const{if(i>=d_.size())throw std::out_of_range("pdc");return d_[i];}
static std::string esc(std::string s){for(auto&c:s)if(c=='\t'||c=='\n'||c=='\r')c=' ';return s;}

static int panDepthCode(PanDepth d) noexcept {
    switch (d) {
        case PanDepth::Minus2_5dB: return 25;
        case PanDepth::Minus3dB: return 30;
        case PanDepth::Minus4_5dB: return 45;
        case PanDepth::Minus6dB: return 60;
    }
    return 30;
}

static PanDepth panDepthFromCode(int code) {
    switch (code) {
        case 25: return PanDepth::Minus2_5dB;
        case 30: return PanDepth::Minus3dB;
        case 45: return PanDepth::Minus4_5dB;
        case 60: return PanDepth::Minus6dB;
        default: throw std::runtime_error("unsupported pan depth");
    }
}

void Project::save(const std::string&p) const {
    std::ofstream f(p.c_str());
    if(!f) throw std::runtime_error("project write");
    f<<"SILVETON_PROJECT_V3\n"<<sampleRate<<'\t'<<tempo<<'\t'<<panDepthCode(panDepth)<<'\t'<<masterFaderDb<<'\n';
    for(const auto&t:tracks) {
        f<<esc(t.name)<<'\t'<<esc(t.audioPath)<<'\t'<<t.gainDb<<'\t'<<t.pan<<'\t'<<t.mute
         <<'\t'<<t.useDualStereoPan<<'\t'<<t.stereoLeftPan<<'\t'<<t.stereoRightPan<<'\n';
    }
    if(!f) throw std::runtime_error("project write failed");
}

Project Project::load(const std::string&p) {
    std::ifstream f(p.c_str());
    std::string line;
    if(!std::getline(f,line)) throw std::runtime_error("project format");
    const bool v1 = line=="SILVETON_PROJECT_V1";
    const bool v2 = line=="SILVETON_PROJECT_V2";
    const bool v3 = line=="SILVETON_PROJECT_V3";
    if(!v1 && !v2 && !v3) throw std::runtime_error("project format");

    Project o;
    if(!std::getline(f,line)) throw std::runtime_error("project header");
    {
        std::istringstream ss(line);
        if(v1) {
            if(!(ss>>o.sampleRate>>o.tempo)) throw std::runtime_error("project header");
            o.panDepth=PanDepth::Minus3dB;
            o.masterFaderDb=0.0F;
        } else if(v2) {
            int pd=30;
            if(!(ss>>o.sampleRate>>o.tempo>>pd)) throw std::runtime_error("project header");
            o.panDepth=panDepthFromCode(pd);
            o.masterFaderDb=0.0F;
        } else {
            int pd=30;
            if(!(ss>>o.sampleRate>>o.tempo>>pd>>o.masterFaderDb)) throw std::runtime_error("project header");
            o.panDepth=panDepthFromCode(pd);
        }
    }

    while(std::getline(f,line)) {
        if(line.empty()) continue;
        std::istringstream ss(line);
        ProjectTrack t;
        std::getline(ss,t.name,'\t');
        std::getline(ss,t.audioPath,'\t');
        if(!(ss>>t.gainDb>>t.pan>>t.mute)) throw std::runtime_error("project track");
        if(v2 || v3) {
            if(!(ss>>t.useDualStereoPan>>t.stereoLeftPan>>t.stereoRightPan)) throw std::runtime_error("project stereo pan state");
        }
        o.tracks.push_back(t);
    }
    return o;
}
namespace {
template <typename T>
void recorderWriteLE(std::ofstream& out, T value) {
    out.write(reinterpret_cast<const char*>(&value), sizeof(T));
}
constexpr std::uint64_t recorderHeaderBytes = 80U;
static void createDirectoryCompat(const std::string& path) {
    if (path.empty() || path == "/" || path == ".") return;
#if defined(_WIN32)
    if (_mkdir(path.c_str()) != 0 && errno != EEXIST)
        throw std::runtime_error("cannot create recorder directory");
#else
    if (::mkdir(path.c_str(), 0775) != 0 && errno != EEXIST)
        throw std::runtime_error("cannot create recorder directory");
#endif
}

static void createParentDirectoriesCompat(const std::string& filePath) {
    const auto slash = filePath.find_last_of("/\\");
    if (slash == std::string::npos) return;
    const std::string parent = filePath.substr(0, slash);
    if (parent.empty()) return;

    std::string current;
    std::size_t i = 0U;
    if (parent[0] == '/') { current = "/"; i = 1U; }
#if defined(_WIN32)
    if (parent.size() >= 2U && parent[1] == ':') { current = parent.substr(0, 2U); i = 2U; }
#endif
    while (i <= parent.size()) {
        const auto next = parent.find_first_of("/\\", i);
        const auto end = next == std::string::npos ? parent.size() : next;
        if (end > i) {
            if (!current.empty() && current.back() != '/' && current.back() != '\\') current += '/';
            current.append(parent, i, end - i);
            createDirectoryCompat(current);
        }
        if (next == std::string::npos) break;
        i = next + 1U;
    }
}

static std::string recorderTempPath(std::uint64_t ticks, std::uint64_t id) {
    const char* env = std::getenv("TMPDIR");
#if defined(_WIN32)
    if (env == nullptr || *env == '\0') env = std::getenv("TEMP");
#endif
    std::string base = (env != nullptr && *env != '\0') ? std::string(env) : std::string("/tmp");
    if (!base.empty() && base.back() != '/' && base.back() != '\\') base += '/';
    return base + "silveton_recording_" + std::to_string(ticks) + "_" + std::to_string(id) + ".wav";
}

}

Recorder::~Recorder() { stop(); }

void Recorder::prepare(std::uint32_t channels,
                       std::uint32_t sampleRate,
                       std::uint32_t ringCapacityFrames) {
    if (recording() || writerThread_.joinable()) throw std::logic_error("cannot prepare recorder while active");
    if (channels == 0U) throw std::invalid_argument("recorder channels must be positive");
    if (sampleRate == 0U) throw std::invalid_argument("recorder sample rate must be positive");
    if (ringCapacityFrames < 2U) throw std::invalid_argument("recorder ring capacity is too small");

    const std::size_t channelCount = static_cast<std::size_t>(channels);
    const std::size_t frameCount = static_cast<std::size_t>(ringCapacityFrames);
    const std::size_t maxFloats = std::vector<float>().max_size();
    if (channelCount != 0U && frameCount > maxFloats / channelCount)
        throw std::length_error("recorder ring capacity is too large");

    ch_ = channels;
    sampleRate_ = sampleRate;
    ringCapacityFrames_ = ringCapacityFrames;
    ring_.assign(frameCount * channelCount, 0.0F);

    writeFrame_.store(0U, std::memory_order_relaxed);
    readFrame_.store(0U, std::memory_order_relaxed);
    framesAccepted_.store(0U, std::memory_order_relaxed);
    framesWritten_.store(0U, std::memory_order_relaxed);
    droppedFrames_.store(0U, std::memory_order_relaxed);
    activePushes_.store(0U, std::memory_order_relaxed);
    recording_.store(false, std::memory_order_relaxed);
    writerStop_.store(false, std::memory_order_relaxed);
    faulted_.store(false, std::memory_order_relaxed);
    overflowed_.store(false, std::memory_order_relaxed);
    writerError_.store(false, std::memory_order_relaxed);
    dataBytesWritten_ = 0U;
    path_.clear();
    captureCache_.resize(0U, 0U);
    captureCacheValid_ = false;
}

void Recorder::writePlaceholderHeader() {
    if (!out_) throw std::runtime_error("recorder output is not open");
    out_.seekp(0, std::ios::beg);

    out_.write("RIFF", 4);
    recorderWriteLE(out_, std::uint32_t{0U});
    out_.write("WAVE", 4);
    out_.write("JUNK", 4);
    recorderWriteLE(out_, std::uint32_t{28U});
    recorderWriteLE(out_, std::uint64_t{0U});
    recorderWriteLE(out_, std::uint64_t{0U});
    recorderWriteLE(out_, std::uint64_t{0U});
    recorderWriteLE(out_, std::uint32_t{0U});

    out_.write("fmt ", 4);
    recorderWriteLE(out_, std::uint32_t{16U});
    recorderWriteLE(out_, std::uint16_t{3U});

    const std::uint64_t blockAlign64 = static_cast<std::uint64_t>(ch_) * sizeof(float);
    if (ch_ > std::numeric_limits<std::uint16_t>::max() ||
        blockAlign64 > std::numeric_limits<std::uint16_t>::max())
        throw std::runtime_error("recorder channel count exceeds WAV format limit");

    recorderWriteLE(out_, static_cast<std::uint16_t>(ch_));
    recorderWriteLE(out_, sampleRate_);
    const auto blockAlign = static_cast<std::uint16_t>(blockAlign64);
    const std::uint64_t byteRate64 = static_cast<std::uint64_t>(sampleRate_) * blockAlign;
    if (byteRate64 > std::numeric_limits<std::uint32_t>::max())
        throw std::runtime_error("recorder WAV byte rate exceeds format limit");
    recorderWriteLE(out_, static_cast<std::uint32_t>(byteRate64));
    recorderWriteLE(out_, blockAlign);
    recorderWriteLE(out_, std::uint16_t{32U});
    out_.write("data", 4);
    recorderWriteLE(out_, std::uint32_t{0U});

    if (!out_ || static_cast<std::uint64_t>(out_.tellp()) != recorderHeaderBytes)
        throw std::runtime_error("recorder WAV header write failed");
}

void Recorder::start(const std::string& path) {
    if (ch_ == 0U || sampleRate_ == 0U || ring_.empty()) throw std::logic_error("recorder is not prepared");
    if (recording() || writerThread_.joinable() || out_.is_open()) throw std::logic_error("recorder is already active");
    if (path.empty()) throw std::invalid_argument("recorder output path is empty");

    createParentDirectoriesCompat(path);
    path_ = path;
    captureCacheValid_ = false;
    captureCache_.resize(0U, 0U);
    writeFrame_.store(0U, std::memory_order_relaxed);
    readFrame_.store(0U, std::memory_order_relaxed);
    framesAccepted_.store(0U, std::memory_order_relaxed);
    framesWritten_.store(0U, std::memory_order_relaxed);
    droppedFrames_.store(0U, std::memory_order_relaxed);
    activePushes_.store(0U, std::memory_order_relaxed);
    faulted_.store(false, std::memory_order_relaxed);
    overflowed_.store(false, std::memory_order_relaxed);
    writerError_.store(false, std::memory_order_relaxed);
    writerStop_.store(false, std::memory_order_relaxed);
    dataBytesWritten_ = 0U;

    out_.open(path_.c_str(), std::ios::binary | std::ios::trunc);
    if (!out_) throw std::runtime_error("cannot open recorder WAV for writing");
    try {
        writePlaceholderHeader();
        out_.flush();
        if (!out_) throw std::runtime_error("recorder WAV header flush failed");
        recording_.store(true, std::memory_order_release);
        writerThread_ = std::thread(&Recorder::writerLoop, this);
    } catch (...) {
        recording_.store(false, std::memory_order_release);
        writerStop_.store(true, std::memory_order_release);
        if (writerThread_.joinable()) writerThread_.join();
        out_.close();
        throw;
    }
}

void Recorder::start() {
    static std::atomic<std::uint64_t> sequence {0U};
    const auto id = sequence.fetch_add(1U, std::memory_order_relaxed);
    const auto ticks = static_cast<std::uint64_t>(std::chrono::steady_clock::now().time_since_epoch().count());
    start(recorderTempPath(ticks, id));
}

void Recorder::markFault(bool writerError) noexcept {
    faulted_.store(true, std::memory_order_release);
    if (writerError) writerError_.store(true, std::memory_order_release);
}

bool Recorder::push(const float* const* in,
                    std::uint32_t channels,
                    std::uint32_t frames) noexcept {
    if (!recording_.load(std::memory_order_acquire)) return false;

    activePushes_.fetch_add(1U, std::memory_order_acq_rel);
    if (!recording_.load(std::memory_order_acquire)) {
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return false;
    }

    if (frames == 0U) {
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return true;
    }
    if (in == nullptr || channels < ch_) {
        droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
        markFault(false);
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return false;
    }
    for (std::uint32_t c = 0U; c < ch_; ++c) {
        if (in[c] == nullptr) {
            droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
            markFault(false);
            activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
            return false;
        }
    }

    const std::uint64_t write = writeFrame_.load(std::memory_order_relaxed);
    const std::uint64_t read = readFrame_.load(std::memory_order_acquire);
    const std::uint64_t used = write - read;
    const std::uint64_t freeFrames = used < ringCapacityFrames_ ? ringCapacityFrames_ - used : 0U;
    if (static_cast<std::uint64_t>(frames) > freeFrames) {
        droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
        overflowed_.store(true, std::memory_order_release);
        markFault(false);
        activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
        return false;
    }

    for (std::uint32_t f = 0U; f < frames; ++f) {
        const std::uint64_t ringFrame = (write + f) % ringCapacityFrames_;
        float* dst = ring_.data() + static_cast<std::size_t>(ringFrame) * ch_;
        for (std::uint32_t c = 0U; c < ch_; ++c) dst[c] = in[c][f];
    }

    writeFrame_.store(write + frames, std::memory_order_release);
    framesAccepted_.fetch_add(frames, std::memory_order_relaxed);
    activePushes_.fetch_sub(1U, std::memory_order_acq_rel);
    return true;
}

void Recorder::writerLoop() noexcept {
    for (;;) {
        const std::uint64_t read = readFrame_.load(std::memory_order_relaxed);
        const std::uint64_t write = writeFrame_.load(std::memory_order_acquire);
        const std::uint64_t available = write - read;

        if (available == 0U) {
            if (writerStop_.load(std::memory_order_acquire)) break;
            std::this_thread::sleep_for(std::chrono::microseconds(500));
            continue;
        }

        const std::uint64_t ringFrame = read % ringCapacityFrames_;
        const std::uint64_t contiguous = std::min<std::uint64_t>(available, ringCapacityFrames_ - ringFrame);
        const std::uint64_t samples = contiguous * ch_;
        const std::uint64_t bytes = samples * sizeof(float);

        out_.write(reinterpret_cast<const char*>(ring_.data() + static_cast<std::size_t>(ringFrame) * ch_),
                   static_cast<std::streamsize>(bytes));
        if (!out_) {
            markFault(true);
            recording_.store(false, std::memory_order_release);
            writerStop_.store(true, std::memory_order_release);
            break;
        }

        dataBytesWritten_ += bytes;
        framesWritten_.fetch_add(contiguous, std::memory_order_relaxed);
        readFrame_.store(read + contiguous, std::memory_order_release);
    }
}

void Recorder::finalizeHeader() {
    if (!out_.is_open()) return;
    out_.flush();
    if (!out_) throw std::runtime_error("recorder WAV data flush failed");

    const std::uint64_t frames = framesWritten_.load(std::memory_order_acquire);
    const std::uint64_t riffSize64 = (recorderHeaderBytes - 8U) + dataBytesWritten_;
    const bool needsRf64 = riffSize64 > std::numeric_limits<std::uint32_t>::max() ||
                           dataBytesWritten_ > std::numeric_limits<std::uint32_t>::max();

    out_.seekp(0, std::ios::beg);
    if (needsRf64) {
        out_.write("RF64", 4);
        recorderWriteLE(out_, std::uint32_t{0xFFFFFFFFU});
        out_.write("WAVE", 4);
        out_.write("ds64", 4);
        recorderWriteLE(out_, std::uint32_t{28U});
        recorderWriteLE(out_, riffSize64);
        recorderWriteLE(out_, dataBytesWritten_);
        recorderWriteLE(out_, frames);
        recorderWriteLE(out_, std::uint32_t{0U});
        out_.seekp(76, std::ios::beg);
        recorderWriteLE(out_, std::uint32_t{0xFFFFFFFFU});
    } else {
        out_.write("RIFF", 4);
        recorderWriteLE(out_, static_cast<std::uint32_t>(riffSize64));
        out_.write("WAVE", 4);
        out_.write("JUNK", 4);
        out_.seekp(76, std::ios::beg);
        recorderWriteLE(out_, static_cast<std::uint32_t>(dataBytesWritten_));
    }
    out_.flush();
    if (!out_) throw std::runtime_error("recorder WAV finalization failed");
}

void Recorder::stop() noexcept {
    recording_.store(false, std::memory_order_release);
    while (activePushes_.load(std::memory_order_acquire) != 0U) std::this_thread::yield();

    writerStop_.store(true, std::memory_order_release);
    if (writerThread_.joinable()) writerThread_.join();

    if (out_.is_open()) {
        try {
            finalizeHeader();
        } catch (...) {
            markFault(true);
        }
        out_.close();
    }
}

RecorderStatus Recorder::status() const noexcept {
    RecorderStatus s;
    s.recording = recording_.load(std::memory_order_acquire);
    s.faulted = faulted_.load(std::memory_order_acquire);
    s.overflowed = overflowed_.load(std::memory_order_acquire);
    s.writerError = writerError_.load(std::memory_order_acquire);
    s.framesAccepted = framesAccepted_.load(std::memory_order_acquire);
    s.framesWritten = framesWritten_.load(std::memory_order_acquire);
    s.droppedFrames = droppedFrames_.load(std::memory_order_acquire);
    return s;
}

const AudioBuffer& Recorder::captured() const {
    if (recording()) throw std::logic_error("cannot load captured audio while recorder is running");
    if (path_.empty()) throw std::logic_error("recorder has no take");
    if (!captureCacheValid_) {
        auto wav = WavFile::read(path_);
        if (wav.sampleRate != sampleRate_) throw std::runtime_error("recorded WAV sample rate mismatch");
        if (wav.audio.channels() != ch_) throw std::runtime_error("recorded WAV channel count mismatch");
        captureCache_ = std::move(wav.audio);
        captureCacheValid_ = true;
    }
    return captureCache_;
}

}
