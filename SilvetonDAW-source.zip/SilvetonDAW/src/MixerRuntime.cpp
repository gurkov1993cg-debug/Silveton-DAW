#include "silveton/MixerRuntime.h"
#include "silveton/MixerRouting.h"
#include <stdexcept>
#include <utility>

namespace silveton {

MixerRuntimeCoordinator::MixerRuntimeCoordinator(Project& project,
                                                 Vst3RuntimeRack& rack,
                                                 AudioEngine& engine,
                                                 std::uint32_t maxCompensationSamples) noexcept
    : project_(project),
      rack_(rack),
      engine_(engine),
      maxCompensationSamples_(maxCompensationSamples) {}

std::uint64_t MixerRuntimeCoordinator::publishRequiredGraph() {
    engine_.setPanDepth(project_.panDepth);
    // Project master fader is part of the immutable master graph node so its
    // automation is snapshotted with the rest of the mixer state.
    engine_.setMasterFaderDb(0.0F);
    engine_.setMasterFaderAutomation(nullptr);
    engine_.applyProjectTrackMixerState(project_);
    auto graph = MixerRoutingBuilder::build(project_, rack_);
    const std::uint64_t generation = engine_.publishProcessorGraph(std::move(graph), maxCompensationSamples_);
    rebuildRequired_ = false;
    lastPublishedGeneration_ = generation;
    if (retiredInstancesWaiting_) retiredInstancesGeneration_ = generation;
    return generation;
}

std::uint64_t MixerRuntimeCoordinator::publishProjectRouting() {
    if (engine_.processorGraphPublicationPending()) {
        rebuildRequired_ = true;
        return 0U;
    }
    rebuildRequired_ = true;
    return publishRequiredGraph();
}

std::uint64_t MixerRuntimeCoordinator::publishProjectTopology() {
    if (engine_.processorGraphPublicationPending())
        throw std::logic_error("cannot replace VST3 topology while processor graph publication is pending");
    if (rack_.publicationStatePending())
        throw std::logic_error("previous VST3 topology replacement has not been reclaimed");

    rack_.stageProject(project_);
    try {
            engine_.setPanDepth(project_.panDepth);
        engine_.setMasterFaderDb(0.0F);
        engine_.setMasterFaderAutomation(nullptr);
        engine_.applyProjectTrackMixerState(project_);

        auto graph = MixerRoutingBuilder::buildStaged(project_, rack_);
        const std::uint64_t generation =
            engine_.publishProcessorGraph(std::move(graph), maxCompensationSamples_);

        // Publication is now guaranteed to reference only the staged rack. The
        // old rack can be retired, but its instances remain owned until the
        // predecessor graph is reclaimed after audio-thread adoption.
        rack_.commitStagedProject();
        retiredInstancesWaiting_ = true;
        retiredInstancesGeneration_ = generation;
        rebuildRequired_ = false;
        lastPublishedGeneration_ = generation;
        return generation;
    } catch (...) {
        rack_.cancelStagedProject();
        throw;
    }
}

MixerRuntimeServiceResult MixerRuntimeCoordinator::serviceVst3Changes() {
    MixerRuntimeServiceResult result;

    // Do not consume more plug-in restart requests while a graph is waiting for
    // its block-boundary adoption. This keeps reload lifetime changes strictly
    // ordered and allows VST3 restart flags to accumulate until the next call.
    if (engine_.processorGraphPublicationPending()) return result;

    if (!rebuildRequired_) {
        result.vst3 = rack_.serviceRestartFlags();
        if (result.vst3.graphRebuildRequired) rebuildRequired_ = true;
        if (result.vst3.reloadPerformed) retiredInstancesWaiting_ = true;
    }

    if (rebuildRequired_) {
        result.graphGeneration = publishRequiredGraph();
        result.graphPublished = true;
    }
    return result;
}

std::size_t MixerRuntimeCoordinator::reclaimRetired() noexcept {
    if (engine_.processorGraphPublicationPending()) return 0U;
    const std::size_t reclaimed = engine_.reclaimRetiredProcessorGraphs();
    if (reclaimed == 0U) return 0U;

    if ((retiredInstancesWaiting_ || rack_.publicationStatePending()) &&
        retiredInstancesGeneration_ != 0U &&
        engine_.liveProcessorGraphGeneration() >= retiredInstancesGeneration_) {
        rack_.releaseRetiredInstances();
        retiredInstancesWaiting_ = false;
        retiredInstancesGeneration_ = 0U;
    }
    return reclaimed;
}

} // namespace silveton
