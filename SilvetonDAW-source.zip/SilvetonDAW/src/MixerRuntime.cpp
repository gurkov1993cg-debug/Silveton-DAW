#include "silveton/MixerRuntime.h"
#include "silveton/MixerRouting.h"
#include <utility>

namespace silveton {

MixerRuntimeCoordinator::MixerRuntimeCoordinator(Project& project,
                                                 Vst3RuntimeRack& rack,
                                                 AudioEngine& engine,
                                                 std::uint32_t maxCompensationSamples) noexcept
    : project_(project),
      rack_(rack),
      engine_(engine),
      maxCompensationSamples_(maxCompensationSamples) {}

std::uint64_t MixerRuntimeCoordinator::publishRequiredGraph() {
    engine_.setTempo(project_.tempo);
    engine_.setPanDepth(project_.panDepth);
    // Project master fader is part of the immutable master graph node so its
    // automation is snapshotted with the rest of the mixer state.
    engine_.setMasterFaderDb(0.0F);
    engine_.setMasterFaderAutomation(nullptr);
    engine_.applyProjectTrackMixerState(project_);
    auto graph = MixerRoutingBuilder::build(project_, rack_);
    const std::uint64_t generation = engine_.publishProcessorGraph(std::move(graph), maxCompensationSamples_);
    rebuildRequired_ = false;
    lastPublishedGeneration_ = generation;
    if (retiredInstancesWaiting_) retiredInstancesGeneration_ = generation;
    return generation;
}

std::uint64_t MixerRuntimeCoordinator::publishProjectRouting() {
    if (engine_.processorGraphPublicationPending()) {
        rebuildRequired_ = true;
        return 0U;
    }
    rebuildRequired_ = true;
    return publishRequiredGraph();
}

MixerRuntimeServiceResult MixerRuntimeCoordinator::serviceVst3Changes() {
    MixerRuntimeServiceResult result;

    // Do not consume more plug-in restart requests while a graph is waiting for
    // its block-boundary adoption. This keeps reload lifetime changes strictly
    // ordered and allows VST3 restart flags to accumulate until the next call.
    if (engine_.processorGraphPublicationPending()) return result;

    if (!rebuildRequired_) {
        result.vst3 = rack_.serviceRestartFlags();
        if (result.vst3.graphRebuildRequired) rebuildRequired_ = true;
        if (result.vst3.reloadPerformed) retiredInstancesWaiting_ = true;
    }

    if (rebuildRequired_) {
        result.graphGeneration = publishRequiredGraph();
        result.graphPublished = true;
    }
    return result;
}

std::size_t MixerRuntimeCoordinator::reclaimRetired() noexcept {
    if (engine_.processorGraphPublicationPending()) return 0U;
    const std::size_t reclaimed = engine_.reclaimRetiredProcessorGraphs();
    if (reclaimed == 0U) return 0U;

    if (retiredInstancesWaiting_ && retiredInstancesGeneration_ != 0U &&
        engine_.liveProcessorGraphGeneration() >= retiredInstancesGeneration_) {
        rack_.releaseRetiredInstances();
        retiredInstancesWaiting_ = false;
        retiredInstancesGeneration_ = 0U;
    }
    return reclaimed;
}

} // namespace silveton
