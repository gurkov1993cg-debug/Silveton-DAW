#include "silveton/SampleEditorModel.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace silveton {

// ---------------------------------------------------------------- viewport --
double SampleViewport::maxSamplesPerPixel() const noexcept {
    return std::max(kMinSamplesPerPixel, length / std::max(1.0, widthPx));
}

void SampleViewport::clamp() {
    if (!(widthPx >= 1.0)) widthPx = 1.0;
    if (!(length >= 1.0)) length = 1.0;
    samplesPerPixel = std::min(std::max(samplesPerPixel, kMinSamplesPerPixel), maxSamplesPerPixel());
    const double room = std::max(0.0, length - visibleSamples());
    first = std::min(std::max(first, 0.0), room);
}

void SampleViewport::configure(double spanLength, double width) {
    const bool wasFitted = samplesPerPixel >= maxSamplesPerPixel() * 0.999;
    length = std::max(1.0, spanLength);
    widthPx = std::max(1.0, width);
    if (wasFitted) samplesPerPixel = maxSamplesPerPixel();
    clamp();
}

void SampleViewport::fitAll() {
    first = 0.0;
    samplesPerPixel = maxSamplesPerPixel();
    clamp();
}

void SampleViewport::zoomAbout(double anchorX, double factor) {
    if (!(factor > 0.0)) return;
    const double anchor = sampleAtX(anchorX);
    samplesPerPixel *= factor;
    samplesPerPixel = std::min(std::max(samplesPerPixel, kMinSamplesPerPixel), maxSamplesPerPixel());
    first = anchor - anchorX * samplesPerPixel;
    clamp();
}

void SampleViewport::zoomToRange(double a, double b) {
    if (b < a) std::swap(a, b);
    const double span = std::max(b - a, 1.0);
    const double margin = span * 0.04;
    samplesPerPixel = (span + 2.0 * margin) / std::max(1.0, widthPx);
    samplesPerPixel = std::min(std::max(samplesPerPixel, kMinSamplesPerPixel), maxSamplesPerPixel());
    first = a - margin;
    clamp();
}

void SampleViewport::scrollPixels(double dx) {
    first += dx * samplesPerPixel;
    clamp();
}

void SampleViewport::ensureVisible(double sample) {
    const double visible = visibleSamples();
    if (sample >= first && sample <= first + visible) return;
    first = sample - visible * 0.1;
    clamp();
}

// ------------------------------------------------------------------- ruler --
std::string formatRulerTime(double seconds, double stepSeconds) {
    if (seconds < 0.0) seconds = 0.0;
    int decimals = 0;
    if (stepSeconds < 1.0) decimals = static_cast<int>(std::min(6.0, std::max(0.0, std::ceil(-std::log10(stepSeconds) - 1.0e-9))));
    const double rounded = std::round(seconds * std::pow(10.0, decimals)) / std::pow(10.0, decimals);
    const long total = static_cast<long>(std::floor(rounded + 1.0e-9));
    const long hours = total / 3600;
    const long minutes = (total % 3600) / 60;
    const double secs = rounded - static_cast<double>(hours * 3600 + minutes * 60);
    char buffer[64];
    if (decimals == 0) {
        if (hours > 0) std::snprintf(buffer, sizeof buffer, "%ld:%02ld:%02d", hours, minutes, static_cast<int>(std::lround(secs)));
        else std::snprintf(buffer, sizeof buffer, "%ld:%02d", minutes, static_cast<int>(std::lround(secs)));
    } else {
        const int width = 3 + decimals;
        if (hours > 0) std::snprintf(buffer, sizeof buffer, "%ld:%02ld:%0*.*f", hours, minutes, width, decimals, secs);
        else std::snprintf(buffer, sizeof buffer, "%ld:%0*.*f", minutes, width, decimals, secs);
    }
    return buffer;
}

std::string formatClockTime(double seconds) {
    if (seconds < 0.0) seconds = 0.0;
    return formatRulerTime(seconds, 0.001);
}

std::vector<RulerTick> buildRuler(const SampleViewport& view, double sampleRate, double minMajorPx, double originSamples) {
    std::vector<RulerTick> ticks;
    if (!(sampleRate > 0.0) || !(view.samplesPerPixel > 0.0)) return ticks;
    const double secondsPerPixel = view.samplesPerPixel / sampleRate;
    const double minStep = std::max(minMajorPx, 8.0) * secondsPerPixel;

    // Smallest 1-2-5 step that is at least minStep.
    static const double mantissas[3] = {1.0, 2.0, 5.0};
    static const int subdivisions[3] = {5, 4, 5};
    double step = 1.0e-7;
    int subs = 5;
    bool found = false;
    for (int exponent = -7; exponent <= 5 && !found; ++exponent)
        for (int k = 0; k < 3 && !found; ++k) {
            const double candidate = mantissas[k] * std::pow(10.0, exponent);
            if (candidate >= minStep) { step = candidate; subs = subdivisions[k]; found = true; }
        }
    if (!found) { step = 3600.0; subs = 6; }
    const double minor = step / subs;

    const double firstSec = (originSamples + view.first) / sampleRate;
    const double lastSec = (originSamples + view.first + view.visibleSamples()) / sampleRate;
    long long index = static_cast<long long>(std::floor(firstSec / minor));
    for (;; ++index) {
        const double t = static_cast<double>(index) * minor;
        if (t > lastSec + minor) break;
        if (index < 0) continue;
        RulerTick tick;
        tick.sample = t * sampleRate - originSamples;
        tick.major = (index % subs) == 0;
        if (tick.major) tick.label = formatRulerTime(t, step);
        ticks.push_back(std::move(tick));
        if (ticks.size() > 4000U) break;   // a safety cap, never reached with sane zoom values
    }
    return ticks;
}

// ------------------------------------------------------------------- pieces --
double PieceView::fileRate() const noexcept {
    if (overview != nullptr && overview->sampleRate > 0U) return static_cast<double>(overview->sampleRate);
    if (detail != nullptr && detail->sampleRate > 0U) return static_cast<double>(detail->sampleRate);
    return projectRate;
}

double PieceView::nativePosition(double rel) const noexcept {
    return (sourceStart + (rel - startRel)) * fileRate() / projectRate;
}

double PieceView::relPosition(double nativePos) const noexcept {
    return startRel + nativePos * projectRate / fileRate() - sourceStart;
}

double pixelsPerFileSample(const PieceView& piece, const SampleViewport& view) noexcept {
    const double fileSamplesPerPixel = view.samplesPerPixel * piece.fileRate() / piece.projectRate;
    return fileSamplesPerPixel > 0.0 ? 1.0 / fileSamplesPerPixel : 1.0e9;
}

void columnPeaks(const PieceView& piece, const SampleViewport& view, std::size_t channel, std::size_t firstColumn,
                 std::size_t columns, std::vector<ColumnPeak>& out) {
    out.assign(columns, ColumnPeak {});
    const bool haveDetail = piece.detail != nullptr && piece.detail->audio.frames() > 0U && piece.detail->audio.channels() > 0U;
    const bool haveOverview = piece.overview != nullptr && !piece.overview->empty();
    if (!haveDetail && !haveOverview) return;
    const double pieceEnd = piece.endRel();
    for (std::size_t c = 0U; c < columns; ++c) {
        const double relA = view.sampleAtX(static_cast<double>(firstColumn + c));
        const double relB = view.sampleAtX(static_cast<double>(firstColumn + c) + 1.0);
        const double a = std::max(relA, piece.startRel);
        const double b = std::min(relB, pieceEnd);
        if (b <= a) continue;
        const double n0 = piece.nativePosition(a);
        const double n1 = piece.nativePosition(b);
        float mn = 0.0F, mx = 0.0F;
        bool have = false;
        const bool useDetail = haveDetail && (!haveOverview || (n1 - n0) <= static_cast<double>(piece.overview->framesPerPeak));
        if (useDetail) {
            const auto& audio = piece.detail->audio;
            const std::size_t ch = channel < audio.channels() ? channel : 0U;
            const long long frames = static_cast<long long>(audio.frames());
            long long i0 = static_cast<long long>(std::floor(n0));
            long long i1 = std::max(i0 + 1, static_cast<long long>(std::ceil(n1)));
            i0 = std::max<long long>(0, std::min(i0, frames - 1));
            i1 = std::min<long long>(frames - 1, i1);
            const float* data = audio.channelData(ch);
            for (long long i = i0; i <= i1; ++i) {
                const float v = data[i];
                if (!std::isfinite(v)) continue;
                if (!have) { mn = mx = v; have = true; }
                else { mn = std::min(mn, v); mx = std::max(mx, v); }
            }
        } else {
            const auto& peaks = piece.overview->peaks;
            const std::size_t ch = channel < peaks.size() ? channel : 0U;
            const auto fpp = static_cast<double>(piece.overview->framesPerPeak);
            long long p0 = static_cast<long long>(std::floor(n0 / fpp));
            long long p1 = std::max(p0 + 1, static_cast<long long>(std::ceil(n1 / fpp)));
            const long long count = static_cast<long long>(peaks[ch].size());
            p0 = std::max<long long>(0, std::min(p0, count - 1));
            p1 = std::min<long long>(count, p1);
            for (long long p = p0; p < p1; ++p) {
                const WaveformPeak& peak = peaks[ch][static_cast<std::size_t>(p)];
                if (!have) { mn = peak.minimum; mx = peak.maximum; have = true; }
                else { mn = std::min(mn, peak.minimum); mx = std::max(mx, peak.maximum); }
            }
        }
        if (!have) continue;
        out[c] = {std::max(-1.0F, std::min(1.0F, mn)), std::max(-1.0F, std::min(1.0F, mx)), true};
    }
}

bool interpolatedSample(const PieceView& piece, std::size_t channel, double rel, float& value) {
    if (piece.detail == nullptr || piece.detail->audio.frames() == 0U || piece.detail->audio.channels() == 0U) return false;
    if (rel < piece.startRel || rel > piece.endRel()) return false;
    const auto& audio = piece.detail->audio;
    const std::size_t ch = channel < audio.channels() ? channel : 0U;
    const double n = piece.nativePosition(rel);
    const long long frames = static_cast<long long>(audio.frames());
    long long i = static_cast<long long>(std::floor(n));
    if (i < 0) i = 0;
    if (i >= frames) return false;
    const long long j = std::min(i + 1, frames - 1);
    const double frac = std::min(1.0, std::max(0.0, n - static_cast<double>(i)));
    const float* data = audio.channelData(ch);
    value = static_cast<float>(data[i] * (1.0 - frac) + data[j] * frac);
    return true;
}

float peakInRange(const PieceView& piece, double relA, double relB) {
    const double a = std::max(relA, piece.startRel);
    const double b = std::min(relB, piece.endRel());
    if (b <= a) return -1.0F;
    const double n0 = piece.nativePosition(a);
    const double n1 = piece.nativePosition(b);
    constexpr double kExactLimit = 4.0e6;   // scan real samples up to this many per channel
    if (piece.detail != nullptr && piece.detail->audio.frames() > 0U && (n1 - n0) <= kExactLimit) {
        const auto& audio = piece.detail->audio;
        const long long frames = static_cast<long long>(audio.frames());
        long long i0 = std::max<long long>(0, static_cast<long long>(std::floor(n0)));
        long long i1 = std::min<long long>(frames, static_cast<long long>(std::ceil(n1)));
        float peak = 0.0F;
        for (std::size_t c = 0U; c < audio.channels(); ++c) {
            const float* data = audio.channelData(c);
            for (long long i = i0; i < i1; ++i) if (std::isfinite(data[i])) peak = std::max(peak, std::abs(data[i]));
        }
        return peak;
    }
    if (piece.overview != nullptr && !piece.overview->empty()) {
        const auto fpp = static_cast<double>(piece.overview->framesPerPeak);
        float peak = 0.0F;
        for (const auto& channel : piece.overview->peaks) {
            const long long count = static_cast<long long>(channel.size());
            long long p0 = std::max<long long>(0, static_cast<long long>(std::floor(n0 / fpp)));
            long long p1 = std::min<long long>(count, std::max(p0 + 1, static_cast<long long>(std::ceil(n1 / fpp))));
            for (long long p = p0; p < p1; ++p)
                peak = std::max(peak, std::max(std::abs(channel[static_cast<std::size_t>(p)].minimum),
                                               std::abs(channel[static_cast<std::size_t>(p)].maximum)));
        }
        return peak;
    }
    return -1.0F;
}

double nearestZeroCrossing(const PieceView& piece, double rel, double maxDistance) {
    if (piece.detail == nullptr || piece.detail->audio.frames() < 2U || piece.detail->audio.channels() == 0U) return rel;
    if (rel < piece.startRel || rel > piece.endRel()) return rel;
    const auto& audio = piece.detail->audio;
    const float* data = audio.channelData(0U);
    const long long frames = static_cast<long long>(audio.frames());
    const double n = piece.nativePosition(rel);
    const long long reach = std::max<long long>(1, static_cast<long long>(std::ceil(maxDistance * piece.fileRate() / piece.projectRate)));
    const long long centre = static_cast<long long>(std::floor(n));
    auto crossesAt = [&](long long i) {
        if (i < 0 || i + 1 >= frames) return false;
        const float s0 = data[i], s1 = data[i + 1];
        return (s0 <= 0.0F && s1 > 0.0F) || (s0 >= 0.0F && s1 < 0.0F);
    };
    for (long long d = 0; d <= reach; ++d) {
        for (const long long i : {centre - d, centre + d}) {
            if (!crossesAt(i)) continue;
            const float s0 = data[i], s1 = data[i + 1];
            const double frac = (s1 == s0) ? 0.0 : static_cast<double>(-s0) / static_cast<double>(s1 - s0);
            const double found = piece.relPosition(static_cast<double>(i) + std::min(1.0, std::max(0.0, frac)));
            if (found < piece.startRel || found > piece.endRel()) continue;
            return found;
        }
    }
    return rel;
}

} // namespace silveton
