#include "silveton/AudioBuffer.h"
#include <algorithm>
#include <stdexcept>

namespace silveton {

AudioBuffer::AudioBuffer(std::size_t channels, std::size_t frames) { resize(channels, frames); }

void AudioBuffer::resize(std::size_t channels, std::size_t frames) {
    data_.assign(channels, std::vector<float>(frames, 0.0F));
}

void AudioBuffer::clear() noexcept {
    for (auto& channel : data_) std::fill(channel.begin(), channel.end(), 0.0F);
}

float* AudioBuffer::channelData(std::size_t channel) {
    if (channel >= data_.size()) throw std::out_of_range("AudioBuffer channel");
    return data_[channel].data();
}

const float* AudioBuffer::channelData(std::size_t channel) const {
    if (channel >= data_.size()) throw std::out_of_range("AudioBuffer channel");
    return data_[channel].data();
}

float& AudioBuffer::sample(std::size_t channel, std::size_t frame) {
    if (channel >= data_.size() || frame >= data_[channel].size()) throw std::out_of_range("AudioBuffer sample");
    return data_[channel][frame];
}

const float& AudioBuffer::sample(std::size_t channel, std::size_t frame) const {
    if (channel >= data_.size() || frame >= data_[channel].size()) throw std::out_of_range("AudioBuffer sample");
    return data_[channel][frame];
}

} // namespace silveton
