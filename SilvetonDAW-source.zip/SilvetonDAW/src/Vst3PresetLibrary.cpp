#include "silveton/Vst3PresetLibrary.h"
#include "silveton/Vst3ScannerIsolation.h"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <fstream>
#include <stdexcept>

#if defined(_WIN32)
#include <windows.h>
#else
#include <dirent.h>
#include <sys/stat.h>
#endif

namespace silveton {
namespace {
bool endsWithPreset(const std::string& path) {
    static const std::string suffix = ".vstpreset";
    if (path.size() < suffix.size()) return false;
    const std::size_t off = path.size() - suffix.size();
    for (std::size_t i=0;i<suffix.size();++i)
        if (static_cast<char>(std::tolower(static_cast<unsigned char>(path[off+i]))) != suffix[i]) return false;
    return true;
}
std::vector<std::string> splitTabs(const std::string& line){std::vector<std::string> out;std::size_t a=0;bool esc=false;for(std::size_t i=0;i<line.size();++i){if(esc){esc=false;continue;}if(line[i]=='\\'){esc=true;continue;}if(line[i]=='\t'){out.push_back(line.substr(a,i-a));a=i+1;}}out.push_back(line.substr(a));return out;}
#ifndef _WIN32
void scanPosix(const std::string& dir, bool recursive, std::vector<std::string>& out) {
    DIR* d = ::opendir(dir.c_str()); if(!d) return;
    while (dirent* e = ::readdir(d)) {
        const std::string name=e->d_name; if(name=="."||name=="..")continue;
        const std::string path = dir + (dir.empty()||dir.back()=='/'?"":"/") + name;
        struct stat st{}; if(::stat(path.c_str(),&st)!=0)continue;
        if(S_ISDIR(st.st_mode)){ if(recursive)scanPosix(path,true,out); }
        else if(S_ISREG(st.st_mode)&&endsWithPreset(path)) out.push_back(path);
    }
    ::closedir(d);
}
#else
void scanWindows(const std::string& dir, bool recursive, std::vector<std::string>& out) {
    WIN32_FIND_DATAA data{}; const std::string pattern=dir+"\\*"; HANDLE h=FindFirstFileA(pattern.c_str(),&data); if(h==INVALID_HANDLE_VALUE)return;
    do { std::string name=data.cFileName; if(name=="."||name=="..")continue; std::string path=dir+"\\"+name; if((data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)!=0){if(recursive)scanWindows(path,true,out);}else if(endsWithPreset(path))out.push_back(path); } while(FindNextFileA(h,&data));
    FindClose(h);
}
#endif
}

Vst3PresetEntry* Vst3PresetLibrary::find(const std::string& path) noexcept { auto it=std::find_if(entries_.begin(),entries_.end(),[&](const auto&e){return e.path==path;});return it==entries_.end()?nullptr:&*it; }
const Vst3PresetEntry* Vst3PresetLibrary::find(const std::string& path) const noexcept { auto it=std::find_if(entries_.begin(),entries_.end(),[&](const auto&e){return e.path==path;});return it==entries_.end()?nullptr:&*it; }
std::string Vst3PresetLibrary::displayNameFromPath(const std::string& path){auto slash=path.find_last_of("/\\");std::string n=slash==std::string::npos?path:path.substr(slash+1);if(endsWithPreset(n))n.resize(n.size()-10U);return n;}
void Vst3PresetLibrary::upsert(Vst3PresetEntry entry){if(entry.path.empty())throw std::invalid_argument("preset path empty");if(entry.name.empty())entry.name=displayNameFromPath(entry.path);if(auto* e=find(entry.path)){const bool fav=e->favorite;const auto recent=e->lastUsedSerial;*e=std::move(entry);e->favorite=e->favorite||fav;e->lastUsedSerial=std::max(e->lastUsedSerial,recent);return;}entries_.push_back(std::move(entry));}

void Vst3PresetLibrary::scanDirectory(const std::string& directory, bool recursive){if(directory.empty())throw std::invalid_argument("preset directory empty");std::vector<std::string> paths;
#ifdef _WIN32
scanWindows(directory,recursive,paths);
#else
scanPosix(directory,recursive,paths);
#endif
for(const auto&p:paths){if(find(p)==nullptr)upsert({p,displayNameFromPath(p),{}, {},false,0U});}}

std::vector<Vst3PresetEntry> Vst3PresetLibrary::forPlugin(const std::string& module,const std::string& cls) const {std::vector<Vst3PresetEntry> out;for(const auto&e:entries_)if((e.modulePath.empty()||e.modulePath==module)&&(e.classId.empty()||e.classId==cls))out.push_back(e);return out;}
std::vector<Vst3PresetEntry> Vst3PresetLibrary::favorites() const {std::vector<Vst3PresetEntry> out;for(const auto&e:entries_)if(e.favorite)out.push_back(e);return out;}
std::vector<Vst3PresetEntry> Vst3PresetLibrary::recent(std::size_t limit) const {auto out=entries_;out.erase(std::remove_if(out.begin(),out.end(),[](const auto&e){return e.lastUsedSerial==0U;}),out.end());std::sort(out.begin(),out.end(),[](const auto&a,const auto&b){return a.lastUsedSerial>b.lastUsedSerial;});if(out.size()>limit)out.resize(limit);return out;}
bool Vst3PresetLibrary::setFavorite(const std::string& path,bool favorite) noexcept {if(auto*e=find(path)){e->favorite=favorite;return true;}return false;}

bool Vst3PresetLibrary::savePreset(IVst3PluginInstance& instance,const std::string& path,const std::string& name){if(path.empty()||!endsWithPreset(path))return false;if(!instance.savePreset(path))return false;Vst3PresetEntry e{path,name,instance.modulePath(),instance.classId(),false,++serial_};if(const auto*old=find(path))e.favorite=old->favorite;upsert(std::move(e));return true;}
bool Vst3PresetLibrary::loadPreset(IVst3PluginInstance& instance,const std::string& path){if(const auto*e=find(path)){if((!e->classId.empty()&&e->classId!=instance.classId())||(!e->modulePath.empty()&&e->modulePath!=instance.modulePath()))return false;}if(!instance.loadPreset(path))return false;if(auto*e=find(path)){e->lastUsedSerial=++serial_;if(e->modulePath.empty())e->modulePath=instance.modulePath();if(e->classId.empty())e->classId=instance.classId();}else upsert({path,displayNameFromPath(path),instance.modulePath(),instance.classId(),false,++serial_});return true;}

void Vst3PresetLibrary::saveIndex(const std::string& path) const {const std::string tmp=path+".tmp";std::ofstream out(tmp.c_str(),std::ios::binary|std::ios::trunc);if(!out)throw std::runtime_error("cannot write preset index");out<<"SILVETON_PRESET_INDEX_V1\t"<<serial_<<'\n';for(const auto&e:entries_)out<<encodeVst3ScanField(e.path)<<'\t'<<encodeVst3ScanField(e.name)<<'\t'<<encodeVst3ScanField(e.modulePath)<<'\t'<<encodeVst3ScanField(e.classId)<<'\t'<<e.favorite<<'\t'<<e.lastUsedSerial<<'\n';out.flush();if(!out)throw std::runtime_error("preset index write failed");out.close();(void)std::remove(path.c_str());if(std::rename(tmp.c_str(),path.c_str())!=0){(void)std::remove(tmp.c_str());throw std::runtime_error("cannot replace preset index");}}
void Vst3PresetLibrary::loadIndex(const std::string& path){std::ifstream in(path.c_str(),std::ios::binary);if(!in)return;std::string line;if(!std::getline(in,line))throw std::runtime_error("invalid preset index");auto header=splitTabs(line);if(header.size()!=2U||header[0]!="SILVETON_PRESET_INDEX_V1")throw std::runtime_error("invalid preset index");std::uint64_t newSerial=0U;try{newSerial=std::stoull(header[1]);}catch(...){throw std::runtime_error("invalid preset serial");}std::vector<Vst3PresetEntry> next;while(std::getline(in,line)){if(line.empty())continue;auto f=splitTabs(line);if(f.size()!=6U)throw std::runtime_error("invalid preset index row");Vst3PresetEntry e;std::string fav,recent;if(!decodeVst3ScanField(f[0],e.path)||!decodeVst3ScanField(f[1],e.name)||!decodeVst3ScanField(f[2],e.modulePath)||!decodeVst3ScanField(f[3],e.classId))throw std::runtime_error("invalid preset index field");e.favorite=f[4]=="1";try{e.lastUsedSerial=std::stoull(f[5]);}catch(...){throw std::runtime_error("invalid preset recent serial");}if(e.path.empty())throw std::runtime_error("empty preset path");if(std::any_of(next.begin(),next.end(),[&](const auto&x){return x.path==e.path;}))throw std::runtime_error("duplicate preset index path");next.push_back(std::move(e));}entries_.swap(next);serial_=newSerial;}

} // namespace silveton
