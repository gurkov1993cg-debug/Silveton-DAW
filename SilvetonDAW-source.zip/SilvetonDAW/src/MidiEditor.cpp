#include "silveton/MidiEditor.h"
#include <stdexcept>
#include <utility>

namespace silveton {

void MidiEditor::push(MidiSequence before, MidiSequence after) {
    undo_.push_back({std::move(before), std::move(after)});
    if (undo_.size() > kMaxUndoSteps) undo_.erase(undo_.begin());
    redo_.clear();
}

std::uint64_t MidiEditor::addNote(MusicalMidiNote note) {
    MidiSequence before = sequence_;
    const auto id = sequence_.addNote(note);
    push(std::move(before), sequence_);
    return id;
}

std::uint64_t MidiEditor::addController(double qn, std::uint8_t channel, std::uint8_t controller, std::uint8_t value) {
    if (channel > 15U || controller > 127U || value > 127U) throw std::invalid_argument("invalid MIDI controller");
    MidiSequence before = sequence_;
    const auto id = sequence_.addMessage({0U, qn, static_cast<std::uint8_t>(0xB0U | channel), controller, value, false});
    push(std::move(before), sequence_);
    return id;
}

std::uint64_t MidiEditor::addPitchBend(double qn, std::uint8_t channel, std::uint16_t value14Bit) {
    if (channel > 15U || value14Bit > 16383U) throw std::invalid_argument("invalid MIDI pitch bend");
    MidiSequence before = sequence_;
    const auto id = sequence_.addMessage({0U, qn, static_cast<std::uint8_t>(0xE0U | channel),
                                          static_cast<std::uint8_t>(value14Bit & 0x7FU),
                                          static_cast<std::uint8_t>((value14Bit >> 7U) & 0x7FU), false});
    push(std::move(before), sequence_);
    return id;
}

std::uint64_t MidiEditor::addProgramChange(double qn, std::uint8_t channel, std::uint8_t program) {
    if (channel > 15U || program > 127U) throw std::invalid_argument("invalid MIDI program change");
    MidiSequence before = sequence_;
    const auto id = sequence_.addMessage({0U, qn, static_cast<std::uint8_t>(0xC0U | channel), program, 0U, false});
    push(std::move(before), sequence_);
    return id;
}

bool MidiEditor::deleteNote(std::uint64_t id) { return mutate([&]{ return sequence_.removeNote(id); }); }
bool MidiEditor::deleteMessage(std::uint64_t id) { return mutate([&]{ return sequence_.removeMessage(id); }); }
bool MidiEditor::moveNote(std::uint64_t id, double qn) { return mutate([&]{ return sequence_.moveNote(id, qn); }); }
bool MidiEditor::resizeNote(std::uint64_t id, double qn) { return mutate([&]{ return sequence_.resizeNote(id, qn); }); }
bool MidiEditor::setVelocity(std::uint64_t id, std::uint8_t v) { return mutate([&]{ return sequence_.setNoteVelocity(id, v); }); }
bool MidiEditor::setReleaseVelocity(std::uint64_t id, std::uint8_t v) { return mutate([&]{ return sequence_.setNoteReleaseVelocity(id, v); }); }
bool MidiEditor::setPitch(std::uint64_t id, std::uint8_t pitch) { return mutate([&]{ return sequence_.setNotePitch(id, pitch); }); }
bool MidiEditor::setChannel(std::uint64_t id, std::uint8_t channel) { return mutate([&]{ return sequence_.setNoteChannel(id, channel); }); }
bool MidiEditor::setNoteMuted(std::uint64_t id, bool muted) { return mutate([&]{ return sequence_.setNoteMuted(id, muted); }); }
bool MidiEditor::moveMessage(std::uint64_t id, double qn) { return mutate([&]{ return sequence_.moveMessage(id, qn); }); }
bool MidiEditor::setMessageMuted(std::uint64_t id, bool muted) { return mutate([&]{ return sequence_.setMessageMuted(id, muted); }); }

bool MidiEditor::setControllerValue(std::uint64_t id, std::uint8_t value) {
    if (value > 127U) return false;
    return mutate([&]{
        for (const auto& m : sequence_.messages()) {
            if (m.id != id) continue;
            const auto type = static_cast<std::uint8_t>(m.status & 0xF0U);
            if (type != 0xB0U && type != 0xA0U && type != 0xD0U) return false;
            return sequence_.setMessageData(id, m.status, m.data1, value);
        }
        return false;
    });
}

void MidiEditor::quantize(double divisionsPerQuarter, double strength) {
    MidiSequence before = sequence_;
    sequence_.quantize(divisionsPerQuarter, strength);
    push(std::move(before), sequence_);
}

void MidiEditor::transpose(int semitones) {
    MidiSequence before = sequence_;
    sequence_.transpose(semitones);
    push(std::move(before), sequence_);
}

bool MidiEditor::undo() {
    if (undo_.empty()) return false;
    Command command = std::move(undo_.back());
    undo_.pop_back();
    sequence_ = command.before;
    redo_.push_back(std::move(command));
    return true;
}

bool MidiEditor::redo() {
    if (redo_.empty()) return false;
    Command command = std::move(redo_.back());
    redo_.pop_back();
    sequence_ = command.after;
    undo_.push_back(std::move(command));
    if (undo_.size() > kMaxUndoSteps) undo_.erase(undo_.begin());
    return true;
}

} // namespace silveton
