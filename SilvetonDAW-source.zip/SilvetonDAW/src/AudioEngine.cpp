#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/DiskStream.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <thread>

namespace silveton {

namespace {

std::int64_t cycleMappedSample(std::int64_t sample,
                               bool cycleEnabled,
                               std::int64_t cycleStart,
                               std::int64_t cycleEnd) noexcept {
    if (!cycleEnabled || cycleEnd <= cycleStart || sample < cycleEnd) return sample;
    const std::int64_t length = cycleEnd - cycleStart;
    if (sample < cycleStart) return sample;
    return cycleStart + ((sample - cycleStart) % length);
}

std::uint32_t framesUntilCycleBoundary(std::int64_t timelineSample,
                                       std::uint32_t remaining,
                                       bool cycleEnabled,
                                       std::int64_t cycleStart,
                                       std::int64_t cycleEnd) noexcept {
    if (!cycleEnabled || cycleEnd <= cycleStart || timelineSample >= cycleEnd) return remaining;
    const std::int64_t untilEnd = cycleEnd - timelineSample;
    if (untilEnd <= 0) return remaining;
    return static_cast<std::uint32_t>(std::min<std::int64_t>(untilEnd, static_cast<std::int64_t>(remaining)));
}

} // namespace

AudioEngine::AudioEngine() {
    for (auto& state : voicePlanStates_) state.store(PlanSlotState::Free, std::memory_order_relaxed);
    voicePlanStates_[0].store(PlanSlotState::Live, std::memory_order_relaxed);
    livePlanIndex_.store(0, std::memory_order_relaxed);
    pendingPlanIndex_.store(kNoPendingPlan, std::memory_order_relaxed);

    for (auto& state : graphPlanStates_) state.store(GraphSlotState::Free, std::memory_order_relaxed);
    graphPlanStates_[0].store(GraphSlotState::Live, std::memory_order_relaxed);
    liveGraphIndex_.store(0, std::memory_order_relaxed);
    pendingGraphIndex_.store(kNoPendingPlan, std::memory_order_relaxed);

    for (auto& state : tempoMapStates_) state.store(TempoSlotState::Free, std::memory_order_relaxed);
    tempoMaps_[0] = initialTempoMap_;
    tempoMapStates_[0].store(TempoSlotState::Live, std::memory_order_relaxed);
    liveTempoMapIndex_.store(0, std::memory_order_relaxed);
    pendingTempoMapIndex_.store(kNoPendingPlan, std::memory_order_relaxed);
}

float AudioEngine::dbToLinear(float db) noexcept {
    return static_cast<float>(MixMath::dbToLinear(static_cast<double>(db)));
}

void AudioEngine::setProcessorGraph(ProcessorGraph* graph,
                                    std::uint32_t maxCompensationSamples) {
    if (prepared_) throw std::logic_error("initial processor graph must be attached before engine prepare");
    if (graph != nullptr) {
        if (graph->nodeCount() == 0U) throw std::invalid_argument("processor graph has no nodes");
        if (tracks_.size() > graph->nodeCount())
            throw std::length_error("processor graph has fewer nodes than existing tracks");
    }
    initialProcessorGraph_ = graph;
    initialProcessorGraphMaxCompensation_ = maxCompensationSamples;
    controlGraphNodeCount_.store(graph == nullptr ? 0U : graph->nodeCount(), std::memory_order_release);
}

ProcessorGraph* AudioEngine::processorGraph() const noexcept {
    if (!prepared_) return initialProcessorGraph_;
    return liveGraphPlan().graph;
}

bool AudioEngine::processorGraphPublicationPending() const noexcept {
    return pendingGraphIndex_.load(std::memory_order_acquire) != kNoPendingPlan;
}

std::uint64_t AudioEngine::liveProcessorGraphGeneration() const noexcept {
    if (!prepared_) return 0U;
    return liveGraphPlan().generation;
}

std::uint64_t AudioEngine::publishProcessorGraphLatencyRefresh() {
    if (!prepared_) throw std::logic_error("processor graph latency refresh requires prepared engine");
    if (processorGraphPublicationPending())
        throw std::logic_error("processor graph publication already pending");

    const GraphRenderPlan& current = liveGraphPlan();
    if (current.graph == nullptr) throw std::logic_error("no live processor graph to refresh");
    auto replacement = current.graph->cloneDefinition();
    return publishProcessorGraph(std::move(replacement), current.maxCompensationSamples);
}

void AudioEngine::clearGraphRenderPlan(GraphRenderPlan& plan) noexcept {
    plan.graph = nullptr;
    plan.ownedGraph.reset();
    plan.maxCompensationSamples = 16384U;
    plan.nodeCount = 0U;
    plan.blockCapacity = 0U;
    plan.sourceLeft.clear();
    plan.sourceRight.clear();
    plan.sourceBuses.clear();
    plan.masterLeft.clear();
    plan.masterRight.clear();
    plan.generation = 0U;
}

void AudioEngine::prepareGraphRenderPlan(GraphRenderPlan& plan,
                                         std::unique_ptr<ProcessorGraph> ownedGraph,
                                         ProcessorGraph* externalGraph,
                                         std::uint32_t maxCompensationSamples,
                                         std::uint64_t generation,
                                         const ProcessorGraph* predecessor) {
    clearGraphRenderPlan(plan);
    plan.ownedGraph = std::move(ownedGraph);
    plan.graph = plan.ownedGraph != nullptr ? plan.ownedGraph.get() : externalGraph;
    plan.maxCompensationSamples = maxCompensationSamples;
    plan.generation = generation;

    if (plan.graph == nullptr) return;
    if (plan.graph->nodeCount() == 0U) throw std::invalid_argument("processor graph has no nodes");
    if (tracks_.size() > plan.graph->nodeCount())
        throw std::length_error("processor graph has fewer nodes than existing tracks");

    if (predecessor == nullptr)
        plan.graph->prepare(config_.sampleRate, config_.blockSize, maxCompensationSamples);
    else
        plan.graph->prepareForPublication(config_.sampleRate, config_.blockSize, maxCompensationSamples, predecessor);

    plan.nodeCount = plan.graph->nodeCount();
    plan.blockCapacity = config_.blockSize;
    if (plan.nodeCount > std::vector<float>().max_size() / plan.blockCapacity)
        throw std::length_error("processor graph source buffer size overflow");
    const std::size_t graphSamples = plan.nodeCount * plan.blockCapacity;
    plan.sourceLeft.assign(graphSamples, 0.0F);
    plan.sourceRight.assign(graphSamples, 0.0F);
    plan.sourceBuses.resize(plan.nodeCount);
    for (std::size_t node = 0U; node < plan.nodeCount; ++node) {
        const std::size_t base = node * plan.blockCapacity;
        plan.sourceBuses[node] = {plan.sourceLeft.data() + base, plan.sourceRight.data() + base};
    }
    plan.masterLeft.assign(config_.blockSize, 0.0F);
    plan.masterRight.assign(config_.blockSize, 0.0F);
}

std::size_t AudioEngine::reclaimRetiredProcessorGraphs() noexcept {
    std::size_t reclaimed = 0U;
    for (std::size_t i = 0U; i < graphPlanStates_.size(); ++i) {
        GraphSlotState expected = GraphSlotState::Retired;
        if (!graphPlanStates_[i].compare_exchange_strong(expected,
                                                         GraphSlotState::Writing,
                                                         std::memory_order_acq_rel,
                                                         std::memory_order_acquire)) {
            continue;
        }
        clearGraphRenderPlan(graphPlans_[i]);
        graphPlanStates_[i].store(GraphSlotState::Free, std::memory_order_release);
        ++reclaimed;
    }
    return reclaimed;
}

std::size_t AudioEngine::acquireFreeGraphSlot() {
    (void)reclaimRetiredProcessorGraphs();
    for (;;) {
        for (std::size_t i = 0U; i < graphPlanStates_.size(); ++i) {
            GraphSlotState expected = GraphSlotState::Free;
            if (graphPlanStates_[i].compare_exchange_strong(expected,
                                                            GraphSlotState::Writing,
                                                            std::memory_order_acq_rel,
                                                            std::memory_order_acquire)) {
                clearGraphRenderPlan(graphPlans_[i]);
                return i;
            }
        }
        std::this_thread::yield();
    }
}

void AudioEngine::publishPendingGraph(std::size_t slot) {
    graphPlanStates_[slot].store(GraphSlotState::Pending, std::memory_order_release);
    const int expected = kNoPendingPlan;
    int noPending = expected;
    if (!pendingGraphIndex_.compare_exchange_strong(noPending,
                                                    static_cast<int>(slot),
                                                    std::memory_order_acq_rel,
                                                    std::memory_order_acquire)) {
        graphPlanStates_[slot].store(GraphSlotState::Writing, std::memory_order_release);
        clearGraphRenderPlan(graphPlans_[slot]);
        graphPlanStates_[slot].store(GraphSlotState::Free, std::memory_order_release);
        throw std::logic_error("processor graph publication already pending");
    }
}

std::uint64_t AudioEngine::publishProcessorGraph(std::unique_ptr<ProcessorGraph> graph,
                                                 std::uint32_t maxCompensationSamples) {
    if (!prepared_) throw std::logic_error("live processor graph publication requires prepared engine");
    if (processorGraphPublicationPending())
        throw std::logic_error("processor graph publication already pending");
    if (graph != nullptr && tracks_.size() > graph->nodeCount())
        throw std::length_error("processor graph has fewer nodes than existing tracks");

    const ProcessorGraph* predecessor = liveGraphPlan().graph;
    const std::size_t slot = acquireFreeGraphSlot();
    const std::uint64_t generation = nextGraphGeneration_++;
    try {
        prepareGraphRenderPlan(graphPlans_[slot],
                               std::move(graph),
                               nullptr,
                               maxCompensationSamples,
                               generation,
                               predecessor);
        publishPendingGraph(slot);
        controlGraphNodeCount_.store(graphPlans_[slot].nodeCount, std::memory_order_release);
    } catch (...) {
        clearGraphRenderPlan(graphPlans_[slot]);
        graphPlanStates_[slot].store(GraphSlotState::Free, std::memory_order_release);
        throw;
    }
    return generation;
}

void AudioEngine::adoptPendingProcessorGraph() noexcept {
    const int next = pendingGraphIndex_.load(std::memory_order_acquire);
    if (next == kNoPendingPlan) return;

    const int old = liveGraphIndex_.exchange(next, std::memory_order_acq_rel);
    graphPlanStates_[static_cast<std::size_t>(next)].store(GraphSlotState::Live, std::memory_order_release);
    if (old != next && old >= 0)
        graphPlanStates_[static_cast<std::size_t>(old)].store(GraphSlotState::Retired, std::memory_order_release);

    // Publication acknowledgement comes last. A control thread that observes
    // pending=false is therefore guaranteed to see the completed Live/Retired
    // state transition and may safely reclaim the predecessor before building
    // another generation.
    pendingGraphIndex_.store(kNoPendingPlan, std::memory_order_release);
}

AudioEngine::GraphRenderPlan& AudioEngine::liveGraphPlan() noexcept {
    const int index = liveGraphIndex_.load(std::memory_order_acquire);
    return graphPlans_[static_cast<std::size_t>(index)];
}

const AudioEngine::GraphRenderPlan& AudioEngine::liveGraphPlan() const noexcept {
    const int index = liveGraphIndex_.load(std::memory_order_acquire);
    return graphPlans_[static_cast<std::size_t>(index)];
}

void AudioEngine::setTempo(double tempo) {
    if (!std::isfinite(tempo) || tempo <= 0.0) throw std::invalid_argument("tempo must be positive");
    tempo_.store(tempo, std::memory_order_release);
    TempoMap replacement;
    replacement.setSampleRate(prepared_ ? config_.sampleRate : initialTempoMap_.sampleRate());
    replacement.setInitialTempo(tempo);
    if (!prepared_) {
        initialTempoMap_ = replacement;
        return;
    }
    (void)publishTempoMap(replacement);
}

void AudioEngine::setTempoMap(const TempoMap& map) {
    if (prepared_) throw std::logic_error("initial tempo map must be attached before engine prepare");
    initialTempoMap_ = map;
    tempo_.store(initialTempoMap_.tempoAtSample(0), std::memory_order_release);
}

bool AudioEngine::tempoMapPublicationPending() const noexcept {
    return pendingTempoMapIndex_.load(std::memory_order_acquire) != kNoPendingPlan;
}

std::uint64_t AudioEngine::liveTempoMapGeneration() const noexcept {
    return liveTempoMapGeneration_.load(std::memory_order_acquire);
}

std::size_t AudioEngine::acquireFreeTempoSlot() {
    for (;;) {
        for (std::size_t i = 0U; i < tempoMapStates_.size(); ++i) {
            TempoSlotState expected = TempoSlotState::Free;
            if (tempoMapStates_[i].compare_exchange_strong(expected,
                                                           TempoSlotState::Writing,
                                                           std::memory_order_acq_rel,
                                                           std::memory_order_acquire))
                return i;
        }
        std::this_thread::yield();
    }
}

void AudioEngine::publishPendingTempoMap(std::size_t slot) noexcept {
    tempoMapStates_[slot].store(TempoSlotState::Pending, std::memory_order_release);
    pendingTempoMapIndex_.store(static_cast<int>(slot), std::memory_order_release);
}

std::uint64_t AudioEngine::publishTempoMap(const TempoMap& map) {
    if (!prepared_) throw std::logic_error("live tempo-map publication requires prepared engine");
    if (tempoMapPublicationPending()) throw std::logic_error("tempo-map publication already pending");
    const std::size_t slot = acquireFreeTempoSlot();
    try {
        tempoMaps_[slot] = map;
        tempoMaps_[slot].setSampleRate(config_.sampleRate);
        const std::uint64_t generation = nextTempoMapGeneration_++;
        tempoMapGenerations_[slot] = generation;
        publishPendingTempoMap(slot);
        return generation;
    } catch (...) {
        tempoMapStates_[slot].store(TempoSlotState::Free, std::memory_order_release);
        throw;
    }
}

void AudioEngine::adoptPendingTempoMap() noexcept {
    const int next = pendingTempoMapIndex_.load(std::memory_order_acquire);
    if (next == kNoPendingPlan) return;
    const int old = liveTempoMapIndex_.exchange(next, std::memory_order_acq_rel);
    tempoMapStates_[static_cast<std::size_t>(next)].store(TempoSlotState::Live, std::memory_order_release);
    liveTempoMapGeneration_.store(tempoMapGenerations_[static_cast<std::size_t>(next)], std::memory_order_release);
    tempo_.store(tempoMaps_[static_cast<std::size_t>(next)].tempoAtSample(transport_.positionSamples()),
                 std::memory_order_release);
    if (old != next && old >= 0)
        tempoMapStates_[static_cast<std::size_t>(old)].store(TempoSlotState::Free, std::memory_order_release);
    pendingTempoMapIndex_.store(kNoPendingPlan, std::memory_order_release);
}

const TempoMap& AudioEngine::liveTempoMap() const noexcept {
    return tempoMaps_[static_cast<std::size_t>(liveTempoMapIndex_.load(std::memory_order_acquire))];
}

TempoMapPosition AudioEngine::musicalPositionAtSample(std::int64_t sample) const noexcept {
    return prepared_ ? liveTempoMap().positionAtSample(sample) : initialTempoMap_.positionAtSample(sample);
}

void AudioEngine::setRecorder(Recorder* recorder) noexcept {
    if (recorder_.load(std::memory_order_acquire) != nullptr) detachRecorderAndWait();
    if (recorder != nullptr) {
        recordedTimelineSpanCount_.store(0U, std::memory_order_relaxed);
        recordedFrameCursor_.store(0U, std::memory_order_relaxed);
        recordedTimelineSpanOverflow_.store(false, std::memory_order_relaxed);
    }
    recorder_.store(recorder, std::memory_order_release);
}

void AudioEngine::detachRecorderAndWait() noexcept {
    recorder_.store(nullptr, std::memory_order_release);
    while (recordingCallbackUsers_.load(std::memory_order_acquire) != 0U) std::this_thread::yield();
}

void AudioEngine::appendRecordedTimelineSpan(std::int64_t projectStartSample,
                                             std::uint32_t frames,
                                             std::uint64_t cyclePass) noexcept {
    if (frames == 0U) return;
    const std::uint64_t recorderStart = recordedFrameCursor_.fetch_add(frames, std::memory_order_relaxed);
    const std::size_t count = recordedTimelineSpanCount_.load(std::memory_order_acquire);
    if (count != 0U) {
        auto& last = recordedTimelineSpans_[count - 1U];
        const std::uint64_t lastRecorderStart = last.recorderFrameStart.load(std::memory_order_acquire);
        const std::int64_t lastProjectStart = last.projectStartSample.load(std::memory_order_acquire);
        const std::uint32_t lastFrames = last.frames.load(std::memory_order_acquire);
        const std::uint64_t lastPass = last.cyclePass.load(std::memory_order_acquire);
        const bool recorderContiguous = lastRecorderStart <= std::numeric_limits<std::uint64_t>::max() - lastFrames &&
            lastRecorderStart + lastFrames == recorderStart;
        const bool projectContiguous = lastProjectStart <= std::numeric_limits<std::int64_t>::max() - static_cast<std::int64_t>(lastFrames) &&
            lastProjectStart + static_cast<std::int64_t>(lastFrames) == projectStartSample;
        if (lastPass == cyclePass && recorderContiguous && projectContiguous &&
            lastFrames <= std::numeric_limits<std::uint32_t>::max() - frames) {
            last.frames.store(lastFrames + frames, std::memory_order_release);
            return;
        }
    }

    if (count >= kMaxRecordedTimelineSpans) {
        recordedTimelineSpanOverflow_.store(true, std::memory_order_release);
        return;
    }
    auto& slot = recordedTimelineSpans_[count];
    slot.recorderFrameStart.store(recorderStart, std::memory_order_relaxed);
    slot.projectStartSample.store(projectStartSample, std::memory_order_relaxed);
    slot.frames.store(frames, std::memory_order_relaxed);
    slot.cyclePass.store(cyclePass, std::memory_order_relaxed);
    recordedTimelineSpanCount_.store(count + 1U, std::memory_order_release);
}

std::vector<RecordedTimelineSpan> AudioEngine::recordedTimelineSpans() const {
    const std::size_t count = recordedTimelineSpanCount_.load(std::memory_order_acquire);
    std::vector<RecordedTimelineSpan> out;
    out.reserve(count);
    for (std::size_t i = 0U; i < count; ++i) {
        const auto& slot = recordedTimelineSpans_[i];
        out.push_back({slot.recorderFrameStart.load(std::memory_order_acquire),
                       slot.projectStartSample.load(std::memory_order_acquire),
                       slot.frames.load(std::memory_order_acquire),
                       slot.cyclePass.load(std::memory_order_acquire)});
    }
    return out;
}

void AudioEngine::setPunchRange(bool enabled, std::int64_t punchInSample, std::int64_t punchOutSample) {
    if (enabled) {
        if (punchInSample < 0 || punchOutSample <= punchInSample)
            throw std::invalid_argument("invalid punch range");
        punchInSample_.store(punchInSample, std::memory_order_release);
        punchOutSample_.store(punchOutSample, std::memory_order_release);
    }
    punchEnabled_.store(enabled, std::memory_order_release);
}

void AudioEngine::prepare(const AudioDeviceConfig& config) {
    if (!std::isfinite(config.sampleRate) || config.sampleRate <= 0.0) throw std::invalid_argument("invalid engine sample rate");
    if (config.blockSize == 0U) throw std::invalid_argument("invalid engine block size");
    if (config.outputChannels < 2U) throw std::invalid_argument("engine milestone requires stereo output");
    config_ = config;
    transport_.setSampleRate(config.sampleRate);
    initialTempoMap_.setSampleRate(config.sampleRate);
    for (std::size_t i = 0U; i < tempoMaps_.size(); ++i) {
        tempoMapStates_[i].store(TempoSlotState::Free, std::memory_order_relaxed);
        tempoMapGenerations_[i] = 0U;
    }
    tempoMaps_[0] = initialTempoMap_;
    tempoMapStates_[0].store(TempoSlotState::Live, std::memory_order_release);
    liveTempoMapIndex_.store(0, std::memory_order_release);
    pendingTempoMapIndex_.store(kNoPendingPlan, std::memory_order_release);
    liveTempoMapGeneration_.store(0U, std::memory_order_release);
    nextTempoMapGeneration_ = 1U;
    tempo_.store(tempoMaps_[0].tempoAtSample(0), std::memory_order_release);
    mixLeft_.assign(config.blockSize, 0.0);
    mixRight_.assign(config.blockSize, 0.0);
    mixLeftCompensation_.assign(config.blockSize, 0.0);
    mixRightCompensation_.assign(config.blockSize, 0.0);
    // One reusable per-track scratch pair is enough because tracks are rendered
    // sequentially. It is allocated here and never resized in processAudio().
    trackScratchLeft_.assign(config.blockSize, 0.0F);
    trackScratchRight_.assign(config.blockSize, 0.0F);

    for (std::size_t i = 0U; i < graphPlans_.size(); ++i) {
        clearGraphRenderPlan(graphPlans_[i]);
        graphPlanStates_[i].store(GraphSlotState::Free, std::memory_order_relaxed);
    }
    graphPlanStates_[0].store(GraphSlotState::Writing, std::memory_order_relaxed);
    prepareGraphRenderPlan(graphPlans_[0],
                           nullptr,
                           initialProcessorGraph_,
                           initialProcessorGraphMaxCompensation_,
                           0U,
                           nullptr);
    graphPlanStates_[0].store(GraphSlotState::Live, std::memory_order_release);
    liveGraphIndex_.store(0, std::memory_order_release);
    pendingGraphIndex_.store(kNoPendingPlan, std::memory_order_release);
    controlGraphNodeCount_.store(graphPlans_[0].nodeCount, std::memory_order_release);
    nextGraphGeneration_ = 1U;

    masterGainCurrent_ = static_cast<double>(masterGainTargetLinear_.load(std::memory_order_acquire));
    prepared_ = true;
}

std::size_t AudioEngine::acquireFreePlanSlot() {
    // Single control-thread contract. A free slot always exists with the
    // Live/Pending/Free triple-buffer topology; yield only if we race the
    // audio thread while it is retiring the previous Live slot.
    for (;;) {
        for (std::size_t i = 0U; i < voicePlanStates_.size(); ++i) {
            PlanSlotState expected = PlanSlotState::Free;
            if (voicePlanStates_[i].compare_exchange_strong(expected,
                                                            PlanSlotState::Writing,
                                                            std::memory_order_acq_rel,
                                                            std::memory_order_acquire)) {
                return i;
            }
        }
        std::this_thread::yield();
    }
}

void AudioEngine::publishPendingPlan(std::size_t slot) noexcept {
    voicePlanStates_[slot].store(PlanSlotState::Pending, std::memory_order_release);
    const int replaced = pendingPlanIndex_.exchange(static_cast<int>(slot), std::memory_order_acq_rel);
    if (replaced != kNoPendingPlan && replaced != static_cast<int>(slot)) {
        voicePlanStates_[static_cast<std::size_t>(replaced)].store(PlanSlotState::Free, std::memory_order_release);
    }
}

void AudioEngine::adoptPendingPlan() noexcept {
    const int next = pendingPlanIndex_.exchange(kNoPendingPlan, std::memory_order_acq_rel);
    if (next == kNoPendingPlan) return;

    const int old = livePlanIndex_.exchange(next, std::memory_order_acq_rel);
    voicePlanStates_[static_cast<std::size_t>(next)].store(PlanSlotState::Live, std::memory_order_release);
    if (old != next && old >= 0) {
        voicePlanStates_[static_cast<std::size_t>(old)].store(PlanSlotState::Free, std::memory_order_release);
    }
}

const AudioEngine::VoicePlan& AudioEngine::livePlan() const noexcept {
    const int index = livePlanIndex_.load(std::memory_order_acquire);
    return voicePlans_[static_cast<std::size_t>(index)];
}

void AudioEngine::rebuildVoicePlan() {
    voicedTrackIndices_.clear();
    voicedTrackIndices_.reserve(tracks_.size());
    for (std::size_t i = 0; i < tracks_.size(); ++i) {
        const bool renderEnabled = !trackRenderMaskActive_ || trackRenderMask_[i] != 0U;
        if (tracks_[i].voiceEnabled && renderEnabled) voicedTrackIndices_.push_back(i);
    }
    std::stable_sort(voicedTrackIndices_.begin(), voicedTrackIndices_.end(), [this](std::size_t a, std::size_t b) {
        return tracks_[a].voicePriority > tracks_[b].voicePriority;
    });

    const std::size_t limit = voiceLimit_.load(std::memory_order_acquire);
    if (limit != 0U && voicedTrackIndices_.size() > limit) voicedTrackIndices_.resize(limit);
    controlVoicedTrackCount_.store(voicedTrackIndices_.size(), std::memory_order_release);

    const std::size_t slot = acquireFreePlanSlot();
    VoicePlan& plan = voicePlans_[slot];
    plan.count = 0U;
    plan.trackNodeMaskCount = tracks_.size();
    for (std::size_t i = 0U; i < tracks_.size(); ++i)
        plan.trackNodeEnabled[i] = (!trackRenderMaskActive_ || trackRenderMask_[i] != 0U) ? 1U : 0U;
    const PanDepth depth = panDepth_.load(std::memory_order_acquire);

    for (const std::size_t trackIndex : voicedTrackIndices_) {
        if (plan.count >= plan.voices.size()) break;
        const auto& track = tracks_[trackIndex];
        PreparedVoice voice;
        voice.trackIndex = trackIndex;
        voice.source = track.source;
        voice.diskSource = track.diskSource;
        voice.timelineStartSample = track.timelineStartSample;
        voice.sourceStartSample = track.sourceStartSample;
        voice.mute = track.mute;
        voice.useDualStereoPan = track.useDualStereoPan;
        voice.gainDb = track.gainDb;
        voice.pan = track.pan;
        if (track.gainAutomationDb != nullptr) {
            voice.gainAutomationDb = *track.gainAutomationDb;
            voice.hasGainAutomation = true;
        }
        if (track.panAutomation != nullptr) {
            voice.panAutomation = *track.panAutomation;
            voice.hasPanAutomation = true;
        }
        if (track.muteAutomation != nullptr) {
            voice.muteAutomation = *track.muteAutomation;
            voice.hasMuteAutomation = true;
        }
        voice.gain = MixMath::dbToLinear(static_cast<double>(track.gainDb));

        auto appendPreparedClip = [&voice](const TimelineClip& clip) {
            PreparedClip prepared;
            prepared.source = clip.source;
            prepared.diskSource = clip.diskSource;
            prepared.timelineStartSample = clip.timelineStartSample;
            prepared.sourceStartSample = clip.sourceStartSample;
            prepared.gain = MixMath::dbToLinear(static_cast<double>(clip.gainDb));
            prepared.mute = clip.mute;
            prepared.fadeInSamples = clip.fadeInSamples;
            prepared.fadeOutSamples = clip.fadeOutSamples;

            if (clip.source != nullptr) {
                prepared.sourceFrames = static_cast<std::uint64_t>(clip.source->frames());
                prepared.channels = clip.source->channels();
            } else {
                prepared.sourceFrames = clip.diskSource->frames();
                prepared.channels = static_cast<std::size_t>(clip.diskSource->channels());
            }
            const std::uint64_t available = prepared.sourceFrames - prepared.sourceStartSample;
            prepared.lengthSamples = clip.lengthSamples == 0U
                ? available
                : std::min(clip.lengthSamples, available);
            const std::uint64_t clipSourceEnd = prepared.sourceStartSample + prepared.lengthSamples;
            prepared.fadeInAnchorSourceSample = clip.fadeInAnchorSourceSample == TimelineClip::kAutoFadeAnchor
                ? prepared.sourceStartSample
                : clip.fadeInAnchorSourceSample;
            prepared.fadeOutAnchorSourceSample = clip.fadeOutAnchorSourceSample == TimelineClip::kAutoFadeAnchor
                ? clipSourceEnd
                : clip.fadeOutAnchorSourceSample;
            voice.clips.push_back(prepared);
        };

        if (!track.clips.empty()) {
            voice.clips.reserve(track.clips.size());
            for (const auto& clip : track.clips) appendPreparedClip(clip);
            voice.channels = voice.clips.front().channels;
        } else {
            TimelineClip legacy;
            legacy.source = track.source;
            legacy.diskSource = track.diskSource;
            legacy.timelineStartSample = track.timelineStartSample;
            legacy.sourceStartSample = track.sourceStartSample;
            appendPreparedClip(legacy);
            voice.sourceFrames = voice.clips.front().sourceFrames;
            voice.channels = voice.clips.front().channels;
        }

        if (voice.channels == 1U) {
            voice.monoPan = MixMath::monoPan(track.pan, depth);
        } else if (track.useDualStereoPan) {
            voice.stereoLeftPan = MixMath::monoPan(track.stereoLeftPan, depth);
            voice.stereoRightPan = MixMath::monoPan(track.stereoRightPan, depth);
        } else {
            voice.balance = MixMath::stereoBalance(track.pan);
        }
        plan.voices[plan.count++] = voice;
    }

    publishPendingPlan(slot);
}

void AudioEngine::clearTracks() {
    tracks_.clear();
    voicedTrackIndices_.clear();
    trackRenderMaskActive_ = false;
    trackRenderMask_.fill(0U);
    controlTrackCount_.store(0U, std::memory_order_release);
    controlVoicedTrackCount_.store(0U, std::memory_order_release);
    for (auto& meter : trackMeters_) {
        meter.leftPeak.store(0.0F, std::memory_order_relaxed);
        meter.rightPeak.store(0.0F, std::memory_order_relaxed);
        meter.leftRms.store(0.0F, std::memory_order_relaxed);
        meter.rightRms.store(0.0F, std::memory_order_relaxed);
    }
    rebuildVoicePlan();
}

void AudioEngine::addTrack(TimelineTrack track) {
    if (tracks_.size() >= kMaxEngineTracks) throw std::length_error("audio engine track limit is 512");
    const std::size_t graphNodeCount = controlGraphNodeCount_.load(std::memory_order_acquire);
    if (graphNodeCount != 0U && tracks_.size() >= graphNodeCount)
        throw std::length_error("processor graph has no node for additional track");
    auto validateSource = [](const AudioBuffer* source,
                             DiskAudioSource* diskSource,
                             std::uint64_t sourceStart,
                             std::uint64_t length,
                             std::int64_t timelineStart) -> std::size_t {
        const bool memorySource = source != nullptr;
        const bool diskBacked = diskSource != nullptr;
        if (memorySource == diskBacked) throw std::invalid_argument("clip must have exactly one audio source");
        const std::uint64_t frames = memorySource
            ? static_cast<std::uint64_t>(source->frames())
            : diskSource->frames();
        const std::size_t channels = memorySource
            ? source->channels()
            : static_cast<std::size_t>(diskSource->channels());
        if (channels == 0U) throw std::invalid_argument("clip source has no channels");
        if (sourceStart >= frames) throw std::invalid_argument("clip source offset outside buffer");
        const std::uint64_t available = frames - sourceStart;
        const std::uint64_t resolvedLength = length == 0U ? available : length;
        if (resolvedLength == 0U || resolvedLength > available)
            throw std::invalid_argument("clip length outside source");
        if (resolvedLength > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()))
            throw std::overflow_error("clip length exceeds timeline range");
        const std::int64_t signedLength = static_cast<std::int64_t>(resolvedLength);
        if (timelineStart > std::numeric_limits<std::int64_t>::max() - signedLength)
            throw std::overflow_error("clip end exceeds timeline range");
        return channels;
    };

    if (track.clips.empty()) {
        (void)validateSource(track.source, track.diskSource, track.sourceStartSample, 0U, track.timelineStartSample);
    } else {
        if (track.source != nullptr || track.diskSource != nullptr)
            throw std::invalid_argument("explicit clip track must not also use legacy track source");
        std::size_t trackChannels = 0U;
        for (const auto& clip : track.clips) {
            const std::size_t channels = validateSource(clip.source, clip.diskSource, clip.sourceStartSample,
                                                        clip.lengthSamples, clip.timelineStartSample);
            if (trackChannels == 0U) trackChannels = channels;
            else if (channels != trackChannels)
                throw std::invalid_argument("all clips on a track must have the same channel count");
            if (!std::isfinite(clip.gainDb)) throw std::invalid_argument("invalid clip gain");
            const std::uint64_t frames = clip.source != nullptr
                ? static_cast<std::uint64_t>(clip.source->frames())
                : clip.diskSource->frames();
            const std::uint64_t resolvedLength = clip.lengthSamples == 0U
                ? frames - clip.sourceStartSample
                : clip.lengthSamples;
            const std::uint64_t sourceEnd = clip.sourceStartSample + resolvedLength;
            const std::uint64_t fadeInAnchor = clip.fadeInAnchorSourceSample == TimelineClip::kAutoFadeAnchor
                ? clip.sourceStartSample
                : clip.fadeInAnchorSourceSample;
            const std::uint64_t fadeOutAnchor = clip.fadeOutAnchorSourceSample == TimelineClip::kAutoFadeAnchor
                ? sourceEnd
                : clip.fadeOutAnchorSourceSample;
            // Split children intentionally inherit the parent fade anchors, so an
            // anchor may lie outside this child's trimmed source interval. It must
            // only stay inside the original source (sourceFrames is one-past-end).
            if (fadeInAnchor > frames || fadeOutAnchor > frames)
                throw std::invalid_argument("clip fade anchor outside source");
        }
    }
    track.pan = std::clamp(track.pan, -1.0F, 1.0F);
    track.stereoLeftPan = std::clamp(track.stereoLeftPan, -1.0F, 1.0F);
    track.stereoRightPan = std::clamp(track.stereoRightPan, -1.0F, 1.0F);
    tracks_.push_back(track);
    controlTrackCount_.store(tracks_.size(), std::memory_order_release);
    rebuildVoicePlan();
}

void AudioEngine::setTrackRenderMask(const std::vector<std::size_t>& audibleTrackIndices) {
    trackRenderMask_.fill(0U);
    for (const std::size_t index : audibleTrackIndices) {
        if (index >= tracks_.size()) throw std::out_of_range("track render mask index");
        trackRenderMask_[index] = 1U;
    }
    trackRenderMaskActive_ = true;
    rebuildVoicePlan();
}

void AudioEngine::clearTrackRenderMask() {
    trackRenderMaskActive_ = false;
    trackRenderMask_.fill(0U);
    rebuildVoicePlan();
}

void AudioEngine::setGraphMonitorNode(int node) {
    if (node < 0) {
        clearGraphMonitorNode();
        return;
    }
    const std::size_t nodeCount = controlGraphNodeCount_.load(std::memory_order_acquire);
    if (nodeCount == 0U || static_cast<std::size_t>(node) >= nodeCount)
        throw std::out_of_range("graph monitor node");
    graphMonitorNode_.store(node, std::memory_order_release);
}

void AudioEngine::applyProjectTrackMixerState(const Project& project) {
    const std::size_t count = std::min(tracks_.size(), project.tracks.size());
    for (std::size_t i = 0U; i < count; ++i) {
        auto& runtime = tracks_[i];
        const auto& state = project.tracks[i];
        runtime.gainDb = state.gainDb;
        runtime.pan = std::clamp(state.pan, -1.0F, 1.0F);
        runtime.mute = state.mute;
        runtime.useDualStereoPan = state.useDualStereoPan;
        runtime.stereoLeftPan = std::clamp(state.stereoLeftPan, -1.0F, 1.0F);
        runtime.stereoRightPan = std::clamp(state.stereoRightPan, -1.0F, 1.0F);
        runtime.gainAutomationDb = state.gainAutomationMode == AutomationMode::Off ? nullptr : &state.gainAutomationDb;
        runtime.panAutomation = state.panAutomationMode == AutomationMode::Off ? nullptr : &state.panAutomation;
        runtime.muteAutomation = state.muteAutomationMode == AutomationMode::Off ? nullptr : &state.muteAutomation;
    }
    rebuildVoicePlan();
}

void AudioEngine::setVoiceLimit(std::size_t maxVoices) {
    voiceLimit_.store(maxVoices, std::memory_order_release);
    rebuildVoicePlan();
}

void AudioEngine::setPanDepth(PanDepth depth) {
    panDepth_.store(depth, std::memory_order_release);
    rebuildVoicePlan();
}

void AudioEngine::setLowLatencyInputMonitoring(bool enabled, float gainDb) noexcept {
    inputMonitorGainLinear_.store(dbToLinear(std::isfinite(gainDb) ? gainDb : 0.0F), std::memory_order_release);
    inputMonitoring_.store(enabled, std::memory_order_release);
}

void AudioEngine::setMasterFaderDb(float db) noexcept {
    const float safeDb = std::isfinite(db) ? std::clamp(db, -144.0F, 24.0F) : 0.0F;
    masterFaderDb_.store(safeDb, std::memory_order_release);
    masterGainTargetLinear_.store(dbToLinear(safeDb), std::memory_order_release);
}

StereoMeterSnapshot AudioEngine::outputMeter() const noexcept {
    return {
        leftPeak_.load(std::memory_order_acquire),
        rightPeak_.load(std::memory_order_acquire),
        leftRms_.load(std::memory_order_acquire),
        rightRms_.load(std::memory_order_acquire)
    };
}

TrackMeterSnapshot AudioEngine::trackMeter(std::size_t trackIndex) const noexcept {
    if (trackIndex >= controlTrackCount_.load(std::memory_order_acquire) || trackIndex >= trackMeters_.size()) return {};
    const auto& meter = trackMeters_[trackIndex];
    return {
        meter.leftPeak.load(std::memory_order_acquire),
        meter.rightPeak.load(std::memory_order_acquire),
        meter.leftRms.load(std::memory_order_acquire),
        meter.rightRms.load(std::memory_order_acquire)
    };
}

void AudioEngine::publishMeters(const float* left, const float* right, std::uint32_t frames) noexcept {
    if (frames == 0U || left == nullptr || right == nullptr) {
        leftPeak_.store(0.0F, std::memory_order_release);
        rightPeak_.store(0.0F, std::memory_order_release);
        leftRms_.store(0.0F, std::memory_order_release);
        rightRms_.store(0.0F, std::memory_order_release);
        return;
    }

    float lp = 0.0F, rp = 0.0F;
    double ls = 0.0, rs = 0.0;
    for (std::uint32_t i = 0; i < frames; ++i) {
        const float l = left[i];
        const float r = right[i];
        lp = std::max(lp, std::abs(l));
        rp = std::max(rp, std::abs(r));
        ls += static_cast<double>(l) * static_cast<double>(l);
        rs += static_cast<double>(r) * static_cast<double>(r);
    }
    leftPeak_.store(lp, std::memory_order_release);
    rightPeak_.store(rp, std::memory_order_release);
    leftRms_.store(static_cast<float>(std::sqrt(ls / static_cast<double>(frames))), std::memory_order_release);
    rightRms_.store(static_cast<float>(std::sqrt(rs / static_cast<double>(frames))), std::memory_order_release);
}

void AudioEngine::addToMix(std::uint32_t index, double left, double right) noexcept {
    MixMath::compensatedAdd(left, mixLeft_[index], mixLeftCompensation_[index]);
    MixMath::compensatedAdd(right, mixRight_[index], mixRightCompensation_[index]);
}

void AudioEngine::addTrackContribution(GraphRenderPlan* graphPlan,
                                       std::size_t trackIndex,
                                       std::uint32_t index,
                                       double left,
                                       double right) noexcept {
    if (graphPlan == nullptr || graphPlan->graph == nullptr) {
        addToMix(index, left, right);
        return;
    }
    if (trackIndex >= graphPlan->nodeCount || index >= graphPlan->blockCapacity) return;
    const std::size_t offset = trackIndex * graphPlan->blockCapacity + index;
    graphPlan->sourceLeft[offset] += static_cast<float>(left);
    graphPlan->sourceRight[offset] += static_cast<float>(right);
}

void AudioEngine::clearGraphSources(GraphRenderPlan* graphPlan, std::uint32_t frames) noexcept {
    if (graphPlan == nullptr || graphPlan->graph == nullptr) return;
    for (std::size_t node = 0U; node < graphPlan->nodeCount; ++node) {
        const std::size_t base = node * graphPlan->blockCapacity;
        std::fill_n(graphPlan->sourceLeft.data() + base, frames, 0.0F);
        std::fill_n(graphPlan->sourceRight.data() + base, frames, 0.0F);
    }
    std::fill_n(graphPlan->masterLeft.data(), frames, 0.0F);
    std::fill_n(graphPlan->masterRight.data(), frames, 0.0F);
}

void AudioEngine::renderProcessorGraph(GraphRenderPlan* graphPlan,
                                       std::int64_t projectSample,
                                       std::uint32_t sourceOffset,
                                       std::uint32_t frames,
                                       bool playing,
                                       bool recording) noexcept {
    if (graphPlan == nullptr || graphPlan->graph == nullptr) return;
    ProcessorContext context;
    context.sampleRate = config_.sampleRate;
    context.projectSample = projectSample;
    context.frames = frames;
    const TempoMap& map = liveTempoMap();
    const TempoMapPosition musical = map.positionAtSample(projectSample);
    context.tempo = musical.bpm;
    context.timeSignatureNumerator = musical.numerator;
    context.timeSignatureDenominator = musical.denominator;
    context.playing = playing;
    context.recording = recording;
    context.projectQuarterNotes = musical.quarterNotes;
    context.barStartQuarterNotes = musical.barStartQuarterNotes;

    for (std::size_t node = 0U; node < graphPlan->nodeCount; ++node) {
        const std::size_t base = node * graphPlan->blockCapacity + sourceOffset;
        graphPlan->sourceBuses[node] = {graphPlan->sourceLeft.data() + base,
                                       graphPlan->sourceRight.data() + base};
    }
    const VoicePlan& voicePlan = livePlan();
    graphPlan->graph->process(graphPlan->sourceBuses.data(),
                              graphPlan->sourceBuses.size(),
                              {graphPlan->masterLeft.data() + sourceOffset,
                               graphPlan->masterRight.data() + sourceOffset},
                              frames,
                              context,
                              voicePlan.trackNodeEnabled.data(),
                              voicePlan.trackNodeMaskCount);
    const int monitorNode = graphMonitorNode_.load(std::memory_order_acquire);
    if (monitorNode >= 0) {
        (void)graphPlan->graph->copyNodePostFader(static_cast<std::size_t>(monitorNode),
                                                  {graphPlan->masterLeft.data() + sourceOffset,
                                                   graphPlan->masterRight.data() + sourceOffset},
                                                  frames);
    }
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const std::uint32_t outputIndex = sourceOffset + i;
        addToMix(outputIndex,
                 static_cast<double>(graphPlan->masterLeft[outputIndex]),
                 static_cast<double>(graphPlan->masterRight[outputIndex]));
    }
}

void AudioEngine::processAudio(const float* const* inputs,
                               float* const* outputs,
                               std::uint32_t inputChannels,
                               std::uint32_t outputChannels,
                               std::uint32_t frames) noexcept {
    if (outputs == nullptr || outputChannels == 0U) return;

    for (std::uint32_t c = 0; c < outputChannels; ++c) {
        if (outputs[c] != nullptr) std::fill(outputs[c], outputs[c] + frames, 0.0F);
    }

    if (!prepared_ || frames > mixLeft_.size() || outputChannels < 2U || outputs[0] == nullptr || outputs[1] == nullptr) {
        if (outputChannels >= 2U) publishMeters(outputs[0], outputs[1], frames);
        return;
    }

    // Lock-free block-boundary publication. Graph is adopted before the voice
    // plan so a track-count/routing edit published together can never feed a
    // newly visible voice into the previous graph. No allocation or destruction
    // occurs on the realtime thread.
    adoptPendingTempoMap();
    adoptPendingProcessorGraph();
    adoptPendingPlan();
    GraphRenderPlan& graphPlan = liveGraphPlan();
    const VoicePlan& plan = livePlan();

    std::fill_n(mixLeft_.begin(), frames, 0.0);
    std::fill_n(mixRight_.begin(), frames, 0.0);
    std::fill_n(mixLeftCompensation_.begin(), frames, 0.0);
    std::fill_n(mixRightCompensation_.begin(), frames, 0.0);
    clearGraphSources(&graphPlan, frames);
    for (std::size_t v = 0U; v < plan.count; ++v) {
        const std::size_t trackIndex = plan.voices[v].trackIndex;
        if (trackIndex >= trackMeters_.size()) continue;
        trackMeters_[trackIndex].leftPeak.store(0.0F, std::memory_order_relaxed);
        trackMeters_[trackIndex].rightPeak.store(0.0F, std::memory_order_relaxed);
        trackMeters_[trackIndex].leftRms.store(0.0F, std::memory_order_relaxed);
        trackMeters_[trackIndex].rightRms.store(0.0F, std::memory_order_relaxed);
    }

    const bool playingNow = transport_.isPlaying();
    const std::int64_t blockStart = transport_.positionSamples();
    const bool cycleEnabled = playingNow && transport_.cycleEnabled();
    const std::int64_t cycleStart = cycleEnabled ? transport_.cycleStartSample() : 0;
    const std::int64_t cycleEnd = cycleEnabled ? transport_.cycleEndSample() : 0;
    recordingCallbackUsers_.fetch_add(1U, std::memory_order_acq_rel);
    Recorder* rec = recorder_.load(std::memory_order_acquire);
    const bool recorderActive = rec != nullptr && rec->recording();
    const bool punchEnabled = punchEnabled_.load(std::memory_order_acquire);
    const std::int64_t punchIn = punchInSample_.load(std::memory_order_acquire);
    const std::int64_t punchOut = punchOutSample_.load(std::memory_order_acquire);

    if (recorderActive) {
        if (!punchEnabled) {
            if (rec->push(inputs, inputChannels, frames)) {
                std::uint32_t offset = 0U;
                std::uint64_t cyclePass = transport_.cyclePass();
                while (offset < frames) {
                    const std::int64_t absoluteSample = blockStart + static_cast<std::int64_t>(offset);
                    const std::int64_t segmentStart = cycleMappedSample(absoluteSample, cycleEnabled, cycleStart, cycleEnd);
                    const std::uint32_t segmentFrames = framesUntilCycleBoundary(
                        segmentStart, frames - offset, cycleEnabled, cycleStart, cycleEnd);
                    appendRecordedTimelineSpan(segmentStart, segmentFrames, cyclePass);
                    offset += segmentFrames;
                    if (cycleEnabled && offset < frames &&
                        segmentStart + static_cast<std::int64_t>(segmentFrames) == cycleEnd)
                        ++cyclePass;
                }
            }
        } else if (rec->channels() <= 256U && inputs != nullptr) {
            // Punch is evaluated in project-timeline space. When cycle playback
            // wraps inside this callback, split the input block at the exact
            // cycle boundary so every pass records only its punch intersection.
            std::uint32_t offset = 0U;
            std::uint64_t cyclePass = transport_.cyclePass();
            while (offset < frames) {
                const std::int64_t absoluteSample = blockStart + static_cast<std::int64_t>(offset);
                const std::int64_t segmentStart = cycleMappedSample(absoluteSample, cycleEnabled, cycleStart, cycleEnd);
                const std::uint32_t remaining = frames - offset;
                const std::uint32_t segmentFrames = framesUntilCycleBoundary(segmentStart, remaining, cycleEnabled, cycleStart, cycleEnd);
                const std::int64_t segmentEnd = segmentStart + static_cast<std::int64_t>(segmentFrames);
                const std::int64_t recordStart = std::max(segmentStart, punchIn);
                const std::int64_t recordEnd = std::min(segmentEnd, punchOut);
                if (recordStart < recordEnd) {
                    const std::uint32_t localOffset = static_cast<std::uint32_t>(recordStart - segmentStart);
                    const std::uint32_t recordFrames = static_cast<std::uint32_t>(recordEnd - recordStart);
                    std::array<const float*, 256U> shiftedInputs {};
                    const std::uint32_t fillChannels = std::min<std::uint32_t>(inputChannels, 256U);
                    for (std::uint32_t c = 0U; c < fillChannels; ++c)
                        shiftedInputs[c] = inputs[c] != nullptr ? inputs[c] + offset + localOffset : nullptr;
                    if (rec->push(shiftedInputs.data(), inputChannels, recordFrames))
                        appendRecordedTimelineSpan(recordStart, recordFrames, cyclePass);
                }
                offset += segmentFrames;
                if (cycleEnabled && offset < frames && segmentEnd == cycleEnd) ++cyclePass;
            }
        }
    }
    recordingCallbackUsers_.fetch_sub(1U, std::memory_order_acq_rel);

    // Native low-latency monitoring path: input enters the current callback mix
    // without travelling through timeline/playback processing.
    if (inputMonitoring_.load(std::memory_order_acquire) && inputs != nullptr && inputChannels > 0U) {
        const double monitorGain = static_cast<double>(inputMonitorGainLinear_.load(std::memory_order_acquire));
        const float* inL = inputs[0];
        const float* inR = inputChannels > 1U ? inputs[1] : inputs[0];
        if (inL != nullptr && inR != nullptr) {
            for (std::uint32_t i = 0; i < frames; ++i) {
                addToMix(i,
                         static_cast<double>(inL[i]) * monitorGain,
                         static_cast<double>(inR[i]) * monitorGain);
            }
        }
    }

    if (playingNow) {
        const PanDepth depth = panDepth_.load(std::memory_order_acquire);

        for (std::size_t voiceIndex = 0U; voiceIndex < plan.count; ++voiceIndex) {
            const PreparedVoice& voice = plan.voices[voiceIndex];
            const std::size_t trackIndex = voice.trackIndex;
            const bool graphHandlesFader = graphPlan.graph != nullptr && graphPlan.graph->nodeUsesMixControl(trackIndex);
            if (!graphHandlesFader && voice.mute && !voice.hasMuteAutomation) continue;
            if (voice.clips.empty() || voice.channels == 0U) continue;

            std::fill_n(trackScratchLeft_.begin(), frames, 0.0F);
            std::fill_n(trackScratchRight_.begin(), frames, 0.0F);

            // First build the actual track signal from all overlapping clips. Clip
            // gain/fades live here; track pan/fader/mute are intentionally applied
            // only after the sum, so crossfades and meters see the real result.
            // Cycle playback is split at the exact wrap sample so a callback may
            // render tail-of-loop and head-of-loop into one device block.
            const auto renderClipSegment = [&](const PreparedClip& clip,
                                               std::int64_t segmentStart,
                                               std::uint32_t segmentFrames,
                                               std::uint32_t outputOffset) noexcept {
                const bool memorySource = clip.source != nullptr;
                const bool diskSource = clip.diskSource != nullptr;
                if (memorySource == diskSource) return;

                const std::int64_t clipLength = static_cast<std::int64_t>(clip.lengthSamples);
                const std::int64_t clipEnd = clip.timelineStartSample + clipLength;
                const std::int64_t segmentEnd = segmentStart + static_cast<std::int64_t>(segmentFrames);
                const std::int64_t overlapStart = std::max(segmentStart, clip.timelineStartSample);
                const std::int64_t overlapEnd = std::min(segmentEnd, clipEnd);
                if (overlapStart >= overlapEnd) return;

                const std::uint32_t overlapFrames = static_cast<std::uint32_t>(overlapEnd - overlapStart);
                const std::uint64_t firstSourceFrame = clip.sourceStartSample +
                    static_cast<std::uint64_t>(overlapStart - clip.timelineStartSample);
                const float* srcL = nullptr;
                const float* srcR = nullptr;
                DiskBlockView diskView;
                if (memorySource) {
                    srcL = clip.source->channelData(0U) + firstSourceFrame;
                    srcR = clip.channels > 1U ? clip.source->channelData(1U) + firstSourceFrame : nullptr;
                } else {
                    if (!clip.diskSource->acquire(firstSourceFrame, overlapFrames, diskView)) return;
                }

                const std::uint32_t firstOutput = outputOffset +
                    static_cast<std::uint32_t>(overlapStart - segmentStart);
                for (std::uint32_t local = 0U; local < overlapFrames; ++local) {
                    const std::uint32_t outIndex = firstOutput + local;
                    const std::uint64_t sourceFrame = firstSourceFrame + local;
                    double leftSample = 0.0;
                    double rightSample = 0.0;
                    if (memorySource) {
                        leftSample = static_cast<double>(srcL[local]);
                        rightSample = clip.channels > 1U ? static_cast<double>(srcR[local]) : leftSample;
                    } else {
                        const std::size_t base = static_cast<std::size_t>(diskView.frameOffset + local) * diskView.channels;
                        leftSample = static_cast<double>(diskView.interleaved[base]);
                        rightSample = clip.channels > 1U
                            ? static_cast<double>(diskView.interleaved[base + 1U])
                            : leftSample;
                    }

                    double clipGain = clip.gain;
                    if (clip.fadeInSamples != 0U) {
                        const double position = sourceFrame <= clip.fadeInAnchorSourceSample
                            ? 0.0
                            : static_cast<double>(sourceFrame - clip.fadeInAnchorSourceSample);
                        clipGain *= std::clamp(position / static_cast<double>(clip.fadeInSamples), 0.0, 1.0);
                    }
                    if (clip.fadeOutSamples != 0U) {
                        const double remaining = sourceFrame >= clip.fadeOutAnchorSourceSample
                            ? 0.0
                            : static_cast<double>(clip.fadeOutAnchorSourceSample - sourceFrame);
                        clipGain *= std::clamp(remaining / static_cast<double>(clip.fadeOutSamples), 0.0, 1.0);
                    }

                    trackScratchLeft_[outIndex] += static_cast<float>(leftSample * clipGain);
                    if (voice.channels > 1U)
                        trackScratchRight_[outIndex] += static_cast<float>(rightSample * clipGain);
                }

                if (diskSource) clip.diskSource->release(diskView);
            };

            for (const PreparedClip& clip : voice.clips) {
                if (clip.mute || clip.lengthSamples == 0U || clip.channels == 0U) continue;
                std::uint32_t outputOffset = 0U;
                while (outputOffset < frames) {
                    const std::int64_t absoluteSample = blockStart + static_cast<std::int64_t>(outputOffset);
                    const std::int64_t segmentStart = cycleMappedSample(absoluteSample, cycleEnabled, cycleStart, cycleEnd);
                    const std::uint32_t segmentFrames = framesUntilCycleBoundary(
                        segmentStart, frames - outputOffset, cycleEnabled, cycleStart, cycleEnd);
                    renderClipSegment(clip, segmentStart, segmentFrames, outputOffset);
                    outputOffset += segmentFrames;
                }
            }

            float trackLeftPeak = 0.0F;
            float trackRightPeak = 0.0F;
            double trackLeftSquares = 0.0;
            double trackRightSquares = 0.0;
            for (std::uint32_t i = 0U; i < frames; ++i) {
                const std::int64_t timelineSample = cycleMappedSample(
                    blockStart + static_cast<std::int64_t>(i), cycleEnabled, cycleStart, cycleEnd);
                const bool muted = !graphHandlesFader && voice.hasMuteAutomation
                    ? voice.muteAutomation.stepValueAt(timelineSample, voice.mute ? 1.0F : 0.0F) >= 0.5F
                    : (!graphHandlesFader && voice.mute);
                if (muted) continue;

                double gain = graphHandlesFader ? 1.0 : voice.gain;
                if (!graphHandlesFader && voice.hasGainAutomation) {
                    const float automatedDb = voice.gainAutomationDb.valueAt(timelineSample, voice.gainDb);
                    if (std::isfinite(automatedDb)) gain = MixMath::dbToLinear(static_cast<double>(automatedDb));
                }

                StereoGainPair monoPan = voice.monoPan;
                StereoGainPair balance = voice.balance;
                if (voice.hasPanAutomation && !voice.useDualStereoPan) {
                    const float automatedPan = std::clamp(voice.panAutomation.valueAt(timelineSample, voice.pan), -1.0F, 1.0F);
                    if (voice.channels == 1U) monoPan = MixMath::monoPan(automatedPan, depth);
                    else balance = MixMath::stereoBalance(automatedPan);
                }

                const double leftSample = static_cast<double>(trackScratchLeft_[i]);
                const double rightSample = voice.channels > 1U
                    ? static_cast<double>(trackScratchRight_[i])
                    : leftSample;
                double contributionL = 0.0;
                double contributionR = 0.0;
                if (voice.channels == 1U) {
                    const double x = leftSample * gain;
                    contributionL = x * monoPan.left;
                    contributionR = x * monoPan.right;
                } else if (voice.useDualStereoPan) {
                    const double l = leftSample * gain;
                    const double r = rightSample * gain;
                    contributionL = l * voice.stereoLeftPan.left + r * voice.stereoRightPan.left;
                    contributionR = l * voice.stereoLeftPan.right + r * voice.stereoRightPan.right;
                } else {
                    contributionL = leftSample * gain * balance.left;
                    contributionR = rightSample * gain * balance.right;
                }
                addTrackContribution(&graphPlan, trackIndex, i, contributionL, contributionR);

                const float meterL = static_cast<float>(contributionL);
                const float meterR = static_cast<float>(contributionR);
                trackLeftPeak = std::max(trackLeftPeak, std::abs(meterL));
                trackRightPeak = std::max(trackRightPeak, std::abs(meterR));
                trackLeftSquares += contributionL * contributionL;
                trackRightSquares += contributionR * contributionR;
            }

            if (trackIndex < trackMeters_.size() && frames != 0U) {
                auto& meter = trackMeters_[trackIndex];
                meter.leftPeak.store(trackLeftPeak, std::memory_order_release);
                meter.rightPeak.store(trackRightPeak, std::memory_order_release);
                meter.leftRms.store(static_cast<float>(std::sqrt(trackLeftSquares / static_cast<double>(frames))), std::memory_order_release);
                meter.rightRms.store(static_cast<float>(std::sqrt(trackRightSquares / static_cast<double>(frames))), std::memory_order_release);
            }
        }
        transport_.advance(frames);
    }

    // ProcessorGraph executes on every callback, including stopped transport, so
    // instruments, effect tails and queued MIDI are not artificially tied to play state.
    {
        const TempoMap& map = liveTempoMap();
        std::uint32_t offset = 0U;
        while (offset < frames) {
            const std::int64_t absoluteSample = blockStart + static_cast<std::int64_t>(offset);
            const std::int64_t segmentStart = cycleMappedSample(absoluteSample, cycleEnabled, cycleStart, cycleEnd);
            std::int64_t nextBoundary = map.nextChangeSampleAfter(segmentStart);
            if (cycleEnabled && segmentStart < cycleEnd) nextBoundary = std::min(nextBoundary, cycleEnd);
            if (recorderActive && punchEnabled) {
                if (segmentStart < punchIn) nextBoundary = std::min(nextBoundary, punchIn);
                else if (segmentStart < punchOut) nextBoundary = std::min(nextBoundary, punchOut);
            }
            std::uint32_t segmentFrames = frames - offset;
            if (nextBoundary != std::numeric_limits<std::int64_t>::max() && nextBoundary > segmentStart) {
                const std::int64_t untilBoundary = nextBoundary - segmentStart;
                if (untilBoundary < static_cast<std::int64_t>(segmentFrames))
                    segmentFrames = static_cast<std::uint32_t>(untilBoundary);
            }
            if (segmentFrames == 0U) segmentFrames = 1U;
            const bool segmentRecording = recorderActive &&
                (!punchEnabled || (segmentStart >= punchIn && segmentStart < punchOut));
            renderProcessorGraph(&graphPlan, segmentStart, offset, segmentFrames, playingNow, segmentRecording);
            offset += segmentFrames;
        }
    }

    // The internal bus is deliberately not clipped at 0 dBFS. This preserves
    // floating-point headroom. The Master Fader changes path gain without
    // introducing a nonlinear ceiling.
    const bool internalGraphTap = graphMonitorNode_.load(std::memory_order_acquire) >= 0;
    const AutomationLane* masterAutomation = internalGraphTap ? nullptr : masterFaderAutomation_.load(std::memory_order_acquire);
    if (internalGraphTap) {
        for (std::uint32_t i = 0U; i < frames; ++i) {
            outputs[0][i] = static_cast<float>(mixLeft_[i] + mixLeftCompensation_[i]);
            outputs[1][i] = static_cast<float>(mixRight_[i] + mixRightCompensation_[i]);
        }
    } else if (masterAutomation != nullptr) {
        const float fallbackDb = masterFaderDb_.load(std::memory_order_acquire);
        double lastGain = masterGainCurrent_;
        for (std::uint32_t i = 0U; i < frames; ++i) {
            const std::int64_t timelineSample = cycleMappedSample(
                blockStart + static_cast<std::int64_t>(i), cycleEnabled, cycleStart, cycleEnd);
            const float db = masterAutomation->valueAt(timelineSample, fallbackDb);
            const double g = MixMath::dbToLinear(static_cast<double>(db));
            outputs[0][i] = static_cast<float>((mixLeft_[i] + mixLeftCompensation_[i]) * g);
            outputs[1][i] = static_cast<float>((mixRight_[i] + mixRightCompensation_[i]) * g);
            lastGain = g;
        }
        masterGainCurrent_ = lastGain;
    } else {
        const double targetMasterGain = static_cast<double>(masterGainTargetLinear_.load(std::memory_order_acquire));
        if (frames <= 1U) {
            masterGainCurrent_ = targetMasterGain;
            if (frames == 1U) {
                outputs[0][0] = static_cast<float>((mixLeft_[0] + mixLeftCompensation_[0]) * masterGainCurrent_);
                outputs[1][0] = static_cast<float>((mixRight_[0] + mixRightCompensation_[0]) * masterGainCurrent_);
            }
        } else {
            const double step = (targetMasterGain - masterGainCurrent_) / static_cast<double>(frames - 1U);
            double g = masterGainCurrent_;
            for (std::uint32_t i = 0; i < frames; ++i) {
                outputs[0][i] = static_cast<float>((mixLeft_[i] + mixLeftCompensation_[i]) * g);
                outputs[1][i] = static_cast<float>((mixRight_[i] + mixRightCompensation_[i]) * g);
                g += step;
            }
            masterGainCurrent_ = targetMasterGain;
        }
    }

    // Master meters are post-fader, derived from the actual device-bound signal.
    publishMeters(outputs[0], outputs[1], frames);
}

} // namespace silveton
