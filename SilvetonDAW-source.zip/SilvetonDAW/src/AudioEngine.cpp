#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/DiskStream.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <thread>

namespace silveton {

AudioEngine::AudioEngine() {
    for (auto& state : voicePlanStates_) state.store(PlanSlotState::Free, std::memory_order_relaxed);
    voicePlanStates_[0].store(PlanSlotState::Live, std::memory_order_relaxed);
    livePlanIndex_.store(0, std::memory_order_relaxed);
    pendingPlanIndex_.store(kNoPendingPlan, std::memory_order_relaxed);
}

float AudioEngine::dbToLinear(float db) noexcept {
    return static_cast<float>(MixMath::dbToLinear(static_cast<double>(db)));
}

void AudioEngine::prepare(const AudioDeviceConfig& config) {
    if (!std::isfinite(config.sampleRate) || config.sampleRate <= 0.0) throw std::invalid_argument("invalid engine sample rate");
    if (config.blockSize == 0U) throw std::invalid_argument("invalid engine block size");
    if (config.outputChannels < 2U) throw std::invalid_argument("engine milestone requires stereo output");
    config_ = config;
    transport_.setSampleRate(config.sampleRate);
    mixLeft_.assign(config.blockSize, 0.0);
    mixRight_.assign(config.blockSize, 0.0);
    mixLeftCompensation_.assign(config.blockSize, 0.0);
    mixRightCompensation_.assign(config.blockSize, 0.0);
    masterGainCurrent_ = static_cast<double>(masterGainTargetLinear_.load(std::memory_order_acquire));
    prepared_ = true;
}

std::size_t AudioEngine::acquireFreePlanSlot() {
    // Single control-thread contract. A free slot always exists with the
    // Live/Pending/Free triple-buffer topology; yield only if we race the
    // audio thread while it is retiring the previous Live slot.
    for (;;) {
        for (std::size_t i = 0U; i < voicePlanStates_.size(); ++i) {
            PlanSlotState expected = PlanSlotState::Free;
            if (voicePlanStates_[i].compare_exchange_strong(expected,
                                                            PlanSlotState::Writing,
                                                            std::memory_order_acq_rel,
                                                            std::memory_order_acquire)) {
                return i;
            }
        }
        std::this_thread::yield();
    }
}

void AudioEngine::publishPendingPlan(std::size_t slot) noexcept {
    voicePlanStates_[slot].store(PlanSlotState::Pending, std::memory_order_release);
    const int replaced = pendingPlanIndex_.exchange(static_cast<int>(slot), std::memory_order_acq_rel);
    if (replaced != kNoPendingPlan && replaced != static_cast<int>(slot)) {
        voicePlanStates_[static_cast<std::size_t>(replaced)].store(PlanSlotState::Free, std::memory_order_release);
    }
}

void AudioEngine::adoptPendingPlan() noexcept {
    const int next = pendingPlanIndex_.exchange(kNoPendingPlan, std::memory_order_acq_rel);
    if (next == kNoPendingPlan) return;

    const int old = livePlanIndex_.exchange(next, std::memory_order_acq_rel);
    voicePlanStates_[static_cast<std::size_t>(next)].store(PlanSlotState::Live, std::memory_order_release);
    if (old != next && old >= 0) {
        voicePlanStates_[static_cast<std::size_t>(old)].store(PlanSlotState::Free, std::memory_order_release);
    }
}

const AudioEngine::VoicePlan& AudioEngine::livePlan() const noexcept {
    const int index = livePlanIndex_.load(std::memory_order_acquire);
    return voicePlans_[static_cast<std::size_t>(index)];
}

void AudioEngine::rebuildVoicePlan() {
    voicedTrackIndices_.clear();
    voicedTrackIndices_.reserve(tracks_.size());
    for (std::size_t i = 0; i < tracks_.size(); ++i) {
        if (tracks_[i].voiceEnabled) voicedTrackIndices_.push_back(i);
    }
    std::stable_sort(voicedTrackIndices_.begin(), voicedTrackIndices_.end(), [this](std::size_t a, std::size_t b) {
        return tracks_[a].voicePriority > tracks_[b].voicePriority;
    });

    const std::size_t limit = voiceLimit_.load(std::memory_order_acquire);
    if (limit != 0U && voicedTrackIndices_.size() > limit) voicedTrackIndices_.resize(limit);
    controlVoicedTrackCount_.store(voicedTrackIndices_.size(), std::memory_order_release);

    const std::size_t slot = acquireFreePlanSlot();
    VoicePlan& plan = voicePlans_[slot];
    plan.count = 0U;
    const PanDepth depth = panDepth_.load(std::memory_order_acquire);

    for (const std::size_t trackIndex : voicedTrackIndices_) {
        if (plan.count >= plan.voices.size()) break;
        const auto& track = tracks_[trackIndex];
        PreparedVoice voice;
        voice.trackIndex = trackIndex;
        voice.source = track.source;
        voice.diskSource = track.diskSource;
        voice.timelineStartSample = track.timelineStartSample;
        voice.sourceStartSample = track.sourceStartSample;
        voice.mute = track.mute;
        voice.useDualStereoPan = track.useDualStereoPan;
        voice.gainDb = track.gainDb;
        voice.pan = track.pan;
        voice.gainAutomationDb = track.gainAutomationDb;
        voice.panAutomation = track.panAutomation;
        voice.gain = MixMath::dbToLinear(static_cast<double>(track.gainDb));

        if (track.source != nullptr) {
            voice.sourceFrames = static_cast<std::uint64_t>(track.source->frames());
            voice.channels = track.source->channels();
        } else if (track.diskSource != nullptr) {
            voice.sourceFrames = track.diskSource->frames();
            voice.channels = static_cast<std::size_t>(track.diskSource->channels());
        }

        if (voice.channels == 1U) {
            voice.monoPan = MixMath::monoPan(track.pan, depth);
        } else if (track.useDualStereoPan) {
            voice.stereoLeftPan = MixMath::monoPan(track.stereoLeftPan, depth);
            voice.stereoRightPan = MixMath::monoPan(track.stereoRightPan, depth);
        } else {
            voice.balance = MixMath::stereoBalance(track.pan);
        }
        plan.voices[plan.count++] = voice;
    }

    publishPendingPlan(slot);
}

void AudioEngine::clearTracks() {
    tracks_.clear();
    voicedTrackIndices_.clear();
    controlTrackCount_.store(0U, std::memory_order_release);
    controlVoicedTrackCount_.store(0U, std::memory_order_release);
    for (auto& meter : trackMeters_) {
        meter.leftPeak.store(0.0F, std::memory_order_relaxed);
        meter.rightPeak.store(0.0F, std::memory_order_relaxed);
        meter.leftRms.store(0.0F, std::memory_order_relaxed);
        meter.rightRms.store(0.0F, std::memory_order_relaxed);
    }
    rebuildVoicePlan();
}

void AudioEngine::addTrack(TimelineTrack track) {
    if (tracks_.size() >= kMaxEngineTracks) throw std::length_error("audio engine track limit is 512");
    const bool memorySource = track.source != nullptr;
    const bool diskSource = track.diskSource != nullptr;
    if (memorySource == diskSource) throw std::invalid_argument("track must have exactly one audio source");
    const std::uint64_t sourceFrames = memorySource
        ? static_cast<std::uint64_t>(track.source->frames())
        : track.diskSource->frames();
    const std::size_t sourceChannels = memorySource
        ? track.source->channels()
        : static_cast<std::size_t>(track.diskSource->channels());
    if (sourceChannels == 0U) throw std::invalid_argument("track source has no channels");
    if (track.sourceStartSample >= sourceFrames) throw std::invalid_argument("track source offset outside buffer");
    track.pan = std::clamp(track.pan, -1.0F, 1.0F);
    track.stereoLeftPan = std::clamp(track.stereoLeftPan, -1.0F, 1.0F);
    track.stereoRightPan = std::clamp(track.stereoRightPan, -1.0F, 1.0F);
    tracks_.push_back(track);
    controlTrackCount_.store(tracks_.size(), std::memory_order_release);
    rebuildVoicePlan();
}

void AudioEngine::setVoiceLimit(std::size_t maxVoices) {
    voiceLimit_.store(maxVoices, std::memory_order_release);
    rebuildVoicePlan();
}

void AudioEngine::setPanDepth(PanDepth depth) {
    panDepth_.store(depth, std::memory_order_release);
    rebuildVoicePlan();
}

void AudioEngine::setLowLatencyInputMonitoring(bool enabled, float gainDb) noexcept {
    inputMonitorGainLinear_.store(dbToLinear(std::isfinite(gainDb) ? gainDb : 0.0F), std::memory_order_release);
    inputMonitoring_.store(enabled, std::memory_order_release);
}

void AudioEngine::setMasterFaderDb(float db) noexcept {
    const float safeDb = std::isfinite(db) ? std::clamp(db, -144.0F, 24.0F) : 0.0F;
    masterFaderDb_.store(safeDb, std::memory_order_release);
    masterGainTargetLinear_.store(dbToLinear(safeDb), std::memory_order_release);
}

StereoMeterSnapshot AudioEngine::outputMeter() const noexcept {
    return {
        leftPeak_.load(std::memory_order_acquire),
        rightPeak_.load(std::memory_order_acquire),
        leftRms_.load(std::memory_order_acquire),
        rightRms_.load(std::memory_order_acquire)
    };
}

TrackMeterSnapshot AudioEngine::trackMeter(std::size_t trackIndex) const noexcept {
    if (trackIndex >= controlTrackCount_.load(std::memory_order_acquire) || trackIndex >= trackMeters_.size()) return {};
    const auto& meter = trackMeters_[trackIndex];
    return {
        meter.leftPeak.load(std::memory_order_acquire),
        meter.rightPeak.load(std::memory_order_acquire),
        meter.leftRms.load(std::memory_order_acquire),
        meter.rightRms.load(std::memory_order_acquire)
    };
}

void AudioEngine::publishMeters(const float* left, const float* right, std::uint32_t frames) noexcept {
    if (frames == 0U || left == nullptr || right == nullptr) {
        leftPeak_.store(0.0F, std::memory_order_release);
        rightPeak_.store(0.0F, std::memory_order_release);
        leftRms_.store(0.0F, std::memory_order_release);
        rightRms_.store(0.0F, std::memory_order_release);
        return;
    }

    float lp = 0.0F, rp = 0.0F;
    double ls = 0.0, rs = 0.0;
    for (std::uint32_t i = 0; i < frames; ++i) {
        const float l = left[i];
        const float r = right[i];
        lp = std::max(lp, std::abs(l));
        rp = std::max(rp, std::abs(r));
        ls += static_cast<double>(l) * static_cast<double>(l);
        rs += static_cast<double>(r) * static_cast<double>(r);
    }
    leftPeak_.store(lp, std::memory_order_release);
    rightPeak_.store(rp, std::memory_order_release);
    leftRms_.store(static_cast<float>(std::sqrt(ls / static_cast<double>(frames))), std::memory_order_release);
    rightRms_.store(static_cast<float>(std::sqrt(rs / static_cast<double>(frames))), std::memory_order_release);
}

void AudioEngine::addToMix(std::uint32_t index, double left, double right) noexcept {
    MixMath::compensatedAdd(left, mixLeft_[index], mixLeftCompensation_[index]);
    MixMath::compensatedAdd(right, mixRight_[index], mixRightCompensation_[index]);
}

void AudioEngine::processAudio(const float* const* inputs,
                               float* const* outputs,
                               std::uint32_t inputChannels,
                               std::uint32_t outputChannels,
                               std::uint32_t frames) noexcept {
    if (outputs == nullptr || outputChannels == 0U) return;

    for (std::uint32_t c = 0; c < outputChannels; ++c) {
        if (outputs[c] != nullptr) std::fill(outputs[c], outputs[c] + frames, 0.0F);
    }

    if (!prepared_ || frames > mixLeft_.size() || outputChannels < 2U || outputs[0] == nullptr || outputs[1] == nullptr) {
        if (outputChannels >= 2U) publishMeters(outputs[0], outputs[1], frames);
        return;
    }

    // Lock-free block-boundary plan handoff. No allocation, lock or control
    // model access occurs here.
    adoptPendingPlan();
    const VoicePlan& plan = livePlan();

    std::fill_n(mixLeft_.begin(), frames, 0.0);
    std::fill_n(mixRight_.begin(), frames, 0.0);
    std::fill_n(mixLeftCompensation_.begin(), frames, 0.0);
    std::fill_n(mixRightCompensation_.begin(), frames, 0.0);
    for (std::size_t v = 0U; v < plan.count; ++v) {
        const std::size_t trackIndex = plan.voices[v].trackIndex;
        if (trackIndex >= trackMeters_.size()) continue;
        trackMeters_[trackIndex].leftPeak.store(0.0F, std::memory_order_relaxed);
        trackMeters_[trackIndex].rightPeak.store(0.0F, std::memory_order_relaxed);
        trackMeters_[trackIndex].leftRms.store(0.0F, std::memory_order_relaxed);
        trackMeters_[trackIndex].rightRms.store(0.0F, std::memory_order_relaxed);
    }

    if (Recorder* rec = recorder_.load(std::memory_order_acquire); rec != nullptr && rec->recording()) {
        (void)rec->push(inputs, inputChannels, frames);
    }

    // Native low-latency monitoring path: input enters the current callback mix
    // without travelling through timeline/playback processing.
    if (inputMonitoring_.load(std::memory_order_acquire) && inputs != nullptr && inputChannels > 0U) {
        const double monitorGain = static_cast<double>(inputMonitorGainLinear_.load(std::memory_order_acquire));
        const float* inL = inputs[0];
        const float* inR = inputChannels > 1U ? inputs[1] : inputs[0];
        if (inL != nullptr && inR != nullptr) {
            for (std::uint32_t i = 0; i < frames; ++i) {
                addToMix(i,
                         static_cast<double>(inL[i]) * monitorGain,
                         static_cast<double>(inR[i]) * monitorGain);
            }
        }
    }

    if (transport_.isPlaying()) {
        const std::int64_t blockStart = transport_.positionSamples();
        const std::int64_t blockEnd = blockStart + static_cast<std::int64_t>(frames);
        const PanDepth depth = panDepth_.load(std::memory_order_acquire);

        for (std::size_t voiceIndex = 0U; voiceIndex < plan.count; ++voiceIndex) {
            const PreparedVoice& voice = plan.voices[voiceIndex];
            const std::size_t trackIndex = voice.trackIndex;
            if (voice.mute) continue;

            const bool memorySource = voice.source != nullptr;
            const bool diskSource = voice.diskSource != nullptr;
            if (memorySource == diskSource || voice.channels == 0U) continue;

            const std::int64_t sourceFrames = static_cast<std::int64_t>(voice.sourceFrames);
            const std::int64_t sourceOffset = static_cast<std::int64_t>(voice.sourceStartSample);
            const auto channels = voice.channels;
            const auto playableSourceFrames = sourceFrames - sourceOffset;
            if (playableSourceFrames <= 0) continue;

            const std::int64_t clipStart = std::max<std::int64_t>(0, voice.timelineStartSample);
            const std::int64_t negativeTrim = std::max<std::int64_t>(0, -voice.timelineStartSample);
            const std::int64_t effectiveSourceOffset = sourceOffset + negativeTrim;
            const std::int64_t effectiveLength = sourceFrames - effectiveSourceOffset;
            if (effectiveLength <= 0) continue;
            const std::int64_t clipEnd = clipStart + effectiveLength;

            const std::int64_t overlapStart = std::max(blockStart, clipStart);
            const std::int64_t overlapEnd = std::min(blockEnd, clipEnd);
            if (overlapStart >= overlapEnd) continue;

            const std::uint32_t overlapFrames = static_cast<std::uint32_t>(overlapEnd - overlapStart);
            const std::uint64_t firstSourceFrame = static_cast<std::uint64_t>(effectiveSourceOffset + (overlapStart - clipStart));

            const float* srcL = nullptr;
            const float* srcR = nullptr;
            DiskBlockView diskView;
            if (memorySource) {
                srcL = voice.source->channelData(0U) + firstSourceFrame;
                srcR = channels > 1U ? voice.source->channelData(1U) + firstSourceFrame : nullptr;
            } else {
                if (!voice.diskSource->acquire(firstSourceFrame, overlapFrames, diskView)) continue;
            }

            float trackLeftPeak = 0.0F;
            float trackRightPeak = 0.0F;
            double trackLeftSquares = 0.0;
            double trackRightSquares = 0.0;
            for (std::uint32_t local = 0U; local < overlapFrames; ++local) {
                const auto outIndex = static_cast<std::uint32_t>((overlapStart - blockStart) + local);
                const std::int64_t timelineSample = overlapStart + static_cast<std::int64_t>(local);
                double leftSample = 0.0;
                double rightSample = 0.0;
                if (memorySource) {
                    leftSample = static_cast<double>(srcL[local]);
                    rightSample = channels > 1U ? static_cast<double>(srcR[local]) : leftSample;
                } else {
                    const std::size_t base = static_cast<std::size_t>(diskView.frameOffset + local) * diskView.channels;
                    leftSample = static_cast<double>(diskView.interleaved[base]);
                    rightSample = channels > 1U
                        ? static_cast<double>(diskView.interleaved[base + 1U])
                        : leftSample;
                }

                double gain = voice.gain;
                if (voice.gainAutomationDb != nullptr) {
                    const float automatedDb = voice.gainAutomationDb->valueAt(timelineSample, voice.gainDb);
                    if (std::isfinite(automatedDb)) gain = MixMath::dbToLinear(static_cast<double>(automatedDb));
                }

                StereoGainPair monoPan = voice.monoPan;
                StereoGainPair balance = voice.balance;
                if (voice.panAutomation != nullptr && !voice.useDualStereoPan) {
                    const float automatedPan = std::clamp(voice.panAutomation->valueAt(timelineSample, voice.pan), -1.0F, 1.0F);
                    if (channels == 1U) monoPan = MixMath::monoPan(automatedPan, depth);
                    else balance = MixMath::stereoBalance(automatedPan);
                }

                double contributionL = 0.0;
                double contributionR = 0.0;
                if (channels == 1U) {
                    const double x = leftSample * gain;
                    contributionL = x * monoPan.left;
                    contributionR = x * monoPan.right;
                } else if (voice.useDualStereoPan) {
                    const double l = leftSample * gain;
                    const double r = rightSample * gain;
                    contributionL = l * voice.stereoLeftPan.left + r * voice.stereoRightPan.left;
                    contributionR = l * voice.stereoLeftPan.right + r * voice.stereoRightPan.right;
                } else {
                    contributionL = leftSample * gain * balance.left;
                    contributionR = rightSample * gain * balance.right;
                }
                addToMix(outIndex, contributionL, contributionR);

                const float meterL = static_cast<float>(contributionL);
                const float meterR = static_cast<float>(contributionR);
                trackLeftPeak = std::max(trackLeftPeak, std::abs(meterL));
                trackRightPeak = std::max(trackRightPeak, std::abs(meterR));
                trackLeftSquares += contributionL * contributionL;
                trackRightSquares += contributionR * contributionR;
            }

            if (trackIndex < trackMeters_.size() && overlapFrames != 0U) {
                auto& meter = trackMeters_[trackIndex];
                meter.leftPeak.store(trackLeftPeak, std::memory_order_release);
                meter.rightPeak.store(trackRightPeak, std::memory_order_release);
                meter.leftRms.store(static_cast<float>(std::sqrt(trackLeftSquares / static_cast<double>(overlapFrames))), std::memory_order_release);
                meter.rightRms.store(static_cast<float>(std::sqrt(trackRightSquares / static_cast<double>(overlapFrames))), std::memory_order_release);
            }

            if (diskSource) voice.diskSource->release(diskView);
        }
        transport_.advance(frames);
    }

    // The internal bus is deliberately not clipped at 0 dBFS. This preserves
    // floating-point headroom. The Master Fader changes path gain without
    // introducing a nonlinear ceiling.
    const double targetMasterGain = static_cast<double>(masterGainTargetLinear_.load(std::memory_order_acquire));
    if (frames <= 1U) {
        masterGainCurrent_ = targetMasterGain;
        if (frames == 1U) {
            outputs[0][0] = static_cast<float>((mixLeft_[0] + mixLeftCompensation_[0]) * masterGainCurrent_);
            outputs[1][0] = static_cast<float>((mixRight_[0] + mixRightCompensation_[0]) * masterGainCurrent_);
        }
    } else {
        const double step = (targetMasterGain - masterGainCurrent_) / static_cast<double>(frames - 1U);
        double g = masterGainCurrent_;
        for (std::uint32_t i = 0; i < frames; ++i) {
            outputs[0][i] = static_cast<float>((mixLeft_[i] + mixLeftCompensation_[i]) * g);
            outputs[1][i] = static_cast<float>((mixRight_[i] + mixRightCompensation_[i]) * g);
            g += step;
        }
        masterGainCurrent_ = targetMasterGain;
    }

    // Master meters are post-fader, derived from the actual device-bound signal.
    publishMeters(outputs[0], outputs[1], frames);
}

} // namespace silveton
