#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace silveton {

float AudioEngine::dbToLinear(float db) noexcept {
    return static_cast<float>(MixMath::dbToLinear(static_cast<double>(db)));
}

void AudioEngine::prepare(const AudioDeviceConfig& config) {
    if (!std::isfinite(config.sampleRate) || config.sampleRate <= 0.0) throw std::invalid_argument("invalid engine sample rate");
    if (config.blockSize == 0U) throw std::invalid_argument("invalid engine block size");
    if (config.outputChannels < 2U) throw std::invalid_argument("engine milestone requires stereo output");
    config_ = config;
    transport_.setSampleRate(config.sampleRate);
    mixLeft_.assign(config.blockSize, 0.0);
    mixRight_.assign(config.blockSize, 0.0);
    mixLeftCompensation_.assign(config.blockSize, 0.0);
    mixRightCompensation_.assign(config.blockSize, 0.0);
    masterGainCurrent_ = static_cast<double>(masterGainTargetLinear_.load(std::memory_order_acquire));
    prepared_ = true;
}

void AudioEngine::rebuildVoicePlan() {
    if (transport_.isPlaying()) throw std::logic_error("cannot rebuild voice plan while transport is playing");
    voicedTrackIndices_.clear();
    voicedTrackIndices_.reserve(tracks_.size());
    for (std::size_t i = 0; i < tracks_.size(); ++i) {
        if (tracks_[i].voiceEnabled) voicedTrackIndices_.push_back(i);
    }
    std::stable_sort(voicedTrackIndices_.begin(), voicedTrackIndices_.end(), [this](std::size_t a, std::size_t b) {
        return tracks_[a].voicePriority > tracks_[b].voicePriority;
    });
    if (voiceLimit_ != 0U && voicedTrackIndices_.size() > voiceLimit_) voicedTrackIndices_.resize(voiceLimit_);

    preparedVoices_.clear();
    preparedVoices_.reserve(voicedTrackIndices_.size());
    for (const std::size_t trackIndex : voicedTrackIndices_) {
        const auto& track = tracks_[trackIndex];
        PreparedVoice voice;
        voice.trackIndex = trackIndex;
        voice.gain = MixMath::dbToLinear(static_cast<double>(track.gainDb));
        if (track.source != nullptr && track.source->channels() == 1U) {
            voice.monoPan = MixMath::monoPan(track.pan, panDepth_);
        } else if (track.useDualStereoPan) {
            voice.stereoLeftPan = MixMath::monoPan(track.stereoLeftPan, panDepth_);
            voice.stereoRightPan = MixMath::monoPan(track.stereoRightPan, panDepth_);
        } else {
            voice.balance = MixMath::stereoBalance(track.pan);
        }
        preparedVoices_.push_back(voice);
    }
}

void AudioEngine::clearTracks() {
    if (transport_.isPlaying()) throw std::logic_error("cannot edit track graph while transport is playing");
    tracks_.clear();
    voicedTrackIndices_.clear();
    preparedVoices_.clear();
}

void AudioEngine::addTrack(TimelineTrack track) {
    if (transport_.isPlaying()) throw std::logic_error("cannot edit track graph while transport is playing");
    if (track.source == nullptr) throw std::invalid_argument("track source is null");
    if (track.source->channels() == 0U) throw std::invalid_argument("track source has no channels");
    if (track.sourceStartSample >= track.source->frames()) throw std::invalid_argument("track source offset outside buffer");
    track.pan = std::clamp(track.pan, -1.0F, 1.0F);
    track.stereoLeftPan = std::clamp(track.stereoLeftPan, -1.0F, 1.0F);
    track.stereoRightPan = std::clamp(track.stereoRightPan, -1.0F, 1.0F);
    tracks_.push_back(track);
    rebuildVoicePlan();
}

void AudioEngine::setVoiceLimit(std::size_t maxVoices) {
    if (transport_.isPlaying()) throw std::logic_error("cannot change voice allocation while transport is playing");
    voiceLimit_ = maxVoices;
    rebuildVoicePlan();
}

void AudioEngine::setPanDepth(PanDepth depth) {
    if (transport_.isPlaying()) throw std::logic_error("cannot change pan depth while transport is playing");
    panDepth_ = depth;
    rebuildVoicePlan();
}

void AudioEngine::setLowLatencyInputMonitoring(bool enabled, float gainDb) noexcept {
    inputMonitorGainLinear_.store(dbToLinear(std::isfinite(gainDb) ? gainDb : 0.0F), std::memory_order_release);
    inputMonitoring_.store(enabled, std::memory_order_release);
}

void AudioEngine::setMasterFaderDb(float db) noexcept {
    const float safeDb = std::isfinite(db) ? std::clamp(db, -144.0F, 24.0F) : 0.0F;
    masterFaderDb_.store(safeDb, std::memory_order_release);
    masterGainTargetLinear_.store(dbToLinear(safeDb), std::memory_order_release);
}

StereoMeterSnapshot AudioEngine::outputMeter() const noexcept {
    return {
        leftPeak_.load(std::memory_order_acquire),
        rightPeak_.load(std::memory_order_acquire),
        leftRms_.load(std::memory_order_acquire),
        rightRms_.load(std::memory_order_acquire)
    };
}

void AudioEngine::publishMeters(const float* left, const float* right, std::uint32_t frames) noexcept {
    if (frames == 0U || left == nullptr || right == nullptr) {
        leftPeak_.store(0.0F, std::memory_order_release);
        rightPeak_.store(0.0F, std::memory_order_release);
        leftRms_.store(0.0F, std::memory_order_release);
        rightRms_.store(0.0F, std::memory_order_release);
        return;
    }

    float lp = 0.0F, rp = 0.0F;
    double ls = 0.0, rs = 0.0;
    for (std::uint32_t i = 0; i < frames; ++i) {
        const float l = left[i];
        const float r = right[i];
        lp = std::max(lp, std::abs(l));
        rp = std::max(rp, std::abs(r));
        ls += static_cast<double>(l) * static_cast<double>(l);
        rs += static_cast<double>(r) * static_cast<double>(r);
    }
    leftPeak_.store(lp, std::memory_order_release);
    rightPeak_.store(rp, std::memory_order_release);
    leftRms_.store(static_cast<float>(std::sqrt(ls / static_cast<double>(frames))), std::memory_order_release);
    rightRms_.store(static_cast<float>(std::sqrt(rs / static_cast<double>(frames))), std::memory_order_release);
}

void AudioEngine::addToMix(std::uint32_t index, double left, double right) noexcept {
    MixMath::compensatedAdd(left, mixLeft_[index], mixLeftCompensation_[index]);
    MixMath::compensatedAdd(right, mixRight_[index], mixRightCompensation_[index]);
}

void AudioEngine::processAudio(const float* const* inputs,
                               float* const* outputs,
                               std::uint32_t inputChannels,
                               std::uint32_t outputChannels,
                               std::uint32_t frames) noexcept {
    if (outputs == nullptr || outputChannels == 0U) return;

    for (std::uint32_t c = 0; c < outputChannels; ++c) {
        if (outputs[c] != nullptr) std::fill(outputs[c], outputs[c] + frames, 0.0F);
    }

    if (!prepared_ || frames > mixLeft_.size() || outputChannels < 2U || outputs[0] == nullptr || outputs[1] == nullptr) {
        if (outputChannels >= 2U) publishMeters(outputs[0], outputs[1], frames);
        return;
    }

    std::fill_n(mixLeft_.begin(), frames, 0.0);
    std::fill_n(mixRight_.begin(), frames, 0.0);
    std::fill_n(mixLeftCompensation_.begin(), frames, 0.0);
    std::fill_n(mixRightCompensation_.begin(), frames, 0.0);

    if (Recorder* rec = recorder_.load(std::memory_order_acquire); rec != nullptr && rec->recording()) {
        (void)rec->push(inputs, inputChannels, frames);
    }

    // Native low-latency monitoring path: input enters the current callback mix
    // without travelling through timeline/playback processing.
    if (inputMonitoring_.load(std::memory_order_acquire) && inputs != nullptr && inputChannels > 0U) {
        const double monitorGain = static_cast<double>(inputMonitorGainLinear_.load(std::memory_order_acquire));
        const float* inL = inputs[0];
        const float* inR = inputChannels > 1U ? inputs[1] : inputs[0];
        if (inL != nullptr && inR != nullptr) {
            for (std::uint32_t i = 0; i < frames; ++i) {
                addToMix(i,
                         static_cast<double>(inL[i]) * monitorGain,
                         static_cast<double>(inR[i]) * monitorGain);
            }
        }
    }

    if (transport_.isPlaying()) {
        const std::int64_t blockStart = transport_.positionSamples();
        const std::int64_t blockEnd = blockStart + static_cast<std::int64_t>(frames);

        for (const auto& voice : preparedVoices_) {
            const std::size_t trackIndex = voice.trackIndex;
            if (trackIndex >= tracks_.size()) continue;
            const auto& track = tracks_[trackIndex];
            if (track.mute || track.source == nullptr) continue;

            const auto sourceFrames = static_cast<std::int64_t>(track.source->frames());
            const auto sourceOffset = static_cast<std::int64_t>(track.sourceStartSample);
            const auto playableSourceFrames = sourceFrames - sourceOffset;
            if (playableSourceFrames <= 0) continue;

            const std::int64_t clipStart = std::max<std::int64_t>(0, track.timelineStartSample);
            const std::int64_t negativeTrim = std::max<std::int64_t>(0, -track.timelineStartSample);
            const std::int64_t effectiveSourceOffset = sourceOffset + negativeTrim;
            const std::int64_t effectiveLength = sourceFrames - effectiveSourceOffset;
            if (effectiveLength <= 0) continue;
            const std::int64_t clipEnd = clipStart + effectiveLength;

            const std::int64_t overlapStart = std::max(blockStart, clipStart);
            const std::int64_t overlapEnd = std::min(blockEnd, clipEnd);
            if (overlapStart >= overlapEnd) continue;

            const double gain = voice.gain;
            const auto channels = track.source->channels();
            const float* srcL = track.source->channelData(0U);
            const float* srcR = channels > 1U ? track.source->channelData(1U) : nullptr;

            for (std::int64_t timelineSample = overlapStart; timelineSample < overlapEnd; ++timelineSample) {
                const auto outIndex = static_cast<std::uint32_t>(timelineSample - blockStart);
                const auto srcIndex = static_cast<std::size_t>(effectiveSourceOffset + (timelineSample - clipStart));
                if (channels == 1U) {
                    const double x = static_cast<double>(srcL[srcIndex]) * gain;
                    addToMix(outIndex, x * voice.monoPan.left, x * voice.monoPan.right);
                } else if (track.useDualStereoPan) {
                    const double l = static_cast<double>(srcL[srcIndex]) * gain;
                    const double r = static_cast<double>(srcR[srcIndex]) * gain;
                    addToMix(outIndex,
                             l * voice.stereoLeftPan.left + r * voice.stereoRightPan.left,
                             l * voice.stereoLeftPan.right + r * voice.stereoRightPan.right);
                } else {
                    addToMix(outIndex,
                             static_cast<double>(srcL[srcIndex]) * gain * voice.balance.left,
                             static_cast<double>(srcR[srcIndex]) * gain * voice.balance.right);
                }
            }
        }
        transport_.advance(frames);
    }

    // The internal bus is deliberately not clipped at 0 dBFS. This preserves
    // floating-point headroom. The Master Fader changes path gain without
    // introducing a nonlinear ceiling.
    const double targetMasterGain = static_cast<double>(masterGainTargetLinear_.load(std::memory_order_acquire));
    if (frames <= 1U) {
        masterGainCurrent_ = targetMasterGain;
        if (frames == 1U) {
            outputs[0][0] = static_cast<float>((mixLeft_[0] + mixLeftCompensation_[0]) * masterGainCurrent_);
            outputs[1][0] = static_cast<float>((mixRight_[0] + mixRightCompensation_[0]) * masterGainCurrent_);
        }
    } else {
        const double step = (targetMasterGain - masterGainCurrent_) / static_cast<double>(frames - 1U);
        double g = masterGainCurrent_;
        for (std::uint32_t i = 0; i < frames; ++i) {
            outputs[0][i] = static_cast<float>((mixLeft_[i] + mixLeftCompensation_[i]) * g);
            outputs[1][i] = static_cast<float>((mixRight_[i] + mixRightCompensation_[i]) * g);
            g += step;
        }
        masterGainCurrent_ = targetMasterGain;
    }

    // Master meters are post-fader, derived from the actual device-bound signal.
    publishMeters(outputs[0], outputs[1], frames);
}

} // namespace silveton
