#include "silveton/Mixer.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <vector>

namespace silveton {

float Mixer::dbToLinear(float db) noexcept {
    return static_cast<float>(MixMath::dbToLinear(static_cast<double>(db)));
}

void Mixer::mixStereo(const std::vector<TrackState>& tracks, AudioBuffer& output, PanDepth panDepth) {
    if (output.channels() != 2U) throw std::invalid_argument("mixStereo requires 2-channel output");
    output.clear();

    std::vector<double> left(output.frames(), 0.0);
    std::vector<double> right(output.frames(), 0.0);
    std::vector<double> leftComp(output.frames(), 0.0);
    std::vector<double> rightComp(output.frames(), 0.0);

    for (const auto& track : tracks) {
        if (track.mute || track.source == nullptr || track.source->channels() == 0U) continue;
        if (track.source->frames() != output.frames()) throw std::invalid_argument("track/output frame mismatch");

        const double gain = MixMath::dbToLinear(static_cast<double>(track.gainDb));
        const auto channels = track.source->channels();

        if (channels == 1U) {
            const auto p = MixMath::monoPan(track.pan, panDepth);
            const float* src = track.source->channelData(0U);
            for (std::size_t f = 0; f < output.frames(); ++f) {
                const double x = static_cast<double>(src[f]) * gain;
                MixMath::compensatedAdd(x * p.left, left[f], leftComp[f]);
                MixMath::compensatedAdd(x * p.right, right[f], rightComp[f]);
            }
            continue;
        }

        const float* srcL = track.source->channelData(0U);
        const float* srcR = track.source->channelData(1U);

        if (track.useDualStereoPan) {
            const auto leftPan = MixMath::monoPan(track.stereoLeftPan, panDepth);
            const auto rightPan = MixMath::monoPan(track.stereoRightPan, panDepth);
            for (std::size_t f = 0; f < output.frames(); ++f) {
                const double l = static_cast<double>(srcL[f]) * gain;
                const double r = static_cast<double>(srcR[f]) * gain;
                MixMath::compensatedAdd(l * leftPan.left + r * rightPan.left, left[f], leftComp[f]);
                MixMath::compensatedAdd(l * leftPan.right + r * rightPan.right, right[f], rightComp[f]);
            }
        } else {
            const auto bal = MixMath::stereoBalance(track.pan);
            for (std::size_t f = 0; f < output.frames(); ++f) {
                MixMath::compensatedAdd(static_cast<double>(srcL[f]) * gain * bal.left, left[f], leftComp[f]);
                MixMath::compensatedAdd(static_cast<double>(srcR[f]) * gain * bal.right, right[f], rightComp[f]);
            }
        }
    }

    float* outL = output.channelData(0U);
    float* outR = output.channelData(1U);
    for (std::size_t f = 0; f < output.frames(); ++f) {
        outL[f] = static_cast<float>(left[f] + leftComp[f]);
        outR[f] = static_cast<float>(right[f] + rightComp[f]);
    }
}

} // namespace silveton
