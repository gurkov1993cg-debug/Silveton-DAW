#include "silveton/Vst3ScannerIsolation.h"

#include <chrono>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <thread>

#if defined(__APPLE__) || defined(__linux__)
#include <cerrno>
#include <csignal>
#include <cstdlib>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

namespace silveton {
namespace {
constexpr std::uintmax_t kMaxScannerOutputBytes = 4U * 1024U * 1024U;

std::vector<std::string> splitTabs(const std::string& line) {
    std::vector<std::string> fields;
    std::size_t start = 0U;
    bool escaped = false;
    for (std::size_t i = 0U; i < line.size(); ++i) {
        if (escaped) { escaped = false; continue; }
        if (line[i] == '\\') { escaped = true; continue; }
        if (line[i] == '\t') {
            fields.push_back(line.substr(start, i - start));
            start = i + 1U;
        }
    }
    fields.push_back(line.substr(start));
    return fields;
}

std::string makeTempPath() {
#if defined(__APPLE__) || defined(__linux__)
    std::string pattern = "/tmp/silveton-vst3scan-XXXXXX";
    std::vector<char> buffer(pattern.begin(), pattern.end());
    buffer.push_back('\0');
    const int fd = ::mkstemp(buffer.data());
    if (fd < 0) throw std::runtime_error("cannot create VST3 scanner temp file");
    ::close(fd);
    return std::string(buffer.data());
#else
    char tmp[L_tmpnam];
    if (std::tmpnam(tmp) == nullptr) throw std::runtime_error("cannot create VST3 scanner temp file");
    return tmp;
#endif
}

bool parseScannerFile(const std::string& path, Vst3IsolatedScanResult& result) {
    std::ifstream in(path.c_str(), std::ios::binary | std::ios::ate);
    if (!in) { result.error = "scanner did not produce an output file"; return false; }
    const auto size = in.tellg();
    if (size < 0 || static_cast<std::uintmax_t>(size) > kMaxScannerOutputBytes) {
        result.error = "scanner output exceeds safety limit";
        return false;
    }
    in.seekg(0, std::ios::beg);
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        const auto fields = splitTabs(line);
        if (fields.empty()) continue;
        if (fields[0] == "ERR") {
            if (fields.size() >= 2U) {
                std::string decoded;
                if (decodeVst3ScanField(fields[1], decoded)) result.error = std::move(decoded);
            }
            continue;
        }
        if (fields[0] != "PLUGIN" || fields.size() != 6U) continue;
        Vst3ScanRecord r;
        if (!decodeVst3ScanField(fields[1], r.modulePath) ||
            !decodeVst3ScanField(fields[2], r.classId) ||
            !decodeVst3ScanField(fields[3], r.name) ||
            !decodeVst3ScanField(fields[4], r.vendor) ||
            !decodeVst3ScanField(fields[5], r.version)) {
            continue;
        }
        if (!r.modulePath.empty() && !r.classId.empty()) result.plugins.push_back(std::move(r));
    }
    return true;
}
}

std::string encodeVst3ScanField(const std::string& value) {
    std::string out;
    out.reserve(value.size());
    for (const char c : value) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '\t': out += "\\t"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            default: out += c; break;
        }
    }
    return out;
}

bool decodeVst3ScanField(const std::string& value, std::string& out) {
    out.clear();
    out.reserve(value.size());
    for (std::size_t i = 0U; i < value.size(); ++i) {
        if (value[i] != '\\') { out += value[i]; continue; }
        if (++i >= value.size()) return false;
        switch (value[i]) {
            case '\\': out += '\\'; break;
            case 't': out += '\t'; break;
            case 'n': out += '\n'; break;
            case 'r': out += '\r'; break;
            default: return false;
        }
    }
    return true;
}

Vst3IsolatedScanResult scanVst3ModuleIsolated(const std::string& scannerExecutable,
                                              const std::string& modulePath,
                                              std::uint32_t timeoutMs,
                                              Vst3Blacklist& blacklist) {
    Vst3IsolatedScanResult result;
    if (scannerExecutable.empty() || modulePath.empty()) {
        result.crashedOrFailed = true;
        result.error = "invalid scanner executable/module path";
        return result;
    }
    if (blacklist.contains(modulePath, "*")) {
        result.skippedBlacklisted = true;
        result.error = blacklist.reason(modulePath, "*");
        return result;
    }
#if defined(__APPLE__) || defined(__linux__)
    const std::string temp = makeTempPath();
    const pid_t pid = ::fork();
    if (pid < 0) {
        (void)std::remove(temp.c_str());
        result.crashedOrFailed = true;
        result.error = "fork failed";
        blacklist.add(modulePath, "*", result.error);
        return result;
    }
    if (pid == 0) {
        ::execl(scannerExecutable.c_str(), scannerExecutable.c_str(), modulePath.c_str(), temp.c_str(), static_cast<char*>(nullptr));
        ::_exit(127);
    }

    const auto started = std::chrono::steady_clock::now();
    int status = 0;
    bool finished = false;
    while (!finished) {
        const pid_t waited = ::waitpid(pid, &status, WNOHANG);
        if (waited == pid) { finished = true; break; }
        if (waited < 0 && errno != EINTR) { finished = true; status = -1; break; }
        const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started).count();
        if (elapsed >= static_cast<long long>(timeoutMs)) {
            (void)::kill(pid, SIGKILL);
            (void)::waitpid(pid, &status, 0);
            result.timedOut = true;
            result.crashedOrFailed = true;
            result.error = "scanner timeout";
            blacklist.add(modulePath, "*", result.error);
            (void)std::remove(temp.c_str());
            return result;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    if (status == -1 || !WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        result.crashedOrFailed = true;
        if (WIFSIGNALED(status)) result.error = "scanner terminated by signal " + std::to_string(WTERMSIG(status));
        else if (WIFEXITED(status)) result.error = "scanner exited with code " + std::to_string(WEXITSTATUS(status));
        else result.error = "scanner abnormal exit";
        result.exitCode = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
        blacklist.add(modulePath, "*", result.error);
        (void)std::remove(temp.c_str());
        return result;
    }
    result.exitCode = 0;
    if (!parseScannerFile(temp, result)) {
        result.crashedOrFailed = true;
        blacklist.add(modulePath, "*", result.error.empty() ? "invalid scanner output" : result.error);
    }
    (void)std::remove(temp.c_str());
    return result;
#else
    result.crashedOrFailed = true;
    result.error = "isolated VST3 scanning is unsupported on this platform";
    blacklist.add(modulePath, "*", result.error);
    return result;
#endif
}

} // namespace silveton
