#include "silveton/OfflineBounce.h"
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/MidiTimeline.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/Vst3Runtime.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

namespace silveton {
namespace {

template <typename T>
void writeLE(std::fstream& out, T value) {
    out.write(reinterpret_cast<const char*>(&value), static_cast<std::streamsize>(sizeof(T)));
}

class Float32WaveStreamWriter final {
public:
    Float32WaveStreamWriter(const std::string& path, std::uint16_t channels, std::uint32_t sampleRate)
        : channels_(channels), sampleRate_(sampleRate) {
        if (channels_ == 0U || sampleRate_ == 0U) throw std::invalid_argument("invalid bounce WAV format");
        out_.open(path.c_str(), std::ios::binary | std::ios::in | std::ios::out | std::ios::trunc);
        if (!out_) throw std::runtime_error("cannot open bounce WAV");
        writeHeader(false, 0U, 0U);
        out_.seekp(80, std::ios::beg);
    }

    ~Float32WaveStreamWriter() {
        if (!finalized_) {
            try { finalize(); } catch (...) {}
        }
    }

    void writeStereo(const float* left, const float* right, std::uint32_t frames) {
        if (finalized_) throw std::logic_error("bounce WAV already finalized");
        if (channels_ != 2U || left == nullptr || right == nullptr) throw std::invalid_argument("invalid bounce stereo block");
        for (std::uint32_t i = 0U; i < frames; ++i) {
            writeLE(out_, left[i]);
            writeLE(out_, right[i]);
        }
        if (!out_) throw std::runtime_error("bounce WAV write failed");
        frames_ += frames;
        dataBytes_ += static_cast<std::uint64_t>(frames) * 2U * sizeof(float);
    }

    void finalize() {
        if (finalized_) return;
        out_.flush();
        if (!out_) throw std::runtime_error("bounce WAV flush failed");
        const std::uint64_t riffSize = 72U + dataBytes_;
        const bool rf64 = riffSize > std::numeric_limits<std::uint32_t>::max() ||
                          dataBytes_ > std::numeric_limits<std::uint32_t>::max();
        out_.seekp(0, std::ios::beg);
        writeHeader(rf64, frames_, dataBytes_);
        out_.flush();
        if (!out_) throw std::runtime_error("bounce WAV finalize failed");
        finalized_ = true;
    }

private:
    void writeHeader(bool rf64, std::uint64_t frames, std::uint64_t dataBytes) {
        constexpr std::uint16_t bitsPerSample = 32U;
        const std::uint16_t blockAlign = static_cast<std::uint16_t>(channels_ * sizeof(float));
        const std::uint64_t byteRate64 = static_cast<std::uint64_t>(sampleRate_) * blockAlign;
        if (byteRate64 > std::numeric_limits<std::uint32_t>::max()) throw std::overflow_error("bounce WAV byte rate overflow");
        const auto byteRate = static_cast<std::uint32_t>(byteRate64);
        const std::uint64_t riffSize = 72U + dataBytes;

        if (rf64) {
            out_.write("RF64", 4);
            writeLE(out_, std::uint32_t{0xFFFFFFFFU});
            out_.write("WAVE", 4);
            out_.write("ds64", 4);
            writeLE(out_, std::uint32_t{28U});
            writeLE(out_, riffSize);
            writeLE(out_, dataBytes);
            writeLE(out_, frames);
            writeLE(out_, std::uint32_t{0U});
        } else {
            if (riffSize > std::numeric_limits<std::uint32_t>::max() || dataBytes > std::numeric_limits<std::uint32_t>::max())
                throw std::overflow_error("bounce RIFF size overflow");
            out_.write("RIFF", 4);
            writeLE(out_, static_cast<std::uint32_t>(riffSize));
            out_.write("WAVE", 4);
            out_.write("JUNK", 4);
            writeLE(out_, std::uint32_t{28U});
            writeLE(out_, std::uint64_t{0U});
            writeLE(out_, std::uint64_t{0U});
            writeLE(out_, std::uint64_t{0U});
            writeLE(out_, std::uint32_t{0U});
        }

        out_.write("fmt ", 4);
        writeLE(out_, std::uint32_t{16U});
        writeLE(out_, std::uint16_t{3U});
        writeLE(out_, channels_);
        writeLE(out_, sampleRate_);
        writeLE(out_, byteRate);
        writeLE(out_, blockAlign);
        writeLE(out_, bitsPerSample);
        out_.write("data", 4);
        writeLE(out_, rf64 ? std::uint32_t{0xFFFFFFFFU} : static_cast<std::uint32_t>(dataBytes));
    }

    std::fstream out_;
    std::uint16_t channels_ {0U};
    std::uint32_t sampleRate_ {0U};
    std::uint64_t frames_ {0U};
    std::uint64_t dataBytes_ {0U};
    bool finalized_ {false};
};

struct MidiBouncePlan {
    int port {-1};
    MidiRenderPlan plan;
};

std::vector<MidiBouncePlan> buildMidiPlans(const Project& project) {
    std::vector<MidiBouncePlan> result;
    result.reserve(project.midiTracks.size());
    for (const auto& track : project.midiTracks) {
        if (track.outputPort < 0) continue;
        MidiBouncePlan entry;
        entry.port = track.outputPort;
        entry.plan = track.sequence.compile(project.tempoMap);
        result.push_back(std::move(entry));
    }
    return result;
}

std::uint64_t secondsToSamples(double seconds, double sampleRate) {
    if (!std::isfinite(seconds) || seconds < 0.0) throw std::invalid_argument("invalid bounce tail limit");
    const long double samples = static_cast<long double>(seconds) * static_cast<long double>(sampleRate);
    if (samples >= static_cast<long double>(std::numeric_limits<std::uint64_t>::max()))
        return std::numeric_limits<std::uint64_t>::max();
    return static_cast<std::uint64_t>(std::llround(samples));
}

} // namespace

OfflineBounceResult OfflineBounce::renderFloat32Wav(const std::string& path,
                                                     Project& project,
                                                     AudioEngine& engine,
                                                     Vst3RuntimeRack* vst3Rack,
                                                     const OfflineBounceOptions& options) {
    if (path.empty()) throw std::invalid_argument("bounce path is empty");
    if (options.startSample < 0 || options.endSample <= options.startSample)
        throw std::invalid_argument("invalid bounce range");
    if (engine.transport().isPlaying())
        throw std::logic_error("offline bounce requires stopped transport");
    if (engine.recorder() != nullptr && engine.recorder()->recording())
        throw std::logic_error("offline bounce is unavailable while recording");

    const AudioDeviceConfig config = engine.deviceConfig();
    if (!(config.sampleRate > 0.0) || config.blockSize == 0U || config.outputChannels < 2U)
        throw std::logic_error("offline bounce requires a prepared stereo AudioEngine");
    if (std::abs(config.sampleRate - project.sampleRate) > 0.5)
        throw std::invalid_argument("project and AudioEngine sample rates differ");

    const std::uint32_t blockSize = options.blockSize == 0U ? config.blockSize : options.blockSize;
    if (blockSize == 0U || blockSize > config.blockSize)
        throw std::invalid_argument("bounce block size exceeds prepared AudioEngine block size");

    const auto roundedSampleRate = std::llround(config.sampleRate);
    if (roundedSampleRate <= 0 || roundedSampleRate > std::numeric_limits<std::uint32_t>::max())
        throw std::invalid_argument("bounce sample rate is not representable as WAV rate");
    const auto sampleRate = static_cast<std::uint32_t>(roundedSampleRate);

    if (engine.processorGraphPublicationPending())
        throw std::logic_error("offline bounce requires committed processor graph state");

    ProcessorGraph* const bounceGraph = engine.processorGraph();
    if (bounceGraph != nullptr && !bounceGraph->setRunMode(ProcessorRunMode::Offline))
        throw std::runtime_error("processor graph rejected offline export mode");

    const bool oldCycle = engine.transport().cycleEnabled();
    const std::int64_t oldCycleStart = engine.transport().cycleStartSample();
    const std::int64_t oldCycleEnd = engine.transport().cycleEndSample();
    const std::int64_t oldPosition = engine.transport().positionSamples();

    struct RestoreTransport final {
        AudioEngine& engine;
        bool cycle;
        std::int64_t cycleStart;
        std::int64_t cycleEnd;
        std::int64_t position;
        ProcessorGraph* graph;
        ~RestoreTransport() {
            engine.transport().stop();
            if (graph != nullptr) {
                try { (void)graph->setRunMode(ProcessorRunMode::Realtime); } catch (...) {}
                graph->reset();
            }
            try { engine.transport().setCycleRange(cycle, cycleStart, cycleEnd); } catch (...) {}
            engine.transport().seekSamples(position);
        }
    } restore {engine, oldCycle, oldCycleStart, oldCycleEnd, oldPosition, bounceGraph};

    engine.transport().setCycleRange(false, 0, 0);
    if (bounceGraph != nullptr) bounceGraph->reset();

    const auto midiPlans = buildMidiPlans(project);
    std::vector<float> outL(blockSize, 0.0F);
    std::vector<float> outR(blockSize, 0.0F);
    std::array<float*, 2U> outputPtrs {outL.data(), outR.data()};

    Float32WaveStreamWriter writer(path, 2U, sampleRate);
    OfflineBounceResult result;
    result.rangeFrames = static_cast<std::uint64_t>(options.endSample - options.startSample);

    auto queueMusicalData = [&](std::int64_t blockStart, std::uint32_t frames) {
        if (vst3Rack == nullptr) return;
        vst3Rack->queueAutomationForBlock(blockStart, frames);
        for (const auto& midi : midiPlans)
            (void)vst3Rack->queueMidiPlanForBlock(midi.port, midi.plan, blockStart, frames);
    };

    auto render = [&](std::int64_t blockStart, std::uint32_t frames, bool writeOutput, bool queueEvents) {
        if (queueEvents) queueMusicalData(blockStart, frames);
        engine.processAudio(nullptr, outputPtrs.data(), 0U, 2U, frames);
        if (vst3Rack != nullptr) vst3Rack->serviceOutputParameters();
        if (!writeOutput) return;
        for (std::uint32_t i = 0U; i < frames; ++i) {
            result.peak = std::max(result.peak, std::abs(outL[i]));
            result.peak = std::max(result.peak, std::abs(outR[i]));
        }
        writer.writeStereo(outL.data(), outR.data(), frames);
        result.totalFrames += frames;
    };

    const std::int64_t preRollStart = options.preRollSamples >= static_cast<std::uint64_t>(options.startSample)
        ? 0
        : options.startSample - static_cast<std::int64_t>(options.preRollSamples);
    engine.transport().seekSamples(preRollStart);
    engine.transport().play();

    std::int64_t cursor = preRollStart;
    while (cursor < options.startSample) {
        const std::int64_t remaining = options.startSample - cursor;
        const std::uint32_t frames = static_cast<std::uint32_t>(std::min<std::int64_t>(remaining, blockSize));
        render(cursor, frames, false, true);
        cursor += frames;
    }

    while (cursor < options.endSample) {
        const std::int64_t remaining = options.endSample - cursor;
        const std::uint32_t frames = static_cast<std::uint32_t>(std::min<std::int64_t>(remaining, blockSize));
        render(cursor, frames, true, true);
        cursor += frames;
    }

    engine.transport().stop();

    std::uint64_t requestedTail = 0U;
    if (options.tailMode == BounceTailMode::Fixed) {
        requestedTail = options.fixedTailSamples;
    } else if (options.tailMode == BounceTailMode::Automatic) {
        if (bounceGraph != nullptr) {
            requestedTail = bounceGraph->maximumTailSamples();
            if (requestedTail == std::numeric_limits<std::uint64_t>::max()) {
                result.processorReportedInfiniteTail = true;
                requestedTail = secondsToSamples(options.infiniteTailLimitSeconds, config.sampleRate);
            }
        }
    }

    std::uint64_t tailRemaining = requestedTail;
    while (tailRemaining != 0U) {
        const std::uint32_t frames = static_cast<std::uint32_t>(std::min<std::uint64_t>(tailRemaining, blockSize));
        render(options.endSample, frames, true, false);
        result.tailFrames += frames;
        tailRemaining -= frames;
    }

    writer.finalize();
    return result;
}

} // namespace silveton
