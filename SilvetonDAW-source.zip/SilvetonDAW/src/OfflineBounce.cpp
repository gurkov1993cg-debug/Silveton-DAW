#include "silveton/OfflineBounce.h"
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/MidiTimeline.h"
#include "silveton/ProcessorGraph.h"
#include "silveton/Vst3Runtime.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <deque>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>

namespace silveton {
namespace {

template <typename T>
void writeLE(std::fstream& out, T value) {
    out.write(reinterpret_cast<const char*>(&value), static_cast<std::streamsize>(sizeof(T)));
}

class AudioFileStreamWriter final {
public:
    AudioFileStreamWriter(const std::string& path, std::uint16_t channels, std::uint32_t sampleRate,
                          OfflineBounceFileOptions options)
        : channels_(channels), sampleRate_(sampleRate), options_(options) {
        if (channels_ == 0U || sampleRate_ == 0U) throw std::invalid_argument("invalid bounce audio format");
        if (options_.container == BounceContainer::Aiff && options_.sampleFormat == BounceSampleFormat::Float32)
            throw std::invalid_argument("AIFF Float32 is not supported; use PCM32 or WAV Float32");
        out_.open(path.c_str(), std::ios::binary | std::ios::in | std::ios::out | std::ios::trunc);
        if (!out_) throw std::runtime_error("cannot open bounce audio file");
        if (options_.container == BounceContainer::Wav) { writeWavHeader(false, 0U, 0U); out_.seekp(80, std::ios::beg); }
        else { writeAiffHeader(0U, 0U); out_.seekp(54, std::ios::beg); }
    }
    ~AudioFileStreamWriter(){ if(!finalized_) { try{finalize();}catch(...){} } }

    void writeStereo(const float* left, const float* right, std::uint32_t frames) {
        if (finalized_) throw std::logic_error("bounce file already finalized");
        if (channels_ != 2U || left == nullptr || right == nullptr)
            throw std::invalid_argument("invalid bounce stereo block");
        for (std::uint32_t i = 0U; i < frames; ++i) {
            writeSample(left[i]);
            writeSample(right[i]);
        }
        if (!out_) throw std::runtime_error("bounce audio write failed");
        frames_ += frames;
        dataBytes_ += static_cast<std::uint64_t>(frames) * channels_ * bytesPerSample();
    }
    void finalize(){if(finalized_)return; if(options_.container==BounceContainer::Aiff && (dataBytes_&1U)){const char zero=0;out_.write(&zero,1);} out_.flush();if(!out_)throw std::runtime_error("bounce audio flush failed");out_.seekp(0,std::ios::beg);if(options_.container==BounceContainer::Wav){const std::uint64_t riff=72U+dataBytes_;const bool rf64=riff>0xFFFFFFFFULL||dataBytes_>0xFFFFFFFFULL;writeWavHeader(rf64,frames_,dataBytes_);}else writeAiffHeader(frames_,dataBytes_);out_.flush();if(!out_)throw std::runtime_error("bounce audio finalize failed");finalized_=true;}
private:
    std::uint16_t bits()const noexcept{switch(options_.sampleFormat){case BounceSampleFormat::Pcm16:return 16U;case BounceSampleFormat::Pcm24:return 24U;case BounceSampleFormat::Pcm32:return 32U;case BounceSampleFormat::Float32:return 32U;}return 32U;}
    std::uint16_t bytesPerSample()const noexcept{return static_cast<std::uint16_t>(bits()/8U);}
    double randomUnit() noexcept { rng_ ^= rng_<<13U; rng_ ^= rng_>>17U; rng_ ^= rng_<<5U; return static_cast<double>(rng_ & 0x00FFFFFFU)/16777216.0; }
    double dither() noexcept { return options_.dither==BounceDither::Tpdf ? randomUnit()-randomUnit() : 0.0; }
    static double clip(double x) noexcept { return std::max(-1.0,std::min(x,0.9999999995343387)); }
    void writeBytesLE(std::uint32_t v,unsigned n){for(unsigned i=0;i<n;++i){const char b=static_cast<char>((v>>(8U*i))&0xFFU);out_.write(&b,1);}}
    void writeBytesBE(std::uint32_t v,unsigned n){for(unsigned i=0;i<n;++i){const unsigned sh=8U*(n-1U-i);const char b=static_cast<char>((v>>sh)&0xFFU);out_.write(&b,1);}}
    void writeSample(float sample){
        if(options_.sampleFormat==BounceSampleFormat::Float32){writeLE(out_,sample);return;}
        const unsigned b=bits();const double scale=std::ldexp(1.0,static_cast<int>(b-1U));double q=std::nearbyint(clip(sample)*scale+dither());const double lo=-scale,hi=scale-1.0;q=std::max(lo,std::min(q,hi));const std::int64_t signedValue=static_cast<std::int64_t>(q);const std::uint32_t raw=static_cast<std::uint32_t>(signedValue);if(options_.container==BounceContainer::Wav)writeBytesLE(raw,bytesPerSample());else writeBytesBE(raw,bytesPerSample());
    }
    static void writeBE16(std::fstream&out,std::uint16_t v){char b[2]{static_cast<char>((v>>8)&255),static_cast<char>(v&255)};out.write(b,2);} static void writeBE32(std::fstream&out,std::uint32_t v){char b[4]{static_cast<char>((v>>24)&255),static_cast<char>((v>>16)&255),static_cast<char>((v>>8)&255),static_cast<char>(v&255)};out.write(b,4);} static void writeExtended80(std::fstream&out,double value){if(!(value>0.0)){char z[10]{};out.write(z,10);return;}int exponent=0;double fraction=std::frexp(value,&exponent);fraction*=2.0;--exponent;const std::uint16_t exp=static_cast<std::uint16_t>(exponent+16383);long double mant=static_cast<long double>(fraction)*9223372036854775808.0L;const std::uint64_t m=static_cast<std::uint64_t>(mant);writeBE16(out,exp);for(int i=7;i>=0;--i){const char b=static_cast<char>((m>>(i*8))&0xFFU);out.write(&b,1);}}
    void writeWavHeader(bool rf64,std::uint64_t frames,std::uint64_t dataBytes){const auto ba=static_cast<std::uint16_t>(channels_*bytesPerSample());const std::uint64_t br64=static_cast<std::uint64_t>(sampleRate_)*ba;if(br64>0xFFFFFFFFULL)throw std::overflow_error("WAV byte rate overflow");const auto br=static_cast<std::uint32_t>(br64);const std::uint64_t riff=72U+dataBytes;if(rf64){out_.write("RF64",4);writeLE(out_,std::uint32_t{0xFFFFFFFFU});out_.write("WAVE",4);out_.write("ds64",4);writeLE(out_,std::uint32_t{28U});writeLE(out_,riff);writeLE(out_,dataBytes);writeLE(out_,frames);writeLE(out_,std::uint32_t{0U});}else{if(riff>0xFFFFFFFFULL||dataBytes>0xFFFFFFFFULL)throw std::overflow_error("RIFF size overflow");out_.write("RIFF",4);writeLE(out_,static_cast<std::uint32_t>(riff));out_.write("WAVE",4);out_.write("JUNK",4);writeLE(out_,std::uint32_t{28U});writeLE(out_,std::uint64_t{0U});writeLE(out_,std::uint64_t{0U});writeLE(out_,std::uint64_t{0U});writeLE(out_,std::uint32_t{0U});}out_.write("fmt ",4);writeLE(out_,std::uint32_t{16U});writeLE(out_,static_cast<std::uint16_t>(options_.sampleFormat==BounceSampleFormat::Float32?3U:1U));writeLE(out_,channels_);writeLE(out_,sampleRate_);writeLE(out_,br);writeLE(out_,ba);writeLE(out_,bits());out_.write("data",4);writeLE(out_,rf64?std::uint32_t{0xFFFFFFFFU}:static_cast<std::uint32_t>(dataBytes));}
    void writeAiffHeader(std::uint64_t frames,std::uint64_t dataBytes){if(frames>0xFFFFFFFFULL||dataBytes+46U>0xFFFFFFFFULL)throw std::overflow_error("AIFF size exceeds 32-bit container");out_.write("FORM",4);writeBE32(out_,static_cast<std::uint32_t>(46U+dataBytes+(dataBytes&1U)));out_.write("AIFF",4);out_.write("COMM",4);writeBE32(out_,18U);writeBE16(out_,channels_);writeBE32(out_,static_cast<std::uint32_t>(frames));writeBE16(out_,bits());writeExtended80(out_,static_cast<double>(sampleRate_));out_.write("SSND",4);writeBE32(out_,static_cast<std::uint32_t>(dataBytes+8U));writeBE32(out_,0U);writeBE32(out_,0U);}
    std::fstream out_;std::uint16_t channels_;std::uint32_t sampleRate_;OfflineBounceFileOptions options_;std::uint64_t frames_{0U},dataBytes_{0U};std::uint32_t rng_{0x9E3779B9U};bool finalized_{false};
};


class StreamingSincResampler final {
public:
    StreamingSincResampler(std::uint32_t inputRate, std::uint32_t outputRate)
        : inputRate_(inputRate), outputRate_(outputRate) {
        if (inputRate_ == 0U || outputRate_ == 0U) throw std::invalid_argument("invalid export sample rate");
    }

    void process(const float* left, const float* right, std::uint32_t frames, bool final,
                 std::vector<float>& outputLeft, std::vector<float>& outputRight) {
        if ((frames != 0U) && (left == nullptr || right == nullptr)) throw std::invalid_argument("invalid resampler input");
        for (std::uint32_t i = 0U; i < frames; ++i) {
            left_.push_back(left[i]);
            right_.push_back(right[i]);
        }
        totalInputFrames_ += frames;
        outputLeft.clear();
        outputRight.clear();
        const std::uint64_t finalOutputFrames = final
            ? roundedOutputFrames(totalInputFrames_)
            : std::numeric_limits<std::uint64_t>::max();
        while (nextOutputFrame_ < finalOutputFrames) {
            const long double sourcePosition = static_cast<long double>(nextOutputFrame_) * inputRate_ / outputRate_;
            const auto center = static_cast<std::int64_t>(std::floor(sourcePosition));
            if (!final && center + kRadius >= static_cast<std::int64_t>(totalInputFrames_)) break;
            outputLeft.push_back(interpolate(left_, sourcePosition));
            outputRight.push_back(interpolate(right_, sourcePosition));
            ++nextOutputFrame_;
        }
        discardOldInput();
    }

    [[nodiscard]] std::uint64_t outputFrames() const noexcept { return nextOutputFrame_; }

private:
    static constexpr std::int64_t kRadius = 16;
    [[nodiscard]] std::uint64_t roundedOutputFrames(std::uint64_t inputFrames) const noexcept {
        const long double exact = static_cast<long double>(inputFrames) * outputRate_ / inputRate_;
        if (exact >= static_cast<long double>(std::numeric_limits<std::uint64_t>::max()))
            return std::numeric_limits<std::uint64_t>::max();
        return static_cast<std::uint64_t>(std::llround(exact));
    }
    [[nodiscard]] float interpolate(const std::deque<float>& samples, long double position) const noexcept {
        constexpr long double pi = 3.141592653589793238462643383279502884L;
        const auto center = static_cast<std::int64_t>(std::floor(position));
        long double sum = 0.0L;
        long double weightSum = 0.0L;
        for (std::int64_t tap = center - kRadius + 1; tap <= center + kRadius; ++tap) {
            if (tap < 0 || static_cast<std::uint64_t>(tap) >= totalInputFrames_) continue;
            if (static_cast<std::uint64_t>(tap) < baseInputFrame_) continue;
            const auto local = static_cast<std::uint64_t>(tap) - baseInputFrame_;
            if (local >= samples.size()) continue;
            const long double distance = position - static_cast<long double>(tap);
            const long double absolute = std::abs(distance);
            if (absolute >= static_cast<long double>(kRadius)) continue;
            const long double sinc = absolute < 1.0e-18L ? 1.0L : std::sin(pi * distance) / (pi * distance);
            const long double window = 0.5L * (1.0L + std::cos(pi * distance / static_cast<long double>(kRadius)));
            const long double weight = sinc * window;
            sum += static_cast<long double>(samples[static_cast<std::size_t>(local)]) * weight;
            weightSum += weight;
        }
        if (std::abs(weightSum) < 1.0e-18L) return 0.0F;
        return static_cast<float>(sum / weightSum);
    }
    void discardOldInput() noexcept {
        const long double nextPosition = static_cast<long double>(nextOutputFrame_) * inputRate_ / outputRate_;
        const auto floorPosition = static_cast<std::int64_t>(std::floor(nextPosition));
        const std::int64_t keepFromSigned = floorPosition - kRadius - 2;
        const std::uint64_t keepFrom = keepFromSigned > 0 ? static_cast<std::uint64_t>(keepFromSigned) : 0U;
        while (baseInputFrame_ < keepFrom && !left_.empty()) {
            left_.pop_front();
            right_.pop_front();
            ++baseInputFrame_;
        }
    }

    std::uint32_t inputRate_ {0U};
    std::uint32_t outputRate_ {0U};
    std::deque<float> left_;
    std::deque<float> right_;
    std::uint64_t baseInputFrame_ {0U};
    std::uint64_t totalInputFrames_ {0U};
    std::uint64_t nextOutputFrame_ {0U};
};

struct MidiBouncePlan {
    int port {-1};
    MidiRenderPlan plan;
};

std::vector<MidiBouncePlan> buildMidiPlans(const Project& project) {
    std::vector<MidiBouncePlan> result;
    result.reserve(project.midiTracks.size());
    for (const auto& track : project.midiTracks) {
        if (track.outputPort < 0) continue;
        MidiBouncePlan entry;
        entry.port = track.outputPort;
        entry.plan = compileMidiArrangement(track.sequence, track.parts, project.tempoMap);
        result.push_back(std::move(entry));
    }
    return result;
}

std::uint64_t secondsToSamples(double seconds, double sampleRate) {
    if (!std::isfinite(seconds) || seconds < 0.0) throw std::invalid_argument("invalid bounce tail limit");
    const long double samples = static_cast<long double>(seconds) * static_cast<long double>(sampleRate);
    if (samples >= static_cast<long double>(std::numeric_limits<std::uint64_t>::max()))
        return std::numeric_limits<std::uint64_t>::max();
    return static_cast<std::uint64_t>(std::llround(samples));
}

} // namespace

OfflineBounceResult OfflineBounce::renderAudioFile(const std::string& path,
                                                     Project& project,
                                                     AudioEngine& engine,
                                                     Vst3RuntimeRack* vst3Rack,
                                                     const OfflineBounceOptions& options,
                                                     const OfflineBounceFileOptions& fileOptions) {
    if (path.empty()) throw std::invalid_argument("bounce path is empty");
    if (options.startSample < 0 || options.endSample <= options.startSample)
        throw std::invalid_argument("invalid bounce range");
    if (engine.transport().isPlaying())
        throw std::logic_error("offline bounce requires stopped transport");
    if (engine.recorder() != nullptr && engine.recorder()->recording())
        throw std::logic_error("offline bounce is unavailable while recording");

    const AudioDeviceConfig config = engine.deviceConfig();
    if (!(config.sampleRate > 0.0) || config.blockSize == 0U || config.outputChannels < 2U)
        throw std::logic_error("offline bounce requires a prepared stereo AudioEngine");
    if (std::abs(config.sampleRate - project.sampleRate) > 0.5)
        throw std::invalid_argument("project and AudioEngine sample rates differ");

    const std::uint32_t blockSize = options.blockSize == 0U ? config.blockSize : options.blockSize;
    if (blockSize == 0U || blockSize > config.blockSize)
        throw std::invalid_argument("bounce block size exceeds prepared AudioEngine block size");

    const auto roundedSampleRate = std::llround(config.sampleRate);
    if (roundedSampleRate <= 0 || roundedSampleRate > std::numeric_limits<std::uint32_t>::max())
        throw std::invalid_argument("bounce sample rate is not representable as WAV rate");
    const auto sampleRate = static_cast<std::uint32_t>(roundedSampleRate);
    const std::uint32_t outputSampleRate = fileOptions.outputSampleRate == 0U ? sampleRate : fileOptions.outputSampleRate;
    if (outputSampleRate < 8000U || outputSampleRate > 768000U)
        throw std::invalid_argument("export output sample rate is outside supported range");

    if (engine.processorGraphPublicationPending())
        throw std::logic_error("offline bounce requires committed processor graph state");

    ProcessorGraph* const bounceGraph = engine.processorGraph();
    if (bounceGraph != nullptr && !bounceGraph->setRunMode(ProcessorRunMode::Offline))
        throw std::runtime_error("processor graph rejected offline export mode");

    const bool oldCycle = engine.transport().cycleEnabled();
    const std::int64_t oldCycleStart = engine.transport().cycleStartSample();
    const std::int64_t oldCycleEnd = engine.transport().cycleEndSample();
    const std::int64_t oldPosition = engine.transport().positionSamples();
    const bool oldMetronomeEnabled = engine.metronomeEnabled();

    struct RestoreTransport final {
        AudioEngine& engine;
        bool cycle;
        std::int64_t cycleStart;
        std::int64_t cycleEnd;
        std::int64_t position;
        bool metronomeEnabled;
        ProcessorGraph* graph;
        ~RestoreTransport() {
            engine.transport().stop();
            if (graph != nullptr) {
                try { (void)graph->setRunMode(ProcessorRunMode::Realtime); } catch (...) {}
                graph->reset();
            }
            try { engine.transport().setCycleRange(cycle, cycleStart, cycleEnd); } catch (...) {}
            engine.transport().seekSamples(position);
            engine.setMetronomeEnabled(metronomeEnabled);
        }
    } restore {engine, oldCycle, oldCycleStart, oldCycleEnd, oldPosition, oldMetronomeEnabled, bounceGraph};

    engine.setMetronomeEnabled(false);
    engine.transport().setCycleRange(false, 0, 0);
    if (bounceGraph != nullptr) bounceGraph->reset();

    const auto midiPlans = buildMidiPlans(project);
    std::vector<float> outL(blockSize, 0.0F);
    std::vector<float> outR(blockSize, 0.0F);
    std::array<float*, 2U> outputPtrs {outL.data(), outR.data()};

    AudioFileStreamWriter writer(path, 2U, outputSampleRate, fileOptions);
    OfflineBounceResult result;
    result.rangeFrames = static_cast<std::uint64_t>(options.endSample - options.startSample);
    result.outputSampleRate = outputSampleRate;
    std::unique_ptr<StreamingSincResampler> resampler;
    if (outputSampleRate != sampleRate) resampler = std::make_unique<StreamingSincResampler>(sampleRate, outputSampleRate);
    std::vector<float> resampledLeft;
    std::vector<float> resampledRight;

    auto queueMusicalData = [&](std::int64_t blockStart, std::uint32_t frames) {
        if (vst3Rack == nullptr) return;
        vst3Rack->queueAutomationForBlock(blockStart, frames);
        for (const auto& midi : midiPlans)
            (void)vst3Rack->queueMidiPlanForBlock(midi.port, midi.plan, blockStart, frames);
    };

    auto render = [&](std::int64_t blockStart, std::uint32_t frames, bool writeOutput, bool queueEvents) {
        if (queueEvents) queueMusicalData(blockStart, frames);
        engine.processAudio(nullptr, outputPtrs.data(), 0U, 2U, frames);
        if (vst3Rack != nullptr) vst3Rack->serviceOutputParameters();
        if (!writeOutput) return;
        result.totalFrames += frames;
        if (resampler != nullptr) {
            resampler->process(outL.data(), outR.data(), frames, false, resampledLeft, resampledRight);
            for (std::size_t i = 0U; i < resampledLeft.size(); ++i) {
                result.peak = std::max(result.peak, std::abs(resampledLeft[i]));
                result.peak = std::max(result.peak, std::abs(resampledRight[i]));
            }
            if (!resampledLeft.empty()) {
                writer.writeStereo(resampledLeft.data(), resampledRight.data(), static_cast<std::uint32_t>(resampledLeft.size()));
                result.writtenFrames += resampledLeft.size();
            }
        } else {
            for (std::uint32_t i = 0U; i < frames; ++i) {
                result.peak = std::max(result.peak, std::abs(outL[i]));
                result.peak = std::max(result.peak, std::abs(outR[i]));
            }
            writer.writeStereo(outL.data(), outR.data(), frames);
            result.writtenFrames += frames;
        }
    };

    const std::int64_t preRollStart = options.preRollSamples >= static_cast<std::uint64_t>(options.startSample)
        ? 0
        : options.startSample - static_cast<std::int64_t>(options.preRollSamples);
    engine.transport().seekSamples(preRollStart);
    engine.transport().play();

    std::int64_t cursor = preRollStart;
    while (cursor < options.startSample) {
        const std::int64_t remaining = options.startSample - cursor;
        const std::uint32_t frames = static_cast<std::uint32_t>(std::min<std::int64_t>(remaining, blockSize));
        render(cursor, frames, false, true);
        cursor += frames;
    }

    while (cursor < options.endSample) {
        const std::int64_t remaining = options.endSample - cursor;
        const std::uint32_t frames = static_cast<std::uint32_t>(std::min<std::int64_t>(remaining, blockSize));
        render(cursor, frames, true, true);
        cursor += frames;
    }

    engine.transport().stop();

    std::uint64_t requestedTail = 0U;
    if (options.tailMode == BounceTailMode::Fixed) {
        requestedTail = options.fixedTailSamples;
    } else if (options.tailMode == BounceTailMode::Automatic) {
        if (bounceGraph != nullptr) {
            requestedTail = bounceGraph->maximumTailSamples();
            if (requestedTail == std::numeric_limits<std::uint64_t>::max()) {
                result.processorReportedInfiniteTail = true;
                requestedTail = secondsToSamples(options.infiniteTailLimitSeconds, config.sampleRate);
            }
        }
    }

    std::uint64_t tailRemaining = requestedTail;
    while (tailRemaining != 0U) {
        const std::uint32_t frames = static_cast<std::uint32_t>(std::min<std::uint64_t>(tailRemaining, blockSize));
        render(options.endSample, frames, true, false);
        result.tailFrames += frames;
        tailRemaining -= frames;
    }

    if (resampler != nullptr) {
        resampler->process(nullptr, nullptr, 0U, true, resampledLeft, resampledRight);
        for (std::size_t i = 0U; i < resampledLeft.size(); ++i) {
            result.peak = std::max(result.peak, std::abs(resampledLeft[i]));
            result.peak = std::max(result.peak, std::abs(resampledRight[i]));
        }
        if (!resampledLeft.empty()) {
            writer.writeStereo(resampledLeft.data(), resampledRight.data(), static_cast<std::uint32_t>(resampledLeft.size()));
            result.writtenFrames += resampledLeft.size();
        }
    }
    writer.finalize();
    return result;
}

OfflineBounceResult OfflineBounce::renderFloat32Wav(const std::string& path,
                                                     Project& project,
                                                     AudioEngine& engine,
                                                     Vst3RuntimeRack* vst3Rack,
                                                     const OfflineBounceOptions& options) {
    OfflineBounceFileOptions file;
    file.container = BounceContainer::Wav;
    file.sampleFormat = BounceSampleFormat::Float32;
    file.dither = BounceDither::None;
    return renderAudioFile(path, project, engine, vst3Rack, options, file);
}

} // namespace silveton
