#include "silveton/AudioRangeEdit.h"
#include "silveton/ClipEditor.h"

#include <algorithm>
#include <limits>
#include <stdexcept>

namespace silveton {

namespace {

std::int64_t clipEnd(const ProjectAudioClip& c) { return c.timelineStartSample + static_cast<std::int64_t>(c.lengthSamples); }

ProjectTrack& trackAt(Project& project, std::size_t track) {
    if (track >= project.tracks.size()) throw std::out_of_range("range edit track");
    return project.tracks[track];
}
const ProjectTrack& trackAt(const Project& project, std::size_t track) {
    if (track >= project.tracks.size()) throw std::out_of_range("range edit track");
    return project.tracks[track];
}

const ProjectAudioClip* findClip(const ProjectTrack& t, std::uint64_t id) {
    for (const auto& c : t.clips) if (c.id == id) return &c;
    return nullptr;
}

void sortByStart(const ProjectTrack& t, std::vector<std::uint64_t>& ids) {
    std::sort(ids.begin(), ids.end(), [&](std::uint64_t a, std::uint64_t b) {
        const ProjectAudioClip* ca = findClip(t, a);
        const ProjectAudioClip* cb = findClip(t, b);
        if (ca == nullptr || cb == nullptr) return a < b;
        if (ca->timelineStartSample != cb->timelineStartSample) return ca->timelineStartSample < cb->timelineStartSample;
        return a < b;
    });
}

// Cut every clip that crosses `position`.
void cutAt(ClipEditor& editor, Project& project, std::size_t track, std::int64_t position) {
    std::vector<std::uint64_t> crossing;
    for (const auto& c : project.tracks[track].clips)
        if (c.lengthSamples > 0U && c.timelineStartSample < position && position < clipEnd(c)) crossing.push_back(c.id);
    for (const std::uint64_t id : crossing) (void)editor.splitClip(id, position, ClipSnapSettings {});
}

// A fade only survives on a piece when it starts exactly at the piece edge (the same rule the engine
// uses with the fade anchors); a fade that began outside the piece is not part of the piece's new media.
void keepOnlyEdgeFades(ProjectAudioClip& clip) {
    const std::uint64_t inAnchor = clip.fadeInAnchorSourceSample == ProjectAudioClip::kAutoFadeAnchor
        ? clip.sourceStartSample : clip.fadeInAnchorSourceSample;
    const std::uint64_t outAnchor = clip.fadeOutAnchorSourceSample == ProjectAudioClip::kAutoFadeAnchor
        ? clip.sourceStartSample + clip.lengthSamples : clip.fadeOutAnchorSourceSample;
    if (inAnchor != clip.sourceStartSample) clip.fadeInSamples = 0U;
    if (outAnchor != clip.sourceStartSample + clip.lengthSamples) clip.fadeOutSamples = 0U;
}

} // namespace

namespace {
double fadeInAnchorOf(const ProjectAudioClip& c) noexcept {
    return static_cast<double>(c.fadeInAnchorSourceSample == ProjectAudioClip::kAutoFadeAnchor ? c.sourceStartSample
                                                                                              : c.fadeInAnchorSourceSample);
}
double fadeOutAnchorOf(const ProjectAudioClip& c) noexcept {
    return static_cast<double>(c.fadeOutAnchorSourceSample == ProjectAudioClip::kAutoFadeAnchor ? c.sourceStartSample + c.lengthSamples
                                                                                               : c.fadeOutAnchorSourceSample);
}
} // namespace

double AudioRangeEdit::fadeGain(const ProjectAudioClip& clip, double timelineSample) noexcept {
    const double sourceFrame = static_cast<double>(clip.sourceStartSample) + (timelineSample - static_cast<double>(clip.timelineStartSample));
    double gain = 1.0;
    if (clip.fadeInSamples != 0U) {
        const double position = std::max(0.0, sourceFrame - fadeInAnchorOf(clip));
        gain *= std::min(1.0, position / static_cast<double>(clip.fadeInSamples));
    }
    if (clip.fadeOutSamples != 0U) {
        const double remaining = std::max(0.0, fadeOutAnchorOf(clip) - sourceFrame);
        gain *= std::min(1.0, remaining / static_cast<double>(clip.fadeOutSamples));
    }
    return gain;
}

ClipFadeGeometry AudioRangeEdit::fadeGeometry(const ProjectAudioClip& clip) noexcept {
    const double start = static_cast<double>(clip.timelineStartSample);
    const double end = start + static_cast<double>(clip.lengthSamples);
    const double source = static_cast<double>(clip.sourceStartSample);
    ClipFadeGeometry g;
    g.fadeInEnd = start;
    g.fadeOutStart = end;
    if (clip.fadeInSamples != 0U)
        g.fadeInEnd = std::clamp(start + (fadeInAnchorOf(clip) + static_cast<double>(clip.fadeInSamples) - source), start, end);
    if (clip.fadeOutSamples != 0U)
        g.fadeOutStart = std::clamp(start + (fadeOutAnchorOf(clip) - static_cast<double>(clip.fadeOutSamples) - source), start, end);
    return g;
}

EditSpan AudioRangeEdit::span(const Project& project, std::size_t track, std::uint64_t clipId, std::int64_t tolerance) {
    const ProjectTrack& t = trackAt(project, track);
    const ProjectAudioClip* first = findClip(t, clipId);
    EditSpan out;
    if (first == nullptr) return out;
    out.start = first->timelineStartSample;
    out.end = clipEnd(*first);
    std::vector<std::uint64_t> included {first->id};
    bool grew = true;
    while (grew) {
        grew = false;
        for (const auto& c : t.clips) {
            if (c.lengthSamples == 0U) continue;
            if (std::find(included.begin(), included.end(), c.id) != included.end()) continue;
            if (c.timelineStartSample <= out.end + tolerance && clipEnd(c) >= out.start - tolerance) {
                included.push_back(c.id);
                out.start = std::min(out.start, c.timelineStartSample);
                out.end = std::max(out.end, clipEnd(c));
                grew = true;
            }
        }
    }
    sortByStart(t, included);
    out.clipIds = std::move(included);
    return out;
}

std::vector<std::uint64_t> AudioRangeEdit::isolate(Project& project, std::size_t track, TimelineRange range) {
    (void)trackAt(project, track);
    std::vector<std::uint64_t> inside;
    if (!range.valid()) return inside;
    ClipEditor editor(project, track);
    cutAt(editor, project, track, range.start);
    cutAt(editor, project, track, range.end);
    for (const auto& c : project.tracks[track].clips)
        if (c.lengthSamples > 0U && c.timelineStartSample < range.end && clipEnd(c) > range.start) inside.push_back(c.id);
    sortByStart(project.tracks[track], inside);
    return inside;
}

void AudioRangeEdit::erase(Project& project, std::size_t track, TimelineRange range, bool ripple, std::int64_t windowEnd) {
    if (!range.valid()) return;
    const std::vector<std::uint64_t> inside = isolate(project, track, range);
    ClipEditor editor(project, track);
    for (const std::uint64_t id : inside) editor.removeClip(id);
    if (!ripple) return;
    std::vector<std::uint64_t> later;
    for (const auto& c : project.tracks[track].clips)
        if (c.timelineStartSample >= range.end && c.timelineStartSample < windowEnd) later.push_back(c.id);
    for (const std::uint64_t id : later) {
        const ProjectAudioClip* c = findClip(project.tracks[track], id);
        if (c != nullptr) editor.moveClip(id, c->timelineStartSample - range.length(), ClipSnapSettings {});
    }
}

void AudioRangeEdit::crop(Project& project, std::size_t track, TimelineRange range, const EditSpan& span) {
    if (!range.valid()) return;
    (void)isolate(project, track, range);
    ClipEditor editor(project, track);
    std::vector<std::uint64_t> outside;
    for (const auto& c : project.tracks[track].clips) {
        const bool inSpan = c.timelineStartSample < span.end && clipEnd(c) > span.start;
        const bool insideRange = c.timelineStartSample >= range.start && clipEnd(c) <= range.end;
        if (inSpan && !insideRange) outside.push_back(c.id);
    }
    for (const std::uint64_t id : outside) editor.removeClip(id);
}

RangeClipboard AudioRangeEdit::copy(const Project& project, std::size_t track, TimelineRange range) {
    RangeClipboard out;
    if (!range.valid()) return out;
    out.length = range.length();
    for (const auto& c : trackAt(project, track).clips) {
        if (c.lengthSamples == 0U) continue;
        const std::int64_t a = std::max(range.start, c.timelineStartSample);
        const std::int64_t b = std::min(range.end, clipEnd(c));
        if (b <= a) continue;
        ProjectAudioClip piece = c;
        const auto offset = static_cast<std::uint64_t>(a - c.timelineStartSample);
        piece.id = 0U;
        piece.sourceStartSample = c.sourceStartSample + offset;
        piece.lengthSamples = static_cast<std::uint64_t>(b - a);
        piece.timelineStartSample = a - range.start;
        piece.fadeInSamples = a > c.timelineStartSample ? 0U : std::min(c.fadeInSamples, piece.lengthSamples);
        piece.fadeOutSamples = b < clipEnd(c) ? 0U : std::min(c.fadeOutSamples, piece.lengthSamples);
        piece.fadeInAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
        piece.fadeOutAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
        out.pieces.push_back(std::move(piece));
    }
    std::sort(out.pieces.begin(), out.pieces.end(), [](const ProjectAudioClip& x, const ProjectAudioClip& y) {
        return x.timelineStartSample < y.timelineStartSample;
    });
    return out;
}

std::vector<std::uint64_t> AudioRangeEdit::insert(Project& project, std::size_t track, std::int64_t at,
                                                  const RangeClipboard& clipboard, bool ripple, std::int64_t windowEnd) {
    std::vector<std::uint64_t> created;
    if (clipboard.empty()) return created;
    (void)trackAt(project, track);
    at = std::max<std::int64_t>(0, at);
    ClipEditor editor(project, track);
    if (ripple) {
        cutAt(editor, project, track, at);
        std::vector<std::uint64_t> later;
        for (const auto& c : project.tracks[track].clips)
            if (c.timelineStartSample >= at && c.timelineStartSample < windowEnd) later.push_back(c.id);
        for (const std::uint64_t id : later) {
            const ProjectAudioClip* c = findClip(project.tracks[track], id);
            if (c != nullptr) editor.moveClip(id, c->timelineStartSample + clipboard.length, ClipSnapSettings {});
        }
    }
    for (const auto& piece : clipboard.pieces) {
        ProjectAudioClip clip = piece;
        clip.id = 0U;
        clip.timelineStartSample = at + piece.timelineStartSample;
        created.push_back(editor.addClip(std::move(clip), ClipSnapSettings {}));
    }
    return created;
}

std::vector<std::uint64_t> AudioRangeEdit::draw(Project& project, std::size_t track, const DrawnSamples& drawn,
                                                const std::string& outputDirectory) {
    if (trackAt(project, track).locked) throw std::runtime_error("track is locked");
    if (drawn.values.empty()) return {};
    const TimelineRange range {drawn.start, drawn.start + static_cast<std::int64_t>(drawn.values.size())};
    std::vector<std::uint64_t> pieces = isolate(project, track, range);
    for (const std::uint64_t id : pieces) {
        ProjectTrack& t = project.tracks[track];
        auto clipIt = std::find_if(t.clips.begin(), t.clips.end(), [&](const ProjectAudioClip& c) { return c.id == id; });
        if (clipIt == t.clips.end()) continue;
        keepOnlyEdgeFades(*clipIt);
        const std::int64_t offset = clipIt->timelineStartSample - drawn.start;   // where this piece starts inside `drawn`
        (void)AudioProcessor::processClipWith(project, track, id, "Drawn", [&](const AudioBuffer& region) {
            AudioBuffer out = region;
            for (std::size_t i = 0U; i < out.frames(); ++i) {
                const std::int64_t k = offset + static_cast<std::int64_t>(i);
                if (k < 0 || k >= static_cast<std::int64_t>(drawn.values.size())) continue;
                const float value = std::min(1.0F, std::max(-1.0F, drawn.values[static_cast<std::size_t>(k)]));
                for (std::size_t c = 0U; c < out.channels(); ++c)
                    if (drawn.channel < 0 || static_cast<std::size_t>(drawn.channel) == c) out.channelData(c)[i] = value;
            }
            return out;
        }, outputDirectory);
    }
    return pieces;
}

std::vector<std::uint64_t> AudioRangeEdit::process(Project& project, std::size_t track, TimelineRange range,
                                                   AudioProcess process, const AudioProcessOptions& options,
                                                   const std::string& outputDirectory, std::int64_t windowEnd) {
    if (trackAt(project, track).locked) throw std::runtime_error("track is locked");
    std::vector<std::uint64_t> pieces = isolate(project, track, range);
    // The last piece first: a length change then only moves audio that is still to come.
    for (auto it = pieces.rbegin(); it != pieces.rend(); ++it) {
        ProjectTrack& t = project.tracks[track];
        auto clipIt = std::find_if(t.clips.begin(), t.clips.end(), [&](const ProjectAudioClip& c) { return c.id == *it; });
        if (clipIt == t.clips.end()) continue;
        keepOnlyEdgeFades(*clipIt);
        const std::int64_t oldEnd = clipEnd(*clipIt);
        const auto oldLength = static_cast<std::int64_t>(clipIt->lengthSamples);
        (void)AudioProcessor::processClip(project, track, *it, process, options, outputDirectory);
        const ProjectAudioClip* processed = findClip(project.tracks[track], *it);
        if (processed == nullptr) continue;
        const std::int64_t delta = static_cast<std::int64_t>(processed->lengthSamples) - oldLength;
        if (delta == 0) continue;
        ClipEditor editor(project, track);
        std::vector<std::uint64_t> later;
        for (const auto& c : project.tracks[track].clips)
            if (c.id != *it && c.timelineStartSample >= oldEnd && c.timelineStartSample < windowEnd) later.push_back(c.id);
        for (const std::uint64_t id : later) {
            const ProjectAudioClip* c = findClip(project.tracks[track], id);
            if (c != nullptr) editor.moveClip(id, std::max<std::int64_t>(0, c->timelineStartSample + delta), ClipSnapSettings {});
        }
        windowEnd += delta;
    }
    return pieces;
}

} // namespace silveton
