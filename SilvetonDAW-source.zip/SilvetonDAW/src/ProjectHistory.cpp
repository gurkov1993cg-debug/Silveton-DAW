#include "silveton/ProjectHistory.h"
#include <stdexcept>
#include <utility>

namespace silveton {
namespace {
const std::string& emptyLabel() noexcept {
    static const std::string empty;
    return empty;
}
}

ProjectHistory::ProjectHistory(Project& project, std::size_t capacity)
    : project_(project), capacity_(capacity) {
    if (capacity_ == 0U) throw std::invalid_argument("project history capacity must be non-zero");
    undo_.reserve(capacity_);
    redo_.reserve(capacity_);
}

void ProjectHistory::begin(std::string label) {
    if (transactionOpen_) throw std::logic_error("project history transaction already open");
    if (label.empty()) label = "Edit";
    transactionBefore_ = project_;
    transactionLabel_ = std::move(label);
    transactionOpen_ = true;
}

void ProjectHistory::commit() {
    if (!transactionOpen_) throw std::logic_error("project history commit without begin");
    Entry entry {std::move(transactionLabel_), std::move(transactionBefore_), project_};
    transactionOpen_ = false;
    transactionLabel_.clear();
    redo_.clear();
    pushUndo(std::move(entry));
}

void ProjectHistory::cancel() {
    if (!transactionOpen_) return;
    Project restore = std::move(transactionBefore_);
    transactionOpen_ = false;
    transactionLabel_.clear();
    apply(std::move(restore));
}

const std::string& ProjectHistory::undoLabel() const noexcept {
    return undo_.empty() ? emptyLabel() : undo_.back().label;
}

const std::string& ProjectHistory::redoLabel() const noexcept {
    return redo_.empty() ? emptyLabel() : redo_.back().label;
}

void ProjectHistory::pushUndo(Entry entry) {
    if (undo_.size() == capacity_) undo_.erase(undo_.begin());
    undo_.push_back(std::move(entry));
}

void ProjectHistory::apply(Project snapshot) {
    project_ = std::move(snapshot);
    if (applyCallback_) applyCallback_();
}

bool ProjectHistory::undo() {
    if (transactionOpen_) throw std::logic_error("cannot undo with open project transaction");
    if (undo_.empty()) return false;
    Entry entry = std::move(undo_.back());
    undo_.pop_back();
    Project restore = entry.before;
    if (redo_.size() == capacity_) redo_.erase(redo_.begin());
    redo_.push_back(std::move(entry));
    apply(std::move(restore));
    return true;
}

bool ProjectHistory::redo() {
    if (transactionOpen_) throw std::logic_error("cannot redo with open project transaction");
    if (redo_.empty()) return false;
    Entry entry = std::move(redo_.back());
    redo_.pop_back();
    Project restore = entry.after;
    pushUndo(std::move(entry));
    apply(std::move(restore));
    return true;
}

void ProjectHistory::clear() noexcept {
    undo_.clear();
    redo_.clear();
    transactionOpen_ = false;
    transactionLabel_.clear();
    transactionBefore_ = Project{};
}

} // namespace silveton
