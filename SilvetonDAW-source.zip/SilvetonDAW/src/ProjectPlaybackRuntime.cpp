#include "silveton/ProjectPlaybackRuntime.h"
#include <algorithm>
#include <cmath>
#include <sstream>
#include <stdexcept>

namespace silveton {

ProjectPlaybackRuntime::ProjectPlaybackRuntime(Project& project,
                                               AudioEngine& engine,
                                               std::size_t maxOpenFiles)
    : project_(project), engine_(engine), streams_(maxOpenFiles) {}

ProjectPlaybackRuntime::~ProjectPlaybackRuntime() { stop(); }

void ProjectPlaybackRuntime::stop() noexcept {
    streams_.stop();
}

std::shared_ptr<DiskAudioSource> ProjectPlaybackRuntime::resolveSource(const std::string& path,
                                                       std::size_t trackIndex,
                                                       std::uint64_t clipId,
                                                       std::uint32_t cacheFrames) {
    if (path.empty()) {
        status_.issues.push_back({ProjectMediaIssueKind::MissingOrUnreadable, path, trackIndex, clipId,
                                  "audio path is empty"});
        return nullptr;
    }
    const auto existing = sourceByPath_.find(path);
    if (existing != sourceByPath_.end()) {
        auto source = streams_.sourceHandle(existing->second);
        if (std::abs(static_cast<double>(source->sampleRate()) - project_.sampleRate) > 0.5) {
            std::ostringstream detail;
            detail << "media sample rate " << source->sampleRate()
                   << " differs from project sample rate " << project_.sampleRate;
            status_.issues.push_back({ProjectMediaIssueKind::SampleRateMismatch, path, trackIndex, clipId, detail.str()});
            return nullptr;
        }
        return source;
    }

    try {
        (void)streams_.addSource(path, cacheFrames);
        const std::size_t index = streams_.sourceCount() - 1U;
        sourceByPath_.emplace(path, index);
        auto source = streams_.sourceHandle(index);
        if (std::abs(static_cast<double>(source->sampleRate()) - project_.sampleRate) > 0.5) {
            std::ostringstream detail;
            detail << "media sample rate " << source->sampleRate()
                   << " differs from project sample rate " << project_.sampleRate;
            status_.issues.push_back({ProjectMediaIssueKind::SampleRateMismatch, path, trackIndex, clipId, detail.str()});
            // Never play mismatched media at the wrong speed/pitch. Keep it
            // offline until it is converted/relinked by the control layer.
            return nullptr;
        }
        return source;
    } catch (const std::exception& e) {
        status_.issues.push_back({ProjectMediaIssueKind::MissingOrUnreadable, path, trackIndex, clipId, e.what()});
        return nullptr;
    }
}

TimelineClip ProjectPlaybackRuntime::makeClip(const ProjectAudioClip& clip,
                                              const ProjectTrack& track,
                                              std::size_t trackIndex,
                                              std::uint32_t cacheFrames) {
    TimelineClip out;
    const std::string& path = clip.audioPath.empty() ? track.audioPath : clip.audioPath;
    auto source = resolveSource(path, trackIndex, clip.id, cacheFrames);
    if (source && clip.sourceChannels != 0U && clip.sourceChannels != source->channels()) {
        std::ostringstream detail;
        detail << "media channel count " << source->channels()
               << " differs from persisted clip layout " << clip.sourceChannels;
        status_.issues.push_back({ProjectMediaIssueKind::ChannelLayoutMismatch, path, trackIndex, clip.id, detail.str()});
        source.reset();
    }
    out.diskSourceOwner = source;
    out.diskSource = source.get();
    out.timelineStartSample = clip.timelineStartSample;
    out.sourceStartSample = clip.sourceStartSample;
    out.lengthSamples = clip.lengthSamples;
    out.gainDb = clip.gainDb;
    out.mute = clip.mute;
    out.fadeInSamples = clip.fadeInSamples;
    out.fadeOutSamples = clip.fadeOutSamples;
    out.fadeInAnchorSourceSample = clip.fadeInAnchorSourceSample;
    out.fadeOutAnchorSourceSample = clip.fadeOutAnchorSourceSample;
    if (!source) {
        out.sourceFramesHint = std::max<std::uint64_t>(clip.sourceFrames,
            clip.sourceStartSample + std::max<std::uint64_t>(clip.lengthSamples, 1U));
        // V24 persists the original channel count. Legacy projects leave it at
        // zero, where stereo remains the conservative placeholder.
        out.channelsHint = clip.sourceChannels == 1U || clip.sourceChannels == 2U
            ? clip.sourceChannels : 2U;
        if (out.lengthSamples == 0U) out.lengthSamples = out.sourceFramesHint - out.sourceStartSample;
        ++status_.offlineClips;
    }
    return out;
}

ProjectPlaybackRuntimeStatus ProjectPlaybackRuntime::rebuild(std::uint32_t cacheFrames,
                                                             std::uint32_t primeTimeoutMilliseconds) {
    if (cacheFrames == 0U) throw std::invalid_argument("project playback cache must contain frames");
    if (engine_.transport().isPlaying()) throw std::logic_error("project media rebuild requires stopped transport");

    streams_.stop();
    streams_.clearSources();
    sourceByPath_.clear();
    status_ = {};
    engine_.clearTracks();

    for (std::size_t trackIndex = 0U; trackIndex < project_.tracks.size(); ++trackIndex) {
        const ProjectTrack& srcTrack = project_.tracks[trackIndex];
        TimelineTrack track;
        track.timelineStartSample = srcTrack.timelineStartSample;
        track.sourceStartSample = srcTrack.sourceStartSample;
        track.gainDb = srcTrack.gainDb;
        track.pan = srcTrack.pan;
        track.mute = srcTrack.mute;
        track.voiceEnabled = srcTrack.voiceEnabled;
        track.voicePriority = srcTrack.voicePriority;
        track.useDualStereoPan = srcTrack.useDualStereoPan;
        track.stereoLeftPan = srcTrack.stereoLeftPan;
        track.stereoRightPan = srcTrack.stereoRightPan;
        track.gainAutomationDb = &srcTrack.gainAutomationDb;
        track.panAutomation = &srcTrack.panAutomation;
        track.muteAutomation = &srcTrack.muteAutomation;

        if (!srcTrack.clips.empty()) {
            track.clips.reserve(srcTrack.clips.size());
            for (const auto& clip : srcTrack.clips)
                track.clips.push_back(makeClip(clip, srcTrack, trackIndex, cacheFrames));
        } else {
            auto source = resolveSource(srcTrack.audioPath, trackIndex, 0U, cacheFrames);
            if (source) {
                track.diskSourceOwner = source;
                track.diskSource = source.get();
            } else {
                TimelineClip offline;
                offline.timelineStartSample = srcTrack.timelineStartSample;
                offline.sourceStartSample = 0U;
                offline.lengthSamples = 1U;
                offline.sourceFramesHint = 1U;
                offline.channelsHint = 2U;
                track.clips.push_back(offline);
                ++status_.offlineClips;
            }
        }
        engine_.addTrack(std::move(track));
        ++status_.tracksPublished;
    }

    status_.uniqueAudioSources = sourceByPath_.size();
    if (streams_.sourceCount() != 0U) {
        streams_.start();
        if (!streams_.prime(0U, primeTimeoutMilliseconds)) {
            // Priming failure is not silently ignored: every source reporting an
            // I/O error becomes an issue, and the engine will naturally render
            // cache misses as silence rather than doing I/O on the callback.
            for (std::size_t i = 0U; i < streams_.sourceCount(); ++i) {
                const auto& source = streams_.source(i);
                if (source.status().ioError) {
                    status_.issues.push_back({ProjectMediaIssueKind::MissingOrUnreadable,
                                              source.path(), 0U, 0U, "disk-stream prime failed"});
                }
            }
        }
    }
    return status_;
}

} // namespace silveton
