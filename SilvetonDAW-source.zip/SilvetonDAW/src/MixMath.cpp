#include "silveton/MixMath.h"
#include <algorithm>
#include <cmath>

namespace silveton {
namespace {
constexpr double pi = 3.141592653589793238462643383279502884;
constexpr double sqrtHalf = 0.707106781186547524400844362104849039;
}

double MixMath::dbToLinear(double db) noexcept {
    return std::pow(10.0, db / 20.0);
}

double MixMath::panDepthDb(PanDepth depth) noexcept {
    switch (depth) {
        case PanDepth::Minus2_5dB: return -2.5;
        case PanDepth::Minus3dB: return -3.0;
        case PanDepth::Minus4_5dB: return -4.5;
        case PanDepth::Minus6dB: return -6.0;
    }
    return -3.0;
}

StereoGainPair MixMath::monoPan(float pan, PanDepth depth) noexcept {
    const double p = std::clamp(static_cast<double>(pan), -1.0, 1.0);
    const double theta = (p + 1.0) * (pi * 0.25); // 0 .. pi/2
    const double centerGain = dbToLinear(panDepthDb(depth));

    // pow(sqrt(1/2), exponent) == selected centre gain.
    const double exponent = std::log(centerGain) / std::log(sqrtHalf);
    const double c = std::max(0.0, std::cos(theta));
    const double s = std::max(0.0, std::sin(theta));

    StereoGainPair gains;
    gains.left = c == 0.0 ? 0.0 : std::pow(c, exponent);
    gains.right = s == 0.0 ? 0.0 : std::pow(s, exponent);

    // Make endpoint behaviour exact rather than dependent on libm epsilon.
    if (p <= -1.0) return {1.0, 0.0};
    if (p >= 1.0) return {0.0, 1.0};
    return gains;
}

StereoGainPair MixMath::stereoBalance(float balance) noexcept {
    const double p = std::clamp(static_cast<double>(balance), -1.0, 1.0);
    StereoGainPair gains {1.0, 1.0};
    if (p > 0.0) gains.left = std::cos(p * pi * 0.5);
    if (p < 0.0) gains.right = std::cos(-p * pi * 0.5);
    if (p <= -1.0) gains.right = 0.0;
    if (p >= 1.0) gains.left = 0.0;
    return gains;
}

void MixMath::compensatedAdd(double value, double& sum, double& compensation) noexcept {
    const double t = sum + value;
    if (std::abs(sum) >= std::abs(value)) {
        compensation += (sum - t) + value;
    } else {
        compensation += (value - t) + sum;
    }
    sum = t;
}

} // namespace silveton
