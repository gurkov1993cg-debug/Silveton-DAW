#include "silveton/Arrangement.h"
#include "silveton/AudioEngine.h"
#include "silveton/DiskStream.h"

#include <algorithm>
#include <cmath>
#include <functional>
#include <limits>
#include <set>
#include <stdexcept>

namespace silveton {

// ------------------------------------------------------------------ colours --
std::uint32_t silvetonPaletteColor(std::size_t index) noexcept {
    // Muted studio palette: every tone is half way to graphite, so tracks can be told apart
    // without the window turning into a paint box (the colour shows on thin bars, not on bodies).
    static const std::uint32_t palette[16] = {
        0xB2886FU, 0x8DA183U, 0x7B94ABU, 0xA97C91U, 0xB2A277U, 0x75A09EU, 0x9484AEU, 0xAA7A71U,
        0x85987FU, 0x6D8AA2U, 0xA28C79U, 0x7DA7AEU, 0xA0976FU, 0x987687U, 0x759589U, 0x8B8EA6U};
    return palette[index % 16U];
}

std::uint32_t effectiveTrackColor(const Project& project, std::size_t trackIndex) noexcept {
    if (trackIndex < project.tracks.size() && project.tracks[trackIndex].color != 0U) return project.tracks[trackIndex].color;
    return silvetonPaletteColor(trackIndex);
}

// --------------------------------------------------------------------- solo --
bool SoloResolver::anySolo(const Project& project) noexcept {
    for (const auto& t : project.tracks) if (t.solo) return true;
    for (const auto& m : project.midiTracks) if (m.solo) return true;
    for (const auto& b : project.buses) if (b.solo) return true;
    return false;
}

namespace {
bool busReaches(const Project& p, int from, int target) {
    // Follow output chain (and sends) from bus `from`; guards against cycles.
    std::vector<char> seen(p.buses.size(), 0);
    std::vector<int> stack {from};
    while (!stack.empty()) {
        const int b = stack.back();
        stack.pop_back();
        if (b < 0 || static_cast<std::size_t>(b) >= p.buses.size()) continue;
        if (b == target) return true;
        if (seen[static_cast<std::size_t>(b)]) continue;
        seen[static_cast<std::size_t>(b)] = 1;
        stack.push_back(p.buses[static_cast<std::size_t>(b)].outputBus);
        for (const auto& s : p.buses[static_cast<std::size_t>(b)].sends) if (s.enabled) stack.push_back(s.destinationBus);
    }
    return false;
}
bool trackFeedsBus(const Project& p, const ProjectTrack& t, int bus) {
    if (busReaches(p, t.outputBus, bus)) return true;
    for (const auto& s : t.sends) if (s.enabled && busReaches(p, s.destinationBus, bus)) return true;
    return false;
}
} // namespace

std::vector<std::size_t> SoloResolver::audibleTracks(const Project& project) {
    std::vector<std::size_t> out;
    if (!anySolo(project)) {
        out.resize(project.tracks.size());
        for (std::size_t i = 0U; i < out.size(); ++i) out[i] = i;
        return out;
    }
    std::vector<char> audible(project.tracks.size(), 0);
    for (std::size_t i = 0U; i < project.tracks.size(); ++i)
        if (project.tracks[i].solo || project.tracks[i].soloDefeat) audible[i] = 1;
    for (const auto& m : project.midiTracks) {
        if (!m.solo || m.outputPort < 0) continue;
        for (std::size_t i = 0U; i < project.tracks.size(); ++i)
            for (const auto& slot : project.tracks[i].pluginSlots)
                if (slot.midiInputPort == m.outputPort) audible[i] = 1;
    }
    for (std::size_t b = 0U; b < project.buses.size(); ++b) {
        if (!project.buses[b].solo) continue;
        for (std::size_t i = 0U; i < project.tracks.size(); ++i)
            if (trackFeedsBus(project, project.tracks[i], static_cast<int>(b))) audible[i] = 1;
    }
    for (std::size_t i = 0U; i < audible.size(); ++i) if (audible[i]) out.push_back(i);
    return out;
}

void SoloResolver::apply(AudioEngine& engine, const Project& project) {
    if (!anySolo(project)) {
        if (engine.trackRenderMaskActive()) engine.clearTrackRenderMask();
        return;
    }
    auto audible = audibleTracks(project);
    audible.erase(std::remove_if(audible.begin(), audible.end(), [&](std::size_t i) { return i >= engine.trackCount(); }),
                  audible.end());
    engine.setTrackRenderMask(audible);
}

// ------------------------------------------------------------------ markers --
namespace {
template <typename T> std::uint64_t nextId(const std::vector<T>& items) {
    std::uint64_t id = 0U;
    for (const auto& i : items) id = std::max(id, i.id);
    return id + 1U;
}
} // namespace

std::uint64_t MarkerTools::add(Project& project, std::string name, std::int64_t sample) {
    if (sample < 0) throw std::invalid_argument("marker position must not be negative");
    ProjectMarker m;
    m.id = nextId(project.markers);
    m.name = name.empty() ? "Marker " + std::to_string(m.id) : std::move(name);
    m.sample = sample;
    project.markers.push_back(m);
    sort(project);
    return m.id;
}

std::uint64_t MarkerTools::addCycle(Project& project, std::string name, std::int64_t start, std::int64_t end) {
    if (start < 0 || end <= start) throw std::invalid_argument("cycle marker range is empty");
    ProjectMarker m;
    m.id = nextId(project.markers);
    m.name = name.empty() ? "Cycle " + std::to_string(m.id) : std::move(name);
    m.sample = start;
    m.cycle = true;
    m.endSample = end;
    project.markers.push_back(m);
    sort(project);
    return m.id;
}

bool MarkerTools::remove(Project& project, std::uint64_t id) {
    const auto before = project.markers.size();
    project.markers.erase(std::remove_if(project.markers.begin(), project.markers.end(),
                                         [&](const ProjectMarker& m) { return m.id == id; }),
                          project.markers.end());
    return project.markers.size() != before;
}

bool MarkerTools::move(Project& project, std::uint64_t id, std::int64_t sample) {
    if (sample < 0) throw std::invalid_argument("marker position must not be negative");
    for (auto& m : project.markers) {
        if (m.id != id) continue;
        if (m.cycle) m.endSample = sample + (m.endSample - m.sample);
        m.sample = sample;
        sort(project);
        return true;
    }
    return false;
}

bool MarkerTools::rename(Project& project, std::uint64_t id, std::string name) {
    for (auto& m : project.markers) if (m.id == id) { m.name = std::move(name); return true; }
    return false;
}

const ProjectMarker* MarkerTools::find(const Project& project, std::uint64_t id) noexcept {
    for (const auto& m : project.markers) if (m.id == id) return &m;
    return nullptr;
}

const ProjectMarker* MarkerTools::next(const Project& project, std::int64_t sample) noexcept {
    const ProjectMarker* best = nullptr;
    for (const auto& m : project.markers)
        if (m.sample > sample && (!best || m.sample < best->sample)) best = &m;
    return best;
}

const ProjectMarker* MarkerTools::previous(const Project& project, std::int64_t sample) noexcept {
    const ProjectMarker* best = nullptr;
    for (const auto& m : project.markers)
        if (m.sample < sample && (!best || m.sample > best->sample)) best = &m;
    return best;
}

void MarkerTools::sort(Project& project) {
    std::stable_sort(project.markers.begin(), project.markers.end(),
                     [](const ProjectMarker& a, const ProjectMarker& b) { return a.sample < b.sample; });
}

// ----------------------------------------------------------------- arranger --
std::uint64_t ArrangerTools::addSection(Project& project, std::string name, std::int64_t start, std::int64_t end) {
    if (start < 0 || end <= start) throw std::invalid_argument("arranger section range is empty");
    for (const auto& s : project.arrangerSections)
        if (start < s.endSample && end > s.startSample) throw std::invalid_argument("arranger sections must not overlap");
    ArrangerSection s;
    s.id = nextId(project.arrangerSections);
    static const char* names[] = {"Intro", "Verse", "Chorus", "Bridge", "Solo", "Outro"};
    s.name = name.empty() ? std::string(names[(s.id - 1U) % 6U]) : std::move(name);
    s.startSample = start;
    s.endSample = end;
    s.color = silvetonPaletteColor(static_cast<std::size_t>(s.id) * 3U);
    project.arrangerSections.push_back(s);
    std::sort(project.arrangerSections.begin(), project.arrangerSections.end(),
              [](const ArrangerSection& a, const ArrangerSection& b) { return a.startSample < b.startSample; });
    return s.id;
}

bool ArrangerTools::removeSection(Project& project, std::uint64_t id) {
    const auto before = project.arrangerSections.size();
    project.arrangerSections.erase(std::remove_if(project.arrangerSections.begin(), project.arrangerSections.end(),
                                                  [&](const ArrangerSection& s) { return s.id == id; }),
                                   project.arrangerSections.end());
    project.arrangerChain.erase(std::remove_if(project.arrangerChain.begin(), project.arrangerChain.end(),
                                               [&](const ArrangerChainStep& c) { return c.sectionId == id; }),
                                project.arrangerChain.end());
    return before != project.arrangerSections.size();
}

bool ArrangerTools::resizeSection(Project& project, std::uint64_t id, std::int64_t start, std::int64_t end) {
    if (start < 0 || end <= start) throw std::invalid_argument("arranger section range is empty");
    for (const auto& s : project.arrangerSections)
        if (s.id != id && start < s.endSample && end > s.startSample) throw std::invalid_argument("arranger sections must not overlap");
    for (auto& s : project.arrangerSections)
        if (s.id == id) { s.startSample = start; s.endSample = end; return true; }
    return false;
}

const ArrangerSection* ArrangerTools::find(const Project& project, std::uint64_t id) noexcept {
    for (const auto& s : project.arrangerSections) if (s.id == id) return &s;
    return nullptr;
}

void ArrangerTools::appendToChain(Project& project, std::uint64_t sectionId, std::uint32_t repeats) {
    if (!find(project, sectionId)) throw std::invalid_argument("unknown arranger section");
    if (repeats == 0U || repeats > 999U) throw std::invalid_argument("arranger repeats must be 1..999");
    project.arrangerChain.push_back({sectionId, repeats});
}

void ArrangerTools::removeChainStep(Project& project, std::size_t index) {
    if (index >= project.arrangerChain.size()) throw std::out_of_range("arranger chain step");
    project.arrangerChain.erase(project.arrangerChain.begin() + static_cast<std::ptrdiff_t>(index));
}

void ArrangerTools::moveChainStep(Project& project, std::size_t from, std::size_t to) {
    auto& c = project.arrangerChain;
    if (from >= c.size() || to >= c.size()) throw std::out_of_range("arranger chain step");
    const auto step = c[from];
    c.erase(c.begin() + static_cast<std::ptrdiff_t>(from));
    c.insert(c.begin() + static_cast<std::ptrdiff_t>(to), step);
}

std::vector<std::pair<std::int64_t, std::int64_t>> ArrangerTools::chainRanges(const Project& project) {
    std::vector<std::pair<std::int64_t, std::int64_t>> out;
    for (const auto& step : project.arrangerChain) {
        const auto* s = find(project, step.sectionId);
        if (!s) continue;
        for (std::uint32_t r = 0U; r < step.repeats; ++r) out.emplace_back(s->startSample, s->endSample);
    }
    return out;
}

std::int64_t ArrangerTools::chainLengthSamples(const Project& project) {
    std::int64_t total = 0;
    for (const auto& r : chainRanges(project)) total += r.second - r.first;
    return total;
}

namespace {

void copyLane(const AutomationLane& src, AutomationLane& dst, std::int64_t s, std::int64_t e,
              std::int64_t cursor, bool step) {
    if (src.points().empty()) return;
    const float fallback = src.points().front().value;
    auto value = [&](std::int64_t at) { return step ? src.stepValueAt(at, fallback) : src.valueAt(at, fallback); };
    dst.add(cursor, value(s));
    for (const auto& pt : src.points())
        if (pt.sample > s && pt.sample < e) dst.add(cursor + (pt.sample - s), pt.value);
    if (e - s > 1) dst.add(cursor + (e - s) - 1, value(e - 1));
}

void copyParamLane(const ParameterAutomationLane& src, ParameterAutomationLane& dst, std::int64_t s, std::int64_t e,
                   std::int64_t cursor) {
    if (src.points().empty()) return;
    const double fallback = src.points().front().normalized;
    dst.write(cursor, src.valueAt(s, fallback));
    for (const auto& pt : src.points())
        if (pt.sample > s && pt.sample < e) dst.write(cursor + (pt.sample - s), pt.normalized);
    if (e - s > 1) dst.write(cursor + (e - s) - 1, src.valueAt(e - 1, fallback));
}

void copySlotAutomation(const std::vector<ProjectPluginSlot>& src, std::vector<ProjectPluginSlot>& dst,
                        std::int64_t s, std::int64_t e, std::int64_t cursor) {
    for (std::size_t i = 0U; i < src.size() && i < dst.size(); ++i)
        for (std::size_t a = 0U; a < src[i].automation.size() && a < dst[i].automation.size(); ++a)
            copyParamLane(src[i].automation[a].lane, dst[i].automation[a].lane, s, e, cursor);
}

void clearSlotAutomation(std::vector<ProjectPluginSlot>& slots) {
    for (auto& slot : slots) for (auto& a : slot.automation) a.lane.clear();
}

std::vector<ProjectAudioClip> clipsOf(const ProjectTrack& t) {
    if (!t.clips.empty() || t.audioPath.empty()) return t.clips;
    // Legacy whole-file track: inspect the file once to create an explicit clip.
    DiskStreamManager inspect(1U);
    auto& src = inspect.addSource(t.audioPath);
    ProjectAudioClip c;
    c.id = 1U;
    c.audioPath = t.audioPath;
    c.timelineStartSample = t.timelineStartSample;
    c.sourceStartSample = t.sourceStartSample;
    c.sourceFrames = src.frames();
    c.sourceChannels = src.channels();
    c.sourceSampleRate = src.sampleRate();
    c.lengthSamples = src.frames() > t.sourceStartSample ? src.frames() - t.sourceStartSample : 0U;
    return c.lengthSamples ? std::vector<ProjectAudioClip> {c} : std::vector<ProjectAudioClip> {};
}

std::vector<MidiPart> partsOf(const ProjectMidiTrack& t) {
    if (!t.parts.empty()) return t.parts;
    double end = 0.0;
    for (const auto& n : t.sequence.notes()) end = std::max(end, n.startQuarterNotes + n.durationQuarterNotes);
    for (const auto& m : t.sequence.messages()) end = std::max(end, m.quarterNotes + 1.0e-6);
    if (end <= 0.0) return {};
    MidiPart p;
    p.id = 1U;
    p.timelineStartQuarterNotes = 0.0;
    p.sourceOffsetQuarterNotes = 0.0;
    p.lengthQuarterNotes = end + 1.0;
    p.loopLengthQuarterNotes = end + 1.0;
    p.sequence = t.sequence;
    return {p};
}

} // namespace

Project ArrangerTools::flattenChain(const Project& source) {
    const auto ranges = chainRanges(source);
    if (ranges.empty()) throw std::invalid_argument("arranger chain is empty");
    Project out = source;
    out.markers.clear();
    out.arrangerSections.clear();
    out.arrangerChain.clear();
    const TempoMap& tempo = source.tempoMap;

    // Audio tracks
    for (std::size_t ti = 0U; ti < source.tracks.size(); ++ti) {
        const auto& srcTrack = source.tracks[ti];
        auto& dst = out.tracks[ti];
        const auto clips = clipsOf(srcTrack);
        dst.clips.clear();
        dst.takeLanes.clear();
        dst.compSections.clear();
        dst.gainAutomationDb.clear();
        dst.panAutomation.clear();
        dst.muteAutomation.clear();
        clearSlotAutomation(dst.pluginSlots);
        for (auto& send : dst.sends) { send.gainAutomationDb.clear(); send.enabledAutomation.clear(); }
        std::uint64_t id = 1U;
        std::int64_t cursor = ranges.front().first;
        for (const auto& [s, e] : ranges) {
            for (const auto& c : clips) {
                const std::int64_t cs = c.timelineStartSample;
                const std::int64_t ce = cs + static_cast<std::int64_t>(c.lengthSamples);
                if (ce <= s || cs >= e) continue;
                const std::int64_t ns = std::max(cs, s), ne = std::min(ce, e);
                ProjectAudioClip copy = c;
                copy.id = id++;
                copy.sourceStartSample = c.sourceStartSample + static_cast<std::uint64_t>(ns - cs);
                copy.lengthSamples = static_cast<std::uint64_t>(ne - ns);
                copy.timelineStartSample = cursor + (ns - s);
                copy.fadeInSamples = cs >= s ? std::min(c.fadeInSamples, copy.lengthSamples) : 0U;
                copy.fadeOutSamples = ce <= e ? std::min(c.fadeOutSamples, copy.lengthSamples) : 0U;
                copy.fadeInAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
                copy.fadeOutAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
                dst.clips.push_back(copy);
            }
            copyLane(srcTrack.gainAutomationDb, dst.gainAutomationDb, s, e, cursor, false);
            copyLane(srcTrack.panAutomation, dst.panAutomation, s, e, cursor, false);
            copyLane(srcTrack.muteAutomation, dst.muteAutomation, s, e, cursor, true);
            copySlotAutomation(srcTrack.pluginSlots, dst.pluginSlots, s, e, cursor);
            for (std::size_t si = 0U; si < srcTrack.sends.size(); ++si) {
                copyLane(srcTrack.sends[si].gainAutomationDb, dst.sends[si].gainAutomationDb, s, e, cursor, false);
                copyLane(srcTrack.sends[si].enabledAutomation, dst.sends[si].enabledAutomation, s, e, cursor, true);
            }
            cursor += e - s;
        }
        if (dst.clips.empty() && !srcTrack.audioPath.empty()) dst.audioPath.clear();
    }

    // Buses and master automation
    for (std::size_t bi = 0U; bi < source.buses.size(); ++bi) {
        const auto& sb = source.buses[bi];
        auto& db = out.buses[bi];
        db.gainAutomationDb.clear(); db.muteAutomation.clear(); clearSlotAutomation(db.pluginSlots);
        std::int64_t cursor = ranges.front().first;
        for (const auto& [s, e] : ranges) {
            copyLane(sb.gainAutomationDb, db.gainAutomationDb, s, e, cursor, false);
            copyLane(sb.muteAutomation, db.muteAutomation, s, e, cursor, true);
            copySlotAutomation(sb.pluginSlots, db.pluginSlots, s, e, cursor);
            cursor += e - s;
        }
    }
    {
        out.masterFaderAutomationDb.clear();
        clearSlotAutomation(out.masterPluginSlots);
        std::int64_t cursor = ranges.front().first;
        for (const auto& [s, e] : ranges) {
            copyLane(source.masterFaderAutomationDb, out.masterFaderAutomationDb, s, e, cursor, false);
            copySlotAutomation(source.masterPluginSlots, out.masterPluginSlots, s, e, cursor);
            cursor += e - s;
        }
    }

    // MIDI tracks (quarter-note domain)
    for (std::size_t mi = 0U; mi < source.midiTracks.size(); ++mi) {
        const auto parts = partsOf(source.midiTracks[mi]);
        auto& dst = out.midiTracks[mi];
        dst.parts.clear();
        dst.sequence = MidiSequence {};
        std::uint64_t id = 1U;
        std::int64_t cursor = ranges.front().first;
        for (const auto& [s, e] : ranges) {
            const double sq = tempo.quarterNotesAtSample(s), eq = tempo.quarterNotesAtSample(e);
            const double dq = tempo.quarterNotesAtSample(cursor);
            for (const auto& p : parts) {
                const double ps = p.timelineStartQuarterNotes, pe = ps + p.lengthQuarterNotes;
                if (pe <= sq + 1.0e-9 || ps >= eq - 1.0e-9) continue;
                const double ns = std::max(ps, sq), ne = std::min(pe, eq);
                if (ne - ns < 1.0e-9) continue;
                MidiPart copy = p;
                copy.id = id++;
                copy.timelineStartQuarterNotes = dq + (ns - sq);
                copy.sourceOffsetQuarterNotes = p.sourceOffsetQuarterNotes + (ns - ps);
                copy.lengthQuarterNotes = ne - ns;
                dst.parts.push_back(std::move(copy));
            }
            cursor += e - s;
        }
    }

    // One marker per placed section.
    std::int64_t cursor = ranges.front().first;
    for (const auto& step : source.arrangerChain) {
        const auto* s = find(source, step.sectionId);
        if (!s) continue;
        for (std::uint32_t r = 0U; r < step.repeats; ++r) {
            ProjectMarker m;
            m.id = out.markers.size() + 1U;
            m.name = step.repeats > 1U ? s->name + " " + std::to_string(r + 1U) : s->name;
            m.sample = cursor;
            m.color = s->color;
            out.markers.push_back(std::move(m));
            cursor += s->endSample - s->startSample;
        }
    }
    return out;
}

// ------------------------------------------------------------------ folders --
int FolderTools::addFolder(Project& project, std::string name, int parent) {
    if (parent >= 0 && std::none_of(project.folders.begin(), project.folders.end(), [&](const ProjectFolder& f) { return f.id == parent; }))
        throw std::invalid_argument("unknown parent folder");
    int id = 0;
    for (const auto& f : project.folders) id = std::max(id, f.id);
    ProjectFolder f;
    f.id = id + 1;
    f.name = name.empty() ? "Folder " + std::to_string(f.id) : std::move(name);
    f.parent = parent;
    f.color = silvetonPaletteColor(static_cast<std::size_t>(f.id) + 5U);
    project.folders.push_back(f);
    return f.id;
}

bool FolderTools::removeFolder(Project& project, int id) {
    auto it = std::find_if(project.folders.begin(), project.folders.end(), [&](const ProjectFolder& f) { return f.id == id; });
    if (it == project.folders.end()) return false;
    const int parent = it->parent;
    project.folders.erase(it);
    for (auto& f : project.folders) if (f.parent == id) f.parent = parent;
    for (auto& t : project.tracks) if (t.folder == id) t.folder = parent;
    for (auto& t : project.midiTracks) if (t.folder == id) t.folder = parent;
    return true;
}

bool FolderTools::isInside(const Project& project, int folder, int ancestor) noexcept {
    int guard = 0;
    while (folder >= 0 && guard++ < 1024) {
        if (folder == ancestor) return true;
        const auto it = std::find_if(project.folders.begin(), project.folders.end(), [&](const ProjectFolder& f) { return f.id == folder; });
        if (it == project.folders.end()) return false;
        folder = it->parent;
    }
    return false;
}

std::vector<std::size_t> FolderTools::audioTracksIn(const Project& project, int folder) {
    std::vector<std::size_t> out;
    for (std::size_t i = 0U; i < project.tracks.size(); ++i)
        if (isInside(project, project.tracks[i].folder, folder)) out.push_back(i);
    return out;
}

void FolderTools::setMute(Project& project, int folder, bool mute) {
    for (auto& t : project.tracks) if (isInside(project, t.folder, folder)) t.mute = mute;
    for (auto& t : project.midiTracks) if (isInside(project, t.folder, folder)) t.mute = mute;
}

void FolderTools::setSolo(Project& project, int folder, bool solo) {
    for (auto& t : project.tracks) if (isInside(project, t.folder, folder)) t.solo = solo;
    for (auto& t : project.midiTracks) if (isInside(project, t.folder, folder)) t.solo = solo;
}

// ------------------------------------------------------------------- tracks --
namespace {
void remapNodes(Project& p, const std::function<int(int)>& map) {
    auto fix = [&](std::vector<ProjectPluginSlot>& slots) {
        for (auto& s : slots) {
            if (s.sidechainSourceNode >= 0) s.sidechainSourceNode = map(s.sidechainSourceNode);
            for (auto& d : s.extraOutputDestinations) if (d >= 0) d = map(d);
        }
    };
    for (auto& t : p.tracks) fix(t.pluginSlots);
    for (auto& b : p.buses) fix(b.pluginSlots);
    fix(p.masterPluginSlots);
}
} // namespace

void TrackTools::insertTrack(Project& project, std::size_t index, ProjectTrack track) {
    if (project.tracks.size() >= Project::kMaxTracks) throw std::length_error("Silveton project track limit is 256");
    index = std::min(index, project.tracks.size());
    const int at = static_cast<int>(index);
    remapNodes(project, [&](int n) { return n >= at ? n + 1 : n; });
    project.tracks.insert(project.tracks.begin() + static_cast<std::ptrdiff_t>(index), std::move(track));
}

void TrackTools::removeTrack(Project& project, std::size_t index) {
    if (index >= project.tracks.size()) throw std::out_of_range("track index");
    const int at = static_cast<int>(index);
    project.tracks.erase(project.tracks.begin() + static_cast<std::ptrdiff_t>(index));
    remapNodes(project, [&](int n) { return n == at ? -1 : (n > at ? n - 1 : n); });
}

void TrackTools::moveTrack(Project& project, std::size_t from, std::size_t to) {
    const std::size_t n = project.tracks.size();
    if (from >= n || to >= n) throw std::out_of_range("track index");
    if (from == to) return;
    std::vector<int> map(n);
    std::vector<std::size_t> order(n);
    for (std::size_t i = 0U; i < n; ++i) order[i] = i;
    const auto moved = order[from];
    order.erase(order.begin() + static_cast<std::ptrdiff_t>(from));
    order.insert(order.begin() + static_cast<std::ptrdiff_t>(to), moved);
    for (std::size_t newPos = 0U; newPos < n; ++newPos) map[order[newPos]] = static_cast<int>(newPos);
    const int count = static_cast<int>(n);
    remapNodes(project, [&](int node) { return node < count ? map[static_cast<std::size_t>(node)] : node; });
    ProjectTrack t = std::move(project.tracks[from]);
    project.tracks.erase(project.tracks.begin() + static_cast<std::ptrdiff_t>(from));
    project.tracks.insert(project.tracks.begin() + static_cast<std::ptrdiff_t>(to), std::move(t));
}

void TrackTools::addBus(Project& project, ProjectBus bus) {
    const int master = static_cast<int>(project.tracks.size() + project.buses.size());
    remapNodes(project, [&](int n) { return n >= master ? n + 1 : n; });
    project.buses.push_back(std::move(bus));
}

void TrackTools::removeBus(Project& project, std::size_t bi) {
    if (bi >= project.buses.size()) throw std::out_of_range("bus index");
    const int b = static_cast<int>(bi);
    auto fixRouting = [&](int& out, std::vector<ProjectSend>& sends) {
        if (out == b) out = -1; else if (out > b) --out;
        sends.erase(std::remove_if(sends.begin(), sends.end(), [&](const ProjectSend& s) { return s.destinationBus == b; }), sends.end());
        for (auto& s : sends) if (s.destinationBus > b) --s.destinationBus;
    };
    for (auto& t : project.tracks) fixRouting(t.outputBus, t.sends);
    for (auto& bus : project.buses) fixRouting(bus.outputBus, bus.sends);
    const int node = static_cast<int>(project.tracks.size()) + b;
    project.buses.erase(project.buses.begin() + static_cast<std::ptrdiff_t>(bi));
    remapNodes(project, [&](int n) { return n == node ? -1 : (n > node ? n - 1 : n); });
}

std::size_t TrackTools::duplicateTrack(Project& project, std::size_t index) {
    if (index >= project.tracks.size()) throw std::out_of_range("track index");
    ProjectTrack copy = project.tracks[index];
    copy.name += " Copy";
    copy.solo = false;
    copy.recordArm = false;
    for (auto& slot : copy.pluginSlots) slot.midiInputPort = -1;  // MIDI ports must stay unique
    insertTrack(project, index + 1U, std::move(copy));
    return index + 1U;
}

// ------------------------------------------------------------ MIDI parts --
void MidiTrackTools::ensureParts(ProjectMidiTrack& track) {
    if (!track.parts.empty()) return;
    auto parts = partsOf(track);
    if (parts.empty()) return;
    parts[0].lengthQuarterNotes = std::max(4.0, std::ceil(parts[0].lengthQuarterNotes / 4.0) * 4.0);
    parts[0].loopLengthQuarterNotes = parts[0].lengthQuarterNotes;
    track.parts = std::move(parts);
    track.sequence = MidiSequence {};
}

std::uint64_t MidiTrackTools::addEmptyPart(ProjectMidiTrack& track, double start, double length) {
    if (!(length > 0.0) || start < 0.0) throw std::invalid_argument("MIDI part range invalid");
    ensureParts(track);
    MidiPart part;
    part.id = nextId(track.parts);
    part.timelineStartQuarterNotes = start;
    part.lengthQuarterNotes = length;
    part.loopLengthQuarterNotes = length;
    track.parts.push_back(std::move(part));
    return track.parts.back().id;
}

std::uint64_t MidiTrackTools::addPartFromAbsolute(ProjectMidiTrack& track, const MidiSequence& absolute, double bar) {
    if (absolute.notes().empty() && absolute.messages().empty()) return 0U;
    if (!(bar > 0.0)) bar = 4.0;
    double first = std::numeric_limits<double>::max(), last = 0.0;
    for (const auto& n : absolute.notes()) { first = std::min(first, n.startQuarterNotes); last = std::max(last, n.startQuarterNotes + n.durationQuarterNotes); }
    for (const auto& m : absolute.messages()) { first = std::min(first, m.quarterNotes); last = std::max(last, m.quarterNotes); }
    const double start = std::floor(first / bar) * bar;
    const double end = std::max(start + bar, std::ceil((last + 1.0e-9) / bar) * bar);
    const std::uint64_t id = addEmptyPart(track, start, end - start);
    MidiPart* part = findPart(track, id);
    for (auto n : absolute.notes()) { n.id = 0U; n.startQuarterNotes -= start; (void)part->sequence.addNote(n); }
    for (auto m : absolute.messages()) { m.id = 0U; m.quarterNotes -= start; (void)part->sequence.addMessage(m); }
    return id;
}

MidiPart* MidiTrackTools::findPart(ProjectMidiTrack& track, std::uint64_t id) noexcept {
    for (auto& p : track.parts) if (p.id == id) return &p;
    return nullptr;
}

// ----------------------------------------------------------------- MIDI mods --
MidiRenderPlan compileProjectMidiTrack(const ProjectMidiTrack& track, const TempoMap& tempoMap) {
    if (track.mute) return MidiRenderPlan {};
    if (track.transpose == 0 && track.velocityShift == 0)
        return compileMidiArrangement(track.sequence, track.parts, tempoMap);
    auto modify = [&](MidiSequence& seq) {
        if (track.transpose != 0) seq.transpose(track.transpose);
        if (track.velocityShift != 0) {
            for (const auto& n : std::vector<MusicalMidiNote>(seq.notes())) {
                const int v = std::clamp(static_cast<int>(n.velocity) + track.velocityShift, 1, 127);
                (void)seq.setNoteVelocity(n.id, static_cast<std::uint8_t>(v));
            }
        }
    };
    MidiSequence legacy = track.sequence;
    modify(legacy);
    std::vector<MidiPart> parts = track.parts;
    for (auto& p : parts) modify(p.sequence);
    return compileMidiArrangement(legacy, parts, tempoMap);
}

} // namespace silveton
