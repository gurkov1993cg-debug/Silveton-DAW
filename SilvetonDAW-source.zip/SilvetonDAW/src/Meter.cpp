#include "silveton/Meter.h"
#include <algorithm>
#include <cmath>

namespace silveton {

float Meter::linearToDb(float value) noexcept {
    constexpr float floorDb = -160.0F;
    if (value <= 0.0F) return floorDb;
    return std::max(floorDb, 20.0F * std::log10(value));
}

std::vector<ChannelMeter> Meter::measure(const AudioBuffer& buffer) {
    std::vector<ChannelMeter> result(buffer.channels());
    if (buffer.frames() == 0U) return result;

    for (std::size_t c = 0; c < buffer.channels(); ++c) {
        double sumSquares = 0.0;
        float peak = 0.0F;
        for (std::size_t f = 0; f < buffer.frames(); ++f) {
            const float x = buffer.sample(c, f);
            peak = std::max(peak, std::abs(x));
            sumSquares += static_cast<double>(x) * static_cast<double>(x);
        }
        const float rms = static_cast<float>(std::sqrt(sumSquares / static_cast<double>(buffer.frames())));
        result[c] = {peak, rms, linearToDb(peak), linearToDb(rms)};
    }
    return result;
}

} // namespace silveton
