// Silveton Tone Editor — rendering the edited sound, and MIDI extraction.
//
// How the sound is made again (pitch-synchronous overlap-add, "PSOLA"):
//   1. The pitch marks of the voice are found in the real waveform: one mark per period of the voice.
//   2. For the changed parts, small grains of two periods are cut out around the marks, and laid down
//      again at distances that follow the NEW pitch. Because every grain keeps the voice's own
//      waveform, the formants (the colour of the vowel) stay where they were. To change the
//      formants too, the grains are resampled a little before they are laid down.
//   3. The time bend decides which part of the original every grain is taken from.
//   4. Breath, consonants and silence are cut in grains of fixed size (identity when nothing is
//      bent) and everything is divided by the sum of the grain windows, so the loudness is exact.
//   5. Changed and untouched sound are joined by a short cross-fade; the untouched sound is the
//      original, sample for sample.
#include "silveton/ToneEdit.h"
#include "internal/ToneInternal.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace silveton {

using namespace toneinternal;

namespace {

// ---------------------------------------------------------------- interpolation --
// Windowed-sinc (Lanczos, 8 taps) interpolation table. Linear between 256 phases.
struct SincTable {
    static constexpr int kTaps = 8;
    static constexpr int kPhases = 256;
    std::array<float, static_cast<std::size_t>(kPhases + 1) * kTaps> table {};
    SincTable() {
        for (int p = 0; p <= kPhases; ++p) {
            const double frac = static_cast<double>(p) / kPhases;
            double sum = 0.0;
            double row[kTaps];
            for (int k = 0; k < kTaps; ++k) {
                const double x = static_cast<double>(k - 3) - frac;
                double v = 1.0;
                if (std::abs(x) > 1.0e-12) {
                    v = std::sin(kPi * x) / (kPi * x);
                    v *= std::sin(kPi * x / 4.0) / (kPi * x / 4.0);
                }
                if (std::abs(x) >= 4.0) v = 0.0;
                row[k] = v;
                sum += v;
            }
            for (int k = 0; k < kTaps; ++k) table[static_cast<std::size_t>(p) * kTaps + static_cast<std::size_t>(k)] = static_cast<float>(row[k] / sum);
        }
    }
    // weights for the 8 samples i0-3 .. i0+4
    void weights(double frac, float* w) const {
        const double f = frac * kPhases;
        const int p = std::min(kPhases - 1, static_cast<int>(f));
        const float t = static_cast<float>(f - p);
        const float* a = &table[static_cast<std::size_t>(p) * kTaps];
        const float* b = &table[static_cast<std::size_t>(p + 1) * kTaps];
        for (int k = 0; k < kTaps; ++k) w[k] = a[k] + (b[k] - a[k]) * t;
    }
};
const SincTable& sinc() { static const SincTable t; return t; }

// Value of channel data at fractional position `pos` (zero outside).
inline float interp(const float* x, long n, double pos) {
    const double fl = std::floor(pos);
    const long i0 = static_cast<long>(fl);
    const double frac = pos - fl;
    if (frac < 1.0e-9) return (i0 >= 0 && i0 < n) ? x[i0] : 0.0F;
    float w[SincTable::kTaps];
    sinc().weights(frac, w);
    float acc = 0.0F;
    if (i0 - 3 >= 0 && i0 + 4 < n) {
        for (int k = 0; k < SincTable::kTaps; ++k) acc += w[k] * x[i0 - 3 + k];
    } else {
        for (int k = 0; k < SincTable::kTaps; ++k) {
            const long idx = i0 - 3 + k;
            if (idx >= 0 && idx < n) acc += w[k] * x[idx];
        }
    }
    return acc;
}

// ------------------------------------------------------------------ zero-phase LP --
struct LowpassBiquad {
    double b0, b1, b2, a1, a2;
    static LowpassBiquad make(double fc, double rate, double q) {
        const double w = 2.0 * kPi * fc / rate, c = std::cos(w), s = std::sin(w), alpha = s / (2.0 * q), a0 = 1.0 + alpha;
        return {(1.0 - c) / 2.0 / a0, (1.0 - c) / a0, (1.0 - c) / 2.0 / a0, -2.0 * c / a0, (1.0 - alpha) / a0};
    }
    void run(std::vector<double>& x) const {
        double z1 = 0.0, z2 = 0.0;
        for (double& v : x) { const double y = b0 * v + z1; z1 = b1 * v - a1 * y + z2; z2 = b2 * v - a2 * y; v = y; }
    }
};

void zeroPhaseLowpass(std::vector<double>& x, double fc, double rate) {
    // two Butterworth sections (Q = 0.5412, 1.3066) = 4th order, forward and backward = 8th order magnitude, zero phase
    const LowpassBiquad s1 = LowpassBiquad::make(fc, rate, 0.5412), s2 = LowpassBiquad::make(fc, rate, 1.3066);
    s1.run(x); s2.run(x);
    std::reverse(x.begin(), x.end());
    s1.run(x); s2.run(x);
    std::reverse(x.begin(), x.end());
}

// ----------------------------------------------------------------- voiced runs --
struct VoicedRun {
    std::int64_t start {0};           // first sample (inclusive)
    std::int64_t end {0};             // one past the last sample
    std::vector<double> marks;        // pitch marks (sample positions), sorted
    bool usable {false};
};

class Voice {
public:
    Voice(const AudioBuffer& audio, const ToneAnalysis& analysis, const ToneEdit& edit)
        : frames_(analysis.frames), rate_(analysis.sampleRate), length_(static_cast<long>(audio.frames())) {
        const std::size_t n = frames_.size();
        hzEff_.assign(n, 0.0F);
        for (std::size_t i = 0U; i < n; ++i) hzEff_[i] = frames_.hz[i];
        // frames inside blocks that the search called "no pitch" use the best guess
        for (const ToneBlock& b : edit.blocks) {
            if (b.bypass) continue;
            std::size_t fa = 0U, fb = 0U;
            framesOfRange(frames_, b.start, b.end, fa, fb);
            for (std::size_t i = fa; i < fb; ++i)
                if (hzEff_[i] <= 0.0F && i < frames_.rawHz.size() && frames_.rawHz[i] > 0.0F) hzEff_[i] = frames_.rawHz[i];
        }
        mono_.assign(static_cast<std::size_t>(length_), 0.0F);
        const float inv = 1.0F / static_cast<float>(std::max<std::size_t>(1U, audio.channels()));
        for (std::size_t c = 0U; c < audio.channels(); ++c) {
            const float* p = audio.channelData(c);
            for (long i = 0; i < length_; ++i) mono_[static_cast<std::size_t>(i)] += p[i] * inv;
        }
        // runs
        std::size_t i = 0U;
        while (i < n) {
            if (hzEff_[i] <= 0.0F) { ++i; continue; }
            std::size_t j = i;
            while (j < n && hzEff_[j] > 0.0F) ++j;
            VoicedRun run;
            run.start = std::max<std::int64_t>(0, frameStart(frames_, i));
            run.end = std::min<std::int64_t>(length_, frameStart(frames_, j));
            if (run.end - run.start > static_cast<std::int64_t>(frames_.hop) * 2) runs_.push_back(std::move(run));
            i = j;
        }
    }

    [[nodiscard]] std::vector<VoicedRun>& runs() { return runs_; }
    [[nodiscard]] double hzAt(double sample) const {
        const double pos = sample / static_cast<double>(frames_.hop);
        const long i0 = static_cast<long>(std::floor(pos));
        const double t = pos - static_cast<double>(i0);
        const auto get = [&](long i) { return (i >= 0 && i < static_cast<long>(hzEff_.size())) ? static_cast<double>(hzEff_[static_cast<std::size_t>(i)]) : 0.0; };
        double a = get(i0), b = get(i0 + 1);
        if (a <= 0.0) a = b;
        if (b <= 0.0) b = a;
        if (a <= 0.0) return 0.0;
        return a + (b - a) * t;
    }

    // Finds the pitch marks of one run (needs the run's pitch curve).
    void findMarks(VoicedRun& run) const {
        run.marks.clear();
        run.usable = false;
        const double period0 = rate_ / std::max(30.0, hzAt(0.5 * static_cast<double>(run.start + run.end)));
        const long pad = static_cast<long>(std::ceil(period0 * 3.0)) + 64;
        const long a = std::max(0L, static_cast<long>(run.start) - pad);
        const long b = std::min(length_, static_cast<long>(run.end) + pad);
        if (b - a < 16) return;
        std::vector<double> z(static_cast<std::size_t>(b - a));
        for (long i = a; i < b; ++i) z[static_cast<std::size_t>(i - a)] = static_cast<double>(mono_[static_cast<std::size_t>(i)]);
        // median pitch of the run → cut-off of the filter
        std::vector<double> hs;
        for (std::int64_t s = run.start; s < run.end; s += static_cast<std::int64_t>(frames_.hop)) hs.push_back(hzAt(static_cast<double>(s)));
        std::sort(hs.begin(), hs.end());
        const double medianHz = hs.empty() ? 150.0 : hs[hs.size() / 2U];
        const double fc = std::clamp(3.2 * medianHz, 260.0, std::min(2800.0, 0.45 * rate_));
        zeroPhaseLowpass(z, fc, rate_);

        const long rs = static_cast<long>(run.start) - a, re = static_cast<long>(run.end) - a;
        double maxPos = 0.0, maxNeg = 0.0;
        for (long i = rs; i < re; ++i) { maxPos = std::max(maxPos, z[static_cast<std::size_t>(i)]); maxNeg = std::max(maxNeg, -z[static_cast<std::size_t>(i)]); }
        const double sign = maxPos >= maxNeg ? 1.0 : -1.0;
        const double yMax = std::max(maxPos, maxNeg);
        if (yMax < 1.0e-7) return;
        const auto y = [&](long i) { return sign * z[static_cast<std::size_t>(std::clamp(i, 0L, b - a - 1))]; };

        // start: the strongest peak in the middle of the run
        long first = rs + (re - rs) / 4, last = re - (re - rs) / 4;
        if (last - first < 8) { first = rs; last = re; }
        long startPos = first;
        for (long i = first; i < last; ++i) if (y(i) > y(startPos)) startPos = i;

        const auto searchNext = [&](double from, double direction) -> double {
            const double hz = hzAt(from + static_cast<double>(a));
            if (hz <= 0.0) return -1.0;
            const double T = rate_ / hz;
            const double target = from + direction * T;
            const long lo = static_cast<long>(std::floor(target - 0.28 * T)), hi = static_cast<long>(std::ceil(target + 0.28 * T));
            double best = -1.0, bestScore = -std::numeric_limits<double>::max();
            for (long p = lo; p <= hi; ++p) {
                if (p < 0 || p >= b - a) continue;
                const double score = y(p) - 0.25 * yMax * std::abs(static_cast<double>(p) - target) / (0.28 * T);
                if (score > bestScore) { bestScore = score; best = static_cast<double>(p); }
            }
            if (best >= 1.0 && best < static_cast<double>(b - a - 1)) {
                // the exact top of the peak, between two samples
                const auto p0 = static_cast<long>(best);
                const double y0 = y(p0 - 1), y1 = y(p0), y2 = y(p0 + 1);
                const double denom = y0 - 2.0 * y1 + y2;
                if (denom < -1.0e-15) best += std::clamp(0.5 * (y0 - y2) / denom, -0.5, 0.5);
            }
            return best;
        };

        std::vector<double> forward {static_cast<double>(startPos)}, backward;
        for (;;) {
            const double next = searchNext(forward.back(), 1.0);
            if (next < 0.0 || next <= forward.back() || next > static_cast<double>(re)) break;
            forward.push_back(next);
        }
        double cur = static_cast<double>(startPos);
        for (;;) {
            const double prev = searchNext(cur, -1.0);
            if (prev < 0.0 || prev >= cur || prev < static_cast<double>(rs)) break;
            backward.push_back(prev);
            cur = prev;
        }
        std::reverse(backward.begin(), backward.end());
        for (const double m : backward) run.marks.push_back(m + static_cast<double>(a));
        for (const double m : forward) run.marks.push_back(m + static_cast<double>(a));
        run.usable = run.marks.size() >= 3U;
    }

    [[nodiscard]] const std::vector<float>& mono() const { return mono_; }
    [[nodiscard]] double rate() const { return rate_; }
    [[nodiscard]] long length() const { return length_; }
    [[nodiscard]] const ToneFrames& frames() const { return frames_; }
    [[nodiscard]] const std::vector<float>& hzEff() const { return hzEff_; }

private:
    const ToneFrames& frames_;
    double rate_;
    long length_;
    std::vector<float> hzEff_;
    std::vector<float> mono_;
    std::vector<VoicedRun> runs_;
};

// Index of the run that contains `sample`, or -1.
int runAt(const std::vector<VoicedRun>& runs, double sample) {
    int lo = 0, hi = static_cast<int>(runs.size()) - 1, found = -1;
    while (lo <= hi) {
        const int mid = (lo + hi) / 2;
        if (static_cast<double>(runs[static_cast<std::size_t>(mid)].start) <= sample) { found = mid; lo = mid + 1; } else hi = mid - 1;
    }
    if (found >= 0 && sample < static_cast<double>(runs[static_cast<std::size_t>(found)].end)) return found;
    return -1;
}

std::size_t nearestMark(const std::vector<double>& marks, double s) {
    const auto it = std::lower_bound(marks.begin(), marks.end(), s);
    if (it == marks.begin()) return 0U;
    if (it == marks.end()) return marks.size() - 1U;
    const std::size_t hi = static_cast<std::size_t>(it - marks.begin());
    return (s - marks[hi - 1U] <= marks[hi] - s) ? hi - 1U : hi;
}

// Curves in source time, one value per analysis frame.
struct Curves {
    std::vector<double> shift;    // cents
    std::vector<double> formant;  // cents
    std::vector<double> gain;     // dB
    std::vector<unsigned char> edited;
    bool anyGain {false};
};

double sampleCurve(const std::vector<double>& v, double framePos) {
    if (v.empty()) return 0.0;
    const double clamped = std::clamp(framePos, 0.0, static_cast<double>(v.size() - 1U));
    const auto i0 = static_cast<std::size_t>(clamped);
    const std::size_t i1 = std::min(i0 + 1U, v.size() - 1U);
    const double t = clamped - static_cast<double>(i0);
    return v[i0] + (v[i1] - v[i0]) * t;
}

Curves buildCurves(const ToneAnalysis& analysis, const ToneEdit& edit, const Voice& voice) {
    const ToneFrames& f = analysis.frames;
    const std::size_t n = f.size();
    Curves c;
    c.shift.assign(n, 0.0);
    c.formant.assign(n, 0.0);
    c.gain.assign(n, 0.0);
    c.edited.assign(n, 0);
    const auto& hzEff = voice.hzEff();
    std::vector<int> owner(n, -1);

    for (std::size_t bi = 0U; bi < edit.blocks.size(); ++bi) {
        const ToneBlock& b = edit.blocks[bi];
        if (b.bypass) continue;
        std::size_t fa = 0U, fb = 0U;
        framesOfRange(f, b.start, b.end, fa, fb);
        std::vector<char> have(fb - fa, 0);
        for (std::size_t i = fa; i < fb; ++i) {
            owner[i] = static_cast<int>(bi);
            c.formant[i] = static_cast<double>(b.formantCents);
            c.gain[i] = static_cast<double>(b.gainDb);
            if (b.gainDb != 0.0F) c.anyGain = true;
            if (hzEff[i] <= 0.0F) continue;
            const double m = f.hz[i] > 0.0F ? static_cast<double>(f.midi[i]) : midiFromHz(static_cast<double>(hzEff[i]));
            c.shift[i] = (toneFrameTargetPitch(b, edit, analysis, i) - m) * 100.0;
            have[i - fa] = 1;
        }
        // frames without pitch inside the block: glide between the neighbours
        for (std::size_t i = fa; i < fb; ++i) {
            if (have[i - fa] != 0) continue;
            std::size_t l = i, r = i;
            while (l > fa && have[l - 1U - fa] == 0) --l;
            while (r < fb && have[r - fa] == 0) ++r;
            const bool hasL = l > fa, hasR = r < fb;
            const double vl = hasL ? c.shift[l - 1U] : (hasR ? c.shift[r] : 0.0);
            const double vr = hasR ? c.shift[r] : vl;
            const double t = static_cast<double>(i - l + 1U) / static_cast<double>(r - l + 1U);
            c.shift[i] = vl + (vr - vl) * t;
        }
    }

    // pitch glides from block to block where they touch
    const double frameMs = 1000.0 * static_cast<double>(f.hop) / analysis.sampleRate;
    const long half = std::max(1L, std::lround(static_cast<double>(edit.transitionMs) / (2.0 * frameMs)));
    const std::vector<double> original = c.shift;
    for (std::size_t bi = 0U; bi + 1U < edit.blocks.size(); ++bi) {
        const ToneBlock& a = edit.blocks[bi];
        const ToneBlock& b = edit.blocks[bi + 1U];
        if (a.bypass || b.bypass || b.start - a.end > static_cast<std::int64_t>(2U * f.hop)) continue;
        if (!(a.touched() || b.touched())) continue;
        const long boundary = std::lround(static_cast<double>(a.end + b.start) * 0.5 / static_cast<double>(f.hop));
        const long lo = boundary - half, hi = boundary + half;   // frames [lo, hi) are blended
        if (lo - 1 < 0 || hi >= static_cast<long>(n)) continue;
        const double left = original[static_cast<std::size_t>(lo - 1)], right = original[static_cast<std::size_t>(hi)];
        for (long i = lo; i < hi; ++i) {
            const double t = (static_cast<double>(i - lo) + 0.5) / static_cast<double>(hi - lo);
            const double w = 0.5 - 0.5 * std::cos(kPi * t);
            c.shift[static_cast<std::size_t>(i)] = left + (right - left) * w;
            const double fl = c.formant[static_cast<std::size_t>(std::max(0L, lo - 1))], fr = c.formant[static_cast<std::size_t>(std::min<long>(hi, static_cast<long>(n) - 1))];
            c.formant[static_cast<std::size_t>(i)] = fl + (fr - fl) * w;
        }
    }

    for (std::size_t i = 0U; i < n; ++i)
        c.edited[i] = (std::abs(c.shift[i]) > 0.02 || std::abs(c.formant[i]) > 0.02) ? 1U : 0U;
    // soften the gain steps between frames
    if (c.anyGain) {
        std::vector<double> g = c.gain;
        for (std::size_t i = 1U; i + 1U < n; ++i) g[i] = 0.25 * c.gain[i - 1U] + 0.5 * c.gain[i] + 0.25 * c.gain[i + 1U];
        c.gain = g;
    }
    return c;
}

struct Interval { double a; double b; };

} // namespace

// ============================================================================ render ==
AudioBuffer ToneRenderer::render(const AudioBuffer& original, const ToneAnalysis& analysis, const ToneEdit& edit,
                                 const ToneRenderOptions& options, const std::atomic<bool>* cancel) {
    AudioBuffer out = original;
    const long L = static_cast<long>(original.frames());
    if (L == 0L || original.channels() == 0U) return out;
    if (analysis.frames.size() == 0U || analysis.length != static_cast<std::int64_t>(L))
        throw std::invalid_argument("tone render: the analysis does not belong to this audio");
    if (!edit.anyChange()) return out;
    const auto cancelled = [&]() { return cancel != nullptr && cancel->load(std::memory_order_relaxed); };

    const double rate = analysis.sampleRate;
    const std::size_t channels = original.channels();
    const ToneTimeMap map(edit.warp, L);
    Voice voice(original, analysis, edit);
    const Curves curves = buildCurves(analysis, edit, voice);
    const ToneFrames& frames = analysis.frames;
    const double hop = static_cast<double>(frames.hop);
    const long ramp = std::max(8L, std::lround(options.rampMs * 0.001 * rate));

    // ---------------------------------------------------- where is work to do (result time) --
    std::vector<Interval> jobs;
    {
        const std::size_t n = frames.size();
        std::size_t i = 0U;
        while (i < n) {
            if (curves.edited[i] == 0U) { ++i; continue; }
            std::size_t j = i;
            std::size_t gap = 0U;
            std::size_t lastEdited = i;
            while (j < n && gap <= 6U) {
                if (curves.edited[j] != 0U) { lastEdited = j; gap = 0U; } else ++gap;
                ++j;
            }
            const double s0 = static_cast<double>(frameStart(frames, i));
            const double s1 = static_cast<double>(frameStart(frames, lastEdited + 1U));
            jobs.push_back({map.forward(s0), map.forward(s1)});
            i = lastEdited + 1U;
        }
        for (const auto& p : map.pieces())
            if (std::abs((p.t1 - p.t0) - (p.s1 - p.s0)) > 1.0e-6) jobs.push_back({p.t0, p.t1});
        std::sort(jobs.begin(), jobs.end(), [](const Interval& a, const Interval& b) { return a.a < b.a; });
        std::vector<Interval> merged;
        for (const Interval& job : jobs) {
            if (!merged.empty() && job.a <= merged.back().b + 2.0 * static_cast<double>(ramp)) merged.back().b = std::max(merged.back().b, job.b);
            else merged.push_back(job);
        }
        jobs = merged;
    }

    // ---------------------------------------------------------------- the untouched sound --
    if (!map.identity()) {
        for (std::size_t c = 0U; c < channels; ++c) {
            const float* src = original.channelData(c);
            float* dst = out.channelData(c);
            for (long t = 0; t < L; ++t) {
                const long s = std::clamp(static_cast<long>(std::llround(map.inverse(static_cast<double>(t)))), 0L, L - 1L);
                dst[t] = src[s];
            }
        }
    }

    // ---------------------------------------------------------------------- pitch marks --
    {
        std::vector<char> needed(voice.runs().size(), 0);
        for (const Interval& job : jobs) {
            const double s0 = map.inverse(job.a - static_cast<double>(ramp)) - 2.0 * hop, s1 = map.inverse(job.b + static_cast<double>(ramp)) + 2.0 * hop;
            for (std::size_t r = 0U; r < voice.runs().size(); ++r)
                if (static_cast<double>(voice.runs()[r].end) > s0 && static_cast<double>(voice.runs()[r].start) < s1) needed[r] = 1;
        }
        for (std::size_t r = 0U; r < voice.runs().size(); ++r) if (needed[r] != 0) voice.findMarks(voice.runs()[r]);
    }
    if (cancelled()) return original;

    // ------------------------------------------------------------------------ the jobs --
    const long unvoicedHop = std::max(32L, std::lround(0.004 * rate));
    for (const Interval& job : jobs) {
        if (cancelled()) return original;
        const long j0 = static_cast<long>(std::floor(job.a)), j1 = static_cast<long>(std::ceil(job.b));
        const long base = std::max(0L, j0 - ramp);
        const long top = std::min(L, j1 + ramp);
        if (top <= base) continue;
        const std::size_t span = static_cast<std::size_t>(top - base);
        std::vector<std::vector<float>> acc(channels, std::vector<float>(span, 0.0F));
        std::vector<float> wsum(span, 0.0F);

        double t = static_cast<double>(j0 - ramp - unvoicedHop);
        bool voicedState = false;
        long lastLocked = -1;
        std::size_t guard = 0U;
        const double tEnd = static_cast<double>(j1 + ramp + unvoicedHop);
        while (t <= tEnd) {
            if ((++guard & 1023U) == 0U && cancelled()) return original;
            double s = map.inverse(t);
            const int runIndex = runAt(voice.runs(), s);
            const VoicedRun* run = runIndex >= 0 && voice.runs()[static_cast<std::size_t>(runIndex)].usable ? &voice.runs()[static_cast<std::size_t>(runIndex)] : nullptr;
            double halfWidth;
            double srcCentre;     // source position that sits at the grain centre
            double stretch;       // source samples per output sample inside the grain
            double advance;
            if (run != nullptr) {
                std::size_t j = nearestMark(run->marks, s);
                if (!voicedState) {
                    t = map.forward(run->marks[j]);
                    s = run->marks[j];
                    voicedState = true;
                    lastLocked = static_cast<long>(j);
                }
                const double hz = voice.hzAt(s);
                if (hz <= 0.0) { voicedState = false; t += static_cast<double>(unvoicedHop); continue; }
                j = nearestMark(run->marks, s);
                const double basePeriod = rate / hz;
                double Ta;
                const auto& mk = run->marks;
                if (j > 0U && j + 1U < mk.size()) Ta = 0.5 * (mk[j + 1U] - mk[j - 1U]);
                else if (j + 1U < mk.size()) Ta = mk[j + 1U] - mk[j];
                else Ta = mk[j] - mk[j - 1U];
                Ta = std::clamp(Ta, 0.6 * basePeriod, 1.6 * basePeriod);
                const double framePos = s / hop;
                const double shiftCents = sampleCurve(curves.shift, framePos);
                const double ratio = std::pow(2.0, shiftCents / 1200.0);
                const double alpha = std::pow(2.0, sampleCurve(curves.formant, framePos) / 1200.0);
                const double Ts = basePeriod / ratio;
                // Nothing moves in pitch or time here: keep every grain exactly on its own pitch mark, so the
                // sound is the original again (no slow drift between the marks and the pitch curve).
                if (std::abs(shiftCents) < 2.0 && static_cast<long>(j) != lastLocked) {
                    const double slope = map.inverse(t + 1.0) - map.inverse(t);
                    const double anchor = map.forward(run->marks[j]);
                    if (std::abs(slope - 1.0) < 1.0e-6 && std::abs(anchor - t) < 0.5 * Ts) { t = anchor; s = run->marks[j]; lastLocked = static_cast<long>(j); }
                }
                halfWidth = std::clamp(Ta / alpha, 0.8 * Ts, 1.25 * Ts);
                srcCentre = mk[j];
                stretch = alpha;
                advance = Ts;
            } else {
                voicedState = false;
                halfWidth = static_cast<double>(unvoicedHop);
                srcCentre = s;
                stretch = 1.0;
                advance = static_cast<double>(unvoicedHop);
            }
            const long m0 = static_cast<long>(std::ceil(t - halfWidth)), m1 = static_cast<long>(std::floor(t + halfWidth));
            for (long m = std::max(m0, base); m <= std::min(m1, top - 1L); ++m) {
                const double u = (static_cast<double>(m) - t) / halfWidth;
                const float w = static_cast<float>(0.5 + 0.5 * std::cos(kPi * u));
                if (w <= 0.0F) continue;
                const double pos = srcCentre + (static_cast<double>(m) - t) * stretch;
                const std::size_t idx = static_cast<std::size_t>(m - base);
                for (std::size_t c = 0U; c < channels; ++c) acc[c][idx] += w * interp(original.channelData(c), L, pos);
                wsum[idx] += w;
            }
            t += advance;
        }

        // wet / dry
        for (long m = base; m < top; ++m) {
            const std::size_t idx = static_cast<std::size_t>(m - base);
            double mask = 1.0;
            if (m < j0) mask = 0.5 - 0.5 * std::cos(kPi * std::clamp(static_cast<double>(m - (j0 - ramp)) / static_cast<double>(ramp), 0.0, 1.0));
            else if (m >= j1) mask = 0.5 - 0.5 * std::cos(kPi * std::clamp(1.0 - static_cast<double>(m - j1) / static_cast<double>(ramp), 0.0, 1.0));
            if (wsum[idx] < 1.0e-3F) mask = 0.0;
            if (mask <= 0.0) continue;
            for (std::size_t c = 0U; c < channels; ++c) {
                const float wet = acc[c][idx] / wsum[idx];
                float& dst = out.sample(c, static_cast<std::size_t>(m));
                dst = static_cast<float>(static_cast<double>(dst) * (1.0 - mask) + static_cast<double>(wet) * mask);
            }
        }
    }

    // ------------------------------------------------------------------- block loudness --
    if (curves.anyGain) {
        for (long m = 0; m < L; ++m) {
            const double s = map.identity() ? static_cast<double>(m) : map.inverse(static_cast<double>(m));
            const double db = sampleCurve(curves.gain, s / hop);
            if (std::abs(db) < 1.0e-4) continue;
            const auto g = static_cast<float>(std::pow(10.0, db / 20.0));
            for (std::size_t c = 0U; c < channels; ++c) out.sample(c, static_cast<std::size_t>(m)) *= g;
        }
    }
    return out;
}

// ============================================================================== MIDI ==
std::vector<ToneMidiNote> ToneMidi::extract(const ToneAnalysis& analysis, const ToneEdit& edit, const ToneMidiOptions& options) {
    std::vector<ToneMidiNote> notes;
    const ToneTimeMap map(edit.warp, analysis.length);
    const ToneFrames& f = analysis.frames;
    for (const ToneBlock& b : edit.blocks) {
        ToneMidiNote note;
        note.start = static_cast<std::int64_t>(std::llround(map.forward(static_cast<double>(b.start))));
        note.end = static_cast<std::int64_t>(std::llround(map.forward(static_cast<double>(b.end))));
        if (note.end <= note.start) continue;
        const double pitch = (options.useTarget && !b.bypass) ? toneBlockTargetPitch(b, edit) : static_cast<double>(b.pitch);
        note.pitch = std::clamp(static_cast<int>(std::floor(pitch + 0.5)), 0, 127);
        const double loud = std::clamp((static_cast<double>(b.levelDb) + 45.0) / 37.0, 0.0, 1.0);
        note.velocity = std::clamp(options.minVelocity + static_cast<int>(std::lround(loud * (options.maxVelocity - options.minVelocity))), 1, 127);
        if (options.useBend && f.hop > 0U) {
            std::size_t fa = 0U, fb = 0U;
            framesOfRange(f, b.start, b.end, fa, fb);
            int last = -100000;
            for (std::size_t i = fa; i < fb; ++i) {
                if (f.hz[i] <= 0.0F) continue;
                const double target = (options.useTarget && !b.bypass) ? toneFrameTargetPitch(b, edit, analysis, i) : static_cast<double>(f.midi[i]);
                const double semis = target - static_cast<double>(note.pitch);
                const int value = std::clamp(static_cast<int>(std::lround(8192.0 + semis / options.bendRangeSemitones * 8192.0)), 0, 16383);
                if (std::abs(value - last) < 48) continue;
                last = value;
                note.bend.emplace_back(static_cast<std::int64_t>(std::llround(map.forward(static_cast<double>(i * f.hop)))), value);
            }
        }
        notes.push_back(std::move(note));
    }
    return notes;
}

} // namespace silveton
