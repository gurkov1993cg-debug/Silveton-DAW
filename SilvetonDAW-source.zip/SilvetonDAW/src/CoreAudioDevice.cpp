#include "silveton/CoreAudioDevice.h"

#if defined(__APPLE__)

#include <AudioUnit/AudioUnit.h>
#include <CoreAudio/CoreAudio.h>
#include <CoreFoundation/CoreFoundation.h>

#include <algorithm>
#include <chrono>
#include <atomic>
#include <cmath>
#include <cstring>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <utility>
#include <vector>

namespace silveton {
namespace {

[[noreturn]] void throwStatus(const char* operation, OSStatus status) {
    char code[5] {};
    const std::uint32_t raw = static_cast<std::uint32_t>(status);
    code[0] = static_cast<char>((raw >> 24U) & 0xFFU);
    code[1] = static_cast<char>((raw >> 16U) & 0xFFU);
    code[2] = static_cast<char>((raw >> 8U) & 0xFFU);
    code[3] = static_cast<char>(raw & 0xFFU);

    const bool printable = code[0] >= 32 && code[0] <= 126 &&
                           code[1] >= 32 && code[1] <= 126 &&
                           code[2] >= 32 && code[2] <= 126 &&
                           code[3] >= 32 && code[3] <= 126;

    std::ostringstream text;
    text << operation << " failed (OSStatus " << status;
    if (printable) text << ", '" << code << "'";
    text << ')';
    throw std::runtime_error(text.str());
}

void checkStatus(OSStatus status, const char* operation) {
    if (status != noErr) throwStatus(operation, status);
}

AudioObjectPropertyAddress propertyAddress(AudioObjectPropertySelector selector,
                                           AudioObjectPropertyScope scope,
                                           AudioObjectPropertyElement element = static_cast<AudioObjectPropertyElement>(0U)) {
    AudioObjectPropertyAddress result {};
    result.mSelector = selector;
    result.mScope = scope;
    result.mElement = element;
    return result;
}

std::uint32_t defaultDevice(AudioObjectPropertySelector selector) {
    AudioDeviceID id = kAudioObjectUnknown;
    UInt32 size = sizeof(id);
    auto address = propertyAddress(selector, kAudioObjectPropertyScopeGlobal);
    checkStatus(AudioObjectGetPropertyData(kAudioObjectSystemObject, &address, 0, nullptr, &size, &id),
                "AudioObjectGetPropertyData(default device)");
    return static_cast<std::uint32_t>(id);
}

std::string deviceName(AudioDeviceID device) {
    CFStringRef name = nullptr;
    UInt32 size = sizeof(name);
    auto address = propertyAddress(kAudioObjectPropertyName, kAudioObjectPropertyScopeGlobal);
    const OSStatus status = AudioObjectGetPropertyData(device, &address, 0, nullptr, &size, &name);
    if (status != noErr || name == nullptr) return "CoreAudio Device";

    char utf8[512] {};
    const Boolean ok = CFStringGetCString(name, utf8, static_cast<CFIndex>(sizeof(utf8)), kCFStringEncodingUTF8);
    CFRelease(name);
    return ok ? std::string(utf8) : std::string("CoreAudio Device");
}

std::string deviceUidString(AudioDeviceID device) {
    CFStringRef uid = nullptr;
    UInt32 size = sizeof(uid);
    auto address = propertyAddress(kAudioDevicePropertyDeviceUID, kAudioObjectPropertyScopeGlobal);
    const OSStatus status = AudioObjectGetPropertyData(device, &address, 0, nullptr, &size, &uid);
    if (status != noErr || uid == nullptr) return {};

    char utf8[512] {};
    const Boolean ok = CFStringGetCString(uid, utf8, static_cast<CFIndex>(sizeof(utf8)), kCFStringEncodingUTF8);
    CFRelease(uid);
    return ok ? std::string(utf8) : std::string();
}

AudioDeviceID deviceIdForUid(const std::string& wantedUid) {
    if (wantedUid.empty()) return kAudioObjectUnknown;
    UInt32 size = 0U;
    auto address = propertyAddress(kAudioHardwarePropertyDevices, kAudioObjectPropertyScopeGlobal);
    checkStatus(AudioObjectGetPropertyDataSize(kAudioObjectSystemObject, &address, 0, nullptr, &size),
                "AudioObjectGetPropertyDataSize(devices for UID)");
    std::vector<AudioDeviceID> ids(size / sizeof(AudioDeviceID));
    if (!ids.empty()) {
        checkStatus(AudioObjectGetPropertyData(kAudioObjectSystemObject, &address, 0, nullptr, &size, ids.data()),
                    "AudioObjectGetPropertyData(devices for UID)");
    }
    for (const AudioDeviceID id : ids) {
        if (deviceUidString(id) == wantedUid) return id;
    }
    return kAudioObjectUnknown;
}

std::uint32_t channelCount(AudioDeviceID device, AudioObjectPropertyScope scope) {
    auto address = propertyAddress(kAudioDevicePropertyStreamConfiguration, scope);
    UInt32 size = 0U;
    if (AudioObjectGetPropertyDataSize(device, &address, 0, nullptr, &size) != noErr || size < sizeof(AudioBufferList)) {
        return 0U;
    }

    std::vector<std::uint8_t> bytes(size, 0U);
    auto* list = reinterpret_cast<AudioBufferList*>(bytes.data());
    if (AudioObjectGetPropertyData(device, &address, 0, nullptr, &size, list) != noErr) return 0U;

    std::uint64_t channels = 0U;
    for (UInt32 i = 0U; i < list->mNumberBuffers; ++i) channels += list->mBuffers[i].mNumberChannels;
    return static_cast<std::uint32_t>(std::min<std::uint64_t>(channels, std::numeric_limits<std::uint32_t>::max()));
}

double nominalSampleRate(AudioDeviceID device) {
    Float64 sampleRate = 0.0;
    UInt32 size = sizeof(sampleRate);
    auto address = propertyAddress(kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal);
    if (AudioObjectGetPropertyData(device, &address, 0, nullptr, &size, &sampleRate) != noErr) return 0.0;
    return static_cast<double>(sampleRate);
}

std::uint32_t latencyProperty(AudioDeviceID device,
                              AudioObjectPropertySelector selector,
                              AudioObjectPropertyScope scope) noexcept {
    UInt32 value = 0U;
    UInt32 size = sizeof(value);
    auto address = propertyAddress(selector, scope);
    if (AudioObjectGetPropertyData(device, &address, 0, nullptr, &size, &value) != noErr) return 0U;
    return static_cast<std::uint32_t>(value);
}

std::uint32_t streamLatencyFrames(AudioDeviceID device, AudioObjectPropertyScope scope) noexcept {
    auto streamsAddress = propertyAddress(kAudioDevicePropertyStreams, scope);
    UInt32 size = 0U;
    if (AudioObjectGetPropertyDataSize(device, &streamsAddress, 0, nullptr, &size) != noErr || size == 0U) return 0U;

    std::vector<AudioStreamID> streams(size / sizeof(AudioStreamID));
    if (streams.empty()) return 0U;
    if (AudioObjectGetPropertyData(device, &streamsAddress, 0, nullptr, &size, streams.data()) != noErr) return 0U;

    std::uint32_t maximum = 0U;
    for (const AudioStreamID stream : streams) {
        UInt32 latency = 0U;
        UInt32 latencySize = sizeof(latency);
        auto latencyAddress = propertyAddress(kAudioStreamPropertyLatency, kAudioObjectPropertyScopeGlobal);
        if (AudioObjectGetPropertyData(stream, &latencyAddress, 0, nullptr, &latencySize, &latency) == noErr) {
            maximum = std::max(maximum, static_cast<std::uint32_t>(latency));
        }
    }
    return maximum;
}

bool deviceIsAlive(AudioDeviceID device) noexcept {
    UInt32 alive = 0U;
    UInt32 size = sizeof(alive);
    auto address = propertyAddress(kAudioDevicePropertyDeviceIsAlive, kAudioObjectPropertyScopeGlobal);
    return AudioObjectGetPropertyData(device, &address, 0, nullptr, &size, &alive) == noErr && alive != 0U;
}

AudioStreamBasicDescription planarFloatFormat(double sampleRate, std::uint32_t channels) {
    AudioStreamBasicDescription format {};
    format.mSampleRate = sampleRate;
    format.mFormatID = kAudioFormatLinearPCM;
    format.mFormatFlags = kAudioFormatFlagsNativeFloatPacked | kAudioFormatFlagIsNonInterleaved;
    format.mBytesPerPacket = sizeof(Float32);
    format.mFramesPerPacket = 1U;
    format.mBytesPerFrame = sizeof(Float32);
    format.mChannelsPerFrame = channels;
    format.mBitsPerChannel = 32U;
    return format;
}

} // namespace

class CoreAudioDevice::Impl {
public:
    Impl(AudioDeviceConfig requested, CoreAudioDeviceOptions options)
        : requested_(requested), options_(options) {
        validateRequestedConfig();
        try {
            open();
        } catch (...) {
            cleanup();
            throw;
        }
    }

    ~Impl() { cleanup(); }

    const AudioDeviceConfig& config() const noexcept { return actual_; }
    bool isRunning() const noexcept { return running_.load(std::memory_order_acquire); }
    std::uint32_t deviceId() const noexcept { return static_cast<std::uint32_t>(deviceId_); }
    const std::string& deviceUid() const noexcept { return resolvedDeviceUid_; }

    CoreAudioDeviceStatus status() const noexcept {
        CoreAudioDeviceStatus result;
        result.needsReopen = needsReopen_.load(std::memory_order_acquire);
        result.callbackCount = callbackCount_.load(std::memory_order_acquire);
        result.overloadCount = overloadCount_.load(std::memory_order_acquire);
        result.inputLatencyFrames = inputLatencyFrames_;
        result.outputLatencyFrames = outputLatencyFrames_;
        result.audioUnitLatencyFrames = audioUnitLatencyFrames_;
        return result;
    }

    void clearReopenRequest() noexcept { needsReopen_.store(false, std::memory_order_release); }

    void reopen() {
        IAudioDeviceCallback* previousCallback = callback_.load(std::memory_order_acquire);
        const bool wasRunning = isRunning();
        cleanup();
        try {
            open();
            needsReopen_.store(false, std::memory_order_release);
            if (wasRunning && previousCallback != nullptr) start(*previousCallback);
        } catch (...) {
            needsReopen_.store(true, std::memory_order_release);
            cleanup();
            throw;
        }
    }

    void start(IAudioDeviceCallback& callback) {
        if (isRunning()) throw std::logic_error("CoreAudio device already running");
        if (audioUnit_ == nullptr) throw std::logic_error("CoreAudio device is not open");

        callback_.store(&callback, std::memory_order_release);
        const OSStatus status = AudioOutputUnitStart(audioUnit_);
        if (status != noErr) {
            callback_.store(nullptr, std::memory_order_release);
            throwStatus("AudioOutputUnitStart", status);
        }
        running_.store(true, std::memory_order_release);
    }

    void stop() noexcept {
        if (audioUnit_ != nullptr && running_.exchange(false, std::memory_order_acq_rel)) {
            AudioOutputUnitStop(audioUnit_);
        }
        callback_.store(nullptr, std::memory_order_release);
    }

private:
    void cleanup() noexcept {
        stop();
        removeListeners();
        if (audioUnit_ != nullptr) {
            if (audioUnitInitialized_) AudioUnitUninitialize(audioUnit_);
            AudioComponentInstanceDispose(audioUnit_);
            audioUnit_ = nullptr;
            audioUnitInitialized_ = false;
        }
    }

    void validateRequestedConfig() const {
        if (!std::isfinite(requested_.sampleRate) || requested_.sampleRate <= 0.0) {
            throw std::invalid_argument("invalid CoreAudio sample rate");
        }
        if (requested_.blockSize == 0U) throw std::invalid_argument("invalid CoreAudio block size");
        if (requested_.outputChannels == 0U) throw std::invalid_argument("CoreAudio needs at least one output channel");
    }

    void open() {
        if (!options_.deviceUid.empty()) {
            deviceId_ = deviceIdForUid(options_.deviceUid);
            if (deviceId_ == kAudioObjectUnknown) throw std::runtime_error("CoreAudio device UID is not currently available");
        } else {
            deviceId_ = options_.deviceId == 0U
                ? static_cast<AudioDeviceID>(CoreAudioDevice::defaultOutputDeviceId())
                : static_cast<AudioDeviceID>(options_.deviceId);
        }
        if (deviceId_ == kAudioObjectUnknown) throw std::runtime_error("no CoreAudio output device available");
        if (!deviceIsAlive(deviceId_)) throw std::runtime_error("selected CoreAudio device is not alive");
        resolvedDeviceUid_ = deviceUidString(deviceId_);

        const std::uint32_t availableInputs = channelCount(deviceId_, kAudioDevicePropertyScopeInput);
        const std::uint32_t availableOutputs = channelCount(deviceId_, kAudioDevicePropertyScopeOutput);
        if (requested_.inputChannels > availableInputs) throw std::runtime_error("requested CoreAudio input channel count is unavailable");
        if (requested_.outputChannels > availableOutputs) throw std::runtime_error("requested CoreAudio output channel count is unavailable");

        configureDeviceSampleRate();
        configureDeviceBufferSize();

        actual_ = requested_;
        actual_.sampleRate = nominalSampleRate(deviceId_);
        if (!std::isfinite(actual_.sampleRate) || actual_.sampleRate <= 0.0) {
            throw std::runtime_error("CoreAudio returned an invalid sample rate");
        }
        if (std::abs(actual_.sampleRate - requested_.sampleRate) > 0.01) {
            throw std::runtime_error("CoreAudio device did not accept requested sample rate; no hidden resampling is allowed");
        }
        actual_.blockSize = currentBufferSize();
        if (actual_.blockSize == 0U) throw std::runtime_error("CoreAudio returned an invalid block size");

        createAudioUnit();
        prepareRealtimeBuffers();
        calculateLatencies();
        addListeners();
    }

    void configureDeviceSampleRate() {
        const double before = nominalSampleRate(deviceId_);
        if (std::isfinite(before) && std::abs(before - requested_.sampleRate) <= 0.01) return;

        Float64 requestedRate = requested_.sampleRate;
        auto address = propertyAddress(kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal);
        const OSStatus status = AudioObjectSetPropertyData(deviceId_, &address, 0, nullptr, sizeof(requestedRate), &requestedRate);
        if (status != noErr) throwStatus("AudioObjectSetPropertyData(sample rate)", status);

        // Some CoreAudio drivers publish the new nominal rate asynchronously.
        // This wait runs only on the control/open thread, never in renderProc.
        for (int attempt = 0; attempt < 50; ++attempt) {
            const double current = nominalSampleRate(deviceId_);
            if (std::isfinite(current) && std::abs(current - requested_.sampleRate) <= 0.01) return;
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        throw std::runtime_error("CoreAudio device did not reach requested sample rate; no hidden resampling is allowed");
    }

    void configureDeviceBufferSize() {
        UInt32 requestedFrames = requested_.blockSize;
        auto address = propertyAddress(kAudioDevicePropertyBufferFrameSize, kAudioObjectPropertyScopeGlobal);
        const OSStatus status = AudioObjectSetPropertyData(deviceId_, &address, 0, nullptr, sizeof(requestedFrames), &requestedFrames);
        if (status != noErr) {
            const std::uint32_t current = currentBufferSize();
            if (current == 0U) throwStatus("AudioObjectSetPropertyData(buffer size)", status);
        }
    }

    std::uint32_t currentBufferSize() const {
        UInt32 frames = 0U;
        UInt32 size = sizeof(frames);
        auto address = propertyAddress(kAudioDevicePropertyBufferFrameSize, kAudioObjectPropertyScopeGlobal);
        checkStatus(AudioObjectGetPropertyData(deviceId_, &address, 0, nullptr, &size, &frames),
                    "AudioObjectGetPropertyData(buffer size)");
        return static_cast<std::uint32_t>(frames);
    }

    void createAudioUnit() {
        AudioComponentDescription description {};
        description.componentType = kAudioUnitType_Output;
        description.componentSubType = kAudioUnitSubType_HALOutput;
        description.componentManufacturer = kAudioUnitManufacturer_Apple;

        AudioComponent component = AudioComponentFindNext(nullptr, &description);
        if (component == nullptr) throw std::runtime_error("AUHAL AudioComponent is unavailable");
        checkStatus(AudioComponentInstanceNew(component, &audioUnit_), "AudioComponentInstanceNew(AUHAL)");

        UInt32 enable = 1U;
        checkStatus(AudioUnitSetProperty(audioUnit_, kAudioOutputUnitProperty_EnableIO,
                                         kAudioUnitScope_Output, 0U, &enable, sizeof(enable)),
                    "AudioUnitSetProperty(enable output)");

        const UInt32 inputEnable = actual_.inputChannels > 0U ? 1U : 0U;
        checkStatus(AudioUnitSetProperty(audioUnit_, kAudioOutputUnitProperty_EnableIO,
                                         kAudioUnitScope_Input, 1U, &inputEnable, sizeof(inputEnable)),
                    "AudioUnitSetProperty(enable input)");

        checkStatus(AudioUnitSetProperty(audioUnit_, kAudioOutputUnitProperty_CurrentDevice,
                                         kAudioUnitScope_Global, 0U, &deviceId_, sizeof(deviceId_)),
                    "AudioUnitSetProperty(current device)");

        const AudioStreamBasicDescription outputFormat = planarFloatFormat(actual_.sampleRate, actual_.outputChannels);
        checkStatus(AudioUnitSetProperty(audioUnit_, kAudioUnitProperty_StreamFormat,
                                         kAudioUnitScope_Input, 0U, &outputFormat, sizeof(outputFormat)),
                    "AudioUnitSetProperty(output client format)");

        if (actual_.inputChannels > 0U) {
            const AudioStreamBasicDescription inputFormat = planarFloatFormat(actual_.sampleRate, actual_.inputChannels);
            checkStatus(AudioUnitSetProperty(audioUnit_, kAudioUnitProperty_StreamFormat,
                                             kAudioUnitScope_Output, 1U, &inputFormat, sizeof(inputFormat)),
                        "AudioUnitSetProperty(input client format)");
        }

        UInt32 maxFrames = actual_.blockSize;
        checkStatus(AudioUnitSetProperty(audioUnit_, kAudioUnitProperty_MaximumFramesPerSlice,
                                         kAudioUnitScope_Global, 0U, &maxFrames, sizeof(maxFrames)),
                    "AudioUnitSetProperty(maximum frames per slice)");

        AURenderCallbackStruct renderCallback {};
        renderCallback.inputProc = &Impl::renderProc;
        renderCallback.inputProcRefCon = this;
        checkStatus(AudioUnitSetProperty(audioUnit_, kAudioUnitProperty_SetRenderCallback,
                                         kAudioUnitScope_Input, 0U, &renderCallback, sizeof(renderCallback)),
                    "AudioUnitSetProperty(render callback)");

        checkStatus(AudioUnitInitialize(audioUnit_), "AudioUnitInitialize(AUHAL)");
        audioUnitInitialized_ = true;
    }

    void prepareRealtimeBuffers() {
        inputPtrs_.resize(actual_.inputChannels, nullptr);
        inputConstPtrs_.resize(actual_.inputChannels, nullptr);
        outputPtrs_.resize(actual_.outputChannels, nullptr);

        if (actual_.inputChannels == 0U) return;

        const std::size_t samples = static_cast<std::size_t>(actual_.inputChannels) * actual_.blockSize;
        inputStorage_.assign(samples, 0.0F);

        const std::size_t bytes = offsetof(AudioBufferList, mBuffers) +
                                  sizeof(AudioBuffer) * static_cast<std::size_t>(actual_.inputChannels);
        inputListStorage_.assign(bytes, 0U);
        inputList_ = reinterpret_cast<AudioBufferList*>(inputListStorage_.data());
        inputList_->mNumberBuffers = actual_.inputChannels;

        for (std::uint32_t channel = 0U; channel < actual_.inputChannels; ++channel) {
            float* data = inputStorage_.data() + static_cast<std::size_t>(channel) * actual_.blockSize;
            inputPtrs_[channel] = data;
            inputConstPtrs_[channel] = data;
            inputList_->mBuffers[channel].mNumberChannels = 1U;
            inputList_->mBuffers[channel].mDataByteSize = actual_.blockSize * sizeof(float);
            inputList_->mBuffers[channel].mData = data;
        }
    }

    void calculateLatencies() noexcept {
        inputLatencyFrames_ = latencyProperty(deviceId_, kAudioDevicePropertyLatency, kAudioDevicePropertyScopeInput) +
                              latencyProperty(deviceId_, kAudioDevicePropertySafetyOffset, kAudioDevicePropertyScopeInput) +
                              streamLatencyFrames(deviceId_, kAudioDevicePropertyScopeInput);
        outputLatencyFrames_ = latencyProperty(deviceId_, kAudioDevicePropertyLatency, kAudioDevicePropertyScopeOutput) +
                               latencyProperty(deviceId_, kAudioDevicePropertySafetyOffset, kAudioDevicePropertyScopeOutput) +
                               streamLatencyFrames(deviceId_, kAudioDevicePropertyScopeOutput);

        Float64 unitLatencySeconds = 0.0;
        UInt32 size = sizeof(unitLatencySeconds);
        if (audioUnit_ != nullptr &&
            AudioUnitGetProperty(audioUnit_, kAudioUnitProperty_Latency, kAudioUnitScope_Global, 0U,
                                 &unitLatencySeconds, &size) == noErr &&
            std::isfinite(unitLatencySeconds) && unitLatencySeconds > 0.0) {
            const double frames = unitLatencySeconds * actual_.sampleRate;
            audioUnitLatencyFrames_ = static_cast<std::uint32_t>(std::min<double>(
                std::llround(frames), static_cast<double>(std::numeric_limits<std::uint32_t>::max())));
        }
    }

    void addListeners() {
        listeners_.reserve(4U);
        auto alive = propertyAddress(kAudioDevicePropertyDeviceIsAlive, kAudioObjectPropertyScopeGlobal);
        auto rate = propertyAddress(kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal);
        auto buffer = propertyAddress(kAudioDevicePropertyBufferFrameSize, kAudioObjectPropertyScopeGlobal);
        auto overload = propertyAddress(kAudioDeviceProcessorOverload, kAudioObjectPropertyScopeGlobal);

        checkStatus(AudioObjectAddPropertyListener(deviceId_, &alive, &Impl::devicePropertyListener, this),
                    "AudioObjectAddPropertyListener(device alive)");
        listeners_.push_back(alive);
        checkStatus(AudioObjectAddPropertyListener(deviceId_, &rate, &Impl::devicePropertyListener, this),
                    "AudioObjectAddPropertyListener(sample rate)");
        listeners_.push_back(rate);
        checkStatus(AudioObjectAddPropertyListener(deviceId_, &buffer, &Impl::devicePropertyListener, this),
                    "AudioObjectAddPropertyListener(buffer size)");
        listeners_.push_back(buffer);

        // Not every device exposes overload notifications. This listener is
        // diagnostic only, so failure to install it is not fatal.
        if (AudioObjectAddPropertyListener(deviceId_, &overload, &Impl::devicePropertyListener, this) == noErr) {
            listeners_.push_back(overload);
        }

        if (options_.deviceId == 0U && options_.deviceUid.empty() && options_.followDefaultOutputDevice) {
            defaultOutputAddress_ = propertyAddress(kAudioHardwarePropertyDefaultOutputDevice,
                                                    kAudioObjectPropertyScopeGlobal);
            if (AudioObjectAddPropertyListener(kAudioObjectSystemObject, &defaultOutputAddress_,
                                               &Impl::systemPropertyListener, this) == noErr) {
                defaultListenerInstalled_ = true;
            }
        }
    }

    void removeListeners() noexcept {
        for (const auto& address : listeners_) {
            AudioObjectRemovePropertyListener(deviceId_, &address, &Impl::devicePropertyListener, this);
        }
        listeners_.clear();
        if (defaultListenerInstalled_) {
            AudioObjectRemovePropertyListener(kAudioObjectSystemObject, &defaultOutputAddress_,
                                              &Impl::systemPropertyListener, this);
            defaultListenerInstalled_ = false;
        }
    }

    void zeroOutput(AudioBufferList* ioData, UInt32 frames) noexcept {
        if (ioData == nullptr) return;
        for (UInt32 b = 0U; b < ioData->mNumberBuffers; ++b) {
            if (ioData->mBuffers[b].mData != nullptr) {
                const std::size_t bytes = std::min<std::size_t>(ioData->mBuffers[b].mDataByteSize,
                                                                static_cast<std::size_t>(frames) * sizeof(float));
                std::memset(ioData->mBuffers[b].mData, 0, bytes);
            }
        }
    }

    OSStatus render(AudioUnitRenderActionFlags* ioActionFlags,
                    const AudioTimeStamp* timeStamp,
                    UInt32 frames,
                    AudioBufferList* ioData) noexcept {
        callbackCount_.fetch_add(1U, std::memory_order_relaxed);

        if (frames == 0U) return noErr;
        if (frames > actual_.blockSize || ioData == nullptr || ioData->mNumberBuffers < actual_.outputChannels) {
            needsReopen_.store(true, std::memory_order_release);
            zeroOutput(ioData, frames);
            return noErr;
        }

        if (actual_.inputChannels > 0U) {
            for (std::uint32_t channel = 0U; channel < actual_.inputChannels; ++channel) {
                inputList_->mBuffers[channel].mDataByteSize = frames * sizeof(float);
            }
            const OSStatus inputStatus = AudioUnitRender(audioUnit_, ioActionFlags, timeStamp, 1U, frames, inputList_);
            if (inputStatus != noErr) {
                overloadCount_.fetch_add(1U, std::memory_order_relaxed);
                for (std::uint32_t channel = 0U; channel < actual_.inputChannels; ++channel) {
                    std::fill_n(inputPtrs_[channel], frames, 0.0F);
                }
            }
        }

        for (std::uint32_t channel = 0U; channel < actual_.outputChannels; ++channel) {
            auto& buffer = ioData->mBuffers[channel];
            if (buffer.mData == nullptr || buffer.mNumberChannels != 1U ||
                buffer.mDataByteSize < frames * sizeof(float)) {
                needsReopen_.store(true, std::memory_order_release);
                zeroOutput(ioData, frames);
                return noErr;
            }
            outputPtrs_[channel] = static_cast<float*>(buffer.mData);
        }

        IAudioDeviceCallback* callback = callback_.load(std::memory_order_acquire);
        if (callback == nullptr) {
            zeroOutput(ioData, frames);
            return noErr;
        }

        AudioDeviceTimeInfo timeInfo;
        if (timeStamp != nullptr) {
            if ((timeStamp->mFlags & kAudioTimeStampSampleTimeValid) != 0U) {
                timeInfo.sampleTime = timeStamp->mSampleTime;
                timeInfo.sampleTimeValid = true;
            }
            if ((timeStamp->mFlags & kAudioTimeStampHostTimeValid) != 0U) {
                timeInfo.hostTime = timeStamp->mHostTime;
                timeInfo.hostTimeValid = true;
            }
        }
        callback->updateDeviceTime(timeInfo);
        callback->processAudio(actual_.inputChannels == 0U ? nullptr : inputConstPtrs_.data(),
                               outputPtrs_.data(),
                               actual_.inputChannels,
                               actual_.outputChannels,
                               frames);
        return noErr;
    }

    static OSStatus renderProc(void* refCon,
                               AudioUnitRenderActionFlags* ioActionFlags,
                               const AudioTimeStamp* timeStamp,
                               UInt32 /*busNumber*/,
                               UInt32 frames,
                               AudioBufferList* ioData) noexcept {
        auto* self = static_cast<Impl*>(refCon);
        return self != nullptr ? self->render(ioActionFlags, timeStamp, frames, ioData) : noErr;
    }

    static OSStatus devicePropertyListener(AudioObjectID /*objectId*/,
                                           UInt32 numberAddresses,
                                           const AudioObjectPropertyAddress addresses[],
                                           void* clientData) noexcept {
        auto* self = static_cast<Impl*>(clientData);
        if (self == nullptr) return noErr;

        for (UInt32 i = 0U; i < numberAddresses; ++i) {
            if (addresses[i].mSelector == kAudioDeviceProcessorOverload) {
                self->overloadCount_.fetch_add(1U, std::memory_order_relaxed);
            } else {
                self->needsReopen_.store(true, std::memory_order_release);
            }
        }
        return noErr;
    }

    static OSStatus systemPropertyListener(AudioObjectID /*objectId*/,
                                           UInt32 /*numberAddresses*/,
                                           const AudioObjectPropertyAddress[] /*addresses*/,
                                           void* clientData) noexcept {
        auto* self = static_cast<Impl*>(clientData);
        if (self != nullptr) self->needsReopen_.store(true, std::memory_order_release);
        return noErr;
    }

    AudioDeviceConfig requested_ {};
    AudioDeviceConfig actual_ {};
    CoreAudioDeviceOptions options_ {};
    AudioDeviceID deviceId_ {kAudioObjectUnknown};
    std::string resolvedDeviceUid_;
    AudioUnit audioUnit_ {nullptr};
    bool audioUnitInitialized_ {false};

    std::atomic<IAudioDeviceCallback*> callback_ {nullptr};
    std::atomic<bool> running_ {false};
    std::atomic<bool> needsReopen_ {false};
    std::atomic<std::uint64_t> callbackCount_ {0U};
    std::atomic<std::uint64_t> overloadCount_ {0U};

    std::vector<float> inputStorage_;
    std::vector<float*> inputPtrs_;
    std::vector<const float*> inputConstPtrs_;
    std::vector<float*> outputPtrs_;
    std::vector<std::uint8_t> inputListStorage_;
    AudioBufferList* inputList_ {nullptr};

    std::uint32_t inputLatencyFrames_ {0U};
    std::uint32_t outputLatencyFrames_ {0U};
    std::uint32_t audioUnitLatencyFrames_ {0U};
    std::vector<AudioObjectPropertyAddress> listeners_;
    AudioObjectPropertyAddress defaultOutputAddress_ {};
    bool defaultListenerInstalled_ {false};
};

CoreAudioDevice::CoreAudioDevice(AudioDeviceConfig requestedConfig, CoreAudioDeviceOptions options)
    : impl_(std::make_unique<Impl>(requestedConfig, options)) {}

CoreAudioDevice::~CoreAudioDevice() = default;

const AudioDeviceConfig& CoreAudioDevice::config() const noexcept { return impl_->config(); }
void CoreAudioDevice::start(IAudioDeviceCallback& callback) { impl_->start(callback); }
void CoreAudioDevice::stop() noexcept { impl_->stop(); }
bool CoreAudioDevice::isRunning() const noexcept { return impl_->isRunning(); }
std::uint32_t CoreAudioDevice::deviceId() const noexcept { return impl_->deviceId(); }
const std::string& CoreAudioDevice::deviceUid() const noexcept { return impl_->deviceUid(); }
CoreAudioDeviceStatus CoreAudioDevice::status() const noexcept { return impl_->status(); }
void CoreAudioDevice::clearReopenRequest() noexcept { impl_->clearReopenRequest(); }
void CoreAudioDevice::reopen() { impl_->reopen(); }

std::uint32_t CoreAudioDevice::defaultInputDeviceId() {
    return defaultDevice(kAudioHardwarePropertyDefaultInputDevice);
}

std::uint32_t CoreAudioDevice::defaultOutputDeviceId() {
    return defaultDevice(kAudioHardwarePropertyDefaultOutputDevice);
}

std::vector<CoreAudioDeviceInfo> CoreAudioDevice::devices() {
    UInt32 size = 0U;
    auto address = propertyAddress(kAudioHardwarePropertyDevices, kAudioObjectPropertyScopeGlobal);
    checkStatus(AudioObjectGetPropertyDataSize(kAudioObjectSystemObject, &address, 0, nullptr, &size),
                "AudioObjectGetPropertyDataSize(devices)");

    std::vector<AudioDeviceID> ids(size / sizeof(AudioDeviceID));
    if (!ids.empty()) {
        checkStatus(AudioObjectGetPropertyData(kAudioObjectSystemObject, &address, 0, nullptr, &size, ids.data()),
                    "AudioObjectGetPropertyData(devices)");
    }

    const std::uint32_t defaultInput = defaultInputDeviceId();
    const std::uint32_t defaultOutput = defaultOutputDeviceId();

    std::vector<CoreAudioDeviceInfo> result;
    result.reserve(ids.size());
    for (const AudioDeviceID id : ids) {
        CoreAudioDeviceInfo info;
        info.id = static_cast<std::uint32_t>(id);
        info.name = deviceName(id);
        info.uid = deviceUidString(id);
        info.inputChannels = channelCount(id, kAudioDevicePropertyScopeInput);
        info.outputChannels = channelCount(id, kAudioDevicePropertyScopeOutput);
        info.nominalSampleRate = nominalSampleRate(id);
        info.isDefaultInput = info.id == defaultInput;
        info.isDefaultOutput = info.id == defaultOutput;
        result.push_back(std::move(info));
    }
    return result;
}

} // namespace silveton

#endif // __APPLE__
