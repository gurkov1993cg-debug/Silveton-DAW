#include "silveton/MidiPlaybackScheduler.h"
#include "silveton/Vst3Runtime.h"
#include <thread>

namespace silveton {

MidiPlaybackScheduler::MidiPlaybackScheduler() {
    for (auto& s : states_) s.store(State::Free, std::memory_order_relaxed);
    states_[0].store(State::Live, std::memory_order_relaxed);
}

std::size_t MidiPlaybackScheduler::acquireFree() {
    for (;;) {
        for (std::size_t i=0U;i<states_.size();++i) {
            State expected=State::Free;
            if(states_[i].compare_exchange_strong(expected,State::Writing,std::memory_order_acq_rel,std::memory_order_acquire))return i;
        }
        std::this_thread::yield();
    }
}

std::uint64_t MidiPlaybackScheduler::publish(const Project& project) {
    const std::size_t slot=acquireFree();
    auto& dst=slots_[slot];dst.plans.clear();dst.plans.reserve(project.midiTracks.size());
    for(const auto& track:project.midiTracks){if(track.outputPort<0)continue;PortPlan p;p.port=track.outputPort;p.plan=compileMidiArrangement(track.sequence,track.parts,project.tempoMap);dst.plans.push_back(std::move(p));}
    dst.generation=nextGeneration_++;
    states_[slot].store(State::Pending,std::memory_order_release);
    const int replaced=pending_.exchange(static_cast<int>(slot),std::memory_order_acq_rel);
    if(replaced>=0&&replaced!=static_cast<int>(slot))states_[static_cast<std::size_t>(replaced)].store(State::Free,std::memory_order_release);
    return dst.generation;
}

bool MidiPlaybackScheduler::publicationPending() const noexcept { return pending_.load(std::memory_order_acquire)>=0; }

void MidiPlaybackScheduler::adoptPending() noexcept {
    const int next=pending_.exchange(-1,std::memory_order_acq_rel);if(next<0)return;
    const int old=live_.exchange(next,std::memory_order_acq_rel);
    states_[static_cast<std::size_t>(next)].store(State::Live,std::memory_order_release);
    liveGeneration_.store(slots_[static_cast<std::size_t>(next)].generation,std::memory_order_release);
    if(old>=0&&old!=next)states_[static_cast<std::size_t>(old)].store(State::Free,std::memory_order_release);
}

std::size_t MidiPlaybackScheduler::queueBlock(Vst3RuntimeRack& rack,
                                              MidiInputCapture* liveInput,
                                              std::int64_t blockStartSample,
                                              std::uint32_t frames) noexcept {
    adoptPending();
    std::size_t count=0U;
    const auto& slot=slots_[static_cast<std::size_t>(live_.load(std::memory_order_acquire))];
    for(const auto& p:slot.plans)count+=rack.queueMidiPlanForBlock(p.port,p.plan,blockStartSample,frames);
    if(liveInput!=nullptr)count+=rack.queueLiveMidiForBlock(*liveInput,blockStartSample,frames);
    return count;
}

} // namespace silveton
