#include "silveton/ProjectMediaRelinker.h"
#include "silveton/DiskStream.h"
#include "silveton/WavFile.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <stdexcept>
#include <thread>
#include <vector>

namespace silveton {
namespace {

struct SourceMeta {
    std::uint64_t frames {0U};
    std::uint32_t channels {0U};
    std::uint32_t sampleRate {0U};
};

SourceMeta inspect(const std::string& path) {
    DiskStreamManager manager(1U);
    DiskAudioSource& source = manager.addSource(path, 16384U);
    return {source.frames(), source.channels(), source.sampleRate()};
}

void validateRange(const ProjectAudioClip& clip, const SourceMeta& meta) {
    if (clip.sourceStartSample >= meta.frames || clip.lengthSamples == 0U ||
        clip.lengthSamples > meta.frames - clip.sourceStartSample)
        throw std::runtime_error("replacement media is shorter than referenced clip range");
}

void updateClip(ProjectAudioClip& clip, const std::string& path, const SourceMeta& meta) {
    clip.audioPath = path;
    clip.sourceFrames = meta.frames;
    clip.sourceChannels = meta.channels;
    clip.sourceSampleRate = meta.sampleRate;
}

AudioBuffer readDiskSource(const std::string& path, SourceMeta& meta) {
    constexpr std::uint32_t blockFrames = 8192U;
    DiskStreamManager manager(1U);
    DiskAudioSource& source = manager.addSource(path, 32768U);
    meta = {source.frames(), source.channels(), source.sampleRate()};
    if (meta.channels == 0U || meta.channels > 2U)
        throw std::runtime_error("media conform supports mono/stereo sources");
    if (meta.frames > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
        throw std::length_error("media source is too large for conform buffer");
    AudioBuffer audio(meta.channels, static_cast<std::size_t>(meta.frames));
    manager.start();
    try {
        std::uint64_t frame = 0U;
        while (frame < meta.frames) {
            const std::uint32_t count = static_cast<std::uint32_t>(
                std::min<std::uint64_t>(blockFrames, meta.frames - frame));
            source.request(frame);
            DiskBlockView view;
            bool acquired = false;
            for (unsigned retry = 0U; retry < 5000U; ++retry) {
                if (source.acquire(frame, count, view)) { acquired = true; break; }
                if (source.status().ioError) throw std::runtime_error("media conform disk read failed");
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
            if (!acquired) throw std::runtime_error("media conform disk read timed out");
            for (std::uint32_t i = 0U; i < count; ++i) {
                const std::size_t dst = static_cast<std::size_t>(frame + i);
                const std::size_t src = static_cast<std::size_t>(view.frameOffset + i) * view.channels;
                audio.sample(0U, dst) = view.interleaved[src];
                if (meta.channels > 1U) audio.sample(1U, dst) = view.interleaved[src + 1U];
            }
            source.release(view);
            frame += count;
        }
    } catch (...) {
        manager.stop();
        throw;
    }
    manager.stop();
    return audio;
}

} // namespace

ProjectMediaRelinkResult ProjectMediaRelinker::relinkPath(Project& project,
                                                           const std::string& oldPath,
                                                           const std::string& newPath,
                                                           bool requireProjectSampleRate) {
    if (oldPath.empty() || newPath.empty()) throw std::invalid_argument("media relink path is empty");
    const SourceMeta meta = inspect(newPath);
    if (meta.channels == 0U || meta.channels > 2U)
        throw std::runtime_error("Silveton playback supports mono/stereo media");
    if (requireProjectSampleRate && std::abs(static_cast<double>(meta.sampleRate) - project.sampleRate) > 0.5)
        throw std::runtime_error("replacement media sample rate differs from project; conform it first");

    std::size_t references = 0U;
    // Validation pass: absolutely no project mutation before every target is known safe.
    for (const auto& track : project.tracks) {
        if (track.clips.empty() && track.audioPath == oldPath) ++references;
        for (const auto& clip : track.clips) if (clip.audioPath == oldPath) { validateRange(clip, meta); ++references; }
        for (const auto& lane : track.takeLanes)
            for (const auto& clip : lane.clips) if (clip.audioPath == oldPath) { validateRange(clip, meta); ++references; }
    }
    if (references == 0U) throw std::out_of_range("project has no media reference for relink path");

    for (auto& track : project.tracks) {
        if (track.clips.empty() && track.audioPath == oldPath) track.audioPath = newPath;
        for (auto& clip : track.clips) if (clip.audioPath == oldPath) updateClip(clip, newPath, meta);
        for (auto& lane : track.takeLanes)
            for (auto& clip : lane.clips) if (clip.audioPath == oldPath) updateClip(clip, newPath, meta);
    }
    return {references, meta.frames, meta.channels, meta.sampleRate};
}

ProjectMediaRelinkResult ProjectMediaRelinker::conformAndRelinkPath(Project& project,
                                                                    const std::string& oldPath,
                                                                    const std::string& sourcePath,
                                                                    const std::string& conformedWavPath) {
    if (!(project.sampleRate >= 8000.0 && project.sampleRate <= 768000.0) || !std::isfinite(project.sampleRate))
        throw std::invalid_argument("project sample rate is invalid for conform");
    SourceMeta original;
    AudioBuffer source = readDiskSource(sourcePath, original);
    const double ratio = project.sampleRate / static_cast<double>(original.sampleRate);
    AudioBuffer converted = std::abs(ratio - 1.0) < 1.0e-12
        ? source
        : AudioEditor::resampleSinc(source, ratio);
    const auto rate = static_cast<std::uint32_t>(std::llround(project.sampleRate));
    WavFile::writeFloat32(conformedWavPath, rate, converted);
    return relinkPath(project, oldPath, conformedWavPath, true);
}

} // namespace silveton
