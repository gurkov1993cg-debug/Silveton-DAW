// Silveton Poly — 16-voice subtractive instrument.
// Two PolyBLEP oscillators + sub + noise, zero-delay-feedback (TPT) state
// variable low-pass per voice, ADSR amp/filter envelopes, velocity, pitch
// bend, mod-wheel vibrato, sustain pedal and per-voice glide.
#include "internal/NativePluginFactories.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace silveton::native_detail {
namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr double kTwoPi = 2.0 * kPi;

NativeParameterInfo mk(std::uint32_t id, const char* name, const char* units, double mn, double mx, double def,
                       NativeParamScale scale = NativeParamScale::Linear, std::vector<std::string> choices = {}) {
    NativeParameterInfo p;
    p.id = id; p.name = name; p.units = units; p.minValue = mn; p.maxValue = mx; p.defaultValue = def;
    p.scale = scale; p.choices = std::move(choices);
    return p;
}

const NativePluginInfo& polyInfo() {
    for (const auto& i : nativePluginCatalog()) if (i.classId == "silveton.poly") return i;
    throw std::logic_error("native catalog entry missing");
}

inline double polyBlep(double t, double dt) noexcept {
    if (t < dt) { const double x = t / dt; return x + x - x * x - 1.0; }
    if (t > 1.0 - dt) { const double x = (t - 1.0) / dt; return x * x + x + x + 1.0; }
    return 0.0;
}

struct Envelope {
    enum class Stage : std::uint8_t { Idle, Attack, Decay, Sustain, Release };
    Stage stage {Stage::Idle};
    double level {0.0};
    double attackInc {1.0}, decayCoef {0.0}, sustain {1.0}, releaseCoef {0.0};
    void configure(double attackMs, double decayMs, double sustainPct, double releaseMs, double sr) noexcept {
        attackInc = 1.0 / std::max(1.0, attackMs / 1000.0 * sr);
        // Decay/release times are the time to fall 60 dB.
        decayCoef = std::exp(std::log(0.001) / std::max(1.0, decayMs / 1000.0 * sr));
        releaseCoef = std::exp(std::log(0.001) / std::max(1.0, releaseMs / 1000.0 * sr));
        sustain = std::clamp(sustainPct / 100.0, 0.0, 1.0);
    }
    void gateOn() noexcept { stage = Stage::Attack; }
    void gateOff() noexcept { if (stage != Stage::Idle) stage = Stage::Release; }
    inline double next() noexcept {
        switch (stage) {
            case Stage::Attack:
                level += attackInc;
                if (level >= 1.0) { level = 1.0; stage = Stage::Decay; }
                break;
            case Stage::Decay:
                level = sustain + (level - sustain) * decayCoef;
                if (std::abs(level - sustain) < 1.0e-5) { level = sustain; stage = Stage::Sustain; }
                break;
            case Stage::Sustain: level = sustain; break;
            case Stage::Release:
                level *= releaseCoef;
                if (level < 1.0e-5) { level = 0.0; stage = Stage::Idle; }
                break;
            case Stage::Idle: level = 0.0; break;
        }
        return level;
    }
};

class PolySynth final : public NativePlugin {
public:
    enum : std::uint32_t {
        Osc1Wave, Osc2Wave, Osc2Semi, Osc2Detune, OscMix, SubLevel, Noise,
        Cutoff, Resonance, FilterEnvAmt, KeyTrack,
        AmpA, AmpD, AmpS, AmpR, FltA, FltD, FltS, FltR,
        VibRate, VibDepth, VelSens, Glide, BendRange, Volume, Spread, Count
    };
    static constexpr int kVoices = 16;

    PolySynth() : NativePlugin(polyInfo(), {
        mk(Osc1Wave, "Osc 1 Wave", "", 0, 3, 0, NativeParamScale::Choice, {"Saw", "Square", "Triangle", "Sine"}),
        mk(Osc2Wave, "Osc 2 Wave", "", 0, 3, 1, NativeParamScale::Choice, {"Saw", "Square", "Triangle", "Sine"}),
        mk(Osc2Semi, "Osc 2 Semitones", "st", -24, 24, 0, NativeParamScale::Integer),
        mk(Osc2Detune, "Osc 2 Detune", "ct", -50, 50, 7),
        mk(OscMix, "Osc 2 Level", "%", 0, 100, 50),
        mk(SubLevel, "Sub Level", "%", 0, 100, 0),
        mk(Noise, "Noise", "%", 0, 100, 0),
        mk(Cutoff, "Cutoff", "Hz", 20, 20000, 4000, NativeParamScale::Logarithmic),
        mk(Resonance, "Resonance", "%", 0, 100, 20),
        mk(FilterEnvAmt, "Filter Env", "%", -100, 100, 40),
        mk(KeyTrack, "Key Track", "%", 0, 100, 50),
        mk(AmpA, "Amp Attack", "ms", 0.5, 5000, 5, NativeParamScale::Logarithmic),
        mk(AmpD, "Amp Decay", "ms", 1, 5000, 250, NativeParamScale::Logarithmic),
        mk(AmpS, "Amp Sustain", "%", 0, 100, 80),
        mk(AmpR, "Amp Release", "ms", 1, 10000, 300, NativeParamScale::Logarithmic),
        mk(FltA, "Filter Attack", "ms", 0.5, 5000, 2, NativeParamScale::Logarithmic),
        mk(FltD, "Filter Decay", "ms", 1, 5000, 400, NativeParamScale::Logarithmic),
        mk(FltS, "Filter Sustain", "%", 0, 100, 30),
        mk(FltR, "Filter Release", "ms", 1, 10000, 300, NativeParamScale::Logarithmic),
        mk(VibRate, "Vibrato Rate", "Hz", 0.1, 12, 5, NativeParamScale::Logarithmic),
        mk(VibDepth, "Mod Wheel Vibrato", "ct", 0, 100, 30),
        mk(VelSens, "Velocity", "%", 0, 100, 70),
        mk(Glide, "Glide", "ms", 0, 2000, 0),
        mk(BendRange, "Bend Range", "st", 1, 24, 2, NativeParamScale::Integer),
        mk(Volume, "Volume", "dB", -48, 6, -6),
        mk(Spread, "Stereo Spread", "%", 0, 100, 50),
    }) {}

protected:
    struct Voice {
        bool active {false};
        bool held {false};
        bool sustained {false};
        std::uint8_t note {0};
        double velGain {1.0};
        double semi {60.0};       // current (gliding) pitch in semitones
        double targetSemi {60.0};
        double p1 {0.0}, p2 {0.0}, ps {0.0};
        double tri1 {0.0}, tri2 {0.0};
        double ic1 {0.0}, ic2 {0.0};
        double g {0.1}, k {1.4}, a1 {0.0}, a2 {0.0}, a3 {0.0};
        double panL {0.7071}, panR {0.7071};
        std::uint64_t age {0};
        Envelope amp, flt;
    };

    void onPrepare(double, std::uint32_t) override {}
    void onReset() noexcept override {
        for (auto& v : voices_) v = Voice{};
        bend_ = 0.0; modWheel_ = 0.0; sustainPedal_ = false; lfo_ = 0.0; lastSemi_ = -1.0; counter_ = 0U;
    }
    void onParametersChanged() noexcept override {
        const double sr = sampleRate();
        for (auto& v : voices_) {
            v.amp.configure(p(AmpA), p(AmpD), p(AmpS), p(AmpR), sr);
            v.flt.configure(p(FltA), p(FltD), p(FltS), p(FltR), sr);
        }
    }

    void onMidi(const Vst3MidiEvent& e) noexcept override {
        const std::uint8_t type = e.status & 0xF0U;
        if (type == 0x90U && e.data2 > 0U) noteOn(e.data1 & 0x7FU, e.data2 & 0x7FU);
        else if (type == 0x80U || (type == 0x90U && e.data2 == 0U)) noteOff(e.data1 & 0x7FU);
        else if (type == 0xE0U) bend_ = (static_cast<double>((static_cast<int>(e.data2) << 7) | e.data1) - 8192.0) / 8192.0;
        else if (type == 0xB0U) {
            if (e.data1 == 1U) modWheel_ = e.data2 / 127.0;
            else if (e.data1 == 64U) {
                sustainPedal_ = e.data2 >= 64U;
                if (!sustainPedal_) for (auto& v : voices_) if (v.sustained) { v.sustained = false; release(v); }
            } else if (e.data1 == 123U) { for (auto& v : voices_) if (v.active) release(v); }
            else if (e.data1 == 120U) { for (auto& v : voices_) v.active = false; }
        }
    }

    void release(Voice& v) noexcept { v.held = false; v.amp.gateOff(); v.flt.gateOff(); }

    void noteOn(std::uint8_t note, std::uint8_t velocity) noexcept {
        Voice* chosen = nullptr;
        for (auto& v : voices_) if (v.active && v.note == note && !v.held) { chosen = &v; break; }
        if (!chosen) for (auto& v : voices_) if (!v.active) { chosen = &v; break; }
        if (!chosen) {
            // steal: oldest releasing voice, else the oldest voice
            for (auto& v : voices_) if (!v.held && (!chosen || v.age < chosen->age)) chosen = &v;
            if (!chosen) for (auto& v : voices_) if (!chosen || v.age < chosen->age) chosen = &v;
        }
        Voice& v = *chosen;
        const bool wasActive = v.active;
        v.active = true; v.held = true; v.sustained = false; v.note = note;
        v.age = ++counter_;
        const double sens = p(VelSens) / 100.0;
        v.velGain = (1.0 - sens) + sens * (velocity / 127.0);
        v.targetSemi = note;
        v.semi = (p(Glide) > 0.0 && lastSemi_ >= 0.0) ? lastSemi_ : static_cast<double>(note);
        lastSemi_ = note;
        if (!wasActive) { v.p1 = 0.0; v.p2 = 0.25; v.ps = 0.0; v.tri1 = v.tri2 = 0.0; v.ic1 = v.ic2 = 0.0; v.amp.level = 0.0; v.flt.level = 0.0; }
        const double spread = p(Spread) / 100.0;
        const double pos = std::clamp(((note % 12) / 5.5 - 1.0) * spread, -1.0, 1.0);
        const double angle = (pos + 1.0) * 0.25 * kPi;
        v.panL = std::cos(angle); v.panR = std::sin(angle);
        v.amp.configure(p(AmpA), p(AmpD), p(AmpS), p(AmpR), sampleRate());
        v.flt.configure(p(FltA), p(FltD), p(FltS), p(FltR), sampleRate());
        v.amp.gateOn(); v.flt.gateOn();
    }

    void noteOff(std::uint8_t note) noexcept {
        for (auto& v : voices_) {
            if (!v.active || !v.held || v.note != note) continue;
            if (sustainPedal_) { v.held = false; v.sustained = true; }
            else release(v);
        }
    }

    static double osc(int wave, double t, double dt, double& tri) noexcept {
        switch (wave) {
            case 0: return 2.0 * t - 1.0 - polyBlep(t, dt);
            case 1: {
                double s = t < 0.5 ? 1.0 : -1.0;
                s += polyBlep(t, dt);
                double t2 = t + 0.5; if (t2 >= 1.0) t2 -= 1.0;
                s -= polyBlep(t2, dt);
                return s;
            }
            case 2: {
                double s = t < 0.5 ? 1.0 : -1.0;
                s += polyBlep(t, dt);
                double t2 = t + 0.5; if (t2 >= 1.0) t2 -= 1.0;
                s -= polyBlep(t2, dt);
                tri = tri * 0.9995 + 4.0 * dt * s;
                return tri;
            }
            default: return std::sin(kTwoPi * t);
        }
    }

    void render(const RenderIO& io, const ProcessorContext&) noexcept override {
        const double sr = sampleRate();
        const int w1 = static_cast<int>(p(Osc1Wave)), w2 = static_cast<int>(p(Osc2Wave));
        const double osc2Offset = p(Osc2Semi) + p(Osc2Detune) / 100.0;
        const double mix2 = p(OscMix) / 100.0, sub = p(SubLevel) / 100.0, noise = p(Noise) / 100.0;
        const double oscNorm = 1.0 / (1.0 + mix2 + sub + noise);
        const double res = p(Resonance) / 100.0;
        const double kRes = 2.0 - 1.94 * res;
        const double envAmt = p(FilterEnvAmt) / 100.0 * 6.0;
        const double keyTrack = p(KeyTrack) / 100.0;
        const double cutoff = p(Cutoff);
        const double glideCoef = p(Glide) > 0.0 ? std::exp(-1.0 / (p(Glide) / 1000.0 * sr)) : 0.0;
        const double vibInc = kTwoPi * p(VibRate) / sr;
        const double vibDepth = modWheel_ * p(VibDepth) / 100.0;
        const double bendSemi = bend_ * p(BendRange);
        const double volume = std::pow(10.0, p(Volume) / 20.0);
        const double nyq = 0.45 * sr;

        std::fill_n(io.outL, io.frames, 0.0F);
        std::fill_n(io.outR, io.frames, 0.0F);
        for (std::uint32_t i = 0U; i < io.frames; ++i) {
            lfo_ += vibInc; if (lfo_ > kTwoPi) lfo_ -= kTwoPi;
            const double vib = vibDepth * std::sin(lfo_);
            double sumL = 0.0, sumR = 0.0;
            for (auto& v : voices_) {
                if (!v.active) continue;
                v.semi = v.targetSemi + (v.semi - v.targetSemi) * glideCoef;
                const double pitch = v.semi + bendSemi + vib;
                const double f1 = 440.0 * std::pow(2.0, (pitch - 69.0) / 12.0);
                const double f2 = f1 * std::pow(2.0, osc2Offset / 12.0);
                const double dt1 = std::min(0.45, f1 / sr), dt2 = std::min(0.45, f2 / sr);
                double s = osc(w1, v.p1, dt1, v.tri1);
                if (mix2 > 0.0) s += mix2 * osc(w2, v.p2, dt2, v.tri2);
                if (sub > 0.0) s += sub * (v.ps < 0.5 ? 1.0 : -1.0);
                if (noise > 0.0) {
                    noiseState_ ^= noiseState_ << 13U; noiseState_ ^= noiseState_ >> 7U; noiseState_ ^= noiseState_ << 17U;
                    s += noise * (static_cast<double>(noiseState_ >> 11U) * (2.0 / 9007199254740992.0) - 1.0);
                }
                s *= oscNorm;
                v.p1 += dt1; if (v.p1 >= 1.0) v.p1 -= 1.0;
                v.p2 += dt2; if (v.p2 >= 1.0) v.p2 -= 1.0;
                v.ps += dt1 * 0.5; if (v.ps >= 1.0) v.ps -= 1.0;

                const double fe = v.flt.next();
                if ((i & 15U) == 0U) {
                    const double fc = std::clamp(cutoff * std::pow(2.0, envAmt * fe + keyTrack * (v.semi - 60.0) / 12.0), 20.0, nyq);
                    v.g = std::tan(kPi * fc / sr);
                    v.k = kRes;
                    v.a1 = 1.0 / (1.0 + v.g * (v.g + v.k));
                    v.a2 = v.g * v.a1;
                    v.a3 = v.g * v.a2;
                }
                const double v3 = s - v.ic2;
                const double v1 = v.a1 * v.ic1 + v.a2 * v3;
                const double v2 = v.ic2 + v.a2 * v.ic1 + v.a3 * v3;
                v.ic1 = 2.0 * v1 - v.ic1;
                v.ic2 = 2.0 * v2 - v.ic2;
                const double a = v.amp.next();
                if (v.amp.stage == Envelope::Stage::Idle) { v.active = false; v.ic1 = v.ic2 = 0.0; continue; }
                const double out = v2 * a * v.velGain;
                sumL += out * v.panL;
                sumR += out * v.panR;
            }
            io.outL[i] = static_cast<float>(sumL * volume);
            io.outR[i] = static_cast<float>(sumR * volume);
        }
    }

    std::uint64_t computeTailSamples() const noexcept override {
        return static_cast<std::uint64_t>((plainValue(AmpR) / 1000.0 + 0.05) * sampleRate());
    }

private:
    std::array<Voice, kVoices> voices_ {};
    double bend_ {0.0}, modWheel_ {0.0}, lfo_ {0.0}, lastSemi_ {-1.0};
    bool sustainPedal_ {false};
    std::uint64_t counter_ {0U};
    std::uint64_t noiseState_ {0x9E3779B97F4A7C15ULL};
};

} // namespace

std::unique_ptr<NativePlugin> makePolySynth() { return std::make_unique<PolySynth>(); }

} // namespace silveton::native_detail
