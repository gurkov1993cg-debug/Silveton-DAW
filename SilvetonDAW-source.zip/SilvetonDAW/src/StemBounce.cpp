#include "silveton/StemBounce.h"
#include "silveton/AudioEngine.h"
#include "silveton/DawCore.h"
#include "silveton/ProcessorGraph.h"

#include <array>
#include <set>
#include <stdexcept>
#include <utility>

namespace silveton {
namespace {

void adoptMaskWhileOffline(AudioEngine& engine) {
    if (engine.transport().isPlaying())
        throw std::logic_error("stem export requires stopped transport");
    std::array<float, 1U> left {};
    std::array<float, 1U> right {};
    float* outputs[2] {left.data(), right.data()};
    engine.processAudio(nullptr, outputs, 0U, 2U, 1U);
    if (auto* graph = engine.processorGraph()) graph->reset();
}

class MaskRestore final {
public:
    explicit MaskRestore(AudioEngine& engine) : engine_(engine) {}
    ~MaskRestore() {
        try {
            if (engine_.trackRenderMaskActive()) {
                engine_.clearTrackRenderMask();
                adoptMaskWhileOffline(engine_);
            }
        } catch (...) {
        }
    }
private:
    AudioEngine& engine_;
};

} // namespace

std::vector<TrackStemResult> StemBounce::renderTrackStems(Project& project,
                                                          AudioEngine& engine,
                                                          Vst3RuntimeRack* vst3Rack,
                                                          const OfflineBounceOptions& options,
                                                          const std::vector<TrackStemRequest>& requests) {
    if (engine.transport().isPlaying()) throw std::logic_error("stem export requires stopped transport");
    if (engine.trackRenderMaskActive()) throw std::logic_error("stem export requires clear track render mask");
    if (requests.empty()) return {};

    std::set<std::string> paths;
    for (const auto& request : requests) {
        if (request.path.empty()) throw std::invalid_argument("stem output path is empty");
        if (!paths.insert(request.path).second) throw std::invalid_argument("duplicate stem output path");
        if (request.trackIndices.empty()) throw std::invalid_argument("stem has no source tracks");
        std::set<std::size_t> uniqueTracks;
        for (const auto track : request.trackIndices) {
            if (track >= engine.trackCount()) throw std::out_of_range("stem track index");
            if (!uniqueTracks.insert(track).second) throw std::invalid_argument("duplicate track in stem");
        }
    }

    MaskRestore restore(engine);
    std::vector<TrackStemResult> results;
    results.reserve(requests.size());

    for (const auto& request : requests) {
        engine.setTrackRenderMask(request.trackIndices);
        adoptMaskWhileOffline(engine);

        TrackStemResult result;
        result.path = request.path;
        result.trackIndices = request.trackIndices;
        result.bounce = OfflineBounce::renderFloat32Wav(request.path, project, engine, vst3Rack, options);
        results.push_back(std::move(result));
    }

    engine.clearTrackRenderMask();
    adoptMaskWhileOffline(engine);
    return results;
}

std::vector<BusStemResult> StemBounce::renderBusStems(Project& project,
                                                      AudioEngine& engine,
                                                      Vst3RuntimeRack* vst3Rack,
                                                      const OfflineBounceOptions& options,
                                                      const std::vector<BusStemRequest>& requests) {
    if (engine.transport().isPlaying()) throw std::logic_error("bus stem export requires stopped transport");
    if (engine.trackRenderMaskActive()) throw std::logic_error("bus stem export requires clear track render mask");
    if (engine.graphMonitorNode() >= 0) throw std::logic_error("bus stem export requires clear graph monitor tap");
    if (requests.empty()) return {};
    const ProcessorGraph* graph = engine.processorGraph();
    if (graph == nullptr) throw std::logic_error("bus stem export requires active processor graph");

    std::set<std::string> paths;
    for (const auto& request : requests) {
        if (request.path.empty()) throw std::invalid_argument("bus stem output path is empty");
        if (!paths.insert(request.path).second) throw std::invalid_argument("duplicate bus stem output path");
        if (request.busIndex >= project.buses.size()) throw std::out_of_range("bus stem index");
        const std::size_t node = project.tracks.size() + request.busIndex;
        if (node >= graph->nodeCount()) throw std::out_of_range("bus stem graph node");
    }

    struct TapRestore final {
        AudioEngine& engine;
        ~TapRestore() { engine.clearGraphMonitorNode(); }
    } restore {engine};

    std::vector<BusStemResult> results;
    results.reserve(requests.size());
    for (const auto& request : requests) {
        const std::size_t node = project.tracks.size() + request.busIndex;
        engine.setGraphMonitorNode(static_cast<int>(node));
        BusStemResult result;
        result.path = request.path;
        result.busIndex = request.busIndex;
        result.bounce = OfflineBounce::renderFloat32Wav(request.path, project, engine, vst3Rack, options);
        results.push_back(std::move(result));
    }
    engine.clearGraphMonitorNode();
    return results;
}

} // namespace silveton
