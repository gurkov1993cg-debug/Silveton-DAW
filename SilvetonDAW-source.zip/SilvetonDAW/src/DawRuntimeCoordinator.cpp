#include "silveton/DawRuntimeCoordinator.h"
#include <stdexcept>

namespace silveton {

DawRuntimeCoordinator::DawRuntimeCoordinator(ProjectSession& session,
                                             AudioEngine& engine,
                                             IVst3InstanceFactory& vst3Factory,
                                             std::size_t maxOpenAudioFiles,
                                             std::uint32_t maxCompensationSamples)
    : session_(session),
      engine_(engine),
      rack_(vst3Factory),
      mixer_(session.project(), rack_, engine_, maxCompensationSamples),
      playback_(session.project(), engine_, maxOpenAudioFiles),
      audioCallback_(engine_, rack_, midiScheduler_, midiInput_, clockMapper_) {
    session_.setBeforeSaveCallback([this] { capturePluginState(); });
    // Project undo/redo/load may change media ownership. Never destroy disk
    // sources or plug-in instances from an arbitrary UI callback while the
    // audio device can still reference them. The application shell observes
    // this flag, quiesces the device, then calls rebuildProject().
    session_.setRuntimeRebuildCallback([this] { rebuildRequested_ = true; });
}

void DawRuntimeCoordinator::prepare(const AudioDeviceConfig& config) {
    if (prepared_) throw std::logic_error("DAW runtime already prepared");
    Project& project = session_.project();
    if (project.sampleRate != config.sampleRate) {
        project.sampleRate = config.sampleRate;
        project.tempoMap.setSampleRate(config.sampleRate);
    }
    engine_.setTempoMap(project.tempoMap);
    engine_.setPanDepth(project.panDepth);
    engine_.setMetronomeEnabled(project.metronomeEnabled);
    engine_.setMetronomeGainDb(project.metronomeGainDb, project.metronomeAccentGainDb);
    engine_.prepare(config);
    prepared_ = true;
    (void)rebuildProject();
}

DawRuntimeStatus DawRuntimeCoordinator::rebuildProject(std::uint32_t cacheFrames,
                                                       std::uint32_t primeTimeoutMilliseconds) {
    if (!prepared_) throw std::logic_error("DAW runtime must be prepared before project rebuild");
    if (engine_.transport().isPlaying()) throw std::logic_error("project rebuild requires stopped transport");
    Project& project = session_.project();
    engine_.setMetronomeEnabled(project.metronomeEnabled);
    engine_.setMetronomeGainDb(project.metronomeGainDb, project.metronomeAccentGainDb);

    // Retire any previously published graph before replacing plug-in instances.
    // In normal app operation the CoreAudio callback continuously adopts pending
    // graph publications; service() then reclaims old instances on the control thread.
    rack_.clear();
    status_.media = playback_.rebuild(cacheFrames, primeTimeoutMilliseconds);
    rack_.restore(project);
    status_.midiGeneration = midiScheduler_.publish(project);
    if (!engine_.tempoMapPublicationPending()) status_.tempoGeneration = engine_.publishTempoMap(project.tempoMap);
    else status_.tempoGeneration = engine_.liveTempoMapGeneration();
    status_.graphGeneration = mixer_.publishProjectRouting();
    rebuildRequested_ = false;
    return status_;
}

MixerRuntimeServiceResult DawRuntimeCoordinator::service() {
    if (!prepared_) return {};
    rack_.serviceAutomationGestures(engine_.transport().positionSamples());
    MixerRuntimeServiceResult result = mixer_.serviceVst3Changes();
    (void)engine_.reclaimRetiredVoicePlans();
    (void)mixer_.reclaimRetired();
    return result;
}

void DawRuntimeCoordinator::capturePluginState() {
    rack_.captureStateToProject();
}

} // namespace silveton
