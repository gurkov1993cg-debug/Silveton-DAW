#include "silveton/ProjectSession.h"
#include <cmath>
#include <stdexcept>
#include <utility>

namespace silveton {

Project ProjectSession::makeEmptyProject(double sampleRate) {
    if (!std::isfinite(sampleRate) || sampleRate < 8000.0 || sampleRate > 768000.0)
        throw std::invalid_argument("project sample rate outside supported range");
    Project p;
    p.sampleRate = sampleRate;
    p.tempo = 120.0;
    p.tempoMap.setSampleRate(sampleRate);
    p.tempoMap.setInitialTempo(120.0);
    return p;
}

ProjectSession::ProjectSession(double sampleRate, std::size_t historyCapacity)
    : project_(makeEmptyProject(sampleRate)), history_(project_, historyCapacity) {
    history_.setApplyCallback([this] { dirty_ = true; rebuildRuntime(); });
}

void ProjectSession::rebuildRuntime() {
    if (runtimeRebuild_) runtimeRebuild_();
}

void ProjectSession::newProject(double sampleRate) {
    if (history_.transactionOpen()) history_.cancel();
    project_ = makeEmptyProject(sampleRate);
    projectPath_.clear();
    dirty_ = false;
    history_.clear();
    nextAutosaveAt_ = 0.0;
    lastAutosaveError_.clear();
    rebuildRuntime();
}

ProjectSessionLoadResult ProjectSession::open(const std::string& path) {
    if (path.empty()) throw std::invalid_argument("project path is empty");
    if (history_.transactionOpen()) history_.cancel();
    auto loaded = ProjectRecovery::loadBestAvailable(path);
    project_ = std::move(loaded.project);
    projectPath_ = path;
    dirty_ = loaded.source != ProjectRecoverySource::Primary;
    history_.clear();
    nextAutosaveAt_ = 0.0;
    lastAutosaveError_.clear();
    rebuildRuntime();
    return {loaded.source, loaded.path, dirty_};
}

void ProjectSession::save() {
    if (projectPath_.empty()) throw std::logic_error("project has no save path");
    if (beforeSave_) beforeSave_();
    ProjectRecovery::safeSave(project_, projectPath_);
    dirty_ = false;
    lastAutosaveError_.clear();
}

void ProjectSession::saveAs(const std::string& path) {
    if (path.empty()) throw std::invalid_argument("project path is empty");
    if (beforeSave_) beforeSave_();
    ProjectRecovery::safeSave(project_, path);
    projectPath_ = path;
    dirty_ = false;
    lastAutosaveError_.clear();
}

void ProjectSession::autosave() {
    if (projectPath_.empty()) throw std::logic_error("unnamed project cannot autosave");
    if (beforeSave_) beforeSave_();
    ProjectRecovery::autosave(project_, projectPath_);
    lastAutosaveError_.clear();
}

void ProjectSession::beginEdit(std::string label) { history_.begin(std::move(label)); }

void ProjectSession::commitEdit() {
    history_.commit();
    dirty_ = true;
    rebuildRuntime();
}

void ProjectSession::cancelEdit() { history_.cancel(); }

bool ProjectSession::undo() { return history_.undo(); }
bool ProjectSession::redo() { return history_.redo(); }

void ProjectSession::setAutosaveIntervalSeconds(double seconds) {
    if (!std::isfinite(seconds) || seconds < 0.0) throw std::invalid_argument("invalid autosave interval");
    autosaveIntervalSeconds_ = seconds;
    nextAutosaveAt_ = 0.0;
}

bool ProjectSession::serviceAutosave(double monotonicSeconds) {
    if (!std::isfinite(monotonicSeconds) || monotonicSeconds < 0.0)
        throw std::invalid_argument("invalid monotonic autosave time");
    if (autosaveIntervalSeconds_ <= 0.0 || !dirty_ || projectPath_.empty()) return false;
    if (nextAutosaveAt_ == 0.0) {
        nextAutosaveAt_ = monotonicSeconds + autosaveIntervalSeconds_;
        return false;
    }
    if (monotonicSeconds < nextAutosaveAt_) return false;
    nextAutosaveAt_ = monotonicSeconds + autosaveIntervalSeconds_;
    try {
        autosave();
        return true;
    } catch (const std::exception& e) {
        lastAutosaveError_ = e.what();
        return false;
    }
}

} // namespace silveton
