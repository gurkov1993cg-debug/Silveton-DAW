#pragma once
#include "silveton/NativePlugins.h"
#include <memory>

namespace silveton::native_detail {

std::unique_ptr<NativePlugin> makeContourEq();
std::unique_ptr<NativePlugin> makePressCompressor();
std::unique_ptr<NativePlugin> makeGate();
std::unique_ptr<NativePlugin> makeCeilingLimiter();
std::unique_ptr<NativePlugin> makeEchoDelay();
std::unique_ptr<NativePlugin> makeSpaceReverb();
std::unique_ptr<NativePlugin> makeDriveSaturator();
std::unique_ptr<NativePlugin> makeEnsembleChorus();
std::unique_ptr<NativePlugin> makePolySynth();

} // namespace silveton::native_detail
