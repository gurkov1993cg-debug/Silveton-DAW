#pragma once
#include "silveton/DawCore.h"
#include <istream>
#include <ostream>

namespace silveton {

// V26 project extension block (track/bus/MIDI state, markers, arranger,
// folders, notes). Written between MASTERAUTO and END as:
//   EXT_BEGIN
//   <TAG>\t...
//   EXT_END
// Unknown tags are skipped so newer projects still open in older 0.17.x builds.
void writeProjectExtensions(std::ostream& out, const Project& project);
void readProjectExtensions(std::istream& in, Project& project);

std::string escapeProjectText(const std::string& text);
std::string unescapeProjectText(const std::string& text);

} // namespace silveton
