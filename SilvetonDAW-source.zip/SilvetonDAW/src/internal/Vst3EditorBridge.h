#pragma once
#if defined(__APPLE__)
namespace Steinberg { namespace Vst { class IEditController; } }
namespace silveton::detail {
struct Vst3EditorHandle;
Vst3EditorHandle* openVst3CocoaEditor(Steinberg::Vst::IEditController* controller);
void closeVst3CocoaEditor(Vst3EditorHandle*& handle) noexcept;
bool vst3CocoaEditorIsOpen(const Vst3EditorHandle* handle) noexcept;
}
#endif
