#pragma once
// Small helpers shared by the Tone Editor sources (analysis, editing, rendering). Not part of the public API.
#include "silveton/ToneEdit.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>

namespace silveton::toneinternal {

constexpr double kPi = 3.14159265358979323846264338327950288;

inline double midiFromHz(double hz) noexcept { return 69.0 + 12.0 * std::log2(hz / 440.0); }
inline double hzFromMidi(double midi) noexcept { return 440.0 * std::pow(2.0, (midi - 69.0) / 12.0); }

// Frame i of the analysis is centred on sample i * hop; it covers [i*hop - hop/2, i*hop + hop/2).
inline std::int64_t frameStart(const ToneFrames& f, std::size_t i) noexcept {
    return static_cast<std::int64_t>(i * f.hop) - static_cast<std::int64_t>(f.hop / 2U);
}

// Frames whose centre lies inside [start, end).
inline void framesOfRange(const ToneFrames& f, std::int64_t start, std::int64_t end, std::size_t& first, std::size_t& last) noexcept {
    const auto hop = static_cast<std::int64_t>(f.hop);
    std::int64_t a = (start + hop - 1) / hop;      // first centre >= start
    if (start <= 0) a = 0;
    std::int64_t b = (end + hop - 1) / hop;        // one past the last centre < end
    if (end <= 0) b = 0;
    const auto n = static_cast<std::int64_t>(f.size());
    a = std::clamp<std::int64_t>(a, 0, n);
    b = std::clamp<std::int64_t>(b, a, n);
    first = static_cast<std::size_t>(a);
    last = static_cast<std::size_t>(b);
}

// Heard pitch of a stretch of frames (loudness weighted, the outer parts and outliers left out).
// Returns false when there is no pitch in the stretch.
bool heardPitch(const ToneFrames& f, std::size_t first, std::size_t last, bool allowRaw, double& midiOut, double& levelDbOut);

// Recomputes pitch and level of a block from its frames.
void refreshBlock(ToneBlock& block, const ToneAnalysis& analysis, double fallbackPitch);

} // namespace silveton::toneinternal
