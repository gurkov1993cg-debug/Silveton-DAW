#import "SilvetonViews.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <vector>

using namespace silveton;

// ============================================================== Page bar ==
@implementation SilvetonPageBar {
    NSRect _tabRects[4];
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    sv::line(NSMakePoint(0, b.size.height - 0.5), NSMakePoint(b.size.width, b.size.height - 0.5), sv::hairline());
    // Wordmark: small copper disc + letter-spaced name.
    sv::roundFill(NSMakeRect(14, 13, 18, 18), 9, sv::copper());
    sv::roundFill(NSMakeRect(19, 18, 8, 8), 4, sv::canvas());
    NSDictionary* brand = @{NSFontAttributeName: sv::ui(13, true), NSForegroundColorAttributeName: sv::ink(), NSKernAttributeName: @(3.0)};
    [@"SILVETON" drawAtPoint:NSMakePoint(40, 13) withAttributes:brand];

    NSArray<NSString*>* titles = @[@"ARRANGE", @"MIX", @"EDIT", @"LIBRARY"];
    const CGFloat tabW = 104, tabH = 28;
    const CGFloat total = tabW * 4 + 6 * 3;
    CGFloat x = std::floor((b.size.width - total) * 0.5);
    sv::roundFill(NSMakeRect(x - 5, 7, total + 10, tabH + 2), 3, sv::hex(0x1E1E20));
    for (int i = 0; i < 4; ++i) {
        NSRect r = NSMakeRect(x, 8, tabW, tabH);
        _tabRects[i] = r;
        const bool on = i == self.page;
        if (on) sv::roundFill(r, 7, sv::raisedHi());
        if (on) sv::fill(NSMakeRect(r.origin.x + 30, r.origin.y + tabH - 3, tabW - 60, 2), sv::copper());
        sv::textIn(titles[i], NSMakeRect(r.origin.x, r.origin.y + 7, tabW, 16), sv::ui(10.5, true), on ? sv::ink() : sv::inkDim(), NSTextAlignmentCenter);
        x += tabW + 6;
    }
    NSString* title = self.projectTitle ?: @"Untitled";
    const CGFloat rightX = x + 24;
    sv::textIn(title, NSMakeRect(rightX, 9, b.size.width - rightX - 16, 16), sv::ui(12, true), sv::ink(), NSTextAlignmentRight);
    sv::textIn(self.statusText ?: @"", NSMakeRect(rightX, 26, b.size.width - rightX - 16, 14), sv::ui(10), sv::inkDim(), NSTextAlignmentRight);
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    for (int i = 0; i < 4; ++i)
        if (NSPointInRect(p, _tabRects[i])) { [self.controller showPage:static_cast<SVPage>(i)]; return; }
}
@end

// ================================================================= Meter ==
@implementation SilvetonMeter {
    float _l, _r, _holdL, _holdR;
    double _holdAtL, _holdAtR;
}
- (BOOL)isOpaque { return NO; }
- (void)setLeft:(float)left right:(float)right {
    _l = std::max(0.0F, left); _r = std::max(0.0F, right);
    const double now = [NSDate timeIntervalSinceReferenceDate];
    if (_l >= _holdL || now - _holdAtL > 1.5) { _holdL = _l; _holdAtL = now; }
    if (_r >= _holdR || now - _holdAtR > 1.5) { _holdR = _r; _holdAtR = now; }
    [self setNeedsDisplay:YES];
}
- (void)drawBar:(NSRect)r value:(float)v hold:(float)h {
    sv::roundFill(r, 2, sv::hex(0x0E0D10));
    const double n = sv::meterNorm(v);
    if (n > 0.0) {
        NSRect fillR = r;
        fillR.size.height = r.size.height * n;
        NSGradient* g = [[NSGradient alloc] initWithColorsAndLocations:sv::sage(), 0.0, sv::amber(), 0.78, sv::rec(), 1.0, nil];
        [g drawInRect:r angle:90];
        sv::fill(NSMakeRect(r.origin.x, r.origin.y + fillR.size.height, r.size.width, r.size.height - fillR.size.height), sv::hex(0x0E0D10));
    }
    const double hn = sv::meterNorm(h);
    if (hn > 0.0) sv::fill(NSMakeRect(r.origin.x, r.origin.y + r.size.height * hn - 1, r.size.width, 1.5), h >= 1.0F ? sv::rec() : sv::ink());
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    const CGFloat w = (b.size.width - 2) / 2;
    [self drawBar:NSMakeRect(0, 0, w, b.size.height) value:_l hold:_holdL];
    [self drawBar:NSMakeRect(w + 2, 0, w, b.size.height) value:_r hold:_holdR];
}
@end

// ======================================================= Transport deck ==
namespace {
enum TransportKey { kKeyPrev, kKeyRew, kKeyStop, kKeyPlay, kKeyRec, kKeyFwd, kKeyNext, kKeyLoop, kKeyClick, kKeyMark, kKeyCount };
}
@implementation SilvetonTransportDeck {
    NSRect _keys[kKeyCount];
    NSRect _counterRect, _tempoRect, _meterRect, _signatureRect;
    float _ml, _mr, _hl, _hr;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)tick {
    if (!self.controller || !self.controller.core || !self.controller.core->ready()) return;
    const auto m = self.controller.core->engine().outputMeter();
    _ml = m.leftPeak; _mr = m.rightPeak;
    _hl = std::max(_hl * 0.96F, _ml); _hr = std::max(_hr * 0.96F, _mr);
    [self setNeedsDisplay:YES];
}
- (void)drawKey:(int)k glyph:(NSString*)glyph lit:(bool)lit color:(NSColor*)color wide:(bool)wide {
    const NSRect r = _keys[k];
    sv::roundFill(r, 8, lit ? color : sv::raised());
    sv::roundStroke(r, 8, lit ? color : sv::hairline());
    NSFont* f = wide ? sv::ui(10, true) : sv::ui(15, true);
    const NSSize sz = sv::textSize(glyph, f);
    sv::text(glyph, NSMakePoint(NSMidX(r) - sz.width / 2, NSMidY(r) - sz.height / 2), f, lit ? sv::canvas() : sv::ink());
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    sv::line(NSMakePoint(0, 0.5), NSMakePoint(b.size.width, 0.5), sv::hairline());
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    const Project& p = *c.project;
    const std::int64_t pos = c.playheadSample;
    const bool ready = c.core && c.core->ready();
    const bool playing = ready && c.core->engine().transport().isPlaying();
    const bool cycle = ready && c.core->engine().transport().cycleEnabled();
    const bool recording = c.core && c.core->recording() != nullptr;

    // Counter card
    _counterRect = NSMakeRect(14, 10, 250, 56);
    sv::roundFill(_counterRect, 10, sv::panel());
    sv::roundStroke(_counterRect, 10, sv::hairline());
    sv::text(sv::ns(formatBarsBeats(p.tempoMap, pos)), NSMakePoint(28, 14), sv::mono(24, true), sv::copper());
    const double sr = p.sampleRate > 0 ? p.sampleRate : 48000.0;
    sv::text(sv::ns(formatClock(static_cast<double>(pos) / sr)), NSMakePoint(30, 45), sv::mono(11), sv::inkDim());
    sv::text(@"BAR · BEAT · TICK", NSMakePoint(150, 47), sv::ui(8), sv::inkFaint());

    // Tempo / meter card
    const auto tp = p.tempoMap.positionAtSample(pos);
    _tempoRect = NSMakeRect(274, 10, 92, 56);
    _signatureRect = NSMakeRect(372, 10, 64, 56);
    sv::roundFill(_tempoRect, 10, sv::panel());
    sv::roundFill(_signatureRect, 10, sv::panel());
    sv::textIn([NSString stringWithFormat:@"%.2f", tp.bpm], NSMakeRect(274, 16, 92, 22), sv::mono(17, true), sv::ink(), NSTextAlignmentCenter);
    sv::textIn(@"TEMPO", NSMakeRect(274, 44, 92, 12), sv::ui(8), sv::inkFaint(), NSTextAlignmentCenter);
    sv::textIn([NSString stringWithFormat:@"%u/%u", tp.numerator, tp.denominator], NSMakeRect(372, 16, 64, 22), sv::mono(17, true), sv::ink(), NSTextAlignmentCenter);
    sv::textIn(@"METER", NSMakeRect(372, 44, 64, 12), sv::ui(8), sv::inkFaint(), NSTextAlignmentCenter);

    // Keys
    CGFloat x = std::max<CGFloat>(452, std::floor(b.size.width * 0.5 - 250));
    const CGFloat y = 16, h = 44;
    const CGFloat widths[kKeyCount] = {40, 40, 48, 64, 48, 40, 40, 58, 58, 58};
    for (int k = 0; k < kKeyCount; ++k) {
        if (k == kKeyLoop) x += 14;
        _keys[k] = NSMakeRect(x, y, widths[k], h);
        x += widths[k] + 6;
    }
    [self drawKey:kKeyPrev glyph:@"⇤" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyRew glyph:@"«" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyStop glyph:@"■" lit:!playing color:sv::raisedHi() wide:false];
    [self drawKey:kKeyPlay glyph:@"▶" lit:playing color:sv::sage() wide:false];
    [self drawKey:kKeyRec glyph:@"●" lit:recording color:sv::rec() wide:false];
    [self drawKey:kKeyFwd glyph:@"»" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyNext glyph:@"⇥" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyLoop glyph:@"LOOP" lit:cycle color:sv::copper() wide:true];
    [self drawKey:kKeyClick glyph:@"CLICK" lit:p.metronomeEnabled color:sv::amber() wide:true];
    [self drawKey:kKeyMark glyph:@"+ MARK" lit:false color:sv::copper() wide:true];

    // Cycle range read-out
    if (ready) {
        const auto& t = c.core->engine().transport();
        if (t.cycleEndSample() > t.cycleStartSample()) {
            NSString* range = [NSString stringWithFormat:@"%@ → %@", sv::ns(formatBarsBeats(p.tempoMap, t.cycleStartSample())),
                                                                     sv::ns(formatBarsBeats(p.tempoMap, t.cycleEndSample()))];
            sv::text(range, NSMakePoint(_keys[kKeyLoop].origin.x, 2), sv::mono(9), cycle ? sv::copper() : sv::inkFaint());
        }
    }

    // Master meter (horizontal, real output meter)
    _meterRect = NSMakeRect(b.size.width - 230, 18, 210, 40);
    sv::roundFill(_meterRect, 8, sv::panel());
    sv::text(@"MASTER", NSMakePoint(_meterRect.origin.x + 10, 21), sv::ui(8, true), sv::inkFaint());
    const float vals[2] = {_ml, _mr};
    const float holds[2] = {_hl, _hr};
    for (int ch = 0; ch < 2; ++ch) {
        const NSRect bar = NSMakeRect(_meterRect.origin.x + 10, 34 + ch * 10, 190, 7);
        sv::roundFill(bar, 3, sv::hex(0x0E0D10));
        const double n = sv::meterNorm(vals[ch]);
        if (n > 0) {
            NSGradient* g = [[NSGradient alloc] initWithColorsAndLocations:sv::sage(), 0.0, sv::amber(), 0.78, sv::rec(), 1.0, nil];
            [NSGraphicsContext saveGraphicsState];
            NSRectClip(NSMakeRect(bar.origin.x, bar.origin.y, bar.size.width * n, bar.size.height));
            [g drawInRect:bar angle:0];
            [NSGraphicsContext restoreGraphicsState];
        }
        const double hn = sv::meterNorm(holds[ch]);
        if (hn > 0) sv::fill(NSMakeRect(bar.origin.x + bar.size.width * hn - 1, bar.origin.y, 1.5, bar.size.height), holds[ch] >= 1.0F ? sv::rec() : sv::ink());
    }
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    SilvetonController* c = self.controller;
    if (NSPointInRect(p, _counterRect)) { [c gotoPositionDialog:nil]; return; }
    if (NSPointInRect(p, _tempoRect)) { [c editTempo:nil]; return; }
    if (NSPointInRect(p, _signatureRect)) { [c editSignature:nil]; return; }
    for (int k = 0; k < kKeyCount; ++k) {
        if (!NSPointInRect(p, _keys[k])) continue;
        switch (k) {
            case kKeyPrev: [c previousMarker:nil]; break;
            case kKeyRew: [c rewindBar:nil]; break;
            case kKeyStop: [c stop:nil]; break;
            case kKeyPlay: [c togglePlay:nil]; break;
            case kKeyRec: [c record:nil]; break;
            case kKeyFwd: [c forwardBar:nil]; break;
            case kKeyNext: [c nextMarker:nil]; break;
            case kKeyLoop: [c toggleCycle:nil]; break;
            case kKeyClick: [c toggleMetronome:nil]; break;
            case kKeyMark: [c addMarkerAtPlayhead:nil]; break;
            default: break;
        }
        [self setNeedsDisplay:YES];
        return;
    }
}
@end

// ========================================================= Arrange view ==
namespace {
constexpr CGFloat kHeaderW = 232.0;
constexpr CGFloat kRulerH = 22.0;
constexpr CGFloat kMarkerH = 16.0;
constexpr CGFloat kSectionH = 16.0;
constexpr CGFloat kTop = kRulerH + kMarkerH + kSectionH;
constexpr CGFloat kTrackH = 38.0;
constexpr CGFloat kFolderH = 22.0;

enum class DragMode { None, Ruler, NewSection, MoveClip, TrimLeft, TrimRight, MovePart };

struct Hit {
    long row {-1};
    bool header {false};
    std::uint64_t clip {0U};
    std::uint64_t part {0U};
    bool legacyPart {false};
    int edge {0};   // -1 left, +1 right
    std::int64_t sample {0};
};

CGFloat rowHeight(const ArrangeRow& r) { return r.kind == ArrangeRowKind::Folder ? kFolderH : kTrackH; }

std::uint32_t rowColor(const Project& p, const ArrangeRow& r) {
    switch (r.kind) {
        case ArrangeRowKind::Folder: return r.index < p.folders.size() && p.folders[r.index].color ? p.folders[r.index].color : 0x8A8FB8U;
        case ArrangeRowKind::Audio: return effectiveTrackColor(p, r.index);
        case ArrangeRowKind::Midi: {
            if (r.index < p.midiTracks.size() && p.midiTracks[r.index].color) return p.midiTracks[r.index].color;
            const int inst = instrumentTrackForPort(p, r.index < p.midiTracks.size() ? p.midiTracks[r.index].outputPort : -1);
            return inst >= 0 ? effectiveTrackColor(p, static_cast<std::size_t>(inst)) : silvetonPaletteColor(r.index + 7U);
        }
    }
    return 0x999999U;
}

// Pill hit rects inside a header row starting at y.
NSRect pillRect(const ArrangeRow& r, CGFloat y, int i) {
    if (r.kind == ArrangeRowKind::Folder) return NSMakeRect(kHeaderW - 40 + i * 18, y + 4, 16, 14);
    return NSMakeRect(kHeaderW - 80 + i * 18, y + 5, 16, 14);
}
} // namespace

@implementation SilvetonArrangeView {
    std::vector<ArrangeRow> _rows;
    DragMode _drag;
    std::int64_t _dragAnchor;
    std::int64_t _dragCurrent;
    std::int64_t _grabOffset;
    double _grabOffsetQ;
    std::size_t _dragTrack;
    std::uint64_t _dragId;
    BOOL _gestureOpen;
    BOOL _moved;
    NSPoint _downPoint;
    BOOL _externalDrag;
}
- (instancetype)initWithFrame:(NSRect)frame {
    if ((self = [super initWithFrame:frame])) {
        [self registerForDraggedTypes:@[NSPasteboardTypeFileURL]];
    }
    return self;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (TimelineMapping)mapping {
    TimelineMapping m;
    const Project* p = self.controller.project;
    m.sampleRate = p && p->sampleRate > 0 ? p->sampleRate : 48000.0;
    m.pixelsPerSecond = self.controller.pixelsPerSecond;
    m.originX = kHeaderW;
    m.scrollSeconds = self.scrollSeconds;
    return m;
}

- (CGFloat)contentHeight {
    CGFloat h = 0;
    for (const auto& r : _rows) h += rowHeight(r);
    return h;
}

- (void)ensurePlayheadVisible {
    const auto m = [self mapping];
    const double x = m.xForSample(self.controller.playheadSample);
    const double right = self.bounds.size.width - 40;
    if (x > right) self.scrollSeconds += (x - kHeaderW - (right - kHeaderW) * 0.25) / m.pixelsPerSecond;
    else if (x < kHeaderW) self.scrollSeconds = std::max(0.0, static_cast<double>(self.controller.playheadSample) / m.sampleRate - 1.0);
}

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    const Project& p = *c.project;
    _rows = buildArrangeRows(p);
    const auto map = [self mapping];
    const CGFloat laneW = std::max<CGFloat>(0, b.size.width - kHeaderW);
    const double sr = map.sampleRate;
    self.scrollY = std::max(0.0, std::min(self.scrollY, std::max(0.0, static_cast<double>([self contentHeight] - (b.size.height - kTop) + 40))));

    // 1. lane backgrounds
    CGFloat y = kTop - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const auto& r = _rows[i];
        const CGFloat h = rowHeight(r);
        bool sel = false;
        if (r.kind == ArrangeRowKind::Audio) sel = static_cast<long>(r.index) == c.selectedTrack;
        if (r.kind == ArrangeRowKind::Midi) sel = static_cast<long>(r.index) == c.selectedMidiTrack;
        if (r.kind == ArrangeRowKind::Folder) sel = static_cast<long>(r.index) == c.selectedFolder;
        if (y + h >= kTop && y <= b.size.height)
            sv::fill(NSMakeRect(kHeaderW, y, laneW, h - 1), sel ? sv::laneSel() : (i % 2 ? sv::laneB() : sv::laneA()));
        y += h;
    }

    // 2. grid
    const auto grid = buildGrid(p.tempoMap, map, laneW);
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(kHeaderW, kTop, laneW, b.size.height - kTop));
    for (const auto& g : grid) {
        const CGFloat gx = std::floor(map.xForSample(g.sample)) + 0.5;
        NSColor* col = g.level == 0 ? sv::hex(0x34303A) : (g.level == 1 ? sv::hex(0x26242A) : sv::hex(0x201F24));
        sv::line(NSMakePoint(gx, kTop), NSMakePoint(gx, b.size.height), col);
    }
    // arranger sections tint the lanes lightly
    for (const auto& s : p.arrangerSections) {
        const CGFloat x0 = map.xForSample(s.startSample), x1 = map.xForSample(s.endSample);
        sv::fill(NSMakeRect(x0, kTop, x1 - x0, b.size.height - kTop), sv::hex(s.color, 0.035));
    }

    // 3. clips / parts
    y = kTop - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const auto& r = _rows[i];
        const CGFloat h = rowHeight(r);
        if (y + h < kTop || y > b.size.height || r.kind == ArrangeRowKind::Folder) { y += h; continue; }
        NSColor* base = sv::hex(rowColor(p, r));
        if (r.kind == ArrangeRowKind::Audio && r.index < p.tracks.size()) {
            const auto& t = p.tracks[r.index];
            for (const auto& clip : t.clips) {
                const CGFloat x0 = map.xForSample(clip.timelineStartSample);
                const CGFloat x1 = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples));
                if (x1 < kHeaderW || x0 > b.size.width) continue;
                const NSRect cr = NSMakeRect(x0, y + 2, std::max<CGFloat>(3, x1 - x0), h - 5);
                const bool sel = clip.id == c.selectedClipId && static_cast<long>(r.index) == c.selectedTrack;
                sv::roundFill(cr, 3, [base colorWithAlphaComponent:0.30]);
                sv::roundFill(NSMakeRect(cr.origin.x, cr.origin.y, cr.size.width, 10), 3, base);
                NSString* nm = [[sv::ns(clip.audioPath) lastPathComponent] stringByDeletingPathExtension];
                sv::textIn(nm, NSMakeRect(cr.origin.x + 4, cr.origin.y - 1, cr.size.width - 6, 11), sv::ui(7.5, true), sv::hex(0x111111));
                const std::string& path = clip.audioPath.empty() ? t.audioPath : clip.audioPath;
                c.core->waveformCache().request(path);
                if (auto ov = c.core->waveformCache().find(path))
                    sv::drawWaveform(*ov, clip.sourceStartSample, clip.lengthSamples, NSMakeRect(cr.origin.x + 1, cr.origin.y + 11, cr.size.width - 2, cr.size.height - 12),
                                     [base blendedColorWithFraction:0.55 ofColor:sv::ink()], false);
                // fades
                if (clip.fadeInSamples) {
                    const CGFloat fx = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.fadeInSamples));
                    sv::line(NSMakePoint(cr.origin.x, NSMaxY(cr)), NSMakePoint(fx, cr.origin.y + 10), sv::amber(), 1.2);
                }
                if (clip.fadeOutSamples) {
                    const CGFloat fx = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples - clip.fadeOutSamples));
                    sv::line(NSMakePoint(fx, cr.origin.y + 10), NSMakePoint(NSMaxX(cr), NSMaxY(cr)), sv::amber(), 1.2);
                }
                if (clip.mute) sv::roundFill(cr, 3, sv::rgb(0.05, 0.05, 0.06, 0.6));
                if (sel) sv::roundStroke(cr, 3, sv::ink(), 2.0);
            }
            // live recording take
            if (c.core->recording() && c.core->recordingTrackIndex() == static_cast<long>(r.index)) {
                const auto st = c.core->recording()->status();
                if (st.framesAccepted > 0U) {
                    const CGFloat x0 = map.xForSample(c.core->recordingStartSample());
                    const CGFloat x1 = map.xForSample(c.core->recordingStartSample() + static_cast<std::int64_t>(st.framesAccepted));
                    const NSRect rr = NSMakeRect(x0, y + 2, std::max<CGFloat>(3, x1 - x0), h - 5);
                    sv::roundFill(rr, 5, sv::rgb(0.55, 0.14, 0.12, 0.85));
                    const auto live = c.core->recording()->waveformPreview(0U, st.framesAccepted,
                        static_cast<std::size_t>(std::max<CGFloat>(64, std::min<CGFloat>(4096, rr.size.width))));
                    sv::drawWaveform(live, 0U, live.frames, NSInsetRect(rr, 1, 3), sv::ink(), false);
                    sv::roundStroke(rr, 5, sv::rec(), 1.5);
                }
            }
        } else if (r.kind == ArrangeRowKind::Midi && r.index < p.midiTracks.size()) {
            const auto& mt = p.midiTracks[r.index];
            auto drawPart = [&](const MidiSequence& seq, double startQ, double offsetQ, double lenQ, std::uint64_t id, bool muted) {
                const CGFloat x0 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(startQ));
                const CGFloat x1 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(startQ + lenQ));
                if (x1 < kHeaderW || x0 > b.size.width) return;
                const NSRect pr = NSMakeRect(x0, y + 2, std::max<CGFloat>(3, x1 - x0), h - 5);
                const bool sel = static_cast<long>(r.index) == c.selectedMidiTrack && id == c.selectedPartId;
                sv::roundFill(pr, 3, [base colorWithAlphaComponent:0.26]);
                sv::roundFill(NSMakeRect(pr.origin.x, pr.origin.y, pr.size.width, 10), 3, base);
                int lo = 127, hi = 0;
                for (const auto& n : seq.notes()) { lo = std::min<int>(lo, n.pitch); hi = std::max<int>(hi, n.pitch); }
                if (hi < lo) { lo = 60; hi = 72; }
                const double span = std::max(6, hi - lo + 1);
                [NSGraphicsContext saveGraphicsState];
                NSRectClip(pr);
                for (const auto& n : seq.notes()) {
                    if (n.muted) continue;
                    const double qs = startQ + (n.startQuarterNotes - offsetQ);
                    if (qs + n.durationQuarterNotes < startQ || qs > startQ + lenQ) continue;
                    const CGFloat nx0 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(qs));
                    const CGFloat nx1 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(qs + n.durationQuarterNotes));
                    const CGFloat ny = pr.origin.y + 13 + (pr.size.height - 17) * (1.0 - (n.pitch - lo + 0.5) / span);
                    sv::fill(NSMakeRect(nx0, ny - 1, std::max<CGFloat>(2, nx1 - nx0 - 1), 2), [base blendedColorWithFraction:0.45 ofColor:sv::ink()]);
                }
                [NSGraphicsContext restoreGraphicsState];
                if (muted) sv::roundFill(pr, 3, sv::rgb(0.05, 0.05, 0.06, 0.6));
                if (sel) sv::roundStroke(pr, 3, sv::ink(), 2.0);
            };
            if (mt.parts.empty()) {
                double end = 0;
                for (const auto& n : mt.sequence.notes()) end = std::max(end, n.startQuarterNotes + n.durationQuarterNotes);
                if (end > 0) drawPart(mt.sequence, 0.0, 0.0, std::ceil(end / 4.0) * 4.0, 0U, mt.mute);
            } else {
                for (const auto& part : mt.parts)
                    drawPart(part.sequence, part.timelineStartQuarterNotes, part.sourceOffsetQuarterNotes, part.lengthQuarterNotes, part.id, part.muted || mt.mute);
            }
        }
        y += h;
    }
    [NSGraphicsContext restoreGraphicsState];

    // 4. headers
    sv::fill(NSMakeRect(0, kTop, kHeaderW, b.size.height - kTop), sv::panel());
    y = kTop - self.scrollY;
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(0, kTop, kHeaderW, b.size.height - kTop));
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const auto& r = _rows[i];
        const CGFloat h = rowHeight(r);
        if (y + h < kTop || y > b.size.height) { y += h; continue; }
        const CGFloat indent = r.depth * 12.0;
        NSColor* col = sv::hex(rowColor(p, r));
        bool sel = false;
        sv::line(NSMakePoint(0, y + h - 0.5), NSMakePoint(kHeaderW, y + h - 0.5), sv::hairline());
        if (r.kind == ArrangeRowKind::Folder && r.index < p.folders.size()) {
            const auto& f = p.folders[r.index];
            sel = static_cast<long>(r.index) == c.selectedFolder;
            sv::fill(NSMakeRect(0, y, kHeaderW, h - 1), sel ? sv::hex(0x55555B) : sv::hex(0x45454A));
            sv::fill(NSMakeRect(0, y, 6, h - 1), col);
            sv::text(f.collapsed ? @"▸" : @"▾", NSMakePoint(10 + indent, y + 4), sv::ui(10, true), sv::inkDim());
            sv::textIn(sv::ns(f.name), NSMakeRect(26 + indent, y + 4, kHeaderW - 80 - indent, 14), sv::ui(10, true), sv::ink());
            bool allMute = true, anySolo = false, any = false;
            for (const auto& t : p.tracks) if (FolderTools::isInside(p, t.folder, f.id)) { any = true; allMute &= t.mute; anySolo |= t.solo; }
            sv::pill(pillRect(r, y, 0), @"M", any && allMute, sv::muteTint());
            sv::pill(pillRect(r, y, 1), @"S", anySolo, sv::soloTint());
        } else if (r.kind == ArrangeRowKind::Audio && r.index < p.tracks.size()) {
            const auto& t = p.tracks[r.index];
            sel = static_cast<long>(r.index) == c.selectedTrack;
            sv::fill(NSMakeRect(0, y, kHeaderW, h - 1), sel ? sv::hex(0x4A4038) : sv::hex(0x333336));
            sv::fill(NSMakeRect(0, y, 6, h - 1), col);
            bool instrument = false;
            for (const auto& s2 : t.pluginSlots) if (s2.midiInputPort >= 0) instrument = true;
            sv::textIn([NSString stringWithFormat:@"%lu", (unsigned long)(r.index + 1)], NSMakeRect(9 + indent, y + 12, 18, 12), sv::mono(8), sv::inkFaint(), NSTextAlignmentCenter);
            sv::textIn(sv::ns(t.name.empty() ? std::string("Audio") : t.name), NSMakeRect(30 + indent, y + 5, kHeaderW - 118 - indent, 14), sv::ui(10, true), sv::ink());
            sv::text(instrument ? @"INSTRUMENT" : @"AUDIO", NSMakePoint(30 + indent, y + 19), sv::ui(7, true), sv::inkFaint());
            sv::pill(pillRect(r, y, 0), @"M", t.mute, sv::muteTint());
            sv::pill(pillRect(r, y, 1), @"S", t.solo, sv::soloTint());
            sv::pill(pillRect(r, y, 2), @"●", t.recordArm, sv::rec());
            sv::pill(pillRect(r, y, 3), @"I", t.monitor, sv::amber());
            // mini fader line + level
            const CGFloat fx0 = kHeaderW - 80, fw = 70;
            sv::roundFill(NSMakeRect(fx0, y + 25, fw, 3), 1, sv::hex(0x1A1A1C));
            sv::fill(NSMakeRect(fx0 + fw * faderPositionForDb(t.gainDb) - 2, y + 22, 4, 9), sv::hex(0xD6D6DA));
            if (t.locked) sv::text(@"🔒", NSMakePoint(kHeaderW - 100, y + 4), sv::ui(8), sv::inkDim());
            if (c.core->ready() && r.index < c.core->engine().trackCount()) {
                const auto m = c.core->engine().trackMeter(r.index);
                const double lv = sv::meterNorm(std::max(m.leftPeak, m.rightPeak));
                const NSRect mr = NSMakeRect(kHeaderW - 6, y + 3, 3, h - 7);
                sv::fill(mr, sv::hex(0x141416));
                sv::fill(NSMakeRect(mr.origin.x, NSMaxY(mr) - mr.size.height * lv, 3, mr.size.height * lv), lv > 0.92 ? sv::rec() : (lv > 0.75 ? sv::amber() : sv::sage()));
            }
        } else if (r.kind == ArrangeRowKind::Midi && r.index < p.midiTracks.size()) {
            const auto& m = p.midiTracks[r.index];
            sel = static_cast<long>(r.index) == c.selectedMidiTrack;
            sv::fill(NSMakeRect(0, y, kHeaderW, h - 1), sel ? sv::hex(0x4A4038) : sv::hex(0x333336));
            sv::fill(NSMakeRect(0, y, 6, h - 1), col);
            if (r.drivesInstrument) sv::fill(NSMakeRect(6, y, 2, h - 1), [col colorWithAlphaComponent:0.5]);
            sv::textIn(sv::ns(m.name.empty() ? std::string("MIDI") : m.name), NSMakeRect(30 + indent, y + 5, kHeaderW - 118 - indent, 14), sv::ui(10, true), sv::ink());
            NSString* dest = @"NO OUTPUT";
            const int inst = instrumentTrackForPort(p, m.outputPort);
            if (inst >= 0) dest = [NSString stringWithFormat:@"MIDI → %@", sv::ns(p.tracks[static_cast<std::size_t>(inst)].name).uppercaseString];
            sv::textIn(dest, NSMakeRect(30 + indent, y + 19, kHeaderW - 118 - indent, 11), sv::ui(7, true), sv::inkFaint());
            sv::pill(pillRect(r, y, 0), @"M", m.mute, sv::muteTint());
            sv::pill(pillRect(r, y, 1), @"S", m.solo, sv::soloTint());
            if (m.transpose != 0 || m.velocityShift != 0)
                sv::text([NSString stringWithFormat:@"T%+d V%+d", m.transpose, m.velocityShift], NSMakePoint(kHeaderW - 80, y + 23), sv::mono(7.5), sv::amber());
        }
        y += h;
    }
    [NSGraphicsContext restoreGraphicsState];
    sv::line(NSMakePoint(kHeaderW - 0.5, 0), NSMakePoint(kHeaderW - 0.5, b.size.height), sv::hairline());

    // 5. top lanes: ruler, markers, arranger
    sv::fill(NSMakeRect(0, 0, b.size.width, kTop), sv::panel());
    sv::text(@"RULER", NSMakePoint(14, 6), sv::ui(8, true), sv::inkFaint());
    sv::text(@"MARKERS", NSMakePoint(14, kRulerH + 3), sv::ui(8, true), sv::inkFaint());
    sv::text(@"ARRANGER", NSMakePoint(14, kRulerH + kMarkerH + 4), sv::ui(8, true), sv::inkFaint());
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(kHeaderW, 0, laneW, kTop));
    for (const auto& g : grid) {
        const CGFloat gx = std::floor(map.xForSample(g.sample)) + 0.5;
        const CGFloat top = g.level == 0 ? 10 : (g.level == 1 ? 16 : 20);
        sv::line(NSMakePoint(gx, top), NSMakePoint(gx, kRulerH), g.level == 0 ? sv::inkDim() : sv::inkFaint());
        if (!g.label.empty()) sv::text(sv::ns(g.label), NSMakePoint(gx + 3, 2), sv::mono(9), sv::ink());
    }
    if (c.core->ready()) {
        const auto& tr = c.core->engine().transport();
        if (tr.cycleEndSample() > tr.cycleStartSample()) {
            const CGFloat x0 = map.xForSample(tr.cycleStartSample()), x1 = map.xForSample(tr.cycleEndSample());
            sv::fill(NSMakeRect(x0, 0, x1 - x0, kRulerH), [(tr.cycleEnabled() ? sv::copper() : sv::inkFaint()) colorWithAlphaComponent:0.28]);
            sv::fill(NSMakeRect(x0, kRulerH - 3, x1 - x0, 3), tr.cycleEnabled() ? sv::copper() : sv::inkFaint());
        }
    }
    if (_drag == DragMode::Ruler && _moved) {
        const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
        sv::fill(NSMakeRect(x0, 0, x1 - x0, kRulerH), [sv::copper() colorWithAlphaComponent:0.45]);
    }
    sv::line(NSMakePoint(kHeaderW, kRulerH - 0.5), NSMakePoint(b.size.width, kRulerH - 0.5), sv::hairline());
    for (const auto& m : p.markers) {
        const CGFloat mx = map.xForSample(m.sample);
        NSColor* mc = m.color ? sv::hex(m.color) : sv::copper();
        if (m.cycle) {
            const CGFloat x1 = map.xForSample(m.endSample);
            sv::roundFill(NSMakeRect(mx, kRulerH + 3, x1 - mx, kMarkerH - 6), 3, [mc colorWithAlphaComponent:0.35]);
        }
        NSBezierPath* flag = [NSBezierPath bezierPath];
        [flag moveToPoint:NSMakePoint(mx, kRulerH + 2)];
        [flag lineToPoint:NSMakePoint(mx + 8, kRulerH + 2)];
        [flag lineToPoint:NSMakePoint(mx + 8, kRulerH + 11)];
        [flag lineToPoint:NSMakePoint(mx, kRulerH + 15)];
        [flag closePath];
        [mc setFill];
        [flag fill];
        sv::text(sv::ns(m.name), NSMakePoint(mx + 11, kRulerH + 2), sv::ui(9, true), sv::ink());
    }
    sv::line(NSMakePoint(kHeaderW, kRulerH + kMarkerH - 0.5), NSMakePoint(b.size.width, kRulerH + kMarkerH - 0.5), sv::hairline());
    for (const auto& s : p.arrangerSections) {
        const CGFloat x0 = map.xForSample(s.startSample), x1 = map.xForSample(s.endSample);
        const NSRect sr2 = NSMakeRect(x0 + 1, kRulerH + kMarkerH + 2, std::max<CGFloat>(2, x1 - x0 - 2), kSectionH - 4);
        sv::roundFill(sr2, 4, sv::hex(s.color ? s.color : 0x6A9BC3U, s.id == c.selectedSectionId ? 1.0 : 0.72));
        sv::textIn(sv::ns(s.name), NSMakeRect(sr2.origin.x + 5, sr2.origin.y + 1, sr2.size.width - 8, 13), sv::ui(9, true), sv::canvas());
    }
    if (_drag == DragMode::NewSection && _moved) {
        const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
        sv::roundFill(NSMakeRect(x0, kRulerH + kMarkerH + 2, x1 - x0, kSectionH - 4), 4, [sv::copper() colorWithAlphaComponent:0.5]);
    }
    [NSGraphicsContext restoreGraphicsState];
    sv::line(NSMakePoint(0, kTop - 0.5), NSMakePoint(b.size.width, kTop - 0.5), sv::hairline());

    // 6. playhead
    const CGFloat px = map.xForSample(c.playheadSample);
    if (px >= kHeaderW && px <= b.size.width) {
        sv::line(NSMakePoint(std::floor(px) + 0.5, 0), NSMakePoint(std::floor(px) + 0.5, b.size.height), sv::copper(), 1.5);
        NSBezierPath* head = [NSBezierPath bezierPath];
        [head moveToPoint:NSMakePoint(px - 6, 0)];
        [head lineToPoint:NSMakePoint(px + 6, 0)];
        [head lineToPoint:NSMakePoint(px, 9)];
        [head closePath];
        [sv::copper() setFill];
        [head fill];
    }

    if (_rows.empty()) {
        NSString* t = @"Drop WAV / AIFF files here";
        NSString* s2 = @"or use  Project ▸ Add Instrument Track (⌥⌘I)  ·  Add Audio Track (⌥⌘A)";
        const CGFloat cy = std::max<CGFloat>(kTop + 60, b.size.height * 0.42);
        sv::textIn(t, NSMakeRect(kHeaderW, cy, laneW, 26), sv::ui(20, true), sv::inkDim(), NSTextAlignmentCenter);
        sv::textIn(s2, NSMakeRect(kHeaderW, cy + 32, laneW, 16), sv::ui(11), sv::inkFaint(), NSTextAlignmentCenter);
    }
    if (_externalDrag) sv::roundStroke(NSInsetRect(b, 4, 4), 10, sv::copper(), 3);
}

// ---------------------------------------------------------------- hit test --
- (Hit)hitAt:(NSPoint)pt {
    Hit hit;
    const Project* p = self.controller.project;
    if (!p) return hit;
    const auto map = [self mapping];
    hit.sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    if (pt.y < kTop) return hit;
    CGFloat y = kTop - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const CGFloat h = rowHeight(_rows[i]);
        if (pt.y >= y && pt.y < y + h) {
            hit.row = static_cast<long>(i);
            hit.header = pt.x < kHeaderW;
            if (hit.header) return hit;
            const auto& r = _rows[i];
            if (r.kind == ArrangeRowKind::Audio && r.index < p->tracks.size()) {
                for (const auto& clip : p->tracks[r.index].clips) {
                    const CGFloat x0 = map.xForSample(clip.timelineStartSample);
                    const CGFloat x1 = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples));
                    if (pt.x >= x0 && pt.x <= x1) {
                        hit.clip = clip.id;
                        if (pt.x - x0 < 6 && x1 - x0 > 18) hit.edge = -1;
                        else if (x1 - pt.x < 6 && x1 - x0 > 18) hit.edge = 1;
                    }
                }
            } else if (r.kind == ArrangeRowKind::Midi && r.index < p->midiTracks.size()) {
                const auto& mt = p->midiTracks[r.index];
                if (mt.parts.empty()) {
                    double end = 0;
                    for (const auto& n : mt.sequence.notes()) end = std::max(end, n.startQuarterNotes + n.durationQuarterNotes);
                    const CGFloat x1 = map.xForSample(p->tempoMap.sampleAtQuarterNotes(std::ceil(end / 4.0) * 4.0));
                    if (end > 0 && pt.x >= map.xForSample(0) && pt.x <= x1) hit.legacyPart = true;
                } else {
                    for (const auto& part : mt.parts) {
                        const CGFloat x0 = map.xForSample(p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes));
                        const CGFloat x1 = map.xForSample(p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes + part.lengthQuarterNotes));
                        if (pt.x >= x0 && pt.x <= x1) hit.part = part.id;
                    }
                }
            }
            return hit;
        }
        y += h;
    }
    return hit;
}

- (void)mouseDown:(NSEvent*)event {
    [self.window makeFirstResponder:self];
    SilvetonController* c = self.controller;
    Project* p = c.project;
    if (!p) return;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    _downPoint = pt;
    _moved = NO;
    _drag = DragMode::None;
    const auto map = [self mapping];
    const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    const bool twice = event.clickCount >= 2;
    if (pt.y < kTop) {
        if (pt.x < kHeaderW) return;
        if (pt.y < kRulerH) {
            _drag = DragMode::Ruler;
            _dragAnchor = _dragCurrent = [c snapSample:sample];
        } else if (pt.y < kRulerH + kMarkerH) {
            for (const auto& m : p->markers) {
                const CGFloat mx = map.xForSample(m.sample);
                if (pt.x >= mx - 3 && pt.x <= mx + 10) { [c markerClicked:m.id doubleClick:twice]; [self setNeedsDisplay:YES]; return; }
            }
            if (twice) [c addMarkerAtSample:[c snapSample:sample]];
        } else {
            for (const auto& s : p->arrangerSections) {
                if (sample >= s.startSample && sample < s.endSample) { [c sectionClicked:s.id doubleClick:twice]; [self setNeedsDisplay:YES]; return; }
            }
            _drag = DragMode::NewSection;
            _dragAnchor = _dragCurrent = [c snapSample:sample];
        }
        [self setNeedsDisplay:YES];
        return;
    }
    const Hit hit = [self hitAt:pt];
    if (hit.row < 0) { c.selectedClipId = 0; [c refreshAll]; return; }
    const ArrangeRow row = _rows[static_cast<std::size_t>(hit.row)];
    // compute row top
    CGFloat y = kTop - self.scrollY;
    for (long i = 0; i < hit.row; ++i) y += rowHeight(_rows[static_cast<std::size_t>(i)]);
    if (hit.header) {
        if (row.kind == ArrangeRowKind::Folder) {
            if (pt.x < 26 + row.depth * 12.0) { [c toggleFolderCollapse:row.index]; return; }
            if (NSPointInRect(pt, pillRect(row, y, 0))) { [c toggleMute:row]; return; }
            if (NSPointInRect(pt, pillRect(row, y, 1))) { [c toggleSolo:row]; return; }
        } else {
            if (NSPointInRect(pt, pillRect(row, y, 0))) { [c toggleMute:row]; return; }
            if (NSPointInRect(pt, pillRect(row, y, 1))) { [c toggleSolo:row]; return; }
            if (row.kind == ArrangeRowKind::Audio && NSPointInRect(pt, pillRect(row, y, 2))) { [c toggleArm:row]; return; }
            if (row.kind == ArrangeRowKind::Audio && NSPointInRect(pt, pillRect(row, y, 3))) { [c toggleMonitor:row]; return; }
        }
        [c selectRow:row];
        if (twice) [c renameRow:row];
        return;
    }
    [c selectRow:row];
    if (row.kind == ArrangeRowKind::Audio) {
        c.selectedClipId = hit.clip;
        if (hit.clip) {
            _dragTrack = row.index;
            _dragId = hit.clip;
            for (const auto& clip : p->tracks[row.index].clips) if (clip.id == hit.clip) _grabOffset = sample - clip.timelineStartSample;
            _drag = hit.edge < 0 ? DragMode::TrimLeft : (hit.edge > 0 ? DragMode::TrimRight : DragMode::MoveClip);
            if (twice) { [c showPage:SVPage::Edit]; _drag = DragMode::None; }
        } else {
            [c seekToSample:sample];
        }
    } else if (row.kind == ArrangeRowKind::Midi) {
        c.selectedPartId = hit.part;
        if (hit.part) {
            _dragTrack = row.index;
            _dragId = hit.part;
            const double q = p->tempoMap.quarterNotesAtSample(sample);
            for (const auto& part : p->midiTracks[row.index].parts) if (part.id == hit.part) _grabOffsetQ = q - part.timelineStartQuarterNotes;
            _drag = DragMode::MovePart;
            if (twice) { _drag = DragMode::None; [c openEditor:nil]; }
        } else if (hit.legacyPart) {
            if (twice) [c openEditor:nil];
        } else if (twice) {
            [c createPartForMidiTrack:row.index atSample:[c snapSample:sample]];
        } else {
            [c seekToSample:sample];
        }
    }
    [c refreshAll];
}

- (void)mouseDragged:(NSEvent*)event {
    SilvetonController* c = self.controller;
    Project* p = c.project;
    if (!p || _drag == DragMode::None) return;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (!_moved && std::hypot(pt.x - _downPoint.x, pt.y - _downPoint.y) < 3.0) return;
    _moved = YES;
    const auto map = [self mapping];
    const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    switch (_drag) {
        case DragMode::Ruler:
        case DragMode::NewSection:
            _dragCurrent = [c snapSample:sample];
            break;
        case DragMode::MoveClip:
            if (!_gestureOpen) { [c beginGesture:@"Move Clip"]; _gestureOpen = YES; }
            [c dragClip:_dragId track:_dragTrack toSample:std::max<std::int64_t>(0, sample - _grabOffset)];
            break;
        case DragMode::TrimLeft:
        case DragMode::TrimRight:
            if (!_gestureOpen) { [c beginGesture:@"Trim Clip"]; _gestureOpen = YES; }
            [c dragClipEdge:_dragId track:_dragTrack leftEdge:(_drag == DragMode::TrimLeft) toSample:sample];
            break;
        case DragMode::MovePart: {
            if (!_gestureOpen) { [c beginGesture:@"Move MIDI Part"]; _gestureOpen = YES; }
            const double q = p->tempoMap.quarterNotesAtSample([c snapSample:sample]) - _grabOffsetQ;
            const double div = std::max<std::uint32_t>(1U, c.gridDivisionsPerQuarter);
            [c dragPart:_dragId midiTrack:_dragTrack toQuarter:std::max(0.0, c.snapEnabled ? std::round(q * div) / div : q)];
            break;
        }
        default: break;
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    SilvetonController* c = self.controller;
    const auto map = [self mapping];
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (_drag == DragMode::Ruler) {
        if (_moved && _dragCurrent != _dragAnchor) [c setCycleStart:std::min(_dragAnchor, _dragCurrent) end:std::max(_dragAnchor, _dragCurrent)];
        else [c seekToSample:std::max<std::int64_t>(0, map.sampleForX(pt.x))];
    } else if (_drag == DragMode::NewSection && _moved && _dragCurrent != _dragAnchor) {
        [c createSectionFrom:std::min(_dragAnchor, _dragCurrent) to:std::max(_dragAnchor, _dragCurrent)];
    }
    if (_gestureOpen) { [c endGesture]; _gestureOpen = NO; }
    _drag = DragMode::None;
    [c refreshAll];
}

- (NSMenu*)menuForEvent:(NSEvent*)event {
    SilvetonController* c = self.controller;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    const auto map = [self mapping];
    const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    if (pt.y < kTop && pt.x >= kHeaderW && c.project) {
        if (pt.y >= kRulerH && pt.y < kRulerH + kMarkerH) {
            for (const auto& m : c.project->markers) {
                const CGFloat mx = map.xForSample(m.sample);
                if (pt.x >= mx - 3 && pt.x <= mx + 10) return [c contextMenuForMarker:m.id];
            }
        } else if (pt.y >= kRulerH + kMarkerH) {
            for (const auto& s : c.project->arrangerSections)
                if (sample >= s.startSample && sample < s.endSample) return [c contextMenuForSection:s.id];
        }
        return nil;
    }
    const Hit hit = [self hitAt:pt];
    ArrangeRow row;
    bool haveRow = hit.row >= 0;
    if (haveRow) {
        row = _rows[static_cast<std::size_t>(hit.row)];
        [c selectRow:row];
        if (row.kind == ArrangeRowKind::Audio) c.selectedClipId = hit.clip;
        if (row.kind == ArrangeRowKind::Midi) c.selectedPartId = hit.part;
    } else {
        row.kind = ArrangeRowKind::Audio;
        row.index = static_cast<std::size_t>(-1);
    }
    [c seekToSample:sample];
    return [c contextMenuForRow:row clip:hit.clip part:hit.part atSample:sample];
}

- (void)scrollWheel:(NSEvent*)event {
    const NSEventModifierFlags mods = event.modifierFlags & NSEventModifierFlagDeviceIndependentFlagsMask;
    SilvetonController* c = self.controller;
    if ((mods & NSEventModifierFlagOption) || (mods & NSEventModifierFlagCommand)) {
        const double dy = event.scrollingDeltaY;
        if (std::abs(dy) > 0.001) {
            const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
            const auto before = [self mapping];
            const std::int64_t anchor = before.sampleForX(pt.x);
            [c setPixelsPerSecond:c.pixelsPerSecond * std::pow(1.08, dy / 4.0)];
            const double pps = c.pixelsPerSecond;
            self.scrollSeconds = std::max(0.0, static_cast<double>(anchor) / before.sampleRate - (pt.x - kHeaderW) / pps);
        }
    } else {
        double dx = event.scrollingDeltaX, dy = event.scrollingDeltaY;
        if (!event.hasPreciseScrollingDeltas) { dx *= 12; dy *= 12; }
        if (mods & NSEventModifierFlagShift) { dx = dy; dy = 0; }
        self.scrollSeconds = std::max(0.0, self.scrollSeconds - dx / std::max(1.0, c.pixelsPerSecond));
        self.scrollY = std::max(0.0, self.scrollY - dy);
    }
    [self setNeedsDisplay:YES];
}
- (void)magnifyWithEvent:(NSEvent*)event {
    [self.controller setPixelsPerSecond:self.controller.pixelsPerSecond * (1.0 + event.magnification)];
    [self setNeedsDisplay:YES];
}

// External file drops
- (NSArray<NSURL*>*)audioURLs:(id<NSDraggingInfo>)sender {
    NSArray* urls = [sender.draggingPasteboard readObjectsForClasses:@[[NSURL class]] options:@{NSPasteboardURLReadingFileURLsOnlyKey: @YES}];
    NSMutableArray<NSURL*>* out = [NSMutableArray array];
    for (NSURL* u in urls) {
        NSString* ext = u.pathExtension.lowercaseString;
        if ([ext isEqualToString:@"wav"] || [ext isEqualToString:@"aif"] || [ext isEqualToString:@"aiff"]) [out addObject:u];
    }
    return out;
}
- (NSDragOperation)draggingEntered:(id<NSDraggingInfo>)sender {
    _externalDrag = [self audioURLs:sender].count > 0;
    [self setNeedsDisplay:YES];
    return _externalDrag ? NSDragOperationCopy : NSDragOperationNone;
}
- (NSDragOperation)draggingUpdated:(id<NSDraggingInfo>)sender { return [self audioURLs:sender].count > 0 ? NSDragOperationCopy : NSDragOperationNone; }
- (void)draggingExited:(id<NSDraggingInfo>)sender { (void)sender; _externalDrag = NO; [self setNeedsDisplay:YES]; }
- (BOOL)performDragOperation:(id<NSDraggingInfo>)sender {
    NSArray<NSURL*>* urls = [self audioURLs:sender];
    _externalDrag = NO;
    [self setNeedsDisplay:YES];
    if (urls.count == 0) return NO;
    const NSPoint pt = [self convertPoint:sender.draggingLocation fromView:nil];
    const std::int64_t sample = pt.x > kHeaderW ? [self.controller snapSample:std::max<std::int64_t>(0, [self mapping].sampleForX(pt.x))]
                                                : self.controller.playheadSample;
    [self.controller importAudioURLs:urls atSample:sample];
    return YES;
}
@end
