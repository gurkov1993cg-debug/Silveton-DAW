#import "SilvetonViews.h"
#include "SilvetonMeterDraw.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <vector>

using namespace silveton;

// ============================================================= Side bar ==
namespace {
constexpr int kNavKeyCount = 4;          // PROJECT, MIX, LIBRARY, SETUP (SETUP opens Audio System Setup)
constexpr CGFloat kWoodW = 72.0;         // the wood itself; the bar view is 2 px wider for the edge lines
}
@implementation SilvetonSideBar {
    NSRect _navRects[kNavKeyCount];
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
// Walnut: a warm left-to-right gradient with wavy grain lines (fixed seed, so it always looks the same).
- (void)drawWood:(NSRect)wood {
    NSGradient* grad = [[NSGradient alloc] initWithColorsAndLocations:
        sv::hex(0x4E301C), 0.0, sv::hex(0x764A2A), 0.35, sv::hex(0x603A22), 0.7, sv::hex(0x462A18), 1.0, nil];
    [grad drawInRect:wood angle:0.0];
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(wood);
    std::uint32_t seed = 7U;
    auto next = [&seed]() { seed = seed * 1664525U + 1013904223U; return static_cast<double>(seed) / 4294967296.0; };
    for (int k = 0; k < 70; ++k) {
        const double x0 = next() * wood.size.width;
        const double amp = 2.0 + next() * 6.0;
        const double period = 120.0 + next() * 260.0;
        const double phase = next() * 6.28;
        const bool dark = next() > 0.5;
        const double alpha = (dark ? 28.0 + next() * 30.0 : 18.0 + next() * 20.0) / 255.0;
        const double width = 0.6 + next() * 1.6;
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = static_cast<CGFloat>(width);
        bool first = true;
        for (double y = -8.0; y <= wood.size.height + 8.0; y += 8.0) {
            const NSPoint pt = NSMakePoint(static_cast<CGFloat>(x0 + amp * std::sin(phase + y / period * 6.28)), static_cast<CGFloat>(y));
            if (first) { [path moveToPoint:pt]; first = false; } else [path lineToPoint:pt];
        }
        [(dark ? sv::rgb(20.0 / 255.0, 10.0 / 255.0, 4.0 / 255.0, alpha) : sv::rgb(220.0 / 255.0, 170.0 / 255.0, 110.0 / 255.0, alpha)) setStroke];
        [path stroke];
    }
    [NSGraphicsContext restoreGraphicsState];
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    const NSRect wood = NSMakeRect(0, 0, kWoodW, b.size.height);
    [self drawWood:wood];
    sv::fill(NSMakeRect(kWoodW, 0, 1.5, b.size.height), sv::hex(0x0A0806));
    sv::fill(NSMakeRect(kWoodW + 1.5, 0, 0.5, b.size.height), sv::hex(0x787C86));

    // Wordmark: letter-spaced gold name, written downwards.
    NSDictionary* brand = @{NSFontAttributeName: sv::ui(12, true), NSForegroundColorAttributeName: sv::gold(), NSKernAttributeName: @(3.0)};
    NSString* name = @"SILVETON";
    const NSSize nameSize = [name sizeWithAttributes:brand];
    [NSGraphicsContext saveGraphicsState];
    NSAffineTransform* turn = [NSAffineTransform transform];
    [turn translateXBy:kWoodW * 0.5 yBy:14.0];
    [turn rotateByDegrees:90.0];
    [turn concat];
    [name drawAtPoint:NSMakePoint(0, -nameSize.height * 0.5) withAttributes:brand];
    [NSGraphicsContext restoreGraphicsState];

    // The editor has no key of its own: it opens under the tracks (double-click a clip) or on a full page (FULL PAGE).
    NSArray<NSString*>* titles = @[@"PROJECT", @"MIX", @"LIBRARY", @"SETUP"];
    for (int i = 0; i < kNavKeyCount; ++i) {
        const NSRect r = NSMakeRect(5.0, 118.0 + 58.0 * i, kWoodW - 10.0, 46.0);
        _navRects[i] = r;
        const bool on = i < 3 && i == self.page;
        sv::keyCap(r, 11.0, on, sv::gold());
        sv::textIn(titles[static_cast<NSUInteger>(i)], NSMakeRect(r.origin.x, r.origin.y + (r.size.height - 2.0) * 0.5 - 7.0, r.size.width, 15.0),
                   sv::ui(10, true), on ? sv::gold() : sv::inkDim(), NSTextAlignmentCenter);
    }
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    for (int i = 0; i < kNavKeyCount; ++i) {
        if (!NSPointInRect(p, _navRects[i])) continue;
        if (i == 0) [self.controller showPage:SVPage::Arrange];
        else if (i == 1) [self.controller showPage:SVPage::Mix];
        else if (i == 2) [self.controller showPage:SVPage::Library];
        else [self.controller audioSetup:nil];
        return;
    }
}
@end

// ============================================================== Page bar ==
// Status bar along the bottom edge: message on the left, project and sample rate on the right.
@implementation SilvetonPageBar
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::rail(b);
    NSMutableString* right = [NSMutableString stringWithString:self.projectTitle ?: @"Untitled"];
    if (self.controller.project) {
        const double rate = self.controller.project->sampleRate;
        if (rate > 0.0) [right appendFormat:@"   ·   %@ kHz", std::abs(rate / 1000.0 - std::round(rate / 1000.0)) < 0.001 ? [NSString stringWithFormat:@"%.0f", rate / 1000.0] : [NSString stringWithFormat:@"%.1f", rate / 1000.0]];
        if (self.controller.core && self.controller.core->ready()) {   // how much of the time for one block the processing takes
            const double load = static_cast<double>(self.controller.core->runtime().engineCallback().dspLoad());
            [right appendFormat:@"   ·   DSP %.0f %%", std::min(load, 9.99) * 100.0];
        }
    }
    const CGFloat rightW = std::min<CGFloat>(420.0, std::ceil(sv::textSize(right, sv::mono(10)).width) + 8.0);
    sv::textIn(right, NSMakeRect(b.size.width - rightW - 14.0, 5, rightW, 14), sv::mono(10), sv::inkFaint(), NSTextAlignmentRight);
    NSString* msg = self.statusText.length ? self.statusText : @"Ready";
    sv::textIn(msg, NSMakeRect(14, 5, std::max<CGFloat>(40.0, b.size.width - rightW - 44.0), 14), sv::mono(10), sv::lcdValue());
}
@end

// ======================================================= Transport deck ==
namespace {
enum TransportKey { kKeyPrev, kKeyRew, kKeyStop, kKeyPlay, kKeyRec, kKeyFwd, kKeyNext, kKeyLoop, kKeyClick, kKeyCount };
constexpr CGFloat kMasterBarLength = 190.0;   // the master meter bars in the transport deck

// Small drawn symbols for the transport keys (flipped view).
void drawSymbol(int key, NSPoint c, NSColor* color) {
    [color setFill];
    [color setStroke];
    NSBezierPath* p = [NSBezierPath bezierPath];
    auto tri = [&](CGFloat x, CGFloat w, bool right) {
        if (right) { [p moveToPoint:NSMakePoint(x, c.y - 6.5)]; [p lineToPoint:NSMakePoint(x + w, c.y)]; [p lineToPoint:NSMakePoint(x, c.y + 6.5)]; }
        else { [p moveToPoint:NSMakePoint(x, c.y - 6.5)]; [p lineToPoint:NSMakePoint(x - w, c.y)]; [p lineToPoint:NSMakePoint(x, c.y + 6.5)]; }
        [p closePath];
    };
    switch (key) {
        case kKeyPlay: tri(c.x - 5, 12, true); [p fill]; break;
        case kKeyStop: sv::roundFill(NSMakeRect(c.x - 5.5, c.y - 5.5, 11, 11), 2, color); break;
        case kKeyRec: [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x - 6, c.y - 6, 12, 12)] fill]; break;
        case kKeyRew: tri(c.x + 1, 8, false); tri(c.x + 9, 8, false); [p fill]; break;
        case kKeyFwd: tri(c.x - 9, 8, true); tri(c.x - 1, 8, true); [p fill]; break;
        case kKeyPrev: sv::fill(NSMakeRect(c.x - 8, c.y - 6.5, 2.5, 13), color); tri(c.x + 7, 10, false); [p fill]; break;
        case kKeyNext: sv::fill(NSMakeRect(c.x + 5.5, c.y - 6.5, 2.5, 13), color); tri(c.x - 7, 10, true); [p fill]; break;
        default: break;
    }
}
}
@implementation SilvetonTransportDeck {
    NSRect _keys[kKeyCount];
    NSRect _counterRect, _tempoRect, _meterRect, _signatureRect;
    silveton::StereoMeterDisplay _meter;
    std::uint32_t _meterSig;
    std::int64_t _lastPos;
    BOOL _lastPlaying;
    BOOL _forceNext;
    int _lastDsp;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)tick {
    SilvetonController* c = self.controller;
    if (!c || !c.core || !c.core->ready()) return;
    // The master meter comes from the shared meter bank (ballistics already applied).
    _meter = [c masterMeterDisplay];
    const std::uint32_t sig = sv::meter::signature(_meter, kMasterBarLength, true) ^
        (static_cast<std::uint32_t>(std::lround(std::max(-99.0F, _meter.maxDb()) * 10.0F) + 1000) * 40503U);
    const bool meterMoved = sig != _meterSig;
    // Repaint only what changed: the whole deck when the counter/keys changed,
    // otherwise just the small master-meter card.
    const std::int64_t pos = c.playheadSample;
    const bool playing = c.core->engine().transport().isPlaying();
    const int dsp = static_cast<int>(std::lround(std::min(9.99F, c.core->runtime().engineCallback().dspLoad()) * 50.0F));   // steps of 2 %
    const bool deckChanged = pos != _lastPos || playing != _lastPlaying || _forceNext || dsp != _lastDsp;
    _lastDsp = dsp;
    _meterSig = sig; _lastPos = pos; _lastPlaying = playing; _forceNext = NO;
    if (deckChanged) [self setNeedsDisplay:YES];
    else if (meterMoved) {
        if (NSIsEmptyRect(_meterRect)) [self setNeedsDisplay:YES];
        else [self setNeedsDisplayInRect:_meterRect];
    }
}
- (void)drawKey:(int)k glyph:(NSString*)glyph lit:(bool)lit color:(NSColor*)color wide:(bool)wide {
    const NSRect r = _keys[k];
    sv::keyCap(r, 7.0, lit, color);
    const NSPoint mid = NSMakePoint(NSMidX(r), r.origin.y + (r.size.height - 2.0) * 0.5);
    NSColor* ink = lit ? color : sv::inkDim();
    if (wide) {
        NSFont* f = sv::ui(10, true);
        const NSSize sz = sv::textSize(glyph, f);
        sv::text(glyph, NSMakePoint(mid.x - sz.width / 2, mid.y - sz.height / 2), f, ink);
    } else {
        drawSymbol(k, mid, lit ? color : sv::inkDim());
    }
}
// Master level card: dark display, segmented bars on the fader scale, peak read-out, clip lamp.
- (void)drawMasterMeter:(NSRect)b {
    _meterRect = NSMakeRect(b.size.width - 230, 10, 210, 58);
    const CGFloat mx = _meterRect.origin.x;
    sv::lcd(_meterRect, 8.0);
    sv::text(@"MASTER", NSMakePoint(mx + 10, 14), sv::ui(10, true), sv::lcdDim());
    const float maxDb = _meter.maxDb();
    NSString* readout = maxDb <= -99.0F ? @"-∞ dB" : [NSString stringWithFormat:@"%+.1f dB", maxDb];
    sv::textIn(readout, NSMakeRect(mx + 80, 14, 104, 13), sv::mono(10, true), maxDb > 0.0F ? sv::rec() : sv::lcdValue(), NSTextAlignmentRight);
    sv::meter::drawClipLamp(NSMakeRect(mx + 190, 16, 10, 6), _meter.clip());
    for (int ch = 0; ch < 2; ++ch) {
        const silveton::MeterChannelDisplay& m = ch == 0 ? _meter.left : _meter.right;
        sv::meter::drawBar(NSMakeRect(mx + 10, 31 + ch * 10, kMasterBarLength, 8), false, m.levelDb, m.holdDb, m.clip, true);
    }
    // dB scale under the bars (same positions as the fader scale)
    for (double db : {-40.0, -24.0, -12.0, -6.0, 0.0, 6.0}) {
        const CGFloat tx = std::round(mx + 10 + sv::meter::position(db) * kMasterBarLength);
        NSColor* tone = db == 0.0 ? sv::lcdValue() : sv::lcdDim();
        sv::line(NSMakePoint(tx + 0.5, 50), NSMakePoint(tx + 0.5, 53), tone);
        sv::textIn(sv::meter::dbLabel(db), NSMakeRect(tx - 14, 52, 28, 13), sv::mono(10), tone, NSTextAlignmentCenter);
    }
}
- (void)drawRect:(NSRect)dirty {
    const NSRect b = self.bounds;
    sv::rail(b);
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    // The timer invalidates only the master card while everything else is still.
    if (!NSIsEmptyRect(_meterRect) && NSContainsRect(_meterRect, dirty)) { [self drawMasterMeter:b]; return; }
    const Project& p = *c.project;
    const std::int64_t pos = c.playheadSample;
    const bool ready = c.core && c.core->ready();
    const bool playing = ready && c.core->engine().transport().isPlaying();
    const bool cycle = ready && c.core->engine().transport().cycleEnabled();
    const bool recording = c.core && c.core->recording() != nullptr;
    const CGFloat top = 10, lcdH = 58;

    // Position display: bars · beats · ticks big, clock small
    const NSRect pos0 = NSMakeRect(14, top, 224, lcdH);
    _counterRect = pos0;
    sv::lcd(pos0, 8.0);
    sv::text(@"POSITION", NSMakePoint(pos0.origin.x + 10, top + 5), sv::ui(10, true), sv::lcdDim());
    const double sr = p.sampleRate > 0 ? p.sampleRate : 48000.0;
    sv::textIn(sv::ns(formatClock(static_cast<double>(pos) / sr)), NSMakeRect(pos0.origin.x + 100, top + 5, pos0.size.width - 110, 13), sv::mono(11), sv::lcdValue(), NSTextAlignmentRight);
    sv::text(sv::ns(formatBarsBeats(p.tempoMap, pos)), NSMakePoint(pos0.origin.x + 10, top + 21), sv::mono(24, true), sv::copper());

    // Tempo display: tempo big, signature small (its own click area)
    const auto tp = p.tempoMap.positionAtSample(pos);
    const NSRect tempo0 = NSMakeRect(NSMaxX(pos0) + 8, top, 104, lcdH);
    _tempoRect = tempo0;
    _signatureRect = NSMakeRect(NSMaxX(tempo0) - 54, top, 54, 24);
    sv::lcd(tempo0, 8.0);
    sv::text(@"TEMPO", NSMakePoint(tempo0.origin.x + 10, top + 5), sv::ui(10, true), sv::lcdDim());
    sv::textIn([NSString stringWithFormat:@"%u/%u", tp.numerator, tp.denominator], NSMakeRect(NSMaxX(tempo0) - 52, top + 5, 44, 13), sv::mono(11), sv::lcdValue(), NSTextAlignmentRight);
    sv::text([NSString stringWithFormat:@"%.2f", tp.bpm], NSMakePoint(tempo0.origin.x + 10, top + 25), sv::mono(21, true), sv::copper());

    // Keys: marker back, bar back, stop, play, record, bar forward, marker forward | cycle, click
    CGFloat x = NSMaxX(tempo0) + 16;
    const CGFloat y = 17, h = 42;
    const CGFloat widths[kKeyCount] = {34, 34, 38, 50, 38, 34, 34, 56, 56};
    for (int k = 0; k < kKeyCount; ++k) {
        if (k == kKeyLoop) x += 12;
        _keys[k] = NSMakeRect(x, y, widths[k], h);
        x += widths[k] + (k == kKeyNext ? 0 : 5);
    }
    [self drawKey:kKeyPrev glyph:@"" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyRew glyph:@"" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyStop glyph:@"" lit:!playing color:sv::inkDim() wide:false];
    [self drawKey:kKeyPlay glyph:@"" lit:playing color:sv::copper() wide:false];
    [self drawKey:kKeyRec glyph:@"" lit:recording color:sv::rec() wide:false];
    [self drawKey:kKeyFwd glyph:@"" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyNext glyph:@"" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyLoop glyph:@"CYCLE" lit:cycle color:sv::copper() wide:true];
    [self drawKey:kKeyClick glyph:@"CLICK" lit:p.metronomeEnabled color:sv::copper() wide:true];

    // Cycle range, as far as the window is wide enough (the project name is in the title bar and the status line)
    CGFloat spare = (b.size.width - 244) - (x + 14);
    CGFloat lx = x + 14;
    if (spare >= 168) {
        const NSRect loc = NSMakeRect(lx, top, 160, lcdH);
        sv::lcd(loc, 8.0);
        sv::text(@"LOCATORS", NSMakePoint(loc.origin.x + 10, top + 5), sv::ui(10, true), sv::lcdDim());
        NSString* l = @"L  —", *r = @"R  —";
        if (ready) {
            const auto& t = c.core->engine().transport();
            if (t.cycleEndSample() > t.cycleStartSample()) {
                l = [NSString stringWithFormat:@"L  %@", sv::ns(formatBarsBeats(p.tempoMap, t.cycleStartSample()))];
                r = [NSString stringWithFormat:@"R  %@", sv::ns(formatBarsBeats(p.tempoMap, t.cycleEndSample()))];
            }
        }
        sv::text(l, NSMakePoint(loc.origin.x + 10, top + 23), sv::mono(11), cycle ? sv::copper() : sv::lcdValue());
        sv::text(r, NSMakePoint(loc.origin.x + 10, top + 38), sv::mono(11), cycle ? sv::copper() : sv::lcdValue());
        lx = NSMaxX(loc) + 8;
        spare -= 168;
    }
    (void)lx;

    [self drawMasterMeter:b];
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    SilvetonController* c = self.controller;
    if (NSPointInRect(p, _counterRect)) { [c gotoPositionDialog:nil]; return; }
    if (NSPointInRect(p, _signatureRect)) { [c editSignature:nil]; return; }
    if (NSPointInRect(p, _tempoRect)) { [c editTempo:nil]; return; }
    if (NSPointInRect(p, _meterRect)) {   // click: clear the clip lamp and the peak read-out
        SVStrip master;
        master.kind = SVStripKind::Master;
        [c resetMetersForStrip:master all:(event.modifierFlags & NSEventModifierFlagOption) != 0];
        return;
    }
    for (int k = 0; k < kKeyCount; ++k) {
        if (!NSPointInRect(p, _keys[k])) continue;
        switch (k) {
            case kKeyPrev: [c previousMarker:nil]; break;
            case kKeyRew: [c rewindBar:nil]; break;
            case kKeyStop: [c stop:nil]; break;
            case kKeyPlay: [c togglePlay:nil]; break;
            case kKeyRec: [c record:nil]; break;
            case kKeyFwd: [c forwardBar:nil]; break;
            case kKeyNext: [c nextMarker:nil]; break;
            case kKeyLoop: [c toggleCycle:nil]; break;
            case kKeyClick: [c toggleMetronome:nil]; break;
            default: break;
        }
        [self setNeedsDisplay:YES];
        return;
    }
}
@end

// ========================================================= Arrange view ==
namespace {
constexpr CGFloat kHeaderW = 264.0;
constexpr CGFloat kRulerH = 26.0;
constexpr CGFloat kMarkerH = 20.0;
constexpr CGFloat kSectionH = 20.0;
constexpr CGFloat kTop = kRulerH + kMarkerH + kSectionH;
constexpr CGFloat kTrackH = 48.0;
constexpr CGFloat kFolderH = 28.0;
constexpr CGFloat kMinTrackH = 32.0;
constexpr CGFloat kMaxTrackH = 640.0;
constexpr CGFloat kEdgeGrabH = 5.0;   // how close to the bottom edge of a header the mouse must be to resize it
constexpr CGFloat kPillW = 20.0, kPillH = 18.0, kPillStep = 22.0;

enum class DragMode { None, Ruler, NewSection, MoveClip, TrimLeft, TrimRight, MovePart, ResizeRow };

struct Hit {
    long row {-1};
    bool header {false};
    std::uint64_t clip {0U};
    std::uint64_t part {0U};
    bool legacyPart {false};
    int edge {0};   // -1 left, +1 right
    std::int64_t sample {0};
};

// Heights the user chose for single tracks (drag the bottom edge of a header, or View > Track Height).
std::map<std::uint64_t, CGFloat>& chosenHeights() {
    static std::map<std::uint64_t, CGFloat> heights;
    return heights;
}
std::uint64_t rowKey(const ArrangeRow& r) { return (static_cast<std::uint64_t>(r.kind) << 56) | static_cast<std::uint64_t>(r.index); }
CGFloat rowHeight(const ArrangeRow& r) {
    if (r.kind == ArrangeRowKind::Folder) return kFolderH;
    const auto it = chosenHeights().find(rowKey(r));
    return it == chosenHeights().end() ? kTrackH : it->second;
}

std::uint32_t rowColor(const Project& p, const ArrangeRow& r) {
    switch (r.kind) {
        case ArrangeRowKind::Folder: return r.index < p.folders.size() && p.folders[r.index].color ? p.folders[r.index].color : 0x8A8FB8U;
        case ArrangeRowKind::Audio: return effectiveTrackColor(p, r.index);
        case ArrangeRowKind::Midi: {
            if (r.index < p.midiTracks.size() && p.midiTracks[r.index].color) return p.midiTracks[r.index].color;
            const int inst = instrumentTrackForPort(p, r.index < p.midiTracks.size() ? p.midiTracks[r.index].outputPort : -1);
            return inst >= 0 ? effectiveTrackColor(p, static_cast<std::size_t>(inst)) : silvetonPaletteColor(r.index + 7U);
        }
    }
    return 0x999999U;
}

// Pill hit rects inside a header row starting at y.
NSRect pillRect(const ArrangeRow& r, CGFloat y, int i) {
    if (r.kind == ArrangeRowKind::Folder) return NSMakeRect(kHeaderW - 54 + i * kPillStep, y + 5, kPillW, kPillH);
    return NSMakeRect(kHeaderW - 98 + i * kPillStep, y + 7, kPillW, kPillH);
}
} // namespace

@implementation SilvetonArrangeView {
    std::vector<ArrangeRow> _rows;
    DragMode _drag;
    std::int64_t _dragAnchor;
    std::int64_t _dragCurrent;
    std::int64_t _grabOffset;
    double _grabOffsetQ;
    std::size_t _dragTrack;
    std::uint64_t _dragId;
    BOOL _gestureOpen;
    BOOL _moved;
    NSPoint _downPoint;
    BOOL _externalDrag;
    CGFloat _lastPlayheadX;
    std::uint32_t _lastMeterSignature;
    NSTrackingArea* _tracking;
    std::uint64_t _resizeKey;
    CGFloat _resizeStartH;
}
- (instancetype)initWithFrame:(NSRect)frame {
    if ((self = [super initWithFrame:frame])) {
        [self registerForDraggedTypes:@[NSPasteboardTypeFileURL]];
    }
    return self;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (TimelineMapping)mapping {
    TimelineMapping m;
    const Project* p = self.controller.project;
    m.sampleRate = p && p->sampleRate > 0 ? p->sampleRate : 48000.0;
    m.pixelsPerSecond = self.controller.pixelsPerSecond;
    m.originX = kHeaderW;
    m.scrollSeconds = self.scrollSeconds;
    return m;
}

- (CGFloat)contentHeight {
    CGFloat h = 0;
    for (const auto& r : _rows) h += rowHeight(r);
    return h;
}

- (BOOL)ensurePlayheadVisible {
    const auto m = [self mapping];
    const double x = m.xForSample(self.controller.playheadSample);
    const double right = self.bounds.size.width - 40;
    if (x > right) { self.scrollSeconds += (x - kHeaderW - (right - kHeaderW) * 0.25) / m.pixelsPerSecond; return YES; }
    if (x < kHeaderW) { self.scrollSeconds = std::max(0.0, static_cast<double>(self.controller.playheadSample) / m.sampleRate - 1.0); return YES; }
    return NO;
}

// Called by the UI timer. Instead of repainting the whole canvas 20 times a
// second, only the thin stripe around the playhead and the level-meter column
// are invalidated (and only when they actually changed).
- (void)tickAnimation {
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    const NSRect b = self.bounds;
    const auto m = [self mapping];
    const CGFloat px = m.xForSample(c.playheadSample);
    if (std::abs(px - _lastPlayheadX) >= 0.5) {
        const CGFloat lo = std::min(px, _lastPlayheadX) - 8.0, hi = std::max(px, _lastPlayheadX) + 8.0;
        [self setNeedsDisplayInRect:NSIntersectionRect(NSMakeRect(lo, 0, hi - lo, b.size.height), b)];
        _lastPlayheadX = px;
    }
    const std::uint32_t sig = [c meterSignature];
    if (sig != _lastMeterSignature) {
        _lastMeterSignature = sig;
        [self setNeedsDisplayInRect:NSMakeRect(kHeaderW - 10, kTop, 10, std::max<CGFloat>(0, b.size.height - kTop))];
    }
}

- (void)drawRect:(NSRect)dirty {
    // Paint each invalid rectangle on its own (a thin playhead stripe and the
    // meter column are far apart; their bounding box would be most of the view).
    const NSRect* rects = nullptr;
    NSInteger count = 0;
    [self getRectsBeingDrawn:&rects count:&count];
    if (count <= 0 || count > 6 || !rects) { [self paintRect:dirty]; return; }
    for (NSInteger i = 0; i < count; ++i) {
        [NSGraphicsContext saveGraphicsState];
        NSRectClip(rects[i]);
        [self paintRect:rects[i]];
        [NSGraphicsContext restoreGraphicsState];
    }
}

- (void)paintRect:(NSRect)dirty {
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    const Project& p = *c.project;
    _rows = buildArrangeRows(p);
    const auto map = [self mapping];
    const CGFloat laneW = std::max<CGFloat>(0, b.size.width - kHeaderW);
    const double sr = map.sampleRate;
    self.scrollY = std::max(0.0, std::min(self.scrollY, std::max(0.0, static_cast<double>([self contentHeight] - (b.size.height - kTop) + 40))));

    // 1. lane backgrounds
    CGFloat y = kTop - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const auto& r = _rows[i];
        const CGFloat h = rowHeight(r);
        bool sel = false;
        if (r.kind == ArrangeRowKind::Audio) sel = static_cast<long>(r.index) == c.selectedTrack;
        if (r.kind == ArrangeRowKind::Midi) sel = static_cast<long>(r.index) == c.selectedMidiTrack;
        if (r.kind == ArrangeRowKind::Folder) sel = static_cast<long>(r.index) == c.selectedFolder;
        if (y + h >= kTop && y <= b.size.height)
            sv::fill(NSMakeRect(kHeaderW, y, laneW, h - 1), sel ? sv::laneSel() : (i % 2 ? sv::laneB() : sv::laneA()));
        y += h;
    }

    // 2. grid
    const auto grid = buildGrid(p.tempoMap, map, laneW);
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(kHeaderW, kTop, laneW, b.size.height - kTop));
    for (const auto& g : grid) {
        const CGFloat gx = std::floor(map.xForSample(g.sample)) + 0.5;
        if (gx < dirty.origin.x - 1 || gx > NSMaxX(dirty) + 1) continue;
        NSColor* col = g.level == 0 ? sv::hex(0x30333B) : (g.level == 1 ? sv::hex(0x24272D) : sv::hex(0x1C1D22));
        sv::line(NSMakePoint(gx, kTop), NSMakePoint(gx, b.size.height), col);
    }
    // arranger sections tint the lanes lightly
    for (const auto& s : p.arrangerSections) {
        const CGFloat x0 = map.xForSample(s.startSample), x1 = map.xForSample(s.endSample);
        sv::fill(NSMakeRect(x0, kTop, x1 - x0, b.size.height - kTop), sv::hex(s.color, 0.035));
    }

    // 3. clips / parts
    y = kTop - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const auto& r = _rows[i];
        const CGFloat h = rowHeight(r);
        if (y + h < kTop || y > b.size.height || r.kind == ArrangeRowKind::Folder) { y += h; continue; }
        NSColor* base = sv::hex(rowColor(p, r));
        NSColor* tone = [base blendedColorWithFraction:0.32 ofColor:sv::hex(0x9AA0AC)];   // the track colour, calmed down
        if (r.kind == ArrangeRowKind::Audio && r.index < p.tracks.size()) {
            const auto& t = p.tracks[r.index];
            for (const auto& clip : t.clips) {
                const CGFloat x0 = map.xForSample(clip.timelineStartSample);
                const CGFloat x1 = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples));
                if (x1 < kHeaderW || x0 > b.size.width) continue;
                const NSRect cr = NSMakeRect(x0, y + 2, std::max<CGFloat>(3, x1 - x0), h - 5);
                if (!NSIntersectsRect(cr, dirty)) continue;
                const bool sel = clip.id == c.selectedClipId && static_cast<long>(r.index) == c.selectedTrack;
                // Body in the track's colour (dark), a lighter title bar, the outline in the colour itself.
                sv::roundFill(cr, 6, [tone blendedColorWithFraction:(sel ? 0.5 : 0.62) ofColor:[NSColor blackColor]]);
                [NSGraphicsContext saveGraphicsState];
                [[NSBezierPath bezierPathWithRoundedRect:cr xRadius:6 yRadius:6] addClip];
                sv::fill(NSMakeRect(cr.origin.x, cr.origin.y, cr.size.width, 15), [tone blendedColorWithFraction:0.38 ofColor:[NSColor blackColor]]);
                [NSGraphicsContext restoreGraphicsState];
                sv::roundStroke(cr, 6, [tone blendedColorWithFraction:0.15 ofColor:[NSColor blackColor]], 1.0);
                NSString* nm = [[sv::ns(clip.audioPath) lastPathComponent] stringByDeletingPathExtension];
                sv::textIn(nm, NSMakeRect(cr.origin.x + 5, cr.origin.y + 1, cr.size.width - 8, 14), sv::ui(10, true), sv::hex(0xF2F2F0));
                const std::string& path = clip.audioPath.empty() ? t.audioPath : clip.audioPath;
                c.core->waveformCache().request(path);
                if (auto ov = c.core->waveformCache().find(path))
                    sv::drawWaveform(*ov, clip.sourceStartSample, clip.lengthSamples, NSMakeRect(cr.origin.x + 1, cr.origin.y + 16, cr.size.width - 2, cr.size.height - 17),
                                     [tone blendedColorWithFraction:0.3 ofColor:[NSColor whiteColor]], false, dirty.origin.x, NSMaxX(dirty), p.sampleRate);
                // fades
                if (clip.fadeInSamples) {
                    const CGFloat fx = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.fadeInSamples));
                    sv::line(NSMakePoint(cr.origin.x, NSMaxY(cr)), NSMakePoint(fx, cr.origin.y + 15), sv::amber(), 1.2);
                }
                if (clip.fadeOutSamples) {
                    const CGFloat fx = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples - clip.fadeOutSamples));
                    sv::line(NSMakePoint(fx, cr.origin.y + 15), NSMakePoint(NSMaxX(cr), NSMaxY(cr)), sv::amber(), 1.2);
                }
                if (clip.mute) sv::roundFill(cr, 6, sv::rgb(0.05, 0.05, 0.06, 0.6));
                if (sel) sv::roundStroke(cr, 6, sv::ink(), 2.0);
            }
            // live recording take
            if (c.core->recording() && c.core->recordingTrackIndex() == static_cast<long>(r.index)) {
                const auto st = c.core->recording()->status();
                if (st.framesAccepted > 0U) {
                    const CGFloat x0 = map.xForSample(c.core->recordingStartSample());
                    const CGFloat x1 = map.xForSample(c.core->recordingStartSample() + static_cast<std::int64_t>(st.framesAccepted));
                    const NSRect rr = NSMakeRect(x0, y + 2, std::max<CGFloat>(3, x1 - x0), h - 5);
                    sv::roundFill(rr, 5, sv::rgb(0.55, 0.14, 0.12, 0.85));
                    const auto live = c.core->recording()->waveformPreview(0U, st.framesAccepted,
                        static_cast<std::size_t>(std::max<CGFloat>(64, std::min<CGFloat>(4096, rr.size.width))));
                    sv::drawWaveform(live, 0U, live.frames, NSInsetRect(rr, 1, 3), sv::ink(), false);
                    sv::roundStroke(rr, 5, sv::rec(), 1.5);
                }
            }
        } else if (r.kind == ArrangeRowKind::Midi && r.index < p.midiTracks.size()) {
            const auto& mt = p.midiTracks[r.index];
            auto drawPart = [&](const MidiSequence& seq, double startQ, double offsetQ, double lenQ, std::uint64_t id, bool muted) {
                const CGFloat x0 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(startQ));
                const CGFloat x1 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(startQ + lenQ));
                if (x1 < kHeaderW || x0 > b.size.width) return;
                const NSRect pr = NSMakeRect(x0, y + 2, std::max<CGFloat>(3, x1 - x0), h - 5);
                if (!NSIntersectsRect(pr, dirty)) return;
                const bool sel = static_cast<long>(r.index) == c.selectedMidiTrack && id == c.selectedPartId;
                sv::roundFill(pr, 6, [tone blendedColorWithFraction:(sel ? 0.5 : 0.62) ofColor:[NSColor blackColor]]);
                [NSGraphicsContext saveGraphicsState];
                [[NSBezierPath bezierPathWithRoundedRect:pr xRadius:6 yRadius:6] addClip];
                sv::fill(NSMakeRect(pr.origin.x, pr.origin.y, pr.size.width, 15), [tone blendedColorWithFraction:0.38 ofColor:[NSColor blackColor]]);
                [NSGraphicsContext restoreGraphicsState];
                int lo = 127, hi = 0;
                for (const auto& n : seq.notes()) { lo = std::min<int>(lo, n.pitch); hi = std::max<int>(hi, n.pitch); }
                if (hi < lo) { lo = 60; hi = 72; }
                const double span = std::max(6, hi - lo + 1);
                [NSGraphicsContext saveGraphicsState];
                NSRectClip(pr);
                for (const auto& n : seq.notes()) {
                    if (n.muted) continue;
                    const double qs = startQ + (n.startQuarterNotes - offsetQ);
                    if (qs + n.durationQuarterNotes < startQ || qs > startQ + lenQ) continue;
                    const CGFloat nx0 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(qs));
                    const CGFloat nx1 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(qs + n.durationQuarterNotes));
                    const CGFloat ny = pr.origin.y + 18 + (pr.size.height - 22) * (1.0 - (n.pitch - lo + 0.5) / span);
                    sv::fill(NSMakeRect(nx0, ny - 1, std::max<CGFloat>(2, nx1 - nx0 - 1), 2), [tone blendedColorWithFraction:0.2 ofColor:sv::ink()]);
                }
                [NSGraphicsContext restoreGraphicsState];
                if (muted) sv::roundFill(pr, 6, sv::rgb(0.05, 0.05, 0.06, 0.6));
                if (sel) sv::roundStroke(pr, 6, sv::ink(), 2.0);
            };
            if (mt.parts.empty()) {
                double end = 0;
                for (const auto& n : mt.sequence.notes()) end = std::max(end, n.startQuarterNotes + n.durationQuarterNotes);
                if (end > 0) drawPart(mt.sequence, 0.0, 0.0, std::ceil(end / 4.0) * 4.0, 0U, mt.mute);
            } else {
                for (const auto& part : mt.parts)
                    drawPart(part.sequence, part.timelineStartQuarterNotes, part.sourceOffsetQuarterNotes, part.lengthQuarterNotes, part.id, part.muted || mt.mute);
            }
        }
        y += h;
    }
    [NSGraphicsContext restoreGraphicsState];

    // 4. headers
    sv::fill(NSMakeRect(0, kTop, kHeaderW, b.size.height - kTop), sv::hex(0x16181C));   // the console surface behind the channel plates
    y = kTop - self.scrollY;
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(0, kTop, kHeaderW, b.size.height - kTop));
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const auto& r = _rows[i];
        const CGFloat h = rowHeight(r);
        if (y + h < kTop || y > b.size.height || !NSIntersectsRect(NSMakeRect(0, y, kHeaderW, h), dirty)) { y += h; continue; }
        const CGFloat indent = r.depth * 12.0;
        NSColor* col = [sv::hex(rowColor(p, r)) blendedColorWithFraction:0.25 ofColor:sv::hex(0x9AA0AC)];
        bool sel = false;
        sv::line(NSMakePoint(0, y + h - 0.5), NSMakePoint(kHeaderW, y + h - 0.5), sv::hairline());
        if (r.kind == ArrangeRowKind::Folder && r.index < p.folders.size()) {
            const auto& f = p.folders[r.index];
            sel = static_cast<long>(r.index) == c.selectedFolder;
            sv::brushedPanel(NSMakeRect(2, y + 1, kHeaderW - 4, h - 4), sel, true);
            sv::roundFill(NSMakeRect(5, y + 5, 5, h - 12), 2.5, col);
            sv::text(f.collapsed ? @"▸" : @"▾", NSMakePoint(12 + indent, y + 6), sv::ui(12, true), sv::inkDim());
            sv::engravedIn(sv::ns(f.name), NSMakeRect(32 + indent, y + 6, kHeaderW - 96 - indent, 16), sv::ui(12, true), sv::ink());
            bool allMute = true, anySolo = false, any = false;
            for (const auto& t : p.tracks) if (FolderTools::isInside(p, t.folder, f.id)) { any = true; allMute &= t.mute; anySolo |= t.solo; }
            sv::consoleKey(pillRect(r, y, 0), @"M", any && allMute, sv::muteTint());
            sv::consoleKey(pillRect(r, y, 1), @"S", anySolo, sv::soloTint());
        } else if (r.kind == ArrangeRowKind::Audio && r.index < p.tracks.size()) {
            const auto& t = p.tracks[r.index];
            sel = static_cast<long>(r.index) == c.selectedTrack;
            sv::brushedPanel(NSMakeRect(2, y + 1, kHeaderW - 4, h - 4), sel, false);
            sv::roundFill(NSMakeRect(5, y + 5, 5, h - 12), 2.5, col);
            bool instrument = false;
            for (const auto& s2 : t.pluginSlots) if (s2.midiInputPort >= 0) instrument = true;
            sv::textIn([NSString stringWithFormat:@"%lu", (unsigned long)(r.index + 1)], NSMakeRect(8 + indent, y + 16, 22, 14), sv::mono(10), sv::inkFaint(), NSTextAlignmentCenter);
            sv::engravedIn(sv::ns(t.name.empty() ? std::string("Audio") : t.name), NSMakeRect(34 + indent, y + 6, kHeaderW - 138 - indent, 17), sv::ui(12, true), sv::ink());
            sv::engraved(instrument ? @"INSTRUMENT" : @"AUDIO", NSMakePoint(34 + indent, y + 26), sv::ui(10, true), sv::hex(0x8A8F9A));
            sv::consoleKey(pillRect(r, y, 0), @"M", t.mute, sv::muteTint());
            sv::consoleKey(pillRect(r, y, 1), @"S", t.solo, sv::soloTint());
            sv::consoleKey(pillRect(r, y, 2), @"●", t.recordArm, sv::rec());
            sv::consoleKey(pillRect(r, y, 3), @"I", t.monitor, sv::amber());
            // small fader: groove with a cap, the same scale as the mixer
            const CGFloat fx0 = kHeaderW - 98, fw = 86;
            sv::sunkenWell(NSMakeRect(fx0, y + 33, fw, 6), 3.0, sv::hex(0x0A0B0D));
            const CGFloat capX = fx0 + fw * faderPositionForDb(t.gainDb);
            sv::roundFill(NSMakeRect(capX - 4, y + 29, 9, 14), 2.0, sv::hex(0x14161A));
            sv::roundFill(NSMakeRect(capX - 3, y + 30, 7, 12), 2.0, sv::hex(0x4A4E57));
            sv::fill(NSMakeRect(capX - 0.5, y + 32, 1, 8), sv::hex(0xF2F0E8));
            if (t.locked) sv::text(@"🔒", NSMakePoint(kHeaderW - 128, y + 28), sv::ui(11), sv::inkDim());
            if (c.core->ready() && r.index < c.core->engine().trackCount()) {
                SVStrip strip;
                strip.kind = SVStripKind::Track;
                strip.index = r.index;
                const silveton::StereoMeterDisplay md = [c meterDisplayForStrip:strip];
                sv::sunkenWell(NSMakeRect(kHeaderW - 12, y + 3, 11, h - 6), 2.0, sv::hex(0x08090B));
                sv::meter::drawBar(NSMakeRect(kHeaderW - 10, y + 5, 3, h - 10), true, md.left.levelDb, md.left.holdDb, md.left.clip, false);
                sv::meter::drawBar(NSMakeRect(kHeaderW - 6, y + 5, 3, h - 10), true, md.right.levelDb, md.right.holdDb, md.right.clip, false);
            }
        } else if (r.kind == ArrangeRowKind::Midi && r.index < p.midiTracks.size()) {
            const auto& m = p.midiTracks[r.index];
            sel = static_cast<long>(r.index) == c.selectedMidiTrack;
            sv::brushedPanel(NSMakeRect(2, y + 1, kHeaderW - 4, h - 4), sel, false);
            sv::roundFill(NSMakeRect(5, y + 5, 5, h - 12), 2.5, col);
            if (r.drivesInstrument) sv::roundFill(NSMakeRect(11, y + 5, 2, h - 12), 1.0, [col colorWithAlphaComponent:0.5]);
            sv::engravedIn(sv::ns(m.name.empty() ? std::string("MIDI") : m.name), NSMakeRect(34 + indent, y + 6, kHeaderW - 138 - indent, 17), sv::ui(12, true), sv::ink());
            NSString* dest = @"NO OUTPUT";
            const int inst = instrumentTrackForPort(p, m.outputPort);
            if (inst >= 0) dest = [NSString stringWithFormat:@"MIDI → %@", sv::ns(p.tracks[static_cast<std::size_t>(inst)].name).uppercaseString];
            sv::engravedIn(dest, NSMakeRect(34 + indent, y + 26, kHeaderW - 138 - indent, 14), sv::ui(10, true), sv::hex(0x8A8F9A));
            sv::consoleKey(pillRect(r, y, 0), @"M", m.mute, sv::muteTint());
            sv::consoleKey(pillRect(r, y, 1), @"S", m.solo, sv::soloTint());
            if (m.transpose != 0 || m.velocityShift != 0)
                sv::text([NSString stringWithFormat:@"T%+d V%+d", m.transpose, m.velocityShift], NSMakePoint(kHeaderW - 98, y + 29), sv::mono(10), sv::amber());
        }
        y += h;
    }
    [NSGraphicsContext restoreGraphicsState];
    sv::line(NSMakePoint(kHeaderW - 0.5, 0), NSMakePoint(kHeaderW - 0.5, b.size.height), sv::hairline());

    // 5. top lanes: ruler, markers, arranger (brushed rails, engraved legends)
    sv::rail(NSMakeRect(0, 0, b.size.width, kRulerH));
    sv::bands(NSMakeRect(0, kRulerH, b.size.width, kMarkerH), 0x24272C, 0x202228);
    sv::bands(NSMakeRect(0, kRulerH + kMarkerH, b.size.width, kSectionH), 0x202228, 0x1C1E23);
    sv::fill(NSMakeRect(0, kTop - 1, b.size.width, 1), sv::hex(0x0C0D10));
    sv::engraved(@"RULER", NSMakePoint(14, 7), sv::ui(10, true), sv::hex(0x8A8F9A));
    sv::engraved(@"MARKERS", NSMakePoint(14, kRulerH + 4), sv::ui(10, true), sv::hex(0x8A8F9A));
    sv::engraved(@"ARRANGER", NSMakePoint(14, kRulerH + kMarkerH + 4), sv::ui(10, true), sv::hex(0x8A8F9A));
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(kHeaderW, 0, laneW, kTop));
    const bool topDirty = dirty.origin.y < kTop;
    for (const auto& g : grid) {
        if (!topDirty) break;
        const CGFloat gx = std::floor(map.xForSample(g.sample)) + 0.5;
        if (gx < dirty.origin.x - 70 || gx > NSMaxX(dirty) + 1) continue;
        const CGFloat top = g.level == 0 ? 6 : (g.level == 1 ? 17 : 21);
        sv::line(NSMakePoint(gx, top), NSMakePoint(gx, kRulerH), g.level == 0 ? sv::inkDim() : sv::inkFaint());
        if (!g.label.empty()) sv::text(sv::ns(g.label), NSMakePoint(gx + 4, 5), sv::mono(11), sv::ink());
    }
    if (c.core->ready()) {
        const auto& tr = c.core->engine().transport();
        if (tr.cycleEndSample() > tr.cycleStartSample()) {
            const CGFloat x0 = map.xForSample(tr.cycleStartSample()), x1 = map.xForSample(tr.cycleEndSample());
            sv::fill(NSMakeRect(x0, 0, x1 - x0, kRulerH), [(tr.cycleEnabled() ? sv::copper() : sv::inkFaint()) colorWithAlphaComponent:0.28]);
            sv::fill(NSMakeRect(x0, kRulerH - 3, x1 - x0, 3), tr.cycleEnabled() ? sv::copper() : sv::inkFaint());
        }
    }
    if (_drag == DragMode::Ruler && _moved) {
        const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
        sv::fill(NSMakeRect(x0, 0, x1 - x0, kRulerH), [sv::copper() colorWithAlphaComponent:0.45]);
    }
    sv::line(NSMakePoint(kHeaderW, kRulerH - 0.5), NSMakePoint(b.size.width, kRulerH - 0.5), sv::hairline());
    for (const auto& m : p.markers) {
        const CGFloat mx = map.xForSample(m.sample);
        NSColor* mc = m.color ? [sv::hex(m.color) blendedColorWithFraction:0.25 ofColor:sv::hex(0x9AA0AC)] : sv::amber();
        if (m.cycle) {
            const CGFloat x1 = map.xForSample(m.endSample);
            sv::roundFill(NSMakeRect(mx, kRulerH + 4, x1 - mx, kMarkerH - 8), 3, [mc colorWithAlphaComponent:0.35]);
        }
        NSBezierPath* flag = [NSBezierPath bezierPath];
        [flag moveToPoint:NSMakePoint(mx, kRulerH + 3)];
        [flag lineToPoint:NSMakePoint(mx + 9, kRulerH + 3)];
        [flag lineToPoint:NSMakePoint(mx + 9, kRulerH + 13)];
        [flag lineToPoint:NSMakePoint(mx, kRulerH + 18)];
        [flag closePath];
        [mc setFill];
        [flag fill];
        sv::text(sv::ns(m.name), NSMakePoint(mx + 13, kRulerH + 3), sv::ui(11, true), sv::ink());
    }
    sv::line(NSMakePoint(kHeaderW, kRulerH + kMarkerH - 0.5), NSMakePoint(b.size.width, kRulerH + kMarkerH - 0.5), sv::hairline());
    for (const auto& s : p.arrangerSections) {
        const CGFloat x0 = map.xForSample(s.startSample), x1 = map.xForSample(s.endSample);
        const NSRect sr2 = NSMakeRect(x0 + 1, kRulerH + kMarkerH + 2, std::max<CGFloat>(2, x1 - x0 - 2), kSectionH - 4);
        sv::roundFill(sr2, 4, [[sv::hex(s.color ? s.color : 0x6A9BC3U) blendedColorWithFraction:0.3 ofColor:sv::hex(0x9AA0AC)] colorWithAlphaComponent:s.id == c.selectedSectionId ? 1.0 : 0.72]);
        sv::textIn(sv::ns(s.name), NSMakeRect(sr2.origin.x + 6, sr2.origin.y + 1, sr2.size.width - 10, 15), sv::ui(11, true), sv::canvas());
    }
    if (_drag == DragMode::NewSection && _moved) {
        const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
        sv::roundFill(NSMakeRect(x0, kRulerH + kMarkerH + 2, x1 - x0, kSectionH - 4), 4, [sv::copper() colorWithAlphaComponent:0.5]);
    }
    [NSGraphicsContext restoreGraphicsState];
    sv::line(NSMakePoint(0, kTop - 0.5), NSMakePoint(b.size.width, kTop - 0.5), sv::hairline());

    // 6. playhead
    const CGFloat px = map.xForSample(c.playheadSample);
    if (px >= kHeaderW && px <= b.size.width) {
        sv::line(NSMakePoint(std::floor(px) + 0.5, 0), NSMakePoint(std::floor(px) + 0.5, b.size.height), sv::copper(), 1.5);
        NSBezierPath* head = [NSBezierPath bezierPath];
        [head moveToPoint:NSMakePoint(px - 6, 0)];
        [head lineToPoint:NSMakePoint(px + 6, 0)];
        [head lineToPoint:NSMakePoint(px, 9)];
        [head closePath];
        [sv::copper() setFill];
        [head fill];
    }

    if (_rows.empty()) {
        NSString* t = @"Drop WAV / AIFF files here";
        NSString* s2 = @"or use  Project ▸ Add Instrument Track (⌥⌘I)  ·  Add Audio Track (⌥⌘A)";
        const CGFloat cy = std::max<CGFloat>(kTop + 60, b.size.height * 0.42);
        sv::textIn(t, NSMakeRect(kHeaderW, cy, laneW, 26), sv::ui(20, true), sv::inkDim(), NSTextAlignmentCenter);
        sv::textIn(s2, NSMakeRect(kHeaderW, cy + 32, laneW, 16), sv::ui(11), sv::inkFaint(), NSTextAlignmentCenter);
    }
    if (_externalDrag) sv::roundStroke(NSInsetRect(b, 4, 4), 10, sv::copper(), 3);
}

// ------------------------------------------------------------ track height --
// The row whose bottom edge is at view height `y` (so its header can be dragged taller), or -1.
- (long)rowWithBottomEdgeAt:(CGFloat)y {
    if (y < kTop) return -1;
    CGFloat top = kTop - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const CGFloat h = rowHeight(_rows[i]);
        if (_rows[i].kind != ArrangeRowKind::Folder && std::abs(top + h - y) <= kEdgeGrabH) return static_cast<long>(i);
        top += h;
    }
    return -1;
}

- (void)updateTrackingAreas {
    [super updateTrackingAreas];
    if (_tracking) [self removeTrackingArea:_tracking];
    _tracking = [[NSTrackingArea alloc] initWithRect:self.bounds
                                             options:NSTrackingMouseMoved | NSTrackingActiveInKeyWindow | NSTrackingInVisibleRect
                                               owner:self userInfo:nil];
    [self addTrackingArea:_tracking];
}

- (void)mouseMoved:(NSEvent*)event {
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (pt.x < kHeaderW && [self rowWithBottomEdgeAt:pt.y] >= 0) [[NSCursor resizeUpDownCursor] set];
    else [[NSCursor arrowCursor] set];
}

- (BOOL)setSelectedTrackHeight:(CGFloat)height {
    SilvetonController* c = self.controller;
    CGFloat top = 0.0;
    for (const ArrangeRow& r : _rows) {
        const bool selected = (r.kind == ArrangeRowKind::Audio && static_cast<long>(r.index) == c.selectedTrack) ||
                              (r.kind == ArrangeRowKind::Midi && static_cast<long>(r.index) == c.selectedMidiTrack);
        if (!selected) { top += rowHeight(r); continue; }
        const CGFloat fill = std::max(kMinTrackH, self.bounds.size.height - kTop - 2.0);
        CGFloat target = height;
        if (height == -2.0) target = rowHeight(r) > kTrackH + 1.0 ? 0.0 : -1.0;   // zoom on / off
        if (target == 0.0) chosenHeights().erase(rowKey(r));
        else chosenHeights()[rowKey(r)] = std::min(kMaxTrackH, std::max(kMinTrackH, target < 0.0 ? fill : target));
        if (target < 0.0) self.scrollY = top;   // a zoomed track starts at the top of the window
        [self setNeedsDisplay:YES];
        return YES;
    }
    return NO;
}

- (void)resetTrackHeights {
    chosenHeights().clear();
    [self setNeedsDisplay:YES];
}

// ---------------------------------------------------------------- hit test --
- (Hit)hitAt:(NSPoint)pt {
    Hit hit;
    const Project* p = self.controller.project;
    if (!p) return hit;
    const auto map = [self mapping];
    hit.sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    if (pt.y < kTop) return hit;
    CGFloat y = kTop - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const CGFloat h = rowHeight(_rows[i]);
        if (pt.y >= y && pt.y < y + h) {
            hit.row = static_cast<long>(i);
            hit.header = pt.x < kHeaderW;
            if (hit.header) return hit;
            const auto& r = _rows[i];
            if (r.kind == ArrangeRowKind::Audio && r.index < p->tracks.size()) {
                for (const auto& clip : p->tracks[r.index].clips) {
                    const CGFloat x0 = map.xForSample(clip.timelineStartSample);
                    const CGFloat x1 = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples));
                    if (pt.x >= x0 && pt.x <= x1) {
                        hit.clip = clip.id;
                        if (pt.x - x0 < 6 && x1 - x0 > 18) hit.edge = -1;
                        else if (x1 - pt.x < 6 && x1 - x0 > 18) hit.edge = 1;
                    }
                }
            } else if (r.kind == ArrangeRowKind::Midi && r.index < p->midiTracks.size()) {
                const auto& mt = p->midiTracks[r.index];
                if (mt.parts.empty()) {
                    double end = 0;
                    for (const auto& n : mt.sequence.notes()) end = std::max(end, n.startQuarterNotes + n.durationQuarterNotes);
                    const CGFloat x1 = map.xForSample(p->tempoMap.sampleAtQuarterNotes(std::ceil(end / 4.0) * 4.0));
                    if (end > 0 && pt.x >= map.xForSample(0) && pt.x <= x1) hit.legacyPart = true;
                } else {
                    for (const auto& part : mt.parts) {
                        const CGFloat x0 = map.xForSample(p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes));
                        const CGFloat x1 = map.xForSample(p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes + part.lengthQuarterNotes));
                        if (pt.x >= x0 && pt.x <= x1) hit.part = part.id;
                    }
                }
            }
            return hit;
        }
        y += h;
    }
    return hit;
}

- (void)mouseDown:(NSEvent*)event {
    [self.window makeFirstResponder:self];
    SilvetonController* c = self.controller;
    Project* p = c.project;
    if (!p) return;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    _downPoint = pt;
    _moved = NO;
    _drag = DragMode::None;
    const auto map = [self mapping];
    const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    const bool twice = event.clickCount >= 2;
    if (pt.y < kTop) {
        if (pt.x < kHeaderW) return;
        if (pt.y < kRulerH) {
            _drag = DragMode::Ruler;
            _dragAnchor = _dragCurrent = [c snapSample:sample];
        } else if (pt.y < kRulerH + kMarkerH) {
            for (const auto& m : p->markers) {
                const CGFloat mx = map.xForSample(m.sample);
                if (pt.x >= mx - 3 && pt.x <= mx + 10) { [c markerClicked:m.id doubleClick:twice]; [self setNeedsDisplay:YES]; return; }
            }
            if (twice) [c addMarkerAtSample:[c snapSample:sample]];
        } else {
            for (const auto& s : p->arrangerSections) {
                if (sample >= s.startSample && sample < s.endSample) { [c sectionClicked:s.id doubleClick:twice]; [self setNeedsDisplay:YES]; return; }
            }
            _drag = DragMode::NewSection;
            _dragAnchor = _dragCurrent = [c snapSample:sample];
        }
        [self setNeedsDisplay:YES];
        return;
    }
    if (pt.x < kHeaderW) {   // the bottom edge of a track header: drag = taller / shorter, double click = normal
        const long edge = [self rowWithBottomEdgeAt:pt.y];
        if (edge >= 0) {
            const ArrangeRow& er = _rows[static_cast<std::size_t>(edge)];
            if (twice) { chosenHeights().erase(rowKey(er)); [self setNeedsDisplay:YES]; return; }
            _drag = DragMode::ResizeRow;
            _resizeKey = rowKey(er);
            _resizeStartH = rowHeight(er);
            return;
        }
    }
    const Hit hit = [self hitAt:pt];
    if (hit.row < 0) { c.selectedClipId = 0; [c refreshAll]; return; }
    const ArrangeRow row = _rows[static_cast<std::size_t>(hit.row)];
    // compute row top
    CGFloat y = kTop - self.scrollY;
    for (long i = 0; i < hit.row; ++i) y += rowHeight(_rows[static_cast<std::size_t>(i)]);
    if (hit.header) {
        if (row.kind == ArrangeRowKind::Folder) {
            if (pt.x < 26 + row.depth * 12.0) { [c toggleFolderCollapse:row.index]; return; }
            if (NSPointInRect(pt, pillRect(row, y, 0))) { [c toggleMute:row]; return; }
            if (NSPointInRect(pt, pillRect(row, y, 1))) { [c toggleSolo:row]; return; }
        } else {
            if (NSPointInRect(pt, pillRect(row, y, 0))) { [c toggleMute:row]; return; }
            if (NSPointInRect(pt, pillRect(row, y, 1))) { [c toggleSolo:row]; return; }
            if (row.kind == ArrangeRowKind::Audio && NSPointInRect(pt, pillRect(row, y, 2))) { [c toggleArm:row]; return; }
            if (row.kind == ArrangeRowKind::Audio && NSPointInRect(pt, pillRect(row, y, 3))) { [c toggleMonitor:row]; return; }
        }
        [c selectRow:row];
        if (twice) [c renameRow:row];
        return;
    }
    [c selectRow:row];
    if (row.kind == ArrangeRowKind::Audio) {
        c.selectedClipId = hit.clip;
        if (hit.clip) {
            _dragTrack = row.index;
            _dragId = hit.clip;
            for (const auto& clip : p->tracks[row.index].clips) if (clip.id == hit.clip) _grabOffset = sample - clip.timelineStartSample;
            _drag = hit.edge < 0 ? DragMode::TrimLeft : (hit.edge > 0 ? DragMode::TrimRight : DragMode::MoveClip);
            if (twice) { [c openEditor:nil]; _drag = DragMode::None; }
        } else {
            [c seekToSample:sample];
        }
    } else if (row.kind == ArrangeRowKind::Midi) {
        c.selectedPartId = hit.part;
        if (hit.part) {
            _dragTrack = row.index;
            _dragId = hit.part;
            const double q = p->tempoMap.quarterNotesAtSample(sample);
            for (const auto& part : p->midiTracks[row.index].parts) if (part.id == hit.part) _grabOffsetQ = q - part.timelineStartQuarterNotes;
            _drag = DragMode::MovePart;
            if (twice) { _drag = DragMode::None; [c openEditor:nil]; }
        } else if (hit.legacyPart) {
            if (twice) [c openEditor:nil];
        } else if (twice) {
            [c createPartForMidiTrack:row.index atSample:[c snapSample:sample]];
        } else {
            [c seekToSample:sample];
        }
    }
    [c refreshAll];
}

- (void)mouseDragged:(NSEvent*)event {
    SilvetonController* c = self.controller;
    Project* p = c.project;
    if (!p || _drag == DragMode::None) return;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (!_moved && std::hypot(pt.x - _downPoint.x, pt.y - _downPoint.y) < 3.0) return;
    _moved = YES;
    const auto map = [self mapping];
    const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    switch (_drag) {
        case DragMode::Ruler:
        case DragMode::NewSection:
            _dragCurrent = [c snapSample:sample];
            break;
        case DragMode::MoveClip:
            if (!_gestureOpen) { [c beginGesture:@"Move Clip"]; _gestureOpen = YES; }
            [c dragClip:_dragId track:_dragTrack toSample:std::max<std::int64_t>(0, sample - _grabOffset)];
            break;
        case DragMode::TrimLeft:
        case DragMode::TrimRight:
            if (!_gestureOpen) { [c beginGesture:@"Trim Clip"]; _gestureOpen = YES; }
            [c dragClipEdge:_dragId track:_dragTrack leftEdge:(_drag == DragMode::TrimLeft) toSample:sample];
            break;
        case DragMode::ResizeRow:
            chosenHeights()[_resizeKey] = std::min(kMaxTrackH, std::max(kMinTrackH, _resizeStartH + (pt.y - _downPoint.y)));
            break;
        case DragMode::MovePart: {
            if (!_gestureOpen) { [c beginGesture:@"Move MIDI Part"]; _gestureOpen = YES; }
            const double q = p->tempoMap.quarterNotesAtSample([c snapSample:sample]) - _grabOffsetQ;
            const double div = std::max<std::uint32_t>(1U, c.gridDivisionsPerQuarter);
            [c dragPart:_dragId midiTrack:_dragTrack toQuarter:std::max(0.0, c.snapEnabled ? std::round(q * div) / div : q)];
            break;
        }
        default: break;
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    SilvetonController* c = self.controller;
    const auto map = [self mapping];
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (_drag == DragMode::Ruler) {
        if (_moved && _dragCurrent != _dragAnchor) [c setCycleStart:std::min(_dragAnchor, _dragCurrent) end:std::max(_dragAnchor, _dragCurrent)];
        else [c seekToSample:std::max<std::int64_t>(0, map.sampleForX(pt.x))];
    } else if (_drag == DragMode::NewSection && _moved && _dragCurrent != _dragAnchor) {
        [c createSectionFrom:std::min(_dragAnchor, _dragCurrent) to:std::max(_dragAnchor, _dragCurrent)];
    }
    if (_gestureOpen) { [c endGesture]; _gestureOpen = NO; }
    _drag = DragMode::None;
    [c refreshAll];
}

- (NSMenu*)menuForEvent:(NSEvent*)event {
    SilvetonController* c = self.controller;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    const auto map = [self mapping];
    const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    if (pt.y < kTop && pt.x >= kHeaderW && c.project) {
        if (pt.y >= kRulerH && pt.y < kRulerH + kMarkerH) {
            for (const auto& m : c.project->markers) {
                const CGFloat mx = map.xForSample(m.sample);
                if (pt.x >= mx - 3 && pt.x <= mx + 10) return [c contextMenuForMarker:m.id];
            }
        } else if (pt.y >= kRulerH + kMarkerH) {
            for (const auto& s : c.project->arrangerSections)
                if (sample >= s.startSample && sample < s.endSample) return [c contextMenuForSection:s.id];
        }
        return nil;
    }
    const Hit hit = [self hitAt:pt];
    ArrangeRow row;
    bool haveRow = hit.row >= 0;
    if (haveRow) {
        row = _rows[static_cast<std::size_t>(hit.row)];
        [c selectRow:row];
        if (row.kind == ArrangeRowKind::Audio) c.selectedClipId = hit.clip;
        if (row.kind == ArrangeRowKind::Midi) c.selectedPartId = hit.part;
    } else {
        row.kind = ArrangeRowKind::Audio;
        row.index = static_cast<std::size_t>(-1);
    }
    [c seekToSample:sample];
    return [c contextMenuForRow:row clip:hit.clip part:hit.part atSample:sample];
}

- (void)scrollWheel:(NSEvent*)event {
    const NSEventModifierFlags mods = event.modifierFlags & NSEventModifierFlagDeviceIndependentFlagsMask;
    SilvetonController* c = self.controller;
    if ((mods & NSEventModifierFlagOption) || (mods & NSEventModifierFlagCommand)) {
        const double dy = event.scrollingDeltaY;
        if (std::abs(dy) > 0.001) {
            const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
            const auto before = [self mapping];
            const std::int64_t anchor = before.sampleForX(pt.x);
            [c setPixelsPerSecond:c.pixelsPerSecond * std::pow(1.08, dy / 4.0)];
            const double pps = c.pixelsPerSecond;
            self.scrollSeconds = std::max(0.0, static_cast<double>(anchor) / before.sampleRate - (pt.x - kHeaderW) / pps);
        }
    } else {
        double dx = event.scrollingDeltaX, dy = event.scrollingDeltaY;
        if (!event.hasPreciseScrollingDeltas) { dx *= 12; dy *= 12; }
        if (mods & NSEventModifierFlagShift) { dx = dy; dy = 0; }
        self.scrollSeconds = std::max(0.0, self.scrollSeconds - dx / std::max(1.0, c.pixelsPerSecond));
        self.scrollY = std::max(0.0, self.scrollY - dy);
    }
    [self setNeedsDisplay:YES];
}
- (void)magnifyWithEvent:(NSEvent*)event {
    [self.controller setPixelsPerSecond:self.controller.pixelsPerSecond * (1.0 + event.magnification)];
    [self setNeedsDisplay:YES];
}

// External file drops
- (NSArray<NSURL*>*)audioURLs:(id<NSDraggingInfo>)sender {
    NSArray* urls = [sender.draggingPasteboard readObjectsForClasses:@[[NSURL class]] options:@{NSPasteboardURLReadingFileURLsOnlyKey: @YES}];
    NSMutableArray<NSURL*>* out = [NSMutableArray array];
    for (NSURL* u in urls) {
        NSString* ext = u.pathExtension.lowercaseString;
        if ([ext isEqualToString:@"wav"] || [ext isEqualToString:@"aif"] || [ext isEqualToString:@"aiff"]) [out addObject:u];
    }
    return out;
}
- (NSDragOperation)draggingEntered:(id<NSDraggingInfo>)sender {
    _externalDrag = [self audioURLs:sender].count > 0;
    [self setNeedsDisplay:YES];
    return _externalDrag ? NSDragOperationCopy : NSDragOperationNone;
}
- (NSDragOperation)draggingUpdated:(id<NSDraggingInfo>)sender { return [self audioURLs:sender].count > 0 ? NSDragOperationCopy : NSDragOperationNone; }
- (void)draggingExited:(id<NSDraggingInfo>)sender { (void)sender; _externalDrag = NO; [self setNeedsDisplay:YES]; }
- (BOOL)performDragOperation:(id<NSDraggingInfo>)sender {
    NSArray<NSURL*>* urls = [self audioURLs:sender];
    _externalDrag = NO;
    [self setNeedsDisplay:YES];
    if (urls.count == 0) return NO;
    const NSPoint pt = [self convertPoint:sender.draggingLocation fromView:nil];
    const std::int64_t sample = pt.x > kHeaderW ? [self.controller snapSample:std::max<std::int64_t>(0, [self mapping].sampleForX(pt.x))]
                                                : self.controller.playheadSample;
    [self.controller importAudioURLs:urls atSample:sample];
    return YES;
}
@end
