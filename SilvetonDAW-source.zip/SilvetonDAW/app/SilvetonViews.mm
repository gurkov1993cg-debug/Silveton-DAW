#import "SilvetonViews.h"
#include "SilvetonMeterDraw.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <map>
#include <limits>
#include <set>
#include <string>
#include <vector>

using namespace silveton;

// ============================================================= Side bar ==
namespace {
constexpr int kNavKeyCount = 4;          // PROJECT, MIX, LIBRARY, SETUP (SETUP opens Audio System Setup)
constexpr CGFloat kWoodW = 72.0;         // the wood itself; the bar view is 2 px wider for the edge lines
}
@implementation SilvetonSideBar {
    NSRect _navRects[kNavKeyCount];
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
// Walnut: a warm left-to-right gradient with wavy grain lines (fixed seed, so it always looks the same).
- (void)drawWood:(NSRect)wood {
    NSGradient* grad = [[NSGradient alloc] initWithColorsAndLocations:
        sv::hex(0x4E301C), 0.0, sv::hex(0x764A2A), 0.35, sv::hex(0x603A22), 0.7, sv::hex(0x462A18), 1.0, nil];
    [grad drawInRect:wood angle:0.0];
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(wood);
    std::uint32_t seed = 7U;
    auto next = [&seed]() { seed = seed * 1664525U + 1013904223U; return static_cast<double>(seed) / 4294967296.0; };
    for (int k = 0; k < 70; ++k) {
        const double x0 = next() * wood.size.width;
        const double amp = 2.0 + next() * 6.0;
        const double period = 120.0 + next() * 260.0;
        const double phase = next() * 6.28;
        const bool dark = next() > 0.5;
        const double alpha = (dark ? 28.0 + next() * 30.0 : 18.0 + next() * 20.0) / 255.0;
        const double width = 0.6 + next() * 1.6;
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = static_cast<CGFloat>(width);
        bool first = true;
        for (double y = -8.0; y <= wood.size.height + 8.0; y += 8.0) {
            const NSPoint pt = NSMakePoint(static_cast<CGFloat>(x0 + amp * std::sin(phase + y / period * 6.28)), static_cast<CGFloat>(y));
            if (first) { [path moveToPoint:pt]; first = false; } else [path lineToPoint:pt];
        }
        [(dark ? sv::rgb(20.0 / 255.0, 10.0 / 255.0, 4.0 / 255.0, alpha) : sv::rgb(220.0 / 255.0, 170.0 / 255.0, 110.0 / 255.0, alpha)) setStroke];
        [path stroke];
    }
    [NSGraphicsContext restoreGraphicsState];
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    const NSRect wood = NSMakeRect(0, 0, kWoodW, b.size.height);
    [self drawWood:wood];
    sv::fill(NSMakeRect(kWoodW, 0, 1.5, b.size.height), sv::hex(0x0A0806));
    sv::fill(NSMakeRect(kWoodW + 1.5, 0, 0.5, b.size.height), sv::hex(0x787C86));

    // Wordmark: letter-spaced gold name, written downwards.
    NSDictionary* brand = @{NSFontAttributeName: sv::ui(12, true), NSForegroundColorAttributeName: sv::gold(), NSKernAttributeName: @(3.0)};
    NSString* name = @"SILVETON";
    const NSSize nameSize = [name sizeWithAttributes:brand];
    [NSGraphicsContext saveGraphicsState];
    NSAffineTransform* turn = [NSAffineTransform transform];
    [turn translateXBy:kWoodW * 0.5 yBy:14.0];
    [turn rotateByDegrees:90.0];
    [turn concat];
    [name drawAtPoint:NSMakePoint(0, -nameSize.height * 0.5) withAttributes:brand];
    [NSGraphicsContext restoreGraphicsState];

    // The editor has no key of its own: it opens under the tracks (double-click a clip) or on a full page (FULL PAGE).
    NSArray<NSString*>* titles = @[@"PROJECT", @"MIX", @"LIBRARY", @"SETUP"];
    for (int i = 0; i < kNavKeyCount; ++i) {
        const NSRect r = NSMakeRect(5.0, 118.0 + 58.0 * i, kWoodW - 10.0, 46.0);
        _navRects[i] = r;
        const bool on = i < 3 && i == self.page;
        sv::keyCap(r, 11.0, on, sv::gold());
        sv::textIn(titles[static_cast<NSUInteger>(i)], NSMakeRect(r.origin.x, r.origin.y + (r.size.height - 2.0) * 0.5 - 7.0, r.size.width, 15.0),
                   sv::ui(10, true), on ? sv::gold() : sv::inkDim(), NSTextAlignmentCenter);
    }
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    for (int i = 0; i < kNavKeyCount; ++i) {
        if (!NSPointInRect(p, _navRects[i])) continue;
        if (i == 0) [self.controller showPage:SVPage::Arrange];
        else if (i == 1) [self.controller showPage:SVPage::Mix];
        else if (i == 2) [self.controller showPage:SVPage::Library];
        else [self.controller audioSetup:nil];
        return;
    }
}
@end

// ============================================================== Page bar ==
// Status bar along the bottom edge: message on the left, project and sample rate on the right.
@implementation SilvetonPageBar
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::rail(b);
    NSMutableString* right = [NSMutableString stringWithString:self.projectTitle ?: @"Untitled"];
    if (self.controller.project) {
        const double rate = self.controller.project->sampleRate;
        if (rate > 0.0) [right appendFormat:@"   ·   %@ kHz", std::abs(rate / 1000.0 - std::round(rate / 1000.0)) < 0.001 ? [NSString stringWithFormat:@"%.0f", rate / 1000.0] : [NSString stringWithFormat:@"%.1f", rate / 1000.0]];
        if (self.controller.core && self.controller.core->ready()) {   // how much of the time for one block the processing takes
            const double load = static_cast<double>(self.controller.core->runtime().engineCallback().dspLoad());
            [right appendFormat:@"   ·   DSP %.0f %%", std::min(load, 9.99) * 100.0];
        }
    }
    const CGFloat rightW = std::min<CGFloat>(420.0, std::ceil(sv::textSize(right, sv::mono(10)).width) + 8.0);
    sv::textIn(right, NSMakeRect(b.size.width - rightW - 14.0, 5, rightW, 14), sv::mono(10), sv::inkFaint(), NSTextAlignmentRight);
    NSString* msg = self.statusText.length ? self.statusText : @"Ready";
    sv::textIn(msg, NSMakeRect(14, 5, std::max<CGFloat>(40.0, b.size.width - rightW - 44.0), 14), sv::mono(10), sv::lcdValue());
}
@end

// ======================================================= Transport deck ==
namespace {
enum TransportKey { kKeyPrev, kKeyRew, kKeyStop, kKeyPlay, kKeyRec, kKeyFwd, kKeyNext, kKeyLoop, kKeyClick, kKeyCount };
constexpr CGFloat kMasterBarLength = 190.0;   // the master meter bars in the transport deck

// Small drawn symbols for the transport keys (flipped view).
void drawSymbol(int key, NSPoint c, NSColor* color) {
    [color setFill];
    [color setStroke];
    NSBezierPath* p = [NSBezierPath bezierPath];
    auto tri = [&](CGFloat x, CGFloat w, bool right) {
        if (right) { [p moveToPoint:NSMakePoint(x, c.y - 6.5)]; [p lineToPoint:NSMakePoint(x + w, c.y)]; [p lineToPoint:NSMakePoint(x, c.y + 6.5)]; }
        else { [p moveToPoint:NSMakePoint(x, c.y - 6.5)]; [p lineToPoint:NSMakePoint(x - w, c.y)]; [p lineToPoint:NSMakePoint(x, c.y + 6.5)]; }
        [p closePath];
    };
    switch (key) {
        case kKeyPlay: tri(c.x - 5, 12, true); [p fill]; break;
        case kKeyStop: sv::roundFill(NSMakeRect(c.x - 5.5, c.y - 5.5, 11, 11), 2, color); break;
        case kKeyRec: [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x - 6, c.y - 6, 12, 12)] fill]; break;
        case kKeyRew: tri(c.x + 1, 8, false); tri(c.x + 9, 8, false); [p fill]; break;
        case kKeyFwd: tri(c.x - 9, 8, true); tri(c.x - 1, 8, true); [p fill]; break;
        case kKeyPrev: sv::fill(NSMakeRect(c.x - 8, c.y - 6.5, 2.5, 13), color); tri(c.x + 7, 10, false); [p fill]; break;
        case kKeyNext: sv::fill(NSMakeRect(c.x + 5.5, c.y - 6.5, 2.5, 13), color); tri(c.x - 7, 10, true); [p fill]; break;
        default: break;
    }
}
}
@implementation SilvetonTransportDeck {
    NSRect _keys[kKeyCount];
    NSRect _counterRect, _tempoRect, _meterRect, _signatureRect;
    silveton::StereoMeterDisplay _meter;
    std::uint32_t _meterSig;
    std::int64_t _lastPos;
    BOOL _lastPlaying;
    BOOL _forceNext;
    int _lastDsp;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)tick {
    SilvetonController* c = self.controller;
    if (!c || !c.core || !c.core->ready()) return;
    // The master meter comes from the shared meter bank (ballistics already applied).
    _meter = [c masterMeterDisplay];
    const std::uint32_t sig = sv::meter::signature(_meter, kMasterBarLength, true) ^
        (static_cast<std::uint32_t>(std::lround(std::max(-99.0F, _meter.maxDb()) * 10.0F) + 1000) * 40503U);
    const bool meterMoved = sig != _meterSig;
    // Repaint only what changed: the whole deck when the counter/keys changed,
    // otherwise just the small master-meter card.
    const std::int64_t pos = c.playheadSample;
    const bool playing = c.core->engine().transport().isPlaying();
    const bool keysChanged = playing != _lastPlaying || _forceNext;
    const bool posChanged = pos != _lastPos;
    _meterSig = sig; _lastPos = pos; _lastPlaying = playing; _forceNext = NO;
    if (keysChanged || NSIsEmptyRect(_counterRect) || NSIsEmptyRect(_meterRect)) { [self setNeedsDisplay:YES]; return; }
    // While playing only the two displays and the meter card are painted again, 30 times a second —
    // not the whole deck with its keys and gradients (that kept an older iMac busy for nothing).
    if (posChanged) { [self setNeedsDisplayInRect:_counterRect]; [self setNeedsDisplayInRect:_tempoRect]; }
    if (meterMoved) [self setNeedsDisplayInRect:_meterRect];
}
- (void)drawKey:(int)k glyph:(NSString*)glyph lit:(bool)lit color:(NSColor*)color wide:(bool)wide {
    const NSRect r = _keys[k];
    sv::keyCap(r, 7.0, lit, color);
    const NSPoint mid = NSMakePoint(NSMidX(r), r.origin.y + (r.size.height - 2.0) * 0.5);
    NSColor* ink = lit ? color : sv::inkDim();
    if (wide) {
        NSFont* f = sv::ui(10, true);
        const NSSize sz = sv::textSize(glyph, f);
        sv::text(glyph, NSMakePoint(mid.x - sz.width / 2, mid.y - sz.height / 2), f, ink);
    } else {
        drawSymbol(k, mid, lit ? color : sv::inkDim());
    }
}
// Master level card: dark display, segmented bars on the fader scale, peak read-out, clip lamp.
- (void)drawMasterMeter:(NSRect)b {
    _meterRect = NSMakeRect(b.size.width - 230, 10, 210, 58);
    const CGFloat mx = _meterRect.origin.x;
    sv::lcd(_meterRect, 8.0);
    sv::text(@"MASTER", NSMakePoint(mx + 10, 14), sv::ui(10, true), sv::lcdDim());
    const float maxDb = _meter.maxDb();
    NSString* readout = maxDb <= -99.0F ? @"-∞ dB" : [NSString stringWithFormat:@"%+.1f dB", maxDb];
    sv::textIn(readout, NSMakeRect(mx + 80, 14, 104, 13), sv::mono(10, true), maxDb > 0.0F ? sv::rec() : sv::lcdValue(), NSTextAlignmentRight);
    sv::meter::drawClipLamp(NSMakeRect(mx + 190, 16, 10, 6), _meter.clip());
    for (int ch = 0; ch < 2; ++ch) {
        const silveton::MeterChannelDisplay& m = ch == 0 ? _meter.left : _meter.right;
        sv::meter::drawBar(NSMakeRect(mx + 10, 31 + ch * 10, kMasterBarLength, 8), false, m.levelDb, m.holdDb, m.clip, true);
    }
    // dB scale under the bars (same positions as the fader scale)
    for (double db : {-40.0, -24.0, -12.0, -6.0, 0.0, 6.0}) {
        const CGFloat tx = std::round(mx + 10 + sv::meter::position(db) * kMasterBarLength);
        NSColor* tone = db == 0.0 ? sv::lcdValue() : sv::lcdDim();
        sv::line(NSMakePoint(tx + 0.5, 50), NSMakePoint(tx + 0.5, 53), tone);
        sv::textIn(sv::meter::dbLabel(db), NSMakeRect(tx - 14, 52, 28, 13), sv::mono(10), tone, NSTextAlignmentCenter);
    }
}
- (void)drawRect:(NSRect)dirty {
    const NSRect b = self.bounds;
    sv::rail(b);
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    // The timer invalidates only the master card while everything else is still.
    if (!NSIsEmptyRect(_meterRect) && NSContainsRect(_meterRect, dirty)) { [self drawMasterMeter:b]; return; }
    const Project& p = *c.project;
    const std::int64_t pos = c.playheadSample;
    const bool ready = c.core && c.core->ready();
    const bool playing = ready && c.core->engine().transport().isPlaying();
    const bool cycle = ready && c.core->engine().transport().cycleEnabled();
    const bool recording = c.core && c.core->recording() != nullptr;
    const CGFloat top = 10, lcdH = 58;

    // Position display: bars · beats · ticks big, clock small
    const NSRect pos0 = NSMakeRect(14, top, 224, lcdH);
    _counterRect = pos0;
    sv::lcd(pos0, 8.0);
    sv::text(@"POSITION", NSMakePoint(pos0.origin.x + 10, top + 5), sv::ui(10, true), sv::lcdDim());
    const double sr = p.sampleRate > 0 ? p.sampleRate : 48000.0;
    sv::textIn(sv::ns(formatClock(static_cast<double>(pos) / sr)), NSMakeRect(pos0.origin.x + 100, top + 5, pos0.size.width - 110, 13), sv::mono(11), sv::lcdValue(), NSTextAlignmentRight);
    sv::text(sv::ns(formatBarsBeats(p.tempoMap, pos)), NSMakePoint(pos0.origin.x + 10, top + 21), sv::mono(24, true), sv::copper());

    // Tempo display: tempo big, signature small (its own click area)
    const auto tp = p.tempoMap.positionAtSample(pos);
    const NSRect tempo0 = NSMakeRect(NSMaxX(pos0) + 8, top, 104, lcdH);
    _tempoRect = tempo0;
    _signatureRect = NSMakeRect(NSMaxX(tempo0) - 54, top, 54, 24);
    sv::lcd(tempo0, 8.0);
    sv::text(@"TEMPO", NSMakePoint(tempo0.origin.x + 10, top + 5), sv::ui(10, true), sv::lcdDim());
    sv::textIn([NSString stringWithFormat:@"%u/%u", tp.numerator, tp.denominator], NSMakeRect(NSMaxX(tempo0) - 52, top + 5, 44, 13), sv::mono(11), sv::lcdValue(), NSTextAlignmentRight);
    sv::text([NSString stringWithFormat:@"%.2f", tp.bpm], NSMakePoint(tempo0.origin.x + 10, top + 25), sv::mono(21, true), sv::copper());

    // Keys: marker back, bar back, stop, play, record, bar forward, marker forward | cycle, click
    CGFloat x = NSMaxX(tempo0) + 16;
    const CGFloat y = 17, h = 42;
    const CGFloat widths[kKeyCount] = {34, 34, 38, 50, 38, 34, 34, 56, 56};
    for (int k = 0; k < kKeyCount; ++k) {
        if (k == kKeyLoop) x += 12;
        _keys[k] = NSMakeRect(x, y, widths[k], h);
        x += widths[k] + (k == kKeyNext ? 0 : 5);
    }
    [self drawKey:kKeyPrev glyph:@"" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyRew glyph:@"" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyStop glyph:@"" lit:!playing color:sv::inkDim() wide:false];
    [self drawKey:kKeyPlay glyph:@"" lit:playing color:sv::copper() wide:false];
    [self drawKey:kKeyRec glyph:@"" lit:recording color:sv::rec() wide:false];
    [self drawKey:kKeyFwd glyph:@"" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyNext glyph:@"" lit:false color:sv::copper() wide:false];
    [self drawKey:kKeyLoop glyph:@"CYCLE" lit:cycle color:sv::copper() wide:true];
    [self drawKey:kKeyClick glyph:@"CLICK" lit:p.metronomeEnabled color:sv::copper() wide:true];

    // Cycle range, as far as the window is wide enough (the project name is in the title bar and the status line)
    CGFloat spare = (b.size.width - 244) - (x + 14);
    CGFloat lx = x + 14;
    if (spare >= 168) {
        const NSRect loc = NSMakeRect(lx, top, 160, lcdH);
        sv::lcd(loc, 8.0);
        sv::text(@"LOCATORS", NSMakePoint(loc.origin.x + 10, top + 5), sv::ui(10, true), sv::lcdDim());
        NSString* l = @"L  —", *r = @"R  —";
        if (ready) {
            const auto& t = c.core->engine().transport();
            if (t.cycleEndSample() > t.cycleStartSample()) {
                l = [NSString stringWithFormat:@"L  %@", sv::ns(formatBarsBeats(p.tempoMap, t.cycleStartSample()))];
                r = [NSString stringWithFormat:@"R  %@", sv::ns(formatBarsBeats(p.tempoMap, t.cycleEndSample()))];
            }
        }
        sv::text(l, NSMakePoint(loc.origin.x + 10, top + 23), sv::mono(11), cycle ? sv::copper() : sv::lcdValue());
        sv::text(r, NSMakePoint(loc.origin.x + 10, top + 38), sv::mono(11), cycle ? sv::copper() : sv::lcdValue());
        lx = NSMaxX(loc) + 8;
        spare -= 168;
    }
    (void)lx;

    [self drawMasterMeter:b];
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    SilvetonController* c = self.controller;
    if (NSPointInRect(p, _counterRect)) { [c gotoPositionDialog:nil]; return; }
    if (NSPointInRect(p, _signatureRect)) { [c editSignature:nil]; return; }
    if (NSPointInRect(p, _tempoRect)) { [c editTempo:nil]; return; }
    if (NSPointInRect(p, _meterRect)) {   // click: clear the clip lamp and the peak read-out
        SVStrip master;
        master.kind = SVStripKind::Master;
        [c resetMetersForStrip:master all:(event.modifierFlags & NSEventModifierFlagOption) != 0];
        return;
    }
    for (int k = 0; k < kKeyCount; ++k) {
        if (!NSPointInRect(p, _keys[k])) continue;
        switch (k) {
            case kKeyPrev: [c previousMarker:nil]; break;
            case kKeyRew: [c rewindBar:nil]; break;
            case kKeyStop: [c stop:nil]; break;
            case kKeyPlay: [c togglePlay:nil]; break;
            case kKeyRec: [c record:nil]; break;
            case kKeyFwd: [c forwardBar:nil]; break;
            case kKeyNext: [c nextMarker:nil]; break;
            case kKeyLoop: [c toggleCycle:nil]; break;
            case kKeyClick: [c toggleMetronome:nil]; break;
            default: break;
        }
        [self setNeedsDisplay:YES];
        return;
    }
}
@end

// ========================================================= Arrange view ==
namespace {
constexpr CGFloat kHeaderW = 264.0;
constexpr CGFloat kRulerH = 26.0;
constexpr CGFloat kMarkerH = 20.0;
constexpr CGFloat kSectionH = 20.0;
constexpr CGFloat kTempoH = 40.0;   // the tempo track under the arranger row (View > Tempo Track)
bool& tempoShown() { static bool shown = false; return shown; }
inline CGFloat topH() { return kRulerH + kMarkerH + kSectionH + (tempoShown() ? kTempoH : 0.0); }
constexpr CGFloat kTempoY = kRulerH + kMarkerH + kSectionH;
constexpr CGFloat kTrackH = 64.0;   // tall enough for a readable stereo waveform (Cubase draws its events about this tall)
constexpr CGFloat kFolderH = 28.0;
constexpr CGFloat kMinTrackH = 32.0;
constexpr CGFloat kMaxTrackH = 640.0;
constexpr CGFloat kEdgeGrabH = 5.0;   // how close to the bottom edge of a header the mouse must be to resize it
constexpr CGFloat kPillW = 20.0, kPillH = 18.0, kPillStep = 22.0;

enum class DragMode { None, MoveTrackHeader, Ruler, NewSection, MoveClip, TrimLeft, TrimRight, MovePart, ResizeRow, Range, ZoomBox, DrawPart, Marquee, MoveSelection, AutoPoint, AutoDraw, CompRange, TempoPoint };

struct Hit {
    long row {-1};
    bool header {false};
    std::uint64_t clip {0U};
    std::uint64_t part {0U};
    bool legacyPart {false};
    int edge {0};   // -1 left, +1 right
    std::int64_t sample {0};
};

// Heights the user chose for single tracks (drag the bottom edge of a header, or View > Track Height).
std::map<std::uint64_t, CGFloat>& chosenHeights() {
    static std::map<std::uint64_t, CGFloat> heights;
    return heights;
}
std::uint64_t rowKey(const ArrangeRow& r) { return (static_cast<std::uint64_t>(r.kind) << 56) | static_cast<std::uint64_t>(r.index); }
// The audio tracks whose automation lanes (Volume, Pan, Mute) are open under the track.
std::set<std::size_t>& automationOpen() {
    static std::set<std::size_t> open;
    return open;
}
constexpr int kLaneCount = 3;          // 0 = Volume, 1 = Pan, 2 = Mute
constexpr CGFloat kLaneH = 40.0;
int laneCount(const ArrangeRow& r) { return r.kind == ArrangeRowKind::Audio && automationOpen().count(r.index) ? kLaneCount : 0; }
// The track's own part of the row (the clips); the lanes hang under it.
CGFloat baseRowHeight(const ArrangeRow& r) {
    if (r.kind == ArrangeRowKind::Folder) return kFolderH;
    const auto it = chosenHeights().find(rowKey(r));
    return it == chosenHeights().end() ? kTrackH : it->second;
}
// The audio tracks whose take lanes (the recorded takes) are open, and how many lanes each has
// (filled in at paint time from the project, so the row heights can be computed without it).
std::set<std::size_t>& takesOpen() {
    static std::set<std::size_t> open;
    return open;
}
std::map<std::size_t, int>& takeLaneCounts() {
    static std::map<std::size_t, int> counts;
    return counts;
}
constexpr CGFloat kTakeH = 44.0;
int takeCount(const ArrangeRow& r) {
    if (r.kind != ArrangeRowKind::Audio || !takesOpen().count(r.index)) return 0;
    const auto it = takeLaneCounts().find(r.index);
    return it == takeLaneCounts().end() ? 0 : it->second;
}
CGFloat rowHeight(const ArrangeRow& r) { return baseRowHeight(r) + kTakeH * takeCount(r) + kLaneH * laneCount(r); }
// Where the automation lanes start under a track: after its take lanes.
CGFloat lanesTop(const ArrangeRow& r) { return baseRowHeight(r) + kTakeH * takeCount(r); }
const char* laneName(int lane) { return lane == 0 ? "Volume" : (lane == 1 ? "Pan" : "Mute"); }
// Lane values on a 0..1 scale (0 = bottom of the lane): volume follows the fader law, pan is linear, mute is 0 / 1.
double laneUnit(int lane, float v) {
    if (lane == 0) return faderPositionForDb(v);
    if (lane == 1) return (std::max(-1.0, std::min(1.0, static_cast<double>(v))) + 1.0) * 0.5;
    return v >= 0.5F ? 1.0 : 0.0;
}
float laneValue(int lane, double unit) {
    unit = std::max(0.0, std::min(1.0, unit));
    if (lane == 0) return static_cast<float>(dbForFaderPosition(unit));
    if (lane == 1) return static_cast<float>(unit * 2.0 - 1.0);
    return unit >= 0.5 ? 1.0F : 0.0F;
}
NSString* laneValueText(int lane, float v) {
    if (lane == 0) return v <= -95.0F ? @"−∞ dB" : [NSString stringWithFormat:@"%+.1f dB", static_cast<double>(v)];
    if (lane == 1) return std::abs(v) < 0.005F ? @"C" : [NSString stringWithFormat:@"%@%d", v < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(v) * 100.0F))];
    return v >= 0.5F ? @"Muted" : @"On";
}
const AutomationLane* laneOf(const Project& p, std::size_t track, int lane) {
    if (track >= p.tracks.size()) return nullptr;
    const auto& t = p.tracks[track];
    return lane == 0 ? &t.gainAutomationDb : (lane == 1 ? &t.panAutomation : &t.muteAutomation);
}
float laneStatic(const Project& p, std::size_t track, int lane) {
    if (track >= p.tracks.size()) return 0.0F;
    const auto& t = p.tracks[track];
    return lane == 0 ? t.gainDb : (lane == 1 ? t.pan : (t.mute ? 1.0F : 0.0F));
}

std::uint32_t rowColor(const Project& p, const ArrangeRow& r) {
    switch (r.kind) {
        case ArrangeRowKind::Folder: return r.index < p.folders.size() && p.folders[r.index].color ? p.folders[r.index].color : 0x8A8FB8U;
        case ArrangeRowKind::Audio: return effectiveTrackColor(p, r.index);
        case ArrangeRowKind::Midi: {
            if (r.index < p.midiTracks.size() && p.midiTracks[r.index].color) return p.midiTracks[r.index].color;
            const int inst = instrumentTrackForPort(p, r.index < p.midiTracks.size() ? p.midiTracks[r.index].outputPort : -1);
            return inst >= 0 ? effectiveTrackColor(p, static_cast<std::size_t>(inst)) : silvetonPaletteColor(r.index + 7U);
        }
    }
    return 0x999999U;
}

// A piece of a file the sample zoom asked the waveform cache for.
struct SVWindowWait { std::string path; std::uint64_t start; std::uint64_t frames; };

// Pill hit rects inside a header row starting at y.
NSRect pillRect(const ArrangeRow& r, CGFloat y, int i) {
    if (r.kind == ArrangeRowKind::Folder) return NSMakeRect(kHeaderW - 54 + i * kPillStep, y + 5, kPillW, kPillH);
    return NSMakeRect(kHeaderW - 98 + i * kPillStep, y + 7, kPillW, kPillH);
}
} // namespace

@implementation SilvetonArrangeView {
    std::vector<ArrangeRow> _rows;
    DragMode _drag;
    std::int64_t _dragAnchor;
    std::int64_t _dragCurrent;
    std::int64_t _grabOffset;
    double _grabOffsetQ;
    std::size_t _dragTrack;
    std::uint64_t _dragId;
    BOOL _gestureOpen;
    BOOL _moved;
    NSPoint _downPoint;
    BOOL _externalDrag;
    CGFloat _lastPlayheadX;
    std::uint32_t _lastMeterSignature;
    NSTrackingArea* _tracking;
    std::uint64_t _resizeKey;
    CGFloat _resizeStartH;
    // Range selection: a span of time over the rows from _rangeRowA to _rangeRowB (row keys, so the range
    // survives a change of the track list; the indices are the last known positions).
    BOOL _hasRange;
    std::int64_t _rangeStart;
    std::int64_t _rangeEnd;
    std::uint64_t _rangeKeyA, _rangeKeyB;
    long _rangeRowA, _rangeRowB;
    std::int64_t _rangeAnchor;       // the fixed end while the range is dragged
    long _rangeAnchorRow;
    long _dropRow;                  // mouse target for moving the track header
    long _dragRow;                   // the row the Draw tool works in
    std::set<SVSelectedEvent> _selectedEvents; // selected clips and MIDI parts, with track-aware IDs
    std::set<SVSelectedEvent> _marqueeBase;
    std::vector<SVEventMoveOrigin> _moveOrigins;
    std::int64_t _marqueeSampleA, _marqueeSampleB;
    long _marqueeRowA, _marqueeRowB;
    int _marqueeSelectionMode; // 0 replace, 1 union, 2 toggle, 3 subtract
    BOOL _duplicateOnDrag;
    std::int64_t _lastMoveDelta;
    std::vector<SVWindowWait> _windowWait;   // pieces of files asked for the sample zoom: the timer repaints when they arrive
    // Automation lanes: the selected point (track, lane, its sample) and the drag in progress.
    long _autoTrack;
    int _autoLane;
    std::int64_t _autoPointSample;    // -1 = none
    std::int64_t _autoDragSample;
    float _autoDragValue;
    std::int64_t _autoLastDrawSample;
    // Take lanes: the lane and clip a comp drag works in
    std::uint64_t _compLaneId, _compClipId;
    std::int64_t _compClipStart, _compClipEnd;
    // Tempo track: the selected tempo change (its sample, -1 = none) and the drag
    std::int64_t _tempoSel;
    std::int64_t _tempoDragSample;
    double _tempoDragBpm;
    BOOL _dragScrolled;   // the last drag event scrolled the view: a partial repaint would be wrong
}
- (instancetype)initWithFrame:(NSRect)frame {
    if ((self = [super initWithFrame:frame])) {
        [self registerForDraggedTypes:@[NSPasteboardTypeFileURL]];
        _autoTrack = -1; _autoLane = -1; _autoPointSample = -1; _autoLastDrawSample = -1; _tempoSel = -1;
    }
    return self;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (TimelineMapping)mapping {
    TimelineMapping m;
    const Project* p = self.controller.project;
    m.sampleRate = p && p->sampleRate > 0 ? p->sampleRate : 48000.0;
    m.pixelsPerSecond = self.controller.pixelsPerSecond;
    m.originX = kHeaderW;
    m.scrollSeconds = self.scrollSeconds;
    return m;
}

- (CGFloat)contentHeight {
    CGFloat h = 0;
    for (const auto& r : _rows) h += rowHeight(r);
    return h;
}

- (BOOL)ensurePlayheadVisible {
    const auto m = [self mapping];
    const double x = m.xForSample(self.controller.playheadSample);
    const double right = self.bounds.size.width - 40;
    if (x > right) { self.scrollSeconds += (x - kHeaderW - (right - kHeaderW) * 0.25) / m.pixelsPerSecond; return YES; }
    if (x < kHeaderW) { self.scrollSeconds = std::max(0.0, static_cast<double>(self.controller.playheadSample) / m.sampleRate - 1.0); return YES; }
    return NO;
}

// Called by the UI timer. Instead of repainting the whole canvas 20 times a
// second, only the thin stripe around the playhead and the level-meter column
// are invalidated (and only when they actually changed).
- (void)tickAnimation {
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    const NSRect b = self.bounds;
    const auto m = [self mapping];
    const CGFloat px = m.xForSample(c.playheadSample);
    if (std::abs(px - _lastPlayheadX) >= 0.5) {
        const CGFloat lo = std::min(px, _lastPlayheadX) - 8.0, hi = std::max(px, _lastPlayheadX) + 8.0;
        [self setNeedsDisplayInRect:NSIntersectionRect(NSMakeRect(lo, 0, hi - lo, b.size.height), b)];
        _lastPlayheadX = px;
    }
    const std::uint32_t sig = [c meterSignature];
    if (sig != _lastMeterSignature) {
        _lastMeterSignature = sig;
        [self setNeedsDisplayInRect:NSMakeRect(kHeaderW - 10, topH(), 10, std::max<CGFloat>(0, b.size.height - topH()))];
    }
    if (!_windowWait.empty() && c.core) {   // a piece of a file for the sample zoom arrived: show it
        auto& cache = c.core->waveformCache();
        for (const auto& w : _windowWait) {
            auto win = cache.findWindow(w.path);
            if (win && win->covers(w.start, w.frames)) { _windowWait.clear(); [self setNeedsDisplay:YES]; break; }
        }
    }
}

- (void)drawRect:(NSRect)dirty {
    // Paint each invalid rectangle on its own (a thin playhead stripe and the
    // meter column are far apart; their bounding box would be most of the view).
    const NSRect* rects = nullptr;
    NSInteger count = 0;
    [self getRectsBeingDrawn:&rects count:&count];
    if (count <= 0 || count > 6 || !rects) { [self paintRect:dirty]; return; }
    for (NSInteger i = 0; i < count; ++i) {
        [NSGraphicsContext saveGraphicsState];
        NSRectClip(rects[i]);
        [self paintRect:rects[i]];
        [NSGraphicsContext restoreGraphicsState];
    }
}

- (void)paintRect:(NSRect)dirty {
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    const Project& p = *c.project;
    for (std::size_t t : takesOpen()) takeLaneCounts()[t] = t < p.tracks.size() ? static_cast<int>(p.tracks[t].takeLanes.size()) : 0;
    _rows = buildArrangeRows(p);
    const auto map = [self mapping];
    const CGFloat laneW = std::max<CGFloat>(0, b.size.width - kHeaderW);
    const double sr = map.sampleRate;
    self.scrollY = std::max(0.0, std::min(self.scrollY, std::max(0.0, static_cast<double>([self contentHeight] - (b.size.height - topH()) + 40))));
    if (_windowWait.size() > 64U) _windowWait.erase(_windowWait.begin(), _windowWait.begin() + 32);
    // Zoomed in to single samples, clips and parts are millions of pixels wide: what is drawn as a
    // shape is cut to the window plus a margin (the rounded corners then lie off screen).
    const CGFloat wideLo = -200.0, wideHi = b.size.width + 200.0;
    auto clampWideX = [&](CGFloat x) { return std::max(wideLo, std::min(wideHi, x)); };
    auto clampWide = [&](NSRect r) {
        const CGFloat x0 = clampWideX(r.origin.x), x1 = clampWideX(NSMaxX(r));
        return NSMakeRect(x0, r.origin.y, std::max<CGFloat>(1.0, x1 - x0), r.size.height);
    };

    // 1. lane backgrounds
    CGFloat y = topH() - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const auto& r = _rows[i];
        const CGFloat h = rowHeight(r);
        bool sel = false;
        if (r.kind == ArrangeRowKind::Audio) sel = static_cast<long>(r.index) == c.selectedTrack || [c trackMarked:r.index];
        if (r.kind == ArrangeRowKind::Midi) sel = static_cast<long>(r.index) == c.selectedMidiTrack;
        if (r.kind == ArrangeRowKind::Folder) sel = static_cast<long>(r.index) == c.selectedFolder;
        if (y + h >= topH() && y <= b.size.height)
            sv::fill(NSMakeRect(kHeaderW, y, laneW, h - 1), sel ? sv::laneSel() : (i % 2 ? sv::laneB() : sv::laneA()));
        y += h;
    }

    // 2. grid
    const auto grid = buildGrid(p.tempoMap, map, laneW);
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(kHeaderW, topH(), laneW, b.size.height - topH()));
    for (const auto& g : grid) {
        const CGFloat gx = std::floor(map.xForSample(g.sample)) + 0.5;
        if (gx < dirty.origin.x - 1 || gx > NSMaxX(dirty) + 1) continue;
        NSColor* col = g.level == 0 ? sv::hex(0x30333B) : (g.level == 1 ? sv::hex(0x24272D) : sv::hex(0x1C1D22));
        sv::line(NSMakePoint(gx, topH()), NSMakePoint(gx, b.size.height), col);
    }
    // arranger sections tint the lanes lightly
    for (const auto& s : p.arrangerSections) {
        const CGFloat x0 = map.xForSample(s.startSample), x1 = map.xForSample(s.endSample);
        sv::fill(NSMakeRect(x0, topH(), x1 - x0, b.size.height - topH()), sv::hex(s.color, 0.035));
    }

    // 3. clips / parts
    y = topH() - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const auto& r = _rows[i];
        const CGFloat hFull = rowHeight(r);
        const CGFloat h = baseRowHeight(r);   // the clips live in the track's own part of the row
        if (y + hFull < topH() || y > b.size.height || r.kind == ArrangeRowKind::Folder) { y += hFull; continue; }
        NSColor* base = sv::hex(rowColor(p, r));
        NSColor* tone = [base blendedColorWithFraction:0.32 ofColor:sv::hex(0x9AA0AC)];   // the track colour, calmed down
        if (takeCount(r) > 0) [self drawTakesOfTrack:r.index top:y + h dirty:dirty map:map];
        if (laneCount(r) > 0) [self drawLanesOfTrack:r.index top:y + lanesTop(r) dirty:dirty map:map];
        if (r.kind == ArrangeRowKind::Audio && r.index < p.tracks.size()) {
            const auto& t = p.tracks[r.index];
            for (const auto& clip : t.clips) {
                const CGFloat x0 = map.xForSample(clip.timelineStartSample);
                const CGFloat x1 = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples));
                if (x1 < kHeaderW || x0 > b.size.width) continue;
                const NSRect cr = NSMakeRect(x0, y + 2, std::max<CGFloat>(3, x1 - x0), h - 5);
                if (!NSIntersectsRect(cr, dirty)) continue;
                // Zoomed in to single samples a clip is millions of pixels wide: the body that is
                // drawn is cut to the screen (plus a margin), the waveform keeps the true geometry.
                const NSRect cd = clampWide(cr);
                const bool sel = !_selectedEvents.empty()
                    ? _selectedEvents.count(SVSelectedEvent {false, r.index, clip.id}) != 0
                    : clip.id == c.selectedClipId && static_cast<long>(r.index) == c.selectedTrack;
                // Body in neutral graphite (the track's colour is only a thin bar along the top); the sound
                // fills the whole height, the name is a small plate in the corner (as in Cubase).
                sv::roundFill(cd, 6, sv::hex(sel ? 0x33373E : 0x2A2D33));
                [NSGraphicsContext saveGraphicsState];
                [[NSBezierPath bezierPathWithRoundedRect:cd xRadius:6 yRadius:6] addClip];
                sv::fill(NSMakeRect(cd.origin.x, cd.origin.y, cd.size.width, 3), tone);
                [NSGraphicsContext restoreGraphicsState];
                sv::roundStroke(cd, 6, sv::hex(0x15171B), 1.0);
                const std::string& path = clip.audioPath.empty() ? t.audioPath : clip.audioPath;
                auto& cache = c.core->waveformCache();
                cache.request(path);
                NSColor* waveColour = sv::hex(sel ? 0xDADDE2 : 0xC4C8CF);   // light grey on graphite: readable, no colour noise
                const NSRect wr = NSMakeRect(cr.origin.x + 1, cr.origin.y + 2, cr.size.width - 2, cr.size.height - 4);
                const double waveGain = c.waveZoom;
                bool samplesDrawn = false;
                if (auto ov = cache.find(path)) {
                    // Single samples: once a file sample is 2 px or wider, the piece on screen is read sample by sample.
                    const double fileRate = ov->sampleRate > 0U ? static_cast<double>(ov->sampleRate) : p.sampleRate;
                    const double pxPerFileFrame = map.pixelsPerSecond / fileRate;
                    if (pxPerFileFrame >= 2.0 && wr.size.width >= 1.0) {
                        const double fileFramesPerClipFrame = fileRate / p.sampleRate;
                        const auto srcStart = static_cast<std::uint64_t>(std::llround(static_cast<double>(clip.sourceStartSample) * fileFramesPerClipFrame));
                        const auto srcLen = std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::llround(static_cast<double>(clip.lengthSamples) * fileFramesPerClipFrame)));
                        const double v0 = std::max(0.0, (std::max(dirty.origin.x, kHeaderW) - wr.origin.x) / pxPerFileFrame);
                        const double v1 = std::min(static_cast<double>(srcLen), (std::min(NSMaxX(dirty), b.size.width) - wr.origin.x) / pxPerFileFrame);
                        if (v1 > v0) {
                            const std::uint64_t need0 = srcStart + static_cast<std::uint64_t>(std::floor(v0));
                            const std::uint64_t needN = static_cast<std::uint64_t>(std::ceil(v1 - std::floor(v0))) + 2U;
                            auto win = cache.findWindow(path);
                            if (win && win->covers(need0, needN)) {
                                sv::drawSamples(*win, srcStart, srcLen, wr, waveColour, std::max(dirty.origin.x, kHeaderW), std::min(NSMaxX(dirty), b.size.width), waveGain);
                                samplesDrawn = true;
                            } else {
                                // ask for a piece wider than the screen, so a scroll does not read again at once
                                const std::uint64_t pad = std::max<std::uint64_t>(needN * 2U, 8192U);
                                const std::uint64_t reqStart = need0 > pad ? need0 - pad : 0U;
                                cache.requestWindow(path, reqStart, needN + 2U * pad);
                                _windowWait.push_back({path, need0, needN});
                            }
                        }
                    }
                    if (!samplesDrawn) {
                        const bool combine = ov->channels > 1U && wr.size.height / static_cast<CGFloat>(std::min<std::uint32_t>(ov->channels, 2U)) < 18.0;
                        sv::drawWaveform(*ov, clip.sourceStartSample, clip.lengthSamples, wr, waveColour, false, dirty.origin.x, NSMaxX(dirty), p.sampleRate, waveGain, combine);
                    }
                }
                // the name: a small dark plate in the top-left corner, over the sound
                NSString* nm = [[sv::ns(clip.audioPath) lastPathComponent] stringByDeletingPathExtension];
                if (cr.origin.x >= cd.origin.x - 1.0 && cd.size.width > 24.0) {   // the plate sits at the real start of the clip
                    const CGFloat nw = std::min<CGFloat>(cd.size.width - 8.0, std::ceil(sv::textSize(nm, sv::ui(10, true)).width) + 10.0);
                    sv::roundFill(NSMakeRect(cr.origin.x + 3, cr.origin.y + 3, nw, 14), 3, sv::rgb(0.04, 0.04, 0.05, 0.62));
                    sv::textIn(nm, NSMakeRect(cr.origin.x + 8, cr.origin.y + 3, nw - 8, 14), sv::ui(10, true), sv::hex(0xF2F2F0));
                }
                // fades
                if (clip.fadeInSamples) {
                    const CGFloat fx = clampWideX(map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.fadeInSamples)));
                    sv::line(NSMakePoint(cd.origin.x, NSMaxY(cd)), NSMakePoint(fx, cd.origin.y + 2), sv::amber(), 1.2);
                }
                if (clip.fadeOutSamples) {
                    const CGFloat fx = clampWideX(map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples - clip.fadeOutSamples)));
                    sv::line(NSMakePoint(fx, cd.origin.y + 2), NSMakePoint(NSMaxX(cd), NSMaxY(cd)), sv::amber(), 1.2);
                }
                if (clip.mute) sv::roundFill(cd, 6, sv::rgb(0.05, 0.05, 0.06, 0.6));
                if (sel) sv::roundStroke(cd, 6, sv::ink(), 2.0);
            }
            // live recording take
            if (c.core->recording() && c.core->recordingTrackIndex() == static_cast<long>(r.index)) {
                const auto st = c.core->recording()->status();
                if (st.framesAccepted > 0U) {
                    const CGFloat x0 = map.xForSample(c.core->recordingStartSample());
                    const CGFloat x1 = map.xForSample(c.core->recordingStartSample() + static_cast<std::int64_t>(st.framesAccepted));
                    const NSRect rr = NSMakeRect(x0, y + 2, std::max<CGFloat>(3, x1 - x0), h - 5);
                    sv::roundFill(rr, 5, sv::rgb(0.55, 0.14, 0.12, 0.85));
                    const auto live = c.core->recording()->waveformPreview(0U, st.framesAccepted,
                        static_cast<std::size_t>(std::max<CGFloat>(64, std::min<CGFloat>(4096, rr.size.width))));
                    sv::drawWaveform(live, 0U, live.frames, NSInsetRect(rr, 1, 3), sv::ink(), false);
                    sv::roundStroke(rr, 5, sv::rec(), 1.5);
                }
            }
        } else if (r.kind == ArrangeRowKind::Midi && r.index < p.midiTracks.size()) {
            const auto& mt = p.midiTracks[r.index];
            auto drawPart = [&](const MidiSequence& seq, double startQ, double offsetQ, double lenQ, std::uint64_t id, bool muted) {
                const CGFloat x0 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(startQ));
                const CGFloat x1 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(startQ + lenQ));
                if (x1 < kHeaderW || x0 > b.size.width) return;
                const NSRect pr = clampWide(NSMakeRect(x0, y + 2, std::max<CGFloat>(3, x1 - x0), h - 5));
                if (!NSIntersectsRect(pr, dirty)) return;
                const bool sel = !_selectedEvents.empty()
                    ? _selectedEvents.count(SVSelectedEvent {true, r.index, id}) != 0
                    : static_cast<long>(r.index) == c.selectedMidiTrack && id == c.selectedPartId;
                sv::roundFill(pr, 6, sv::hex(sel ? 0x33373E : 0x2A2D33));
                [NSGraphicsContext saveGraphicsState];
                [[NSBezierPath bezierPathWithRoundedRect:pr xRadius:6 yRadius:6] addClip];
                sv::fill(NSMakeRect(pr.origin.x, pr.origin.y, pr.size.width, 3), tone);
                [NSGraphicsContext restoreGraphicsState];
                sv::roundStroke(pr, 6, sv::hex(0x15171B), 1.0);
                int lo = 127, hi = 0;
                for (const auto& n : seq.notes()) { lo = std::min<int>(lo, n.pitch); hi = std::max<int>(hi, n.pitch); }
                if (hi < lo) { lo = 60; hi = 72; }
                const double span = std::max(6, hi - lo + 1);
                [NSGraphicsContext saveGraphicsState];
                NSRectClip(pr);
                for (const auto& n : seq.notes()) {
                    if (n.muted) continue;
                    const double qs = startQ + (n.startQuarterNotes - offsetQ);
                    if (qs + n.durationQuarterNotes < startQ || qs > startQ + lenQ) continue;
                    const CGFloat nx0 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(qs));
                    const CGFloat nx1 = map.xForSample(p.tempoMap.sampleAtQuarterNotes(qs + n.durationQuarterNotes));
                    const CGFloat ny = pr.origin.y + 18 + (pr.size.height - 22) * (1.0 - (n.pitch - lo + 0.5) / span);
                    sv::fill(NSMakeRect(nx0, ny - 1, std::max<CGFloat>(2, nx1 - nx0 - 1), 2), sv::hex(0xC4C8CF));
                }
                [NSGraphicsContext restoreGraphicsState];
                if (muted) sv::roundFill(pr, 6, sv::rgb(0.05, 0.05, 0.06, 0.6));
                if (sel) sv::roundStroke(pr, 6, sv::ink(), 2.0);
            };
            if (mt.parts.empty()) {
                double end = 0;
                for (const auto& n : mt.sequence.notes()) end = std::max(end, n.startQuarterNotes + n.durationQuarterNotes);
                if (end > 0) drawPart(mt.sequence, 0.0, 0.0, std::ceil(end / 4.0) * 4.0, 0U, mt.mute);
            } else {
                for (const auto& part : mt.parts)
                    drawPart(part.sequence, part.timelineStartQuarterNotes, part.sourceOffsetQuarterNotes, part.lengthQuarterNotes, part.id, part.muted || mt.mute);
            }
        }
        y += hFull;
    }

    // 3b. the range selection: a light pane over the rows it covers, with firm edges
    long ra = 0, rb = 0;
    const bool rangeRowsKnown = [self hasRange] && [self rangeRowIndicesFrom:&ra to:&rb];
    if ([self hasRange] && (rangeRowsKnown || _rows.empty())) {
        const CGFloat x0 = clampWideX(std::floor(map.xForSample(_rangeStart))), x1 = clampWideX(std::ceil(map.xForSample(_rangeEnd)));
        const CGFloat ry0 = rangeRowsKnown ? [self topOfRow:ra] : topH();
        const CGFloat ry1 = rangeRowsKnown ? [self topOfRow:rb] + rowHeight(_rows[static_cast<std::size_t>(rb)]) - 1.0 : b.size.height;
        const NSRect rr = NSMakeRect(x0, ry0, std::max<CGFloat>(2.0, x1 - x0), ry1 - ry0);
        if (NSIntersectsRect(rr, dirty)) {
            // An outline-only range leaves waveforms, parts and labels fully visible.
            sv::fill(NSMakeRect(rr.origin.x, rr.origin.y, 1.0, rr.size.height), sv::hex(0xE8EAEE, 0.9));
            sv::fill(NSMakeRect(NSMaxX(rr) - 1.0, rr.origin.y, 1.0, rr.size.height), sv::hex(0xE8EAEE, 0.9));
            sv::fill(NSMakeRect(rr.origin.x, rr.origin.y, rr.size.width, 1.0), sv::hex(0xE8EAEE, 0.6));
            sv::fill(NSMakeRect(rr.origin.x, NSMaxY(rr) - 1.0, rr.size.width, 1.0), sv::hex(0xE8EAEE, 0.6));
        }
    }
    // Object-selection marquee, on top of events. Its boundaries follow timeline samples
    // and rows rather than raw pixels, including when the view scrolls while dragging.
    if (_drag == DragMode::Marquee && _moved && !_rows.empty()) {
        const CGFloat x0 = map.xForSample(std::min(_marqueeSampleA, _marqueeSampleB));
        const CGFloat x1 = map.xForSample(std::max(_marqueeSampleA, _marqueeSampleB));
        const long ra = std::max<long>(0, std::min(_marqueeRowA, _marqueeRowB));
        const long rb = std::min<long>(static_cast<long>(_rows.size()) - 1, std::max(_marqueeRowA, _marqueeRowB));
        if (ra <= rb) {
            const CGFloat ry = [self topOfRow:ra];
            const CGFloat by = [self topOfRow:rb] + rowHeight(_rows[static_cast<std::size_t>(rb)]);
            const NSRect selectionRect = NSIntersectionRect(NSMakeRect(x0, ry, std::max<CGFloat>(1, x1-x0), by-ry),
                                                            NSMakeRect(kHeaderW, topH(), laneW, b.size.height-topH()));
            if (!NSIsEmptyRect(selectionRect)) {
                // Outline-only marquee: do not obscure the track events while dragging.
                NSBezierPath* border = [NSBezierPath bezierPathWithRect:NSInsetRect(selectionRect, .5, .5)];
                CGFloat dash[] = {5.0, 3.0};
                [border setLineDash:dash count:2 phase:0];
                [border setLineWidth:1.2];
                [sv::hex(0xE8EAEE, 0.9) setStroke];
                [border stroke];
            }
        }
    }
    // the Zoom tool's box and the Draw tool's new part while the mouse is down
    if (_drag == DragMode::ZoomBox && _moved) {
        const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
        sv::fill(NSMakeRect(x0, topH(), x1 - x0, b.size.height - topH()), sv::hex(0xFFFFFF, 0.10));
        sv::fill(NSMakeRect(x0, topH(), 1.0, b.size.height - topH()), sv::hex(0xFFFFFF, 0.5));
        sv::fill(NSMakeRect(x1, topH(), 1.0, b.size.height - topH()), sv::hex(0xFFFFFF, 0.5));
    }
    if (_drag == DragMode::DrawPart && _moved && _dragRow >= 0 && _dragRow < static_cast<long>(_rows.size())) {
        const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
        const CGFloat ry = [self topOfRow:_dragRow];
        sv::roundFill(NSMakeRect(x0, ry + 2, std::max<CGFloat>(3, x1 - x0), rowHeight(_rows[static_cast<std::size_t>(_dragRow)]) - 5), 6, [sv::copper() colorWithAlphaComponent:0.35]);
        sv::roundStroke(NSMakeRect(x0, ry + 2, std::max<CGFloat>(3, x1 - x0), rowHeight(_rows[static_cast<std::size_t>(_dragRow)]) - 5), 6, sv::copper(), 1.0);
    }
    [NSGraphicsContext restoreGraphicsState];

    // 4. headers
    sv::fill(NSMakeRect(0, topH(), kHeaderW, b.size.height - topH()), sv::hex(0x16181C));   // the console surface behind the channel plates
    y = topH() - self.scrollY;
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(0, topH(), kHeaderW, b.size.height - topH()));
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const auto& r = _rows[i];
        const CGFloat h = rowHeight(r);
        if (y + h < topH() || y > b.size.height || !NSIntersectsRect(NSMakeRect(0, y, kHeaderW, h), dirty)) { y += h; continue; }
        const CGFloat indent = r.depth * 12.0;
        NSColor* col = [sv::hex(rowColor(p, r)) blendedColorWithFraction:0.25 ofColor:sv::hex(0x9AA0AC)];
        bool sel = false;
        sv::line(NSMakePoint(0, y + h - 0.5), NSMakePoint(kHeaderW, y + h - 0.5), sv::hairline());
        if (r.kind == ArrangeRowKind::Folder && r.index < p.folders.size()) {
            const auto& f = p.folders[r.index];
            sel = static_cast<long>(r.index) == c.selectedFolder;
            sv::brushedPanel(NSMakeRect(2, y + 1, kHeaderW - 4, h - 4), sel, true);
            sv::roundFill(NSMakeRect(5, y + 5, 5, h - 12), 2.5, col);
            sv::text(f.collapsed ? @"▸" : @"▾", NSMakePoint(12 + indent, y + 6), sv::ui(12, true), sv::inkDim());
            sv::engravedIn(sv::ns(f.name), NSMakeRect(32 + indent, y + 6, kHeaderW - 96 - indent, 16), sv::ui(12, true), sv::ink());
            bool allMute = true, anySolo = false, any = false;
            for (const auto& t : p.tracks) if (FolderTools::isInside(p, t.folder, f.id)) { any = true; allMute &= t.mute; anySolo |= t.solo; }
            sv::consoleKey(pillRect(r, y, 0), @"M", any && allMute, sv::muteTint());
            sv::consoleKey(pillRect(r, y, 1), @"S", anySolo, sv::soloTint());
        } else if (r.kind == ArrangeRowKind::Audio && r.index < p.tracks.size()) {
            const auto& t = p.tracks[r.index];
            sel = static_cast<long>(r.index) == c.selectedTrack || [c trackMarked:r.index];
            const CGFloat hAll = h;
            const CGFloat h = baseRowHeight(r);   // the track plate; the lane plates hang under it
            (void)hAll;
            sv::brushedPanel(NSMakeRect(2, y + 1, kHeaderW - 4, h - 4), sel, false);
            sv::roundFill(NSMakeRect(5, y + 5, 5, h - 12), 2.5, col);
            // the AUTO key opens the automation lanes under the track, TAKES the recorded takes (when there are any)
            if (h >= 60.0) {
                sv::consoleKey(NSMakeRect(34 + indent, y + h - 19, 44, 15), @"AUTO", automationOpen().count(r.index) != 0U, sv::amber());
                if (!t.takeLanes.empty())
                    sv::consoleKey(NSMakeRect(82 + indent, y + h - 19, 48, 15), @"TAKES", takesOpen().count(r.index) != 0U, sv::amber());
            }
            for (int tl = 0; tl < takeCount(r); ++tl) {
                const CGFloat ty = y + h + kTakeH * tl;
                sv::brushedPanel(NSMakeRect(14, ty + 1, kHeaderW - 16, kTakeH - 3), false, false);
                sv::roundFill(NSMakeRect(17, ty + 5, 3, kTakeH - 11), 1.5, [col colorWithAlphaComponent:0.7]);
                NSString* nm = static_cast<std::size_t>(tl) < t.takeLanes.size() ? sv::ns(t.takeLanes[static_cast<std::size_t>(tl)].name) : @"Take";
                sv::engraved(nm, NSMakePoint(28, ty + 6), sv::ui(10, true), sv::hex(0xC4C8CF));
                sv::engraved(@"click = use this take · drag = use a part of it", NSMakePoint(28, ty + 22), sv::ui(10), sv::hex(0x7A7E88));
                sv::consoleKey(NSMakeRect(kHeaderW - 60, ty + 12, 44, 17), @"USE", false, sv::amber());
            }
            for (int lane = 0; lane < laneCount(r); ++lane) {
                const CGFloat ly = y + lanesTop(r) + kLaneH * lane;
                sv::brushedPanel(NSMakeRect(14, ly + 1, kHeaderW - 16, kLaneH - 3), false, false);
                sv::roundFill(NSMakeRect(17, ly + 5, 3, kLaneH - 11), 1.5, [col colorWithAlphaComponent:0.7]);
                sv::engraved([NSString stringWithUTF8String:laneName(lane)], NSMakePoint(28, ly + 5), sv::ui(10, true), sv::hex(0xC4C8CF));
                const AutomationLane* al = laneOf(p, r.index, lane);
                const float shown = (_drag == DragMode::AutoPoint || _drag == DragMode::AutoDraw) && _autoTrack == static_cast<long>(r.index) && _autoLane == lane
                    ? _autoDragValue : (al ? al->valueAt(c.playheadSample, laneStatic(p, r.index, lane)) : laneStatic(p, r.index, lane));
                sv::text(laneValueText(lane, shown), NSMakePoint(28, ly + 21), sv::mono(10, true), sv::lcdValue());
                NSString* modeNames[5] = {@"OFF", @"READ", @"WRITE", @"TOUCH", @"LATCH"};
                const int mode = static_cast<int>([c automationMode:r.index lane:lane]);
                sv::consoleKey(NSMakeRect(kHeaderW - 72, ly + 11, 56, 17), modeNames[std::max(0, std::min(4, mode))], mode >= 2, sv::amber());
            }
            bool instrument = false;
            for (const auto& s2 : t.pluginSlots) if (s2.midiInputPort >= 0) instrument = true;
            sv::textIn([NSString stringWithFormat:@"%lu", (unsigned long)(r.index + 1)], NSMakeRect(8 + indent, y + 16, 22, 14), sv::mono(10), sv::inkFaint(), NSTextAlignmentCenter);
            sv::engravedIn(sv::ns(t.name.empty() ? std::string("Audio") : t.name), NSMakeRect(34 + indent, y + 6, kHeaderW - 138 - indent, 17), sv::ui(12, true), sv::ink());
            sv::engraved(instrument ? @"INSTRUMENT" : @"AUDIO", NSMakePoint(34 + indent, y + 26), sv::ui(10, true), sv::hex(0x8A8F9A));
            sv::consoleKey(pillRect(r, y, 0), @"M", t.mute, sv::muteTint());
            sv::consoleKey(pillRect(r, y, 1), @"S", t.solo, sv::soloTint());
            sv::consoleKey(pillRect(r, y, 2), @"●", t.recordArm, sv::rec());
            sv::consoleKey(pillRect(r, y, 3), @"I", t.monitor, sv::amber());
            // small fader: groove with a cap, the same scale as the mixer
            const CGFloat fx0 = kHeaderW - 98, fw = 86;
            // a narrow slot with the small charcoal cap of the mixer, lying on its side
            sv::fill(NSMakeRect(fx0 - 1, y + 34, fw + 2, 6), sv::hex(0x101216));
            sv::fill(NSMakeRect(fx0, y + 35, fw, 4), sv::hex(0x040506));
            sv::fill(NSMakeRect(fx0, y + 39, fw, 1), sv::hex(0x3A3E46));
            sv::fill(NSMakeRect(fx0 + 3, y + 36.5, fw - 6, 1), sv::hex(0x22252B));
            const CGFloat zx = std::round(fx0 + fw * faderPositionForDb(0.0)) + 0.5;
            sv::line(NSMakePoint(zx, y + 41), NSMakePoint(zx, y + 44), sv::hex(0x9AA0AC));   // the 0 dB mark
            const CGFloat capX = std::round(fx0 + fw * faderPositionForDb(t.gainDb));
            const NSRect capR = NSMakeRect(capX - 8, y + 29, 16, 16);
            sv::roundFill(NSOffsetRect(capR, 0, 2), 2.0, sv::rgb(0, 0, 0, 0.45));
            sv::gradientIn([NSBezierPath bezierPathWithRoundedRect:capR xRadius:2.0 yRadius:2.0], sv::hex(0x3B3E45), sv::hex(0x15171B));
            sv::roundStroke(capR, 2.0, sv::hex(0x08090B), 1.0);
            sv::gradientIn([NSBezierPath bezierPathWithRoundedRect:NSInsetRect(capR, 2, 2) xRadius:1.0 yRadius:1.0], sv::hex(0x474A52), sv::hex(0x1E2025));
            for (CGFloat k : {-5.0, 5.0}) sv::fill(NSMakeRect(capX + k - 0.5, capR.origin.y + 4, 1, capR.size.height - 8), sv::rgb(0, 0, 0, 0.55));
            sv::fill(NSMakeRect(capX - 2, capR.origin.y + 3, 4, capR.size.height - 6), sv::hex(0x0B0C0F));
            sv::fill(NSMakeRect(capX - 0.5, capR.origin.y + 4, 1, capR.size.height - 8), sv::hex(0xF4F2EA));
            if (t.locked) sv::text(@"🔒", NSMakePoint(kHeaderW - 128, y + 28), sv::ui(11), sv::inkDim());
            if (c.core->ready() && r.index < c.core->engine().trackCount()) {
                SVStrip strip;
                strip.kind = SVStripKind::Track;
                strip.index = r.index;
                const silveton::StereoMeterDisplay md = [c meterDisplayForStrip:strip];
                sv::sunkenWell(NSMakeRect(kHeaderW - 12, y + 3, 11, h - 6), 2.0, sv::hex(0x08090B));
                sv::meter::drawBar(NSMakeRect(kHeaderW - 10, y + 5, 3, h - 10), true, md.left.levelDb, md.left.holdDb, md.left.clip, false);
                sv::meter::drawBar(NSMakeRect(kHeaderW - 6, y + 5, 3, h - 10), true, md.right.levelDb, md.right.holdDb, md.right.clip, false);
            }
        } else if (r.kind == ArrangeRowKind::Midi && r.index < p.midiTracks.size()) {
            const auto& m = p.midiTracks[r.index];
            sel = static_cast<long>(r.index) == c.selectedMidiTrack;
            sv::brushedPanel(NSMakeRect(2, y + 1, kHeaderW - 4, h - 4), sel, false);
            sv::roundFill(NSMakeRect(5, y + 5, 5, h - 12), 2.5, col);
            if (r.drivesInstrument) sv::roundFill(NSMakeRect(11, y + 5, 2, h - 12), 1.0, [col colorWithAlphaComponent:0.5]);
            sv::engravedIn(sv::ns(m.name.empty() ? std::string("MIDI") : m.name), NSMakeRect(34 + indent, y + 6, kHeaderW - 138 - indent, 17), sv::ui(12, true), sv::ink());
            NSString* dest = @"NO OUTPUT";
            const int inst = instrumentTrackForPort(p, m.outputPort);
            if (inst >= 0) dest = [NSString stringWithFormat:@"MIDI → %@", sv::ns(p.tracks[static_cast<std::size_t>(inst)].name).uppercaseString];
            sv::engravedIn(dest, NSMakeRect(34 + indent, y + 26, kHeaderW - 138 - indent, 14), sv::ui(10, true), sv::hex(0x8A8F9A));
            sv::consoleKey(pillRect(r, y, 0), @"M", m.mute, sv::muteTint());
            sv::consoleKey(pillRect(r, y, 1), @"S", m.solo, sv::soloTint());
            if (m.transpose != 0 || m.velocityShift != 0)
                sv::text([NSString stringWithFormat:@"T%+d V%+d", m.transpose, m.velocityShift], NSMakePoint(kHeaderW - 98, y + 29), sv::mono(10), sv::amber());
        }
        y += h;
    }
    [NSGraphicsContext restoreGraphicsState];
    sv::line(NSMakePoint(kHeaderW - 0.5, 0), NSMakePoint(kHeaderW - 0.5, b.size.height), sv::hairline());

    // 5. top lanes: ruler, markers, arranger (brushed rails, engraved legends)
    sv::rail(NSMakeRect(0, 0, b.size.width, kRulerH));
    sv::bands(NSMakeRect(0, kRulerH, b.size.width, kMarkerH), 0x24272C, 0x202228);
    sv::bands(NSMakeRect(0, kRulerH + kMarkerH, b.size.width, kSectionH), 0x202228, 0x1C1E23);
    if (tempoShown()) sv::bands(NSMakeRect(0, kTempoY, b.size.width, kTempoH), 0x1C1E23, 0x181A1F);
    sv::fill(NSMakeRect(0, topH() - 1, b.size.width, 1), sv::hex(0x0C0D10));
    sv::engraved(@"RULER", NSMakePoint(14, 7), sv::ui(10, true), sv::hex(0x8A8F9A));
    sv::engraved(@"MARKERS", NSMakePoint(14, kRulerH + 4), sv::ui(10, true), sv::hex(0x8A8F9A));
    sv::engraved(@"ARRANGER", NSMakePoint(14, kRulerH + kMarkerH + 4), sv::ui(10, true), sv::hex(0x8A8F9A));
    if (tempoShown()) {
        sv::engraved(@"TEMPO", NSMakePoint(14, kTempoY + 4), sv::ui(10, true), sv::hex(0x8A8F9A));
        const double nowBpm = p.tempoMap.tempoAtSample(c.playheadSample);
        sv::text([NSString stringWithFormat:@"%.2f", nowBpm], NSMakePoint(14, kTempoY + 20), sv::mono(11, true), sv::lcdValue());
        sv::engraved(@"dbl-click: add · drag: move · ⌫: remove", NSMakePoint(74, kTempoY + 22), sv::ui(10), sv::hex(0x7A7E88));
    }
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(kHeaderW, 0, laneW, topH()));
    const bool topDirty = dirty.origin.y < topH();
    for (const auto& g : grid) {
        if (!topDirty) break;
        const CGFloat gx = std::floor(map.xForSample(g.sample)) + 0.5;
        if (gx < dirty.origin.x - 70 || gx > NSMaxX(dirty) + 1) continue;
        const CGFloat top = g.level == 0 ? 6 : (g.level == 1 ? 17 : 21);
        sv::line(NSMakePoint(gx, top), NSMakePoint(gx, kRulerH), g.level == 0 ? sv::inkDim() : sv::inkFaint());
        if (!g.label.empty()) sv::text(sv::ns(g.label), NSMakePoint(gx + 4, 5), sv::mono(11), sv::ink());
    }
    if (c.core->ready()) {
        const auto& tr = c.core->engine().transport();
        if (tr.cycleEndSample() > tr.cycleStartSample()) {
            const CGFloat x0 = map.xForSample(tr.cycleStartSample()), x1 = map.xForSample(tr.cycleEndSample());
            sv::fill(NSMakeRect(x0, 0, x1 - x0, kRulerH), [(tr.cycleEnabled() ? sv::copper() : sv::inkFaint()) colorWithAlphaComponent:0.28]);
            sv::fill(NSMakeRect(x0, kRulerH - 3, x1 - x0, 3), tr.cycleEnabled() ? sv::copper() : sv::inkFaint());
        }
    }
    if (_drag == DragMode::Ruler && _moved) {
        const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
        sv::fill(NSMakeRect(x0, 0, x1 - x0, kRulerH), [sv::copper() colorWithAlphaComponent:0.45]);
    }
    sv::line(NSMakePoint(kHeaderW, kRulerH - 0.5), NSMakePoint(b.size.width, kRulerH - 0.5), sv::hairline());
    for (const auto& m : p.markers) {
        const CGFloat mx = map.xForSample(m.sample);
        NSColor* mc = m.color ? [sv::hex(m.color) blendedColorWithFraction:0.25 ofColor:sv::hex(0x9AA0AC)] : sv::amber();
        if (m.cycle) {
            const CGFloat x1 = map.xForSample(m.endSample);
            sv::roundFill(NSMakeRect(mx, kRulerH + 4, x1 - mx, kMarkerH - 8), 3, [mc colorWithAlphaComponent:0.35]);
        }
        NSBezierPath* flag = [NSBezierPath bezierPath];
        [flag moveToPoint:NSMakePoint(mx, kRulerH + 3)];
        [flag lineToPoint:NSMakePoint(mx + 9, kRulerH + 3)];
        [flag lineToPoint:NSMakePoint(mx + 9, kRulerH + 13)];
        [flag lineToPoint:NSMakePoint(mx, kRulerH + 18)];
        [flag closePath];
        [mc setFill];
        [flag fill];
        sv::text(sv::ns(m.name), NSMakePoint(mx + 13, kRulerH + 3), sv::ui(11, true), sv::ink());
    }
    sv::line(NSMakePoint(kHeaderW, kRulerH + kMarkerH - 0.5), NSMakePoint(b.size.width, kRulerH + kMarkerH - 0.5), sv::hairline());
    for (const auto& s : p.arrangerSections) {
        const CGFloat x0 = map.xForSample(s.startSample), x1 = map.xForSample(s.endSample);
        const NSRect sr2 = NSMakeRect(x0 + 1, kRulerH + kMarkerH + 2, std::max<CGFloat>(2, x1 - x0 - 2), kSectionH - 4);
        sv::roundFill(sr2, 4, [[sv::hex(s.color ? s.color : 0x6A9BC3U) blendedColorWithFraction:0.3 ofColor:sv::hex(0x9AA0AC)] colorWithAlphaComponent:s.id == c.selectedSectionId ? 1.0 : 0.72]);
        sv::textIn(sv::ns(s.name), NSMakeRect(sr2.origin.x + 6, sr2.origin.y + 1, sr2.size.width - 10, 15), sv::ui(11, true), sv::canvas());
    }
    if (_drag == DragMode::NewSection && _moved) {
        const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
        sv::roundFill(NSMakeRect(x0, kRulerH + kMarkerH + 2, x1 - x0, kSectionH - 4), 4, [sv::copper() colorWithAlphaComponent:0.5]);
    }
    if (tempoShown() && topDirty) [self drawTempoLane:map width:laneW dirty:dirty];
    [NSGraphicsContext restoreGraphicsState];
    sv::line(NSMakePoint(0, topH() - 0.5), NSMakePoint(b.size.width, topH() - 0.5), sv::hairline());

    // 6. playhead
    const CGFloat px = map.xForSample(c.playheadSample);
    if (px >= kHeaderW && px <= b.size.width) {
        sv::line(NSMakePoint(std::floor(px) + 0.5, 0), NSMakePoint(std::floor(px) + 0.5, b.size.height), sv::copper(), 1.5);
        NSBezierPath* head = [NSBezierPath bezierPath];
        [head moveToPoint:NSMakePoint(px - 6, 0)];
        [head lineToPoint:NSMakePoint(px + 6, 0)];
        [head lineToPoint:NSMakePoint(px, 9)];
        [head closePath];
        [sv::copper() setFill];
        [head fill];
    }

    if (_drag == DragMode::MoveTrackHeader && _moved && _dropRow >= 0 && _dropRow < static_cast<long>(_rows.size())) {
        const auto& dest = _rows[static_cast<std::size_t>(_dropRow)];
        if (dest.kind == ArrangeRowKind::Audio) {
            const CGFloat targetY = [self topOfRow:_dropRow];
            const CGFloat lineY = targetY + (dest.index > _dragTrack ? rowHeight(dest) : 0.0);
            sv::fill(NSMakeRect(0, lineY - 2, b.size.width, 4), sv::copper());
        }
    }
    if (_externalDrag) sv::roundStroke(NSInsetRect(b, 4, 4), 10, sv::copper(), 3);
}

// ------------------------------------------------------------ track height --
// The row whose bottom edge is at view height `y` (so its header can be dragged taller), or -1.
- (long)rowWithBottomEdgeAt:(CGFloat)y {
    if (y < topH()) return -1;
    CGFloat top = topH() - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const CGFloat h = rowHeight(_rows[i]);
        if (_rows[i].kind != ArrangeRowKind::Folder && std::abs(top + h - y) <= kEdgeGrabH) return static_cast<long>(i);
        top += h;
    }
    return -1;
}

- (void)updateTrackingAreas {
    [super updateTrackingAreas];
    if (_tracking) [self removeTrackingArea:_tracking];
    _tracking = [[NSTrackingArea alloc] initWithRect:self.bounds
                                             options:NSTrackingMouseMoved | NSTrackingActiveInKeyWindow | NSTrackingInVisibleRect
                                               owner:self userInfo:nil];
    [self addTrackingArea:_tracking];
}

- (void)mouseMoved:(NSEvent*)event {
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (pt.x < kHeaderW && [self rowWithBottomEdgeAt:pt.y] >= 0) { [[NSCursor resizeUpDownCursor] set]; return; }
    if (pt.x >= kHeaderW && pt.y >= topH()) {
        switch (self.controller.arrangeTool) {
            case SVArrangeTool::Range: [[NSCursor IBeamCursor] set]; return;
            case SVArrangeTool::Split:
            case SVArrangeTool::Zoom:
            case SVArrangeTool::Draw: [[NSCursor crosshairCursor] set]; return;
            case SVArrangeTool::Erase:
            case SVArrangeTool::Mute:
            case SVArrangeTool::Glue: [[NSCursor pointingHandCursor] set]; return;
            default: break;
        }
    }
    [[NSCursor arrowCursor] set];
}

// Keys of the Project window: 1–8 pick a tool (as in Cubase), Esc drops the range, + − 0 zoom.
- (void)keyDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    NSString* chars = event.charactersIgnoringModifiers;
    const unichar ch = chars.length ? [chars characterAtIndex:0] : 0;
    const NSEventModifierFlags mods = event.modifierFlags & NSEventModifierFlagDeviceIndependentFlagsMask;
    if (event.keyCode == 53) { // Esc: cancel the marquee, then clear the current selections
        if (_drag == DragMode::Marquee) { _selectedEvents = _marqueeBase; _drag = DragMode::None; }
        [self clearSelectedEvents];
        [c clearMarkedTracks];
        if (_hasRange) { [self clearRange]; [c arrangeRangeChanged]; }
        [self setNeedsDisplay:YES];
        return;
    }
    if (mods & NSEventModifierFlagCommand) {
        if (ch == 'a' || ch == 'A') { [self selectAllEvents]; return; }
        if (ch == 'c' || ch == 'C') { [c copyClip:nil]; return; }
        if (ch == 'x' || ch == 'X') { [c cutClip:nil]; return; }
        if (ch == 'v' || ch == 'V') { [c pasteClip:nil]; return; }
        if (ch == 'd' || ch == 'D') { [c duplicateClip:nil]; return; }
    }
    if (event.keyCode == 51 || event.keyCode == 117) { [c deleteSelection:nil]; return; } // Backspace / Forward Delete
    if (!(mods & (NSEventModifierFlagCommand | NSEventModifierFlagOption | NSEventModifierFlagControl))) {
        if (ch >= '1' && ch <= '8') { [c setArrangeTool:static_cast<SVArrangeTool>(ch - '1')]; return; }
        if (ch == '+' || ch == '=') { [self zoomAroundX:kHeaderW + (self.bounds.size.width - kHeaderW) * 0.5 factor:1.5]; return; }
        if (ch == '-') { [self zoomAroundX:kHeaderW + (self.bounds.size.width - kHeaderW) * 0.5 factor:1.0 / 1.5]; return; }
        if (ch == '0') { [c zoomToProject:nil]; return; }
    }
    [super keyDown:event];
}

- (BOOL)setSelectedTrackHeight:(CGFloat)height {
    SilvetonController* c = self.controller;
    CGFloat top = 0.0;
    for (const ArrangeRow& r : _rows) {
        const bool selected = (r.kind == ArrangeRowKind::Audio && static_cast<long>(r.index) == c.selectedTrack) ||
                              (r.kind == ArrangeRowKind::Midi && static_cast<long>(r.index) == c.selectedMidiTrack);
        if (!selected) { top += rowHeight(r); continue; }
        const CGFloat fill = std::max(kMinTrackH, self.bounds.size.height - topH() - 2.0);
        CGFloat target = height;
        if (height == -2.0) target = rowHeight(r) > kTrackH + 1.0 ? 0.0 : -1.0;   // zoom on / off
        if (target == 0.0) chosenHeights().erase(rowKey(r));
        else chosenHeights()[rowKey(r)] = std::min(kMaxTrackH, std::max(kMinTrackH, target < 0.0 ? fill : target));
        if (target < 0.0) self.scrollY = top;   // a zoomed track starts at the top of the window
        [self setNeedsDisplay:YES];
        return YES;
    }
    return NO;
}

- (void)resetTrackHeights {
    chosenHeights().clear();
    [self setNeedsDisplay:YES];
}

// -------------------------------------------------------- object selection --
- (std::vector<SVSelectedEvent>)selectedEvents {
    return std::vector<SVSelectedEvent>(_selectedEvents.begin(), _selectedEvents.end());
}
- (void)setSelectedEvents:(const std::vector<SVSelectedEvent>&)events {
    _selectedEvents.clear();
    for (const auto& item : events) if (item.id) _selectedEvents.insert(item);
    // Keep the existing Inspector/Edit page pointed at a valid primary event.
    SilvetonController* c = self.controller;
    if (_selectedEvents.empty()) {
        c.selectedClipId = 0; c.selectedPartId = 0;
    } else {
        const auto& primary = *_selectedEvents.begin();
        c.selectedTrack = primary.midi ? -1 : static_cast<long>(primary.track);
        c.selectedMidiTrack = primary.midi ? static_cast<long>(primary.track) : -1;
        c.selectedFolder = -1;
        c.selectedClipId = primary.midi ? 0 : primary.id;
        c.selectedPartId = primary.midi ? primary.id : 0;
    }
    [self setNeedsDisplay:YES];
}
- (void)clearSelectedEvents {
    if (_selectedEvents.empty()) return;
    _selectedEvents.clear();
    self.controller.selectedClipId = 0;
    self.controller.selectedPartId = 0;
    [self setNeedsDisplay:YES];
}
- (void)selectAllEvents {
    const Project* p = self.controller.project;
    if (!p) return;
    std::vector<SVSelectedEvent> selected;
    for (std::size_t t = 0; t < p->tracks.size(); ++t)
        for (const auto& clip : p->tracks[t].clips) if (clip.id) selected.push_back({false,t,clip.id});
    for (std::size_t t = 0; t < p->midiTracks.size(); ++t)
        for (const auto& part : p->midiTracks[t].parts) if (part.id) selected.push_back({true,t,part.id});
    [self clearRange];
    [self setSelectedEvents:selected];
    [self.controller markAllTracks];   // ⌘A: every track as well (a Process window then works on all of them)
}
- (void)captureMoveOrigins {
    _moveOrigins.clear();
    const Project* p = self.controller.project;
    if (!p) return;
    for (const auto& e : _selectedEvents) {
        if (e.midi) {
            if (e.track >= p->midiTracks.size()) continue;
            for (const auto& part : p->midiTracks[e.track].parts) if (part.id == e.id) {
                _moveOrigins.push_back({e,p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes)});
                break;
            }
        } else {
            if (e.track >= p->tracks.size()) continue;
            for (const auto& clip : p->tracks[e.track].clips) if (clip.id == e.id) {
                _moveOrigins.push_back({e,clip.timelineStartSample});
                break;
            }
        }
    }
}
- (void)updateMarqueeSelection {
    const Project* p = self.controller.project;
    if (!p || _rows.empty()) return;
    std::set<SVSelectedEvent> hits;
    const auto lo = std::min(_marqueeSampleA,_marqueeSampleB);
    const auto hi = std::max(_marqueeSampleA,_marqueeSampleB);
    const long a = std::max<long>(0,std::min(_marqueeRowA,_marqueeRowB));
    const long b = std::min<long>(static_cast<long>(_rows.size())-1,std::max(_marqueeRowA,_marqueeRowB));
    for (long index = a; index <= b; ++index) {
        const ArrangeRow& r = _rows[static_cast<std::size_t>(index)];
        if (r.kind == ArrangeRowKind::Audio && r.index < p->tracks.size()) {
            for (const auto& clip : p->tracks[r.index].clips) {
                const auto start = clip.timelineStartSample;
                const auto end = start + static_cast<std::int64_t>(clip.lengthSamples);
                if (clip.id && end > lo && start < hi) hits.insert({false,r.index,clip.id});
            }
        } else if (r.kind == ArrangeRowKind::Midi && r.index < p->midiTracks.size()) {
            for (const auto& part : p->midiTracks[r.index].parts) {
                const auto start = p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes);
                const auto end = p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes+part.lengthQuarterNotes);
                if (part.id && end > lo && start < hi) hits.insert({true,r.index,part.id});
            }
        }
    }
    std::set<SVSelectedEvent> updated = _marqueeSelectionMode == 0 ? std::set<SVSelectedEvent>{} : _marqueeBase;
    for (const auto& hit : hits) {
        if (_marqueeSelectionMode == 3) updated.erase(hit); // Option: subtract
        else if (_marqueeSelectionMode == 2) { // Command: toggle relative to mouse-down selection
            if (!_marqueeBase.count(hit)) updated.insert(hit);
            else updated.erase(hit);
        } else updated.insert(hit); // ordinary selection or Shift: add
    }
    if (updated != _selectedEvents)
        [self setSelectedEvents:std::vector<SVSelectedEvent>(updated.begin(),updated.end())];
}
- (void)autoScrollSelectionAt:(NSPoint)pt {
    if (_drag != DragMode::Marquee && _drag != DragMode::MoveSelection) return;
    const CGFloat inset = 24.0;
    if (pt.x > self.bounds.size.width - inset)
        self.scrollSeconds += 12.0 / std::max(1.0,self.controller.pixelsPerSecond);
    else if (pt.x < kHeaderW+inset && self.scrollSeconds > 0)
        self.scrollSeconds = std::max(0.0,self.scrollSeconds-12.0/std::max(1.0,self.controller.pixelsPerSecond));
    if (pt.y > self.bounds.size.height-inset)
        self.scrollY = std::min(std::max(0.0,static_cast<double>([self contentHeight]-(self.bounds.size.height-topH()))),self.scrollY+8.0);
    else if (pt.y < topH()+inset)
        self.scrollY = std::max(0.0,self.scrollY-8.0);
}

// ------------------------------------------------------------- automation --
// The lane under `pt` (0..2) of the audio row `row`, or -1 when the point is in the track's own part.
- (int)laneAtPoint:(NSPoint)pt row:(long)row {
    if (row < 0 || row >= static_cast<long>(_rows.size())) return -1;
    const ArrangeRow& r = _rows[static_cast<std::size_t>(row)];
    const int n = laneCount(r);
    if (n == 0) return -1;
    const CGFloat top = [self topOfRow:row] + lanesTop(r);
    if (pt.y < top) return -1;
    const int lane = static_cast<int>((pt.y - top) / kLaneH);
    return lane < n ? lane : -1;
}
- (NSRect)laneRect:(int)lane row:(long)row {
    const ArrangeRow& r = _rows[static_cast<std::size_t>(row)];
    return NSMakeRect(kHeaderW, [self topOfRow:row] + lanesTop(r) + kLaneH * lane, std::max<CGFloat>(0, self.bounds.size.width - kHeaderW), kLaneH);
}
// The take lane under `pt` of the audio row `row` (0-based), or -1.
- (int)takeLaneAtPoint:(NSPoint)pt row:(long)row {
    if (row < 0 || row >= static_cast<long>(_rows.size())) return -1;
    const ArrangeRow& r = _rows[static_cast<std::size_t>(row)];
    const int n = takeCount(r);
    if (n == 0) return -1;
    const CGFloat top = [self topOfRow:row] + baseRowHeight(r);
    if (pt.y < top) return -1;
    const int lane = static_cast<int>((pt.y - top) / kTakeH);
    return lane < n ? lane : -1;
}
- (NSRect)takeRect:(int)lane row:(long)row {
    const ArrangeRow& r = _rows[static_cast<std::size_t>(row)];
    return NSMakeRect(kHeaderW, [self topOfRow:row] + baseRowHeight(r) + kTakeH * lane, std::max<CGFloat>(0, self.bounds.size.width - kHeaderW), kTakeH);
}

// The recorded takes of a track, one lane each: the take's sound ghosted, the parts of it that play
// (chosen in the comp) framed bright. Click a take to use all of it, drag over it to use that part.
- (void)drawTakesOfTrack:(std::size_t)track top:(CGFloat)top dirty:(NSRect)dirty map:(const TimelineMapping&)map {
    SilvetonController* c = self.controller;
    const Project& p = *c.project;
    if (track >= p.tracks.size()) return;
    const auto& t = p.tracks[track];
    const CGFloat laneW = std::max<CGFloat>(0, self.bounds.size.width - kHeaderW);
    const NSRect b = self.bounds;
    for (std::size_t li = 0; li < t.takeLanes.size(); ++li) {
        const NSRect lr = NSMakeRect(kHeaderW, top + kTakeH * static_cast<CGFloat>(li), laneW, kTakeH);
        if (!NSIntersectsRect(lr, dirty)) continue;
        sv::fill(NSMakeRect(lr.origin.x, lr.origin.y, lr.size.width, lr.size.height - 1), sv::hex(li % 2 ? 0x121317 : 0x101115));
        sv::fill(NSMakeRect(lr.origin.x, NSMaxY(lr) - 1, lr.size.width, 1), sv::hex(0x1C1E24));
        const auto& lane = t.takeLanes[li];
        for (const auto& clip : lane.clips) {
            const CGFloat x0 = map.xForSample(clip.timelineStartSample);
            const CGFloat x1 = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples));
            if (x1 < kHeaderW || x0 > b.size.width) continue;
            const CGFloat cx0 = std::max<CGFloat>(-200.0, x0), cx1 = std::min<CGFloat>(b.size.width + 200.0, x1);
            const NSRect cr = NSMakeRect(cx0, lr.origin.y + 2, std::max<CGFloat>(3, cx1 - cx0), kTakeH - 5);
            if (!NSIntersectsRect(cr, dirty)) continue;
            sv::roundFill(cr, 5, sv::hex(0x202329));
            sv::roundStroke(cr, 5, sv::hex(0x15171B), 1.0);
            c.core->waveformCache().request(clip.audioPath);
            if (auto ov = c.core->waveformCache().find(clip.audioPath))
                sv::drawWaveform(*ov, clip.sourceStartSample, clip.lengthSamples, NSMakeRect(x0 + 1, cr.origin.y + 2, x1 - x0 - 2, cr.size.height - 4),
                                 sv::hex(0x8A8F9A), false, std::max(dirty.origin.x, kHeaderW), std::min(NSMaxX(dirty), b.size.width), p.sampleRate, c.waveZoom, true);
        }
        // the parts of this take that the comp plays
        for (const auto& sec : t.compSections) {
            if (sec.takeLaneId != lane.id) continue;
            const CGFloat x0 = std::max<CGFloat>(-200.0, map.xForSample(sec.timelineStartSample));
            const CGFloat x1 = std::min<CGFloat>(b.size.width + 200.0, map.xForSample(sec.timelineStartSample + static_cast<std::int64_t>(sec.lengthSamples)));
            if (x1 < kHeaderW || x0 > b.size.width) continue;
            const NSRect sr = NSMakeRect(x0, lr.origin.y + 2, std::max<CGFloat>(3, x1 - x0), kTakeH - 5);
            sv::roundFill(sr, 5, [sv::copper() colorWithAlphaComponent:0.14]);
            sv::roundStroke(sr, 5, sv::copper(), 1.0);
        }
        if (_drag == DragMode::CompRange && _moved && _autoTrack == static_cast<long>(track) && _compLaneId == lane.id) {
            const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
            sv::roundFill(NSMakeRect(x0, lr.origin.y + 2, std::max<CGFloat>(2, x1 - x0), kTakeH - 5), 5, [sv::ink() colorWithAlphaComponent:0.22]);
        }
    }
}
- (void)toggleTakeLanes {
    SilvetonController* c = self.controller;
    if (c.selectedTrack < 0) { [c setStatus:@"Select an audio track first — its TAKES key or View ▸ Take Lanes opens the recorded takes"]; return; }
    const auto t = static_cast<std::size_t>(c.selectedTrack);
    if (c.project && t < c.project->tracks.size() && c.project->tracks[t].takeLanes.empty()) { [c setStatus:@"This track has no recorded takes yet"]; return; }
    if (!takesOpen().erase(t)) takesOpen().insert(t);
    [self setNeedsDisplay:YES];
}
// Value <-> y inside a lane rect (4 px of air at the top and the bottom).
- (CGFloat)yForUnit:(double)unit inLane:(NSRect)lr { return NSMaxY(lr) - 5.0 - (lr.size.height - 10.0) * std::max(0.0, std::min(1.0, unit)); }
- (double)unitForY:(CGFloat)y inLane:(NSRect)lr { return std::max(0.0, std::min(1.0, (NSMaxY(lr) - 5.0 - y) / (lr.size.height - 10.0))); }

// The three lanes under an audio track: the curve with its points (or the flat line of the fader value
// when the lane is empty), the selected point filled, Mute as steps.
- (void)drawLanesOfTrack:(std::size_t)track top:(CGFloat)top dirty:(NSRect)dirty map:(const TimelineMapping&)map {
    SilvetonController* c = self.controller;
    const Project& p = *c.project;
    const CGFloat laneW = std::max<CGFloat>(0, self.bounds.size.width - kHeaderW);
    for (int lane = 0; lane < kLaneCount; ++lane) {
        const NSRect lr = NSMakeRect(kHeaderW, top + kLaneH * lane, laneW, kLaneH);
        if (!NSIntersectsRect(lr, dirty)) continue;
        sv::fill(NSMakeRect(lr.origin.x, lr.origin.y, lr.size.width, lr.size.height - 1), sv::hex(lane % 2 ? 0x121317 : 0x101115));
        sv::fill(NSMakeRect(lr.origin.x, NSMaxY(lr) - 1, lr.size.width, 1), sv::hex(0x1C1E24));
        const AutomationLane* al = laneOf(p, track, lane);
        const float fallback = laneStatic(p, track, lane);
        const bool live = (_drag == DragMode::AutoPoint || _drag == DragMode::AutoDraw) && _autoTrack == static_cast<long>(track) && _autoLane == lane;
        NSColor* curve = sv::copper();
        NSColor* curveDim = [sv::copper() colorWithAlphaComponent:0.55];
        const CGFloat x0 = std::max(dirty.origin.x, lr.origin.x), x1 = std::min(NSMaxX(dirty), NSMaxX(lr));
        if (x1 <= x0) continue;
        // the middle line for pan (centre) and the 0 dB line for volume, faintly
        if (lane < 2) {
            const CGFloat ry = std::round([self yForUnit:laneUnit(lane, lane == 0 ? 0.0F : 0.0F) inLane:lr]) + 0.5;
            sv::fill(NSMakeRect(x0, ry, x1 - x0, 1), sv::hex(0xFFFFFF, 0.06));
        }
        if (!al || al->points().empty()) {   // no automation yet: the fader / pan / mute value as a flat line
            const CGFloat ry = std::round([self yForUnit:laneUnit(lane, fallback) inLane:lr]) + 0.5;
            sv::fill(NSMakeRect(x0, ry, x1 - x0, 1), curveDim);
            continue;
        }
        // the curve: one value per column between the first and last point, flat before and after
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.5;
        const double sr = map.sampleRate;
        (void)sr;
        bool open = false;
        const auto& pts = al->points();
        auto yAt = [&](std::int64_t sample) {
            const float v = lane == 2 ? al->stepValueAt(sample, fallback) : al->valueAt(sample, fallback);
            return [self yForUnit:laneUnit(lane, v) inLane:lr];
        };
        for (CGFloat px = x0; px <= x1; px += 1.0) {
            const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(px));
            const NSPoint pt = NSMakePoint(px, yAt(sample));
            if (!open) { [path moveToPoint:pt]; open = true; } else [path lineToPoint:pt];
        }
        // a light wash under the curve
        NSBezierPath* wash = [path copy];
        [wash lineToPoint:NSMakePoint(x1, NSMaxY(lr) - 1)];
        [wash lineToPoint:NSMakePoint(x0, NSMaxY(lr) - 1)];
        [wash closePath];
        [[sv::copper() colorWithAlphaComponent:0.10] setFill];
        [wash fill];
        [curve setStroke];
        [path stroke];
        // the points
        for (const auto& ap : pts) {
            const CGFloat px = map.xForSample(ap.sample);
            if (px < x0 - 6 || px > x1 + 6) continue;
            const CGFloat py = [self yForUnit:laneUnit(lane, ap.value) inLane:lr];
            const bool selPt = _autoTrack == static_cast<long>(track) && _autoLane == lane && _autoPointSample == ap.sample;
            sv::roundFill(NSMakeRect(px - 3.5, py - 3.5, 7, 7), 1.5, selPt ? sv::ink() : sv::hex(0x1E2025));
            sv::roundStroke(NSMakeRect(px - 3.5, py - 3.5, 7, 7), 1.5, curve, 1.0);
        }
        if (live) {   // the value under the mouse while it is dragged
            const CGFloat px = map.xForSample(_autoDragSample);
            sv::fill(NSMakeRect(std::floor(px) + 0.5, lr.origin.y, 1, lr.size.height), [sv::ink() colorWithAlphaComponent:0.25]);
        }
    }
}
- (BOOL)automationPointSelected { return _autoTrack >= 0 && _autoLane >= 0 && _autoPointSample >= 0; }
- (BOOL)deleteSelectedAutomationPoint {
    if (![self automationPointSelected]) return NO;
    const std::size_t track = static_cast<std::size_t>(_autoTrack);
    const int lane = _autoLane;
    const std::int64_t sample = _autoPointSample;
    [self.controller automationEdit:@"Delete Automation Point" track:track lane:lane op:^(AutomationLane& al) { (void)al.removeAt(sample); }];
    _autoPointSample = -1;
    [self setNeedsDisplay:YES];
    return YES;
}
- (void)toggleAutomationLanes {
    SilvetonController* c = self.controller;
    if (c.selectedTrack < 0) { [c setStatus:@"Select an audio track first — its AUTO key or View ▸ Automation Lanes opens the lanes"]; return; }
    const auto t = static_cast<std::size_t>(c.selectedTrack);
    if (!automationOpen().erase(t)) automationOpen().insert(t);
    [self setNeedsDisplay:YES];
}

// ------------------------------------------------------------- tempo track --
// The tempo range the lane shows: the changes of the project with some air around them.
- (void)tempoRangeLo:(double*)lo hi:(double*)hi {
    const Project& p = *self.controller.project;
    double a = p.tempoMap.initialTempo(), b = a;
    for (const auto& ch : p.tempoMap.changes()) if (ch.changesTempo) { a = std::min(a, ch.bpm); b = std::max(b, ch.bpm); }
    if (_drag == DragMode::TempoPoint) { a = std::min(a, _tempoDragBpm); b = std::max(b, _tempoDragBpm); }
    const double pad = std::max(10.0, (b - a) * 0.25);
    *lo = std::max(20.0, a - pad);
    *hi = std::min(400.0, b + pad);
    if (*hi - *lo < 20.0) { *lo = std::max(20.0, *lo - 10.0); *hi = std::min(400.0, *hi + 10.0); }
}
- (CGFloat)yForBpm:(double)bpm {
    double lo = 60.0, hi = 180.0;
    [self tempoRangeLo:&lo hi:&hi];
    const double u = (bpm - lo) / std::max(1.0, hi - lo);
    return kTempoY + kTempoH - 6.0 - (kTempoH - 12.0) * std::max(0.0, std::min(1.0, u));
}
- (double)bpmForY:(CGFloat)y {
    double lo = 60.0, hi = 180.0;
    [self tempoRangeLo:&lo hi:&hi];
    const double u = (kTempoY + kTempoH - 6.0 - y) / (kTempoH - 12.0);
    return std::round((lo + (hi - lo) * std::max(0.0, std::min(1.0, u))) * 2.0) / 2.0;   // half-BPM steps
}
- (void)drawTempoLane:(const TimelineMapping&)map width:(CGFloat)laneW dirty:(NSRect)dirty {
    const Project& p = *self.controller.project;
    const CGFloat x0 = std::max(dirty.origin.x, kHeaderW), x1 = std::min(NSMaxX(dirty), kHeaderW + laneW);
    if (x1 <= x0) return;
    // the tempo as steps across the lane
    NSBezierPath* path = [NSBezierPath bezierPath];
    path.lineWidth = 1.5;
    bool open = false;
    for (CGFloat px = x0; px <= x1; px += 1.0) {
        const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(px));
        const NSPoint pt = NSMakePoint(px, [self yForBpm:p.tempoMap.tempoAtSample(sample)]);
        if (!open) { [path moveToPoint:pt]; open = true; } else [path lineToPoint:pt];
    }
    NSBezierPath* wash = [path copy];
    [wash lineToPoint:NSMakePoint(x1, kTempoY + kTempoH - 1)];
    [wash lineToPoint:NSMakePoint(x0, kTempoY + kTempoH - 1)];
    [wash closePath];
    [[sv::copper() colorWithAlphaComponent:0.10] setFill];
    [wash fill];
    [sv::copper() setStroke];
    [path stroke];
    // the changes: a point with its BPM
    auto drawPoint = [&](std::int64_t sample, double bpm, bool selected) {
        const CGFloat px = map.xForSample(sample);
        if (px < x0 - 40 || px > x1 + 40) return;
        const CGFloat py = [self yForBpm:bpm];
        sv::roundFill(NSMakeRect(px - 3.5, py - 3.5, 7, 7), 1.5, selected ? sv::ink() : sv::hex(0x1E2025));
        sv::roundStroke(NSMakeRect(px - 3.5, py - 3.5, 7, 7), 1.5, sv::copper(), 1.0);
        sv::text([NSString stringWithFormat:@"%g", bpm], NSMakePoint(px + 6, std::max(kTempoY + 1.0, py - 13.0)), sv::mono(10, true), selected ? sv::ink() : sv::inkDim());
    };
    drawPoint(0, p.tempoMap.initialTempo(), _tempoSel == 0);
    for (const auto& ch : p.tempoMap.changes()) if (ch.changesTempo && ch.sample > 0) drawPoint(ch.sample, ch.bpm, _tempoSel == ch.sample);
}
// The tempo change under `pt` (its sample; 0 = the initial tempo), or -1.
- (std::int64_t)tempoPointAt:(NSPoint)pt map:(const TimelineMapping&)map {
    const Project& p = *self.controller.project;
    std::int64_t best = -1;
    CGFloat bestD = 7.0;
    auto test = [&](std::int64_t sample, double bpm) {
        const CGFloat d = std::max(std::abs(map.xForSample(sample) - pt.x), std::abs([self yForBpm:bpm] - pt.y));
        if (d < bestD) { bestD = d; best = sample; }
    };
    test(0, p.tempoMap.initialTempo());
    for (const auto& ch : p.tempoMap.changes()) if (ch.changesTempo && ch.sample > 0) test(ch.sample, ch.bpm);
    return best;
}
- (void)toggleTempoTrack { tempoShown() = !tempoShown(); _tempoSel = -1; [self setNeedsDisplay:YES]; }
- (BOOL)tempoTrackShown { return tempoShown(); }
- (BOOL)deleteSelectedTempoPoint {
    if (!tempoShown() || _tempoSel <= 0) return NO;   // the initial tempo cannot be removed
    const std::int64_t at = _tempoSel;
    [self.controller tempoEdit:@"Remove Tempo Change" op:^(TempoMap& tm) { (void)tm.removeTempoChangeAt(at); }];
    _tempoSel = -1;
    [self setNeedsDisplay:YES];
    return YES;
}

// ------------------------------------------------------------------ range --
// The row index of a row key (or -1): the range remembers keys, the picture needs indices.
- (long)rowIndexOfKey:(std::uint64_t)key fallback:(long)index {
    for (std::size_t i = 0; i < _rows.size(); ++i) if (rowKey(_rows[i]) == key) return static_cast<long>(i);
    if (_rows.empty()) return -1;
    return std::min<long>(std::max<long>(0, index), static_cast<long>(_rows.size()) - 1);
}
- (BOOL)rangeRowIndicesFrom:(long*)a to:(long*)b {
    if (!_hasRange || _rows.empty()) return NO;
    if (_rangeRowA < 0 || _rangeRowB < 0) return NO;   // marked in an empty project: a span of time without tracks
    long ra = [self rowIndexOfKey:_rangeKeyA fallback:_rangeRowA];
    long rb = [self rowIndexOfKey:_rangeKeyB fallback:_rangeRowB];
    if (ra < 0 || rb < 0) return NO;
    if (ra > rb) std::swap(ra, rb);
    *a = ra; *b = rb;
    return YES;
}
- (BOOL)hasRange { return _hasRange && _rangeEnd > _rangeStart; }
- (TimelineRange)range { return [self hasRange] ? TimelineRange {_rangeStart, _rangeEnd} : TimelineRange {}; }
- (std::vector<ArrangeRow>)rangeRows {
    std::vector<ArrangeRow> rows;
    long a = 0, b = 0;
    if (![self hasRange] || ![self rangeRowIndicesFrom:&a to:&b]) return rows;
    for (long i = a; i <= b; ++i)
        if (_rows[static_cast<std::size_t>(i)].kind != ArrangeRowKind::Folder) rows.push_back(_rows[static_cast<std::size_t>(i)]);
    return rows;
}
- (void)setRange:(TimelineRange)range rows:(const std::vector<ArrangeRow>&)rows {
    if (!range.valid() || rows.empty()) { [self clearRange]; return; }
    if (_rows.empty() && self.controller.project) _rows = buildArrangeRows(*self.controller.project);
    _hasRange = YES;
    _rangeStart = std::max<std::int64_t>(0, range.start);
    _rangeEnd = range.end;
    _rangeKeyA = rowKey(rows.front());
    _rangeKeyB = rowKey(rows.back());
    _rangeRowA = [self rowIndexOfKey:_rangeKeyA fallback:0];
    _rangeRowB = [self rowIndexOfKey:_rangeKeyB fallback:static_cast<long>(_rows.size()) - 1];
    [self setNeedsDisplay:YES];
}
- (void)clearRange {
    const BOOL had = _hasRange;
    _hasRange = NO;
    if (had) [self setNeedsDisplay:YES];
}
// The row under view height y (the last row when the mouse is below the tracks), or -1 above the tracks.
- (long)rowAtY:(CGFloat)y {
    if (y < topH() || _rows.empty()) return -1;
    CGFloat top = topH() - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const CGFloat h = rowHeight(_rows[i]);
        if (y < top + h) return static_cast<long>(i);
        top += h;
    }
    return static_cast<long>(_rows.size()) - 1;
}
- (CGFloat)topOfRow:(long)row {
    CGFloat y = topH() - self.scrollY;
    for (long i = 0; i < row && i < static_cast<long>(_rows.size()); ++i) y += rowHeight(_rows[static_cast<std::size_t>(i)]);
    return y;
}

// ------------------------------------------------------------------- zoom --
- (void)zoomAroundX:(CGFloat)x factor:(double)factor {
    SilvetonController* c = self.controller;
    const auto before = [self mapping];
    const std::int64_t anchor = std::max<std::int64_t>(0, before.sampleForX(x));
    [c setPixelsPerSecond:c.pixelsPerSecond * factor];
    const double pps = c.pixelsPerSecond;
    self.scrollSeconds = std::max(0.0, static_cast<double>(anchor) / before.sampleRate - (x - kHeaderW) / pps);
    [self setNeedsDisplay:YES];
}
- (void)zoomToSamples:(std::int64_t)start to:(std::int64_t)end {
    SilvetonController* c = self.controller;
    const auto m = [self mapping];
    const double laneW = std::max<CGFloat>(40.0, self.bounds.size.width - kHeaderW - 24.0);
    const double seconds = std::max(0.05, static_cast<double>(std::max<std::int64_t>(1, end - start)) / m.sampleRate);
    [c setPixelsPerSecond:laneW / seconds];
    self.scrollSeconds = std::max(0.0, static_cast<double>(std::max<std::int64_t>(0, start)) / m.sampleRate - 12.0 / c.pixelsPerSecond);
    [self setNeedsDisplay:YES];
}

// ---------------------------------------------------------------- hit test --
- (Hit)hitAt:(NSPoint)pt {
    Hit hit;
    const Project* p = self.controller.project;
    if (!p) return hit;
    const auto map = [self mapping];
    hit.sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    if (pt.y < topH()) return hit;
    CGFloat y = topH() - self.scrollY;
    for (std::size_t i = 0; i < _rows.size(); ++i) {
        const CGFloat h = rowHeight(_rows[i]);
        if (pt.y >= y && pt.y < y + h) {
            hit.row = static_cast<long>(i);
            hit.header = pt.x < kHeaderW;
            if (hit.header) return hit;
            const auto& r = _rows[i];
            if (r.kind == ArrangeRowKind::Audio && r.index < p->tracks.size()) {
                for (const auto& clip : p->tracks[r.index].clips) {
                    const CGFloat x0 = map.xForSample(clip.timelineStartSample);
                    const CGFloat x1 = map.xForSample(clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples));
                    if (pt.x >= x0 && pt.x <= x1) {
                        hit.clip = clip.id;
                        if (pt.x - x0 < 6 && x1 - x0 > 18) hit.edge = -1;
                        else if (x1 - pt.x < 6 && x1 - x0 > 18) hit.edge = 1;
                    }
                }
            } else if (r.kind == ArrangeRowKind::Midi && r.index < p->midiTracks.size()) {
                const auto& mt = p->midiTracks[r.index];
                if (mt.parts.empty()) {
                    double end = 0;
                    for (const auto& n : mt.sequence.notes()) end = std::max(end, n.startQuarterNotes + n.durationQuarterNotes);
                    const CGFloat x1 = map.xForSample(p->tempoMap.sampleAtQuarterNotes(std::ceil(end / 4.0) * 4.0));
                    if (end > 0 && pt.x >= map.xForSample(0) && pt.x <= x1) hit.legacyPart = true;
                } else {
                    for (const auto& part : mt.parts) {
                        const CGFloat x0 = map.xForSample(p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes));
                        const CGFloat x1 = map.xForSample(p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes + part.lengthQuarterNotes));
                        if (pt.x >= x0 && pt.x <= x1) hit.part = part.id;
                    }
                }
            }
            return hit;
        }
        y += h;
    }
    return hit;
}

- (void)mouseDown:(NSEvent*)event {
    [self.window makeFirstResponder:self];
    SilvetonController* c = self.controller;
    Project* p = c.project;
    if (!p) return;
    _rows = buildArrangeRows(*p); // hit testing must see newly added / reordered tracks before repaint
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    _downPoint = pt;
    _moved = NO;
    _drag = DragMode::None;
    _dropRow = -1;
    const auto map = [self mapping];
    const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    const bool twice = event.clickCount >= 2;
    if (pt.y < topH()) {
        if (pt.x < kHeaderW) return;
        if (pt.y < kRulerH) {
            _drag = DragMode::Ruler;
            _dragAnchor = _dragCurrent = [c snapSample:sample];
        } else if (pt.y < kRulerH + kMarkerH) {
            for (const auto& m : p->markers) {
                const CGFloat mx = map.xForSample(m.sample);
                if (pt.x >= mx - 3 && pt.x <= mx + 10) { [c markerClicked:m.id doubleClick:twice]; [self setNeedsDisplay:YES]; return; }
            }
            if (twice) [c addMarkerAtSample:[c snapSample:sample]];
        } else if (pt.y < kRulerH + kMarkerH + kSectionH) {
            for (const auto& s : p->arrangerSections) {
                if (sample >= s.startSample && sample < s.endSample) { [c sectionClicked:s.id doubleClick:twice]; [self setNeedsDisplay:YES]; return; }
            }
            _drag = DragMode::NewSection;
            _dragAnchor = _dragCurrent = [c snapSample:sample];
        } else if (tempoShown()) {
            // the tempo track: a point is selected and dragged (time and BPM); double-click a point = type the BPM,
            // double-click on empty = a new tempo change there; the Draw tool adds one with a click
            const std::int64_t at = [self tempoPointAt:pt map:map];
            if (at >= 0) {
                _tempoSel = at;
                if (twice) { [c tempoTypeValueAt:at]; return; }
                _tempoDragSample = at;
                _tempoDragBpm = at == 0 ? p->tempoMap.initialTempo() : p->tempoMap.tempoAtSample(at);
                _drag = DragMode::TempoPoint;
                [c beginGesture:@"Move Tempo Change"];
                _gestureOpen = YES;
            } else if (twice || c.arrangeTool == SVArrangeTool::Draw) {
                const std::int64_t snapped = std::max<std::int64_t>(0, [c snapSample:sample]);
                const double bpm = c.arrangeTool == SVArrangeTool::Draw ? [self bpmForY:pt.y] : p->tempoMap.tempoAtSample(snapped);
                [c tempoEdit:@"Add Tempo Change" op:^(TempoMap& tm) { if (snapped == 0) tm.setInitialTempo(bpm); else tm.addTempoChange(snapped, bpm); }];
                _tempoSel = snapped;
            } else {
                _tempoSel = -1;
                [c seekToSample:[c snapSample:sample]];
            }
        }
        [self setNeedsDisplay:YES];
        return;
    }
    if (pt.x < kHeaderW) {   // the bottom edge of a track header: drag = taller / shorter, double click = normal
        const long edge = [self rowWithBottomEdgeAt:pt.y];
        if (edge >= 0) {
            const ArrangeRow& er = _rows[static_cast<std::size_t>(edge)];
            if (twice) { chosenHeights().erase(rowKey(er)); [self setNeedsDisplay:YES]; return; }
            _drag = DragMode::ResizeRow;
            _resizeKey = rowKey(er);
            _resizeStartH = rowHeight(er);
            return;
        }
    }
    const Hit hit = [self hitAt:pt];
    const SVArrangeTool tool = c.arrangeTool;
    // Take lanes under a track: click a take = the comp uses all of it, drag = that part of it; USE in the header.
    if (hit.row >= 0) {
        const int tl = [self takeLaneAtPoint:pt row:hit.row];
        const ArrangeRow tr = _rows[static_cast<std::size_t>(hit.row)];
        if (tl >= 0 && tr.kind == ArrangeRowKind::Audio && tr.index < p->tracks.size() && static_cast<std::size_t>(tl) < p->tracks[tr.index].takeLanes.size()) {
            const auto& lane = p->tracks[tr.index].takeLanes[static_cast<std::size_t>(tl)];
            [c selectRow:tr];
            const NSRect takeR = [self takeRect:tl row:hit.row];
            if (pt.x < kHeaderW) {
                if (NSPointInRect(pt, NSMakeRect(kHeaderW - 60, takeR.origin.y + 12, 44, 17))) [c compUseTake:tr.index lane:lane.id];
                [self setNeedsDisplay:YES];
                return;
            }
            for (const auto& clip : lane.clips) {
                const std::int64_t cs = clip.timelineStartSample, ce = cs + static_cast<std::int64_t>(clip.lengthSamples);
                if (sample < cs || sample >= ce) continue;
                _autoTrack = static_cast<long>(tr.index);
                _compLaneId = lane.id;
                _compClipId = clip.id;
                _compClipStart = cs;
                _compClipEnd = ce;
                _dragAnchor = _dragCurrent = std::max(cs, std::min(ce, [c snapSample:sample]));
                _drag = DragMode::CompRange;
                return;
            }
            return;
        }
    }
    // Automation lanes under a track: the mode key in the header column, points in the lane itself.
    if (hit.row >= 0) {
        const int lane = [self laneAtPoint:pt row:hit.row];
        const ArrangeRow lr = _rows[static_cast<std::size_t>(hit.row)];
        if (lane >= 0 && lr.kind == ArrangeRowKind::Audio) {
            const NSRect laneR = [self laneRect:lane row:hit.row];
            if (pt.x < kHeaderW) {
                if (NSPointInRect(pt, NSMakeRect(kHeaderW - 72, laneR.origin.y + 11, 56, 17))) [c cycleAutomationMode:lr.index lane:lane];
                [c selectRow:lr];
                [self setNeedsDisplay:YES];
                return;
            }
            [c selectRow:lr];
            [self clearSelectedEvents];
            if (_hasRange) { [self clearRange]; [c arrangeRangeChanged]; }
            const std::int64_t snapped = [c snapSample:sample];
            const double unit = [self unitForY:pt.y inLane:laneR];
            _autoTrack = static_cast<long>(lr.index);
            _autoLane = lane;
            // a point under the mouse?
            const AutomationLane* al = laneOf(*p, lr.index, lane);
            std::int64_t found = -1;
            float foundValue = 0.0F;
            if (al) {
                CGFloat best = 7.0;
                for (const auto& ap : al->points()) {
                    const CGFloat dx = std::abs(map.xForSample(ap.sample) - pt.x);
                    const CGFloat dy = std::abs([self yForUnit:laneUnit(lane, ap.value) inLane:laneR] - pt.y);
                    const CGFloat d = std::max(dx, dy);
                    if (d < best) { best = d; found = ap.sample; foundValue = ap.value; }
                }
            }
            if (found >= 0) {
                _autoPointSample = found;
                if (twice) { [self deleteSelectedAutomationPoint]; return; }
                _autoDragSample = found;
                _autoDragValue = foundValue;
                _drag = DragMode::AutoPoint;
                [c beginGesture:@"Move Automation Point"];
                _gestureOpen = YES;
                [self setNeedsDisplay:YES];
                return;
            }
            const float value = laneValue(lane, unit);
            if (tool == SVArrangeTool::Draw) {   // freehand: points follow the mouse
                _drag = DragMode::AutoDraw;
                _autoLastDrawSample = snapped;
                _autoDragSample = snapped;
                _autoDragValue = value;
                _autoPointSample = -1;
                [c beginGesture:@"Draw Automation"];
                _gestureOpen = YES;
                [c automationEdit:@"Draw Automation" track:lr.index lane:lane op:^(AutomationLane& a) { a.add(snapped, value); }];
                [self setNeedsDisplay:YES];
                return;
            }
            // a click adds a point and drags it
            [c beginGesture:@"Add Automation Point"];
            _gestureOpen = YES;
            [c automationEdit:@"Add Automation Point" track:lr.index lane:lane op:^(AutomationLane& a) { a.add(snapped, value); }];
            _autoPointSample = snapped;
            _autoDragSample = snapped;
            _autoDragValue = value;
            _drag = DragMode::AutoPoint;
            [self setNeedsDisplay:YES];
            return;
        }
    }
    if (hit.row < 0) {
        // Below the last track: the Range tool still starts a range (on the last row); the others clear the selection.
        if (tool == SVArrangeTool::Range && pt.x >= kHeaderW) {   // with no tracks yet the range still marks time (P sets the cycle to it)
            [self beginRangeAt:[c snapSample:sample] row:static_cast<long>(_rows.size()) - 1 shift:(event.modifierFlags & NSEventModifierFlagShift) != 0];
            return;
        }
        if (tool == SVArrangeTool::Zoom && pt.x >= kHeaderW) { _drag = DragMode::ZoomBox; _dragAnchor = _dragCurrent = sample; return; }
        if (tool == SVArrangeTool::Select && pt.x >= kHeaderW && !_rows.empty()) {
            _drag = DragMode::Marquee;
            _marqueeSampleA = _marqueeSampleB = sample;
            _marqueeRowA = _marqueeRowB = static_cast<long>(_rows.size()) - 1;
            const auto mods = event.modifierFlags;
            _marqueeSelectionMode = (mods & NSEventModifierFlagOption) ? 3 :
                                    (mods & NSEventModifierFlagCommand) ? 2 :
                                    (mods & NSEventModifierFlagShift) ? 1 : 0;
            _marqueeBase = _selectedEvents;
            return;
        }
        [self clearSelectedEvents];
        [c clearMarkedTracks];
        c.selectedClipId = 0;
        if (_hasRange) { [self clearRange]; [c arrangeRangeChanged]; }
        [c refreshAll];
        return;
    }
    const ArrangeRow row = _rows[static_cast<std::size_t>(hit.row)];
    // compute row top
    CGFloat y = topH() - self.scrollY;
    for (long i = 0; i < hit.row; ++i) y += rowHeight(_rows[static_cast<std::size_t>(i)]);
    if (hit.header) {
        if (row.kind == ArrangeRowKind::Folder) {
            if (pt.x < 26 + row.depth * 12.0) { [c toggleFolderCollapse:row.index]; return; }
            if (NSPointInRect(pt, pillRect(row, y, 0))) { [c toggleMute:row]; return; }
            if (NSPointInRect(pt, pillRect(row, y, 1))) { [c toggleSolo:row]; return; }
        } else {
            if (NSPointInRect(pt, pillRect(row, y, 0))) { [c toggleMute:row]; return; }
            if (NSPointInRect(pt, pillRect(row, y, 1))) { [c toggleSolo:row]; return; }
            if (row.kind == ArrangeRowKind::Audio && NSPointInRect(pt, pillRect(row, y, 2))) { [c toggleArm:row]; return; }
            if (row.kind == ArrangeRowKind::Audio && NSPointInRect(pt, pillRect(row, y, 3))) { [c toggleMonitor:row]; return; }
            if (row.kind == ArrangeRowKind::Audio && baseRowHeight(row) >= 60.0 &&
                NSPointInRect(pt, NSMakeRect(34 + row.depth * 12.0, y + baseRowHeight(row) - 19, 44, 15))) {   // AUTO: the lanes open / close
                if (!automationOpen().erase(row.index)) automationOpen().insert(row.index);
                [c selectRow:row];
                [self setNeedsDisplay:YES];
                return;
            }
            if (row.kind == ArrangeRowKind::Audio && baseRowHeight(row) >= 60.0 && row.index < p->tracks.size() && !p->tracks[row.index].takeLanes.empty() &&
                NSPointInRect(pt, NSMakeRect(82 + row.depth * 12.0, y + baseRowHeight(row) - 19, 48, 15))) {   // TAKES: the recorded takes open / close
                if (!takesOpen().erase(row.index)) takesOpen().insert(row.index);
                [c selectRow:row];
                [self setNeedsDisplay:YES];
                return;
            }
        }
        [self clearSelectedEvents];
        const NSEventModifierFlags hm = event.modifierFlags;
        const bool addTrack = (hm & NSEventModifierFlagCommand) != 0, runTrack = (hm & NSEventModifierFlagShift) != 0;
        if (row.kind == ArrangeRowKind::Audio) [c markTrack:row.index mode:(addTrack ? 1 : (runTrack ? 2 : 0))];
        else if (!addTrack && !runTrack) [c clearMarkedTracks];
        [c selectRow:row];
        // Selecting a header has to invalidate the lane and its selection outline.
        [c refreshAll];
        if (twice) { [c renameRow:row]; return; }
        if (row.kind == ArrangeRowKind::Audio && !addTrack && !runTrack) {
            _drag = DragMode::MoveTrackHeader;
            _dragTrack = row.index;
            _dropRow = hit.row;
        }
        return;
    }
    if (tool != SVArrangeTool::Select) [c selectRow:row];
    // The tools other than Object Selection (as the tool buttons of Cubase).
    if (tool != SVArrangeTool::Select) {
        [self clearSelectedEvents];
        const bool option = (event.modifierFlags & NSEventModifierFlagOption) != 0;
        const bool shift = (event.modifierFlags & NSEventModifierFlagShift) != 0;
        switch (tool) {
            case SVArrangeTool::Range:
                if (twice && (hit.clip || hit.part)) { [self setRangeToObjectIn:row clip:hit.clip part:hit.part]; [c arrangeRangeChanged]; [c refreshAll]; return; }
                [self beginRangeAt:[c snapSample:sample] row:hit.row shift:shift];
                return;
            case SVArrangeTool::Zoom:
                _drag = DragMode::ZoomBox;
                _dragAnchor = _dragCurrent = sample;
                _downPoint = pt;
                return;
            case SVArrangeTool::Draw:
                if (row.kind == ArrangeRowKind::Midi) {
                    _drag = DragMode::DrawPart;
                    _dragRow = hit.row;
                    _dragAnchor = _dragCurrent = [c snapSample:sample];
                } else {
                    [c setStatus:@"Draw creates MIDI parts — on an audio track, import a sound (⌘I) or record"];
                }
                return;
            case SVArrangeTool::Split:
            case SVArrangeTool::Glue:
            case SVArrangeTool::Erase:
            case SVArrangeTool::Mute:
                if (hit.clip || hit.part) [c toolClick:tool row:row clip:hit.clip part:hit.part atSample:[c snapSample:sample]];
                else [c seekToSample:[c snapSample:sample]];
                [c refreshAll];
                return;
            default: break;
        }
        (void)option;
    }
    if (_hasRange) { [self clearRange]; [c arrangeRangeChanged]; } // object selection and range selection are exclusive
    const std::uint64_t eventId = row.kind == ArrangeRowKind::Audio ? hit.clip : (row.kind == ArrangeRowKind::Midi ? hit.part : 0);
    const bool eventMidi = row.kind == ArrangeRowKind::Midi;
    const NSEventModifierFlags mods = event.modifierFlags;
    const bool shift = (mods & NSEventModifierFlagShift) != 0;
    const bool toggle = (mods & NSEventModifierFlagCommand) != 0;
    const bool option = (mods & NSEventModifierFlagOption) != 0;
    if (eventId) {
        const SVSelectedEvent clicked {eventMidi,row.index,eventId};
        if (shift || toggle) {
            if (toggle && _selectedEvents.count(clicked)) _selectedEvents.erase(clicked);
            else _selectedEvents.insert(clicked);
            [self setSelectedEvents:[self selectedEvents]];
            return;
        }
        if (!_selectedEvents.count(clicked) || twice || hit.edge != 0)
            [self setSelectedEvents:std::vector<SVSelectedEvent> {clicked}];
        [c selectRow:row];
        if (eventMidi) c.selectedPartId = eventId;
        else c.selectedClipId = eventId;
        _dragTrack = row.index;
        _dragId = eventId;
        _dragAnchor = [c snapSample:sample];
        _duplicateOnDrag = option;
        _lastMoveDelta = std::numeric_limits<std::int64_t>::min();
        if (twice) { [self setSelectedEvents:std::vector<SVSelectedEvent>{clicked}]; [c openEditor:nil]; return; }
        if (_selectedEvents.size() > 1 || option) {
            _drag = DragMode::MoveSelection;
            [self captureMoveOrigins];
        } else if (eventMidi) {
            const double q = p->tempoMap.quarterNotesAtSample(sample);
            for (const auto& part : p->midiTracks[row.index].parts) if (part.id == eventId) _grabOffsetQ = q - part.timelineStartQuarterNotes;
            _drag = DragMode::MovePart;
        } else {
            for (const auto& clip : p->tracks[row.index].clips) if (clip.id == eventId) _grabOffset = sample - clip.timelineStartSample;
            _drag = hit.edge < 0 ? DragMode::TrimLeft : (hit.edge > 0 ? DragMode::TrimRight : DragMode::MoveClip);
        }
    } else if (row.kind == ArrangeRowKind::Midi && hit.legacyPart && twice) {
        [self clearSelectedEvents];
        [c openEditor:nil];
    } else if (row.kind == ArrangeRowKind::Midi && twice) {
        [self clearSelectedEvents];
        [c createPartForMidiTrack:row.index atSample:[c snapSample:sample]];
    } else {
        // Clicking empty track area is a pending marquee, not an immediate seek.
        // Only on mouse-up without a drag does it move the playhead.
        _marqueeBase = _selectedEvents;
        _marqueeSampleA = _marqueeSampleB = sample;
        _marqueeRowA = _marqueeRowB = hit.row;
        _marqueeSelectionMode = option ? 3 : toggle ? 2 : shift ? 1 : 0;
        _drag = DragMode::Marquee;
    }
    [c refreshAll];
}

- (void)mouseDragged:(NSEvent*)event {
    SilvetonController* c = self.controller;
    Project* p = c.project;
    if (!p || _drag == DragMode::None) return;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (!_moved && std::hypot(pt.x - _downPoint.x, pt.y - _downPoint.y) < 3.0) return;
    _moved = YES;
    const double scrollBefore = self.scrollSeconds, scrollYBefore = self.scrollY;
    [self autoScrollSelectionAt:pt];
    _dragScrolled = self.scrollSeconds != scrollBefore || self.scrollY != scrollYBefore;
    const auto map = [self mapping];
    const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    switch (_drag) {
        case DragMode::MoveTrackHeader: {
            const long at = [self rowAtY:pt.y];
            if (at >= 0 && at < static_cast<long>(_rows.size()) &&
                _rows[static_cast<std::size_t>(at)].kind == ArrangeRowKind::Audio)
                _dropRow = at;
            break;
        }
        case DragMode::Ruler:
        case DragMode::NewSection:
            _dragCurrent = [c snapSample:sample];
            break;
        case DragMode::Marquee:
            _marqueeSampleB = sample;
            _marqueeRowB = std::max<long>(0,[self rowAtY:pt.y]);
            [self updateMarqueeSelection];
            break;
        case DragMode::MoveSelection: {
            if (!_gestureOpen) {
                [c beginGesture:_duplicateOnDrag ? @"Copy Selected Events" : @"Move Selected Events"];
                _gestureOpen = YES;
                if (_duplicateOnDrag) {
                    [c duplicateArrangeEvents];
                    [self captureMoveOrigins];
                    _duplicateOnDrag = NO;
                }
            }
            std::int64_t delta = [c snapSample:sample] - _dragAnchor;
            for (const auto& origin : _moveOrigins)
                delta = std::max(delta,-origin.startSample);
            if (delta != _lastMoveDelta) {
                [c moveArrangeEvents:_moveOrigins deltaSamples:delta];
                _lastMoveDelta = delta;
            }
            break;
        }
        case DragMode::MoveClip:
            if (!_gestureOpen) { [c beginGesture:@"Move Clip"]; _gestureOpen = YES; }
            [c dragClip:_dragId track:_dragTrack toSample:std::max<std::int64_t>(0, sample - _grabOffset)];
            break;
        case DragMode::TrimLeft:
        case DragMode::TrimRight:
            if (!_gestureOpen) { [c beginGesture:@"Trim Clip"]; _gestureOpen = YES; }
            [c dragClipEdge:_dragId track:_dragTrack leftEdge:(_drag == DragMode::TrimLeft) toSample:sample];
            break;
        case DragMode::ResizeRow:
            chosenHeights()[_resizeKey] = std::min(kMaxTrackH, std::max(kMinTrackH, _resizeStartH + (pt.y - _downPoint.y)));
            break;
        case DragMode::MovePart: {
            if (!_gestureOpen) { [c beginGesture:@"Move MIDI Part"]; _gestureOpen = YES; }
            const double q = p->tempoMap.quarterNotesAtSample([c snapSample:sample]) - _grabOffsetQ;
            const double div = std::max<std::uint32_t>(1U, c.gridDivisionsPerQuarter);
            [c dragPart:_dragId midiTrack:_dragTrack toQuarter:std::max(0.0, c.snapEnabled ? std::round(q * div) / div : q)];
            break;
        }
        case DragMode::Range: {
            const std::int64_t cur = [c snapSample:sample];
            _hasRange = YES;
            _rangeStart = std::min(_rangeAnchor, cur);
            _rangeEnd = std::max(_rangeAnchor, cur);
            if (_rows.empty()) { _rangeRowA = _rangeRowB = -1; _rangeKeyA = _rangeKeyB = 0U; [c arrangeRangeChanged]; break; }
            long row = [self rowAtY:pt.y];
            if (row < 0) row = 0;
            const long a = std::min(std::max<long>(0, _rangeAnchorRow), row), b = std::max(std::max<long>(0, _rangeAnchorRow), row);
            _rangeRowA = a; _rangeRowB = b;
            _rangeKeyA = rowKey(_rows[static_cast<std::size_t>(a)]);
            _rangeKeyB = rowKey(_rows[static_cast<std::size_t>(b)]);
            [c arrangeRangeChanged];
            break;
        }
        case DragMode::ZoomBox:
            _dragCurrent = sample;
            break;
        case DragMode::DrawPart:
            _dragCurrent = [c snapSample:sample];
            break;
        case DragMode::CompRange:
            _dragCurrent = std::max(_compClipStart, std::min(_compClipEnd, [c snapSample:sample]));
            break;
        case DragMode::TempoPoint: {
            const double bpm = [self bpmForY:pt.y];
            const std::int64_t to = _tempoDragSample == 0 ? 0 : std::max<std::int64_t>(1, [c snapSample:sample]);   // the first tempo stays at the start
            const std::int64_t from = _tempoDragSample;
            [c tempoGestureEdit:^(TempoMap& tm) {
                if (from == 0) tm.setInitialTempo(bpm);
                else if (!tm.moveTempoChange(from, to, bpm)) tm.addTempoChange(to, bpm);
            }];
            _tempoDragSample = to;
            _tempoDragBpm = bpm;
            _tempoSel = to;
            break;
        }
        case DragMode::AutoPoint: {
            if (_autoTrack < 0 || _autoLane < 0 || _autoPointSample < 0) break;
            long row = -1;
            for (std::size_t i = 0; i < _rows.size(); ++i) if (_rows[i].kind == ArrangeRowKind::Audio && static_cast<long>(_rows[i].index) == _autoTrack) row = static_cast<long>(i);
            if (row < 0) break;
            const NSRect laneR = [self laneRect:_autoLane row:row];
            const std::int64_t to = std::max<std::int64_t>(0, [c snapSample:sample]);
            const float value = laneValue(_autoLane, [self unitForY:pt.y inLane:laneR]);
            const std::int64_t from = _autoPointSample;
            const int lane = _autoLane;
            [c automationEdit:@"Move Automation Point" track:static_cast<std::size_t>(_autoTrack) lane:lane op:^(AutomationLane& a) {
                if (!a.movePoint(from, to, value)) a.add(to, value);
            }];
            _autoPointSample = to;
            _autoDragSample = to;
            _autoDragValue = value;
            break;
        }
        case DragMode::AutoDraw: {
            if (_autoTrack < 0 || _autoLane < 0) break;
            long row = -1;
            for (std::size_t i = 0; i < _rows.size(); ++i) if (_rows[i].kind == ArrangeRowKind::Audio && static_cast<long>(_rows[i].index) == _autoTrack) row = static_cast<long>(i);
            if (row < 0) break;
            const NSRect laneR = [self laneRect:_autoLane row:row];
            const std::int64_t at = std::max<std::int64_t>(0, [c snapSample:sample]);
            const float value = laneValue(_autoLane, [self unitForY:pt.y inLane:laneR]);
            const std::int64_t last = _autoLastDrawSample;
            const std::int64_t minStep = std::max<std::int64_t>(1, static_cast<std::int64_t>(3.0 / std::max(1.0e-6, map.pixelsPerSecond / map.sampleRate)));   // one point per 3 px
            if (std::abs(at - last) < minStep && at != last) break;
            const int lane = _autoLane;
            [c automationEdit:@"Draw Automation" track:static_cast<std::size_t>(_autoTrack) lane:lane op:^(AutomationLane& a) {
                // the stroke overwrites what it passes over
                const std::int64_t lo = std::min(last, at), hi = std::max(last, at);
                std::vector<std::int64_t> gone;
                for (const auto& ap : a.points()) if (ap.sample > lo && ap.sample < hi) gone.push_back(ap.sample);
                for (std::int64_t sgone : gone) (void)a.removeAt(sgone);
                a.add(at, value);
            }];
            _autoLastDrawSample = at;
            _autoDragSample = at;
            _autoDragValue = value;
            break;
        }
        default: break;
    }
    [self repaintForDrag];
}

// While the mouse is down only the rows the drag touches are painted again — a full repaint of
// every track and waveform at mouse speed kept an older machine busy and the sound broke up.
- (void)repaintForDrag {
    const NSRect b = self.bounds;
    if (_dragScrolled) { _dragScrolled = NO; [self setNeedsDisplay:YES]; return; }   // the view scrolled: everything moved
    auto rowsRect = [&](long a, long bRow) {
        if (_rows.empty()) return b;
        a = std::max<long>(0, std::min<long>(a, static_cast<long>(_rows.size()) - 1));
        bRow = std::max<long>(0, std::min<long>(bRow, static_cast<long>(_rows.size()) - 1));
        if (a > bRow) std::swap(a, bRow);
        const CGFloat y0 = [self topOfRow:a], y1 = [self topOfRow:bRow] + rowHeight(_rows[static_cast<std::size_t>(bRow)]);
        return NSMakeRect(0, std::max<CGFloat>(topH(), y0 - 2), b.size.width, std::max<CGFloat>(0, y1 - y0 + 4));
    };
    auto rowOfTrack = [&](long track, bool midi) -> long {
        for (std::size_t i = 0; i < _rows.size(); ++i)
            if ((_rows[i].kind == (midi ? ArrangeRowKind::Midi : ArrangeRowKind::Audio)) && static_cast<long>(_rows[i].index) == track) return static_cast<long>(i);
        return -1;
    };
    switch (_drag) {
        case DragMode::Ruler:
        case DragMode::NewSection:
            [self setNeedsDisplayInRect:NSMakeRect(0, 0, b.size.width, topH())];
            return;
        case DragMode::MoveClip:
        case DragMode::TrimLeft:
        case DragMode::TrimRight:
        case DragMode::DrawPart:
        case DragMode::MovePart: {
            const long row = _drag == DragMode::DrawPart ? _dragRow : rowOfTrack(static_cast<long>(_dragTrack), _drag == DragMode::MovePart);
            if (row >= 0) { [self setNeedsDisplayInRect:rowsRect(row, row)]; return; }
            break;
        }
        case DragMode::MoveSelection: {
            long lo = -1, hi = -1;
            for (const auto& o : _moveOrigins) {
                const long row = rowOfTrack(static_cast<long>(o.event.track), o.event.midi);
                if (row < 0) continue;
                lo = lo < 0 ? row : std::min(lo, row);
                hi = hi < 0 ? row : std::max(hi, row);
            }
            if (lo >= 0) { [self setNeedsDisplayInRect:rowsRect(lo, hi)]; return; }
            break;
        }
        case DragMode::Range: {
            if (_rows.empty()) break;
            long a = 0, bRow = 0;
            if ([self rangeRowIndicesFrom:&a to:&bRow]) {
                const long anchor = std::max<long>(0, std::min<long>(_rangeAnchorRow, static_cast<long>(_rows.size()) - 1));
                [self setNeedsDisplayInRect:rowsRect(std::min(a, anchor), std::max(bRow, anchor))];
                [self setNeedsDisplayInRect:rowsRect(0, static_cast<long>(_rows.size()) - 1)];   // the rows that just left the range
                return;
            }
            break;
        }
        case DragMode::Marquee: {
            const long a = std::min(_marqueeRowA, _marqueeRowB), bRow = std::max(_marqueeRowA, _marqueeRowB);
            [self setNeedsDisplayInRect:rowsRect(std::min<long>(a, 0), std::max<long>(bRow, static_cast<long>(_rows.size()) - 1))];
            return;
        }
        case DragMode::AutoPoint:
        case DragMode::AutoDraw:
        case DragMode::CompRange: {
            const long row = rowOfTrack(_autoTrack, false);
            if (row >= 0) { [self setNeedsDisplayInRect:rowsRect(row, row)]; return; }
            break;
        }
        default: break;
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    SilvetonController* c = self.controller;
    const auto map = [self mapping];
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (_drag == DragMode::MoveTrackHeader && _moved && _dropRow >= 0 &&
        _dropRow < static_cast<long>(_rows.size())) {
        const ArrangeRow target = _rows[static_cast<std::size_t>(_dropRow)];
        if (target.kind == ArrangeRowKind::Audio && target.index != _dragTrack)
            [c reorderAudioTrackFrom:_dragTrack to:target.index];
    } else if (_drag == DragMode::Ruler) {
        if (_moved && _dragCurrent != _dragAnchor) [c setCycleStart:std::min(_dragAnchor, _dragCurrent) end:std::max(_dragAnchor, _dragCurrent)];
        else [c seekToSample:std::max<std::int64_t>(0, map.sampleForX(pt.x))];
    } else if (_drag == DragMode::NewSection && _moved && _dragCurrent != _dragAnchor) {
        [c createSectionFrom:std::min(_dragAnchor, _dragCurrent) to:std::max(_dragAnchor, _dragCurrent)];
    } else if (_drag == DragMode::Marquee) {
        if (!_moved) {
            if (_marqueeSelectionMode == 0) [self clearSelectedEvents];
            [c seekToSample:std::max<std::int64_t>(0,map.sampleForX(pt.x))];
        } else {
            [c setStatus:[NSString stringWithFormat:@"%lu audio/MIDI events selected — drag together, ⌥-drag to copy", (unsigned long)_selectedEvents.size()]];
        }
    } else if (_drag == DragMode::CompRange && _autoTrack >= 0) {
        const std::int64_t a = _moved ? std::min(_dragAnchor, _dragCurrent) : _compClipStart;
        const std::int64_t bEnd = _moved ? std::max(_dragAnchor, _dragCurrent) : _compClipEnd;
        if (bEnd > a) [c compUseTake:static_cast<std::size_t>(_autoTrack) lane:_compLaneId clip:_compClipId from:a to:bEnd];
    } else if (_drag == DragMode::Range) {
        if (!_moved || _rangeEnd <= _rangeStart) {   // a plain click: no range, the cursor goes there
            [self clearRange];
            [c seekToSample:std::max<std::int64_t>(0, [c snapSample:map.sampleForX(pt.x)])];
        }
        [c arrangeRangeChanged];
    } else if (_drag == DragMode::ZoomBox) {
        const CGFloat x0 = map.xForSample(std::min(_dragAnchor, _dragCurrent)), x1 = map.xForSample(std::max(_dragAnchor, _dragCurrent));
        if (_moved && x1 - x0 > 8.0) [self zoomToSamples:std::min(_dragAnchor, _dragCurrent) to:std::max(_dragAnchor, _dragCurrent)];
        else [self zoomAroundX:pt.x factor:(event.modifierFlags & NSEventModifierFlagOption) ? 0.5 : 2.0];   // click = in, ⌥ click = out
    } else if (_drag == DragMode::DrawPart && _dragRow >= 0 && _dragRow < static_cast<long>(_rows.size())) {
        const ArrangeRow row = _rows[static_cast<std::size_t>(_dragRow)];
        if (row.kind == ArrangeRowKind::Midi) {
            const std::int64_t a = std::min(_dragAnchor, _dragCurrent), b = std::max(_dragAnchor, _dragCurrent);
            [c createPartForMidiTrack:row.index from:a to:(_moved && b > a ? b : a)];   // a click gives one bar
        }
    }
    if (_gestureOpen) { [c endGesture]; _gestureOpen = NO; }
    _drag = DragMode::None;
    [c refreshAll];
}

// The Range tool: a press starts a new range (or, with Shift, extends the one there is).
- (void)beginRangeAt:(std::int64_t)sample row:(long)row shift:(BOOL)shift {
    _drag = DragMode::Range;
    if (_rows.empty()) {   // an empty project: the range is a span of time only
        _rangeAnchor = sample;
        _rangeAnchorRow = -1;
        _hasRange = NO;
        [self setNeedsDisplay:YES];
        return;
    }
    row = std::min<long>(std::max<long>(0, row), static_cast<long>(_rows.size()) - 1);
    if (shift && [self hasRange]) {
        // the far end stays, the near end follows the mouse
        long a = 0, b = 0;
        [self rangeRowIndicesFrom:&a to:&b];
        const bool nearStart = std::abs(sample - _rangeStart) < std::abs(sample - _rangeEnd);
        _rangeAnchor = nearStart ? _rangeEnd : _rangeStart;
        _rangeAnchorRow = row <= a ? b : a;
        _moved = YES;
        _rangeStart = std::min(_rangeAnchor, sample);
        _rangeEnd = std::max(_rangeAnchor, sample);
        const long ra = std::min(_rangeAnchorRow, row), rb = std::max(_rangeAnchorRow, row);
        _rangeRowA = ra; _rangeRowB = rb;
        _rangeKeyA = rowKey(_rows[static_cast<std::size_t>(ra)]);
        _rangeKeyB = rowKey(_rows[static_cast<std::size_t>(rb)]);
        [self.controller arrangeRangeChanged];
    } else {
        _rangeAnchor = sample;
        _rangeAnchorRow = row;
        _hasRange = NO;
    }
    [self setNeedsDisplay:YES];
}

// Double-click with the Range tool: the range becomes the clip / part under the mouse.
- (void)setRangeToObjectIn:(ArrangeRow)row clip:(std::uint64_t)clipId part:(std::uint64_t)partId {
    const Project* p = self.controller.project;
    if (!p) return;
    TimelineRange r;
    if (row.kind == ArrangeRowKind::Audio && row.index < p->tracks.size()) {
        for (const auto& c : p->tracks[row.index].clips)
            if (c.id == clipId) r = TimelineRange {c.timelineStartSample, c.timelineStartSample + static_cast<std::int64_t>(c.lengthSamples)};
    } else if (row.kind == ArrangeRowKind::Midi && row.index < p->midiTracks.size()) {
        for (const auto& part : p->midiTracks[row.index].parts)
            if (part.id == partId) r = TimelineRange {p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes),
                                                      p->tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes + part.lengthQuarterNotes)};
    }
    if (r.valid()) [self setRange:r rows:std::vector<ArrangeRow> {row}];
}

- (NSMenu*)menuForEvent:(NSEvent*)event {
    SilvetonController* c = self.controller;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    const auto map = [self mapping];
    const std::int64_t sample = std::max<std::int64_t>(0, map.sampleForX(pt.x));
    if (pt.y < topH() && pt.x >= kHeaderW && c.project) {
        if (pt.y >= kRulerH && pt.y < kRulerH + kMarkerH) {
            for (const auto& m : c.project->markers) {
                const CGFloat mx = map.xForSample(m.sample);
                if (pt.x >= mx - 3 && pt.x <= mx + 10) return [c contextMenuForMarker:m.id];
            }
        } else if (pt.y >= kRulerH + kMarkerH) {
            for (const auto& s : c.project->arrangerSections)
                if (sample >= s.startSample && sample < s.endSample) return [c contextMenuForSection:s.id];
        }
        return nil;
    }
    const Hit hit = [self hitAt:pt];
    ArrangeRow row;
    bool haveRow = hit.row >= 0;
    if (haveRow) {
        row = _rows[static_cast<std::size_t>(hit.row)];
        const std::uint64_t id = row.kind == ArrangeRowKind::Audio ? hit.clip : (row.kind == ArrangeRowKind::Midi ? hit.part : 0);
        if (id) {
            SVSelectedEvent clicked {row.kind == ArrangeRowKind::Midi,row.index,id};
            if (!_selectedEvents.count(clicked)) [self setSelectedEvents:std::vector<SVSelectedEvent>{clicked}];
        } else [self clearSelectedEvents];
        [c selectRow:row];
        if (row.kind == ArrangeRowKind::Audio) c.selectedClipId = hit.clip;
        if (row.kind == ArrangeRowKind::Midi) c.selectedPartId = hit.part;
    } else {
        row.kind = ArrangeRowKind::Audio;
        row.index = static_cast<std::size_t>(-1);
    }
    [c seekToSample:sample];
    return [c contextMenuForRow:row clip:hit.clip part:hit.part atSample:sample];
}

- (void)scrollWheel:(NSEvent*)event {
    const NSEventModifierFlags mods = event.modifierFlags & NSEventModifierFlagDeviceIndependentFlagsMask;
    SilvetonController* c = self.controller;
    if ((mods & NSEventModifierFlagOption) || (mods & NSEventModifierFlagCommand)) {
        const double dy = event.scrollingDeltaY;
        if (std::abs(dy) > 0.001) {
            const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
            const auto before = [self mapping];
            const std::int64_t anchor = before.sampleForX(pt.x);
            [c setPixelsPerSecond:c.pixelsPerSecond * std::pow(1.08, dy / 4.0)];
            const double pps = c.pixelsPerSecond;
            self.scrollSeconds = std::max(0.0, static_cast<double>(anchor) / before.sampleRate - (pt.x - kHeaderW) / pps);
        }
    } else {
        double dx = event.scrollingDeltaX, dy = event.scrollingDeltaY;
        if (!event.hasPreciseScrollingDeltas) { dx *= 12; dy *= 12; }
        if (mods & NSEventModifierFlagShift) { dx = dy; dy = 0; }
        self.scrollSeconds = std::max(0.0, self.scrollSeconds - dx / std::max(1.0, c.pixelsPerSecond));
        self.scrollY = std::max(0.0, self.scrollY - dy);
    }
    [self setNeedsDisplay:YES];
}
- (void)magnifyWithEvent:(NSEvent*)event {
    [self.controller setPixelsPerSecond:self.controller.pixelsPerSecond * (1.0 + event.magnification)];
    [self setNeedsDisplay:YES];
}

// External file drops
- (NSArray<NSURL*>*)audioURLs:(id<NSDraggingInfo>)sender {
    NSArray* urls = [sender.draggingPasteboard readObjectsForClasses:@[[NSURL class]] options:@{NSPasteboardURLReadingFileURLsOnlyKey: @YES}];
    NSMutableArray<NSURL*>* out = [NSMutableArray array];
    for (NSURL* u in urls) {
        NSString* ext = u.pathExtension.lowercaseString;
        if ([ext isEqualToString:@"wav"] || [ext isEqualToString:@"aif"] || [ext isEqualToString:@"aiff"]) [out addObject:u];
    }
    return out;
}
- (NSDragOperation)draggingEntered:(id<NSDraggingInfo>)sender {
    _externalDrag = [self audioURLs:sender].count > 0;
    [self setNeedsDisplay:YES];
    return _externalDrag ? NSDragOperationCopy : NSDragOperationNone;
}
- (NSDragOperation)draggingUpdated:(id<NSDraggingInfo>)sender { return [self audioURLs:sender].count > 0 ? NSDragOperationCopy : NSDragOperationNone; }
- (void)draggingExited:(id<NSDraggingInfo>)sender { (void)sender; _externalDrag = NO; [self setNeedsDisplay:YES]; }
- (BOOL)performDragOperation:(id<NSDraggingInfo>)sender {
    NSArray<NSURL*>* urls = [self audioURLs:sender];
    _externalDrag = NO;
    [self setNeedsDisplay:YES];
    if (urls.count == 0) return NO;
    const NSPoint pt = [self convertPoint:sender.draggingLocation fromView:nil];
    const std::int64_t sample = pt.x > kHeaderW ? [self.controller snapSample:std::max<std::int64_t>(0, [self mapping].sampleForX(pt.x))]
                                                : self.controller.playheadSample;
    [self.controller importAudioURLs:urls atSample:sample];
    return YES;
}
@end
