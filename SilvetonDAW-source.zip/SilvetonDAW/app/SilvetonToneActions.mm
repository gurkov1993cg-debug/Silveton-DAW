// Silveton — Tone Editor: the part of the controller that opens a sound, finds its tones in the
// background, renders the changed sound again after a quiet moment and keeps everything in the
// project (so Undo, Redo and saving just work). The window is SilvetonToneView.mm; the maths is
// ToneAnalysis / ToneEditing / ToneRender (tested without any window code).
#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/NativePlugins.h"
#include "silveton/ToneEdit.h"
#include "silveton/ToneProject.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

using namespace silveton;

// ================================================================ helpers ==
namespace {

NSTextField* toneLabel(NSView* parent, NSString* s, NSRect f, NSFont* font, NSColor* color, NSTextAlignment a = NSTextAlignmentLeft) {
    NSTextField* t = [NSTextField labelWithString:s ?: @""];
    t.frame = f;
    t.font = font;
    t.textColor = color;
    t.alignment = a;
    t.lineBreakMode = NSLineBreakByTruncatingTail;
    [parent addSubview:t];
    return t;
}

void toneSection(NSView* parent, NSString* title, CGFloat y, CGFloat w) { (void)sectionHeader(parent, title, y, w); }

NSPopUpButton* tonePopup(NSView* parent, NSRect f, id target, SEL action) {
    NSPopUpButton* p = [[NSPopUpButton alloc] initWithFrame:f pullsDown:NO];
    p.font = sv::ui(11);
    p.target = target;
    p.action = action;
    [parent addSubview:p];
    return p;
}

struct ParamInfo {
    const char* name;
    double min, max, reset;
};
const ParamInfo kParams[SVToneParamCount] = {
    {"Correct Pitch", 0, 100, 0},        // SVToneParamSnap
    {"Straighten", 0, 100, 0},           // SVToneParamFlatten
    {"Vibrato", 0, 200, 100},         // SVToneParamVibrato
    {"Tilt", -100, 100, 0},           // SVToneParamTilt
    {"Move", -1200, 1200, 0},         // SVToneParamMove
    {"Shift Formant", -1200, 1200, 0},      // SVToneParamFormant
    {"Volume", -24, 12, 0},         // SVToneParamGain
    {"Glide", 0, 120, 30},            // SVToneParamTransition
    {"Strength", 0, 100, 100},        // SVToneParamTimingAmount
    {"Sensitivity", 0, 100, 50},      // SVToneParamSensitivity
    {"Split", 0, 100, 50},            // SVToneParamSplitSensitivity
    {"Lowest", 40, 400, 60},          // SVToneParamLowest
    {"Highest", 300, 2000, 1100},     // SVToneParamHighest
    {"Shortest", 20, 200, 45},        // SVToneParamMinBlock
};

NSString* paramText(int param, double v) {
    switch (param) {
        case SVToneParamSnap: case SVToneParamFlatten: case SVToneParamVibrato: case SVToneParamTimingAmount:
        case SVToneParamSensitivity: case SVToneParamSplitSensitivity:
            return [NSString stringWithFormat:@"%.0f %%", v];
        case SVToneParamTilt: case SVToneParamMove: case SVToneParamFormant:
            return [NSString stringWithFormat:@"%+.0f c", v];
        case SVToneParamGain: return [NSString stringWithFormat:@"%+.1f dB", v];
        case SVToneParamTransition: case SVToneParamMinBlock: return [NSString stringWithFormat:@"%.0f ms", v];
        case SVToneParamLowest: case SVToneParamHighest: return [NSString stringWithFormat:@"%.0f Hz", v];
        default: return @"";
    }
}

NSString* noteName(double midi) {
    static const char* names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    const long n = std::lround(midi);
    const long pc = ((n % 12) + 12) % 12;
    return [NSString stringWithFormat:@"%s%ld", names[pc], (n - pc) / 12 - 1];
}

std::string clipAudioPath(const Project& p, std::size_t track, const ProjectAudioClip& clip) {
    return clip.audioPath.empty() ? p.tracks[track].audioPath : clip.audioPath;
}

} // namespace

@implementation SilvetonController (Tone)

// ================================================================== state ==
- (SVToneSession*)toneSession { return _tone.get(); }

- (void)toneReadout:(NSString*)text {
    if (!_core || !_toneView || [_toneView isHidden] || self.selectedTrack < 0) return;
    NSString* title = [NSString stringWithFormat:@"Tone Editor — %@", sv::ns(_core->project().tracks[static_cast<std::size_t>(self.selectedTrack)].name)];
    _editTitle.stringValue = text.length ? [NSString stringWithFormat:@"%@      %@", title, text] : title;
}

- (BOOL)toneEditorShown {
    return [self editorShown] && _toneMode && _toneView != nil && ![_toneView isHidden] && [self editedClip] != nullptr;
}
- (BOOL)toneEditorActive { return [self toneEditorShown] && [self editorFocused]; }

- (SVToneTool)toneTool { return _toneTool; }

- (void)setToneTool:(SVToneTool)tool {
    _toneTool = tool;
    for (int i = 0; i < 6; ++i) _toneToolButtons[i].state = (i == static_cast<int>(tool)) ? NSControlStateValueOn : NSControlStateValueOff;
    [_toneView setNeedsDisplay:YES];
    [_window invalidateCursorRectsForView:_toneView];
    static const char* hints[6] = {
        "Select: click a block, drag it up or down to change its pitch, drag its edges to change where it starts and ends",
        "Time Bend: drag a block left or right, drag its edges to stretch it, drag the sound at the bottom to bend it with points",
        "Cut: click in a block to cut it in two",
        "Glue: click a block to join it with the next one",
        "Erase: click a block to remove it",
        "Draw: drag over a gap to make a new block there"};
    [self setStatus:sv::ns(hints[std::clamp(static_cast<int>(tool), 0, 5)])];
}

- (void)toneToolPicked:(SVToggle*)sender { [self setToneTool:static_cast<SVToneTool>(sender.tag)]; }

- (BOOL)toneCanEdit {
    if (!_tone || _tone->phase != SVToneSession::Phase::Ready) { [self setStatus:@"The Tone Editor is still reading the sound — wait a moment"]; return NO; }
    if (_core && _tone->track < _core->project().tracks.size() && _core->project().tracks[_tone->track].locked) {
        [self setStatus:@"The track is locked — unlock it to change the tones"];
        return NO;
    }
    return YES;
}

- (std::int64_t)toneTimelineSample:(std::int64_t)position { return _tone ? _tone->origin + position : position; }

- (void)toneSetModeFromButton:(id)sender {
    _toneMode = [sender tag] == 1;
    [self refreshEditPage];
    if (_toneMode && [self editorShown]) [_window makeFirstResponder:_toneView];
}

- (void)openToneEditor:(id)sender {
    (void)sender;
    if (![self editedClip]) {
        [self setStatus:@"Select an audio clip with a single voice (a singer or a solo instrument) first, then open the Tone Editor"];
        return;
    }
    _toneMode = YES;
    [self showEditorInZone];
}

// Where position 0 of the analysed sound is on the timeline.
- (void)toneUpdateOrigin {
    ProjectAudioClip* clip = [self editedClip];
    if (!_tone || !clip || !_core) return;
    const Project& p = _core->project();
    const std::string path = clipAudioPath(p, _tone->track, *clip);
    const ProjectToneRecord* record = ToneProject::find(p, path);
    const bool rendered = record != nullptr && record->rate == static_cast<std::uint32_t>(std::llround(p.sampleRate));
    const std::int64_t offset = rendered ? static_cast<std::int64_t>(clip->sourceStartSample)
                                         : static_cast<std::int64_t>(clip->sourceStartSample) - static_cast<std::int64_t>(_tone->source.start);
    _tone->origin = clip->timelineStartSample - offset;
}

// ================================================================== opening ==
- (void)toneOpenTrack:(std::size_t)track clip:(std::uint64_t)clipId {
    [self toneOpenTrack:track clip:clipId options:nullptr];
}

// `forced` (optional) replace the listening settings, and the saved blocks are dropped ("Listen Again").
- (void)toneOpenTrack:(std::size_t)track clip:(std::uint64_t)clipId options:(const ToneAnalysisOptions*)forced {
    if (_tone) { _tone->stop->store(true); _tone->renderStop->store(true); }
    auto s = std::make_shared<SVToneSession>();
    s->track = track;
    s->clipId = clipId;
    const Project& p = _core->project();
    s->rate = p.sampleRate;
    s->clipName = track < p.tracks.size() ? p.tracks[track].name : std::string();
    _tone = s;
    [_toneView sessionChanged];
    ToneEdit saved;
    bool hasSaved = false;
    try {
        s->source = ToneProject::sourceFor(p, track, clipId);
        for (const auto& c : p.tracks[track].clips) if (c.id == clipId) s->renderedPath = clipAudioPath(p, track, c);
        hasSaved = forced == nullptr && s->source.fromRecord && ToneProject::savedEdit(p, track, clipId, saved);
        if (forced) s->source.options = *forced;
        const double seconds = static_cast<double>(s->source.length) / std::max(1.0, p.sampleRate);
        if (seconds > 1200.0) throw std::runtime_error("The clip is longer than 20 minutes. Cut it into shorter pieces first.");
    } catch (const std::exception& e) {
        s->phase = SVToneSession::Phase::Failed;
        s->message = e.what();
        [_toneView setNeedsDisplay:YES];
        [self toneRefreshInspector];
        return;
    }
    [self toneUpdateOrigin];
    [self toneRefreshInspector];
    const bool again = forced != nullptr;
    const double rate = s->rate;
    const ToneSource source = s->source;
    SilvetonController* me = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        std::shared_ptr<AudioBuffer> audio;
        std::shared_ptr<ToneAnalysis> analysis;
        std::string error;
        try {
            audio = std::make_shared<AudioBuffer>(ToneProject::readSource(source, rate));
            analysis = std::make_shared<ToneAnalysis>(ToneAnalyzer::analyze(*audio, rate, source.options, s->stop.get(), s->progress.get()));
        } catch (const std::exception& e) {
            error = e.what();
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (me->_tone != s) return;
            if (!error.empty()) {
                s->phase = SVToneSession::Phase::Failed;
                s->message = error;
            } else if (analysis && !analysis->cancelled) {
                s->audio = audio;
                s->analysis = analysis;
                s->edit = hasSaved ? saved : analysis->initial;
                s->phase = SVToneSession::Phase::Ready;
                if (s->edit.blocks.empty())
                    s->message = "No sung notes were found. Raise Sensitivity, widen Lowest / Highest, or draw blocks with the Draw tool.";
            } else {
                return;
            }
            [me toneUpdateOrigin];
            [me->_toneView sessionLoaded];
            [me toneRefreshInspector];
            if (s->phase == SVToneSession::Phase::Ready && again && [me toneCanEdit]) [me toneEdited:@"Analyze Again"];
            if (s->phase == SVToneSession::Phase::Ready)
                [me setStatus:[NSString stringWithFormat:@"Tone Editor: found %lu tone segment%s", (unsigned long)s->edit.blocks.size(), s->edit.blocks.size() == 1U ? "" : "s"]];
        });
    });
}

// Called by the Editor page whenever the project changed: opens the clip, or follows undo / redo.
- (void)toneSync {
    ProjectAudioClip* clip = [self editedClip];
    if (!clip || !_toneMode || !_core) return;
    const Project& p = _core->project();
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    if (track >= p.tracks.size()) return;
    if (!_tone || _tone->track != track || _tone->clipId != clip->id) { [self toneOpenTrack:track clip:clip->id]; return; }
    SVToneSession& s = *_tone;
    [self toneUpdateOrigin];
    if (s.phase != SVToneSession::Phase::Ready) return;
    const std::string path = clipAudioPath(p, track, *clip);
    if (path == s.renderedPath) return;
    // The clip plays another file than the one this window knows: Undo, Redo, or another process.
    ToneSource now;
    try { now = ToneProject::sourceFor(p, track, clip->id); } catch (...) { [self toneOpenTrack:track clip:clip->id]; return; }
    if (now.path != s.source.path || now.start != s.source.start || now.length != s.source.length) {
        [self toneOpenTrack:track clip:clip->id];
        return;
    }
    ToneEdit saved;
    s.edit = ToneProject::savedEdit(p, track, clip->id, saved) ? saved : s.analysis->initial;
    s.renderedPath = path;
    s.dirty = false;
    s.editGeneration++;
    s.renderStop->store(true);
    std::vector<std::uint32_t> keep;
    for (const std::uint32_t id : s.selected) if (s.edit.find(id)) keep.push_back(id);
    s.selected = keep;
    [self toneUpdateOrigin];
    [_toneView selectionChanged];
    [self toneRefreshInspector];
}

- (BOOL)toneAbsorbUndo {
    if (!_tone || _tone->phase != SVToneSession::Phase::Ready || !(_tone->dirty || _tone->rendering) || !_core) return NO;
    SVToneSession& s = *_tone;
    s.editGeneration++;
    s.renderStop->store(true);
    s.dirty = false;
    ToneEdit saved;
    s.edit = ToneProject::savedEdit(_core->project(), s.track, s.clipId, saved) ? saved : s.analysis->initial;
    std::vector<std::uint32_t> keep;
    for (const std::uint32_t id : s.selected) if (s.edit.find(id)) keep.push_back(id);
    s.selected = keep;
    [_toneView selectionChanged];
    [self toneRefreshInspector];
    [self setStatus:@"The last tone change was not rendered yet — it was dropped. Press Undo again to go back further."];
    return YES;
}

// ================================================================ rendering ==
- (void)toneEdited:(NSString*)label {
    if (!_tone || _tone->phase != SVToneSession::Phase::Ready) return;
    SVToneSession& s = *_tone;
    s.editGeneration++;
    s.dirty = true;
    s.pendingLabel = sv::str(label);
    if (s.rendering) s.renderStop->store(true);   // the work in progress is out of date
    [self toneScheduleRender];
    [self toneRefreshInspector];
    [_toneView setNeedsDisplay:YES];
}

- (void)toneDragBegan { if (_tone) _tone->dragging = true; }
- (void)toneDragEnded {
    if (!_tone) return;
    _tone->dragging = false;
    if (_tone->dirty) [self toneScheduleRender];
}

- (void)toneScheduleRender {
    std::shared_ptr<SVToneSession> s = _tone;
    if (!s) return;
    const std::uint64_t token = ++s->timerGeneration;
    SilvetonController* me = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 280 * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
        if (s->timerGeneration != token) return;
        [me toneStartRender:s];
    });
}

- (void)toneStartRender:(std::shared_ptr<SVToneSession>)s {
    if (!s->dirty || s->rendering || s->dragging || s->phase != SVToneSession::Phase::Ready || !_core || !s->audio || !s->analysis) return;
    std::string dir;
    try { dir = sv::processedMediaDirectory(); } catch (const std::exception& e) { s->dirty = false; [self showError:@"Tone Editor" detail:e.what()]; return; }
    s->rendering = true;
    s->renderStop->store(false);
    [self toneRefreshInspector];
    const std::uint64_t generation = s->editGeneration;
    const ToneEdit edit = s->edit;
    const std::string label = s->pendingLabel;
    const auto audio = s->audio;
    const auto analysis = s->analysis;
    const double rate = s->rate;
    const std::string original = s->source.path;
    SilvetonController* me = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        std::string path, error;
        std::uint64_t frames = 0U;
        std::uint32_t channels = 1U;
        bool cancelled = false;
        try {
            const AudioBuffer out = ToneRenderer::render(*audio, *analysis, edit, ToneRenderOptions {}, s->renderStop.get());
            if (s->renderStop->load()) {
                cancelled = true;
            } else {
                frames = out.frames();
                channels = static_cast<std::uint32_t>(out.channels());
                path = ToneProject::writeRendered(out, rate, original, dir);
            }
        } catch (const std::exception& e) {
            error = e.what();
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            s->rendering = false;
            const bool stale = cancelled || generation != s->editGeneration;
            if (stale || !error.empty()) {
                if (!path.empty()) std::remove(path.c_str());
                if (!error.empty() && !stale) { s->dirty = false; [me showError:@"Tone Editor" detail:error]; }
                else if (s->dirty) [me toneStartRender:s];      // a newer change is waiting
                if (me->_tone == s) [me toneRefreshInspector];
                return;
            }
            NSString* undoLabel = [@"Tone Editor — " stringByAppendingString:sv::ns(label)];
            [me runEdit:undoLabel rebuild:YES block:^{
                ToneProject::commit(me->_core->project(), s->track, s->clipId, s->source, edit, path, frames, channels);
                s->renderedPath = path;
            }];
            if (s->renderedPath == path) {
                s->dirty = false;
                me->_core->waveformCache().request(path);
            } else {
                std::remove(path.c_str());
            }
            if (me->_tone == s) { [me toneRefreshInspector]; [me->_toneView setNeedsDisplay:YES]; }
        });
    });
}

// ================================================================ selection ==
- (void)toneSetSelection:(const std::vector<std::uint32_t>&)ids {
    if (!_tone) return;
    _tone->selected = ids;
    [_toneView selectionChanged];
    [self toneRefreshInspector];
}
- (void)toneSelectionChanged { [self toneRefreshInspector]; }

- (std::vector<std::uint32_t>)toneTargetIds {
    std::vector<std::uint32_t> ids;
    if (!_tone) return ids;
    for (const std::uint32_t id : _tone->selected) if (_tone->edit.find(id)) ids.push_back(id);
    if (ids.empty()) for (const auto& b : _tone->edit.blocks) ids.push_back(b.id);
    return ids;
}

// ================================================================ inspector ==
- (NSString*)toneStatusText {
    if (!_tone) return @"Open an audio clip to edit its tones";
    switch (_tone->phase) {
        case SVToneSession::Phase::Loading:
            return [NSString stringWithFormat:@"Listening to the voice … %.0f %%", 100.0 * static_cast<double>(_tone->progress->load())];
        case SVToneSession::Phase::Failed: return sv::ns(_tone->message);
        case SVToneSession::Phase::Ready: break;
    }
    if (_tone->rendering) return @"Rendering the changed sound …";
    if (_tone->dirty) return @"Changed — rendering in a moment";
    if (_tone->edit.blocks.empty()) return sv::ns(_tone->message);
    return [NSString stringWithFormat:@"%lu tone segment%s · the clip plays the result", (unsigned long)_tone->edit.blocks.size(), _tone->edit.blocks.size() == 1U ? "" : "s"];
}

- (void)toneRefreshInspector {
    if (!_toneStatus) return;
    _toneStatus.stringValue = [self toneStatusText];
    const BOOL ready = _tone && _tone->phase == SVToneSession::Phase::Ready;
    double value[SVToneParamCount];
    for (int i = 0; i < SVToneParamCount; ++i) value[i] = kParams[i].reset;
    NSString* info = @"";
    if (ready) {
        const ToneEdit& edit = _tone->edit;
        const ToneBlock* first = nullptr;
        for (const std::uint32_t id : _tone->selected) { first = edit.find(id); if (first) break; }
        if (!first && !edit.blocks.empty() && _tone->selected.empty()) first = &edit.blocks.front();
        if (first) {
            value[SVToneParamSnap] = 100.0 * first->snap;
            value[SVToneParamFlatten] = 100.0 * first->flatten;
            value[SVToneParamVibrato] = 100.0 * first->vibrato;
            value[SVToneParamTilt] = first->tiltCents;
            value[SVToneParamMove] = first->moveCents;
            value[SVToneParamFormant] = first->formantCents;
            value[SVToneParamGain] = first->gainDb;
        }
        value[SVToneParamTransition] = edit.transitionMs;
        const ToneAnalysisOptions& o = _tone->source.options;
        value[SVToneParamSensitivity] = 100.0 * o.sensitivity;
        value[SVToneParamSplitSensitivity] = 100.0 * o.splitSensitivity;
        value[SVToneParamLowest] = o.lowestHz;
        value[SVToneParamHighest] = o.highestHz;
        value[SVToneParamMinBlock] = o.minBlockMs;
        [_toneScalePop selectItemAtIndex:static_cast<NSInteger>(edit.scale.kind)];
        [_toneRootPop selectItemAtIndex:std::clamp(edit.scale.root, 0, 11)];
        _toneScaleOn.state = edit.snapToScale ? NSControlStateValueOn : NSControlStateValueOff;
        // what the selection is
        if (_tone->selected.size() == 1U) {
            if (const ToneBlock* b = edit.find(_tone->selected.front())) {
                const double target = toneBlockTargetPitch(*b, edit);
                const double seconds = static_cast<double>(b->end - b->start) / std::max(1.0, _tone->rate);
                info = [NSString stringWithFormat:@"%@ → %@   %.2f s   %.0f dB", noteName(b->pitch), noteName(target), seconds, static_cast<double>(b->levelDb)];
            }
        } else if (_tone->selected.size() > 1U) {
            info = [NSString stringWithFormat:@"%lu segments selected", (unsigned long)_tone->selected.size()];
        } else if (!edit.blocks.empty()) {
            info = @"No segment selected — the sliders change all segments";
        }
    }
    _toneBlockInfo.stringValue = info;
    for (int i = 0; i < SVToneParamCount; ++i) {
        if (!_toneSliders[i]) continue;
        _toneSliders[i].doubleValue = value[i];
        _toneValues[i].stringValue = paramText(i, value[i]);
        _toneSliders[i].enabled = ready || i >= SVToneParamSensitivity;
    }
}

- (void)toneSliderMoved:(NSSlider*)sender {
    const int param = static_cast<int>(sender.tag);
    if (param < 0 || param >= SVToneParamCount) return;
    const double v = sender.doubleValue;
    _toneValues[param].stringValue = paramText(param, v);
    if (param >= SVToneParamSensitivity) {      // analysis settings: stored, used by "Listen Again"
        if (!_tone) return;
        ToneAnalysisOptions& o = _tone->source.options;
        if (param == SVToneParamSensitivity) o.sensitivity = v / 100.0;
        else if (param == SVToneParamSplitSensitivity) o.splitSensitivity = v / 100.0;
        else if (param == SVToneParamLowest) o.lowestHz = std::min(v, o.highestHz - 50.0);
        else if (param == SVToneParamHighest) o.highestHz = std::max(v, o.lowestHz + 50.0);
        else if (param == SVToneParamMinBlock) o.minBlockMs = v;
        return;
    }
    if (![self toneCanEdit]) { [self toneRefreshInspector]; return; }
    ToneEdit& edit = _tone->edit;
    const std::vector<std::uint32_t> ids = [self toneTargetIds];
    NSString* label = @"Change";
    switch (param) {
        case SVToneParamSnap: ToneEditing::setSnap(edit, ids, static_cast<float>(v / 100.0)); label = @"Correct Pitch"; break;
        case SVToneParamFlatten: ToneEditing::setFlatten(edit, ids, static_cast<float>(v / 100.0)); label = @"Straighten Curve"; break;
        case SVToneParamVibrato: ToneEditing::setVibrato(edit, ids, static_cast<float>(v / 100.0)); label = @"Vibrato"; break;
        case SVToneParamTransition: edit.transitionMs = static_cast<float>(v); label = @"Glide"; break;
        default:
            for (const std::uint32_t id : ids) {
                ToneBlock* b = edit.find(id);
                if (!b) continue;
                if (param == SVToneParamTilt) b->tiltCents = static_cast<float>(v);
                else if (param == SVToneParamMove) b->moveCents = static_cast<float>(v);
                else if (param == SVToneParamFormant) b->formantCents = static_cast<float>(v);
                else if (param == SVToneParamGain) b->gainDb = static_cast<float>(v);
            }
            label = param == SVToneParamTilt ? @"Tilt" : (param == SVToneParamMove ? @"Move Pitch" : (param == SVToneParamFormant ? @"Shift Formant" : @"Volume"));
            break;
    }
    [self toneEdited:label];
}

// ================================================================== actions ==
- (void)toneApply:(NSString*)label change:(void (^)(ToneEdit& edit, const std::vector<std::uint32_t>& ids))change {
    if (![self toneCanEdit]) return;
    const std::vector<std::uint32_t> ids = [self toneTargetIds];
    change(_tone->edit, ids);
    [self toneEdited:label];
}

- (void)toneSnapFull:(id)sender { (void)sender; [self toneApply:@"Correct Pitch" change:^(ToneEdit& e, const std::vector<std::uint32_t>& ids) { ToneEditing::setSnap(e, ids, 1.0F); }]; }
- (void)toneSnapNone:(id)sender { (void)sender; [self toneApply:@"Correct Pitch" change:^(ToneEdit& e, const std::vector<std::uint32_t>& ids) { ToneEditing::setSnap(e, ids, 0.0F); }]; }
- (void)toneFlattenFull:(id)sender { (void)sender; [self toneApply:@"Straighten Curve" change:^(ToneEdit& e, const std::vector<std::uint32_t>& ids) { ToneEditing::setFlatten(e, ids, 1.0F); }]; }
- (void)toneFlattenNone:(id)sender { (void)sender; [self toneApply:@"Straighten Curve" change:^(ToneEdit& e, const std::vector<std::uint32_t>& ids) { ToneEditing::setFlatten(e, ids, 0.0F); }]; }
- (void)toneUp:(id)sender { (void)sender; [self toneApply:@"Transpose" change:^(ToneEdit& e, const std::vector<std::uint32_t>& ids) { ToneEditing::transpose(e, ids, 1.0); }]; }
- (void)toneDown:(id)sender { (void)sender; [self toneApply:@"Transpose" change:^(ToneEdit& e, const std::vector<std::uint32_t>& ids) { ToneEditing::transpose(e, ids, -1.0); }]; }
- (void)toneOctaveUp:(id)sender { (void)sender; [self toneApply:@"Transpose" change:^(ToneEdit& e, const std::vector<std::uint32_t>& ids) { ToneEditing::transpose(e, ids, 12.0); }]; }
- (void)toneOctaveDown:(id)sender { (void)sender; [self toneApply:@"Transpose" change:^(ToneEdit& e, const std::vector<std::uint32_t>& ids) { ToneEditing::transpose(e, ids, -12.0); }]; }

- (void)toneSelectAll:(id)sender {
    (void)sender;
    if (!_tone || _tone->phase != SVToneSession::Phase::Ready) return;
    std::vector<std::uint32_t> ids;
    for (const auto& b : _tone->edit.blocks) ids.push_back(b.id);
    [self toneSetSelection:ids];
}

- (void)toneResetSelected:(id)sender {
    (void)sender;
    if (![self toneCanEdit]) return;
    if (_tone->selected.empty()) { [self setStatus:@"Select the segments to reset first (or use Reset All)"]; return; }
    for (const std::uint32_t id : _tone->selected) ToneEditing::resetBlock(_tone->edit, id);
    [self toneEdited:@"Reset Segments"];
}

- (void)toneResetAll:(id)sender {
    (void)sender;
    if (![self toneCanEdit]) return;
    ToneEditing::resetAll(_tone->edit, *_tone->analysis);
    _tone->selected.clear();
    [_toneView selectionChanged];
    [self toneEdited:@"Reset All"];
}

- (void)toneDeleteSelected:(id)sender {
    (void)sender;
    if (![self toneCanEdit] || _tone->selected.empty()) return;
    for (const std::uint32_t id : _tone->selected) (void)ToneEditing::remove(_tone->edit, id);
    _tone->selected.clear();
    [_toneView selectionChanged];
    [self toneEdited:@"Remove Segments"];
}

- (void)toneBypassSelected:(id)sender {
    (void)sender;
    if (![self toneCanEdit] || _tone->selected.empty()) { [self setStatus:@"Select a segment first"]; return; }
    bool anyOn = false;
    for (const std::uint32_t id : _tone->selected) if (const ToneBlock* b = _tone->edit.find(id)) anyOn = anyOn || !b->bypass;
    for (const std::uint32_t id : _tone->selected) if (ToneBlock* b = _tone->edit.find(id)) b->bypass = anyOn;
    [self toneEdited:anyOn ? @"Bypass Segments" : @"Use Segments"];
}

- (void)toneSplitAtPlayhead:(id)sender {
    (void)sender;
    if (![self toneCanEdit]) return;
    const std::int64_t at = [self playheadSample] - _tone->origin;
    // Positions in the sound are the original ones; the playhead is on the result, so undo the time bend.
    const ToneTimeMap map(_tone->edit.warp, _tone->analysis->length);
    const auto source = static_cast<std::int64_t>(std::llround(map.inverse(static_cast<double>(at))));
    for (const auto& b : _tone->edit.blocks) {
        if (source > b.start && source < b.end) {
            const std::uint32_t id = ToneEditing::split(_tone->edit, *_tone->analysis, b.id, source);
            if (id) { [self toneEdited:@"Cut Segment"]; return; }
            break;
        }
    }
    [self setStatus:@"Put the playhead inside a segment to cut it there"];
}

- (void)toneGlueSelected:(id)sender {
    (void)sender;
    if (![self toneCanEdit]) return;
    std::vector<std::uint32_t> ids = _tone->selected;
    std::sort(ids.begin(), ids.end(), [&](std::uint32_t a, std::uint32_t b) {
        const ToneBlock* x = _tone->edit.find(a); const ToneBlock* y = _tone->edit.find(b);
        return x && y && x->start < y->start;
    });
    bool any = false;
    if (ids.size() == 1U) {
        const auto& blocks = _tone->edit.blocks;
        for (std::size_t i = 0U; i + 1U < blocks.size(); ++i)
            if (blocks[i].id == ids.front()) { any = ToneEditing::glue(_tone->edit, *_tone->analysis, blocks[i].id, blocks[i + 1U].id) != 0U; break; }
    } else {
        for (std::size_t i = 1U; i < ids.size(); ++i) any = ToneEditing::glue(_tone->edit, *_tone->analysis, ids[i - 1U], ids[i]) != 0U || any;
    }
    if (!any) { [self setStatus:@"Select two neighbouring segments (or one segment to join with the next)"]; return; }
    _tone->selected.clear();
    [_toneView selectionChanged];
    [self toneEdited:@"Glue Segments"];
}

- (void)toneLoopSelected:(id)sender {
    (void)sender;
    if (!_tone || _tone->phase != SVToneSession::Phase::Ready) return;
    std::int64_t a = 0, b = 0;
    bool any = false;
    const ToneTimeMap map(_tone->edit.warp, _tone->analysis->length);
    for (const std::uint32_t id : _tone->selected) {
        const ToneBlock* blk = _tone->edit.find(id);
        if (!blk) continue;
        const auto s = static_cast<std::int64_t>(std::llround(map.forward(static_cast<double>(blk->start))));
        const auto e = static_cast<std::int64_t>(std::llround(map.forward(static_cast<double>(blk->end))));
        a = any ? std::min(a, s) : s;
        b = any ? std::max(b, e) : e;
        any = true;
    }
    if (!any) { [self setStatus:@"Select the segments to loop first"]; return; }
    [self setCycleStart:_tone->origin + a end:_tone->origin + b];
    [self setStatus:@"Cycle set to the selected segments — press Play to hear them over and over"];
}

- (void)toneQuantizeTiming:(id)sender {
    (void)sender;
    if (![self toneCanEdit]) return;
    SVToneSession& s = *_tone;
    const Project& p = _core->project();
    const double amount = std::clamp(_toneSliders[SVToneParamTimingAmount].doubleValue / 100.0, 0.0, 1.0);
    const double div = static_cast<double>(std::max<std::uint32_t>(1U, _gridDiv));
    const std::int64_t total = s.analysis->length;
    const auto minLen = static_cast<std::int64_t>(0.03 * s.rate);
    std::vector<std::uint32_t> ids = [self toneTargetIds];
    std::sort(ids.begin(), ids.end(), [&](std::uint32_t a, std::uint32_t b) {
        const ToneBlock* x = s.edit.find(a); const ToneBlock* y = s.edit.find(b);
        return x && y && x->start < y->start;
    });
    for (const std::uint32_t id : ids) {
        const ToneBlock* b = s.edit.find(id);
        if (!b) continue;
        const ToneTimeMap map(s.edit.warp, total);   // the bend changes with every block that moves
        const double start = map.forward(static_cast<double>(b->start));
        const double end = map.forward(static_cast<double>(b->end));
        const std::int64_t timeline = s.origin + static_cast<std::int64_t>(std::llround(start));
        const double quarter = p.tempoMap.quarterNotesAtSample(timeline);
        const double snappedQuarter = std::round(quarter * div) / div;
        const double wanted = static_cast<double>(p.tempoMap.sampleAtQuarterNotes(snappedQuarter) - s.origin);
        const double newStart = start + amount * (wanted - start);
        (void)ToneEditing::setBlockTime(s.edit, id, static_cast<std::int64_t>(std::llround(newStart)),
                                        static_cast<std::int64_t>(std::llround(newStart + (end - start))), total, minLen);
    }
    [self toneEdited:@"Snap Timing"];
}

- (void)toneClearTiming:(id)sender {
    (void)sender;
    if (![self toneCanEdit]) return;
    ToneEditing::clearTiming(_tone->edit);
    [self toneEdited:@"Clear Timing"];
}

- (void)toneScalePicked:(NSPopUpButton*)sender {
    if (![self toneCanEdit]) { [self toneRefreshInspector]; return; }
    _tone->edit.scale.kind = static_cast<ToneScaleKind>(std::clamp<NSInteger>(sender.indexOfSelectedItem, 0, static_cast<NSInteger>(ToneScaleKind::Count) - 1));
    [self toneEdited:@"Scale"];
}
- (void)toneRootPicked:(NSPopUpButton*)sender {
    if (![self toneCanEdit]) { [self toneRefreshInspector]; return; }
    _tone->edit.scale.root = static_cast<int>(std::clamp<NSInteger>(sender.indexOfSelectedItem, 0, 11));
    [self toneEdited:@"Scale"];
}
- (void)toneScaleToggled:(SVToggle*)sender {
    if (![self toneCanEdit]) { [self toneRefreshInspector]; return; }
    _tone->edit.snapToScale = sender.state == NSControlStateValueOn;
    [self toneEdited:@"Snap Pitch Editing"];
}
- (void)toneDetectScale:(id)sender {
    (void)sender;
    if (![self toneCanEdit]) return;
    double coverage = 0.0;
    const ToneScale scale = ToneEditing::detectScale(_tone->edit, &coverage);
    _tone->edit.scale = scale;
    _tone->edit.snapToScale = true;
    [self toneEdited:@"Scale Suggestions"];
    [self setStatus:[NSString stringWithFormat:@"The singing fits %@ (%.0f %% of the sound) — Correct Pitch now pulls to this scale", sv::ns(scale.name()), coverage]];
}

- (void)toneReanalyse:(id)sender {
    (void)sender;
    if (!_tone || !_core) return;
    if (_tone->phase == SVToneSession::Phase::Loading) return;
    const ToneAnalysisOptions options = _tone->source.options;
    const std::size_t track = _tone->track;
    const std::uint64_t clip = _tone->clipId;
    if (track < _core->project().tracks.size() && _core->project().tracks[track].locked) { [self toneCanEdit]; return; }
    [self toneOpenTrack:track clip:clip options:&options];
}

- (void)toneDisplayToggled:(SVToggle*)sender {
    const BOOL on = sender.state == NSControlStateValueOn;
    switch (sender.tag) {
        case 0: _toneView.showOriginalPitch = on; break;
        case 1: _toneView.showCorrectedPitch = on; break;
        case 2: _toneView.showWaveform = on; break;
        case 3: _toneView.showScale = on; break;
        default: break;
    }
    [_toneView setNeedsDisplay:YES];
}

- (void)toneZoomFit:(id)sender { (void)sender; [_toneView zoomFit]; }
- (void)toneZoomSelection:(id)sender { (void)sender; [_toneView zoomToSelection]; }

// ============================================================ context menu ==
- (NSMenu*)toneContextMenu {
    NSMenu* menu = [[NSMenu alloc] initWithTitle:@""];
    auto add = [&](NSString* title, SEL action) {
        NSMenuItem* item = [menu addItemWithTitle:title action:action keyEquivalent:@""];
        item.target = self;
    };
    add(@"Correct Pitch 100 %", @selector(toneSnapFull:));
    add(@"Correct Pitch 0 %", @selector(toneSnapNone:));
    add(@"Straighten 100 %", @selector(toneFlattenFull:));
    add(@"Straighten 0 %", @selector(toneFlattenNone:));
    [menu addItem:[NSMenuItem separatorItem]];
    add(@"Semitone Up", @selector(toneUp:));
    add(@"Semitone Down", @selector(toneDown:));
    add(@"Octave Up", @selector(toneOctaveUp:));
    add(@"Octave Down", @selector(toneOctaveDown:));
    [menu addItem:[NSMenuItem separatorItem]];
    add(@"Cut at Playhead", @selector(toneSplitAtPlayhead:));
    add(@"Glue", @selector(toneGlueSelected:));
    add(@"Bypass / Use", @selector(toneBypassSelected:));
    add(@"Reset", @selector(toneResetSelected:));
    add(@"Remove", @selector(toneDeleteSelected:));
    [menu addItem:[NSMenuItem separatorItem]];
    add(@"Loop the Selected Segments", @selector(toneLoopSelected:));
    add(@"Extract MIDI", @selector(toneExtractMidi:));
    return menu;
}

// ================================================================== MIDI ==
// The tones become notes on a new instrument track: start, length and loudness of every block, and
// (when "Pitch Bend" is on) the small moves of the pitch inside a block as pitch-bend messages.
- (void)toneExtractMidi:(id)sender {
    (void)sender;
    if (!_tone || _tone->phase != SVToneSession::Phase::Ready || !_core) { [self setStatus:@"Open an audio clip in the Tone Editor first"]; return; }
    ToneMidiOptions options;
    options.useBend = _toneBend.state == NSControlStateValueOn;
    options.useTarget = _toneUseCorrected.state == NSControlStateValueOn;
    const std::vector<ToneMidiNote> notes = ToneMidi::extract(*_tone->analysis, _tone->edit, options);
    if (notes.empty()) { [self setStatus:@"There are no tone segments to turn into notes"]; return; }
    if (_core->project().tracks.size() >= Project::kMaxTracks) { [self showError:@"Extract MIDI" detail:"The project has too many tracks."]; return; }
    const std::int64_t origin = _tone->origin;
    const std::string name = (_tone->clipName.empty() ? std::string("Voice") : _tone->clipName) + " Notes";
    __block std::size_t made = 0U;
    [self runEdit:@"Extract MIDI from Tones" rebuild:YES block:^{
        Project& p = self->_core->project();
        MidiSequence absolute;
        for (const ToneMidiNote& n : notes) {
            const double q0 = std::max(0.0, p.tempoMap.quarterNotesAtSample(origin + n.start));
            const double q1 = p.tempoMap.quarterNotesAtSample(origin + n.end);
            MusicalMidiNote note;
            note.startQuarterNotes = q0;
            note.durationQuarterNotes = std::max(0.02, q1 - q0);
            note.pitch = static_cast<std::uint8_t>(std::clamp(n.pitch, 0, 127));
            note.velocity = static_cast<std::uint8_t>(std::clamp(n.velocity, 1, 127));
            (void)absolute.addNote(note);
            for (const auto& bend : n.bend) {
                MusicalMidiMessage m;
                m.quarterNotes = std::max(0.0, p.tempoMap.quarterNotesAtSample(origin + bend.first));
                m.status = 0xE0U;
                m.data1 = static_cast<std::uint8_t>(bend.second & 0x7F);
                m.data2 = static_cast<std::uint8_t>((bend.second >> 7) & 0x7F);
                (void)absolute.addMessage(m);
            }
            if (!n.bend.empty()) {   // the wheel goes back to the middle when the note is over
                MusicalMidiMessage m;
                m.quarterNotes = q0 + note.durationQuarterNotes;
                m.status = 0xE0U; m.data1 = 0U; m.data2 = 64U;
                (void)absolute.addMessage(m);
            }
            ++made;
        }
        ProjectTrack inst;
        inst.name = name;
        ProjectPluginSlot synth;
        synth.modulePath = kNativeModulePath;
        synth.classId = "silveton.poly";
        synth.midiInputPort = nextFreeMidiPort(p);
        inst.pluginSlots.push_back(synth);
        const int port = synth.midiInputPort;
        p.addTrack(std::move(inst));
        ProjectMidiTrack mt;
        mt.name = name;
        mt.outputPort = port;
        const auto numerator = static_cast<double>(p.tempoMap.numeratorAtSample(origin));
        const auto denominator = static_cast<double>(p.tempoMap.denominatorAtSample(origin));
        (void)MidiTrackTools::addPartFromAbsolute(mt, absolute, std::max(1.0, numerator * 4.0 / std::max(1.0, denominator)));
        p.midiTracks.push_back(std::move(mt));
    }];
    [self setStatus:[NSString stringWithFormat:@"%lu note%s extracted to the new track “%@” — the Poly Synth plays them", (unsigned long)made, made == 1U ? "" : "s", sv::ns(name)]];
}

// ============================================================== inspector UI ==
- (void)buildToneToolsIn:(SVFlipView*)view width:(CGFloat)W {
    CGFloat y = 0.0;
    toneSection(view, @"TONE EDITOR · TOOLS", y, W);
    y += 28.0;
    static NSString* const toolNames[6] = {@"Select", @"Time Bend", @"Cut", @"Glue", @"Erase", @"Draw"};
    const CGFloat colW = (W - 8.0 * 3.0) / 2.0;
    for (int i = 0; i < 6; ++i) {
        const CGFloat x = 8.0 + (i % 2) * (colW + 8.0);
        SVToggle* t = [SVToggle toggleWithTitle:toolNames[i] color:sv::copper() target:self action:@selector(toneToolPicked:)
                                          frame:NSMakeRect(x, y + (i / 2) * 30.0, colW, 24.0)];
        t.tag = i;
        t.state = i == 0 ? NSControlStateValueOn : NSControlStateValueOff;
        [view addSubview:t];
        _toneToolButtons[i] = t;
    }
    y += 3 * 30.0 + 4.0;
    _toneStatus = toneLabel(view, @"", NSMakeRect(8, y, W - 16, 30), sv::ui(11), sv::inkDim());
    _toneStatus.maximumNumberOfLines = 2;
    _toneStatus.lineBreakMode = NSLineBreakByWordWrapping;
    y += 34.0;
    _toneBlockInfo = toneLabel(view, @"", NSMakeRect(8, y, W - 16, 16), sv::mono(11, true), sv::ink());
    y += 26.0;

    auto row = [&](int param) {
        const ParamInfo& info = kParams[param];
        toneLabel(view, sv::ns(info.name), NSMakeRect(8, y + 2, 70, 16), sv::ui(11), sv::inkDim());
        SVResetSlider* sl = [[SVResetSlider alloc] initWithFrame:NSMakeRect(80, y, 108, 20)];
        sl.minValue = info.min; sl.maxValue = info.max; sl.doubleValue = info.reset;
        sl.resetValue = info.reset;
        sl.continuous = YES;
        sl.tag = param;
        sl.target = self; sl.action = @selector(toneSliderMoved:);
        [view addSubview:sl];
        _toneSliders[param] = sl;
        _toneValues[param] = toneLabel(view, paramText(param, info.reset), NSMakeRect(190, y + 2, W - 190 - 8, 16), sv::mono(11, true), sv::ink(), NSTextAlignmentRight);
        y += 26.0;
    };
    auto button = [&](NSString* title, SEL action, int column, int columns, CGFloat rowY) {
        const CGFloat w = (W - 8.0 * (columns + 1)) / columns;
        [view addSubview:[SVButton buttonWithTitle:title target:self action:action frame:NSMakeRect(8 + column * (w + 8), rowY, w, 24)]];
    };

    toneSection(view, @"PITCH · SELECTED SEGMENTS OR ALL", y, W);
    y += 30.0;
    row(SVToneParamSnap); row(SVToneParamFlatten); row(SVToneParamVibrato); row(SVToneParamTilt); row(SVToneParamMove);
    button(@"Correct 100 %", @selector(toneSnapFull:), 0, 2, y);
    button(@"Straighten 100 %", @selector(toneFlattenFull:), 1, 2, y);
    y += 30.0;
    button(@"Up 1", @selector(toneUp:), 0, 4, y); button(@"Down 1", @selector(toneDown:), 1, 4, y);
    button(@"Oct +", @selector(toneOctaveUp:), 2, 4, y); button(@"Oct −", @selector(toneOctaveDown:), 3, 4, y);
    y += 34.0;
    row(SVToneParamTransition);
    y += 4.0;

    toneSection(view, @"SCALE", y, W);
    y += 30.0;
    _toneScalePop = tonePopup(view, NSMakeRect(8, y, 132, 24), self, @selector(toneScalePicked:));
    for (int k = 0; k < static_cast<int>(ToneScaleKind::Count); ++k) [_toneScalePop addItemWithTitle:sv::ns(ToneScale::kindName(static_cast<ToneScaleKind>(k)))];
    _toneRootPop = tonePopup(view, NSMakeRect(148, y, W - 156, 24), self, @selector(toneRootPicked:));
    [_toneRootPop addItemsWithTitles:@[@"C", @"C#", @"D", @"D#", @"E", @"F", @"F#", @"G", @"G#", @"A", @"A#", @"B"]];
    y += 32.0;
    _toneScaleOn = [SVToggle toggleWithTitle:@"Snap Pitch Editing" color:sv::copper() target:self action:@selector(toneScaleToggled:) frame:NSMakeRect(8, y, 112, 24)];
    [view addSubview:_toneScaleOn];
    [view addSubview:[SVButton buttonWithTitle:@"Scale Suggestions" target:self action:@selector(toneDetectScale:) frame:NSMakeRect(128, y, W - 136, 24)]];
    y += 34.0;

    toneSection(view, @"FORMANT AND VOLUME", y, W);
    y += 30.0;
    row(SVToneParamFormant); row(SVToneParamGain);
    y += 4.0;

    toneSection(view, @"TIME", y, W);
    y += 30.0;
    row(SVToneParamTimingAmount);
    button(@"Snap Timing", @selector(toneQuantizeTiming:), 0, 2, y);
    button(@"Clear Timing", @selector(toneClearTiming:), 1, 2, y);
    y += 30.0;
    toneLabel(view, @"Snap Timing pulls the segments to the grid of the Edit page (Grid 1/4 … 1/32).", NSMakeRect(8, y, W - 16, 28), sv::ui(10), sv::inkFaint()).lineBreakMode = NSLineBreakByWordWrapping;
    y += 36.0;

    toneSection(view, @"SEGMENTS", y, W);
    y += 30.0;
    button(@"Select All", @selector(toneSelectAll:), 0, 2, y); button(@"Reset", @selector(toneResetSelected:), 1, 2, y);
    y += 30.0;
    button(@"Reset All", @selector(toneResetAll:), 0, 2, y); button(@"Bypass", @selector(toneBypassSelected:), 1, 2, y);
    y += 30.0;
    button(@"Cut at Playhead", @selector(toneSplitAtPlayhead:), 0, 2, y); button(@"Glue", @selector(toneGlueSelected:), 1, 2, y);
    y += 30.0;
    button(@"Remove", @selector(toneDeleteSelected:), 0, 2, y); button(@"Loop Segments", @selector(toneLoopSelected:), 1, 2, y);
    y += 36.0;

    toneSection(view, @"MIDI", y, W);
    y += 30.0;
    _toneUseCorrected = [SVToggle toggleWithTitle:@"Corrected Pitch" color:sv::copper() target:nil action:nil frame:NSMakeRect(8, y, 112, 24)];
    _toneUseCorrected.state = NSControlStateValueOn;
    [view addSubview:_toneUseCorrected];
    _toneBend = [SVToggle toggleWithTitle:@"Pitch Bend" color:sv::copper() target:nil action:nil frame:NSMakeRect(128, y, W - 136, 24)];
    [view addSubview:_toneBend];
    y += 30.0;
    SVButton* extract = [SVButton buttonWithTitle:@"Extract MIDI to a New Track" target:self action:@selector(toneExtractMidi:) frame:NSMakeRect(8, y, W - 16, 26)];
    extract.accent = YES;
    [view addSubview:extract];
    y += 40.0;

    toneSection(view, @"ANALYSIS · HOW THE SEGMENTS ARE FOUND", y, W);
    y += 30.0;
    row(SVToneParamSensitivity); row(SVToneParamSplitSensitivity); row(SVToneParamLowest); row(SVToneParamHighest); row(SVToneParamMinBlock);
    button(@"Analyze Again", @selector(toneReanalyse:), 0, 1, y);
    y += 30.0;
    toneLabel(view, @"Analyze Again finds the segments anew and drops your segment changes.", NSMakeRect(8, y, W - 16, 28), sv::ui(10), sv::inkFaint()).lineBreakMode = NSLineBreakByWordWrapping;
    y += 36.0;

    toneSection(view, @"VIEW", y, W);
    y += 30.0;
    const char* titles[4] = {"Sung Pitch", "New Pitch", "Waveform", "Scale Rows"};
    for (int i = 0; i < 4; ++i) {
        SVToggle* t = [SVToggle toggleWithTitle:sv::ns(titles[i]) color:sv::copper() target:self action:@selector(toneDisplayToggled:)
                                          frame:NSMakeRect(8.0 + (i % 2) * (colW + 8.0), y + (i / 2) * 30.0, colW, 24.0)];
        t.tag = i;
        t.state = NSControlStateValueOn;
        [view addSubview:t];
        if (i == 0) _toneShowOriginal = t; else if (i == 1) _toneShowCorrected = t; else if (i == 2) _toneShowWave = t; else _toneShowScale = t;
    }
    y += 64.0;
    button(@"Zoom Fit", @selector(toneZoomFit:), 0, 2, y); button(@"Zoom Segments", @selector(toneZoomSelection:), 1, 2, y);
    y += 36.0;
    NSRect f = view.frame;
    f.size.height = y;
    view.frame = f;
}

@end
