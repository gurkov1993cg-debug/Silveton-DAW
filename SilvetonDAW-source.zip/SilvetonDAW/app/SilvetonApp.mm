// Silveton — application controller: lifecycle, window layout, pages,
// selection, transport and the UI timer. Actions and panels live in the
// SilvetonActions.mm / SilvetonPanels.mm categories.
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <string>

using namespace silveton;

@implementation SilvetonController

@synthesize selectedTrack = _selectedTrack;
@synthesize selectedMidiTrack = _selectedMidiTrack;
@synthesize selectedFolder = _selectedFolder;
@synthesize selectedClipId = _selectedClipId;
@synthesize selectedPartId = _selectedPartId;
@synthesize selectedSectionId = _selectedSectionId;

// ------------------------------------------------------------ lifecycle --
- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    try {
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
        _selectedTrack = -1; _selectedMidiTrack = -1; _selectedFolder = -1;
        _insertRow = -1; _sendRow = -1; _midiRecordTrack = -1;
        _pps = 90.0; _snap = YES; _gridDiv = 4U; _page = SVPage::Arrange; _channelPanelVisible = YES;
        _strip = {SVStripKind::Master, 0};
        _supportDir = sv::appSupportDirectory();
        _presetDir = _supportDir + "/Presets";
        [[NSFileManager defaultManager] createDirectoryAtPath:sv::ns(_presetDir) withIntermediateDirectories:YES attributes:nil error:nil];
        _core = std::make_unique<sv::AppRuntime>();
        _core->startDefault();
        NSString* scanner = [[NSBundle mainBundle] pathForResource:@"silveton_vst3_scanner" ofType:nil];
        if (!scanner) scanner = @"silveton_vst3_scanner";
        _browser = std::make_unique<Vst3PluginBrowserService>(sv::str(scanner), _supportDir + "/vst3-cache.txt", _supportDir + "/vst3-quarantine.txt", 7000U);
        try { _browser->load(); } catch (const std::exception&) {}
        try { _presets.loadIndex(_supportDir + "/preset-index.txt"); } catch (const std::exception&) {}
        try { _presets.scanDirectory(_presetDir, true); } catch (const std::exception&) {}
        [self buildMenus];
        [self buildWindow];
        [self reloadPluginResults];
        [self refreshAll];
        _timer = [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(timerTick:) userInfo:nil repeats:YES];
        [_window makeKeyAndOrderFront:nil];
        [NSApp activateIgnoringOtherApps:YES];
    } catch (const std::exception& e) {
        [self showError:@"Silveton failed to start" detail:e.what()];
        [NSApp terminate:nil];
    }
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender { (void)sender; return YES; }

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication*)sender {
    (void)sender;
    if (!_core || !_core->session().dirty()) return NSTerminateNow;
    NSAlert* a = [[NSAlert alloc] init];
    a.messageText = @"Save changes before quitting?";
    [a addButtonWithTitle:@"Save"];
    [a addButtonWithTitle:@"Don't Save"];
    [a addButtonWithTitle:@"Cancel"];
    const NSModalResponse r = [a runModal];
    if (r == NSAlertThirdButtonReturn) return NSTerminateCancel;
    if (r == NSAlertFirstButtonReturn) {
        [self saveProject:nil];
        if (_core->session().dirty()) return NSTerminateCancel;
    }
    return NSTerminateNow;
}

- (void)applicationWillTerminate:(NSNotification*)notification {
    (void)notification;
    [_timer invalidate];
    _timer = nil;
    [SilvetonNativeEditor closeAll];
    try {
        if (_browser) _browser->save();
        _presets.saveIndex(_supportDir + "/preset-index.txt");
        if (_core) { if (_core->recording()) _core->stopRecording(true); _core->shutdown(); }
    } catch (...) {}
}

// ------------------------------------------------------------- accessors --
- (sv::AppRuntime*)core { return _core.get(); }
- (Project*)project { return _core ? &_core->project() : nullptr; }
- (double)pixelsPerSecond { return _pps; }
- (void)setPixelsPerSecond:(double)pps { _pps = std::clamp(pps, 2.0, 2000.0); [_arrange setNeedsDisplay:YES]; }
- (std::int64_t)playheadSample { return _core && _core->ready() ? _core->engine().transport().positionSamples() : 0; }
- (BOOL)snapEnabled { return _snap; }
- (std::uint32_t)gridDivisionsPerQuarter { return _gridDiv; }
- (std::int64_t)snapSample:(std::int64_t)sample {
    if (!_snap || !_core) return std::max<std::int64_t>(0, sample);
    return std::max<std::int64_t>(0, _core->project().tempoMap.snapSampleToQuarterGrid(sample, _gridDiv));
}
- (SVPage)currentPage { return _page; }
- (SVStrip)selectedStrip { return _strip; }

- (void)showError:(NSString*)title detail:(const std::string&)detail {
    NSAlert* a = [[NSAlert alloc] init];
    a.alertStyle = NSAlertStyleCritical;
    a.messageText = title ?: @"Silveton";
    a.informativeText = sv::ns(detail);
    [a addButtonWithTitle:@"OK"];
    [a runModal];
}

- (NSString*)promptText:(NSString*)title message:(NSString*)message initial:(NSString*)initial {
    NSAlert* a = [[NSAlert alloc] init];
    a.messageText = title;
    a.informativeText = message ?: @"";
    [a addButtonWithTitle:@"OK"];
    [a addButtonWithTitle:@"Cancel"];
    NSTextField* f = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 0, 300, 24)];
    f.stringValue = initial ?: @"";
    a.accessoryView = f;
    [a.window setInitialFirstResponder:f];
    if ([a runModal] != NSAlertFirstButtonReturn) return nil;
    return [f.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (void)setStatus:(NSString*)text { _pageBar.statusText = text; [_pageBar setNeedsDisplay:YES]; }
- (void)requestRebuild { if (_core && _core->ready()) _core->runtime().requestProjectRebuild(); }

// Runs `block` inside one undoable edit. Exceptions roll the edit back.
- (void)runEdit:(NSString*)label rebuild:(BOOL)rebuild block:(void (^)(void))block {
    if (!_core) return;
    auto& session = _core->session();
    const bool own = !session.history().transactionOpen();
    try {
        if (own) session.beginEdit(sv::str(label));
        block();
        if (own) session.commitEdit(); else session.markDirty();
        if (rebuild) { if (_gestureOpen) _gestureNeedsRebuild = YES; else [self requestRebuild]; }
    } catch (const std::exception& e) {
        if (own && session.history().transactionOpen()) session.cancelEdit();
        [self showError:label detail:e.what()];
    }
    [self refreshAll];
}

- (void)beginGesture:(NSString*)label {
    if (!_core || _gestureOpen) return;
    if (!_core->session().history().transactionOpen()) _core->session().beginEdit(sv::str(label));
    _gestureOpen = YES;
    _gestureNeedsRebuild = NO;
}
- (void)endGesture {
    if (!_core || !_gestureOpen) return;
    _gestureOpen = NO;
    if (_core->session().history().transactionOpen()) _core->session().commitEdit();
    if (_gestureNeedsRebuild) [self requestRebuild];
    _gestureNeedsRebuild = NO;
    [self refreshAll];
}

// --------------------------------------------------------------- window --
- (void)buildWindow {
    const CGFloat W = 1480, H = 920, headerH = 44, deckH = 78;
    _window = [[NSWindow alloc] initWithContentRect:NSMakeRect(60, 60, W, H)
                                          styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskResizable
                                            backing:NSBackingStoreBuffered defer:NO];
    _window.title = @"Silveton";
    _window.minSize = NSMakeSize(1280, 720);
    _window.backgroundColor = sv::canvas();
    _window.delegate = self;
    if (@available(macOS 10.14, *)) _window.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
    else _window.appearance = [NSAppearance appearanceNamed:@"NSAppearanceNameVibrantDark"];   // macOS 10.13
    _root = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, W, H)];
    _root.autoresizesSubviews = YES;
    _window.contentView = _root;

    _pageBar = [[SilvetonPageBar alloc] initWithFrame:NSMakeRect(0, H - headerH, W, headerH)];
    _pageBar.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    _pageBar.controller = self;
    [_root addSubview:_pageBar];

    _transport = [[SilvetonTransportDeck alloc] initWithFrame:NSMakeRect(0, 0, W, deckH)];
    _transport.autoresizingMask = NSViewWidthSizable | NSViewMaxYMargin;
    _transport.controller = self;
    [_root addSubview:_transport];

    const NSRect content = NSMakeRect(0, deckH, W, H - headerH - deckH);
    _arrangePage = [self makePage:content];
    _mixPage = [self makePage:content];
    _editPage = [self makePage:content];
    _libraryPage = [self makePage:content];

    // Arrange: Inspector on the left, canvas to its right
    const CGFloat panelW = kInspectorPanelW;
    _arrange = [[SilvetonArrangeView alloc] initWithFrame:NSMakeRect(panelW, 0, content.size.width - panelW, content.size.height)];
    _arrange.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _arrange.controller = self;
    [_arrangePage addSubview:_arrange];
    [self buildChannelPanelIn:NSMakeRect(0, 0, panelW, content.size.height)];

    // Mix
    _console = [[SilvetonConsoleView alloc] initWithFrame:NSMakeRect(0, 0, content.size.width, content.size.height)];
    _console.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _console.controller = self;
    [_mixPage addSubview:_console];

    [self buildEditPage:_editPage];
    [self buildLibraryPage:_libraryPage];
    [self showPage:SVPage::Arrange];
}

- (NSView*)makePage:(NSRect)frame {
    NSView* v = [[NSView alloc] initWithFrame:frame];
    v.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    v.autoresizesSubviews = YES;
    [_root addSubview:v];
    return v;
}

- (void)setChannelPanelVisible:(BOOL)visible {
    _channelPanelVisible = visible;
    const NSRect b = _arrangePage.bounds;
    const CGFloat panelW = visible ? kInspectorPanelW : 0;
    _channelScroll.hidden = !visible;
    _arrange.frame = NSMakeRect(panelW, 0, b.size.width - panelW, b.size.height);
    _channelScroll.frame = NSMakeRect(0, 0, kInspectorPanelW, b.size.height);
}
- (void)toggleChannelPanel:(id)sender { (void)sender; [self setChannelPanelVisible:!_channelPanelVisible]; }

- (void)showPage:(SVPage)page {
    _page = page;
    _arrangePage.hidden = page != SVPage::Arrange;
    _mixPage.hidden = page != SVPage::Mix;
    _editPage.hidden = page != SVPage::Edit;
    _libraryPage.hidden = page != SVPage::Library;
    _pageBar.page = static_cast<int>(page);
    [_pageBar setNeedsDisplay:YES];
    if (page == SVPage::Edit) [self refreshEditPage];
    if (page == SVPage::Library) [self refreshLibrary];
    if (page == SVPage::Arrange) [_window makeFirstResponder:_arrange];
    if (page == SVPage::Edit) [_window makeFirstResponder:_noteGrid];
    if (page == SVPage::Mix) [_console setNeedsDisplay:YES];
}
- (void)showArrangePage:(id)sender { (void)sender; [self showPage:SVPage::Arrange]; }
- (void)showMixPage:(id)sender { (void)sender; [self showPage:SVPage::Mix]; }
- (void)showEditPage:(id)sender { (void)sender; [self showPage:SVPage::Edit]; }
- (void)showLibraryPage:(id)sender { (void)sender; [self showPage:SVPage::Library]; }

- (void)refreshAll {
    if (!_core) return;
    Project& p = _core->project();
    if (_selectedTrack >= static_cast<long>(p.tracks.size())) { _selectedTrack = -1; _selectedClipId = 0; }
    if (_selectedMidiTrack >= static_cast<long>(p.midiTracks.size())) { _selectedMidiTrack = -1; _selectedPartId = 0; }
    if (_selectedFolder >= static_cast<long>(p.folders.size())) _selectedFolder = -1;
    if (_strip.kind == SVStripKind::Track && _strip.index >= p.tracks.size()) _strip = {SVStripKind::Master, 0};
    if (_strip.kind == SVStripKind::Bus && _strip.index >= p.buses.size()) _strip = {SVStripKind::Master, 0};
    [_arrange setNeedsDisplay:YES];
    [_console setNeedsDisplay:YES];
    [_transport setNeedsDisplay:YES];
    [self refreshChannelPanel];
    if (_page == SVPage::Edit) [self refreshEditPage];
    if (_page == SVPage::Library) [self refreshLibrary];
    [self updateTitle];
}

- (void)updateTitle {
    if (!_core) return;
    NSString* name = _core->session().hasProjectPath() ? [[sv::ns(_core->session().projectPath()) lastPathComponent] stringByDeletingPathExtension] : @"Untitled";
    NSString* full = [NSString stringWithFormat:@"%@%@", name, _core->session().dirty() ? @" •" : @""];
    if (![_pageBar.projectTitle isEqualToString:full]) { _pageBar.projectTitle = full; [_pageBar setNeedsDisplay:YES]; }
    _window.title = [NSString stringWithFormat:@"%@ — Silveton", full];
}

// ------------------------------------------------------------ selection --
- (void)selectRow:(ArrangeRow)row {
    const Project& p = _core->project();
    switch (row.kind) {
        case ArrangeRowKind::Audio:
            if (row.index >= p.tracks.size()) return;
            _selectedTrack = static_cast<long>(row.index); _selectedMidiTrack = -1; _selectedFolder = -1; _selectedPartId = 0;
            _strip = {SVStripKind::Track, row.index};
            break;
        case ArrangeRowKind::Midi:
            if (row.index >= p.midiTracks.size()) return;
            _selectedMidiTrack = static_cast<long>(row.index); _selectedTrack = -1; _selectedFolder = -1; _selectedClipId = 0;
            if (_core->midi()) _core->midi()->setTargetPort(p.midiTracks[row.index].outputPort);
            break;
        case ArrangeRowKind::Folder:
            if (row.index >= p.folders.size()) return;
            _selectedFolder = static_cast<long>(row.index); _selectedTrack = -1; _selectedMidiTrack = -1;
            _selectedClipId = 0; _selectedPartId = 0;
            break;
    }
    _insertRow = -1; _sendRow = -1;
    [self refreshChannelPanel];
}

- (void)selectStrip:(SVStrip)strip {
    _strip = strip;
    if (strip.kind == SVStripKind::Track) { _selectedTrack = static_cast<long>(strip.index); _selectedMidiTrack = -1; }
    [self refreshChannelPanel];
    [_console setNeedsDisplay:YES];
}

// ------------------------------------------------------------ transport --
- (void)seekToSample:(std::int64_t)sample {
    if (!_core || !_core->ready()) return;
    _core->engine().transport().seekSamples(std::max<std::int64_t>(0, sample));
    [_arrange setNeedsDisplay:YES];
    [_transport setNeedsDisplay:YES];
}

- (void)togglePlay:(id)sender {
    (void)sender;
    if (!_core || !_core->ready()) return;
    if (_core->engine().transport().isPlaying() || _core->recording() || _midiRecordTrack >= 0) [self stop:nil];
    else _core->engine().transport().play();
}

- (void)stop:(id)sender {
    (void)sender;
    if (!_core || !_core->ready()) return;
    try {
        auto& t = _core->engine().transport();
        const bool wasPlaying = t.isPlaying();
        if (_core->recording()) _core->stopRecording(true);
        if (_midiRecordTrack >= 0) [self stopMidiRecording];
        t.stop();
        if (!wasPlaying) t.seekSamples(0);   // stop while stopped returns to zero
    } catch (const std::exception& e) { [self showError:@"Stop" detail:e.what()]; }
    [self refreshAll];
}

- (void)goToStart:(id)sender { (void)sender; [self seekToSample:0]; }

- (void)record:(id)sender {
    (void)sender;
    if (!_core || !_core->ready()) return;
    if (_core->recording() || _midiRecordTrack >= 0) { [self stop:nil]; return; }
    Project& p = _core->project();
    try {
        if (_selectedMidiTrack >= 0 && _selectedMidiTrack < static_cast<long>(p.midiTracks.size())) {
            _midiRecordTrack = _selectedMidiTrack;
            _midiRecordStart = _core->engine().transport().positionSamples();
            if (_core->midi()) _core->midi()->setTargetPort(p.midiTracks[static_cast<std::size_t>(_selectedMidiTrack)].outputPort);
            _core->runtime().midiInput().beginRecording();
            _core->engine().transport().play();
            [self setStatus:@"Recording MIDI…"];
            return;
        }
        long target = -1;
        for (std::size_t i = 0; i < p.tracks.size(); ++i) if (p.tracks[i].recordArm) { target = static_cast<long>(i); break; }
        if (target < 0) target = _selectedTrack;
        if (target < 0 || target >= static_cast<long>(p.tracks.size()))
            throw std::runtime_error("Arm an audio track (● in its header) or select a MIDI track before recording.");
        _core->beginRecording(static_cast<std::size_t>(target));
    } catch (const std::exception& e) {
        _midiRecordTrack = -1;
        [self showError:@"Record" detail:e.what()];
    }
    [self refreshAll];
}

- (void)stopMidiRecording {
    if (_midiRecordTrack < 0 || !_core) return;
    const long track = _midiRecordTrack;
    _midiRecordTrack = -1;
    Project& p = _core->project();
    const std::int64_t stopSample = _core->engine().transport().positionSamples();
    _core->engine().transport().stop();
    MidiSequence absolute;
    const std::size_t count = _core->runtime().midiInput().stopAndCommit(absolute, p.tempoMap, stopSample);
    if (count == 0U || track >= static_cast<long>(p.midiTracks.size())) { [self setStatus:@"No MIDI received"]; return; }
    const std::int64_t recordStart = _midiRecordStart;
    [self runEdit:@"Record MIDI" rebuild:YES block:^{
        auto& mt = self->_core->project().midiTracks[static_cast<std::size_t>(track)];
        const auto pos = self->_core->project().tempoMap.positionAtSample(recordStart);
        const double barLen = pos.numerator * 4.0 / pos.denominator;
        self.selectedPartId = MidiTrackTools::addPartFromAbsolute(mt, absolute, barLen);
        self.selectedMidiTrack = track;
    }];
    [self setStatus:[NSString stringWithFormat:@"Recorded %lu MIDI event(s)", (unsigned long)count]];
}

- (void)toggleCycle:(id)sender {
    (void)sender;
    if (!_core || !_core->ready()) return;
    auto& t = _core->engine().transport();
    std::int64_t start = t.cycleStartSample(), end = t.cycleEndSample();
    if (end <= start) {
        const auto& map = _core->project().tempoMap;
        const auto pos = map.positionAtSample(t.positionSamples());
        start = map.sampleAtQuarterNotes(pos.barStartQuarterNotes);
        end = map.sampleAtQuarterNotes(pos.barStartQuarterNotes + 4.0 * pos.numerator * 4.0 / pos.denominator);
    }
    try { t.setCycleRange(!t.cycleEnabled(), start, end); } catch (const std::exception& e) { [self showError:@"Cycle" detail:e.what()]; }
    [self refreshAll];
}

- (void)setCycleStart:(std::int64_t)start end:(std::int64_t)end {
    if (!_core || !_core->ready() || end <= start) return;
    try { _core->engine().transport().setCycleRange(true, start, end); } catch (const std::exception& e) { [self showError:@"Cycle" detail:e.what()]; }
    [self refreshAll];
}

- (void)toggleMetronome:(id)sender {
    (void)sender;
    __block bool enabled = false;
    [self runEdit:@"Metronome" rebuild:NO block:^{
        auto& p = self->_core->project();
        p.metronomeEnabled = !p.metronomeEnabled;
        enabled = p.metronomeEnabled;
    }];
    if (_core && _core->ready()) _core->engine().setMetronomeEnabled(enabled);
}

- (std::int64_t)barStepFrom:(std::int64_t)sample direction:(int)dir {
    const auto& map = _core->project().tempoMap;
    const auto pos = map.positionAtSample(sample);
    const double barLen = pos.numerator * 4.0 / pos.denominator;
    double q = pos.barStartQuarterNotes;
    if (dir > 0) q += barLen;
    else if (map.sampleAtQuarterNotes(q) >= sample - 1) q = std::max(0.0, q - barLen);
    return map.sampleAtQuarterNotes(q);
}
- (void)rewindBar:(id)sender { (void)sender; if (_core && _core->ready()) [self seekToSample:[self barStepFrom:self.playheadSample direction:-1]]; }
- (void)forwardBar:(id)sender { (void)sender; if (_core && _core->ready()) [self seekToSample:[self barStepFrom:self.playheadSample direction:1]]; }
- (void)previousMarker:(id)sender {
    (void)sender;
    if (!_core) return;
    const auto* m = MarkerTools::previous(_core->project(), self.playheadSample - 1);
    [self seekToSample:m ? m->sample : 0];
}
- (void)nextMarker:(id)sender {
    (void)sender;
    if (!_core) return;
    if (const auto* m = MarkerTools::next(_core->project(), self.playheadSample)) [self seekToSample:m->sample];
}
- (void)addMarkerAtSample:(std::int64_t)sample {
    [self runEdit:@"Add Marker" rebuild:NO block:^{ (void)MarkerTools::add(self->_core->project(), "", sample); }];
}
- (void)addMarkerAtPlayhead:(id)sender { (void)sender; [self addMarkerAtSample:self.playheadSample]; }

- (void)gotoPositionDialog:(id)sender {
    (void)sender;
    if (!_core) return;
    NSString* s = [self promptText:@"Locate" message:@"Bar.Beat.Tick (e.g. 17.1.0)" initial:sv::ns(formatBarsBeats(_core->project().tempoMap, self.playheadSample))];
    if (!s) return;
    std::int64_t sample = 0;
    if (parseBarsBeats(_core->project().tempoMap, sv::str(s), sample)) [self seekToSample:sample];
    else [self showError:@"Locate" detail:"Could not read that position. Use bar.beat.tick, e.g. 9.3.240"];
}

- (void)editTempo:(id)sender {
    (void)sender;
    if (!_core) return;
    Project& p = _core->project();
    const std::int64_t pos = self.playheadSample;
    NSString* s = [self promptText:@"Tempo" message:(pos > 0 ? @"BPM from the current bar (a tempo change is inserted there)" : @"Project tempo in BPM")
                           initial:[NSString stringWithFormat:@"%.3f", p.tempoMap.tempoAtSample(pos)]];
    if (!s) return;
    const double bpm = s.doubleValue;
    if (!(bpm >= 20.0 && bpm <= 400.0)) { [self showError:@"Tempo" detail:"Tempo must be between 20 and 400 BPM"]; return; }
    [self runEdit:@"Tempo" rebuild:YES block:^{
        Project& pr = self->_core->project();
        const auto tp = pr.tempoMap.positionAtSample(pos);
        const std::int64_t bar = pr.tempoMap.sampleAtQuarterNotes(tp.barStartQuarterNotes);
        if (bar <= 0) pr.tempoMap.setInitialTempo(bpm); else pr.tempoMap.addTempoChange(bar, bpm);
        pr.tempo = pr.tempoMap.initialTempo();
    }];
}

- (void)editSignature:(id)sender {
    (void)sender;
    if (!_core) return;
    Project& p = _core->project();
    const std::int64_t pos = self.playheadSample;
    const auto tp = p.tempoMap.positionAtSample(pos);
    NSString* s = [self promptText:@"Time Signature" message:@"numerator/denominator, applied from the current bar"
                           initial:[NSString stringWithFormat:@"%u/%u", tp.numerator, tp.denominator]];
    if (!s) return;
    NSArray<NSString*>* parts = [s componentsSeparatedByString:@"/"];
    if (parts.count != 2) { [self showError:@"Time Signature" detail:"Use the form 3/4"]; return; }
    const int num = [parts[0] intValue], den = [parts[1] intValue];
    [self runEdit:@"Time Signature" rebuild:YES block:^{
        Project& pr = self->_core->project();
        const std::int64_t bar = pr.tempoMap.sampleAtQuarterNotes(pr.tempoMap.positionAtSample(pos).barStartQuarterNotes);
        if (bar <= 0) pr.tempoMap.setInitialTimeSignature(static_cast<std::uint16_t>(num), static_cast<std::uint16_t>(den));
        else pr.tempoMap.addTimeSignatureChange(bar, static_cast<std::uint16_t>(num), static_cast<std::uint16_t>(den));
    }];
}

- (void)toggleSnap:(id)sender { (void)sender; _snap = !_snap; [self setStatus:_snap ? @"Snap on" : @"Snap off"]; }
- (void)zoomIn:(id)sender { (void)sender; [self setPixelsPerSecond:_pps * 1.35]; }
- (void)zoomOut:(id)sender { (void)sender; [self setPixelsPerSecond:_pps / 1.35]; }
- (void)zoomToProject:(id)sender {
    (void)sender;
    if (!_core) return;
    std::int64_t end = 1;
    for (const auto& t : _core->project().tracks)
        for (const auto& c : t.clips) end = std::max<std::int64_t>(end, c.timelineStartSample + static_cast<std::int64_t>(c.lengthSamples));
    const double seconds = std::max(4.0, end / std::max(1.0, _core->project().sampleRate));
    _arrange.scrollSeconds = 0;
    [self setPixelsPerSecond:(_arrange.bounds.size.width - 264 - 28) / seconds];
}

// ----------------------------------------------------------------- timer --
- (void)timerTick:(NSTimer*)timer {
    (void)timer;
    if (!_core) return;
    ++_tick;
    try {
        if (_core->ready() && _core->runtime().projectRebuildRequested() && !_core->recording() && !_gestureOpen)
            [SilvetonNativeEditor closeAll];   // instances are about to be replaced
        if (!_gestureOpen) _core->service();
        // Repaint only what moved: the arrange canvas is never repainted as a whole
        // on a tick (that was far too heavy for 8+ tracks on an older iMac).
        if (_page == SVPage::Arrange) {
            const BOOL playing = _core->ready() && _core->engine().transport().isPlaying();
            BOOL scrolled = NO;
            if (playing) scrolled = [_arrange ensurePlayheadVisible];
            if (scrolled || (_core->recording() && _tick % 5U == 0U)) [_arrange setNeedsDisplay:YES];
            else [_arrange tickAnimation];
        } else if (_page == SVPage::Mix) {
            const std::uint32_t sig = [self meterSignature];
            if (sig != _lastConsoleSignature) { _lastConsoleSignature = sig; [_console setNeedsDisplay:YES]; }
        }
        [_transport tick];
        if (_tick % 4U == 0U) {
            [SilvetonNativeEditor refreshAll];
            if (_core->recording()) {
                [self setStatus:[NSString stringWithFormat:@"Recording audio — %.1f s",
                                 _core->recording()->status().framesAccepted / std::max(1.0, _core->project().sampleRate)]];
            } else if (_midiRecordTrack < 0 && _core->ready()) {
                const auto st = _core->runtime().status();
                if (!st.media.issues.empty()) [self setStatus:[NSString stringWithFormat:@"%lu offline media item(s)", (unsigned long)st.media.issues.size()]];
            }
            [self updateTitle];
            (void)_core->session().serviceAutosave([NSProcessInfo processInfo].systemUptime);
        }
    } catch (const std::exception& e) {
        [self setStatus:sv::ns(e.what())];
    }
}

// Bare-key shortcuts (Space, R, L …) must not fire while typing in a field.
- (BOOL)validateMenuItem:(NSMenuItem*)item {
    NSResponder* fr = _window.firstResponder;
    if ([fr isKindOfClass:[NSText class]] && item.keyEquivalent.length > 0 &&
        (item.keyEquivalentModifierMask & (NSEventModifierFlagCommand | NSEventModifierFlagOption | NSEventModifierFlagControl)) == 0)
        return NO;
    const SEL a = item.action;
    if ([fr isKindOfClass:[NSText class]] && (a == @selector(cutClip:) || a == @selector(copyClip:) || a == @selector(pasteClip:) || a == @selector(duplicateClip:)))
        return NO;   // let the text field handle ⌘X/⌘C/⌘V
    if (a == @selector(togglePlay:)) item.title = (_core && _core->ready() && _core->engine().transport().isPlaying()) ? @"Stop" : @"Play";
    if (a == @selector(toggleSnap:)) item.state = _snap ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(toggleChannelPanel:)) item.state = _channelPanelVisible ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(undo:)) return _core && _core->session().history().canUndo();
    if (a == @selector(redo:)) return _core && _core->session().history().canRedo();
    return YES;
}

@end

int main(int argc, const char* argv[]) {
    (void)argc; (void)argv;
    @autoreleasepool {
        NSApplication* app = [NSApplication sharedApplication];
        SilvetonController* delegate = [[SilvetonController alloc] init];
        app.delegate = delegate;
        [app run];
    }
    return 0;
}
