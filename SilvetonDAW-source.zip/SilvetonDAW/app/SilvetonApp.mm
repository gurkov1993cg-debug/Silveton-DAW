// Silveton — application controller: lifecycle, window layout, pages,
// selection, transport and the UI timer. Actions and panels live in the
// SilvetonActions.mm / SilvetonPanels.mm categories.
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/UiModel.h"

#include "silveton/DiskStream.h"

#include <algorithm>
#include <cmath>
#include <ctime>
#include <sstream>
#include <string>

using namespace silveton;

@implementation SilvetonController

@synthesize selectedTrack = _selectedTrack;
@synthesize selectedMidiTrack = _selectedMidiTrack;
@synthesize selectedFolder = _selectedFolder;
@synthesize selectedClipId = _selectedClipId;
@synthesize selectedPartId = _selectedPartId;
@synthesize selectedSectionId = _selectedSectionId;

// ------------------------------------------------------------ lifecycle --
- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    try {
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
        _selectedTrack = -1; _selectedMidiTrack = -1; _selectedFolder = -1;
        _insertRow = -1; _sendRow = -1; _midiRecordTrack = -1;
        _pps = 30.0; _snap = YES; _arrangeTool = SVArrangeTool::Select; _rangeClipLength = 0; _rangeClipQ0 = 0.0; _gridDiv = 4U; _page = SVPage::Arrange; _channelPanelVisible = YES; _zoneVisible = NO; _zoneTab = 1; _zoneH = 360.0; _editorArmed = NO; _meterPanelVisible = NO; _sampleZeroSnap = YES; _sampleRipple = YES;
        _strip = {SVStripKind::Master, 0};
        _supportDir = sv::appSupportDirectory();
        _presetDir = _supportDir + "/Presets";
        [[NSFileManager defaultManager] createDirectoryAtPath:sv::ns(_presetDir) withIntermediateDirectories:YES attributes:nil error:nil];
        _core = std::make_unique<sv::AppRuntime>();
        // An unavailable/disconnected audio interface must never stop the DAW
        // window from opening. The user can recover from Audio System Setup.
        std::string audioStartupError;
        try {
            _core->startDefault();
        } catch (const std::exception& e) {
            audioStartupError = e.what();
            _core->shutdownRealtime(); // discard any half-created CoreAudio state
        }
        NSString* scanner = [[NSBundle mainBundle] pathForResource:@"silveton_vst3_scanner" ofType:nil];
        if (!scanner) scanner = @"silveton_vst3_scanner";
        _browser = std::make_unique<Vst3PluginBrowserService>(sv::str(scanner), _supportDir + "/vst3-cache.txt", _supportDir + "/vst3-quarantine.txt", 7000U);
        try { _browser->load(); } catch (const std::exception&) {}
        try { _presets.loadIndex(_supportDir + "/preset-index.txt"); } catch (const std::exception&) {}
        try { _presets.scanDirectory(_presetDir, true); } catch (const std::exception&) {}
        [self buildMenus];
        [self buildWindow];
        [self reloadPluginResults];
        [self refreshAll];
        if (!audioStartupError.empty()) {
            [self setStatus:[NSString stringWithFormat:@"Audio device unavailable: %@ — choose SETUP to select an output", sv::ns(audioStartupError)]];
        }
        _timer = [NSTimer scheduledTimerWithTimeInterval:(1.0 / 30.0) target:self selector:@selector(timerTick:) userInfo:nil repeats:YES];
        [_window makeKeyAndOrderFront:nil];
        [NSApp activateIgnoringOtherApps:YES];
    } catch (const std::exception& e) {
        [self showError:@"Silveton failed to start" detail:e.what()];
        [NSApp terminate:nil];
    }
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender { (void)sender; return YES; }

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication*)sender {
    (void)sender;
    if (!_core || !_core->session().dirty()) return NSTerminateNow;
    NSAlert* a = [[NSAlert alloc] init];
    a.messageText = @"Save changes before quitting?";
    [a addButtonWithTitle:@"Save"];
    [a addButtonWithTitle:@"Don't Save"];
    [a addButtonWithTitle:@"Cancel"];
    const NSModalResponse r = [a runModal];
    if (r == NSAlertThirdButtonReturn) return NSTerminateCancel;
    if (r == NSAlertFirstButtonReturn) {
        [self saveProject:nil];
        if (_core->session().dirty()) return NSTerminateCancel;
    }
    return NSTerminateNow;
}

- (void)applicationWillTerminate:(NSNotification*)notification {
    (void)notification;
    [_timer invalidate];
    _timer = nil;
    [SilvetonNativeEditor closeAll];
    try {
        if (_browser) _browser->save();
        _presets.saveIndex(_supportDir + "/preset-index.txt");
        if (_core) { if (_core->recording()) _core->stopRecording(true); _core->shutdown(); }
    } catch (...) {}
}

// ------------------------------------------------------------- accessors --
- (sv::AppRuntime*)core { return _core.get(); }
- (Project*)project { return _core ? &_core->project() : nullptr; }
- (double)pixelsPerSecond { return _pps; }
- (void)setPixelsPerSecond:(double)pps { _pps = std::clamp(pps, 2.0, 2000.0); [_arrange setNeedsDisplay:YES]; [_toolBar setNeedsDisplay:YES]; }
- (std::int64_t)playheadSample { return _core && _core->ready() ? _core->engine().transport().positionSamples() : 0; }
- (BOOL)snapEnabled { return _snap; }
- (std::uint32_t)gridDivisionsPerQuarter { return _gridDiv; }
- (std::int64_t)snapSample:(std::int64_t)sample {
    if (!_snap || !_core) return std::max<std::int64_t>(0, sample);
    return std::max<std::int64_t>(0, _core->project().tempoMap.snapSampleToQuarterGrid(sample, _gridDiv));
}
- (SVPage)currentPage { return _page; }
- (SVStrip)selectedStrip { return _strip; }

- (void)showError:(NSString*)title detail:(const std::string&)detail {
    NSAlert* a = [[NSAlert alloc] init];
    a.alertStyle = NSAlertStyleCritical;
    a.messageText = title ?: @"Silveton";
    a.informativeText = sv::ns(detail);
    [a addButtonWithTitle:@"OK"];
    [a runModal];
}

- (NSString*)promptText:(NSString*)title message:(NSString*)message initial:(NSString*)initial {
    static NSDictionary<NSString*, NSString*>* labels = @{
        @"Rename": @"Name", @"New Folder": @"Name", @"Rename Marker": @"Name", @"Rename Section": @"Name",
        @"Project Notes": @"Notes", @"Locate": @"Position", @"Tempo": @"Tempo", @"Time Signature": @"Signature",
        @"Velocity": @"Velocity",
    };
    SVDialog* d = [SVDialog dialogWithTitle:title ?: @"Silveton" subtitle:message okTitle:@"OK"];
    const NSInteger row = [d addText:labels[title] ?: @"Value" value:initial ?: @""];
    if (![d run]) return nil;
    return [d textAt:row];
}

- (void)setStatus:(NSString*)text {
    _pageBar.statusText = text;
    [_pageBar setNeedsDisplay:YES];
    if (!_statusLog) _statusLog = [NSMutableArray array];
    if (text.length && ![_statusLog.lastObject hasSuffix:text]) {
        [_statusLog addObject:[NSString stringWithFormat:@"%.1f  %@", [NSProcessInfo processInfo].systemUptime, text]];
        while (_statusLog.count > 60) [_statusLog removeObjectAtIndex:0];
    }
}

// ---------------------------------------------------------- diagnostics --
// One text with everything needed to see why playing does not work on a machine we cannot look at.
- (NSString*)diagnosticReport {
    std::ostringstream o;
    const std::time_t now = std::time(nullptr);
    char stamp[64] = {0};
    std::strftime(stamp, sizeof stamp, "%Y-%m-%d %H:%M:%S", std::localtime(&now));
    o << "Silveton diagnostic report  " << stamp << "\n";
    o << "macOS " << sv::str([NSProcessInfo processInfo].operatingSystemVersionString) << "   cores " << [NSProcessInfo processInfo].processorCount
      << "   memory " << ([NSProcessInfo processInfo].physicalMemory / (1024ULL * 1024ULL)) << " MB\n\n";
    if (!_core) { o << "core: none\n"; return sv::ns(o.str()); }
    o << "core ready: " << (_core->ready() ? "yes" : "NO") << "\n";
    try {
        auto& dev = _core->device();
        const auto cfg = dev.config();
        const auto st = dev.status();
        o << "device running: " << (dev.isRunning() ? "yes" : "NO") << "   rate " << cfg.sampleRate << "   block " << cfg.blockSize
          << "   in " << cfg.inputChannels << "   out " << cfg.outputChannels << "\n";
        o << "callbacks " << st.callbackCount << "   overloads " << st.overloadCount << "   needsReopen " << (st.needsReopen ? "YES" : "no")
          << "   latency in/out/unit " << st.inputLatencyFrames << "/" << st.outputLatencyFrames << "/" << st.audioUnitLatencyFrames << "\n";
    } catch (const std::exception& e) { o << "device: " << e.what() << "\n"; }
    if (_core->ready()) {
        auto& engine = _core->engine();
        const auto& t = engine.transport();
        o << "transport playing " << (t.isPlaying() ? "yes" : "no") << "   position " << t.positionSamples()
          << "   cycle " << (t.cycleEnabled() ? "on" : "off") << " " << t.cycleStartSample() << ".." << t.cycleEndSample() << "\n";
        o << "engine rate " << engine.deviceConfig().sampleRate << "   block " << engine.deviceConfig().blockSize
          << "   tracks " << engine.trackCount() << "   buses " << engine.busCount()
          << "   DSP " << (_core->runtime().engineCallback().dspLoad() * 100.0) << " %"
          << "   graph pending " << (engine.processorGraphPublicationPending() ? "YES" : "no") << "\n";
        const auto& rs = _core->runtime().status();
        o << "media: tracks published " << rs.media.tracksPublished << "   sources " << rs.media.uniqueAudioSources
          << "   offline clips " << rs.media.offlineClips << "   issues " << rs.media.issues.size() << "\n";
        for (const auto& issue : rs.media.issues) o << "   issue: " << issue.path << " — " << issue.detail << "\n";
        const auto& streams = _core->runtime().playback().streams();
        o << "disk sources " << streams.sourceCount() << "\n";
        for (std::size_t i = 0U; i < streams.sourceCount(); ++i) {
            const auto& s = streams.source(i);
            const auto ds = s.status();
            o << "   [" << i << "] " << s.path() << "   native " << s.nativeSampleRate() << " Hz -> " << s.sampleRate() << " Hz"
              << (s.rateConverted() ? " (converted live)" : "") << "   ch " << s.channels() << "   frames " << s.frames()
              << "   cache " << s.cacheFrames() << "   loads " << ds.cacheLoads << "   underflow blocks " << ds.underflowBlocks
              << " frames " << ds.underflowFrames << (ds.ioError ? "   IO ERROR" : "") << "\n";
        }
    }
    const Project& p = _core->project();
    o << "project rate " << p.sampleRate << "   tempo " << p.tempo << "   audio tracks " << p.tracks.size() << "   midi tracks " << p.midiTracks.size()
      << "   buses " << p.buses.size() << "\n";
    for (std::size_t i = 0U; i < p.tracks.size(); ++i) {
        const auto& tr = p.tracks[i];
        o << "   track " << i << " '" << tr.name << "'  clips " << tr.clips.size() << "  gain " << tr.gainDb << " dB"
          << (tr.mute ? "  MUTE" : "") << (tr.solo ? "  SOLO" : "") << "  out " << tr.outputBus << "  inserts " << tr.pluginSlots.size() << "\n";
        for (const auto& c : tr.clips)
            o << "      clip " << c.id << "  " << c.audioPath << "  start " << c.timelineStartSample << "  len " << c.lengthSamples
              << "  src " << c.sourceStartSample << "  file " << c.sourceSampleRate << " Hz " << c.sourceChannels << " ch" << (c.mute ? "  muted" : "") << "\n";
    }
    o << "\nlast status messages:\n";
    for (NSString* line in _statusLog ?: @[]) o << "   " << sv::str(line) << "\n";
    return sv::ns(o.str());
}

- (NSString*)saveDiagnosticReport {
    NSString* dir = [NSSearchPathForDirectoriesInDomains(NSDesktopDirectory, NSUserDomainMask, YES) firstObject] ?: NSHomeDirectory();
    NSString* path = [dir stringByAppendingPathComponent:@"Silveton-report.txt"];
    NSError* error = nil;
    [[self diagnosticReport] writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
    return error ? nil : path;
}

- (void)saveDiagnosticReportAction:(id)sender {
    (void)sender;
    NSString* path = [self saveDiagnosticReport];
    if (path) {
        [self setStatus:@"Diagnostic report saved on the Desktop: Silveton-report.txt"];
        [[NSWorkspace sharedWorkspace] selectFile:path inFileViewerRootedAtPath:@""];
    } else {
        [self setStatus:@"Could not write the diagnostic report"];
    }
}
- (void)requestRebuild { if (_core && _core->ready()) _core->runtime().requestProjectRebuild(); }

// Runs `block` inside one undoable edit. Exceptions roll the edit back.
- (void)runEdit:(NSString*)label rebuild:(BOOL)rebuild block:(void (^)(void))block {
    if (!_core) return;
    auto& session = _core->session();
    const bool own = !session.history().transactionOpen();
    try {
        if (own) session.beginEdit(sv::str(label));
        block();
        if (own) session.commitEdit(); else session.markDirty();
        if (rebuild) { if (_gestureOpen) _gestureNeedsRebuild = YES; else [self requestRebuild]; }
    } catch (const std::exception& e) {
        if (own && session.history().transactionOpen()) session.cancelEdit();
        [self showError:label detail:e.what()];
    }
    [self refreshAll];
}

- (void)beginGesture:(NSString*)label {
    if (!_core || _gestureOpen) return;
    if (!_core->session().history().transactionOpen()) _core->session().beginEdit(sv::str(label));
    _gestureOpen = YES;
    _gestureNeedsRebuild = NO;
}
- (void)endGesture {
    if (!_core || !_gestureOpen) return;
    _gestureOpen = NO;
    if (_core->session().history().transactionOpen()) _core->session().commitEdit();
    if (_gestureNeedsRebuild) [self requestRebuild];
    _gestureNeedsRebuild = NO;
    [self refreshAll];
}

// --------------------------------------------------------------- window --
- (void)buildWindow {
    const CGFloat W = 1480, H = 920, statusH = 24, deckH = 78, sideW = 74;
    _window = [[NSWindow alloc] initWithContentRect:NSMakeRect(60, 60, W, H)
                                          styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskResizable
                                            backing:NSBackingStoreBuffered defer:NO];
    _window.title = @"Silveton";
    _window.minSize = NSMakeSize(1280, 720);
    _window.backgroundColor = sv::canvas();
    _window.delegate = self;
    if (@available(macOS 10.14, *)) _window.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
    else _window.appearance = [NSAppearance appearanceNamed:@"NSAppearanceNameVibrantDark"];   // macOS 10.13
    _root = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, W, H)];
    _root.autoresizesSubviews = YES;
    _window.contentView = _root;

    _sideBar = [[SilvetonSideBar alloc] initWithFrame:NSMakeRect(0, 0, sideW, H)];
    _sideBar.autoresizingMask = NSViewHeightSizable | NSViewMaxXMargin;
    _sideBar.controller = self;
    [_root addSubview:_sideBar];

    _pageBar = [[SilvetonPageBar alloc] initWithFrame:NSMakeRect(sideW, 0, W - sideW, statusH)];
    _pageBar.autoresizingMask = NSViewWidthSizable | NSViewMaxYMargin;
    _pageBar.controller = self;
    [_root addSubview:_pageBar];

    _transport = [[SilvetonTransportDeck alloc] initWithFrame:NSMakeRect(sideW, H - deckH, W - sideW, deckH)];
    _transport.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    _transport.controller = self;
    [_root addSubview:_transport];

    const NSRect content = NSMakeRect(sideW, statusH, W - sideW, H - deckH - statusH);
    _arrangePage = [self makeLayoutPage:content];
    _mixPage = [self makePage:content];
    _editPage = [self makeLayoutPage:content];
    _libraryPage = [self makePage:content];

    // Project page: Inspector on the left; tool row, tracks and the small mixer in the middle; level panel on the right
    const CGFloat panelW = kInspectorPanelW;
    _arrange = [[SilvetonArrangeView alloc] initWithFrame:NSMakeRect(panelW, 0, content.size.width - panelW, content.size.height)];
    _arrange.autoresizingMask = NSViewNotSizable;   // all of these are placed by layoutArrangePage
    _arrange.controller = self;
    [_arrangePage addSubview:_arrange];
    [self buildChannelPanelIn:NSMakeRect(0, 0, panelW, content.size.height)];
    _channelScroll.autoresizingMask = NSViewNotSizable;
    _inspectorTabs = [[SilvetonInspectorTabs alloc] initWithFrame:NSMakeRect(0, 0, panelW, 26)];
    _inspectorTabs.autoresizingMask = NSViewNotSizable;
    _inspectorTabs.controller = self;
    [_arrangePage addSubview:_inspectorTabs];
    _toolBar = [[SilvetonToolBar alloc] initWithFrame:NSMakeRect(panelW, 0, 400, 34)];
    _toolBar.autoresizingMask = NSViewNotSizable;
    _toolBar.controller = self;
    [_arrangePage addSubview:_toolBar];
    _infoLine = [[SilvetonInfoLine alloc] initWithFrame:NSMakeRect(panelW, 0, 400, 32)];
    _infoLine.autoresizingMask = NSViewNotSizable;
    _infoLine.controller = self;
    [_arrangePage addSubview:_infoLine];
    _dock = [[SilvetonConsoleView alloc] initWithFrame:NSMakeRect(panelW, 0, 400, 296)];
    _dock.autoresizingMask = NSViewNotSizable;
    _dock.compact = YES;
    _dock.controller = self;
    [_arrangePage addSubview:_dock];
    _zoneBar = [[SilvetonZoneBar alloc] initWithFrame:NSMakeRect(panelW, 0, 400, 24)];
    _zoneBar.autoresizingMask = NSViewNotSizable;
    _zoneBar.controller = self;
    [_arrangePage addSubview:_zoneBar];
    _zoneSplitter = [[SilvetonZoneSplitter alloc] initWithFrame:NSMakeRect(panelW, 0, 400, 8)];
    _zoneSplitter.autoresizingMask = NSViewNotSizable;
    _zoneSplitter.controller = self;
    [_arrangePage addSubview:_zoneSplitter];
    _meterPanel = [[SilvetonMeterPanel alloc] initWithFrame:NSMakeRect(0, 0, 196, 400)];
    _meterPanel.autoresizingMask = NSViewNotSizable;
    _meterPanel.controller = self;
    [_arrangePage addSubview:_meterPanel];
    __weak SilvetonController* weakSelf = self;
    ((SilvetonLayoutView*)_arrangePage).onLayout = ^{ [weakSelf layoutArrangePage]; };
    // Which area the last click landed in decides where Delete, Cut, Copy … go: the editor under the tracks, or the tracks.
    _clickMonitor = [NSEvent addLocalMonitorForEventsMatchingMask:(NSEventMaskLeftMouseDown | NSEventMaskRightMouseDown)
                                                          handler:^NSEvent*(NSEvent* e) { [weakSelf noteClick:e]; return e; }];
    [self layoutArrangePage];

    // Mix
    _console = [[SilvetonConsoleView alloc] initWithFrame:NSMakeRect(0, 0, content.size.width, content.size.height)];
    _console.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _console.controller = self;
    [_mixPage addSubview:_console];

    [self buildEditPage:_editPage];
    ((SilvetonLayoutView*)_editPage).onLayout = ^{ [weakSelf layoutEditPage]; };
    [self buildLibraryPage:_libraryPage];
    [self showPage:SVPage::Arrange];
}

- (NSView*)makePage:(NSRect)frame {
    NSView* v = [[NSView alloc] initWithFrame:frame];
    v.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    v.autoresizesSubviews = YES;
    [_root addSubview:v];
    return v;
}

- (NSView*)makeLayoutPage:(NSRect)frame {
    SilvetonLayoutView* v = [[SilvetonLayoutView alloc] initWithFrame:frame];
    v.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    v.autoresizesSubviews = NO;   // the page places its own children
    [_root addSubview:v];
    return v;
}

// Project page: [Inspector: TRACK | EDITOR] | tool row, info line, tracks, lower zone (mixer or editor) | [level panel]
- (void)layoutArrangePage {
    if (!_arrangePage || !_arrange || !_toolBar) return;
    const NSRect b = _arrangePage.bounds;
    const CGFloat toolH = 34.0, infoH = 32.0, barH = 24.0, splitH = 8.0, meterW = _meterPanelVisible ? 196.0 : 0.0;
    const CGFloat panelW = _channelPanelVisible ? kInspectorPanelW : 0.0;
    const CGFloat zoneMax = std::max<CGFloat>(0.0, b.size.height - toolH - infoH - 140.0);   // the tracks keep at least 140 px
    const CGFloat zoneH = _zoneVisible ? std::min<CGFloat>(zoneMax, std::max<CGFloat>(std::min<CGFloat>(180.0, zoneMax), _zoneH)) : 0.0;
    const CGFloat midW = std::max<CGFloat>(100.0, b.size.width - panelW - meterW);
    if (![self editorShown]) _inspectorTab = 0;
    if (_page == SVPage::Arrange) {
        if (_channelPanelVisible) [self placeInspectorIn:_arrangePage frame:NSMakeRect(0, 0, kInspectorPanelW, b.size.height)];
        else { _inspectorTabs.hidden = YES; _channelScroll.hidden = YES; _editorScroll.hidden = YES; }
    }
    _toolBar.frame = NSMakeRect(panelW, b.size.height - toolH, b.size.width - panelW, toolH);
    _infoLine.frame = NSMakeRect(panelW, b.size.height - toolH - infoH, midW, infoH);
    _arrange.frame = NSMakeRect(panelW, zoneH, midW, std::max<CGFloat>(0.0, b.size.height - toolH - infoH - zoneH));
    const BOOL zone = zoneH >= 1.0;
    _zoneSplitter.hidden = !zone;
    _zoneSplitter.frame = NSMakeRect(panelW, zoneH - splitH, midW, splitH);
    _zoneBar.hidden = !zone;
    _zoneBar.frame = NSMakeRect(panelW, 0, midW, barH);
    const NSRect inner = NSMakeRect(panelW, barH, midW, std::max<CGFloat>(0.0, zoneH - barH - splitH));
    _dock.hidden = !(zone && _zoneTab == 0);
    _dock.frame = inner;
    if (zone && _zoneTab == 1 && _page == SVPage::Arrange) [self placeEditorIn:_arrangePage frame:inner];
    else if (_editorRoot && _editorRoot.superview == _arrangePage) _editorRoot.hidden = YES;
    _meterPanel.hidden = !_meterPanelVisible;
    _meterPanel.frame = NSMakeRect(panelW + midW, 0, meterW, std::max<CGFloat>(0.0, b.size.height - toolH));
    [_toolBar setNeedsDisplay:YES];
    [_infoLine setNeedsDisplay:YES];
    [_zoneBar setNeedsDisplay:YES];
    [_window invalidateCursorRectsForView:_zoneSplitter];
}

// Edit page (the editor on a full page): [Inspector: TRACK | EDITOR] | editor
- (void)layoutEditPage {
    if (!_editPage || !_editorRoot || _page != SVPage::Edit) return;
    const NSRect b = _editPage.bounds;
    [self placeInspectorIn:_editPage frame:NSMakeRect(0, 0, kInspectorPanelW, b.size.height)];
    [self placeEditorIn:_editPage frame:NSMakeRect(kInspectorPanelW, 0, std::max<CGFloat>(100.0, b.size.width - kInspectorPanelW), b.size.height)];
}

// The inspector column (tabs on top, one of the two scroll views under them) is shared by the two pages.
- (void)placeInspectorIn:(NSView*)parent frame:(NSRect)frame {
    if (!parent || !_inspectorTabs || !_channelScroll || !_editorScroll) return;
    const CGFloat tabsH = 26.0;
    for (NSView* v in @[_inspectorTabs, _channelScroll, _editorScroll]) {
        if (v.superview != parent) { [v removeFromSuperview]; [parent addSubview:v]; }
    }
    _inspectorTabs.frame = NSMakeRect(frame.origin.x, NSMaxY(frame) - tabsH, frame.size.width, tabsH);
    const NSRect body = NSMakeRect(frame.origin.x, frame.origin.y, frame.size.width, std::max<CGFloat>(0.0, frame.size.height - tabsH));
    _channelScroll.frame = body;
    _editorScroll.frame = body;
    _inspectorTabs.hidden = NO;
    _channelScroll.hidden = _inspectorTab == 1;
    _editorScroll.hidden = _inspectorTab != 1;
    [_inspectorTabs setNeedsDisplay:YES];
}
- (void)selectInspectorTab:(int)tab {
    _inspectorTab = (tab == 1 && [self editorShown]) ? 1 : 0;
    if (_page == SVPage::Edit) [self layoutEditPage]; else [self layoutArrangePage];
}
- (int)inspectorTab { return _inspectorTab; }

// The editor lives in one view that is moved between the Edit page (full page) and the lower zone.
- (void)placeEditorIn:(NSView*)parent frame:(NSRect)frame {
    if (!_editorRoot || !parent) return;
    if (_editorRoot.superview != parent) {
        [_editorRoot removeFromSuperview];
        [parent addSubview:_editorRoot];
    }
    if (!NSEqualRects(_editorRoot.frame, frame)) _editorRoot.frame = frame;
    _editorRoot.hidden = NO;
}
- (BOOL)editorShown { return _page == SVPage::Edit || (_page == SVPage::Arrange && _zoneVisible && _zoneTab == 1); }
- (BOOL)editorFocused { return _page == SVPage::Edit || ([self editorShown] && _editorArmed); }
- (void)focusEditor {
    NSView* v = (_toneView && ![_toneView isHidden]) ? (NSView*)_toneView
              : ((_sampleView && ![_sampleView isHidden]) ? (NSView*)_sampleView : (NSView*)_noteGrid);
    if (v) [_window makeFirstResponder:v];
}
- (void)showEditorInZone {
    if (_page == SVPage::Edit) { [self refreshEditPage]; [self focusEditor]; return; }
    if (_page != SVPage::Arrange) [self showPage:SVPage::Arrange];
    _zoneVisible = YES;
    _zoneTab = 1;
    _editorArmed = YES;
    _inspectorTab = 1;
    [self layoutArrangePage];
    [self refreshEditPage];
    [self focusEditor];
}
// The Inspector follows the click too: a click in the tracks shows TRACK, a click in the editor shows EDITOR.
- (void)noteClick:(NSEvent*)event {
    if (event.window != _window || _page != SVPage::Arrange || !_editorRoot || _editorRoot.superview != _arrangePage || [_editorRoot isHidden]) return;
    NSView* content = _window.contentView;
    const NSPoint p = [content convertPoint:event.locationInWindow fromView:nil];
    BOOL changed = NO;
    if (NSPointInRect(p, [_editorRoot convertRect:_editorRoot.bounds toView:content])) { changed = !_editorArmed || _inspectorTab != 1; _editorArmed = YES; _inspectorTab = 1; }
    else if (_editorScroll && ![_editorScroll isHidden] && NSPointInRect(p, [_editorScroll convertRect:_editorScroll.bounds toView:content])) _editorArmed = YES;   // the EDITOR inspector works on the editor
    else if (NSPointInRect(p, [_arrange convertRect:_arrange.bounds toView:content])) { changed = _editorArmed || _inspectorTab != 0; _editorArmed = NO; _inspectorTab = 0; }
    if (changed) [self layoutArrangePage];
}

// ---- lower zone switches
- (BOOL)lowerZoneShown { return _zoneVisible; }
- (int)zoneTab { return _zoneTab; }
- (BOOL)dockMixerShown { return _zoneVisible && _zoneTab == 0; }
- (BOOL)editorZoneShown { return _zoneVisible && _zoneTab == 1; }
- (CGFloat)zoneHeight { return _zoneH; }
- (void)setZoneHeight:(CGFloat)height {
    const CGFloat maxH = std::max<CGFloat>(180.0, _arrangePage.bounds.size.height - 34.0 - 140.0);
    _zoneH = std::round(std::min<CGFloat>(maxH, std::max<CGFloat>(180.0, height)));
    [self layoutArrangePage];
}
- (void)selectZoneTab:(int)tab {
    _zoneVisible = YES;
    _zoneTab = tab == 1 ? 1 : 0;
    if (_page != SVPage::Arrange) [self showPage:SVPage::Arrange];
    [self layoutArrangePage];
    if (_zoneTab == 1) { _editorArmed = YES; _inspectorTab = 1; [self layoutArrangePage]; [self refreshEditPage]; [self focusEditor]; }
    else { _inspectorTab = 0; [self layoutArrangePage]; [_dock setNeedsDisplay:YES]; }
}
- (void)toggleDockMixer:(id)sender {
    (void)sender;
    if ([self dockMixerShown]) [self hideLowerZone:nil];
    else [self selectZoneTab:0];
}
- (void)toggleEditorZone:(id)sender {
    (void)sender;
    if ([self editorZoneShown]) [self hideLowerZone:nil];
    else [self selectZoneTab:1];
}
- (void)toggleLowerZone:(id)sender {
    (void)sender;
    if (_zoneVisible) [self hideLowerZone:nil];
    else [self selectZoneTab:_zoneTab];
}
- (void)hideLowerZone:(id)sender {
    (void)sender;
    _zoneVisible = NO;
    [self layoutArrangePage];
    if (_page == SVPage::Arrange) [_window makeFirstResponder:_arrange];
}
- (void)toggleEditorPlace:(id)sender {
    (void)sender;
    if (_page == SVPage::Edit) {
        [self showPage:SVPage::Arrange];
        [self selectZoneTab:1];
    } else {
        [self showPage:SVPage::Edit];
    }
}
- (void)setChannelPanelVisible:(BOOL)visible {
    _channelPanelVisible = visible;
    [self layoutArrangePage];
}
- (void)toggleChannelPanel:(id)sender { (void)sender; [self setChannelPanelVisible:!_channelPanelVisible]; }
- (void)toggleMeterPanel:(id)sender { (void)sender; _meterPanelVisible = !_meterPanelVisible; [self layoutArrangePage]; }
- (BOOL)channelPanelShown { return _channelPanelVisible; }
- (BOOL)meterPanelShown { return _meterPanelVisible; }
- (void)pickGrid:(id)sender {
    const NSInteger tag = [sender respondsToSelector:@selector(tag)] ? [sender tag] : 4;
    _gridDiv = static_cast<std::uint32_t>(std::clamp<NSInteger>(tag, 1, 8));
    static const std::uint32_t divs[4] = {1U, 2U, 4U, 8U};
    for (NSInteger i = 0; i < 4; ++i) if (divs[i] == _gridDiv) [_gridPopup selectItemAtIndex:i];
    [_noteGrid setNeedsDisplay:YES];
    [_arrange setNeedsDisplay:YES];
    [_toolBar setNeedsDisplay:YES];
}

- (void)showPage:(SVPage)page {
    _page = page;
    _arrangePage.hidden = page != SVPage::Arrange;
    _mixPage.hidden = page != SVPage::Mix;
    _editPage.hidden = page != SVPage::Edit;
    _libraryPage.hidden = page != SVPage::Library;
    _sideBar.page = page == SVPage::Mix ? 1 : (page == SVPage::Library ? 2 : 0);   // the full-page editor belongs to the project
    [_sideBar setNeedsDisplay:YES];
    if (page == SVPage::Edit) {
        _inspectorTab = 1;
        [self layoutEditPage];   // the full page: inspector + editor
        [self refreshEditPage];
        [self focusEditor];
    }
    if (page == SVPage::Arrange) {
        [self layoutArrangePage];   // puts the editor back under the tracks when that tab is on
        if ([self editorZoneShown]) [self refreshEditPage];
        [_window makeFirstResponder:_arrange];
    }
    if (page == SVPage::Library) [self refreshLibrary];
    if (page == SVPage::Mix) [_console setNeedsDisplay:YES];
}
- (void)showArrangePage:(id)sender { (void)sender; [self showPage:SVPage::Arrange]; }
- (void)showMixPage:(id)sender { (void)sender; [self showPage:SVPage::Mix]; }
- (void)showEditPage:(id)sender { (void)sender; [self showPage:SVPage::Edit]; }
- (void)showLibraryPage:(id)sender { (void)sender; [self showPage:SVPage::Library]; }

- (void)refreshAll {
    if (!_core) return;
    Project& p = _core->project();
    if (_selectedTrack >= static_cast<long>(p.tracks.size())) { _selectedTrack = -1; _selectedClipId = 0; }
    if (_selectedMidiTrack >= static_cast<long>(p.midiTracks.size())) { _selectedMidiTrack = -1; _selectedPartId = 0; }
    if (_selectedFolder >= static_cast<long>(p.folders.size())) _selectedFolder = -1;
    if (_strip.kind == SVStripKind::Track && _strip.index >= p.tracks.size()) _strip = {SVStripKind::Master, 0};
    if (_strip.kind == SVStripKind::Bus && _strip.index >= p.buses.size()) _strip = {SVStripKind::Master, 0};
    [_arrange setNeedsDisplay:YES];
    [_console setNeedsDisplay:YES];
    [_dock setNeedsDisplay:YES];
    [_meterPanel setNeedsDisplay:YES];
    [_toolBar setNeedsDisplay:YES];
    [_infoLine setNeedsDisplay:YES];
    [_transport setNeedsDisplay:YES];
    [self refreshChannelPanel];
    if ([self editorShown]) [self refreshEditPage];
    if (_page == SVPage::Library) [self refreshLibrary];
    [self updateTitle];
}

- (void)updateTitle {
    if (!_core) return;
    NSString* name = _core->session().hasProjectPath() ? [[sv::ns(_core->session().projectPath()) lastPathComponent] stringByDeletingPathExtension] : @"Untitled";
    NSString* full = [NSString stringWithFormat:@"%@%@", name, _core->session().dirty() ? @" •" : @""];
    if (![_pageBar.projectTitle isEqualToString:full]) { _pageBar.projectTitle = full; [_pageBar setNeedsDisplay:YES]; }
    _window.title = [NSString stringWithFormat:@"%@ — Silveton", full];
}

// ------------------------------------------------------------ selection --
- (void)selectRow:(ArrangeRow)row {
    const Project& p = _core->project();
    switch (row.kind) {
        case ArrangeRowKind::Audio:
            if (row.index >= p.tracks.size()) return;
            _selectedTrack = static_cast<long>(row.index); _selectedMidiTrack = -1; _selectedFolder = -1; _selectedPartId = 0;
            _strip = {SVStripKind::Track, row.index};
            break;
        case ArrangeRowKind::Midi:
            if (row.index >= p.midiTracks.size()) return;
            _selectedMidiTrack = static_cast<long>(row.index); _selectedTrack = -1; _selectedFolder = -1; _selectedClipId = 0;
            if (_core->midi()) _core->midi()->setTargetPort(p.midiTracks[row.index].outputPort);
            break;
        case ArrangeRowKind::Folder:
            if (row.index >= p.folders.size()) return;
            _selectedFolder = static_cast<long>(row.index); _selectedTrack = -1; _selectedMidiTrack = -1;
            _selectedClipId = 0; _selectedPartId = 0;
            break;
    }
    _insertRow = -1; _sendRow = -1;
    [self refreshChannelPanel];
}

- (void)selectStrip:(SVStrip)strip {
    _strip = strip;
    if (strip.kind == SVStripKind::Track) { _selectedTrack = static_cast<long>(strip.index); _selectedMidiTrack = -1; }
    [self refreshChannelPanel];
    [_console setNeedsDisplay:YES];
}

// ------------------------------------------------------------ transport --
- (void)seekToSample:(std::int64_t)sample {
    if (!_core || !_core->ready()) return;
    _core->engine().transport().seekSamples(std::max<std::int64_t>(0, sample));
    [_arrange setNeedsDisplay:YES];
    [_transport setNeedsDisplay:YES];
}

- (void)togglePlay:(id)sender {
    (void)sender;
    if (!_core || !_core->ready()) {
        [self setStatus:@"Audio is not running — open Audio System Setup… and choose an output device"];
        return;
    }
    if (_core->engine().transport().isPlaying() || _core->recording() || _midiRecordTrack >= 0) { [self stop:nil]; return; }
    _meters.resetPeaks();   // a new pass starts with clean clip lamps and peak read-outs
    try {
        // Never start on a stale project: a pending rebuild (for example right after an import) runs first.
        if (!_gestureOpen) _core->service();
    } catch (const std::exception& e) {
        [self setStatus:sv::ns(e.what())];
    }
    if (!_core->ready() || !_core->ensureRunning()) {
        [self setStatus:@"The audio device could not be started — open Audio System Setup… and press Apply"];
        return;
    }
    _playWatchTick = _tick ? _tick : 1U;
    _playWatchPosition = _core->engine().transport().positionSamples();
    _playWatchCallbacks = _core->device().status().callbackCount;
    _core->engine().transport().play();
}

- (void)stop:(id)sender {
    (void)sender;
    if (!_core || !_core->ready()) return;
    try {
        auto& t = _core->engine().transport();
        const bool wasPlaying = t.isPlaying();
        if (_core->recording()) _core->stopRecording(true);
        if (_midiRecordTrack >= 0) [self stopMidiRecording];
        t.stop();
        if (!wasPlaying) t.seekSamples(0);   // stop while stopped returns to zero
    } catch (const std::exception& e) { [self showError:@"Stop" detail:e.what()]; }
    [self refreshAll];
}

- (void)goToStart:(id)sender { (void)sender; [self seekToSample:0]; }

- (void)record:(id)sender {
    (void)sender;
    if (!_core || !_core->ready()) return;
    if (_core->recording() || _midiRecordTrack >= 0) { [self stop:nil]; return; }
    Project& p = _core->project();
    try {
        if (_selectedMidiTrack >= 0 && _selectedMidiTrack < static_cast<long>(p.midiTracks.size())) {
            _midiRecordTrack = _selectedMidiTrack;
            _midiRecordStart = _core->engine().transport().positionSamples();
            if (_core->midi()) _core->midi()->setTargetPort(p.midiTracks[static_cast<std::size_t>(_selectedMidiTrack)].outputPort);
            _core->runtime().midiInput().beginRecording();
            _core->engine().transport().play();
            [self setStatus:@"Recording MIDI…"];
            return;
        }
        long target = -1;
        for (std::size_t i = 0; i < p.tracks.size(); ++i) if (p.tracks[i].recordArm) { target = static_cast<long>(i); break; }
        if (target < 0) target = _selectedTrack;
        if (target < 0 || target >= static_cast<long>(p.tracks.size()))
            throw std::runtime_error("Arm an audio track (● in its header) or select a MIDI track before recording.");
        _core->beginRecording(static_cast<std::size_t>(target));
    } catch (const std::exception& e) {
        _midiRecordTrack = -1;
        [self showError:@"Record" detail:e.what()];
    }
    [self refreshAll];
}

- (void)stopMidiRecording {
    if (_midiRecordTrack < 0 || !_core) return;
    const long track = _midiRecordTrack;
    _midiRecordTrack = -1;
    Project& p = _core->project();
    const std::int64_t stopSample = _core->engine().transport().positionSamples();
    _core->engine().transport().stop();
    MidiSequence absolute;
    const std::size_t count = _core->runtime().midiInput().stopAndCommit(absolute, p.tempoMap, stopSample);
    if (count == 0U || track >= static_cast<long>(p.midiTracks.size())) { [self setStatus:@"No MIDI received"]; return; }
    const std::int64_t recordStart = _midiRecordStart;
    [self runEdit:@"Record MIDI" rebuild:YES block:^{
        auto& mt = self->_core->project().midiTracks[static_cast<std::size_t>(track)];
        const auto pos = self->_core->project().tempoMap.positionAtSample(recordStart);
        const double barLen = pos.numerator * 4.0 / pos.denominator;
        self.selectedPartId = MidiTrackTools::addPartFromAbsolute(mt, absolute, barLen);
        self.selectedMidiTrack = track;
    }];
    [self setStatus:[NSString stringWithFormat:@"Recorded %lu MIDI event(s)", (unsigned long)count]];
}

- (void)toggleCycle:(id)sender {
    (void)sender;
    if (!_core || !_core->ready()) return;
    auto& t = _core->engine().transport();
    std::int64_t start = t.cycleStartSample(), end = t.cycleEndSample();
    if (end <= start) {
        const auto& map = _core->project().tempoMap;
        const auto pos = map.positionAtSample(t.positionSamples());
        start = map.sampleAtQuarterNotes(pos.barStartQuarterNotes);
        end = map.sampleAtQuarterNotes(pos.barStartQuarterNotes + 4.0 * pos.numerator * 4.0 / pos.denominator);
    }
    try { t.setCycleRange(!t.cycleEnabled(), start, end); } catch (const std::exception& e) { [self showError:@"Cycle" detail:e.what()]; }
    [self refreshAll];
}

- (void)setCycleStart:(std::int64_t)start end:(std::int64_t)end {
    if (!_core || !_core->ready() || end <= start) return;
    try { _core->engine().transport().setCycleRange(true, start, end); } catch (const std::exception& e) { [self showError:@"Cycle" detail:e.what()]; }
    [self refreshAll];
}

- (void)toggleMetronome:(id)sender {
    (void)sender;
    __block bool enabled = false;
    [self runEdit:@"Metronome" rebuild:NO block:^{
        auto& p = self->_core->project();
        p.metronomeEnabled = !p.metronomeEnabled;
        enabled = p.metronomeEnabled;
    }];
    if (_core && _core->ready()) _core->engine().setMetronomeEnabled(enabled);
}

- (std::int64_t)barStepFrom:(std::int64_t)sample direction:(int)dir {
    const auto& map = _core->project().tempoMap;
    const auto pos = map.positionAtSample(sample);
    const double barLen = pos.numerator * 4.0 / pos.denominator;
    double q = pos.barStartQuarterNotes;
    if (dir > 0) q += barLen;
    else if (map.sampleAtQuarterNotes(q) >= sample - 1) q = std::max(0.0, q - barLen);
    return map.sampleAtQuarterNotes(q);
}
- (void)rewindBar:(id)sender { (void)sender; if (_core && _core->ready()) [self seekToSample:[self barStepFrom:self.playheadSample direction:-1]]; }
- (void)forwardBar:(id)sender { (void)sender; if (_core && _core->ready()) [self seekToSample:[self barStepFrom:self.playheadSample direction:1]]; }
- (void)previousMarker:(id)sender {
    (void)sender;
    if (!_core) return;
    const auto* m = MarkerTools::previous(_core->project(), self.playheadSample - 1);
    [self seekToSample:m ? m->sample : 0];
}
- (void)nextMarker:(id)sender {
    (void)sender;
    if (!_core) return;
    if (const auto* m = MarkerTools::next(_core->project(), self.playheadSample)) [self seekToSample:m->sample];
}
- (void)addMarkerAtSample:(std::int64_t)sample {
    [self runEdit:@"Add Marker" rebuild:NO block:^{ (void)MarkerTools::add(self->_core->project(), "", sample); }];
}
- (void)addMarkerAtPlayhead:(id)sender { (void)sender; [self addMarkerAtSample:self.playheadSample]; }

- (void)gotoPositionDialog:(id)sender {
    (void)sender;
    if (!_core) return;
    NSString* s = [self promptText:@"Locate" message:@"Bar.Beat.Tick (e.g. 17.1.0)" initial:sv::ns(formatBarsBeats(_core->project().tempoMap, self.playheadSample))];
    if (!s) return;
    std::int64_t sample = 0;
    if (parseBarsBeats(_core->project().tempoMap, sv::str(s), sample)) [self seekToSample:sample];
    else [self showError:@"Locate" detail:"Could not read that position. Use bar.beat.tick, e.g. 9.3.240"];
}

- (void)editTempo:(id)sender {
    (void)sender;
    if (!_core) return;
    Project& p = _core->project();
    const std::int64_t pos = self.playheadSample;
    NSString* s = [self promptText:@"Tempo" message:(pos > 0 ? @"BPM from the current bar (a tempo change is inserted there)" : @"Project tempo in BPM")
                           initial:[NSString stringWithFormat:@"%.3f", p.tempoMap.tempoAtSample(pos)]];
    if (!s) return;
    const double bpm = s.doubleValue;
    if (!(bpm >= 20.0 && bpm <= 400.0)) { [self showError:@"Tempo" detail:"Tempo must be between 20 and 400 BPM"]; return; }
    [self runEdit:@"Tempo" rebuild:YES block:^{
        Project& pr = self->_core->project();
        const auto tp = pr.tempoMap.positionAtSample(pos);
        const std::int64_t bar = pr.tempoMap.sampleAtQuarterNotes(tp.barStartQuarterNotes);
        if (bar <= 0) pr.tempoMap.setInitialTempo(bpm); else pr.tempoMap.addTempoChange(bar, bpm);
        pr.tempo = pr.tempoMap.initialTempo();
    }];
}

- (void)editSignature:(id)sender {
    (void)sender;
    if (!_core) return;
    Project& p = _core->project();
    const std::int64_t pos = self.playheadSample;
    const auto tp = p.tempoMap.positionAtSample(pos);
    NSString* s = [self promptText:@"Time Signature" message:@"numerator/denominator, applied from the current bar"
                           initial:[NSString stringWithFormat:@"%u/%u", tp.numerator, tp.denominator]];
    if (!s) return;
    NSArray<NSString*>* parts = [s componentsSeparatedByString:@"/"];
    if (parts.count != 2) { [self showError:@"Time Signature" detail:"Use the form 3/4"]; return; }
    const int num = [parts[0] intValue], den = [parts[1] intValue];
    [self runEdit:@"Time Signature" rebuild:YES block:^{
        Project& pr = self->_core->project();
        const std::int64_t bar = pr.tempoMap.sampleAtQuarterNotes(pr.tempoMap.positionAtSample(pos).barStartQuarterNotes);
        if (bar <= 0) pr.tempoMap.setInitialTimeSignature(static_cast<std::uint16_t>(num), static_cast<std::uint16_t>(den));
        else pr.tempoMap.addTimeSignatureChange(bar, static_cast<std::uint16_t>(num), static_cast<std::uint16_t>(den));
    }];
}

- (void)toggleSnap:(id)sender { (void)sender; _snap = !_snap; [self setStatus:_snap ? @"Snap on" : @"Snap off"]; }
- (void)zoomIn:(id)sender {
    (void)sender;
    if ([self toneEditorActive]) { [_toneView zoomBy:0.6]; return; }
    if ([self sampleEditorActive]) { [_sampleView zoomBy:0.6]; return; }
    if ([self keyEditorActive]) { [_noteGrid zoomBy:0.7]; return; }
    [self setPixelsPerSecond:_pps * 1.35];
}
- (void)zoomOut:(id)sender {
    (void)sender;
    if ([self toneEditorActive]) { [_toneView zoomBy:1.0 / 0.6]; return; }
    if ([self sampleEditorActive]) { [_sampleView zoomBy:1.0 / 0.6]; return; }
    if ([self keyEditorActive]) { [_noteGrid zoomBy:1.0 / 0.7]; return; }
    [self setPixelsPerSecond:_pps / 1.35];
}
- (void)zoomToProject:(id)sender {
    (void)sender;
    if (!_core) return;
    if ([self toneEditorActive]) { [_toneView zoomFit]; return; }
    if ([self sampleEditorActive]) { [_sampleView zoomFit]; return; }
    if ([self keyEditorActive]) { [_noteGrid zoomFit]; return; }
    std::int64_t end = 1;
    for (const auto& t : _core->project().tracks)
        for (const auto& c : t.clips) end = std::max<std::int64_t>(end, c.timelineStartSample + static_cast<std::int64_t>(c.lengthSamples));
    const double seconds = std::max(4.0, end / std::max(1.0, _core->project().sampleRate));
    _arrange.scrollSeconds = 0;
    [self setPixelsPerSecond:(_arrange.bounds.size.width - 264 - 28) / seconds];
}

// ----------------------------------------------------------------- timer --
- (void)timerTick:(NSTimer*)timer {
    (void)timer;
    if (!_core) return;
    ++_tick;
    try {
        if (_core->ready() && _core->runtime().projectRebuildRequested() && !_core->recording() && !_gestureOpen)
            [SilvetonNativeEditor closeAll];   // instances are about to be replaced
        if (!_gestureOpen) _core->service();
        if (_core->ready()) {
            // A new routing graph just went live: it was built from the project, so hand it the current faders again.
            auto& engine = _core->engine();
            const std::uint64_t live = engine.liveProcessorGraphGeneration();
            if (live != _mixSyncGeneration && !engine.processorGraphPublicationPending() && engine.applyLiveMixerState(_core->project()))
                _mixSyncGeneration = live;
        }
        [self updateMeters];
        [self watchPlayStart];
        // Repaint only what moved: the arrange canvas is never repainted as a whole
        // on a tick (that was far too heavy for 8+ tracks on an older iMac).
        if (_page == SVPage::Arrange) {
            const BOOL playing = _core->ready() && _core->engine().transport().isPlaying();
            BOOL scrolled = NO;
            if (playing) scrolled = [_arrange ensurePlayheadVisible];
            if (scrolled || (_core->recording() && _tick % 8U == 0U)) [_arrange setNeedsDisplay:YES];
            else [_arrange tickAnimation];
            if ([self dockMixerShown]) [_dock tickMeters];
            if (_meterPanelVisible) [_meterPanel tick];
        } else if (_page == SVPage::Mix) {
            [_console tickMeters];   // repaints only the meter columns that visibly moved
        }
        if ([self editorShown]) {   // full page, or under the tracks
            if (![_sampleView isHidden]) [_sampleView tick];      // playhead, page-turn while playing, sample detail finishing in the background
            else if (![_toneView isHidden]) [_toneView tick];     // playhead, page-turn while playing, progress of the listening
            else if (![_noteGrid isHidden]) [_noteGrid tick];     // playhead and page-turn while playing
        }
        [_transport tick];
        if (_tick % 6U == 0U) {
            [SilvetonNativeEditor refreshAll];
            [_pageBar setNeedsDisplay:YES];   // the DSP figure
            if (_core->recording()) {
                [self setStatus:[NSString stringWithFormat:@"Recording audio — %.1f s",
                                 _core->recording()->status().framesAccepted / std::max(1.0, _core->project().sampleRate)]];
            } else if (_midiRecordTrack < 0 && _core->ready()) {
                const auto st = _core->runtime().status();
                if (!st.media.issues.empty()) {
                    // Say WHICH file and WHY, not only how many.
                    const auto& issue = st.media.issues.front();
                    NSString* file = [sv::ns(issue.path) lastPathComponent];
                    [self setStatus:[NSString stringWithFormat:@"%lu offline media item(s) — %@: %@", (unsigned long)st.media.issues.size(),
                                     file.length ? file : @"(no file)", sv::ns(issue.detail)]];
                }
            }
            [self updateTitle];
            (void)_core->session().serviceAutosave([NSProcessInfo processInfo].systemUptime);
        }
    } catch (const std::exception& e) {
        [self setStatus:sv::ns(e.what())];
    }
}

// ~0.6 s after Play was pressed: if the position has not moved, say so (and why, when we can tell)
// instead of leaving the user with a silent button.
- (void)watchPlayStart {
    if (_playWatchTick == 0U || !_core || !_core->ready()) return;
    const auto& transport = _core->engine().transport();
    if (!transport.isPlaying()) { _playWatchTick = 0U; return; }
    if (_tick - _playWatchTick < 20U) return;
    _playWatchTick = 0U;
    if (transport.positionSamples() != _playWatchPosition) return;
    const bool deviceCalling = _core->device().status().callbackCount != _playWatchCallbacks;
    [self setStatus:deviceCalling
        ? @"Play is on but the position is not moving — check the cycle range and the project length"
        : @"Play is on but the audio device is not answering — open Audio System Setup… and press Apply"];
    // Leave the facts on the Desktop, so the next zip can be built on them instead of on guesses.
    if ([self saveDiagnosticReport]) [self setStatus:[_pageBar.statusText stringByAppendingString:@"  (report saved on the Desktop: Silveton-report.txt)"]];
}

// Double-click on a field of the info line (field numbers as in SilvetonInfoLine).
- (void)infoFieldDoubleClicked:(NSInteger)field {
    if ([self arrangeRange].valid()) { if (field == 3 || field == 1 || field == 2) [self rangeZoom:nil]; return; }   // the range: its fields only zoom to it
    switch (field) {
        case 4: case 5: [self clipFades:nil]; break;              // fades
        case 6: [self clipGain:nil]; break;                       // gain
        case 7: [self toggleClipMute:nil]; break;                 // mute
        default: break;
    }
}

// Bare-key shortcuts (Space, R, L …) must not fire while typing in a field.
- (BOOL)validateMenuItem:(NSMenuItem*)item {
    if ([SVProgress isActive]) return NO;   // an export is running: nothing else may change the project
    NSResponder* fr = _window.firstResponder;
    if ([fr isKindOfClass:[NSText class]] && item.keyEquivalent.length > 0 &&
        (item.keyEquivalentModifierMask & (NSEventModifierFlagCommand | NSEventModifierFlagOption | NSEventModifierFlagControl)) == 0)
        return NO;
    const SEL a = item.action;
    if ([fr isKindOfClass:[NSText class]] && (a == @selector(cutClip:) || a == @selector(copyClip:) || a == @selector(pasteClip:) ||
                                               a == @selector(duplicateClip:) || a == @selector(sampleSelectAll:)))
        return NO;   // let the text field handle ⌘X/⌘C/⌘V/⌘A
    if (a == @selector(toggleSampleZeroSnap:)) item.state = _sampleZeroSnap ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(toggleSampleRipple:)) item.state = _sampleRipple ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(sampleSelectAll:)) return [self sampleEditorActive] || [self toneEditorActive] || [self keyEditorActive] || (![self editorFocused] && _core && (!_core->project().tracks.empty() || !_core->project().midiTracks.empty()));
    if (a == @selector(pickArrangeTool:)) { item.state = static_cast<NSInteger>(_arrangeTool) == item.tag ? NSControlStateValueOn : NSControlStateValueOff; return ![self editorFocused]; }
    if (a == @selector(rangeCut:) || a == @selector(rangeCopy:) || a == @selector(rangeDelete:) || a == @selector(rangeCutTime:) || a == @selector(rangeDeleteTime:) ||
        a == @selector(rangeInsertSilence:) || a == @selector(rangeSplit:) || a == @selector(rangeCrop:) || a == @selector(rangeSetCycle:) || a == @selector(rangeZoom:))
        return [self arrangeRangeActive];
    if (a == @selector(rangePaste:)) return ![self editorFocused] && [self rangeClipboardFull];
    if (a == @selector(toggleSampleZeroSnap:) || a == @selector(toggleSampleRipple:) || a == @selector(sampleZoomFit:))
        return [self sampleEditorActive];
    if (a == @selector(sampleZoomSelection:)) return [self keyEditorActive] || [self toneEditorActive] || ([self sampleEditorActive] && [self sampleSelection].valid());
    if (a == @selector(sampleCropToSelection:) || a == @selector(sampleLoopSelection:))
        return [self sampleEditorActive] && [self sampleSelection].valid();
    if (a == @selector(keyFitToScale:) || a == @selector(keySplitAtCursor:) || a == @selector(keyGlueSelected:) || a == @selector(keySelectSamePitch:) ||
        a == @selector(keySelectInvert:) || a == @selector(keySelectFromCursor:) || a == @selector(keyThinLane:) || a == @selector(keySelectNone:))
        return [self keyEditorShown];   // explicit Key Editor commands: enough that the grid is on screen
    if (a == @selector(toneUp:) || a == @selector(toneDown:) || a == @selector(toneOctaveUp:) || a == @selector(toneOctaveDown:) ||
        a == @selector(toneSnapFull:) || a == @selector(toneFlattenFull:) || a == @selector(toneQuantizeTiming:) || a == @selector(toneDetectScale:) ||
        a == @selector(toneSplitAtPlayhead:) || a == @selector(toneGlueSelected:) || a == @selector(toneBypassSelected:) || a == @selector(toneResetSelected:) ||
        a == @selector(toneDeleteSelected:) || a == @selector(toneExtractMidi:))
        return [self toneEditorShown];
    if (a == @selector(togglePlay:)) item.title = (_core && _core->ready() && _core->engine().transport().isPlaying()) ? @"Stop" : @"Play";
    if (a == @selector(toggleSnap:)) item.state = _snap ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(toggleChannelPanel:)) item.state = _channelPanelVisible ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(toggleDockMixer:)) item.state = [self dockMixerShown] ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(toggleEditorZone:)) item.state = [self editorZoneShown] ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(toggleLowerZone:)) item.state = _zoneVisible ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(toggleEditorPlace:)) item.title = _page == SVPage::Edit ? @"Editor Under the Tracks" : @"Editor in Full Page";
    if (a == @selector(toggleMeterPanel:)) item.state = _meterPanelVisible ? NSControlStateValueOn : NSControlStateValueOff;
    if (a == @selector(undo:)) return _core && _core->session().history().canUndo();
    if (a == @selector(redo:)) return _core && _core->session().history().canRedo();
    return YES;
}

@end

int main(int argc, const char* argv[]) {
    (void)argc; (void)argv;
    @autoreleasepool {
        NSApplication* app = [NSApplication sharedApplication];
        SilvetonController* delegate = [[SilvetonController alloc] init];
        app.delegate = delegate;
        [app run];
    }
    return 0;
}
