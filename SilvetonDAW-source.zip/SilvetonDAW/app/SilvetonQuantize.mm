// Silveton — Quantize Panel (Cubase-style Quantize Setup, Groove Quantize and
// Audio Quantize in one window) and the shared quantize state.
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>

#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include <algorithm>
#include <cmath>
#include <string>

using namespace silveton;

// ------------------------------------------------------------------ state --
static SVQuantizeState* gQuantizeState = nil;

@implementation SVQuantizeState
+ (instancetype)shared {
    if (!gQuantizeState) gQuantizeState = [[SVQuantizeState alloc] init];
    return gQuantizeState;
}
- (instancetype)init {
    if ((self = [super init])) {
        grooveTiming = 1.0;
        grooveVelocity = 0.0;
    }
    return self;
}
@end

// ------------------------------------------------------------------ panel --
namespace {
enum Tag { kSwing = 1, kStrength, kMagnet, kNonQ, kRandom, kAudioSens, kAudioStrength, kGrooveTiming, kGrooveVel };

NSTextField* lbl(NSView* p, NSString* s, NSRect f, NSFont* font, NSColor* c, NSTextAlignment a = NSTextAlignmentLeft) {
    NSTextField* t = [NSTextField labelWithString:s ?: @""];
    t.frame = f; t.font = font; t.textColor = c; t.alignment = a;
    [p addSubview:t];
    return t;
}
NSPopUpButton* pop(NSView* p, NSRect f, NSArray<NSString*>* items) {
    NSPopUpButton* b = [[NSPopUpButton alloc] initWithFrame:f pullsDown:NO];
    b.font = sv::ui(11);
    [b addItemsWithTitles:items];
    [p addSubview:b];
    return b;
}
NSButton* check(NSView* p, NSString* title, NSRect f, BOOL on) {
    NSButton* b = [[NSButton alloc] initWithFrame:f];
    [b setButtonType:NSButtonTypeSwitch];
    b.title = title;
    b.state = on ? NSControlStateValueOn : NSControlStateValueOff;
    [p addSubview:b];
    return b;
}
void section(NSView* p, NSString* s, CGFloat y, CGFloat w) {
    SVFlipView* rule = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, y, w, 1)];
    rule.fillColor = sv::hairline();
    [p addSubview:rule];
    lbl(p, s, NSMakeRect(14, y + 6, w - 28, 16), sv::ui(10, true), sv::copper());
}
const double kGridQuarters[7] = {4.0, 2.0, 1.0, 0.5, 0.25, 0.125, 0.0625};
constexpr double kTicksPerQuarter = 480.0;
}

@interface SVQuantizePanel : NSObject <NSWindowDelegate>
@property(nonatomic, weak) SilvetonController* owner;
@property(nonatomic, strong) NSWindow* window;
@property(nonatomic, strong) NSPopUpButton* gridPopup;
@property(nonatomic, strong) NSPopUpButton* typePopup;
@property(nonatomic, strong) NSPopUpButton* groovePopup;
@property(nonatomic, strong) NSButton* startCheck;
@property(nonatomic, strong) NSButton* endCheck;
@property(nonatomic, strong) NSButton* lengthCheck;
@property(nonatomic, strong) NSTextField* fadeField;
@property(nonatomic, strong) NSMutableDictionary<NSNumber*, NSTextField*>* valueLabels;
+ (instancetype)shared;
- (void)show;
@end

static SVQuantizePanel* gQuantizePanel = nil;

@implementation SVQuantizePanel {
    std::vector<GrooveTemplate> _builtIn;
    GrooveTemplate _extracted;
    BOOL _haveExtracted;
}
+ (instancetype)shared {
    if (!gQuantizePanel) gQuantizePanel = [[SVQuantizePanel alloc] init];
    return gQuantizePanel;
}

- (NSSlider*)slider:(NSView*)root tag:(Tag)tag y:(CGFloat)y title:(NSString*)title min:(double)lo max:(double)hi value:(double)v {
    lbl(root, title, NSMakeRect(14, y + 2, 150, 16), sv::ui(11), sv::inkDim());
    NSSlider* s = [[NSSlider alloc] initWithFrame:NSMakeRect(168, y, 190, 20)];
    s.minValue = lo; s.maxValue = hi; s.doubleValue = v; s.tag = tag;
    s.target = self; s.action = @selector(sliderMoved:);
    s.continuous = YES;
    [root addSubview:s];
    NSTextField* val = lbl(root, @"", NSMakeRect(364, y + 2, 62, 16), sv::mono(11), sv::ink(), NSTextAlignmentRight);
    self.valueLabels[@(tag)] = val;
    [self updateLabel:tag value:v];
    return s;
}

- (void)updateLabel:(Tag)tag value:(double)v {
    NSTextField* t = self.valueLabels[@(tag)];
    if (!t) return;
    switch (tag) {
        case kNonQ:
        case kRandom: t.stringValue = [NSString stringWithFormat:@"%.0f tk", v]; break;
        default: t.stringValue = [NSString stringWithFormat:@"%.0f %%", v]; break;
    }
}

- (void)show {
    SVQuantizeState* st = SVQuantizeState.shared;
    if (!self.window) {
        self.valueLabels = [NSMutableDictionary dictionary];
        _builtIn = Quantizer::builtInGrooves();
        const CGFloat W = 440, H = 616;
        self.window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, W, H)
                                                  styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable
                                                    backing:NSBackingStoreBuffered defer:NO];
        self.window.title = @"Quantize Panel";
        self.window.delegate = self;
        self.window.releasedWhenClosed = NO;
        self.window.level = NSFloatingWindowLevel;
        if (@available(macOS 10.14, *)) self.window.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
        else self.window.appearance = [NSAppearance appearanceNamed:@"NSAppearanceNameVibrantDark"];
        SVFlipView* root = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, W, H)];
        root.fillColor = sv::canvas();
        self.window.contentView = root;

        // ---- MIDI quantize setup
        section(root, @"MIDI · QUANTIZE SETUP", 0, W);
        lbl(root, @"Grid", NSMakeRect(14, 34, 60, 16), sv::ui(11), sv::inkDim());
        self.gridPopup = pop(root, NSMakeRect(60, 30, 90, 22), @[@"1/1", @"1/2", @"1/4", @"1/8", @"1/16", @"1/32", @"1/64"]);
        self.gridPopup.target = self; self.gridPopup.action = @selector(gridPicked:);
        lbl(root, @"Type", NSMakeRect(170, 34, 40, 16), sv::ui(11), sv::inkDim());
        self.typePopup = pop(root, NSMakeRect(210, 30, 120, 22), @[@"Straight", @"Triplet", @"Dotted"]);
        self.typePopup.target = self; self.typePopup.action = @selector(typePicked:);
        [self slider:root tag:kSwing y:62 title:@"Swing" min:0 max:100 value:st->settings.swing * 100.0];
        [self slider:root tag:kStrength y:88 title:@"Iterative strength" min:0 max:100 value:st->settings.strength * 100.0];
        [self slider:root tag:kMagnet y:114 title:@"Magnetic area" min:0 max:100 value:st->settings.magneticArea * 100.0];
        [self slider:root tag:kNonQ y:140 title:@"Non-quantize" min:0 max:120 value:st->settings.nonQuantizeQuarterNotes * kTicksPerQuarter];
        [self slider:root tag:kRandom y:166 title:@"Random" min:0 max:120 value:st->settings.randomQuarterNotes * kTicksPerQuarter];
        self.startCheck = check(root, @"Quantize note start", NSMakeRect(14, 196, 170, 18), st->settings.quantizeStart);
        self.endCheck = check(root, @"Quantize note end", NSMakeRect(190, 196, 160, 18), st->settings.quantizeEnd);
        self.lengthCheck = check(root, @"Quantize length", NSMakeRect(14, 218, 170, 18), st->settings.quantizeLength);
        for (NSButton* b in @[self.startCheck, self.endCheck, self.lengthCheck]) { b.target = self; b.action = @selector(checksChanged:); }
        [root addSubview:[SVButton buttonWithTitle:@"Apply Quantize  (Q)" target:self.owner action:@selector(midiQuantize:) frame:NSMakeRect(14, 246, 200, 24)]];
        [root addSubview:[SVButton buttonWithTitle:@"Quantize Length" target:self.owner action:@selector(midiQuantizeLength:) frame:NSMakeRect(222, 246, 204, 24)]];

        // ---- Groove
        section(root, @"MIDI · GROOVE QUANTIZE", 284, W);
        NSMutableArray<NSString*>* names = [NSMutableArray arrayWithObject:@"(none)"];
        for (const auto& g : _builtIn) [names addObject:sv::ns(g.name)];
        lbl(root, @"Groove", NSMakeRect(14, 318, 60, 16), sv::ui(11), sv::inkDim());
        self.groovePopup = pop(root, NSMakeRect(80, 314, 250, 22), names);
        self.groovePopup.target = self; self.groovePopup.action = @selector(groovePicked:);
        [self slider:root tag:kGrooveTiming y:344 title:@"Timing" min:0 max:100 value:st->grooveTiming * 100.0];
        [self slider:root tag:kGrooveVel y:370 title:@"Velocity" min:0 max:100 value:st->grooveVelocity * 100.0];
        [root addSubview:[SVButton buttonWithTitle:@"Extract from Part" target:self action:@selector(extractClicked:) frame:NSMakeRect(14, 400, 200, 24)]];
        [root addSubview:[SVButton buttonWithTitle:@"Apply Groove" target:self.owner action:@selector(midiGrooveApply:) frame:NSMakeRect(222, 400, 204, 24)]];

        // ---- Audio
        section(root, @"AUDIO · QUANTIZE CLIP", 442, W);
        [self slider:root tag:kAudioSens y:474 title:@"Transient sensitivity" min:0 max:100 value:st->audio.sensitivity * 100.0];
        [self slider:root tag:kAudioStrength y:500 title:@"Strength" min:0 max:100 value:st->audio.strength * 100.0];
        lbl(root, @"Slice fade (ms)", NSMakeRect(14, 530, 150, 16), sv::ui(11), sv::inkDim());
        self.fadeField = [[NSTextField alloc] initWithFrame:NSMakeRect(168, 526, 60, 22)];
        self.fadeField.font = sv::ui(11);
        self.fadeField.stringValue = [NSString stringWithFormat:@"%.1f", st->audio.fadeMilliseconds];
        self.fadeField.target = self; self.fadeField.action = @selector(fadeChanged:);
        [root addSubview:self.fadeField];
        [root addSubview:[SVButton buttonWithTitle:@"Quantize Audio Clip" target:self.owner action:@selector(audioQuantize:) frame:NSMakeRect(14, 562, 412, 26)]];
        lbl(root, @"Uses the grid, type and swing above. Select a clip first.", NSMakeRect(14, 592, 412, 14), sv::ui(10), sv::inkFaint());
        [self.window center];
    }
    // Reflect the current state.
    const double g = st->settings.gridQuarterNotes;
    NSInteger gi = 4;
    for (NSInteger i = 0; i < 7; ++i) if (std::abs(kGridQuarters[i] - g) < 1e-9) gi = i;
    [self.gridPopup selectItemAtIndex:gi];
    [self.typePopup selectItemAtIndex:static_cast<NSInteger>(st->settings.type)];
    [self.window makeKeyAndOrderFront:nil];
}

- (void)gridPicked:(NSPopUpButton*)p {
    SVQuantizeState.shared->settings.gridQuarterNotes = kGridQuarters[std::clamp<NSInteger>(p.indexOfSelectedItem, 0, 6)];
}
- (void)typePicked:(NSPopUpButton*)p {
    SVQuantizeState.shared->settings.type = static_cast<QuantizeGridType>(std::clamp<NSInteger>(p.indexOfSelectedItem, 0, 2));
}
- (void)checksChanged:(id)sender {
    (void)sender;
    auto& s = SVQuantizeState.shared->settings;
    s.quantizeStart = self.startCheck.state == NSControlStateValueOn;
    s.quantizeEnd = self.endCheck.state == NSControlStateValueOn;
    s.quantizeLength = self.lengthCheck.state == NSControlStateValueOn;
}
- (void)sliderMoved:(NSSlider*)sl {
    SVQuantizeState* st = SVQuantizeState.shared;
    const double v = sl.doubleValue;
    switch (static_cast<Tag>(sl.tag)) {
        case kSwing: st->settings.swing = v / 100.0; break;
        case kStrength: st->settings.strength = v / 100.0; break;
        case kMagnet: st->settings.magneticArea = v / 100.0; break;
        case kNonQ: st->settings.nonQuantizeQuarterNotes = v / kTicksPerQuarter; break;
        case kRandom: st->settings.randomQuarterNotes = v / kTicksPerQuarter; break;
        case kAudioSens: st->audio.sensitivity = v / 100.0; break;
        case kAudioStrength: st->audio.strength = v / 100.0; break;
        case kGrooveTiming: st->grooveTiming = v / 100.0; break;
        case kGrooveVel: st->grooveVelocity = v / 100.0; break;
    }
    [self updateLabel:static_cast<Tag>(sl.tag) value:v];
}
- (void)fadeChanged:(NSTextField*)f {
    SVQuantizeState.shared->audio.fadeMilliseconds = std::clamp(f.doubleValue, 0.0, 50.0);
}
- (void)groovePicked:(NSPopUpButton*)p {
    SVQuantizeState* st = SVQuantizeState.shared;
    const NSInteger i = p.indexOfSelectedItem;
    if (i <= 0) { st->groove = GrooveTemplate {}; return; }
    const auto idx = static_cast<std::size_t>(i - 1);
    if (idx < _builtIn.size()) st->groove = _builtIn[idx];
    else if (_haveExtracted) st->groove = _extracted;
}
- (void)extractClicked:(id)sender {
    (void)sender;
    SilvetonController* c = self.owner;
    if (!c) return;
    SVQuantizeState* st = SVQuantizeState.shared;
    st->groove = GrooveTemplate {};
    [c midiGrooveExtract:nil];
    if (st->groove.offsetQuarterNotes.empty()) return;
    _extracted = st->groove;
    if (!_haveExtracted) { [self.groovePopup addItemWithTitle:@"Extracted groove"]; _haveExtracted = YES; }
    [self.groovePopup selectItemAtIndex:self.groovePopup.numberOfItems - 1];
}
@end

@implementation SilvetonController (Quantize)
- (void)showQuantizePanel:(id)sender {
    (void)sender;
    SVQuantizePanel* p = [SVQuantizePanel shared];
    p.owner = self;
    [p show];
}
@end
