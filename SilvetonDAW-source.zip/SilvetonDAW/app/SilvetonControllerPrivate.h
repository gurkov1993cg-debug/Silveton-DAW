// Private controller state shared by SilvetonApp.mm, SilvetonActions.mm and
// SilvetonPanels.mm (class extension + categories).
#pragma once
#import "SilvetonViews.h"

#include "silveton/AudioProcessing.h"
#include "silveton/AudioRangeEdit.h"
#include "silveton/MidiFile.h"
#include "silveton/Quantize.h"
#include "silveton/Vst3PluginCatalog.h"
#include "silveton/Vst3PresetLibrary.h"

#include "SilvetonKeyState.h"
#include "SilvetonToneState.h"
#include "silveton/MidiTimeline.h"

#include <memory>
#include <string>
#include <vector>

// ---------------------------------------------------------------- controls --
@interface SVFlipView : NSView
@property(nonatomic, strong) NSColor* fillColor;
@property(nonatomic, assign) BOOL rail;              // draws as a soft metal rail instead of a flat colour
@property(nonatomic, copy) void (^onLayout)(void);   // runs whenever the view changes size (children placed by hand)
@end

// One piece of a copied range of the Project window: a clip or a MIDI part cut to the range, with the track it
// came from. Clip positions are relative to the start of the range; part positions are absolute quarter notes.
struct SVRangePiece {
    silveton::ArrangeRowKind kind {silveton::ArrangeRowKind::Audio};
    std::size_t track {0U};
    silveton::ProjectAudioClip clip;
    silveton::MidiPart part;
};

@class SVSectionStack;
// The title bar of one inspector section; a click folds the section or opens it again.
@interface SVSectionHeader : NSView
@property(nonatomic, copy) NSString* title;
@property(nonatomic, assign) BOOL collapsed;
@property(nonatomic, weak) SVSectionStack* stack;
@end

// An inspector panel built from sections (as the Inspector of Cubase): the builder places everything at fixed
// places as before and only makes the section bars with sectionHeader(); finishSections then remembers where
// everything is, and folding a section hides its controls and moves what is below it up.
@interface SVSectionStack : SVFlipView
- (void)registerSection:(SVSectionHeader*)header;
- (void)finishSections;
- (void)foldSectionsNamed:(NSArray<NSString*>*)titles;   // folded until the user opens them
- (void)toggleSection:(SVSectionHeader*)header;
- (void)relayout;   // sets the frame height and, when shown, the height of the scroll document around it
@end
SVSectionHeader* sectionHeader(NSView* parent, NSString* title, CGFloat y, CGFloat w);

// Shared Quantize Setup (used by the Q key, the menus and the Quantize Panel).
@interface SVQuantizeState : NSObject {
@public
    silveton::QuantizeSettings settings;
    silveton::AudioQuantizeOptions audio;
    silveton::GrooveTemplate groove;
    double grooveTiming;
    double grooveVelocity;
}
+ (instancetype)shared;
@end

// Left-hand panels (Inspector, Edit tools) are 248 px of content plus the 15 px a
// classic always-visible scroller takes, so the scroller never covers a control.
constexpr CGFloat kPanelContentW = 248.0;
constexpr CGFloat kPanelScrollerW = 15.0;
constexpr CGFloat kInspectorPanelW = kPanelContentW + kPanelScrollerW;

@interface SVButton : NSButton
@property(nonatomic, assign) BOOL accent;
+ (instancetype)buttonWithTitle:(NSString*)title target:(id)target action:(SEL)action frame:(NSRect)frame;
@end

@interface SVToggle : NSButton
@property(nonatomic, strong) NSColor* onColor;
+ (instancetype)toggleWithTitle:(NSString*)title color:(NSColor*)color target:(id)target action:(SEL)action frame:(NSRect)frame;
@end

@interface SVResetSlider : NSSlider
@property(nonatomic, assign) double resetValue;
@property(nonatomic, assign) SEL beginAction;
@property(nonatomic, assign) SEL endAction;
@end

// A Silveton dialog: dark window with a header, rows of labelled controls (slider + number + quick
// values, choice, tick box, text), a live note and Cancel / OK. Used for every question the program asks.
@class SVDialog;
typedef NSString* (^SVDialogNote)(SVDialog* dialog);
@interface SVDialog : NSObject <NSWindowDelegate>
+ (instancetype)dialogWithTitle:(NSString*)title subtitle:(NSString*)subtitle okTitle:(NSString*)okTitle;
- (NSInteger)addNumber:(NSString*)label unit:(NSString*)unit min:(double)min max:(double)max value:(double)value
              decimals:(int)decimals presets:(NSArray<NSNumber*>*)presets;
- (NSInteger)addChoice:(NSString*)label items:(NSArray<NSString*>*)items selected:(NSInteger)selected;
- (NSInteger)addCheck:(NSString*)label on:(BOOL)on;
- (NSInteger)addText:(NSString*)label value:(NSString*)value;
- (void)setNote:(SVDialogNote)note;   // text under the controls, recomputed after every change
- (BOOL)run;                                    // modal; YES when OK was pressed
- (double)numberAt:(NSInteger)row;
- (NSInteger)choiceAt:(NSInteger)row;
- (BOOL)checkAt:(NSInteger)row;
- (NSString*)textAt:(NSInteger)row;
@end

// Progress window for long jobs (exports): bar, percent, time used, time left and Cancel. The job runs
// on the main thread, so every updateFraction: also lets the window redraw and react to Cancel.
@interface SVProgress : NSObject <NSWindowDelegate>
+ (instancetype)progressWithTitle:(NSString*)title;
+ (BOOL)isActive;                         // YES while a progress window is open (menus are off then)
@property(nonatomic, assign) NSInteger parts;   // > 1: the status line says "Part x of n"
@property(nonatomic, copy) NSString* partNoun;  // "Stem", "File" ...
- (void)begin;
- (BOOL)updateFraction:(double)fraction;  // NO = the user pressed Cancel, stop now
- (void)end;
@end

struct SVPluginEntry {
    bool native {false};
    bool instrument {false};
    std::string modulePath;
    std::string classId;
    std::string name;
    std::string vendor;
};

@interface SilvetonController () <NSTableViewDataSource, NSTableViewDelegate, NSSearchFieldDelegate, NSWindowDelegate, NSTextFieldDelegate, NSMenuDelegate> {
@public
    std::unique_ptr<sv::AppRuntime> _core;
    std::unique_ptr<silveton::Vst3PluginBrowserService> _browser;
    silveton::Vst3PresetLibrary _presets;
    std::string _supportDir;
    std::string _presetDir;
    NSTimer* _timer;
    NSWindow* _window;
    NSView* _root;
    SilvetonSideBar* _sideBar;
    SilvetonPageBar* _pageBar;
    SilvetonTransportDeck* _transport;
    NSView* _arrangePage;
    NSView* _mixPage;
    NSView* _editPage;
    NSView* _libraryPage;
    SilvetonArrangeView* _arrange;
    SilvetonToolBar* _toolBar;
    SilvetonConsoleView* _dock;      // compact mixer under the tracks
    SilvetonMeterPanel* _meterPanel;
    // Lower zone under the tracks
    SilvetonZoneBar* _zoneBar;           // tab strip along its bottom edge
    SilvetonZoneSplitter* _zoneSplitter; // thin bar above it, dragged for the height
    SilvetonInfoLine* _infoLine;         // under the tool row
    // Inspector column: TRACK / EDITOR tabs over two scroll views (the track panels, the editor's panels)
    SilvetonInspectorTabs* _inspectorTabs;
    NSScrollView* _editorScroll;
    int _inspectorTab;                   // 0 = TRACK, 1 = EDITOR
    BOOL _zoneVisible;
    int _zoneTab;                    // 0 = mixer, 1 = editor
    CGFloat _zoneH;                  // its height, dragged at the bar
    BOOL _editorArmed;               // the last click was in the editor, so Delete / Cut / Copy … go there and not to the tracks
    NSView* _editorRoot;             // the whole editor (tools, strip, content): on the Edit page or under the tracks
    id _clickMonitor;
    SVButton* _editPlaceButton;      // FULL PAGE / IN PROJECT
    BOOL _meterPanelVisible;
    NSScrollView* _channelScroll;
    SVSectionStack* _audioPanel;
    SVSectionStack* _midiPanel;
    BOOL _channelPanelVisible;
    SilvetonConsoleView* _console;
    SilvetonNoteGridView* _noteGrid;
    SilvetonSampleView* _sampleView;
    SVSectionStack* _midiTools;
    SVSectionStack* _audioTools;
    // Tone Editor
    SilvetonToneView* _toneView;
    SVSectionStack* _toneTools;
    SVToggle* _toneModeWave;
    SVToggle* _toneModeTone;
    BOOL _toneMode;
    SVToneTool _toneTool;
    std::shared_ptr<SVToneSession> _tone;
    SVToggle* _toneToolButtons[6];
    NSSlider* _toneSliders[SVToneParamCount];
    NSTextField* _toneValues[SVToneParamCount];
    NSTextField* _toneStatus;
    NSTextField* _toneBlockInfo;
    NSPopUpButton* _toneScalePop;
    NSPopUpButton* _toneRootPop;
    SVToggle* _toneScaleOn;
    SVToggle* _toneBend;
    SVToggle* _toneUseCorrected;
    SVToggle* _toneShowOriginal;
    SVToggle* _toneShowCorrected;
    SVToggle* _toneShowWave;
    SVToggle* _toneShowScale;
    // Key Editor
    SVKeyState _key;
    SVToggle* _keyToolButtons[7];
    NSPopUpButton* _keyInsertPop;
    NSPopUpButton* _keyChordPop;
    NSPopUpButton* _keyScalePop;
    NSPopUpButton* _keyRootPop;
    NSPopUpButton* _keyShapePop;
    NSPopUpButton* _keyPeriodPop;
    SVToggle* _keyListen;
    SVToggle* _keyFollow;
    SVToggle* _keyScaleRows;
    SVToggle* _keyScaleSnap;
    NSSlider* _keyVelSlider;
    NSTextField* _keyVelValue;
    NSTextField* _keyHint;
    NSTextField* _editTitle;
    NSPopUpButton* _gridPopup;

    // Library page
    NSSearchField* _pluginSearch;
    NSTableView* _pluginTable;
    NSTableView* _poolTable;
    NSTableView* _markerTable;
    NSTableView* _sectionTable;
    NSTableView* _chainTable;

    // Channel panel (audio)
    NSTextField* _cpName;
    NSTextField* _cpType;
    NSPopUpButton* _cpColor;
    NSPopUpButton* _cpAutomation;
    NSPopUpButton* _cpOutput;
    SVResetSlider* _cpVolume;
    SVResetSlider* _cpPan;
    NSTextField* _cpVolumeValue;
    NSTextField* _cpPanValue;
    SVToggle* _cpMute;
    SVToggle* _cpSolo;
    SVToggle* _cpArm;
    SVToggle* _cpMonitor;
    SVToggle* _cpLock;
    NSTableView* _insertTable;
    NSTableView* _sendTable;
    SVToggle* _sendPre;
    SVResetSlider* _sendLevel;
    NSTextField* _sendLevelValue;
    NSTextField* _cpNotes;
    // Channel panel (MIDI)
    NSTextField* _mpName;
    NSPopUpButton* _mpColor;
    NSPopUpButton* _mpOutput;
    NSTextField* _mpTranspose;
    NSTextField* _mpVelocity;
    SVToggle* _mpMute;
    SVToggle* _mpSolo;

    // State
    SVPage _page;
    double _pps;
    BOOL _snap;
    std::uint32_t _gridDiv;
    SVStrip _strip;
    std::size_t _insertSlotCount;
    long _insertRow;
    long _sendRow;
    std::vector<SVPluginEntry> _pluginResults;
    std::vector<std::string> _pool;
    BOOL _updating;
    BOOL _scannerBusy;
    BOOL _gestureNeedsRebuild;
    BOOL _gestureOpen;
    silveton::AutomationWriter _gainWriter;
    silveton::AutomationWriter _panWriter;
    silveton::ProjectAudioClip _clipboard;
    BOOL _clipboardValid;
    long _midiRecordTrack;
    std::int64_t _midiRecordStart;
    SVStrip _menuStrip;
    silveton::ArrangeRow _menuRow;
    std::int64_t _menuSample;
    std::uint64_t _menuMarker;
    std::uint64_t _menuSection;
    unsigned _tick;
    silveton::MeterBank _meters;
    double _meterClock;
    // Play watchdog: after Play is pressed, the UI checks that the position really moves.
    unsigned _playWatchTick;
    std::int64_t _playWatchPosition;
    std::uint64_t _playWatchCallbacks;
    NSMutableArray<NSString*>* _statusLog;   // the last status-line messages, for the diagnostic report
    // Routing-graph generation the live faders were last handed to (see timerTick:).
    std::uint64_t _mixSyncGeneration;
    // Sample editor: the selected part of the sound, the audio last copied from it, and the two modes.
    silveton::TimelineRange _sampleSel;
    silveton::RangeClipboard _rangeClipboard;
    BOOL _sampleZeroSnap;
    BOOL _sampleRipple;
    // Project window: the tool in use and the last copied range (see SilvetonRangeActions.mm).
    SVArrangeTool _arrangeTool;
    std::vector<SVRangePiece> _rangeClip;
    std::int64_t _rangeClipLength;
    double _rangeClipQ0;              // quarter note of the start of the copied range
}
// Shared helpers (implemented across the category files)
- (void)runEdit:(NSString*)label rebuild:(BOOL)rebuild block:(void (^)(void))block;
- (void)showError:(NSString*)title detail:(const std::string&)detail;
- (NSString*)promptText:(NSString*)title message:(NSString*)message initial:(NSString*)initial;
- (void)requestRebuild;
- (void)refreshChannelPanel;
- (void)refreshLibrary;
- (void)refreshEditPage;
- (BOOL)editorShown;             // the editor is on screen (full page, or under the tracks)
- (BOOL)editorFocused;           // … and commands belong to it (full page, or the last click was in it)
- (void)showEditorInZone;        // opens the editor under the tracks (stays on the full page if that is open)
- (void)focusEditor;
- (void)placeEditorIn:(NSView*)parent frame:(NSRect)frame;
- (void)placeInspectorIn:(NSView*)parent frame:(NSRect)frame;   // tabs + the visible scroll view
- (void)clipGain:(id)sender;
- (void)clipFades:(id)sender;
- (void)toggleClipMute:(id)sender;
- (void)renameSelected:(id)sender;
- (void)layoutEditPage;
- (void)layoutEditorStrip;
- (void)layoutArrangePage;
- (void)noteClick:(NSEvent*)event;
- (NSString*)diagnosticReport;             // everything about the audio device, the engine and the media, as text
- (NSString*)saveDiagnosticReport;         // writes it to the Desktop; returns the path
- (void)saveDiagnosticReportAction:(id)sender;
- (void)buildChannelPanelIn:(NSRect)frame;
- (void)buildLibraryPage:(NSView*)page;
- (void)buildEditPage:(NSView*)page;
- (void)buildMenus;
- (NSMenu*)paletteMenuWithAction:(SEL)action;
- (std::vector<silveton::ProjectPluginSlot>*)slotsForStrip:(SVStrip)strip;
- (silveton::IVst3PluginInstance*)instanceForStrip:(SVStrip)strip slot:(std::size_t)slot;
- (silveton::NativePlugin*)nativeInstanceForStrip:(SVStrip)strip slot:(std::size_t)slot;
- (void)openInsertEditor:(SVStrip)strip slot:(std::size_t)slot;
- (NSString*)stripName:(SVStrip)strip;
- (void)insertPluginEntry:(const SVPluginEntry&)entry intoStrip:(SVStrip)strip;
- (void)reloadPluginResults;
- (void)addInstrumentTrackWith:(const SVPluginEntry&)entry;
- (void)stopMidiRecording;
- (void)updateInputMonitoring;
// Menu/document actions implemented in SilvetonActions.mm
- (void)saveProject:(id)sender;
- (void)undo:(id)sender;
- (void)redo:(id)sender;
- (void)updateTitle;
// Quantize family (SilvetonActions.mm applies, SilvetonQuantize.mm shows the panel)
- (void)showQuantizePanel:(id)sender;
- (void)midiQuantizeSetup:(id)sender;
- (void)midiQuantizeLength:(id)sender;
- (void)midiGrooveApply:(id)sender;
- (void)midiGrooveExtract:(id)sender;
- (void)audioQuantize:(id)sender;
// Tone Editor (SilvetonToneActions.mm)
- (void)buildToneToolsIn:(SVFlipView*)view width:(CGFloat)width;
- (void)toneSync;                                // called by the Editor page: opens / follows the clip
- (BOOL)toneAbsorbUndo;                          // YES when Undo only threw away a change that was not rendered yet
- (void)toneSetModeFromButton:(id)sender;
- (void)openToneEditor:(id)sender;
- (void)nudgeSelectionBy:(int)direction;
- (void)nudgeLeft:(id)sender;
- (void)nudgeRight:(id)sender;
- (void)toneExtractMidi:(id)sender;
// Key Editor (SilvetonKeyActions.mm)
- (void)buildKeyToolsIn:(SVFlipView*)view width:(CGFloat)width;
- (CGFloat)keyToolsHeight;
- (void)keyCopy;
- (void)keyCut;
- (void)keyPaste;
- (void)keyDuplicate;
- (void)keyDelete;
- (void)keySelectAllNotes;
- (void)keyMuteNotes:(id)sender;
- (void)keySplitAtCursor:(id)sender;
- (void)keyGlueSelected:(id)sender;
- (void)keyFitToScale:(id)sender;
- (void)keySelectInvert:(id)sender;
- (void)keySelectSamePitch:(id)sender;
- (void)keySelectFromCursor:(id)sender;
- (void)keySelectNone:(id)sender;
- (void)keyThinLane:(id)sender;
- (void)keyClearLane:(id)sender;
// Range selection of the Project window (SilvetonRangeActions.mm)
- (void)rangeCut:(id)sender;            // to the clipboard, leaves a gap
- (void)rangeCopy:(id)sender;
- (void)rangePaste:(id)sender;          // at the cursor, on the selected track
- (void)rangeDelete:(id)sender;         // leaves a gap
- (void)rangeCutTime:(id)sender;        // to the clipboard, later events move left
- (void)rangeDeleteTime:(id)sender;     // later events move left
- (void)rangeInsertSilence:(id)sender;  // later events move right
- (void)rangeSplit:(id)sender;          // splits at both edges of the range
- (void)rangeCrop:(id)sender;           // keeps only the range
- (void)rangeSetCycle:(id)sender;       // the cycle (locators) = the range
- (void)rangeZoom:(id)sender;
- (void)rangeSelectAll;                 // a range over the whole project on every track
- (BOOL)rangeClipboardFull;
// Sample editor operations (SilvetonSampleActions.mm)
- (void)sampleCopy:(id)sender;
- (void)sampleCut:(id)sender;
- (void)samplePaste:(id)sender;
- (void)sampleDelete:(id)sender;
- (void)sampleDuplicate:(id)sender;
- (BOOL)runRangeProcess:(silveton::AudioProcess)process options:(silveton::AudioProcessOptions)options;   // YES when handled
// What an audio process would work on right now: the selected part in the sample editor, otherwise the whole clip.
- (NSString*)sampleDurationText:(std::int64_t)samples;
- (std::int64_t)processScopeSamples;
- (NSString*)processScopeText;
- (BOOL)requireProcessTarget:(NSString*)title;   // NO (with a message) when no audio clip is open
@end
