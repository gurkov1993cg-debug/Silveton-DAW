// Private controller state shared by SilvetonApp.mm, SilvetonActions.mm and
// SilvetonPanels.mm (class extension + categories).
#pragma once
#import "SilvetonViews.h"

#include "silveton/AudioProcessing.h"
#include "silveton/MidiFile.h"
#include "silveton/Quantize.h"
#include "silveton/Vst3PluginCatalog.h"
#include "silveton/Vst3PresetLibrary.h"

#include <memory>
#include <string>
#include <vector>

// ---------------------------------------------------------------- controls --
@interface SVFlipView : NSView
@property(nonatomic, strong) NSColor* fillColor;
@end

// Shared Quantize Setup (used by the Q key, the menus and the Quantize Panel).
@interface SVQuantizeState : NSObject {
@public
    silveton::QuantizeSettings settings;
    silveton::AudioQuantizeOptions audio;
    silveton::GrooveTemplate groove;
    double grooveTiming;
    double grooveVelocity;
}
+ (instancetype)shared;
@end

// Left-hand panels (Inspector, Edit tools) are 248 px of content plus the 15 px a
// classic always-visible scroller takes, so the scroller never covers a control.
constexpr CGFloat kPanelContentW = 248.0;
constexpr CGFloat kPanelScrollerW = 15.0;
constexpr CGFloat kInspectorPanelW = kPanelContentW + kPanelScrollerW;

@interface SVButton : NSButton
@property(nonatomic, assign) BOOL accent;
+ (instancetype)buttonWithTitle:(NSString*)title target:(id)target action:(SEL)action frame:(NSRect)frame;
@end

@interface SVToggle : NSButton
@property(nonatomic, strong) NSColor* onColor;
+ (instancetype)toggleWithTitle:(NSString*)title color:(NSColor*)color target:(id)target action:(SEL)action frame:(NSRect)frame;
@end

@interface SVResetSlider : NSSlider
@property(nonatomic, assign) double resetValue;
@property(nonatomic, assign) SEL beginAction;
@property(nonatomic, assign) SEL endAction;
@end

struct SVPluginEntry {
    bool native {false};
    bool instrument {false};
    std::string modulePath;
    std::string classId;
    std::string name;
    std::string vendor;
};

@interface SilvetonController () <NSTableViewDataSource, NSTableViewDelegate, NSSearchFieldDelegate, NSWindowDelegate, NSTextFieldDelegate, NSMenuDelegate> {
@public
    std::unique_ptr<sv::AppRuntime> _core;
    std::unique_ptr<silveton::Vst3PluginBrowserService> _browser;
    silveton::Vst3PresetLibrary _presets;
    std::string _supportDir;
    std::string _presetDir;
    NSTimer* _timer;
    NSWindow* _window;
    NSView* _root;
    SilvetonPageBar* _pageBar;
    SilvetonTransportDeck* _transport;
    NSView* _arrangePage;
    NSView* _mixPage;
    NSView* _editPage;
    NSView* _libraryPage;
    SilvetonArrangeView* _arrange;
    NSScrollView* _channelScroll;
    SVFlipView* _audioPanel;
    SVFlipView* _midiPanel;
    BOOL _channelPanelVisible;
    SilvetonConsoleView* _console;
    SilvetonNoteGridView* _noteGrid;
    SilvetonSampleView* _sampleView;
    SVFlipView* _midiTools;
    SVFlipView* _audioTools;
    NSTextField* _editTitle;
    NSPopUpButton* _gridPopup;
    NSSlider* _swingSlider;
    NSTextField* _swingValue;

    // Library page
    NSSearchField* _pluginSearch;
    NSTableView* _pluginTable;
    NSTableView* _poolTable;
    NSTableView* _markerTable;
    NSTableView* _sectionTable;
    NSTableView* _chainTable;

    // Channel panel (audio)
    NSTextField* _cpName;
    NSTextField* _cpType;
    NSPopUpButton* _cpColor;
    NSPopUpButton* _cpAutomation;
    NSPopUpButton* _cpOutput;
    SVResetSlider* _cpVolume;
    SVResetSlider* _cpPan;
    NSTextField* _cpVolumeValue;
    NSTextField* _cpPanValue;
    SVToggle* _cpMute;
    SVToggle* _cpSolo;
    SVToggle* _cpArm;
    SVToggle* _cpMonitor;
    SVToggle* _cpLock;
    NSTableView* _insertTable;
    NSTableView* _sendTable;
    SVToggle* _sendPre;
    SVResetSlider* _sendLevel;
    NSTextField* _sendLevelValue;
    NSTextField* _cpNotes;
    // Channel panel (MIDI)
    NSTextField* _mpName;
    NSPopUpButton* _mpColor;
    NSPopUpButton* _mpOutput;
    NSTextField* _mpTranspose;
    NSTextField* _mpVelocity;
    SVToggle* _mpMute;
    SVToggle* _mpSolo;

    // State
    SVPage _page;
    double _pps;
    BOOL _snap;
    std::uint32_t _gridDiv;
    SVStrip _strip;
    std::size_t _insertSlotCount;
    long _insertRow;
    long _sendRow;
    std::vector<SVPluginEntry> _pluginResults;
    std::vector<std::string> _pool;
    BOOL _updating;
    BOOL _scannerBusy;
    BOOL _gestureNeedsRebuild;
    BOOL _gestureOpen;
    silveton::AutomationWriter _gainWriter;
    silveton::AutomationWriter _panWriter;
    silveton::ProjectAudioClip _clipboard;
    BOOL _clipboardValid;
    long _midiRecordTrack;
    std::int64_t _midiRecordStart;
    SVStrip _menuStrip;
    silveton::ArrangeRow _menuRow;
    std::int64_t _menuSample;
    std::uint64_t _menuMarker;
    std::uint64_t _menuSection;
    unsigned _tick;
    silveton::MeterBank _meters;
    double _meterClock;
    // Play watchdog: after Play is pressed, the UI checks that the position really moves.
    unsigned _playWatchTick;
    std::int64_t _playWatchPosition;
    std::uint64_t _playWatchCallbacks;
}
// Shared helpers (implemented across the category files)
- (void)runEdit:(NSString*)label rebuild:(BOOL)rebuild block:(void (^)(void))block;
- (void)showError:(NSString*)title detail:(const std::string&)detail;
- (NSString*)promptText:(NSString*)title message:(NSString*)message initial:(NSString*)initial;
- (void)requestRebuild;
- (void)refreshChannelPanel;
- (void)refreshLibrary;
- (void)refreshEditPage;
- (void)buildChannelPanelIn:(NSRect)frame;
- (void)buildLibraryPage:(NSView*)page;
- (void)buildEditPage:(NSView*)page;
- (void)buildMenus;
- (NSMenu*)paletteMenuWithAction:(SEL)action;
- (std::vector<silveton::ProjectPluginSlot>*)slotsForStrip:(SVStrip)strip;
- (silveton::IVst3PluginInstance*)instanceForStrip:(SVStrip)strip slot:(std::size_t)slot;
- (silveton::NativePlugin*)nativeInstanceForStrip:(SVStrip)strip slot:(std::size_t)slot;
- (void)openInsertEditor:(SVStrip)strip slot:(std::size_t)slot;
- (NSString*)stripName:(SVStrip)strip;
- (void)insertPluginEntry:(const SVPluginEntry&)entry intoStrip:(SVStrip)strip;
- (void)reloadPluginResults;
- (void)addInstrumentTrackWith:(const SVPluginEntry&)entry;
- (void)stopMidiRecording;
- (void)updateInputMonitoring;
// Menu/document actions implemented in SilvetonActions.mm
- (void)saveProject:(id)sender;
- (void)undo:(id)sender;
- (void)redo:(id)sender;
- (void)updateTitle;
// Quantize family (SilvetonActions.mm applies, SilvetonQuantize.mm shows the panel)
- (void)showQuantizePanel:(id)sender;
- (void)midiQuantizeSetup:(id)sender;
- (void)midiQuantizeLength:(id)sender;
- (void)midiGrooveApply:(id)sender;
- (void)midiGrooveExtract:(id)sender;
- (void)audioQuantize:(id)sender;
@end
