// Silveton — the Tone Editor window.
//
// The voice is drawn as TONE BLOCKS on a piano grid: one block per sung note, at the pitch it will
// have after the changes. The thin line is the pitch as it was sung, the bright line is the pitch
// after the changes. Under the grid is the sound itself; the points on it are the "time bend".
// Everything on the screen is in RESULT time (after the time bend), so the ruler and the playhead
// agree with the project. The maths is in ToneEdit.h; this file only draws and turns the mouse
// and the keys into those calls.
#import "SilvetonViews.h"
#include "SilvetonTheme.h"
#include "SilvetonToneState.h"

#include "silveton/SampleEditorModel.h"
#include "silveton/ToneEdit.h"

#include <algorithm>
#include <cmath>
#include <vector>

using namespace silveton;

namespace {

constexpr CGFloat kGutterW = 62.0;
constexpr CGFloat kRulerH = 24.0;
constexpr CGFloat kWaveH = 92.0;
constexpr CGFloat kReadoutH = 26.0;
constexpr CGFloat kEdgeGrab = 5.0;
constexpr CGFloat kDragThreshold = 3.0;
constexpr std::size_t kPeakBlock = 256U;

enum class Drag { None, Rubber, Pitch, TimeMove, EdgeEdit, EdgeStretch, WarpPoint, Scrub, Draw };

struct Hit {
    const ToneBlock* block {nullptr};
    int edge {0};          // -1 left edge, +1 right edge, 0 body
};

// Every note has its own colour (as the segments of VariAudio), so a melody reads at a glance.
NSColor* noteFill(double midi, double alpha) {
    const int pc = ((static_cast<int>(std::lround(midi)) % 12) + 12) % 12;
    return [NSColor colorWithCalibratedHue:static_cast<CGFloat>(pc) / 12.0 saturation:0.42 brightness:0.66 alpha:static_cast<CGFloat>(alpha)];
}
NSColor* noteEdge(double midi) {
    const int pc = ((static_cast<int>(std::lround(midi)) % 12) + 12) % 12;
    return [NSColor colorWithCalibratedHue:static_cast<CGFloat>(pc) / 12.0 saturation:0.30 brightness:0.92 alpha:1.0];
}
NSColor* noteDeep(double midi) {
    const int pc = ((static_cast<int>(std::lround(midi)) % 12) + 12) % 12;
    return [NSColor colorWithCalibratedHue:static_cast<CGFloat>(pc) / 12.0 saturation:0.55 brightness:0.42 alpha:0.95];
}

NSString* noteLabel(double midi) {
    static const char* names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    const long n = std::lround(midi);
    const long pc = ((n % 12) + 12) % 12;
    return [NSString stringWithFormat:@"%s%ld", names[pc], (n - pc) / 12 - 1];
}

bool blackKey(int pitchClass) { return pitchClass == 1 || pitchClass == 3 || pitchClass == 6 || pitchClass == 8 || pitchClass == 10; }

} // namespace

@interface SilvetonToneView () {
    SampleViewport _vp;                 // time axis: result samples of the analysed sound
    double _topMidi;                    // pitch at the top edge of the grid
    double _semiH;                      // pixels per semitone
    std::vector<float> _peakMin, _peakMax;   // pyramid of the original sound (mono, one entry per kPeakBlock samples)
    const void* _peaksFor;              // the audio the pyramid belongs to
    NSTrackingArea* _tracking;
    Drag _drag;
    NSPoint _down;
    NSPoint _last;
    BOOL _moved;
    std::uint32_t _dragId;
    int _dragEdge;
    double _dragAnchorPitch;            // target pitch of the clicked block when the drag began
    double _dragLastDelta;
    std::vector<std::pair<std::uint32_t, float>> _dragMoves;   // block id, moveCents at the start
    std::vector<ToneBlock> _blocksBackup;
    std::vector<ToneWarpPoint> _warpBackup;
    std::int64_t _dragSource;           // source position of the warp point being dragged
    std::int64_t _dragStartRes, _dragEndRes;   // result position of the dragged block when the drag began
    NSRect _rubber;
    std::int64_t _drawFrom, _drawTo;
    double _drawPitch;
    std::int64_t _lastPlayhead;
    std::uint32_t _hover;
    NSPoint _mouse;
    BOOL _mouseIn;
}
@end

@implementation SilvetonToneView

- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _showOriginalPitch = YES;
        _showCorrectedPitch = YES;
        _showWaveform = YES;
        _showScale = YES;
        _topMidi = 72.0;
        _semiH = 20.0;
        _lastPlayhead = -1;
        _vp.length = 1.0;
        _vp.samplesPerPixel = 100.0;
        _vp.widthPx = 100.0;
    }
    return self;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (BOOL)acceptsFirstMouse:(NSEvent*)event { (void)event; return YES; }

- (void)updateTrackingAreas {
    [super updateTrackingAreas];
    if (_tracking) [self removeTrackingArea:_tracking];
    _tracking = [[NSTrackingArea alloc] initWithRect:self.bounds
                                             options:NSTrackingMouseMoved | NSTrackingMouseEnteredAndExited | NSTrackingActiveInKeyWindow | NSTrackingInVisibleRect
                                               owner:self userInfo:nil];
    [self addTrackingArea:_tracking];
}

// ================================================================ geometry ==
- (CGFloat)waveH { return self.compact ? 0.0 : kWaveH; }
- (CGFloat)readoutH { return self.compact ? 0.0 : kReadoutH; }
- (NSRect)gridRect {
    const NSRect b = self.bounds;
    const CGFloat y = kRulerH;
    const CGFloat below = self.compact ? 0.0 : (kWaveH + kReadoutH + 8.0);
    return NSMakeRect(kGutterW, y, std::max<CGFloat>(1.0, b.size.width - kGutterW), std::max<CGFloat>(60.0, b.size.height - y - below));
}
- (NSRect)rulerRect { const NSRect g = [self gridRect]; return NSMakeRect(g.origin.x, 0, g.size.width, kRulerH); }
- (NSRect)waveRect { const NSRect g = [self gridRect]; return NSMakeRect(g.origin.x, NSMaxY(g) + 4.0, g.size.width, [self waveH]); }
- (NSRect)readoutRect { const NSRect b = self.bounds; return NSMakeRect(0, b.size.height - [self readoutH], b.size.width, [self readoutH]); }

- (SVToneSession*)session { return [self.controller toneSession]; }
- (BOOL)ready {
    SVToneSession* s = [self session];
    return s && s->phase == SVToneSession::Phase::Ready && s->analysis && s->audio;
}

- (CGFloat)xAtResult:(double)r { return [self gridRect].origin.x + _vp.xAtSample(r); }
- (double)resultAtX:(CGFloat)x { return _vp.sampleAtX(x - [self gridRect].origin.x); }
- (CGFloat)yAtMidi:(double)midi { return [self gridRect].origin.y + (_topMidi - midi) * _semiH; }
- (double)midiAtY:(CGFloat)y { return _topMidi - (y - [self gridRect].origin.y) / _semiH; }

- (ToneTimeMap)timeMap {
    SVToneSession* s = [self session];
    return ToneTimeMap(s->edit.warp, s->analysis->length);
}

- (NSRect)rectOfBlock:(const ToneBlock&)b map:(const ToneTimeMap&)map {
    SVToneSession* s = [self session];
    const CGFloat x0 = [self xAtResult:map.forward(static_cast<double>(b.start))];
    const CGFloat x1 = [self xAtResult:map.forward(static_cast<double>(b.end))];
    const CGFloat h = std::max<CGFloat>(12.0, _semiH * 0.84);
    const CGFloat yc = [self yAtMidi:toneBlockTargetPitch(b, s->edit)];
    return NSMakeRect(x0, yc - h * 0.5, std::max<CGFloat>(2.0, x1 - x0), h);
}

// ================================================================ view state ==
- (void)configureViewport {
    SVToneSession* s = [self session];
    const NSRect g = [self gridRect];
    if (!s || !s->analysis) { _vp.configure(1.0, g.size.width); return; }
    _vp.configure(static_cast<double>(std::max<std::int64_t>(1, s->analysis->length)), g.size.width);
}

- (void)buildPeaks {
    SVToneSession* s = [self session];
    _peakMin.clear(); _peakMax.clear();
    _peaksFor = nullptr;
    if (!s || !s->audio) return;
    const AudioBuffer& a = *s->audio;
    const std::size_t frames = a.frames(), channels = a.channels();
    if (frames == 0U || channels == 0U) return;
    const std::size_t blocks = (frames + kPeakBlock - 1U) / kPeakBlock;
    _peakMin.assign(blocks, 0.0F);
    _peakMax.assign(blocks, 0.0F);
    for (std::size_t b = 0U; b < blocks; ++b) {
        const std::size_t i0 = b * kPeakBlock, i1 = std::min(frames, i0 + kPeakBlock);
        float lo = 0.0F, hi = 0.0F;
        for (std::size_t c = 0U; c < channels; ++c) {
            const float* d = a.channelData(c);
            for (std::size_t i = i0; i < i1; ++i) { lo = std::min(lo, d[i]); hi = std::max(hi, d[i]); }
        }
        _peakMin[b] = lo;
        _peakMax[b] = hi;
    }
    _peaksFor = s->audio.get();
}

- (void)sessionChanged {
    _peakMin.clear(); _peakMax.clear(); _peaksFor = nullptr;
    _drag = Drag::None;
    _hover = 0U;
    [self setNeedsDisplay:YES];
}

- (void)sessionLoaded {
    [self buildPeaks];
    [self configureViewport];
    [self zoomFit];
}

- (void)zoomFit {
    SVToneSession* s = [self session];
    [self configureViewport];
    _vp.fitAll();
    if (s && s->analysis && !s->edit.blocks.empty()) {
        double lo = 200.0, hi = -200.0;
        for (const auto& b : s->edit.blocks) {
            const double t = toneBlockTargetPitch(b, s->edit);
            lo = std::min({lo, t, static_cast<double>(b.pitch)});
            hi = std::max({hi, t, static_cast<double>(b.pitch)});
        }
        const NSRect g = [self gridRect];
        const double range = std::max(6.0, hi - lo + 6.0);
        _semiH = std::clamp(static_cast<double>(g.size.height) / range, 10.0, 44.0);
        const double rows = g.size.height / _semiH;
        _topMidi = std::min(127.0, (hi + lo) * 0.5 + rows * 0.5);
    }
    [self setNeedsDisplay:YES];
}

- (void)zoomToSelection {
    SVToneSession* s = [self session];
    if (![self ready] || s->selected.empty()) { [self zoomFit]; return; }
    const ToneTimeMap map = [self timeMap];
    double a = 1.0e18, b = -1.0e18, lo = 200.0, hi = -200.0;
    for (const std::uint32_t id : s->selected) {
        const ToneBlock* blk = s->edit.find(id);
        if (!blk) continue;
        a = std::min(a, map.forward(static_cast<double>(blk->start)));
        b = std::max(b, map.forward(static_cast<double>(blk->end)));
        const double t = toneBlockTargetPitch(*blk, s->edit);
        lo = std::min(lo, t); hi = std::max(hi, t);
    }
    if (b <= a) return;
    [self configureViewport];
    _vp.zoomToRange(a, b);
    const NSRect g = [self gridRect];
    const double range = std::max(8.0, hi - lo + 8.0);
    _semiH = std::clamp(static_cast<double>(g.size.height) / range, 10.0, 44.0);
    _topMidi = std::min(127.0, (hi + lo) * 0.5 + g.size.height / _semiH * 0.5);
    [self setNeedsDisplay:YES];
}

- (void)zoomBy:(double)factor {
    const NSRect g = [self gridRect];
    _vp.zoomAbout(g.size.width * 0.5, factor);
    [self setNeedsDisplay:YES];
}

- (void)selectionChanged { [self setNeedsDisplay:YES]; }

- (void)clampPitchView {
    const NSRect g = [self gridRect];
    const double rows = g.size.height / _semiH;
    _topMidi = std::clamp(_topMidi, rows - 4.0, 134.0);
}

// ================================================================ drawing ==
- (void)drawRect:(NSRect)dirty {
    const NSRect b = self.bounds;
    sv::fill(dirty, sv::canvas());
    [self configureViewport];
    SVToneSession* s = [self session];
    const NSRect g = [self gridRect], ruler = [self rulerRect], wave = [self waveRect];
    if (!s) {
        sv::textIn(@"Select an audio clip with a single voice, then press TONE in the top bar.", NSMakeRect(20, b.size.height * 0.4, b.size.width - 40, 22),
                   sv::ui(13), sv::inkDim(), NSTextAlignmentCenter);
        return;
    }
    if (![self ready]) {
        NSString* text = s->phase == SVToneSession::Phase::Failed ? sv::ns(s->message)
            : [NSString stringWithFormat:@"Listening to the voice … %.0f %%", 100.0 * static_cast<double>(s->progress->load())];
        sv::fill(g, sv::laneA());
        sv::textIn(text, NSMakeRect(kGutterW + 20, g.origin.y + g.size.height * 0.4, g.size.width - 40, 22), sv::ui(13), sv::inkDim(), NSTextAlignmentCenter);
        return;
    }
    const ToneTimeMap map = [self timeMap];
    [self drawGrid:g dirty:dirty];
    [self drawRuler:ruler dirty:dirty];
    [self drawKeys:g dirty:dirty];
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(g);
    [self drawGridWave:g map:map dirty:dirty];   // the sound, faint, behind the blocks (as in VariAudio)
    [self drawBlocks:g map:map dirty:dirty];
    [self drawCurves:g map:map dirty:dirty];   // the pitch lines go over the blocks, so they are always seen
    [self drawOverlays:g map:map];
    [NSGraphicsContext restoreGraphicsState];
    if (!self.compact) [self drawWave:wave map:map dirty:dirty];
    [self drawPlayhead];
    if (!self.compact) [self drawReadout:[self readoutRect] map:map];
}

- (void)drawGrid:(NSRect)g dirty:(NSRect)dirty {
    if (!NSIntersectsRect(dirty, g)) return;
    SVToneSession* s = [self session];
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(g);
    sv::fill(g, sv::laneA());
    const int first = static_cast<int>(std::floor(_topMidi - g.size.height / _semiH)) - 1, last = static_cast<int>(std::ceil(_topMidi)) + 1;
    const ToneScale scale = s->edit.scale;
    const bool useScale = _showScale && (!scale.chromatic());
    for (int n = std::max(0, first); n <= std::min(127, last); ++n) {
        const CGFloat yc = [self yAtMidi:n];
        const NSRect row = NSMakeRect(g.origin.x, yc - _semiH * 0.5, g.size.width, _semiH);
        const int pc = n % 12;
        NSColor* fill = blackKey(pc) ? sv::laneA() : sv::laneB();
        if (useScale) {
            if (!scale.contains(pc)) fill = sv::hex(0x101114);
            else if (pc == ((scale.root % 12) + 12) % 12) fill = sv::hex(0x23262C);
            else fill = sv::hex(0x1B1D22);
        }
        sv::fill(row, fill);
        sv::line(NSMakePoint(g.origin.x, row.origin.y), NSMakePoint(NSMaxX(g), row.origin.y), pc == 0 ? sv::hex(0x3A3E48) : sv::hairline());
    }
    // beat lines from the project's grid
    SilvetonController* c = self.controller;
    Project* project = [c project];
    if (project) {
        const double rate = std::max(1.0, s->rate);
        const double div = static_cast<double>(std::max<std::uint32_t>(1U, [c gridDivisionsPerQuarter]));
        const double visA = _vp.first, visB = _vp.first + _vp.visibleSamples();
        const double q0 = std::floor(project->tempoMap.quarterNotesAtSample(s->origin + static_cast<std::int64_t>(visA)) * div) / div;
        const double q1 = project->tempoMap.quarterNotesAtSample(s->origin + static_cast<std::int64_t>(visB)) + 1.0 / div;
        const double qStep = 1.0 / div;
        const double pxPerQuarter = _vp.samplesPerPixel > 0.0 ? (rate * 60.0 / std::max(20.0, project->tempoMap.tempoAtSample(s->origin))) / _vp.samplesPerPixel : 0.0;
        if (pxPerQuarter * qStep >= 7.0 && (q1 - q0) / qStep < 4000.0) {
            for (double q = q0; q <= q1; q += qStep) {
                const double r = static_cast<double>(project->tempoMap.sampleAtQuarterNotes(q) - s->origin);
                const CGFloat x = std::floor([self xAtResult:r]) + 0.5;
                if (x < g.origin.x || x > NSMaxX(g)) continue;
                const bool beat = std::abs(q - std::round(q)) < 1.0e-6;
                const double barLen = static_cast<double>(project->tempoMap.numeratorAtSample(s->origin)) * 4.0 / std::max(1.0, static_cast<double>(project->tempoMap.denominatorAtSample(s->origin)));
                const bool bar = beat && std::abs(std::fmod(q, barLen)) < 1.0e-6;
                sv::line(NSMakePoint(x, g.origin.y), NSMakePoint(x, NSMaxY(g)), bar ? sv::hex(0x3A3E48) : (beat ? sv::hex(0x2A2D34) : sv::hex(0x1E2025)));
            }
        }
    }
    [NSGraphicsContext restoreGraphicsState];
}

- (void)drawKeys:(NSRect)g dirty:(NSRect)dirty {
    const NSRect gutter = NSMakeRect(0, g.origin.y, kGutterW, g.size.height);
    if (!NSIntersectsRect(dirty, gutter)) return;
    SVToneSession* s = [self session];
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(gutter);
    sv::fill(gutter, sv::panel());
    const int first = static_cast<int>(std::floor(_topMidi - g.size.height / _semiH)) - 1, last = static_cast<int>(std::ceil(_topMidi)) + 1;
    const ToneScale scale = s->edit.scale;
    for (int n = std::max(0, first); n <= std::min(127, last); ++n) {
        const CGFloat yc = [self yAtMidi:n];
        const int pc = n % 12;
        const NSRect key = NSMakeRect(0, yc - _semiH * 0.5, kGutterW - 1.0, _semiH);
        const bool inScale = !scale.chromatic() && scale.contains(pc);
        NSColor* body = blackKey(pc) ? sv::hex(0x2B2E35) : sv::hex(0x4A4E58);
        if (inScale && _showScale) body = blackKey(pc) ? sv::hex(0x5C4A2A) : sv::hex(0x8F6428);
        sv::fill(NSInsetRect(key, 0, 0.5), body);
        if (pc == 0 || _semiH >= 15.0) {
            sv::textIn(noteLabel(n), NSMakeRect(6, key.origin.y + (_semiH - 13.0) * 0.5, kGutterW - 14, 13), sv::mono(10, pc == 0),
                       pc == 0 ? sv::ink() : sv::inkDim(), NSTextAlignmentRight);
        }
    }
    [NSGraphicsContext restoreGraphicsState];
    sv::line(NSMakePoint(kGutterW - 0.5, g.origin.y), NSMakePoint(kGutterW - 0.5, NSMaxY(g)), sv::hairline());
}

- (void)drawRuler:(NSRect)ruler dirty:(NSRect)dirty {
    const NSRect full = NSMakeRect(0, 0, self.bounds.size.width, kRulerH);
    if (!NSIntersectsRect(dirty, full)) return;
    SVToneSession* s = [self session];
    sv::fill(full, sv::panel());
    sv::line(NSMakePoint(0, kRulerH - 0.5), NSMakePoint(NSMaxX(ruler), kRulerH - 0.5), sv::hairline());
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(ruler);
    const auto ticks = buildRuler(_vp, s->rate, 96.0, static_cast<double>(s->origin));
    for (const RulerTick& t : ticks) {
        const CGFloat x = std::floor(ruler.origin.x + _vp.xAtSample(t.sample)) + 0.5;
        if (x < ruler.origin.x - 1.0 || x > NSMaxX(ruler) + 1.0) continue;
        sv::line(NSMakePoint(x, kRulerH - (t.major ? 11.0 : 5.0)), NSMakePoint(x, kRulerH), sv::inkFaint());
        if (t.major && !t.label.empty()) sv::text(sv::ns(t.label), NSMakePoint(x + 4.0, 3.0), sv::mono(10), sv::inkDim());
    }
    [NSGraphicsContext restoreGraphicsState];
}

- (void)drawCurves:(NSRect)g map:(const ToneTimeMap&)map dirty:(NSRect)dirty {
    if (!NSIntersectsRect(dirty, g)) return;
    SVToneSession* s = [self session];
    const ToneFrames& f = s->analysis->frames;
    if (f.hop == 0U) return;
    const double visA = _vp.first - 2.0 * _vp.samplesPerPixel, visB = _vp.first + _vp.visibleSamples() + 2.0 * _vp.samplesPerPixel;
    if (_showOriginalPitch) {
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.4;
        BOOL open = NO;
        const std::size_t i0 = static_cast<std::size_t>(std::max(0.0, std::floor(map.inverse(visA) / static_cast<double>(f.hop))));
        for (std::size_t i = i0; i < f.size(); ++i) {
            const double r = map.forward(static_cast<double>(i * f.hop));
            if (r > visB) break;
            if (!f.voiced(i)) { open = NO; continue; }
            const NSPoint p = NSMakePoint([self xAtResult:r], [self yAtMidi:f.midi[i]]);
            if (open) [path lineToPoint:p]; else { [path moveToPoint:p]; open = YES; }
        }
        [sv::hex(0xE6EBF2, 0.75) setStroke];   // sung pitch: light grey line
        [path stroke];
    }
    if (_showCorrectedPitch) {
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.6;
        BOOL open = NO;
        for (const auto& b : s->edit.blocks) {
            const double rs = map.forward(static_cast<double>(b.start)), re = map.forward(static_cast<double>(b.end));
            if (re < visA || rs > visB) continue;
            const std::size_t fa = static_cast<std::size_t>(std::max<std::int64_t>(0, b.start / static_cast<std::int64_t>(f.hop)));
            const std::size_t fb = std::min<std::size_t>(f.size(), static_cast<std::size_t>((b.end + static_cast<std::int64_t>(f.hop) - 1) / static_cast<std::int64_t>(f.hop)));
            open = NO;
            for (std::size_t i = fa; i < fb; ++i) {
                if (!f.voiced(i)) { open = NO; continue; }
                const double r = map.forward(static_cast<double>(i * f.hop));
                const double midi = b.bypass ? static_cast<double>(f.midi[i]) : toneFrameTargetPitch(b, s->edit, *s->analysis, i);
                const NSPoint p = NSMakePoint([self xAtResult:r], [self yAtMidi:midi]);
                if (open) [path lineToPoint:p]; else { [path moveToPoint:p]; open = YES; }
            }
        }
        [sv::hex(0xFFD27A, 1.0) setStroke];    // corrected pitch: amber line
        [path stroke];
    }
}

- (void)drawBlocks:(NSRect)g map:(const ToneTimeMap&)map dirty:(NSRect)dirty {
    if (!NSIntersectsRect(dirty, g)) return;
    SVToneSession* s = [self session];
    NSFont* font = sv::mono(10, true);
    for (const auto& b : s->edit.blocks) {
        const NSRect r = [self rectOfBlock:b map:map];
        if (NSMaxX(r) < g.origin.x || r.origin.x > NSMaxX(g)) continue;
        const BOOL selected = s->selectedHas(b.id);
        const double target = toneBlockTargetPitch(b, s->edit);
        // ghost at the sung pitch when the block was moved
        if (std::abs(target - static_cast<double>(b.pitch)) > 0.08 && !b.bypass) {
            NSRect ghost = r;
            ghost.origin.y = [self yAtMidi:b.pitch] - r.size.height * 0.5;
            sv::roundStroke(ghost, 3.0, sv::hex(0x9AA3B4, 0.45), 1.0);
            sv::line(NSMakePoint(NSMidX(r), NSMidY(r)), NSMakePoint(NSMidX(r), NSMidY(ghost)), sv::hex(0x9AA3B4, 0.35), 1.0);
        }
        NSColor* fill = b.bypass ? sv::hex(0x2B2E35, 0.9) : (selected ? sv::hex(0xFFB347, 0.78) : noteFill(target, 0.72));
        NSColor* edge = b.bypass ? sv::hex(0x6A6F7A) : (selected ? sv::hex(0xFFE0A8) : noteEdge(target));
        // loudness shows as how filled the block is from below
        sv::roundFill(r, 3.0, fill);
        const double level = std::clamp((static_cast<double>(b.levelDb) + 50.0) / 50.0, 0.1, 1.0);
        NSRect lower = NSMakeRect(r.origin.x, NSMaxY(r) - r.size.height * 0.22, r.size.width, r.size.height * 0.22);
        lower.size.width *= level;
        if (!b.bypass) sv::roundFill(lower, 2.0, selected ? sv::hex(0xC77A1E, 0.9) : noteDeep(target));
        sv::roundStroke(r, 3.0, edge, selected ? 1.5 : 1.0);
        if (b.id == _hover && !selected) sv::roundStroke(NSInsetRect(r, -1, -1), 3.0, sv::hex(0xFFFFFF, 0.5), 1.0);
        if (r.size.width >= 26.0) {
            const double cents = (target - std::round(target)) * 100.0;
            NSString* label = std::abs(cents) >= 1.0 && r.size.width >= 64.0
                ? [NSString stringWithFormat:@"%@ %+.0f", noteLabel(target), cents] : noteLabel(target);
            sv::textIn(label, NSMakeRect(r.origin.x + 4, r.origin.y + (r.size.height - 13.0) * 0.5 - 1.0, r.size.width - 6, 13), font,
                       b.bypass ? sv::inkFaint() : (selected ? sv::hex(0x1A1308) : sv::hex(0xF2F5F9)));
        }
        // small mark on the blocks that carry a change
        if (b.touched() && !b.bypass) {
            sv::fill(NSMakeRect(NSMaxX(r) - 6.0, r.origin.y + 3.0, 3.0, 3.0), selected ? sv::hex(0x1A1308) : sv::hex(0xFFE0A8));
        }
    }
}

- (void)drawOverlays:(NSRect)g map:(const ToneTimeMap&)map {
    (void)map;
    if (_drag == Drag::Rubber) {
        sv::fill(_rubber, sv::hex(0xFFB347, 0.15));
        sv::roundStroke(_rubber, 0.0, sv::hex(0xFFB347, 0.8), 1.0);
    } else if (_drag == Drag::Draw) {
        const CGFloat x0 = [self xAtResult:static_cast<double>(std::min(_drawFrom, _drawTo))];
        const CGFloat x1 = [self xAtResult:static_cast<double>(std::max(_drawFrom, _drawTo))];
        const CGFloat h = std::max<CGFloat>(12.0, _semiH * 0.84);
        const NSRect r = NSMakeRect(x0, [self yAtMidi:_drawPitch] - h * 0.5, std::max<CGFloat>(2.0, x1 - x0), h);
        sv::roundFill(r, 3.0, sv::hex(0xFFB347, 0.45));
        sv::roundStroke(r, 3.0, sv::hex(0xFFE0A8), 1.0);
    }
    (void)g;
}

// The peak of the sound under one screen column (uses the peak pyramid when the column covers many samples).
- (void)columnPeakAtX:(NSInteger)x origin:(CGFloat)originX map:(const ToneTimeMap&)map low:(float*)lo high:(float*)hi {
    SVToneSession* s = [self session];
    const AudioBuffer& a = *s->audio;
    const std::size_t frames = a.frames(), channels = a.channels();
    *lo = 0.0F; *hi = 0.0F;
    (void)originX;
    const double r0 = _vp.sampleAtX(static_cast<double>(x)), r1 = _vp.sampleAtX(static_cast<double>(x + 1));
    double s0 = map.inverse(r0), s1 = map.inverse(r1);
    if (s1 <= s0) s1 = s0 + 1.0;
    if (s1 < 0.0 || s0 >= static_cast<double>(frames)) return;
    const auto i0 = static_cast<std::size_t>(std::max(0.0, std::floor(s0)));
    const auto i1 = std::min(frames, static_cast<std::size_t>(std::ceil(s1)) + 1U);
    const bool usePyramid = !_peakMin.empty() && _peaksFor == s->audio.get();
    if (usePyramid && (i1 - i0) >= 2U * kPeakBlock) {
        const std::size_t p0 = i0 / kPeakBlock, p1 = std::min(_peakMin.size(), (i1 + kPeakBlock - 1U) / kPeakBlock);
        for (std::size_t p = p0; p < p1; ++p) { *lo = std::min(*lo, _peakMin[p]); *hi = std::max(*hi, _peakMax[p]); }
    } else {
        for (std::size_t ch = 0U; ch < channels; ++ch) {
            const float* d = a.channelData(ch);
            for (std::size_t i = i0; i < i1; ++i) { *lo = std::min(*lo, d[i]); *hi = std::max(*hi, d[i]); }
        }
    }
    *lo = std::max(-1.0F, *lo); *hi = std::min(1.0F, *hi);
}

- (void)drawGridWave:(NSRect)g map:(const ToneTimeMap&)map dirty:(NSRect)dirty {
    if (!NSIntersectsRect(dirty, g)) return;
    SVToneSession* s = [self session];
    if (!_showWaveform || !s->audio) return;
    const CGFloat mid = NSMidY(g), amp = g.size.height * 0.42;
    const NSInteger xa = std::max<NSInteger>(0, static_cast<NSInteger>(std::floor(dirty.origin.x - g.origin.x)) - 1);
    const NSInteger xb = std::min<NSInteger>(static_cast<NSInteger>(g.size.width), static_cast<NSInteger>(std::ceil(NSMaxX(dirty) - g.origin.x)) + 1);
    NSBezierPath* path = [NSBezierPath bezierPath];
    path.lineWidth = 1.0;
    for (NSInteger x = xa; x < xb; ++x) {
        float lo = 0.0F, hi = 0.0F;
        [self columnPeakAtX:x origin:g.origin.x map:map low:&lo high:&hi];
        if (hi - lo < 0.002F) continue;
        const CGFloat px = g.origin.x + static_cast<CGFloat>(x) + 0.5;
        [path moveToPoint:NSMakePoint(px, mid - static_cast<CGFloat>(hi) * amp)];
        [path lineToPoint:NSMakePoint(px, mid - static_cast<CGFloat>(lo) * amp)];
    }
    [sv::hex(0xAEB6C4, 0.10) setStroke];
    [path stroke];
}

- (void)drawWave:(NSRect)wave map:(const ToneTimeMap&)map dirty:(NSRect)dirty {
    if (!NSIntersectsRect(dirty, NSInsetRect(wave, -2, -2))) return;
    SVToneSession* s = [self session];
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(wave);
    sv::fill(wave, sv::hex(0x14161A));
    const CGFloat mid = NSMidY(wave), amp = wave.size.height * 0.46;
    sv::line(NSMakePoint(wave.origin.x, mid), NSMakePoint(NSMaxX(wave), mid), sv::hex(0x2A2D34));
    if (_showWaveform && s->audio) {
        const AudioBuffer& a = *s->audio;
        const std::size_t frames = a.frames(), channels = a.channels();
        const NSInteger xa = std::max<NSInteger>(0, static_cast<NSInteger>(std::floor(dirty.origin.x - wave.origin.x)) - 1);
        const NSInteger xb = std::min<NSInteger>(static_cast<NSInteger>(wave.size.width), static_cast<NSInteger>(std::ceil(NSMaxX(dirty) - wave.origin.x)) + 1);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.0;
        const bool usePyramid = !_peakMin.empty() && _peaksFor == s->audio.get();
        for (NSInteger x = xa; x < xb; ++x) {
            const double r0 = _vp.sampleAtX(static_cast<double>(x)), r1 = _vp.sampleAtX(static_cast<double>(x + 1));
            double s0 = map.inverse(r0), s1 = map.inverse(r1);
            if (s1 <= s0) s1 = s0 + 1.0;
            if (s1 < 0.0 || s0 >= static_cast<double>(frames)) continue;
            const auto i0 = static_cast<std::size_t>(std::max(0.0, std::floor(s0)));
            const auto i1 = std::min(frames, static_cast<std::size_t>(std::ceil(s1)) + 1U);
            float lo = 0.0F, hi = 0.0F;
            if (usePyramid && (i1 - i0) >= 2U * kPeakBlock) {
                const std::size_t p0 = i0 / kPeakBlock, p1 = std::min(_peakMin.size(), (i1 + kPeakBlock - 1U) / kPeakBlock);
                for (std::size_t p = p0; p < p1; ++p) { lo = std::min(lo, _peakMin[p]); hi = std::max(hi, _peakMax[p]); }
            } else {
                for (std::size_t ch = 0U; ch < channels; ++ch) {
                    const float* d = a.channelData(ch);
                    for (std::size_t i = i0; i < i1; ++i) { lo = std::min(lo, d[i]); hi = std::max(hi, d[i]); }
                }
            }
            lo = std::max(-1.0F, lo); hi = std::min(1.0F, hi);
            const CGFloat px = wave.origin.x + static_cast<CGFloat>(x) + 0.5;
            [path moveToPoint:NSMakePoint(px, mid - static_cast<CGFloat>(hi) * amp)];
            [path lineToPoint:NSMakePoint(px, mid - static_cast<CGFloat>(lo) * amp - 0.5)];
        }
        [sv::hex(0xB8843C, 0.9) setStroke];
        [path stroke];
    }
    // block borders and the selection on the sound
    for (const auto& b : s->edit.blocks) {
        const CGFloat x0 = [self xAtResult:map.forward(static_cast<double>(b.start))], x1 = [self xAtResult:map.forward(static_cast<double>(b.end))];
        if (x1 < wave.origin.x || x0 > NSMaxX(wave)) continue;
        if (s->selectedHas(b.id)) sv::fill(NSMakeRect(x0, wave.origin.y, std::max<CGFloat>(1.0, x1 - x0), wave.size.height), sv::hex(0xFFB347, 0.14));
        sv::line(NSMakePoint(std::floor(x0) + 0.5, wave.origin.y), NSMakePoint(std::floor(x0) + 0.5, NSMaxY(wave)), sv::hex(0x5E7C99, 0.7));
        sv::line(NSMakePoint(std::floor(x1) + 0.5, wave.origin.y), NSMakePoint(std::floor(x1) + 0.5, NSMaxY(wave)), sv::hex(0x5E7C99, 0.7));
    }
    // time-bend points
    for (const auto& w : s->edit.warp) {
        const CGFloat x = [self xAtResult:static_cast<double>(w.target)];
        if (x < wave.origin.x - 6.0 || x > NSMaxX(wave) + 6.0) continue;
        const CGFloat y = wave.origin.y + 7.0;
        NSBezierPath* d = [NSBezierPath bezierPath];
        [d moveToPoint:NSMakePoint(x, y - 6.0)]; [d lineToPoint:NSMakePoint(x + 5.0, y)];
        [d lineToPoint:NSMakePoint(x, y + 6.0)]; [d lineToPoint:NSMakePoint(x - 5.0, y)]; [d closePath];
        [sv::hex(0xFFE0A8) setFill]; [d fill];
        if (w.target != w.source) {   // a thread to where this part of the sound came from
            const CGFloat xs = [self xAtResult:static_cast<double>(w.source)];
            sv::line(NSMakePoint(x, y + 6.0), NSMakePoint(xs, NSMaxY(wave) - 2.0), sv::hex(0xFFE0A8, 0.5), 1.0);
        }
    }
    [NSGraphicsContext restoreGraphicsState];
    sv::line(NSMakePoint(wave.origin.x, wave.origin.y - 0.5), NSMakePoint(NSMaxX(wave), wave.origin.y - 0.5), sv::hairline());
    sv::fill(NSMakeRect(0, wave.origin.y, kGutterW - 1.0, wave.size.height), sv::panel());
    sv::textIn(@"SOUND", NSMakeRect(6, wave.origin.y + 6, kGutterW - 12, 12), sv::ui(10, true), sv::inkFaint(), NSTextAlignmentRight);
    sv::textIn(@"bend:", NSMakeRect(6, wave.origin.y + 20, kGutterW - 12, 12), sv::ui(10), sv::inkFaint(), NSTextAlignmentRight);
    sv::textIn(@"Time tool", NSMakeRect(6, wave.origin.y + 32, kGutterW - 12, 12), sv::ui(10), sv::inkFaint(), NSTextAlignmentRight);
}

- (CGFloat)playheadX {
    SVToneSession* s = [self session];
    if (!s) return -1000.0;
    return [self xAtResult:static_cast<double>([self.controller playheadSample] - s->origin)];
}

- (void)drawPlayhead {
    const CGFloat x = std::floor([self playheadX]) + 0.5;
    const NSRect g = [self gridRect], w = [self waveRect];
    if (x < g.origin.x || x > NSMaxX(g)) return;
    sv::line(NSMakePoint(x, 0), NSMakePoint(x, NSMaxY(w)), sv::copper(), 1.5);
}

- (NSString*)readoutText {
    SVToneSession* s = [self session];
    if (!_mouseIn || !s) return @"";
    const double midi = [self midiAtY:_mouse.y];
    const double rpos = [self resultAtX:_mouse.x];
    return [NSString stringWithFormat:@"%@  %+.0f c   ·   %@", noteLabel(midi), (midi - std::round(midi)) * 100.0,
            sv::ns(formatClockTime(std::max(0.0, rpos) / std::max(1.0, s->rate)))];
}

- (void)drawReadout:(NSRect)r map:(const ToneTimeMap&)map {
    (void)map;
    SVToneSession* s = [self session];
    sv::fill(r, sv::panel());
    sv::line(NSMakePoint(0, r.origin.y + 0.5), NSMakePoint(NSMaxX(r), r.origin.y + 0.5), sv::hairline());
    NSString* left = [self readoutText];
    sv::textIn(left, NSMakeRect(kGutterW + 8, r.origin.y + 6, 360, 15), sv::mono(11, true), sv::ink());
    NSString* right = s->rendering ? @"Rendering …" : (s->dirty ? @"Changed" : @"Up to date");
    sv::textIn(right, NSMakeRect(r.size.width - 180, r.origin.y + 6, 170, 15), sv::ui(11), s->dirty || s->rendering ? sv::copper() : sv::inkFaint(), NSTextAlignmentRight);
    NSString* mid = s->edit.snapToScale ? [NSString stringWithFormat:@"Snap to %@", sv::ns(s->edit.scale.name())] : @"Snap to semitones";
    sv::textIn(mid, NSMakeRect(r.size.width - 420, r.origin.y + 6, 220, 15), sv::ui(11), sv::inkDim(), NSTextAlignmentRight);
}

// ================================================================ playhead tick ==
- (void)tick {
    SilvetonController* c = self.controller;
    if (!c || ![c core] || ![c core]->ready()) return;
    SVToneSession* s = [self session];
    if (s && s->phase == SVToneSession::Phase::Loading) { [self setNeedsDisplay:YES]; [c toneSelectionChanged]; return; }
    if (![self ready]) return;
    const std::int64_t pos = [c playheadSample];
    const double rel = static_cast<double>(pos - s->origin);
    const bool playing = [c core]->engine().transport().isPlaying();
    if (playing && _drag == Drag::None && rel >= 0.0 && rel <= _vp.length) {
        const double before = _vp.first;
        _vp.ensureVisible(rel);
        if (_vp.first != before) { _lastPlayhead = pos; [self setNeedsDisplay:YES]; return; }
    }
    if (pos != _lastPlayhead) {
        const NSRect g = [self gridRect], w = [self waveRect];
        auto stripe = [&](std::int64_t p) {
            const CGFloat x = [self xAtResult:static_cast<double>(p - s->origin)];
            [self setNeedsDisplayInRect:NSMakeRect(x - 3.0, 0, 7.0, NSMaxY(w))];
        };
        (void)g;
        if (_lastPlayhead >= 0) stripe(_lastPlayhead);
        stripe(pos);
        _lastPlayhead = pos;
    }
    if (_drag != Drag::None && _drag != Drag::Pitch) [self autoScrollWhileDragging];
}

- (void)autoScrollWhileDragging {
    const NSRect g = [self gridRect];
    const NSPoint mouse = [self convertPoint:[self.window mouseLocationOutsideOfEventStream] fromView:nil];
    CGFloat over = 0.0;
    if (mouse.x < g.origin.x) over = mouse.x - g.origin.x;
    else if (mouse.x > NSMaxX(g)) over = mouse.x - NSMaxX(g);
    if (over == 0.0) return;
    _vp.scrollPixels(over < 0.0 ? -std::min<CGFloat>(40.0, std::max<CGFloat>(3.0, -over / 3.0)) : std::min<CGFloat>(40.0, std::max<CGFloat>(3.0, over / 3.0)));
    [self dragToPoint:NSMakePoint(std::clamp(mouse.x, g.origin.x, NSMaxX(g)), mouse.y) flags:0];
    [self setNeedsDisplay:YES];
}

// ================================================================ hit tests ==
- (Hit)hitAt:(NSPoint)p requireY:(BOOL)requireY map:(const ToneTimeMap&)map {
    SVToneSession* s = [self session];
    Hit hit;
    const ToneBlock* xOnly = nullptr;
    for (const auto& b : s->edit.blocks) {
        const NSRect r = [self rectOfBlock:b map:map];
        if (p.x < r.origin.x - kEdgeGrab || p.x > NSMaxX(r) + kEdgeGrab) continue;
        const BOOL inY = p.y >= r.origin.y - 3.0 && p.y <= NSMaxY(r) + 3.0;
        if (inY) {
            hit.block = &b;
            const CGFloat grab = std::min<CGFloat>(kEdgeGrab, r.size.width * 0.3);
            if (p.x <= r.origin.x + grab) hit.edge = -1;
            else if (p.x >= NSMaxX(r) - grab) hit.edge = 1;
            return hit;
        }
        if (!xOnly && p.x >= r.origin.x && p.x <= NSMaxX(r)) xOnly = &b;
    }
    if (!requireY && xOnly) { hit.block = xOnly; }
    return hit;
}

- (BOOL)inGrid:(NSPoint)p { return NSPointInRect(p, [self gridRect]); }
- (BOOL)inWave:(NSPoint)p { return NSPointInRect(p, [self waveRect]); }
- (BOOL)inRuler:(NSPoint)p { return p.y < kRulerH && p.x >= kGutterW; }

- (std::int64_t)sourceAtResult:(double)r map:(const ToneTimeMap&)map {
    SVToneSession* s = [self session];
    return std::clamp<std::int64_t>(static_cast<std::int64_t>(std::llround(map.inverse(r))), 0, s->analysis->length);
}

- (void)seekAtX:(CGFloat)x {
    SVToneSession* s = [self session];
    const double r = std::max(0.0, [self resultAtX:x]);
    [self.controller seekToSample:s->origin + static_cast<std::int64_t>(r)];
}

// ================================================================== mouse ==
- (void)mouseMoved:(NSEvent*)event {
    _mouse = [self convertPoint:event.locationInWindow fromView:nil];
    _mouseIn = YES;
    if ([self ready]) {
        const ToneTimeMap map = [self timeMap];
        const SVToneTool tool = [self.controller toneTool];
        const Hit hit = [self inGrid:_mouse] ? [self hitAt:_mouse requireY:(tool == SVToneTool::Select) map:map] : Hit {};
        const std::uint32_t id = hit.block ? hit.block->id : 0U;
        if (id != _hover) { _hover = id; [self setNeedsDisplay:YES]; }
        NSCursor* cursor = [NSCursor arrowCursor];
        if (hit.block && hit.edge != 0 && (tool == SVToneTool::Select || tool == SVToneTool::Time)) cursor = [NSCursor resizeLeftRightCursor];
        else if (hit.block && tool == SVToneTool::Select) cursor = [NSCursor resizeUpDownCursor];
        else if (hit.block && tool == SVToneTool::Time) cursor = [NSCursor openHandCursor];
        else if (tool == SVToneTool::Cut || tool == SVToneTool::Draw) cursor = [NSCursor crosshairCursor];
        else if (tool == SVToneTool::Erase && hit.block) cursor = [NSCursor disappearingItemCursor];
        else if (tool == SVToneTool::Time && [self inWave:_mouse]) cursor = [NSCursor resizeLeftRightCursor];
        [cursor set];
    }
    if (self.compact) [self.controller toneReadout:[self readoutText]];
    else [self setNeedsDisplayInRect:[self readoutRect]];
}

- (void)mouseExited:(NSEvent*)event {
    (void)event;
    _mouseIn = NO;
    _hover = 0U;
    [[NSCursor arrowCursor] set];
    [self setNeedsDisplay:YES];
}

- (void)mouseDown:(NSEvent*)event {
    [self.window makeFirstResponder:self];
    if (![self ready]) return;
    SilvetonController* c = self.controller;
    SVToneSession* s = [self session];
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    _down = _last = p;
    _moved = NO;
    _drag = Drag::None;
    _dragId = 0U;
    const ToneTimeMap map = [self timeMap];
    const SVToneTool tool = [c toneTool];
    const BOOL shift = (event.modifierFlags & NSEventModifierFlagShift) != 0;

    if ([self inRuler:p]) { _drag = Drag::Scrub; [self seekAtX:p.x]; return; }

    // ---- the sound at the bottom: bend points (Time tool) or just the playhead
    if ([self inWave:p]) {
        if (tool == SVToneTool::Time && [c toneCanEdit]) {
            // an existing point? double-click removes it
            for (std::size_t i = 0U; i < s->edit.warp.size(); ++i) {
                const CGFloat x = [self xAtResult:static_cast<double>(s->edit.warp[i].target)];
                if (std::abs(x - p.x) <= 7.0) {
                    if (event.clickCount >= 2) { (void)ToneEditing::removeWarpPoint(s->edit, i); [c toneEdited:@"Remove Bend Point"]; return; }
                    _drag = Drag::WarpPoint;
                    _dragSource = s->edit.warp[i].source;
                    _warpBackup = s->edit.warp;
                    _warpBackup.erase(_warpBackup.begin() + static_cast<std::ptrdiff_t>(i));
                    [c toneDragBegan];
                    return;
                }
            }
            _drag = Drag::WarpPoint;
            _dragSource = [self sourceAtResult:[self resultAtX:p.x] map:map];
            _warpBackup = s->edit.warp;
            [c toneDragBegan];
            return;
        }
        _drag = Drag::Scrub;
        [self seekAtX:p.x];
        return;
    }
    if (![self inGrid:p]) return;

    const Hit hit = [self hitAt:p requireY:(tool == SVToneTool::Select || tool == SVToneTool::Draw) map:map];

    switch (tool) {
        case SVToneTool::Select: {
            if (hit.block) {
                const std::uint32_t id = hit.block->id;
                if (event.clickCount >= 2 && hit.edge == 0) {
                    const double rs = map.forward(static_cast<double>(hit.block->start));
                    [c seekToSample:s->origin + static_cast<std::int64_t>(rs)];
                    return;
                }
                std::vector<std::uint32_t> sel = s->selected;
                if (shift) {
                    auto it = std::find(sel.begin(), sel.end(), id);
                    if (it != sel.end()) sel.erase(it); else sel.push_back(id);
                } else if (!s->selectedHas(id)) {
                    sel = {id};
                }
                [c toneSetSelection:sel];
                if (!s->selectedHas(id)) return;   // it was switched off by shift-click
                if (![c toneCanEdit]) return;
                _dragId = id;
                if (hit.edge != 0) {
                    _drag = Drag::EdgeEdit;
                    _dragEdge = hit.edge;
                    _blocksBackup = s->edit.blocks;
                    [c toneDragBegan];
                } else {
                    _drag = Drag::Pitch;
                    _dragAnchorPitch = toneBlockTargetPitch(*hit.block, s->edit);
                    _dragLastDelta = 0.0;
                    _dragMoves.clear();
                    for (const std::uint32_t sid : s->selected) if (const ToneBlock* b = s->edit.find(sid)) _dragMoves.emplace_back(sid, b->moveCents);
                    [c toneDragBegan];
                }
            } else {
                _drag = Drag::Rubber;
                _rubber = NSMakeRect(p.x, p.y, 0, 0);
                if (!shift) [c toneSetSelection:std::vector<std::uint32_t>()];
            }
            break;
        }
        case SVToneTool::Time: {
            if (!hit.block) return;
            if (![c toneCanEdit]) return;
            _dragId = hit.block->id;
            _blocksBackup = s->edit.blocks;
            _warpBackup = s->edit.warp;
            _dragStartRes = static_cast<std::int64_t>(std::llround(map.forward(static_cast<double>(hit.block->start))));
            _dragEndRes = static_cast<std::int64_t>(std::llround(map.forward(static_cast<double>(hit.block->end))));
            _dragEdge = hit.edge;
            _drag = hit.edge != 0 ? Drag::EdgeStretch : Drag::TimeMove;
            [c toneSetSelection:std::vector<std::uint32_t>{_dragId}];
            [c toneDragBegan];
            break;
        }
        case SVToneTool::Cut: {
            if (!hit.block || ![c toneCanEdit]) return;
            const std::int64_t at = [self sourceAtResult:[self resultAtX:p.x] map:map];
            if (ToneEditing::split(s->edit, *s->analysis, hit.block->id, at) != 0U) [c toneEdited:@"Cut Segment"];
            else [c setStatus:@"A segment cannot be cut so close to its edge"];
            break;
        }
        case SVToneTool::Glue: {
            if (!hit.block || ![c toneCanEdit]) return;
            const auto& blocks = s->edit.blocks;
            for (std::size_t i = 0U; i + 1U < blocks.size(); ++i) {
                if (blocks[i].id == hit.block->id) {
                    if (ToneEditing::glue(s->edit, *s->analysis, blocks[i].id, blocks[i + 1U].id) != 0U) { [c toneSetSelection:std::vector<std::uint32_t>()]; [c toneEdited:@"Glue Segments"]; }
                    return;
                }
            }
            [c setStatus:@"This is the last segment — there is nothing to join it with"];
            break;
        }
        case SVToneTool::Erase: {
            if (!hit.block || ![c toneCanEdit]) return;
            (void)ToneEditing::remove(s->edit, hit.block->id);
            [c toneSetSelection:std::vector<std::uint32_t>()];
            [c toneEdited:@"Remove Segment"];
            break;
        }
        case SVToneTool::Draw: {
            if (hit.block || ![c toneCanEdit]) { if (hit.block) [c setStatus:@"Draw over a gap — there is already a segment here"]; return; }
            _drag = Drag::Draw;
            _drawFrom = _drawTo = [self sourceAtResult:[self resultAtX:p.x] map:map];
            _drawPitch = std::round([self midiAtY:p.y]);
            break;
        }
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent*)event {
    [self dragToPoint:[self convertPoint:event.locationInWindow fromView:nil] flags:event.modifierFlags];
}

- (void)dragToPoint:(NSPoint)p flags:(NSEventModifierFlags)flags {
    if (_drag == Drag::None || ![self ready]) return;
    SilvetonController* c = self.controller;
    SVToneSession* s = [self session];
    if (!_moved && std::hypot(p.x - _down.x, p.y - _down.y) < kDragThreshold) return;
    _moved = YES;
    _last = p;
    _mouse = p;
    const ToneTimeMap currentMap = [self timeMap];
    const BOOL alt = (flags & NSEventModifierFlagOption) != 0;

    switch (_drag) {
        case Drag::Scrub: [self seekAtX:std::clamp(p.x, kGutterW, NSMaxX([self gridRect]))]; break;
        case Drag::Rubber: {
            _rubber = NSMakeRect(std::min(_down.x, p.x), std::min(_down.y, p.y), std::abs(p.x - _down.x), std::abs(p.y - _down.y));
            std::vector<std::uint32_t> sel;
            for (const auto& b : s->edit.blocks) if (NSIntersectsRect(_rubber, [self rectOfBlock:b map:currentMap])) sel.push_back(b.id);
            if (sel != s->selected) [c toneSetSelection:sel];
            break;
        }
        case Drag::Pitch: {
            double delta = (_down.y - p.y) / _semiH;   // semitones
            if (!alt) delta = std::round(_dragAnchorPitch + delta) - _dragAnchorPitch;
            if (std::abs(delta - _dragLastDelta) < 1.0e-9) break;
            _dragLastDelta = delta;
            for (const auto& m : _dragMoves) if (ToneBlock* b = s->edit.find(m.first)) b->moveCents = m.second + static_cast<float>(delta * 100.0);
            [c toneEdited:@"Move Pitch"];
            break;
        }
        case Drag::EdgeEdit: {
            s->edit.blocks = _blocksBackup;
            const ToneBlock* orig = nullptr;
            std::size_t index = 0U;
            for (std::size_t i = 0U; i < s->edit.blocks.size(); ++i) if (s->edit.blocks[i].id == _dragId) { orig = &s->edit.blocks[i]; index = i; }
            if (!orig) break;
            const std::int64_t pos = [self sourceAtResult:[self resultAtX:p.x] map:currentMap];
            const std::int64_t hop = static_cast<std::int64_t>(s->analysis->frames.hop);
            bool done = false;
            if (_dragEdge < 0 && index > 0U && std::abs(s->edit.blocks[index - 1U].end - orig->start) <= hop) {
                done = ToneEditing::moveBorder(s->edit, *s->analysis, s->edit.blocks[index - 1U].id, _dragId, pos);
            } else if (_dragEdge > 0 && index + 1U < s->edit.blocks.size() && std::abs(s->edit.blocks[index + 1U].start - orig->end) <= hop) {
                done = ToneEditing::moveBorder(s->edit, *s->analysis, _dragId, s->edit.blocks[index + 1U].id, pos);
            } else {
                done = _dragEdge < 0 ? ToneEditing::setEdges(s->edit, *s->analysis, _dragId, pos, orig->end)
                                     : ToneEditing::setEdges(s->edit, *s->analysis, _dragId, orig->start, pos);
            }
            if (done) [c toneEdited:@"Change Segment Edges"];
            break;
        }
        case Drag::TimeMove: case Drag::EdgeStretch: {
            s->edit.warp = _warpBackup;
            const ToneTimeMap base(_warpBackup, s->analysis->length);
            const double dRes = (p.x - _down.x) * _vp.samplesPerPixel;
            std::int64_t ns = _dragStartRes, ne = _dragEndRes;
            const auto snapTimeline = [&](std::int64_t res) {
                if (![c snapEnabled]) return res;
                return [c snapSample:s->origin + res] - s->origin;
            };
            if (_drag == Drag::TimeMove) {
                ns = snapTimeline(static_cast<std::int64_t>(std::llround(_dragStartRes + dRes)));
                ne = ns + (_dragEndRes - _dragStartRes);
            } else if (_dragEdge < 0) {
                ns = snapTimeline(static_cast<std::int64_t>(std::llround(_dragStartRes + dRes)));
            } else {
                ne = snapTimeline(static_cast<std::int64_t>(std::llround(_dragEndRes + dRes)));
            }
            const auto minLen = static_cast<std::int64_t>(0.03 * s->rate);
            (void)base;
            if (ToneEditing::setBlockTime(s->edit, _dragId, ns, ne, s->analysis->length, minLen)) [c toneEdited:_drag == Drag::TimeMove ? @"Move Segment in Time" : @"Stretch Segment"];
            break;
        }
        case Drag::WarpPoint: {
            s->edit.warp = _warpBackup;
            const double targetRes = std::clamp([self resultAtX:p.x], 0.0, static_cast<double>(s->analysis->length));
            const auto minGap = static_cast<std::int64_t>(0.02 * s->rate);
            if (ToneEditing::movePoint(s->edit, _dragSource, static_cast<std::int64_t>(std::llround(targetRes)), s->analysis->length, minGap)) [c toneEdited:@"Bend Time"];
            break;
        }
        case Drag::Draw:
            _drawTo = [self sourceAtResult:[self resultAtX:p.x] map:currentMap];
            break;
        case Drag::None: break;
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    SilvetonController* c = self.controller;
    SVToneSession* s = [self session];
    const Drag drag = _drag;
    _drag = Drag::None;
    if (![self ready]) return;
    if (drag == Drag::Pitch || drag == Drag::EdgeEdit || drag == Drag::TimeMove || drag == Drag::EdgeStretch || drag == Drag::WarpPoint) [c toneDragEnded];
    if (drag == Drag::Rubber && !_moved) {      // a plain click on the empty grid moves the playhead
        [self seekAtX:_down.x];
    }
    if (drag == Drag::Draw && _moved) {
        const std::int64_t a = std::min(_drawFrom, _drawTo), b = std::max(_drawFrom, _drawTo);
        const std::int64_t minLen = std::max<std::int64_t>(static_cast<std::int64_t>(0.04 * s->rate), 1);
        if (b - a >= minLen) {
            const std::uint32_t id = ToneEditing::add(s->edit, *s->analysis, a, b, _drawPitch);
            if (id != 0U) { [c toneSetSelection:std::vector<std::uint32_t>{id}]; [c toneEdited:@"Draw Segment"]; }
            else [c setStatus:@"A segment cannot be drawn here — it would touch another segment"];
        }
    }
    [self setNeedsDisplay:YES];
}

- (void)rightMouseDown:(NSEvent*)event {
    if (![self ready]) { [super rightMouseDown:event]; return; }
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    SilvetonController* c = self.controller;
    SVToneSession* s = [self session];
    if ([self inGrid:p]) {
        const ToneTimeMap map = [self timeMap];
        const Hit hit = [self hitAt:p requireY:YES map:map];
        if (hit.block && !s->selectedHas(hit.block->id)) [c toneSetSelection:std::vector<std::uint32_t>{hit.block->id}];
    }
    [NSMenu popUpContextMenu:[c toneContextMenu] withEvent:event forView:self];
}

// ================================================================== wheel ==
- (void)scrollWheel:(NSEvent*)event {
    if (![self ready]) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const NSRect g = [self gridRect];
    double dx = event.scrollingDeltaX, dy = event.scrollingDeltaY;
    if (!event.hasPreciseScrollingDeltas) { dx *= 12.0; dy *= 12.0; }
    const NSEventModifierFlags mods = event.modifierFlags;
    if (mods & NSEventModifierFlagCommand) {          // taller or shorter rows
        const double before = [self midiAtY:p.y];
        _semiH = std::clamp(_semiH * std::exp(dy * 0.01), 8.0, 60.0);
        _topMidi += before - [self midiAtY:p.y];
        [self clampPitchView];
    } else if (mods & (NSEventModifierFlagOption | NSEventModifierFlagControl)) {   // zoom in time around the mouse
        _vp.zoomAbout(std::min(std::max(p.x - g.origin.x, 0.0), g.size.width), std::exp(-dy * 0.015));
    } else if (mods & NSEventModifierFlagShift) {
        _vp.scrollPixels(-(std::abs(dx) > std::abs(dy) ? dx : dy));
    } else {
        if (std::abs(dx) > 0.0) _vp.scrollPixels(-dx);
        _topMidi += dy / _semiH;
        [self clampPitchView];
    }
    [self setNeedsDisplay:YES];
}

- (void)magnifyWithEvent:(NSEvent*)event {
    if (![self ready]) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const NSRect g = [self gridRect];
    _vp.zoomAbout(std::min(std::max(p.x - g.origin.x, 0.0), g.size.width), std::max(0.2, 1.0 - event.magnification));
    [self setNeedsDisplay:YES];
}

// =================================================================== keys ==
- (void)keyDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    NSString* chars = event.charactersIgnoringModifiers;
    const unichar ch = chars.length ? [chars characterAtIndex:0] : 0;
    const NSEventModifierFlags mods = event.modifierFlags;
    if (event.keyCode == 53) { [c toneSetSelection:std::vector<std::uint32_t>()]; return; }     // Esc
    if (![self ready]) { [super keyDown:event]; return; }
    if (ch >= '1' && ch <= '6' && !(mods & NSEventModifierFlagCommand)) { [c setToneTool:static_cast<SVToneTool>(ch - '1')]; return; }
    if (ch == NSUpArrowFunctionKey) { if (mods & NSEventModifierFlagShift) [c toneOctaveUp:nil]; else [c toneUp:nil]; return; }
    if (ch == NSDownArrowFunctionKey) { if (mods & NSEventModifierFlagShift) [c toneOctaveDown:nil]; else [c toneDown:nil]; return; }
    if (ch == NSHomeFunctionKey) { _vp.first = 0.0; [self setNeedsDisplay:YES]; return; }
    if (ch == '+' || ch == '=') { [self zoomBy:0.6]; return; }
    if (ch == '-') { [self zoomBy:1.0 / 0.6]; return; }
    if (ch == '0') { [self zoomFit]; return; }
    [super keyDown:event];
}

- (NSMenu*)menuForEvent:(NSEvent*)event { (void)event; return nil; }   // the right mouse button is handled in rightMouseDown:

@end
