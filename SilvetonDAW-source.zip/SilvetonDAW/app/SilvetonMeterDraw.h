// One look for every level meter in Silveton (console strips, the master meter
// in the transport deck, the small meter in each track header).
//
//  * LED-style segments (3 px pitch) with the unlit segments faintly visible,
//    so the scale reads like a real meter;
//  * four colour zones: green -> amber (-12 dB) -> copper (-3 dB) -> red (0 dB);
//  * a peak-hold marker and a latched clip lamp;
//  * the position along the meter follows the FADER scale, so 0 dB on the meter
//    is level with 0 dB on the fader.
//
// All views using it are flipped (y grows downwards).
#pragma once
#import <AppKit/AppKit.h>

#include "SilvetonTheme.h"
#include "silveton/MeterBank.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <cstdint>

namespace sv {
namespace meter {

constexpr CGFloat kPitch = 3.0;           // one LED segment = 2 px lit + 1 px gap
constexpr double kHoldVisibleDb = 0.7;    // the marker is drawn once it is this far above the bar

inline NSColor* well() { return hex(0x0E0D10); }

inline double position(double db) { return silveton::faderPositionForDb(db); }

// Opaque blend of `a` over `b` (NSRectFill ignores alpha, so no translucent colours).
inline NSColor* mixed(std::uint32_t a, std::uint32_t b, double t) {
    auto ch = [&](int shift) {
        const double x = ((a >> shift) & 0xFF) * t + ((b >> shift) & 0xFF) * (1.0 - t);
        return static_cast<std::uint32_t>(std::lround(std::min(255.0, std::max(0.0, x))));
    };
    return hex((ch(16) << 16) | (ch(8) << 8) | ch(0));
}

inline NSColor* zoneColor(int zone) {
    static NSColor* colors[4] = {hex(0x548A64), hex(0xC8AC68), hex(0xDE8F52), hex(0xD06852)};
    return colors[std::max(0, std::min(3, zone))];
}
inline NSColor* zoneDimColor(int zone) {
    static NSColor* dim[4] = {mixed(0x548A64, 0x0E0D10, 0.22), mixed(0xC8AC68, 0x0E0D10, 0.22),
                              mixed(0xDE8F52, 0x0E0D10, 0.24), mixed(0xD06852, 0x0E0D10, 0.28)};
    return dim[std::max(0, std::min(3, zone))];
}

// Segment-snapped length (in px, measured from the start of the bar) for a level.
inline CGFloat litLength(double db, CGFloat length, bool segmented) {
    (void)segmented;                 // flat look: smooth bars, no LED segments
    const CGFloat pitch = 1.0;
    const double p = std::max(0.0, std::min(1.0, position(db)));
    return std::min(length, std::floor(p * length / pitch + 1.0e-6) * pitch);
}

// Draws one bar. `vertical`: level grows upwards from the bottom edge; otherwise
// from the left edge to the right.
inline void drawBar(NSRect r, bool vertical, double levelDb, double holdDb, bool clip, bool segmented) {
    const CGFloat length = vertical ? r.size.height : r.size.width;
    if (length < 6.0 || (vertical ? r.size.width : r.size.height) < 1.0) return;
    (void)segmented;
    const CGFloat pitch = 1.0;
    fill(r, well());

    auto piece = [&](CGFloat from, CGFloat to) {
        return vertical ? NSMakeRect(r.origin.x, NSMaxY(r) - to, r.size.width, to - from)
                        : NSMakeRect(r.origin.x + from, r.origin.y, to - from, r.size.height);
    };

    CGFloat edge[5] = {0.0, 0.0, 0.0, 0.0, length};
    const double zoneDb[3] = {-12.0, -3.0, 0.0};
    for (int i = 0; i < 3; ++i)
        edge[i + 1] = std::min(length, std::round(position(zoneDb[i]) * length / pitch) * pitch);
    const CGFloat lit = litLength(levelDb, length, segmented);

    for (int zone = 0; zone < 4; ++zone) {
        const CGFloat a = edge[zone], b = edge[zone + 1];
        if (b <= a) continue;
        if (lit > a) fill(piece(a, std::min(b, lit)), zoneColor(zone));   // unlit = the dark well, nothing else
    }

    if (holdDb > levelDb + kHoldVisibleDb && position(holdDb) > 0.0) {
        const CGFloat at = litLength(holdDb, length, segmented);
        const CGFloat thickness = 1.0;
        if (at + thickness <= length + 0.01) fill(piece(at, at + thickness), clip ? rec() : ink());
    }
}

inline void drawClipLamp(NSRect r, bool on) {
    roundFill(r, 1.5, on ? rec() : mixed(0xE0533F, 0x0E0D10, 0.22));
}

// A cheap fingerprint of what a stereo bar pair will look like (segment-snapped),
// so a view repaints only when something visibly moved.
inline std::uint32_t signature(const silveton::StereoMeterDisplay& d, CGFloat length, bool segmented) {
    auto mix = [](std::uint32_t h, std::uint32_t v) { return (h ^ v) * 16777619U; };
    auto channel = [&](std::uint32_t h, const silveton::MeterChannelDisplay& m) {
        h = mix(h, static_cast<std::uint32_t>(litLength(m.levelDb, length, segmented)));
        const bool holdShown = m.holdDb > m.levelDb + kHoldVisibleDb;
        h = mix(h, holdShown ? static_cast<std::uint32_t>(litLength(m.holdDb, length, segmented)) + 1U : 0U);
        return mix(h, m.clip ? 1U : 0U);
    };
    return channel(channel(2166136261U, d.left), d.right);
}

inline NSString* dbLabel(double db) {
    if (db <= -99.0) return @"-∞";
    return db > 0.05 ? [NSString stringWithFormat:@"+%d", static_cast<int>(std::lround(db))]
                     : [NSString stringWithFormat:@"%d", static_cast<int>(std::lround(db))];
}

} // namespace meter
} // namespace sv
