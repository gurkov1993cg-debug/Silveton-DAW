// Project-page furniture: the page layout helper, the tool row above the tracks and the level panel
// on the right. (The mixer under the tracks is SilvetonConsoleView in its compact form.)
#import "SilvetonViews.h"
#include "SilvetonMeterDraw.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <cstdint>

using namespace silveton;

// ================================================================ layout ==
@implementation SilvetonLayoutView
- (void)setFrameSize:(NSSize)size {
    [super setFrameSize:size];
    if (self.onLayout) self.onLayout();
}
@end

// =============================================================== tool row ==
namespace {
enum BarItem { kBarSnap, kBarGrid, kBarSmall, kBarNormal, kBarLarge, kBarHuge, kBarZoomTrack, kBarZoom,
               kBarInspector, kBarMixer, kBarLevel, kBarCount };
constexpr double kMinPps = 2.0, kMaxPps = 2000.0;
}

@implementation SilvetonToolBar {
    NSRect _hit[kBarCount];
    BOOL _dragZoom;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }

- (void)drawKeyIn:(NSRect)r title:(NSString*)title lit:(BOOL)lit {
    sv::keyCap(r, 5.0, lit, sv::copper());
    sv::textIn(title, NSMakeRect(r.origin.x, r.origin.y + (r.size.height - 2.0) * 0.5 - 7.0, r.size.width, 15.0),
               sv::ui(10, true), lit ? sv::copper() : sv::inkDim(), NSTextAlignmentCenter);
}
- (void)label:(NSString*)title at:(CGFloat)x {
    sv::text(title, NSMakePoint(x, 10), sv::ui(10, true), sv::inkFaint());
}
- (double)zoomFraction {
    const double pps = std::max(kMinPps, std::min(kMaxPps, self.controller.pixelsPerSecond));
    return std::log(pps / kMinPps) / std::log(kMaxPps / kMinPps);
}

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    SilvetonController* c = self.controller;
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    sv::line(NSMakePoint(0, b.size.height - 0.5), NSMakePoint(b.size.width, b.size.height - 0.5), sv::hairline());
    if (!c) return;
    const CGFloat y = 5.0, h = 24.0;
    CGFloat x = 12.0;

    _hit[kBarSnap] = NSMakeRect(x, y, 54, h);
    [self drawKeyIn:_hit[kBarSnap] title:@"SNAP" lit:c.snapEnabled];
    x += 54 + 14;

    [self label:@"GRID" at:x];
    x += 36;
    _hit[kBarGrid] = NSMakeRect(x, y, 72, h);
    sv::wellFill(_hit[kBarGrid], 4.0);
    NSString* gridText = [NSString stringWithFormat:@"1/%u", static_cast<unsigned>(4U * std::max<std::uint32_t>(1U, c.gridDivisionsPerQuarter))];
    sv::textIn(gridText, NSMakeRect(x + 8, y + 5, 44, 15), sv::mono(11, true), sv::lcdValue());
    NSBezierPath* caret = [NSBezierPath bezierPath];
    [caret moveToPoint:NSMakePoint(x + 72 - 17, y + h * 0.5 - 2)];
    [caret lineToPoint:NSMakePoint(x + 72 - 9, y + h * 0.5 - 2)];
    [caret lineToPoint:NSMakePoint(x + 72 - 13, y + h * 0.5 + 3)];
    [caret closePath];
    [sv::inkFaint() setFill];
    [caret fill];
    x += 72 + 14;

    [self label:@"HEIGHT" at:x];
    x += 46;
    NSArray<NSString*>* heights = @[@"S", @"M", @"L", @"XL"];
    for (int i = 0; i < 4; ++i) {
        _hit[kBarSmall + i] = NSMakeRect(x, y, 28, h);
        [self drawKeyIn:_hit[kBarSmall + i] title:heights[static_cast<NSUInteger>(i)] lit:NO];
        x += 28 + 3;
    }
    x += 11;
    _hit[kBarZoomTrack] = NSMakeRect(x, y, 90, h);
    [self drawKeyIn:_hit[kBarZoomTrack] title:@"ZOOM TRACK" lit:NO];
    x += 90 + 14;

    [self label:@"ZOOM" at:x];
    x += 40;
    _hit[kBarZoom] = NSMakeRect(x, y, 120, h);
    const CGFloat midY = y + h * 0.5;
    const double t = [self zoomFraction];
    sv::roundFill(NSMakeRect(x, midY - 1.5, 120, 3), 1.5, sv::hex(0x101114));
    sv::roundFill(NSMakeRect(x, midY - 1.5, static_cast<CGFloat>(120.0 * t), 3), 1.5, sv::inkFaint());
    sv::roundFill(NSMakeRect(x + static_cast<CGFloat>(120.0 * t) - 3, midY - 6, 6, 12), 2, sv::hex(0xE2E2DE));

    // Panel switches on the right: Inspector | Mixer | Level
    NSArray<NSString*>* names = @[@"INSPECTOR", @"MIXER", @"LEVEL"];
    const BOOL on[3] = {c.channelPanelShown, c.dockMixerShown, c.meterPanelShown};
    CGFloat rx = b.size.width - 12.0;
    for (int i = 2; i >= 0; --i) {
        NSString* title = names[static_cast<NSUInteger>(i)];
        const CGFloat w = std::ceil(sv::textSize(title, sv::ui(10, true)).width) + 26.0;
        rx -= w;
        _hit[kBarInspector + i] = NSMakeRect(rx, y, w, h);
        [self drawKeyIn:_hit[kBarInspector + i] title:title lit:on[i]];
        rx -= 4.0;
    }
}

- (void)setZoomFromX:(CGFloat)px {
    const NSRect r = _hit[kBarZoom];
    if (r.size.width < 1.0) return;
    const double t = sv::clamp01((px - r.origin.x) / r.size.width);
    [self.controller setPixelsPerSecond:kMinPps * std::pow(kMaxPps / kMinPps, t)];
    [self setNeedsDisplay:YES];
}

- (void)mouseDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (!c) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    for (int i = 0; i < kBarCount; ++i) {
        if (!NSPointInRect(p, i == kBarZoom ? NSInsetRect(_hit[i], -6, 0) : _hit[i])) continue;
        switch (i) {
            case kBarSnap: [c toggleSnap:nil]; break;
            case kBarGrid: {
                NSMenu* menu = [[NSMenu alloc] initWithTitle:@"Grid"];
                NSArray<NSString*>* titles = @[@"1/4", @"1/8", @"1/16", @"1/32"];
                const std::uint32_t divs[4] = {1U, 2U, 4U, 8U};
                for (int k = 0; k < 4; ++k) {
                    NSMenuItem* it = [menu addItemWithTitle:titles[static_cast<NSUInteger>(k)] action:@selector(pickGrid:) keyEquivalent:@""];
                    it.target = c;
                    it.tag = static_cast<NSInteger>(divs[k]);
                    if (divs[k] == c.gridDivisionsPerQuarter) it.state = NSControlStateValueOn;
                }
                [NSMenu popUpContextMenu:menu withEvent:event forView:self];
                break;
            }
            case kBarSmall: case kBarNormal: case kBarLarge: case kBarHuge: {
                static const NSInteger tags[4] = {32, 0, 96, 192};   // the same values as View > Track Height
                NSMenuItem* it = [[NSMenuItem alloc] init];
                it.tag = tags[i - kBarSmall];
                [c setTrackHeight:it];
                break;
            }
            case kBarZoomTrack: {
                NSMenuItem* it = [[NSMenuItem alloc] init];
                it.tag = -2;
                [c setTrackHeight:it];
                break;
            }
            case kBarZoom: _dragZoom = YES; [self setZoomFromX:p.x]; return;
            case kBarInspector: [c toggleChannelPanel:nil]; break;
            case kBarMixer: [c toggleDockMixer:nil]; break;
            case kBarLevel: [c toggleMeterPanel:nil]; break;
            default: break;
        }
        [self setNeedsDisplay:YES];
        return;
    }
}
- (void)mouseDragged:(NSEvent*)event {
    if (!_dragZoom) return;
    [self setZoomFromX:[self convertPoint:event.locationInWindow fromView:nil].x];
}
- (void)mouseUp:(NSEvent*)event { (void)event; _dragZoom = NO; }
@end

// ============================================================ level panel ==
namespace {
void sectionTitle(NSString* title, NSPoint at) {
    NSDictionary* attrs = @{NSFontAttributeName: sv::ui(10, true), NSForegroundColorAttributeName: sv::gold(), NSKernAttributeName: @(1.8)};
    [title drawAtPoint:at withAttributes:attrs];
}
NSString* kiloHertz(double hz) {
    const double k = hz / 1000.0;
    return std::abs(k - std::round(k)) < 0.001 ? [NSString stringWithFormat:@"%.0f kHz", k] : [NSString stringWithFormat:@"%.1f kHz", k];
}
}

@implementation SilvetonMeterPanel {
    std::uint32_t _sig;
    NSRect _meterRect;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }

- (CGFloat)meterHeight {
    return std::max<CGFloat>(80.0, std::min<CGFloat>(230.0, self.bounds.size.height - 100.0 - 190.0));
}

- (void)tick {
    SilvetonController* c = self.controller;
    if (!c || !c.core || !c.core->ready()) return;
    const StereoMeterDisplay md = [c masterMeterDisplay];
    const std::uint32_t sig = sv::meter::signature(md, [self meterHeight], true) ^
        (static_cast<std::uint32_t>(std::lround(std::max(-99.0F, md.maxDb()) * 10.0F) + 1000) * 40503U);
    if (sig == _sig) return;
    _sig = sig;
    [self setNeedsDisplayInRect:NSMakeRect(0, 20, self.bounds.size.width, 100.0 + [self meterHeight])];
}

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    SilvetonController* c = self.controller;
    const NSRect b = self.bounds;
    const CGFloat w = b.size.width;
    sv::fill(b, sv::canvas());
    sv::line(NSMakePoint(0.5, 0), NSMakePoint(0.5, b.size.height), sv::hairline());
    sectionTitle(@"LEVEL", NSMakePoint(14, 8));
    if (!c || !c.project || !c.core) return;

    // Master peak read-out on a light display
    const StereoMeterDisplay md = [c masterMeterDisplay];
    const NSRect lcdRect = NSMakeRect(10, 26, w - 20, 60);
    sv::lcd(lcdRect, 8.0);
    sv::text(@"MASTER PEAK", NSMakePoint(20, 31), sv::ui(10, true), sv::lcdDim());
    const float maxDb = md.maxDb();
    NSString* peak = maxDb <= -99.0F ? @"-∞" : [NSString stringWithFormat:@"%.1f", maxDb];
    NSFont* big = sv::mono(26, true);
    sv::text(peak, NSMakePoint(20, 46), big, maxDb > 0.0F ? sv::rec() : sv::copper());
    sv::text(@"dB", NSMakePoint(20 + std::ceil(sv::textSize(peak, big).width) + 4, 60), sv::mono(11), sv::lcdValue());
    const float hold = std::max(md.left.holdDb, md.right.holdDb);
    sv::textIn(hold <= -99.0F ? @"" : [NSString stringWithFormat:@"hold %.1f", hold], NSMakeRect(w - 100, 31, 82, 13), sv::mono(10), sv::lcdValue(), NSTextAlignmentRight);

    // Big stereo meter
    const CGFloat meterH = [self meterHeight];
    _meterRect = NSMakeRect(10, 96, w - 20, meterH);
    sv::wellFill(_meterRect, 5.0);
    const CGFloat barW = 18.0, barX = std::floor(NSMidX(_meterRect) - barW - 3.0 + 14.0);
    const NSRect left = NSMakeRect(barX, _meterRect.origin.y + 14, barW, meterH - 22);
    sv::meter::drawClipLamp(NSMakeRect(barX, _meterRect.origin.y + 6, barW * 2.0 + 6.0, 5), md.clip());
    sv::meter::drawBar(left, true, md.left.levelDb, md.left.holdDb, md.left.clip, true);
    sv::meter::drawBar(NSMakeRect(barX + barW + 6.0, left.origin.y, barW, left.size.height), true, md.right.levelDb, md.right.holdDb, md.right.clip, true);
    CGFloat lastLabelY = -1.0e9;
    for (double db : {6.0, 0.0, -6.0, -12.0, -24.0, -40.0, -60.0}) {
        const CGFloat ty = std::round(NSMaxY(left) - left.size.height * sv::meter::position(db));
        NSColor* tone = db == 0.0 ? sv::inkDim() : sv::inkFaint();
        sv::line(NSMakePoint(barX - 5, ty + 0.5), NSMakePoint(barX - 1, ty + 0.5), tone);
        if (ty - lastLabelY < 13.0) continue;
        lastLabelY = ty;
        sv::textIn(sv::meter::dbLabel(db), NSMakeRect(barX - 44, ty - 6, 36, 12), sv::mono(10), tone, NSTextAlignmentRight);
    }

    // Details of what is selected
    const Project& p = *c.project;
    const double sr = p.sampleRate > 0.0 ? p.sampleRate : 48000.0;
    NSString* heading = @"DETAILS";
    NSMutableArray<NSArray<NSString*>*>* rows = [NSMutableArray array];
    const ProjectAudioClip* clip = nullptr;
    if (c.selectedTrack >= 0 && static_cast<std::size_t>(c.selectedTrack) < p.tracks.size() && c.selectedClipId != 0U)
        for (const auto& cl : p.tracks[static_cast<std::size_t>(c.selectedTrack)].clips)
            if (cl.id == c.selectedClipId) clip = &cl;
    if (clip) {
        heading = @"SELECTED CLIP";
        const auto& t = p.tracks[static_cast<std::size_t>(c.selectedTrack)];
        NSString* nm = [[sv::ns(clip->audioPath.empty() ? t.audioPath : clip->audioPath) lastPathComponent] stringByDeletingPathExtension];
        [rows addObject:@[@"Name", nm.length ? nm : @"—"]];
        [rows addObject:@[@"Start", sv::ns(formatBarsBeats(p.tempoMap, clip->timelineStartSample))]];
        [rows addObject:@[@"Length", sv::ns(formatClock(static_cast<double>(clip->lengthSamples) / sr))]];
        [rows addObject:@[@"Gain", [NSString stringWithFormat:@"%+.1f dB", clip->gainDb]]];
        [rows addObject:@[@"Fades", [NSString stringWithFormat:@"%.0f / %.0f ms", clip->fadeInSamples * 1000.0 / sr, clip->fadeOutSamples * 1000.0 / sr]]];
        if (clip->sourceSampleRate > 0U) {
            NSString* file = kiloHertz(static_cast<double>(clip->sourceSampleRate));
            if (std::abs(static_cast<double>(clip->sourceSampleRate) - sr) > 0.5) file = [NSString stringWithFormat:@"%@ → %@", file, kiloHertz(sr)];
            [rows addObject:@[@"File rate", file]];
        }
    } else if (c.selectedMidiTrack >= 0 && static_cast<std::size_t>(c.selectedMidiTrack) < p.midiTracks.size() && c.selectedPartId != 0U) {
        const auto& mt = p.midiTracks[static_cast<std::size_t>(c.selectedMidiTrack)];
        for (const auto& part : mt.parts) {
            if (part.id != c.selectedPartId) continue;
            heading = @"SELECTED PART";
            [rows addObject:@[@"Track", sv::ns(mt.name.empty() ? std::string("MIDI") : mt.name)]];
            [rows addObject:@[@"Start", sv::ns(formatBarsBeats(p.tempoMap, p.tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes)))]];
            [rows addObject:@[@"Length", [NSString stringWithFormat:@"%.1f quarters", part.lengthQuarterNotes]]];
            [rows addObject:@[@"Notes", [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(part.sequence.notes().size())]]];
            break;
        }
    } else if (c.selectedTrack >= 0 && static_cast<std::size_t>(c.selectedTrack) < p.tracks.size()) {
        const auto& t = p.tracks[static_cast<std::size_t>(c.selectedTrack)];
        heading = @"SELECTED TRACK";
        [rows addObject:@[@"Name", sv::ns(t.name.empty() ? std::string("Audio") : t.name)]];
        [rows addObject:@[@"Level", [NSString stringWithFormat:@"%+.1f dB", t.gainDb]]];
        [rows addObject:@[@"Pan", std::abs(t.pan) < 0.005 ? @"C" : [NSString stringWithFormat:@"%@%d", t.pan < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(t.pan) * 100))]]];
        [rows addObject:@[@"Inserts", [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(t.pluginSlots.size())]]];
        [rows addObject:@[@"Clips", [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(t.clips.size())]]];
    }
    CGFloat y = NSMaxY(_meterRect) + 16.0;
    sectionTitle(heading, NSMakePoint(14, y));
    y += 22.0;
    if (rows.count == 0U) {
        sv::textIn(@"Click a clip or a track", NSMakeRect(14, y, w - 28, 15), sv::ui(11), sv::inkFaint());
        sv::textIn(@"to see its details here.", NSMakeRect(14, y + 16, w - 28, 15), sv::ui(11), sv::inkFaint());
        return;
    }
    for (NSArray<NSString*>* row in rows) {
        if (y + 18.0 > b.size.height) break;
        sv::text(row[0], NSMakePoint(14, y), sv::ui(10), sv::inkFaint());
        sv::textIn(row[1], NSMakeRect(66, y - 1, w - 66 - 12, 14), sv::mono(10), sv::lcdValue(), NSTextAlignmentRight);
        sv::line(NSMakePoint(14, y + 16.5), NSMakePoint(w - 12, y + 16.5), sv::rgb(1, 1, 1, 0.05));
        y += 20.0;
    }
}

- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (!NSPointInRect(p, _meterRect) || !self.controller) return;
    SVStrip master;
    master.kind = SVStripKind::Master;
    [self.controller resetMetersForStrip:master all:(event.modifierFlags & NSEventModifierFlagOption) != 0];
    [self setNeedsDisplay:YES];
}
@end
