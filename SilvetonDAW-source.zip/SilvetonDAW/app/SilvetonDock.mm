// Project-page furniture: the page layout helper, the tool row above the tracks and the level panel
// on the right. (The mixer under the tracks is SilvetonConsoleView in its compact form.)
#import "SilvetonViews.h"
#include "SilvetonMeterDraw.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/SampleEditorModel.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <cstdint>

using namespace silveton;

// ================================================================ layout ==
@implementation SilvetonLayoutView
- (void)setFrameSize:(NSSize)size {
    [super setFrameSize:size];
    if (self.onLayout) self.onLayout();
}
@end

// =============================================================== tool row ==
namespace {
enum BarItem { kBarTool0, kBarTool1, kBarTool2, kBarTool3, kBarTool4, kBarTool5, kBarTool6, kBarTool7,
               kBarSnap, kBarGrid, kBarHeight, kBarZoom, kBarFit, kBarWave, kBarInspector, kBarZone, kBarLevel, kBarCount };
constexpr int kToolCount = 8;
constexpr double kMinPps = 2.0, kMaxPps = 1500000.0;   // the slider reaches single samples (see setPixelsPerSecond:)

// The small pictures on the tool keys (flipped view, `r` is the key face).
void drawToolGlyph(int tool, NSRect r, NSColor* ink) {
    const CGFloat cx = NSMidX(r), cy = NSMidY(r) - 1.0;
    [ink setFill];
    [ink setStroke];
    NSBezierPath* p = [NSBezierPath bezierPath];
    p.lineWidth = 1.6;
    p.lineCapStyle = NSRoundLineCapStyle;
    p.lineJoinStyle = NSRoundLineJoinStyle;
    switch (tool) {
        case 0: {   // Object Selection: the pointer
            [p moveToPoint:NSMakePoint(cx - 4, cy - 6)];
            [p lineToPoint:NSMakePoint(cx - 4, cy + 5)];
            [p lineToPoint:NSMakePoint(cx - 1, cy + 2.5)];
            [p lineToPoint:NSMakePoint(cx + 1, cy + 6.5)];
            [p lineToPoint:NSMakePoint(cx + 3, cy + 5.5)];
            [p lineToPoint:NSMakePoint(cx + 1, cy + 1.5)];
            [p lineToPoint:NSMakePoint(cx + 5, cy + 1.5)];
            [p closePath];
            [p fill];
            break;
        }
        case 1: {   // Range Selection: a dashed box with the I-beam
            NSBezierPath* box = [NSBezierPath bezierPathWithRect:NSMakeRect(cx - 6.5, cy - 4.5, 13, 9)];
            const CGFloat dash[2] = {2.0, 2.0};
            [box setLineDash:dash count:2 phase:0];
            box.lineWidth = 1.2;
            [box stroke];
            [p moveToPoint:NSMakePoint(cx, cy - 6.5)];
            [p lineToPoint:NSMakePoint(cx, cy + 6.5)];
            [p moveToPoint:NSMakePoint(cx - 2, cy - 6.5)];
            [p lineToPoint:NSMakePoint(cx + 2, cy - 6.5)];
            [p moveToPoint:NSMakePoint(cx - 2, cy + 6.5)];
            [p lineToPoint:NSMakePoint(cx + 2, cy + 6.5)];
            [p stroke];
            break;
        }
        case 2: {   // Split: scissors
            [p moveToPoint:NSMakePoint(cx - 3.5, cy - 6.5)];
            [p lineToPoint:NSMakePoint(cx + 3.0, cy + 2.5)];
            [p moveToPoint:NSMakePoint(cx + 3.5, cy - 6.5)];
            [p lineToPoint:NSMakePoint(cx - 3.0, cy + 2.5)];
            [p stroke];
            NSBezierPath* a = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(cx - 6.5, cy + 2.0, 4.5, 4.5)];
            NSBezierPath* b = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(cx + 2.0, cy + 2.0, 4.5, 4.5)];
            a.lineWidth = b.lineWidth = 1.4;
            [a stroke];
            [b stroke];
            break;
        }
        case 3: {   // Glue: the tube
            [[NSBezierPath bezierPathWithRoundedRect:NSMakeRect(cx - 3.5, cy - 1.5, 7, 8.5) xRadius:1.5 yRadius:1.5] fill];
            [[NSBezierPath bezierPathWithRect:NSMakeRect(cx - 1.5, cy - 5.0, 3, 3.5)] fill];
            [[NSBezierPath bezierPathWithRect:NSMakeRect(cx - 0.75, cy - 7.0, 1.5, 2.0)] fill];
            break;
        }
        case 4: {   // Erase: the eraser
            [p moveToPoint:NSMakePoint(cx - 6.5, cy + 2.5)];
            [p lineToPoint:NSMakePoint(cx + 1.5, cy - 5.5)];
            [p lineToPoint:NSMakePoint(cx + 6.5, cy - 0.5)];
            [p lineToPoint:NSMakePoint(cx - 1.5, cy + 7.5)];
            [p closePath];
            [p fill];
            NSBezierPath* cut = [NSBezierPath bezierPath];
            cut.lineWidth = 1.2;
            [cut moveToPoint:NSMakePoint(cx - 2.5, cy - 1.5)];
            [cut lineToPoint:NSMakePoint(cx + 2.5, cy + 3.5)];
            [[NSColor colorWithCalibratedWhite:0.12 alpha:0.85] setStroke];
            [cut stroke];
            break;
        }
        case 5: {   // Zoom: the magnifier
            NSBezierPath* lens = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(cx - 6.5, cy - 6.5, 9.5, 9.5)];
            lens.lineWidth = 1.7;
            [lens stroke];
            NSBezierPath* handle = [NSBezierPath bezierPath];
            handle.lineWidth = 2.4;
            handle.lineCapStyle = NSRoundLineCapStyle;
            [handle moveToPoint:NSMakePoint(cx + 1.8, cy + 1.8)];
            [handle lineToPoint:NSMakePoint(cx + 6.5, cy + 6.5)];
            [handle stroke];
            break;
        }
        case 6: {   // Mute: the cross
            p.lineWidth = 2.2;
            [p moveToPoint:NSMakePoint(cx - 5, cy - 5)];
            [p lineToPoint:NSMakePoint(cx + 5, cy + 5)];
            [p moveToPoint:NSMakePoint(cx + 5, cy - 5)];
            [p lineToPoint:NSMakePoint(cx - 5, cy + 5)];
            [p stroke];
            break;
        }
        case 7: {   // Draw: the pencil
            NSBezierPath* body = [NSBezierPath bezierPath];
            body.lineWidth = 3.2;
            body.lineCapStyle = NSButtLineCapStyle;
            [body moveToPoint:NSMakePoint(cx - 3.0, cy + 3.0)];
            [body lineToPoint:NSMakePoint(cx + 5.5, cy - 5.5)];
            [body stroke];
            [p moveToPoint:NSMakePoint(cx - 4.2, cy + 1.8)];
            [p lineToPoint:NSMakePoint(cx - 1.8, cy + 4.2)];
            [p lineToPoint:NSMakePoint(cx - 6.0, cy + 6.0)];
            [p closePath];
            [p fill];
            break;
        }
        default: break;
    }
}

NSArray<NSString*>* toolTips() {
    return @[@"Object Selection (1): click selects, drag moves, the edges trim",
             @"Range Selection (2): drag over the tracks to mark a range — Delete, ⌘X, ⌘C, ⌘V and Edit ▸ Range work on it",
             @"Split (3): click a clip or part to cut it there",
             @"Glue (4): join a clip or part with the next one",
             @"Erase (5): click a clip or part to remove it",
             @"Zoom (6): click zooms in, ⌥ click zooms out, drag a box to zoom to it",
             @"Mute (7): click a clip or part to mute it",
             @"Draw (8): drag on a MIDI track to create a part"];
}
}

@implementation SilvetonToolBar {
    NSRect _hit[kBarCount];
    BOOL _dragZoom;
    BOOL _dragWave;
    BOOL _tipsSet;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }

- (void)drawKeyIn:(NSRect)r title:(NSString*)title lit:(BOOL)lit {
    sv::keyCap(r, 5.0, lit, sv::copper());
    sv::textIn(title, NSMakeRect(r.origin.x, r.origin.y + (r.size.height - 2.0) * 0.5 - 7.0, r.size.width, 15.0),
               sv::ui(10, true), lit ? sv::copper() : sv::inkDim(), NSTextAlignmentCenter);
}
- (void)label:(NSString*)title at:(CGFloat)x {
    sv::engraved(title, NSMakePoint(x, 10), sv::ui(10, true), sv::hex(0x8A8F9A));
}
- (double)zoomFraction {
    const double pps = std::max(kMinPps, std::min(kMaxPps, self.controller.pixelsPerSecond));
    return std::log(pps / kMinPps) / std::log(kMaxPps / kMinPps);
}
- (void)drawPopupWell:(NSRect)r text:(NSString*)text {
    sv::wellFill(r, 4.0);
    sv::textIn(text, NSMakeRect(r.origin.x + 8, r.origin.y + 5, r.size.width - 28, 15), sv::mono(11, true), sv::lcdValue());
    NSBezierPath* caret = [NSBezierPath bezierPath];
    [caret moveToPoint:NSMakePoint(NSMaxX(r) - 17, r.origin.y + r.size.height * 0.5 - 2)];
    [caret lineToPoint:NSMakePoint(NSMaxX(r) - 9, r.origin.y + r.size.height * 0.5 - 2)];
    [caret lineToPoint:NSMakePoint(NSMaxX(r) - 13, r.origin.y + r.size.height * 0.5 + 3)];
    [caret closePath];
    [sv::inkFaint() setFill];
    [caret fill];
}
// Tool tips over the tool keys (their places never change: they sit at the left edge).
- (NSString*)view:(NSView*)view stringForToolTip:(NSToolTipTag)tag point:(NSPoint)point userData:(void*)data {
    (void)view; (void)tag; (void)point;
    const NSUInteger i = static_cast<NSUInteger>(reinterpret_cast<std::intptr_t>(data));
    NSArray<NSString*>* tips = toolTips();
    return i < tips.count ? tips[i] : @"";
}

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    SilvetonController* c = self.controller;
    const NSRect b = self.bounds;
    sv::rail(b);
    if (!c) return;
    const CGFloat y = 5.0, h = 24.0;
    CGFloat x = 12.0;

    // The tools (as the tool buttons of Cubase): keys 1–8.
    const int tool = static_cast<int>(c.arrangeTool);
    for (int i = 0; i < kToolCount; ++i) {
        _hit[kBarTool0 + i] = NSMakeRect(x, y, 26, h);
        const bool lit = i == tool;
        sv::keyCap(_hit[kBarTool0 + i], 5.0, lit, sv::copper());
        drawToolGlyph(i, NSMakeRect(x, y, 26, h - 2.0), lit ? sv::copper() : sv::hex(0xC9CCD2));
        x += 26 + 3;
    }
    if (!_tipsSet) {
        for (int i = 0; i < kToolCount; ++i)
            [self addToolTipRect:_hit[kBarTool0 + i] owner:self userData:reinterpret_cast<void*>(static_cast<std::intptr_t>(i))];
        _tipsSet = YES;
    }
    x += 11;

    _hit[kBarSnap] = NSMakeRect(x, y, 54, h);
    [self drawKeyIn:_hit[kBarSnap] title:@"SNAP" lit:c.snapEnabled];
    x += 54 + 14;

    [self label:@"GRID" at:x];
    x += 36;
    _hit[kBarGrid] = NSMakeRect(x, y, 64, h);
    [self drawPopupWell:_hit[kBarGrid] text:[NSString stringWithFormat:@"1/%u", static_cast<unsigned>(4U * std::max<std::uint32_t>(1U, c.gridDivisionsPerQuarter))]];
    x += 64 + 12;

    [self label:@"HEIGHT" at:x];
    x += 50;
    _hit[kBarHeight] = NSMakeRect(x, y, 70, h);
    [self drawPopupWell:_hit[kBarHeight] text:@"Tracks"];
    x += 70 + 12;

    [self label:@"ZOOM" at:x];
    x += 40;
    _hit[kBarZoom] = NSMakeRect(x, y, 120, h);
    const CGFloat midY = y + h * 0.5;
    const double t = [self zoomFraction];
    sv::roundFill(NSMakeRect(x, midY - 1.5, 120, 3), 1.5, sv::hex(0x101114));
    sv::roundFill(NSMakeRect(x, midY - 1.5, static_cast<CGFloat>(120.0 * t), 3), 1.5, sv::inkFaint());
    sv::roundFill(NSMakeRect(x + static_cast<CGFloat>(120.0 * t) - 3, midY - 6, 6, 12), 2, sv::hex(0xE2E2DE));
    x += 120 + 8;
    _hit[kBarFit] = NSMakeRect(x, y, 40, h);
    [self drawKeyIn:_hit[kBarFit] title:@"FIT" lit:NO];   // the whole project fills the tracks (Zoom to Project)
    x += 40 + 14;

    // WAVE: how tall the waveforms are drawn (as the waveform zoom slider of Cubase)
    [self label:@"WAVE" at:x];
    x += 42;
    _hit[kBarWave] = NSMakeRect(x, y, 70, h);
    const double wt = std::log(c.waveZoom) / std::log(8.0);
    sv::roundFill(NSMakeRect(x, midY - 1.5, 70, 3), 1.5, sv::hex(0x101114));
    sv::roundFill(NSMakeRect(x, midY - 1.5, static_cast<CGFloat>(70.0 * wt), 3), 1.5, sv::inkFaint());
    sv::roundFill(NSMakeRect(x + static_cast<CGFloat>(70.0 * wt) - 3, midY - 6, 6, 12), 2, sv::hex(0xE2E2DE));

    // Zone switches on the right (as the layout keys of Cubase): Inspector | Lower Zone | Level
    NSArray<NSString*>* names = @[@"INSPECTOR", @"LOWER ZONE", @"LEVEL"];
    const BOOL on[3] = {c.channelPanelShown, c.lowerZoneShown, c.meterPanelShown};
    CGFloat rx = b.size.width - 12.0;
    for (int i = 2; i >= 0; --i) {
        NSString* title = names[static_cast<NSUInteger>(i)];
        const CGFloat w = std::ceil(sv::textSize(title, sv::ui(10, true)).width) + 26.0;
        rx -= w;
        _hit[kBarInspector + i] = NSMakeRect(rx, y, w, h);
        [self drawKeyIn:_hit[kBarInspector + i] title:title lit:on[i]];
        rx -= 4.0;
    }
}

- (void)setZoomFromX:(CGFloat)px {
    const NSRect r = _hit[kBarZoom];
    if (r.size.width < 1.0) return;
    const double t = sv::clamp01((px - r.origin.x) / r.size.width);
    [self.controller setPixelsPerSecond:kMinPps * std::pow(kMaxPps / kMinPps, t)];
    [self setNeedsDisplay:YES];
}
- (void)setWaveFromX:(CGFloat)px {
    const NSRect r = _hit[kBarWave];
    if (r.size.width < 1.0) return;
    const double t = sv::clamp01((px - r.origin.x) / r.size.width);
    [self.controller setWaveZoom:std::pow(8.0, t)];
    [self setNeedsDisplay:YES];
}

- (void)mouseDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (!c) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    for (int i = 0; i < kBarCount; ++i) {
        if (!NSPointInRect(p, (i == kBarZoom || i == kBarWave) ? NSInsetRect(_hit[i], -6, 0) : _hit[i])) continue;
        if (i >= kBarTool0 && i <= kBarTool7) { [c setArrangeTool:static_cast<SVArrangeTool>(i - kBarTool0)]; [self setNeedsDisplay:YES]; return; }
        switch (i) {
            case kBarSnap: [c toggleSnap:nil]; break;
            case kBarGrid: {
                NSMenu* menu = [[NSMenu alloc] initWithTitle:@"Grid"];
                NSArray<NSString*>* titles = @[@"1/4", @"1/8", @"1/16", @"1/32"];
                const std::uint32_t divs[4] = {1U, 2U, 4U, 8U};
                for (int k = 0; k < 4; ++k) {
                    NSMenuItem* it = [menu addItemWithTitle:titles[static_cast<NSUInteger>(k)] action:@selector(pickGrid:) keyEquivalent:@""];
                    it.target = c;
                    it.tag = static_cast<NSInteger>(divs[k]);
                    if (divs[k] == c.gridDivisionsPerQuarter) it.state = NSControlStateValueOn;
                }
                [NSMenu popUpContextMenu:menu withEvent:event forView:self];
                break;
            }
            case kBarHeight: {   // the same choices as View > Track Height
                NSMenu* menu = [[NSMenu alloc] initWithTitle:@"Track Height"];
                NSArray<NSString*>* titles = @[@"Small", @"Normal", @"Large", @"Huge", @"Fill the Window", @"Zoom Track On / Off", @"All Tracks Normal"];
                const NSInteger tags[7] = {32, 0, 96, 192, -1, -2, -3};
                for (int k = 0; k < 7; ++k) {
                    if (k == 4 || k == 6) [menu addItem:[NSMenuItem separatorItem]];
                    NSMenuItem* it = [menu addItemWithTitle:titles[static_cast<NSUInteger>(k)] action:@selector(setTrackHeight:) keyEquivalent:@""];
                    it.target = c;
                    it.tag = tags[k];
                }
                [NSMenu popUpContextMenu:menu withEvent:event forView:self];
                break;
            }
            case kBarZoom: _dragZoom = YES; _dragWave = NO; [self setZoomFromX:p.x]; return;
            case kBarWave:
                if (event.clickCount >= 2) { [c setWaveZoom:1.0]; [self setNeedsDisplay:YES]; return; }   // double-click = as recorded
                _dragWave = YES; _dragZoom = NO; [self setWaveFromX:p.x]; return;
            case kBarFit: [c zoomToProject:nil]; break;
            case kBarInspector: [c toggleChannelPanel:nil]; break;
            case kBarZone: [c toggleLowerZone:nil]; break;
            case kBarLevel: [c toggleMeterPanel:nil]; break;
            default: break;
        }
        [self setNeedsDisplay:YES];
        return;
    }
}
- (void)mouseDragged:(NSEvent*)event {
    if (_dragWave) { [self setWaveFromX:[self convertPoint:event.locationInWindow fromView:nil].x]; return; }
    if (!_dragZoom) return;
    [self setZoomFromX:[self convertPoint:event.locationInWindow fromView:nil].x];
}
- (void)mouseUp:(NSEvent*)event { (void)event; _dragZoom = NO; _dragWave = NO; }
@end

// ============================================================= zone bar ==
// The tab strip along the bottom of the lower zone (as the tabs of the Lower Zone of Cubase).
namespace {
enum ZoneItem { kZoneMixer, kZoneEditor, kZoneFull, kZoneHide, kZoneCount };
}

@implementation SilvetonZoneBar {
    NSRect _hit[kZoneCount];
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }

- (void)drawKeyIn:(NSRect)r title:(NSString*)title lit:(BOOL)lit {
    sv::keyCap(r, 4.0, lit, sv::copper());
    sv::textIn(title, NSMakeRect(r.origin.x, r.origin.y + (r.size.height - 2.0) * 0.5 - 7.0, r.size.width, 15.0),
               sv::ui(10, true), lit ? sv::copper() : sv::inkDim(), NSTextAlignmentCenter);
}

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    SilvetonController* c = self.controller;
    const NSRect b = self.bounds;
    sv::rail(b);
    for (auto& r : _hit) r = NSZeroRect;
    if (!c) return;
    const CGFloat y = 2.0, h = 20.0;
    CGFloat x = 8.0;
    NSArray<NSString*>* tabs = @[@"MIXER", @"EDITOR"];
    for (int i = 0; i < 2; ++i) {
        NSString* title = tabs[static_cast<NSUInteger>(i)];
        const CGFloat w = std::ceil(sv::textSize(title, sv::ui(10, true)).width) + 28.0;
        _hit[kZoneMixer + i] = NSMakeRect(x, y, w, h);
        [self drawKeyIn:_hit[kZoneMixer + i] title:title lit:c.zoneTab == i];
        x += w + 4.0;
    }
    CGFloat rx = b.size.width - 8.0;
    auto keyRight = [&](int item, NSString* title) {
        const CGFloat w = std::ceil(sv::textSize(title, sv::ui(10, true)).width) + 28.0;
        rx -= w;
        _hit[item] = NSMakeRect(rx, y, w, h);
        [self drawKeyIn:_hit[item] title:title lit:NO];
        rx -= 4.0;
    };
    keyRight(kZoneHide, @"HIDE");
    if (c.zoneTab == 1) keyRight(kZoneFull, @"FULL PAGE");
}

- (void)mouseDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (!c) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    for (int i = 0; i < kZoneCount; ++i) {
        if (_hit[i].size.width < 1.0 || !NSPointInRect(p, _hit[i])) continue;
        switch (i) {
            case kZoneMixer: [c selectZoneTab:0]; break;
            case kZoneEditor: [c selectZoneTab:1]; break;
            case kZoneFull: [c toggleEditorPlace:nil]; break;
            case kZoneHide: [c hideLowerZone:nil]; break;
            default: break;
        }
        [self setNeedsDisplay:YES];
        return;
    }
}
@end

// ============================================================ zone splitter ==
@implementation SilvetonZoneSplitter {
    BOOL _dragging;
    CGFloat _dragStartY;
    CGFloat _dragStartH;
}
- (BOOL)isOpaque { return YES; }
- (void)resetCursorRects { [self addCursorRect:self.bounds cursor:[NSCursor resizeUpDownCursor]]; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::fill(b, sv::hex(0x2A2D34));
    sv::line(NSMakePoint(0, NSMaxY(b) - 0.5), NSMakePoint(b.size.width, NSMaxY(b) - 0.5), sv::hex(0x50545E));
    sv::line(NSMakePoint(0, 0.5), NSMakePoint(b.size.width, 0.5), sv::hairline());
    const CGFloat gx = std::round(b.size.width * 0.5) - 16.0;
    sv::fill(NSMakeRect(gx, std::round(b.size.height * 0.5) - 0.5, 32.0, 1.0), sv::inkFaint());
}
- (void)mouseDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (!c) return;
    _dragging = YES;
    _dragStartY = event.locationInWindow.y;
    _dragStartH = c.zoneHeight;
}
- (void)mouseDragged:(NSEvent*)event {
    if (!_dragging) return;
    [self.controller setZoneHeight:_dragStartH + (event.locationInWindow.y - _dragStartY)];   // the zone is at the bottom: up = taller
}
- (void)mouseUp:(NSEvent*)event { (void)event; _dragging = NO; }
@end

// ========================================================== inspector tabs ==
@implementation SilvetonInspectorTabs {
    NSRect _hit[2];
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    SilvetonController* c = self.controller;
    const NSRect b = self.bounds;
    sv::rail(b);
    if (!c) return;
    NSArray<NSString*>* titles = @[@"TRACK", @"EDITOR"];
    const CGFloat w = std::floor((b.size.width - 12.0) / 2.0);
    for (int i = 0; i < 2; ++i) {
        _hit[i] = NSMakeRect(4.0 + i * (w + 4.0), 3.0, w, b.size.height - 6.0);
        const BOOL lit = c.inspectorTab == i;
        sv::keyCap(_hit[i], 4.0, lit, sv::copper());
        sv::textIn(titles[static_cast<NSUInteger>(i)], NSMakeRect(_hit[i].origin.x, _hit[i].origin.y + (_hit[i].size.height - 2.0) * 0.5 - 7.0, w, 15.0),
                   sv::ui(10, true), lit ? sv::copper() : sv::inkDim(), NSTextAlignmentCenter);
    }
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    for (int i = 0; i < 2; ++i) if (NSPointInRect(p, _hit[i])) { [self.controller selectInspectorTab:i]; return; }
}
@end

// ================================================================ info line ==
// Field numbers (the controller gets them on a double-click).
namespace {
enum InfoField { kInfoName = 0, kInfoStart, kInfoEnd, kInfoLength, kInfoFadeIn, kInfoFadeOut, kInfoGain, kInfoMute, kInfoRate, kInfoCount };
}

@implementation SilvetonInfoLine {
    NSRect _hit[kInfoCount];
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    SilvetonController* c = self.controller;
    const NSRect b = self.bounds;
    sv::fill(b, sv::hex(0x1A1C21));
    sv::line(NSMakePoint(0, b.size.height - 0.5), NSMakePoint(b.size.width, b.size.height - 0.5), sv::hairline());
    for (auto& r : _hit) r = NSZeroRect;
    if (!c || !c.project) return;
    const Project& p = *c.project;
    const double sr = p.sampleRate > 0.0 ? p.sampleRate : 96000.0;
    auto ms = [&](std::uint64_t samples) { return [NSString stringWithFormat:@"%.0f ms", static_cast<double>(samples) * 1000.0 / sr]; };
    NSMutableArray<NSString*>* labels = [NSMutableArray array];
    NSMutableArray<NSString*>* values = [NSMutableArray array];
    NSMutableArray<NSNumber*>* fields = [NSMutableArray array];
    auto put = [&](int field, NSString* label, NSString* value) { [fields addObject:@(field)]; [labels addObject:label]; [values addObject:value]; };
    const TimelineRange range = [c arrangeRange];
    if (range.valid()) {   // a marked range: its facts, and what the keys do with it
        const auto rows = [c arrangeRangeRows];
        put(kInfoName, @"RANGE", [NSString stringWithFormat:@"%lu track%s", (unsigned long)rows.size(), rows.size() == 1U ? "" : "s"]);
        put(kInfoStart, @"START", sv::ns(formatBarsBeats(p.tempoMap, range.start)));
        put(kInfoEnd, @"END", sv::ns(formatBarsBeats(p.tempoMap, range.end)));
        put(kInfoLength, @"LENGTH", sv::ns(formatClockTime(static_cast<double>(range.length()) / sr)));
        put(kInfoFadeIn, @"KEYS", @"Delete removes  ·  ⌘X cuts  ·  ⌘C copies  ·  ⌘V pastes at the cursor  ·  Edit ▸ Range: more");
    } else if (const ProjectAudioClip* clip = [c editedClip]) {
        const std::int64_t end = clip->timelineStartSample + static_cast<std::int64_t>(clip->lengthSamples);
        put(kInfoName, @"FILE", [sv::ns(clip->audioPath) lastPathComponent]);
        put(kInfoStart, @"START", sv::ns(formatBarsBeats(p.tempoMap, clip->timelineStartSample)));
        put(kInfoEnd, @"END", sv::ns(formatBarsBeats(p.tempoMap, end)));
        put(kInfoLength, @"LENGTH", sv::ns(formatClockTime(static_cast<double>(clip->lengthSamples) / sr)));
        put(kInfoFadeIn, @"FADE IN", ms(clip->fadeInSamples));
        put(kInfoFadeOut, @"FADE OUT", ms(clip->fadeOutSamples));
        put(kInfoGain, @"GAIN", [NSString stringWithFormat:@"%+.1f dB", static_cast<double>(clip->gainDb)]);
        put(kInfoMute, @"MUTE", clip->mute ? @"On" : @"Off");
        put(kInfoRate, @"FILE RATE", clip->sourceSampleRate ? [NSString stringWithFormat:@"%u Hz", clip->sourceSampleRate] : @"—");
    } else if (const MidiPart* part = [c editedPart]) {
        const std::int64_t start = p.tempoMap.sampleAtQuarterNotes(part->timelineStartQuarterNotes);
        const std::int64_t end = p.tempoMap.sampleAtQuarterNotes(part->timelineStartQuarterNotes + part->lengthQuarterNotes);
        put(kInfoName, @"PART", [NSString stringWithFormat:@"%lu notes", (unsigned long)part->sequence.notes().size()]);
        put(kInfoStart, @"START", sv::ns(formatBarsBeats(p.tempoMap, start)));
        put(kInfoEnd, @"END", sv::ns(formatBarsBeats(p.tempoMap, end)));
        put(kInfoLength, @"LENGTH", [NSString stringWithFormat:@"%.2f beats", part->lengthQuarterNotes]);
        put(kInfoMute, @"MUTE", part->muted ? @"On" : @"Off");
        put(kInfoRate, @"LOOP", [NSString stringWithFormat:@"%.2f beats", part->loopLengthQuarterNotes]);
    } else {
        sv::text(@"Select a clip or a MIDI part to see its facts here", NSMakePoint(12, 11), sv::ui(10), sv::inkFaint());
        return;
    }
    CGFloat x = 12.0;
    for (NSUInteger i = 0; i < labels.count; ++i) {
        const CGFloat lw = sv::textSize(labels[i], sv::ui(9, true)).width;
        const CGFloat vw = sv::textSize(values[i], sv::mono(11, true)).width;
        const CGFloat w = std::ceil(std::max(lw, vw)) + 4.0;
        if (x + w > b.size.width - 8.0) break;
        _hit[fields[i].intValue] = NSMakeRect(x - 4.0, 0, w + 8.0, b.size.height);
        sv::engraved(labels[i], NSMakePoint(x, 3.0), sv::ui(9, true), sv::hex(0x8A8F9A));
        sv::text(values[i], NSMakePoint(x, 16.0), sv::mono(11, true), sv::lcdValue());
        x += w + 22.0;
        sv::line(NSMakePoint(x - 11.0, 6.0), NSMakePoint(x - 11.0, b.size.height - 6.0), sv::hex(0x2E323A));
    }
}
- (void)mouseDown:(NSEvent*)event {
    if (event.clickCount < 2) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    for (int i = 0; i < kInfoCount; ++i)
        if (_hit[i].size.width > 0.0 && NSPointInRect(p, _hit[i])) { [self.controller infoFieldDoubleClicked:i]; return; }
}
@end

// ============================================================ level panel ==
namespace {
void sectionTitle(NSString* title, NSPoint at) {
    NSDictionary* attrs = @{NSFontAttributeName: sv::ui(10, true), NSForegroundColorAttributeName: sv::gold(), NSKernAttributeName: @(1.8)};
    [title drawAtPoint:at withAttributes:attrs];
}
NSString* kiloHertz(double hz) {
    const double k = hz / 1000.0;
    return std::abs(k - std::round(k)) < 0.001 ? [NSString stringWithFormat:@"%.0f kHz", k] : [NSString stringWithFormat:@"%.1f kHz", k];
}
}

@implementation SilvetonMeterPanel {
    std::uint32_t _sig;
    NSRect _meterRect;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }

- (CGFloat)meterHeight {
    return std::max<CGFloat>(80.0, std::min<CGFloat>(230.0, self.bounds.size.height - 100.0 - 190.0));
}

- (void)tick {
    SilvetonController* c = self.controller;
    if (!c || !c.core || !c.core->ready()) return;
    const StereoMeterDisplay md = [c masterMeterDisplay];
    const std::uint32_t sig = sv::meter::signature(md, [self meterHeight], true) ^
        (static_cast<std::uint32_t>(std::lround(std::max(-99.0F, md.maxDb()) * 10.0F) + 1000) * 40503U);
    if (sig == _sig) return;
    _sig = sig;
    [self setNeedsDisplayInRect:NSMakeRect(0, 20, self.bounds.size.width, 100.0 + [self meterHeight])];
}

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    SilvetonController* c = self.controller;
    const NSRect b = self.bounds;
    const CGFloat w = b.size.width;
    sv::fill(b, sv::canvas());
    sv::line(NSMakePoint(0.5, 0), NSMakePoint(0.5, b.size.height), sv::hairline());
    sectionTitle(@"LEVEL", NSMakePoint(14, 8));
    if (!c || !c.project || !c.core) return;

    // Master peak read-out on a light display
    const StereoMeterDisplay md = [c masterMeterDisplay];
    const NSRect lcdRect = NSMakeRect(10, 26, w - 20, 60);
    sv::lcd(lcdRect, 8.0);
    sv::text(@"MASTER PEAK", NSMakePoint(20, 31), sv::ui(10, true), sv::lcdDim());
    const float maxDb = md.maxDb();
    NSString* peak = maxDb <= -99.0F ? @"-∞" : [NSString stringWithFormat:@"%.1f", maxDb];
    NSFont* big = sv::mono(26, true);
    sv::text(peak, NSMakePoint(20, 46), big, maxDb > 0.0F ? sv::rec() : sv::copper());
    sv::text(@"dB", NSMakePoint(20 + std::ceil(sv::textSize(peak, big).width) + 4, 60), sv::mono(11), sv::lcdValue());
    const float hold = std::max(md.left.holdDb, md.right.holdDb);
    sv::textIn(hold <= -99.0F ? @"" : [NSString stringWithFormat:@"hold %.1f", hold], NSMakeRect(w - 100, 31, 82, 13), sv::mono(10), sv::lcdValue(), NSTextAlignmentRight);

    // Big stereo meter
    const CGFloat meterH = [self meterHeight];
    _meterRect = NSMakeRect(10, 96, w - 20, meterH);
    sv::wellFill(_meterRect, 5.0);
    const CGFloat barW = 18.0, barX = std::floor(NSMidX(_meterRect) - barW - 3.0 + 14.0);
    const NSRect left = NSMakeRect(barX, _meterRect.origin.y + 14, barW, meterH - 22);
    sv::meter::drawClipLamp(NSMakeRect(barX, _meterRect.origin.y + 6, barW * 2.0 + 6.0, 5), md.clip());
    sv::meter::drawBar(left, true, md.left.levelDb, md.left.holdDb, md.left.clip, true);
    sv::meter::drawBar(NSMakeRect(barX + barW + 6.0, left.origin.y, barW, left.size.height), true, md.right.levelDb, md.right.holdDb, md.right.clip, true);
    CGFloat lastLabelY = -1.0e9;
    for (double db : {6.0, 0.0, -6.0, -12.0, -24.0, -40.0, -60.0}) {
        const CGFloat ty = std::round(NSMaxY(left) - left.size.height * sv::meter::position(db));
        NSColor* tone = db == 0.0 ? sv::inkDim() : sv::inkFaint();
        sv::line(NSMakePoint(barX - 5, ty + 0.5), NSMakePoint(barX - 1, ty + 0.5), tone);
        if (ty - lastLabelY < 13.0) continue;
        lastLabelY = ty;
        sv::textIn(sv::meter::dbLabel(db), NSMakeRect(barX - 44, ty - 6, 36, 12), sv::mono(10), tone, NSTextAlignmentRight);
    }

    // Details of what is selected
    const Project& p = *c.project;
    const double sr = p.sampleRate > 0.0 ? p.sampleRate : 48000.0;
    NSString* heading = @"DETAILS";
    NSMutableArray<NSArray<NSString*>*>* rows = [NSMutableArray array];
    const ProjectAudioClip* clip = nullptr;
    if (c.selectedTrack >= 0 && static_cast<std::size_t>(c.selectedTrack) < p.tracks.size() && c.selectedClipId != 0U)
        for (const auto& cl : p.tracks[static_cast<std::size_t>(c.selectedTrack)].clips)
            if (cl.id == c.selectedClipId) clip = &cl;
    if (clip) {
        heading = @"SELECTED CLIP";
        const auto& t = p.tracks[static_cast<std::size_t>(c.selectedTrack)];
        NSString* nm = [[sv::ns(clip->audioPath.empty() ? t.audioPath : clip->audioPath) lastPathComponent] stringByDeletingPathExtension];
        [rows addObject:@[@"Name", nm.length ? nm : @"—"]];
        [rows addObject:@[@"Start", sv::ns(formatBarsBeats(p.tempoMap, clip->timelineStartSample))]];
        [rows addObject:@[@"Length", sv::ns(formatClock(static_cast<double>(clip->lengthSamples) / sr))]];
        [rows addObject:@[@"Gain", [NSString stringWithFormat:@"%+.1f dB", clip->gainDb]]];
        [rows addObject:@[@"Fades", [NSString stringWithFormat:@"%.0f / %.0f ms", clip->fadeInSamples * 1000.0 / sr, clip->fadeOutSamples * 1000.0 / sr]]];
        if (clip->sourceSampleRate > 0U) {
            NSString* file = kiloHertz(static_cast<double>(clip->sourceSampleRate));
            if (std::abs(static_cast<double>(clip->sourceSampleRate) - sr) > 0.5) file = [NSString stringWithFormat:@"%@ → %@", file, kiloHertz(sr)];
            [rows addObject:@[@"File rate", file]];
        }
    } else if (c.selectedMidiTrack >= 0 && static_cast<std::size_t>(c.selectedMidiTrack) < p.midiTracks.size() && c.selectedPartId != 0U) {
        const auto& mt = p.midiTracks[static_cast<std::size_t>(c.selectedMidiTrack)];
        for (const auto& part : mt.parts) {
            if (part.id != c.selectedPartId) continue;
            heading = @"SELECTED PART";
            [rows addObject:@[@"Track", sv::ns(mt.name.empty() ? std::string("MIDI") : mt.name)]];
            [rows addObject:@[@"Start", sv::ns(formatBarsBeats(p.tempoMap, p.tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes)))]];
            [rows addObject:@[@"Length", [NSString stringWithFormat:@"%.1f quarters", part.lengthQuarterNotes]]];
            [rows addObject:@[@"Notes", [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(part.sequence.notes().size())]]];
            break;
        }
    } else if (c.selectedTrack >= 0 && static_cast<std::size_t>(c.selectedTrack) < p.tracks.size()) {
        const auto& t = p.tracks[static_cast<std::size_t>(c.selectedTrack)];
        heading = @"SELECTED TRACK";
        [rows addObject:@[@"Name", sv::ns(t.name.empty() ? std::string("Audio") : t.name)]];
        [rows addObject:@[@"Level", [NSString stringWithFormat:@"%+.1f dB", t.gainDb]]];
        [rows addObject:@[@"Pan", std::abs(t.pan) < 0.005 ? @"C" : [NSString stringWithFormat:@"%@%d", t.pan < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(t.pan) * 100))]]];
        [rows addObject:@[@"Inserts", [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(t.pluginSlots.size())]]];
        [rows addObject:@[@"Clips", [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(t.clips.size())]]];
    }
    CGFloat y = NSMaxY(_meterRect) + 16.0;
    sectionTitle(heading, NSMakePoint(14, y));
    y += 22.0;
    if (rows.count == 0U) {
        sv::textIn(@"Click a clip or a track", NSMakeRect(14, y, w - 28, 15), sv::ui(11), sv::inkFaint());
        sv::textIn(@"to see its details here.", NSMakeRect(14, y + 16, w - 28, 15), sv::ui(11), sv::inkFaint());
        return;
    }
    for (NSArray<NSString*>* row in rows) {
        if (y + 18.0 > b.size.height) break;
        sv::text(row[0], NSMakePoint(14, y), sv::ui(10), sv::inkFaint());
        sv::textIn(row[1], NSMakeRect(66, y - 1, w - 66 - 12, 14), sv::mono(10), sv::lcdValue(), NSTextAlignmentRight);
        sv::line(NSMakePoint(14, y + 16.5), NSMakePoint(w - 12, y + 16.5), sv::rgb(1, 1, 1, 0.05));
        y += 20.0;
    }
}

- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (!NSPointInRect(p, _meterRect) || !self.controller) return;
    SVStrip master;
    master.kind = SVStripKind::Master;
    [self.controller resetMetersForStrip:master all:(event.modifierFlags & NSEventModifierFlagOption) != 0];
    [self setNeedsDisplay:YES];
}
@end
