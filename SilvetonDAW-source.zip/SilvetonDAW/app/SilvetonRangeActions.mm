// Project window tools (Split / Glue / Erase / Mute / Draw / Zoom) and the range selection drawn
// across the tracks: cut, copy, paste, delete, the ripple variants, split, crop, cycle and zoom.
// The names follow the Edit > Range menu of Cubase. All edits are one undo step each.
#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/ClipEditor.h"
#include "silveton/MidiPartEditor.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <vector>

using namespace silveton;

// Methods implemented in SilvetonActions.mm that are called here.
@interface SilvetonController (RangeForward)
- (void)clipEdit:(NSString*)label op:(void (^)(ClipEditor& editor))op;
- (void)republishMidi;
@end

namespace {

NSString* toolName(SVArrangeTool tool) {
    switch (tool) {
        case SVArrangeTool::Select: return @"Object Selection";
        case SVArrangeTool::Range: return @"Range Selection";
        case SVArrangeTool::Split: return @"Split";
        case SVArrangeTool::Glue: return @"Glue";
        case SVArrangeTool::Erase: return @"Erase";
        case SVArrangeTool::Zoom: return @"Zoom";
        case SVArrangeTool::Mute: return @"Mute";
        case SVArrangeTool::Draw: return @"Draw";
    }
    return @"";
}

NSString* toolHint(SVArrangeTool tool) {
    switch (tool) {
        case SVArrangeTool::Select: return @"drag on empty space: rectangle-select clips and MIDI parts; ⇧ add, ⌘ toggle, ⌥ subtract; drag selected objects together, ⌥-drag copies";
        case SVArrangeTool::Range: return @"drag over the tracks to mark a range — Delete, ⌘X, ⌘C, ⌘V and Edit ▸ Range work on it";
        case SVArrangeTool::Split: return @"click a clip or part to cut it there";
        case SVArrangeTool::Glue: return @"click a clip or part to join it with the next one on the track";
        case SVArrangeTool::Erase: return @"click a clip or part to remove it";
        case SVArrangeTool::Zoom: return @"click zooms in, ⌥ click zooms out, drag a box to zoom to it";
        case SVArrangeTool::Mute: return @"click a clip or part to mute it (click again to hear it)";
        case SVArrangeTool::Draw: return @"drag on a MIDI track to create a part (a click gives one bar)";
    }
    return @"";
}

// ---- audio: what a range does to the clips of one track ----------------------------------------
// Removes the part of every clip that lies inside [start, end).
void removeAudioRange(ClipEditor& e, const ProjectTrack& track, std::int64_t start, std::int64_t end) {
    const auto clips = track.clips;   // a copy: the editor changes the list
    for (const auto& c : clips) {
        const std::int64_t cs = c.timelineStartSample, ce = cs + static_cast<std::int64_t>(c.lengthSamples);
        if (ce <= start || cs >= end) continue;
        if (cs < start && ce > end) {
            const std::uint64_t right = e.splitClip(c.id, start);
            const std::uint64_t tail = e.splitClip(right, end);
            (void)tail;
            e.removeClip(right);
        } else if (cs < start) {
            e.trimRight(c.id, start);
        } else if (ce > end) {
            e.trimLeft(c.id, end);
        } else {
            e.removeClip(c.id);
        }
    }
}
// Cuts every clip that crosses `at`.
void splitAudioAt(ClipEditor& e, const ProjectTrack& track, std::int64_t at) {
    const auto clips = track.clips;
    for (const auto& c : clips) {
        const std::int64_t cs = c.timelineStartSample, ce = cs + static_cast<std::int64_t>(c.lengthSamples);
        if (at > cs && at < ce) (void)e.splitClip(c.id, at);
    }
}
// Keeps only what lies inside [start, end).
void cropAudio(ClipEditor& e, const ProjectTrack& track, std::int64_t start, std::int64_t end) {
    const auto clips = track.clips;
    for (const auto& c : clips) {
        const std::int64_t cs = c.timelineStartSample, ce = cs + static_cast<std::int64_t>(c.lengthSamples);
        if (ce <= start || cs >= end) { e.removeClip(c.id); continue; }
        if (cs < start) e.trimLeft(c.id, start);
        if (ce > end) e.trimRight(c.id, end);
    }
}
// Moves every clip that starts at or after `from` by `delta` samples (a split first keeps the clips whole).
void shiftAudio(ClipEditor& e, const ProjectTrack& track, std::int64_t from, std::int64_t delta) {
    if (delta > 0) splitAudioAt(e, track, from);   // room is made: the piece after `from` moves, the piece before stays
    const auto clips = track.clips;
    std::vector<const ProjectAudioClip*> moving;
    for (const auto& c : clips) if (c.timelineStartSample >= from) moving.push_back(&c);
    // leftwards moves need the earliest clip first, rightwards the latest first (no clip may land on another)
    std::sort(moving.begin(), moving.end(), [delta](const ProjectAudioClip* a, const ProjectAudioClip* b) {
        return delta < 0 ? a->timelineStartSample < b->timelineStartSample : a->timelineStartSample > b->timelineStartSample; });
    for (const auto* c : moving) e.moveClip(c->id, std::max<std::int64_t>(0, c->timelineStartSample + delta));
}
// The pieces of the clips inside [start, end), cut to the range and placed relative to `start`.
void copyAudioRange(const ProjectTrack& track, std::size_t trackIndex, std::int64_t start, std::int64_t end, std::vector<SVRangePiece>& out) {
    for (const auto& c : track.clips) {
        const std::int64_t cs = c.timelineStartSample, ce = cs + static_cast<std::int64_t>(c.lengthSamples);
        if (ce <= start || cs >= end) continue;
        SVRangePiece piece;
        piece.kind = ArrangeRowKind::Audio;
        piece.track = trackIndex;
        ProjectAudioClip clip = c;
        clip.id = 0U;
        if (cs < start) {
            const auto cut = static_cast<std::uint64_t>(start - cs);
            clip.sourceStartSample += cut;
            clip.lengthSamples -= cut;
            clip.timelineStartSample = start;
            clip.fadeInSamples = 0U;
        }
        if (ce > end) {
            clip.lengthSamples = static_cast<std::uint64_t>(end - clip.timelineStartSample);
            clip.fadeOutSamples = 0U;
        }
        clip.fadeInSamples = std::min(clip.fadeInSamples, clip.lengthSamples);
        clip.fadeOutSamples = std::min(clip.fadeOutSamples, clip.lengthSamples);
        clip.fadeInAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
        clip.fadeOutAnchorSourceSample = ProjectAudioClip::kAutoFadeAnchor;
        clip.timelineStartSample -= start;
        piece.clip = std::move(clip);
        out.push_back(std::move(piece));
    }
}

// ---- MIDI: the same for the parts of one track (positions in quarter notes) --------------------
void removeMidiRange(MidiPartEditor& e, const std::vector<MidiPart>& parts, double qs, double qe) {
    const auto copy = parts;
    for (const auto& part : copy) {
        const double ps = part.timelineStartQuarterNotes, pe = ps + part.lengthQuarterNotes;
        if (pe <= qs || ps >= qe) continue;
        if (ps < qs && pe > qe) {
            const std::uint64_t right = e.split(part.id, qs);
            (void)e.split(right, qe);
            (void)e.remove(right);
        } else if (ps < qs) {
            (void)e.trimRight(part.id, qs - ps);
        } else if (pe > qe) {
            (void)e.trimLeft(part.id, qe - ps);
        } else {
            (void)e.remove(part.id);
        }
    }
}
void splitMidiAt(MidiPartEditor& e, const std::vector<MidiPart>& parts, double at) {
    const auto copy = parts;
    for (const auto& part : copy) {
        const double ps = part.timelineStartQuarterNotes, pe = ps + part.lengthQuarterNotes;
        if (at > ps && at < pe) (void)e.split(part.id, at);
    }
}
void cropMidi(MidiPartEditor& e, const std::vector<MidiPart>& parts, double qs, double qe) {
    const auto copy = parts;
    for (const auto& part : copy) {
        const double ps = part.timelineStartQuarterNotes, pe = ps + part.lengthQuarterNotes;
        if (pe <= qs || ps >= qe) { (void)e.remove(part.id); continue; }
        if (ps < qs) (void)e.trimLeft(part.id, qs - ps);
        if (pe > qe) (void)e.trimRight(part.id, qe - std::max(ps, qs));
    }
}
void shiftMidi(MidiPartEditor& e, const std::vector<MidiPart>& parts, double from, double delta) {
    if (delta > 0.0) splitMidiAt(e, parts, from);
    const auto copy = parts;
    std::vector<const MidiPart*> moving;
    for (const auto& part : copy) if (part.timelineStartQuarterNotes >= from) moving.push_back(&part);
    std::sort(moving.begin(), moving.end(), [delta](const MidiPart* a, const MidiPart* b) {
        return delta < 0.0 ? a->timelineStartQuarterNotes < b->timelineStartQuarterNotes : a->timelineStartQuarterNotes > b->timelineStartQuarterNotes; });
    for (const auto* part : moving) (void)e.move(part->id, std::max(0.0, part->timelineStartQuarterNotes + delta));
}
void copyMidiRange(const ProjectMidiTrack& track, std::size_t trackIndex, double qs, double qe, std::vector<SVRangePiece>& out) {
    for (const auto& part : track.parts) {
        const double ps = part.timelineStartQuarterNotes, pe = ps + part.lengthQuarterNotes;
        if (pe <= qs || ps >= qe) continue;
        SVRangePiece piece;
        piece.kind = ArrangeRowKind::Midi;
        piece.track = trackIndex;
        MidiPart p = part;
        p.id = 0U;
        if (ps < qs) {
            p.sourceOffsetQuarterNotes += qs - ps;
            p.lengthQuarterNotes -= qs - ps;
            p.timelineStartQuarterNotes = qs;
        }
        if (pe > qe) p.lengthQuarterNotes = qe - p.timelineStartQuarterNotes;
        piece.part = std::move(p);
        out.push_back(std::move(piece));
    }
}

// The notes and messages a part plays (its loop unrolled, its window applied), written into `out`
// at `base` + their timeline position relative to `from`.
void flattenPart(const MidiPart& part, double from, MidiSequence& out) {
    const double sourceBegin = part.sourceOffsetQuarterNotes;
    const double sourceEnd = sourceBegin + part.lengthQuarterNotes;
    const double loop = std::max(1.0e-6, part.loopLengthQuarterNotes);
    const long long firstLoop = static_cast<long long>(std::floor(sourceBegin / loop)) - 1LL;
    const long long lastLoop = static_cast<long long>(std::ceil(sourceEnd / loop)) + 1LL;
    if (lastLoop - firstLoop > 100000LL) return;
    for (long long k = firstLoop; k <= lastLoop; ++k) {
        const double loopBase = static_cast<double>(k) * loop;
        for (const auto& note : part.sequence.notes()) {
            const double on = loopBase + note.startQuarterNotes;
            const double off = on + note.durationQuarterNotes;
            if (off <= sourceBegin || on >= sourceEnd) continue;
            const double clippedOn = std::max(on, sourceBegin), clippedOff = std::min(off, sourceEnd);
            if (!(clippedOff > clippedOn)) continue;
            MusicalMidiNote copy = note;
            copy.id = 0U;
            copy.startQuarterNotes = part.timelineStartQuarterNotes + (clippedOn - sourceBegin) - from;
            copy.durationQuarterNotes = clippedOff - clippedOn;
            (void)out.addNote(copy);
        }
        for (const auto& message : part.sequence.messages()) {
            const double at = loopBase + message.quarterNotes;
            if (at < sourceBegin || at >= sourceEnd) continue;
            MusicalMidiMessage copy = message;
            copy.id = 0U;
            copy.quarterNotes = part.timelineStartQuarterNotes + (at - sourceBegin) - from;
            (void)out.addMessage(copy);
        }
    }
}

} // namespace

@implementation SilvetonController (RangeActions)

// ================================================================== tools ==
- (SVArrangeTool)arrangeTool { return _arrangeTool; }
- (void)setArrangeTool:(SVArrangeTool)tool {
    if (_arrangeTool == tool) return;
    _arrangeTool = tool;
    [self setStatus:[NSString stringWithFormat:@"%@ tool — %@", toolName(tool), toolHint(tool)]];
    [_toolBar setNeedsDisplay:YES];
    [_arrange setNeedsDisplay:YES];
    [_window invalidateCursorRectsForView:_arrange];
}
- (void)pickArrangeTool:(id)sender {
    const NSInteger tag = [sender respondsToSelector:@selector(tag)] ? [sender tag] : 0;
    [self setArrangeTool:static_cast<SVArrangeTool>(std::min<NSInteger>(7, std::max<NSInteger>(0, tag)))];
}

- (void)toolClick:(SVArrangeTool)tool row:(ArrangeRow)row clip:(std::uint64_t)clipId part:(std::uint64_t)partId atSample:(std::int64_t)sample {
    if (!_core) return;
    Project& p = _core->project();
    [self selectRow:row];
    if (row.kind == ArrangeRowKind::Audio && clipId && row.index < p.tracks.size()) {
        self.selectedClipId = clipId;
        switch (tool) {
            case SVArrangeTool::Split: {
                [self clipEdit:@"Split" op:^(ClipEditor& e) { self.selectedClipId = e.splitClip(clipId, sample, ClipSnapSettings {}); }];
                break;
            }
            case SVArrangeTool::Glue: {
                // Join with the next clip on the track when it is the continuation of the same sound (as after a split).
                const auto& clips = p.tracks[row.index].clips;
                const ProjectAudioClip* me = nullptr;
                for (const auto& c : clips) if (c.id == clipId) me = &c;
                if (!me) return;
                const std::int64_t myEnd = me->timelineStartSample + static_cast<std::int64_t>(me->lengthSamples);
                const ProjectAudioClip* next = nullptr;
                for (const auto& c : clips)
                    if (c.id != clipId && c.timelineStartSample >= myEnd && (!next || c.timelineStartSample < next->timelineStartSample)) next = &c;
                if (!next) { [self setStatus:@"Glue: there is no clip after this one on the track"]; return; }
                const bool sameSound = next->audioPath == me->audioPath && next->timelineStartSample == myEnd &&
                                       next->sourceStartSample == me->sourceStartSample + me->lengthSamples;
                if (!sameSound) { [self setStatus:@"Glue joins two pieces of the same sound that follow each other (as the two halves of a split)"]; return; }
                const std::uint64_t nextId = next->id, fadeOut = next->fadeOutSamples, fadeIn = me->fadeInSamples;
                const std::int64_t newEnd = next->timelineStartSample + static_cast<std::int64_t>(next->lengthSamples);
                [self clipEdit:@"Glue" op:^(ClipEditor& e) {
                    e.removeClip(nextId);
                    e.trimRight(clipId, newEnd, ClipSnapSettings {});   // the first piece grows over the second
                    e.setFades(clipId, fadeIn, fadeOut);
                }];
                [self setStatus:@"Glued into one clip"];
                break;
            }
            case SVArrangeTool::Erase: {
                [self clipEdit:@"Erase" op:^(ClipEditor& e) { e.removeClip(clipId); }];
                self.selectedClipId = 0;
                break;
            }
            case SVArrangeTool::Mute: {
                [self toggleClipMute:nil];
                break;
            }
            default: break;
        }
        return;
    }
    if (row.kind == ArrangeRowKind::Midi && partId && row.index < p.midiTracks.size()) {
        self.selectedPartId = partId;
        const auto t = row.index;
        const double q = p.tempoMap.quarterNotesAtSample(sample);
        switch (tool) {
            case SVArrangeTool::Split: {
                [self runEdit:@"Split Part" rebuild:NO block:^{ MidiPartEditor ed(self->_core->project().midiTracks[t].parts); self.selectedPartId = ed.split(partId, q); }];
                [self republishMidi];
                break;
            }
            case SVArrangeTool::Glue: {
                const auto& parts = p.midiTracks[t].parts;
                const MidiPart* me = nullptr;
                for (const auto& part : parts) if (part.id == partId) me = &part;
                if (!me) return;
                const double myEnd = me->timelineStartQuarterNotes + me->lengthQuarterNotes;
                const MidiPart* next = nullptr;
                for (const auto& part : parts)
                    if (part.id != partId && part.timelineStartQuarterNotes >= myEnd - 1.0e-9 &&
                        (!next || part.timelineStartQuarterNotes < next->timelineStartQuarterNotes)) next = &part;
                if (!next) { [self setStatus:@"Glue: there is no part after this one on the track"]; return; }
                // One new part from the start of this one to the end of the next, with the notes both of them play.
                MidiPart joined;
                joined.timelineStartQuarterNotes = me->timelineStartQuarterNotes;
                joined.lengthQuarterNotes = (next->timelineStartQuarterNotes + next->lengthQuarterNotes) - me->timelineStartQuarterNotes;
                joined.loopLengthQuarterNotes = joined.lengthQuarterNotes;
                joined.sourceOffsetQuarterNotes = 0.0;
                joined.muted = me->muted && next->muted;
                flattenPart(*me, me->timelineStartQuarterNotes, joined.sequence);
                flattenPart(*next, me->timelineStartQuarterNotes, joined.sequence);
                const std::uint64_t nextId = next->id;
                [self runEdit:@"Glue Parts" rebuild:NO block:^{
                    MidiPartEditor ed(self->_core->project().midiTracks[t].parts);
                    (void)ed.remove(nextId);
                    (void)ed.remove(partId);
                    self.selectedPartId = ed.add(joined);
                }];
                [self republishMidi];
                break;
            }
            case SVArrangeTool::Erase: {
                [self runEdit:@"Erase Part" rebuild:NO block:^{ MidiPartEditor ed(self->_core->project().midiTracks[t].parts); (void)ed.remove(partId); }];
                self.selectedPartId = 0;
                [self republishMidi];
                break;
            }
            case SVArrangeTool::Mute: {
                [self toggleClipMute:nil];
                break;
            }
            default: break;
        }
    }
}

- (void)createPartForMidiTrack:(std::size_t)track from:(std::int64_t)start to:(std::int64_t)end {
    if (!_core || track >= _core->project().midiTracks.size()) return;
    const TempoMap& tm = _core->project().tempoMap;
    const auto pos = tm.positionAtSample(start);
    const double barLen = pos.numerator * 4.0 / pos.denominator;
    const double q0 = tm.quarterNotesAtSample(start);
    double len = end > start ? tm.quarterNotesAtSample(end) - q0 : barLen;
    if (len < 1.0 / std::max<std::uint32_t>(1U, _gridDiv)) len = barLen;
    [self runEdit:@"Draw MIDI Part" rebuild:NO block:^{
        auto& mt = self->_core->project().midiTracks.at(track);
        self.selectedPartId = MidiTrackTools::addEmptyPart(mt, q0, len);
        self.selectedMidiTrack = static_cast<long>(track);
    }];
    [self republishMidi];
    [self setStatus:@"MIDI part created — double-click it to write notes"];
}

- (void)zoomToSamples:(std::int64_t)start to:(std::int64_t)end { [_arrange zoomToSamples:start to:end]; }

// ================================================================== range ==
- (TimelineRange)arrangeRange { return _arrange ? [_arrange range] : TimelineRange {}; }
- (std::vector<ArrangeRow>)arrangeRangeRows { return _arrange ? [_arrange rangeRows] : std::vector<ArrangeRow> {}; }
- (BOOL)arrangeRangeActive { return _arrange && [_arrange hasRange] && ![self editorFocused]; }
- (void)setArrangeRange:(TimelineRange)range rows:(const std::vector<ArrangeRow>&)rows {
    [_arrange setRange:range rows:rows];
    [self arrangeRangeChanged];
}
- (void)arrangeRangeChanged {
    [_infoLine setNeedsDisplay:YES];
    [_arrange setNeedsDisplay:YES];
}

// The tracks the range covers, split by kind.
- (void)rangeAudioTracks:(std::vector<std::size_t>*)audio midiTracks:(std::vector<std::size_t>*)midi {
    for (const ArrangeRow& r : [self arrangeRangeRows]) {
        if (r.kind == ArrangeRowKind::Audio) audio->push_back(r.index);
        else if (r.kind == ArrangeRowKind::Midi) midi->push_back(r.index);
    }
}
- (BOOL)requireRange:(NSString*)title {
    if ([self arrangeRangeActive]) return YES;
    [self setStatus:[NSString stringWithFormat:@"%@: mark a range first — Range Selection tool (key 2), then drag over the tracks", title]];
    return NO;
}

// One edit over every track of the range: `audio` gets a ClipEditor per audio track, `midi` a MidiPartEditor per MIDI track.
- (void)rangeEdit:(NSString*)label audio:(void (^)(ClipEditor& e, const ProjectTrack& t))audio midi:(void (^)(MidiPartEditor& e, std::vector<MidiPart>& parts, const TempoMap& tm))midi {
    std::vector<std::size_t> audioTracks, midiTracks;
    [self rangeAudioTracks:&audioTracks midiTracks:&midiTracks];
    [self runEdit:label rebuild:YES block:^{
        Project& p = self->_core->project();
        for (std::size_t t : audioTracks) {
            if (t >= p.tracks.size() || p.tracks[t].locked) continue;
            ClipEditor e(p, t);
            audio(e, p.tracks[t]);
        }
        for (std::size_t t : midiTracks) {
            if (t >= p.midiTracks.size()) continue;
            MidiPartEditor e(p.midiTracks[t].parts);
            midi(e, p.midiTracks[t].parts, p.tempoMap);
        }
    }];
    if (!midiTracks.empty()) [self republishMidi];
    self.selectedClipId = 0;
    self.selectedPartId = 0;
    [self refreshAll];
}

- (BOOL)rangeClipboardFull { return !_rangeClip.empty(); }

- (void)rangeCopy:(id)sender {
    (void)sender;
    if (![self requireRange:@"Copy"]) return;
    const TimelineRange r = [self arrangeRange];
    const Project& p = _core->project();
    std::vector<std::size_t> audioTracks, midiTracks;
    [self rangeAudioTracks:&audioTracks midiTracks:&midiTracks];
    std::vector<SVRangePiece> pieces;
    for (std::size_t t : audioTracks) if (t < p.tracks.size()) copyAudioRange(p.tracks[t], t, r.start, r.end, pieces);
    const double qs = p.tempoMap.quarterNotesAtSample(r.start), qe = p.tempoMap.quarterNotesAtSample(r.end);
    for (std::size_t t : midiTracks) if (t < p.midiTracks.size()) copyMidiRange(p.midiTracks[t], t, qs, qe, pieces);
    _rangeClip = std::move(pieces);
    _rangeClipLength = r.length();
    _rangeClipQ0 = qs;
    _clipboardValid = NO;   // the range replaces a copied clip
    [self setStatus:[NSString stringWithFormat:@"Range copied (%lu piece%s, %@) — ⌘V pastes it at the cursor", (unsigned long)_rangeClip.size(),
                     _rangeClip.size() == 1U ? "" : "s", [self sampleDurationText:_rangeClipLength]]];
}

- (void)rangeDelete:(id)sender {
    (void)sender;
    if (![self requireRange:@"Delete"]) return;
    const TimelineRange r = [self arrangeRange];
    [self rangeEdit:@"Delete Range"
              audio:^(ClipEditor& e, const ProjectTrack& t) { removeAudioRange(e, t, r.start, r.end); }
               midi:^(MidiPartEditor& e, std::vector<MidiPart>& parts, const TempoMap& tm) { removeMidiRange(e, parts, tm.quarterNotesAtSample(r.start), tm.quarterNotesAtSample(r.end)); }];
    [self setStatus:@"Range deleted (the gap stays — Edit ▸ Range ▸ Delete Time closes it)"];
}

- (void)rangeCut:(id)sender {
    (void)sender;
    if (![self requireRange:@"Cut"]) return;
    [self rangeCopy:nil];
    [self rangeDelete:nil];
    [self setStatus:@"Range cut — ⌘V pastes it at the cursor"];
}

- (void)rangeDeleteTime:(id)sender {
    (void)sender;
    if (![self requireRange:@"Delete Time"]) return;
    const TimelineRange r = [self arrangeRange];
    [self rangeEdit:@"Delete Time"
              audio:^(ClipEditor& e, const ProjectTrack& t) { removeAudioRange(e, t, r.start, r.end); shiftAudio(e, t, r.end, -r.length()); }
               midi:^(MidiPartEditor& e, std::vector<MidiPart>& parts, const TempoMap& tm) {
                   const double qs = tm.quarterNotesAtSample(r.start), qe = tm.quarterNotesAtSample(r.end);
                   removeMidiRange(e, parts, qs, qe);
                   shiftMidi(e, parts, qe, qs - qe);
               }];
    [_arrange clearRange];
    [self arrangeRangeChanged];
    [self setStatus:@"Time deleted — what came after moved left"];
}

- (void)rangeCutTime:(id)sender {
    (void)sender;
    if (![self requireRange:@"Cut Time"]) return;
    [self rangeCopy:nil];
    [self rangeDeleteTime:nil];
    [self setStatus:@"Time cut — what came after moved left; ⌘V pastes the range at the cursor"];
}

- (void)rangeInsertSilence:(id)sender {
    (void)sender;
    if (![self requireRange:@"Insert Silence"]) return;
    const TimelineRange r = [self arrangeRange];
    [self rangeEdit:@"Insert Silence"
              audio:^(ClipEditor& e, const ProjectTrack& t) { shiftAudio(e, t, r.start, r.length()); }
               midi:^(MidiPartEditor& e, std::vector<MidiPart>& parts, const TempoMap& tm) {
                   const double qs = tm.quarterNotesAtSample(r.start), qe = tm.quarterNotesAtSample(r.end);
                   shiftMidi(e, parts, qs, qe - qs);
               }];
    [self setStatus:@"Silence inserted — what was in the range moved right"];
}

- (void)rangeSplit:(id)sender {
    (void)sender;
    if (![self requireRange:@"Split"]) return;
    const TimelineRange r = [self arrangeRange];
    [self rangeEdit:@"Split at Range"
              audio:^(ClipEditor& e, const ProjectTrack& t) { splitAudioAt(e, t, r.start); splitAudioAt(e, t, r.end); }
               midi:^(MidiPartEditor& e, std::vector<MidiPart>& parts, const TempoMap& tm) {
                   splitMidiAt(e, parts, tm.quarterNotesAtSample(r.start));
                   splitMidiAt(e, parts, tm.quarterNotesAtSample(r.end));
               }];
    [self setStatus:@"Split at both edges of the range"];
}

- (void)rangeCrop:(id)sender {
    (void)sender;
    if (![self requireRange:@"Crop"]) return;
    const TimelineRange r = [self arrangeRange];
    [self rangeEdit:@"Crop to Range"
              audio:^(ClipEditor& e, const ProjectTrack& t) { cropAudio(e, t, r.start, r.end); }
               midi:^(MidiPartEditor& e, std::vector<MidiPart>& parts, const TempoMap& tm) { cropMidi(e, parts, tm.quarterNotesAtSample(r.start), tm.quarterNotesAtSample(r.end)); }];
    [self setStatus:@"Cropped: only the range is left on these tracks"];
}

- (void)rangePaste:(id)sender {
    (void)sender;
    if (!_core || _rangeClip.empty()) return;
    const std::int64_t at = self.playheadSample;
    const double qAt = _core->project().tempoMap.quarterNotesAtSample(at);
    const std::int64_t length = _rangeClipLength;
    const double q0 = _rangeClipQ0;
    // Where it lands: on the selected track, the other tracks of the copy keep their distance to it.
    long audioOffset = 0, midiOffset = 0;
    long firstAudio = -1, firstMidi = -1;
    for (const auto& piece : _rangeClip) {
        if (piece.kind == ArrangeRowKind::Audio && firstAudio < 0) firstAudio = static_cast<long>(piece.track);
        if (piece.kind == ArrangeRowKind::Midi && firstMidi < 0) firstMidi = static_cast<long>(piece.track);
    }
    if (self.selectedTrack >= 0 && firstAudio >= 0) audioOffset = self.selectedTrack - firstAudio;
    if (self.selectedMidiTrack >= 0 && firstMidi >= 0) midiOffset = self.selectedMidiTrack - firstMidi;
    const std::vector<SVRangePiece> pieces = _rangeClip;
    std::size_t placed = 0U;
    std::size_t* placedPtr = &placed;
    bool midiTouched = false;
    bool* midiPtr = &midiTouched;
    [self runEdit:@"Paste Range" rebuild:YES block:^{
        Project& p = self->_core->project();
        // what lies under the pasted pieces goes away (nothing is left hidden under them)
        std::vector<std::size_t> audioTargets, midiTargets;
        for (const auto& piece : pieces) {
            const long target = static_cast<long>(piece.track) + (piece.kind == ArrangeRowKind::Audio ? audioOffset : midiOffset);
            if (target < 0) continue;
            if (piece.kind == ArrangeRowKind::Audio && target < static_cast<long>(p.tracks.size())) audioTargets.push_back(static_cast<std::size_t>(target));
            if (piece.kind == ArrangeRowKind::Midi && target < static_cast<long>(p.midiTracks.size())) midiTargets.push_back(static_cast<std::size_t>(target));
        }
        std::sort(audioTargets.begin(), audioTargets.end()); audioTargets.erase(std::unique(audioTargets.begin(), audioTargets.end()), audioTargets.end());
        std::sort(midiTargets.begin(), midiTargets.end()); midiTargets.erase(std::unique(midiTargets.begin(), midiTargets.end()), midiTargets.end());
        for (std::size_t t : audioTargets) { if (p.tracks[t].locked) continue; ClipEditor e(p, t); removeAudioRange(e, p.tracks[t], at, at + length); }
        const double qEnd = p.tempoMap.quarterNotesAtSample(at + length);
        for (std::size_t t : midiTargets) { MidiPartEditor e(p.midiTracks[t].parts); removeMidiRange(e, p.midiTracks[t].parts, qAt, qEnd); }
        for (const auto& piece : pieces) {
            const long target = static_cast<long>(piece.track) + (piece.kind == ArrangeRowKind::Audio ? audioOffset : midiOffset);
            if (target < 0) continue;
            if (piece.kind == ArrangeRowKind::Audio) {
                if (target >= static_cast<long>(p.tracks.size()) || p.tracks[static_cast<std::size_t>(target)].locked) continue;
                ClipEditor e(p, static_cast<std::size_t>(target));
                ProjectAudioClip c = piece.clip;
                c.timelineStartSample += at;
                self.selectedClipId = e.addClip(std::move(c), ClipSnapSettings {});
                self.selectedTrack = target;
                ++*placedPtr;
            } else {
                if (target >= static_cast<long>(p.midiTracks.size())) continue;
                MidiPartEditor e(p.midiTracks[static_cast<std::size_t>(target)].parts);
                MidiPart part = piece.part;
                part.timelineStartQuarterNotes = std::max(0.0, part.timelineStartQuarterNotes - q0 + qAt);
                self.selectedPartId = e.add(part);
                self.selectedMidiTrack = target;
                *midiPtr = true;
                ++*placedPtr;
            }
        }
    }];
    if (midiTouched) [self republishMidi];
    [self setStatus:[NSString stringWithFormat:@"Range pasted at the cursor (%lu piece%s; what was there is replaced)", (unsigned long)placed, placed == 1U ? "" : "s"]];
}

- (void)rangeSetCycle:(id)sender {
    (void)sender;
    if (![self requireRange:@"Set Cycle"]) return;
    const TimelineRange r = [self arrangeRange];
    [self setCycleStart:r.start end:r.end];
    [self setStatus:@"Cycle set to the range"];
}

- (void)rangeZoom:(id)sender {
    (void)sender;
    if (![self requireRange:@"Zoom to Range"]) return;
    const TimelineRange r = [self arrangeRange];
    [_arrange zoomToSamples:r.start to:r.end];
}

- (void)rangeSelectAll {
    if (!_core) return;
    const Project& p = _core->project();
    std::int64_t end = 0;
    for (const auto& t : p.tracks)
        for (const auto& c : t.clips) end = std::max<std::int64_t>(end, c.timelineStartSample + static_cast<std::int64_t>(c.lengthSamples));
    for (const auto& mt : p.midiTracks)
        for (const auto& part : mt.parts) end = std::max<std::int64_t>(end, p.tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes + part.lengthQuarterNotes));
    if (end <= 0) { [self setStatus:@"Nothing to select: the project is empty"]; return; }
    std::vector<ArrangeRow> rows;
    for (const ArrangeRow& r : buildArrangeRows(p)) if (r.kind != ArrangeRowKind::Folder) rows.push_back(r);
    if (rows.empty()) return;
    [self setArrangeRange:TimelineRange {0, end} rows:rows];
    [self setStatus:@"Everything selected as a range — Delete, ⌘X, ⌘C and Edit ▸ Range work on it"];
}

@end
