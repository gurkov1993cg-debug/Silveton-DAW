// Interface between Silveton's custom views and the application controller.
#pragma once
#import <AppKit/AppKit.h>

#include "SilvetonRuntime.h"
#include "silveton/UiModel.h"

#include <cstdint>

// What a console strip / channel panel refers to.
enum class SVStripKind : int { Track = 0, Bus = 1, Master = 2 };
struct SVStrip {
    SVStripKind kind {SVStripKind::Track};
    std::size_t index {0U};
    bool operator==(const SVStrip& o) const noexcept { return kind == o.kind && (kind == SVStripKind::Master || index == o.index); }
};

enum class SVPage : int { Arrange = 0, Mix = 1, Edit = 2, Library = 3 };

@interface SilvetonController : NSObject <NSApplicationDelegate>

// Model access (control thread only).
- (sv::AppRuntime*)core;
- (silveton::Project*)project;
- (double)pixelsPerSecond;
- (void)setPixelsPerSecond:(double)pps;
- (std::int64_t)playheadSample;
- (BOOL)snapEnabled;
- (std::uint32_t)gridDivisionsPerQuarter;
- (std::int64_t)snapSample:(std::int64_t)sample;

// Selection
@property(nonatomic, assign) long selectedTrack;      // audio track index or -1
@property(nonatomic, assign) long selectedMidiTrack;  // MIDI track index or -1
@property(nonatomic, assign) long selectedFolder;     // folder vector index or -1
@property(nonatomic, assign) std::uint64_t selectedClipId;
@property(nonatomic, assign) std::uint64_t selectedPartId;
@property(nonatomic, assign) std::uint64_t selectedSectionId;
- (SVStrip)selectedStrip;
- (void)selectStrip:(SVStrip)strip;
- (void)selectRow:(silveton::ArrangeRow)row;

// Pages / refresh
- (void)showPage:(SVPage)page;
- (SVPage)currentPage;
- (void)refreshAll;
- (void)setStatus:(NSString*)text;

// Transport
- (void)seekToSample:(std::int64_t)sample;
- (void)togglePlay:(id)sender;
- (void)stop:(id)sender;
- (void)record:(id)sender;
- (void)toggleCycle:(id)sender;
- (void)toggleMetronome:(id)sender;
- (void)previousMarker:(id)sender;
- (void)nextMarker:(id)sender;
- (void)rewindBar:(id)sender;
- (void)forwardBar:(id)sender;
- (void)addMarkerAtPlayhead:(id)sender;
- (void)editTempo:(id)sender;
- (void)editSignature:(id)sender;
- (void)gotoPositionDialog:(id)sender;
- (void)setCycleStart:(std::int64_t)start end:(std::int64_t)end;

// Undoable gestures that span several mouse events.
- (void)beginGesture:(NSString*)label;
- (void)endGesture;

// Arrange
- (void)toggleMute:(silveton::ArrangeRow)row;
- (void)toggleSolo:(silveton::ArrangeRow)row;
- (void)toggleArm:(silveton::ArrangeRow)row;
- (void)toggleMonitor:(silveton::ArrangeRow)row;
- (void)toggleFolderCollapse:(std::size_t)folderIndex;
- (void)renameRow:(silveton::ArrangeRow)row;
- (void)dragClip:(std::uint64_t)clipId track:(std::size_t)track toSample:(std::int64_t)sample;
- (void)dragClipEdge:(std::uint64_t)clipId track:(std::size_t)track leftEdge:(BOOL)left toSample:(std::int64_t)sample;
- (void)dragPart:(std::uint64_t)partId midiTrack:(std::size_t)track toQuarter:(double)quarter;
- (void)createPartForMidiTrack:(std::size_t)track atSample:(std::int64_t)sample;
- (void)openEditor:(id)sender;
- (NSMenu*)contextMenuForRow:(silveton::ArrangeRow)row clip:(std::uint64_t)clipId part:(std::uint64_t)partId atSample:(std::int64_t)sample;
- (void)importAudioURLs:(NSArray<NSURL*>*)urls atSample:(std::int64_t)sample;
- (void)markerClicked:(std::uint64_t)markerId doubleClick:(BOOL)twice;
- (NSMenu*)contextMenuForMarker:(std::uint64_t)markerId;
- (void)addMarkerAtSample:(std::int64_t)sample;
- (void)sectionClicked:(std::uint64_t)sectionId doubleClick:(BOOL)twice;
- (void)createSectionFrom:(std::int64_t)start to:(std::int64_t)end;
- (NSMenu*)contextMenuForSection:(std::uint64_t)sectionId;

// Console
- (void)setStrip:(SVStrip)strip gainDb:(double)db;
- (void)setStrip:(SVStrip)strip pan:(double)pan;
- (void)toggleStripMute:(SVStrip)strip;
- (void)toggleStripSolo:(SVStrip)strip;
- (void)stripInsertClicked:(SVStrip)strip slot:(std::size_t)slot;
- (NSMenu*)insertMenuForStrip:(SVStrip)strip;
- (NSMenu*)contextMenuForStrip:(SVStrip)strip;
- (silveton::StereoMeterSnapshot)meterForStrip:(SVStrip)strip;

// Editors
- (silveton::MidiPart*)editedPart;
- (silveton::MidiSequence*)editedSequence;
- (double)editedPartOffsetQuarterNotes;   // timeline quarter of sequence position 0
- (void)noteGridAddNoteAt:(double)quarter pitch:(int)pitch;
- (void)noteGridMoveNote:(std::uint64_t)noteId toQuarter:(double)quarter pitch:(int)pitch;
- (void)noteGridResizeNote:(std::uint64_t)noteId length:(double)quarters;
- (void)noteGridDeleteNote:(std::uint64_t)noteId;
- (void)noteGridSetVelocity:(std::uint64_t)noteId velocity:(int)velocity;
- (silveton::ProjectAudioClip*)editedClip;
@end
