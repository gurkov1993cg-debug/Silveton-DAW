// Interface between Silveton's custom views and the application controller.
#pragma once
#import <AppKit/AppKit.h>

#include "SilvetonRuntime.h"
#include "silveton/AudioRangeEdit.h"
#include "silveton/MeterBank.h"
#include "silveton/UiModel.h"

#include <cstdint>
#include <vector>

// What a console strip / channel panel refers to.
enum class SVStripKind : int { Track = 0, Bus = 1, Master = 2 };
struct SVStrip {
    SVStripKind kind {SVStripKind::Track};
    std::size_t index {0U};
    bool operator==(const SVStrip& o) const noexcept { return kind == o.kind && (kind == SVStripKind::Master || index == o.index); }
};

enum class SVPage : int { Arrange = 0, Mix = 1, Edit = 2, Library = 3 };

// Tools of the Project window (as the tool buttons of Cubase, keys 1–8).
enum class SVArrangeTool : int { Select = 0, Range = 1, Split = 2, Glue = 3, Erase = 4, Zoom = 5, Mute = 6, Draw = 7 };

// One selectable audio event or MIDI part in the Project window.
// Keeping the kind and track index prevents ID collisions across tracks.
struct SVSelectedEvent {
    bool midi {false};
    std::size_t track {0U};
    std::uint64_t id {0U};
    bool operator==(const SVSelectedEvent& o) const noexcept { return midi == o.midi && track == o.track && id == o.id; }
    bool operator<(const SVSelectedEvent& o) const noexcept {
        if (midi != o.midi) return midi < o.midi;
        if (track != o.track) return track < o.track;
        return id < o.id;
    }
};
struct SVEventMoveOrigin {
    SVSelectedEvent event;
    std::int64_t startSample {0};
};

struct SVToneSession;
enum class SVToneTool : int;
struct SVKeyState;
enum class SVKeyTool : int;

@interface SilvetonController : NSObject <NSApplicationDelegate>

// Model access (control thread only).
- (sv::AppRuntime*)core;
- (silveton::Project*)project;
- (double)pixelsPerSecond;
- (void)setPixelsPerSecond:(double)pps;
- (std::int64_t)playheadSample;
- (BOOL)snapEnabled;
- (std::uint32_t)gridDivisionsPerQuarter;
- (std::int64_t)snapSample:(std::int64_t)sample;

// Selection
@property(nonatomic, assign) long selectedTrack;      // audio track index or -1
@property(nonatomic, assign) long selectedMidiTrack;  // MIDI track index or -1
@property(nonatomic, assign) long selectedFolder;     // folder vector index or -1
@property(nonatomic, assign) std::uint64_t selectedClipId;
@property(nonatomic, assign) std::uint64_t selectedPartId;
@property(nonatomic, assign) std::uint64_t selectedSectionId;
- (SVStrip)selectedStrip;
- (void)selectStrip:(SVStrip)strip;
- (void)selectRow:(silveton::ArrangeRow)row;

// Pages / refresh
- (void)showPage:(SVPage)page;
- (SVPage)currentPage;
- (void)refreshAll;
- (void)setStatus:(NSString*)text;
- (void)audioSetup:(id)sender;   // opens the Audio System Setup window

// Project page panels
- (void)toggleSnap:(id)sender;
- (void)toggleChannelPanel:(id)sender;   // Inspector on the left
- (void)toggleMeterPanel:(id)sender;     // level panel on the right
- (BOOL)channelPanelShown;
- (BOOL)meterPanelShown;
// The lower zone under the tracks (as the Lower Zone of Cubase): the compact mixer or the editor of the
// selected clip / part. The whole project stays visible above it.
- (void)toggleDockMixer:(id)sender;      // mixer under the tracks
- (void)toggleEditorZone:(id)sender;     // editor under the tracks
- (void)hideLowerZone:(id)sender;
- (void)toggleLowerZone:(id)sender;      // shows it again with the tab it had
- (void)selectZoneTab:(int)tab;          // 0 = mixer, 1 = editor (shows the zone)
- (int)zoneTab;
- (BOOL)lowerZoneShown;
- (BOOL)dockMixerShown;
- (BOOL)editorZoneShown;
- (CGFloat)zoneHeight;
- (void)setZoneHeight:(CGFloat)height;   // dragged at the zone bar
- (void)toggleEditorPlace:(id)sender;    // editor: full page <-> under the tracks
// Inspector tabs: 0 = TRACK, 1 = EDITOR
- (void)selectInspectorTab:(int)tab;
- (int)inspectorTab;
// Info line: a field was double-clicked (see SilvetonInfoLine for the field numbers)
- (void)infoFieldDoubleClicked:(NSInteger)field;
- (void)pickGrid:(id)sender;             // the item's tag = divisions per quarter note (1, 2, 4, 8)
- (void)zoomToProject:(id)sender;        // the whole project fills the tracks (the editors: all of the open material)
- (double)waveZoom;                      // how tall the waveforms are drawn in the tracks (1 = as recorded … 8)
- (void)setWaveZoom:(double)zoom;

// Transport
- (void)seekToSample:(std::int64_t)sample;
- (void)togglePlay:(id)sender;
- (void)stop:(id)sender;
- (void)record:(id)sender;
- (void)toggleCycle:(id)sender;
- (void)toggleMetronome:(id)sender;
- (void)previousMarker:(id)sender;
- (void)nextMarker:(id)sender;
- (void)rewindBar:(id)sender;
- (void)forwardBar:(id)sender;
- (void)addMarkerAtPlayhead:(id)sender;
- (void)editTempo:(id)sender;
- (void)editSignature:(id)sender;
- (void)gotoPositionDialog:(id)sender;
- (void)setCycleStart:(std::int64_t)start end:(std::int64_t)end;

// Undoable gestures that span several mouse events.
- (void)beginGesture:(NSString*)label;
- (void)endGesture;

// Actions invoked directly by the Project/Arrange view.
- (void)copyClip:(id)sender;
- (void)cutClip:(id)sender;
- (void)pasteClip:(id)sender;
- (void)duplicateClip:(id)sender;
- (void)deleteSelection:(id)sender;

// Arrange
- (void)toggleMute:(silveton::ArrangeRow)row;
- (void)toggleSolo:(silveton::ArrangeRow)row;
- (void)toggleArm:(silveton::ArrangeRow)row;
- (void)toggleMonitor:(silveton::ArrangeRow)row;
- (void)toggleFolderCollapse:(std::size_t)folderIndex;
- (void)renameRow:(silveton::ArrangeRow)row;
- (void)dragClip:(std::uint64_t)clipId track:(std::size_t)track toSample:(std::int64_t)sample;
- (void)reorderAudioTrackFrom:(std::size_t)from to:(std::size_t)to;
- (void)dragClipEdge:(std::uint64_t)clipId track:(std::size_t)track leftEdge:(BOOL)left toSample:(std::int64_t)sample;
- (void)dragPart:(std::uint64_t)partId midiTrack:(std::size_t)track toQuarter:(double)quarter;
- (void)createPartForMidiTrack:(std::size_t)track atSample:(std::int64_t)sample;
- (void)openEditor:(id)sender;
// `header`: the mouse is on the track header (the channel menu), not on the lane (clip / part / empty lane menu).
- (NSMenu*)contextMenuForRow:(silveton::ArrangeRow)row header:(BOOL)header clip:(std::uint64_t)clipId part:(std::uint64_t)partId atSample:(std::int64_t)sample;
- (void)importAudioURLs:(NSArray<NSURL*>*)urls atSample:(std::int64_t)sample;
- (void)markerClicked:(std::uint64_t)markerId doubleClick:(BOOL)twice;
- (NSMenu*)contextMenuForMarker:(std::uint64_t)markerId;
- (void)addMarkerAtSample:(std::int64_t)sample;
- (void)sectionClicked:(std::uint64_t)sectionId doubleClick:(BOOL)twice;
- (void)createSectionFrom:(std::int64_t)start to:(std::int64_t)end;
- (NSMenu*)contextMenuForSection:(std::uint64_t)sectionId;

// Project window tools (the tool row) and the range selection drawn across the tracks.
- (SVArrangeTool)arrangeTool;
- (void)setArrangeTool:(SVArrangeTool)tool;
- (void)pickArrangeTool:(id)sender;                          // menu: the item's tag is the tool
- (silveton::TimelineRange)arrangeRange;                      // the selected range (empty = none)
- (std::vector<silveton::ArrangeRow>)arrangeRangeRows;        // the tracks it covers, top to bottom (no folders)
- (BOOL)arrangeRangeActive;                                   // a range exists and the commands belong to the tracks
- (void)arrangeRangeChanged;                                  // the tracks changed the range: info line, status
- (void)setArrangeRange:(silveton::TimelineRange)range rows:(const std::vector<silveton::ArrangeRow>&)rows;
// Rectangle (marquee) selection of audio events and MIDI parts.
- (std::vector<SVSelectedEvent>)arrangeSelectedEvents;
- (void)clearArrangeSelectedEvents;
- (void)selectAllArrangeEvents;
- (void)deleteArrangeEvents;
- (void)copyArrangeEvents;
- (void)pasteArrangeEvents;
- (void)duplicateArrangeEvents;
- (void)moveArrangeEvents:(const std::vector<SVEventMoveOrigin>&)origins deltaSamples:(std::int64_t)delta;
// Automation lanes under an audio track (0 = Volume, 1 = Pan, 2 = Mute). An edit is one undo step (or part
// of the open gesture) and is heard at once; a lane that gets points while its mode is Off goes to Read.
- (silveton::AutomationMode)automationMode:(std::size_t)track lane:(int)lane;
- (void)cycleAutomationMode:(std::size_t)track lane:(int)lane;   // Off > Read > Write > Touch > Latch > Off
- (void)automationEdit:(NSString*)label track:(std::size_t)track lane:(int)lane op:(void (^)(silveton::AutomationLane& lane))op;
- (void)toggleAutomationLanes:(id)sender;                        // View menu: the lanes of the selected track
// Take lanes (the recorded takes of a track) and the comp built from them.
- (void)toggleTakeLanes:(id)sender;                              // View menu: the takes of the selected track
- (void)compUseTake:(std::size_t)track lane:(std::uint64_t)laneId;   // the whole take plays
- (void)compUseTake:(std::size_t)track lane:(std::uint64_t)laneId clip:(std::uint64_t)clipId from:(std::int64_t)start to:(std::int64_t)end;   // that part of it plays
- (void)crossfadeClips:(id)sender;                               // Audio menu (X): the selected clip and the next one blend where they meet
// Tempo track (View menu): tempo changes as points on a lane under the arranger row.
- (void)toggleTempoTrack:(id)sender;
- (void)tempoEdit:(NSString*)label op:(void (^)(silveton::TempoMap& map))op;   // one undo step, the engine follows
- (void)tempoGestureEdit:(void (^)(silveton::TempoMap& map))op;               // inside a mouse gesture: no undo step of its own
- (void)tempoTypeValueAt:(std::int64_t)sample;                                 // asks for the BPM of the change at `sample` (0 = the start)
// Marked tracks (a click on a header marks that one, ⌘-click adds or removes, ⇧-click marks the
// run up to it, ⌘A everything). The audio processes work on every clip of the marked tracks.
- (BOOL)trackMarked:(std::size_t)track;
- (void)markTrack:(std::size_t)track mode:(int)mode;   // 0 = only this one, 1 = toggle, 2 = the run from the last one
- (std::vector<std::size_t>)markedTracks;
- (void)clearMarkedTracks;
- (void)markAllTracks;
// One click with the Split / Glue / Erase / Mute tool on a clip or part.
- (void)toolClick:(SVArrangeTool)tool row:(silveton::ArrangeRow)row clip:(std::uint64_t)clipId part:(std::uint64_t)partId atSample:(std::int64_t)sample;
- (void)createPartForMidiTrack:(std::size_t)track from:(std::int64_t)start to:(std::int64_t)end;   // Draw tool
- (void)zoomToSamples:(std::int64_t)start to:(std::int64_t)end;                                   // Zoom tool, Zoom to Range

// Console
- (void)setStrip:(SVStrip)strip gainDb:(double)db;
- (void)setStrip:(SVStrip)strip pan:(double)pan;
- (void)toggleStripMute:(SVStrip)strip;
- (void)toggleStripSolo:(SVStrip)strip;
- (void)stripInsertClicked:(SVStrip)strip slot:(std::size_t)slot;
- (NSMenu*)insertMenuForStrip:(SVStrip)strip;
- (NSMenu*)contextMenuForStrip:(SVStrip)strip;
- (void)renameStrip:(SVStrip)strip;   // asks for the new name (double-click on a name, the channel menu)
- (void)updateMeters;                                           // once per UI tick: reads the engine, runs the ballistics
- (silveton::StereoMeterDisplay)meterDisplayForStrip:(SVStrip)strip;
- (silveton::StereoMeterDisplay)masterMeterDisplay;
- (std::uint32_t)meterSignature;                                // changes whenever a track-header meter visibly moved
- (void)resetMetersForStrip:(SVStrip)strip all:(BOOL)all;        // clears the clip lamp and the peak read-out

// Editors
- (silveton::MidiPart*)editedPart;
- (silveton::MidiSequence*)editedSequence;
- (double)editedPartOffsetQuarterNotes;   // timeline quarter of sequence position 0

// Key Editor (the note grid and its panel). Positions in "sequence quarters" count from the start of the edited part's notes.
- (SVKeyState*)keyState;
- (SVKeyTool)keyTool;
- (void)setKeyTool:(SVKeyTool)tool;
- (BOOL)keyEditorShown;                                    // the note grid of a MIDI part is on screen (full page or under the tracks)
- (BOOL)keyEditorActive;                                   // … and the commands belong to it (the last click was there)
- (void)noteEdit:(NSString*)label op:(void (^)(silveton::MidiSequence& seq))op;   // one undo step (or part of the open gesture)
- (void)keyAudition:(int)pitch velocity:(int)velocity on:(BOOL)on;                // the note is heard on the track's instrument
- (double)keyPlayheadQuarter;                              // the playhead in sequence quarters
- (void)keySeekToQuarter:(double)quarter;
- (double)keyBarQuarters;                                  // length of a bar in quarter notes
- (BOOL)keyCycleStart:(double*)start end:(double*)end;     // the cycle range in sequence quarters (NO when there is none)
- (BOOL)keyPartRange:(double*)start end:(double*)end;      // the part of the notes that sounds (NO when the track has no parts)
- (double)keyInsertLength;                                 // length of a new note in quarter notes
- (std::vector<std::uint64_t>)keySelectedNotes;
- (void)keySetSelectedNotes:(const std::vector<std::uint64_t>&)ids;
- (void)keyToolsChanged;                                   // the panel follows a change made in the grid (tool, scale)
- (void)keyStatus:(NSString*)text;
- (NSNumber*)keyAskControllerNumber;                       // asks for a controller number (0–127); nil when cancelled
- (silveton::ProjectAudioClip*)editedClip;

// Sample editor (audio). Positions are timeline samples at the project rate.
- (BOOL)sampleEditorActive;                       // the sample editor of a clip is on screen and the commands belong to it
- (silveton::EditSpan)sampleSpan;                 // the clips that touch the edited clip (empty when none)
- (silveton::TimelineRange)sampleSelection;       // always inside the span; empty = no selection
- (void)setSampleSelection:(silveton::TimelineRange)range;
- (BOOL)sampleZeroSnap;
- (BOOL)sampleRipple;
- (void)toggleSampleZeroSnap:(id)sender;
- (void)toggleSampleRipple:(id)sender;
- (void)sampleSelectAll:(id)sender;
- (void)sampleCropToSelection:(id)sender;
- (void)sampleLoopSelection:(id)sender;
- (void)sampleZoomIn:(id)sender;
- (void)sampleZoomOut:(id)sender;
- (void)sampleZoomFit:(id)sender;
- (void)sampleZoomSelection:(id)sender;
// Tone Editor (pitch and timing of one voice). The view changes `session->edit` itself and then
// tells the controller, which renders the sound again after a quiet moment and stores it in the project.
- (SVToneSession*)toneSession;                    // the open sound, or null
- (void)toneReadout:(NSString*)text;              // what is under the mouse, shown in the editor's strip when compact
- (BOOL)toneEditorShown;                          // the Tone Editor is on screen with a clip
- (BOOL)toneEditorActive;                         // the Tone Editor is on screen and the commands belong to it
- (SVToneTool)toneTool;
- (void)setToneTool:(SVToneTool)tool;
- (BOOL)toneCanEdit;                              // NO (with a message) while the sound loads or the track is locked
- (void)toneEdited:(NSString*)label;              // the edit changed: render again soon
- (void)toneDragBegan;                            // no render while the mouse is down ...
- (void)toneDragEnded;                            // ... until it goes up
- (void)toneSelectionChanged;                     // the selected blocks changed: refresh the controls
- (void)toneSetSelection:(const std::vector<std::uint32_t>&)ids;
- (std::int64_t)toneTimelineSample:(std::int64_t)position;     // position in the sound -> timeline sample
- (NSMenu*)toneContextMenu;
- (void)toneUp:(id)sender;
- (void)toneDown:(id)sender;
- (void)toneOctaveUp:(id)sender;
- (void)toneOctaveDown:(id)sender;
- (void)toneSelectAll:(id)sender;
- (void)toneDeleteSelected:(id)sender;
- (void)setTrackHeight:(id)sender;   // View > Track Height: the item's tag is the height (0 normal, -1 fill, -2 zoom on/off, -3 all normal)
// Fade handles (called inside beginGesture: / endGesture).
- (void)sampleSetFadesOfClip:(std::uint64_t)clipId fadeIn:(std::uint64_t)fadeIn fadeOut:(std::uint64_t)fadeOut;
// Pencil: writes hand-drawn sample values (one per timeline sample, from `start`) into the open audio.
// channel 0 / 1 = one channel, -1 = all channels. One undo step.
- (void)sampleDrawValues:(const std::vector<float>&)values start:(std::int64_t)start channel:(int)channel;
@end
