// Silveton — Sample Editor operations: select, cut, copy, paste, crop, duplicate and
// process just a part of the sound. The window itself is SilvetonSampleEditor.mm; the
// audio maths and the clip surgery are in AudioRangeEdit / SampleEditorModel (tested
// without any window code).
#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include "silveton/ClipEditor.h"
#include "silveton/SampleEditorModel.h"

#include <algorithm>
#include <cmath>

using namespace silveton;

@implementation SilvetonController (SampleEditor)

// ================================================================== state ==
- (BOOL)sampleEditorActive {
    return [self editorFocused] && _sampleView != nil && ![_sampleView isHidden] && [self editedClip] != nullptr;
}

- (EditSpan)sampleSpan {
    if (!_core || self.selectedTrack < 0 || self.selectedClipId == 0U) return {};
    const Project& p = _core->project();
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    if (track >= p.tracks.size()) return {};
    return AudioRangeEdit::span(p, track, self.selectedClipId);
}

- (TimelineRange)sampleSelection {
    const EditSpan span = [self sampleSpan];
    if (span.empty()) return {};
    TimelineRange r = _sampleSel;
    r.start = std::max(r.start, span.start);
    r.end = std::min(r.end, span.end);
    return r.valid() ? r : TimelineRange {};
}

- (void)setSampleSelection:(TimelineRange)range {
    _sampleSel = range.valid() ? range : TimelineRange {};
    [_sampleView selectionChanged];
}

- (BOOL)sampleZeroSnap { return _sampleZeroSnap; }
- (BOOL)sampleRipple { return _sampleRipple; }
- (void)toggleSampleZeroSnap:(id)sender {
    (void)sender;
    _sampleZeroSnap = !_sampleZeroSnap;
    [self setStatus:_sampleZeroSnap ? @"Zero-crossing snap on — selection edges jump to the nearest place where the sound crosses zero"
                                    : @"Zero-crossing snap off"];
    [_sampleView selectionChanged];
}
- (void)toggleSampleRipple:(id)sender {
    (void)sender;
    _sampleRipple = !_sampleRipple;
    [self setStatus:_sampleRipple ? @"Ripple on — cut and delete close the gap, paste pushes the sound after it"
                                  : @"Ripple off — cut and delete leave a gap, paste lays over the sound"];
    [_sampleView selectionChanged];
}

// ================================================================ helpers ==
// After an edit the clip that was open may be gone (cut away, split into pieces). Keep the
// editor on the sound the user is working on: the clip that holds `sample`, or the closest one.
- (void)sampleReselectNear:(std::int64_t)sample track:(std::size_t)track limit:(std::int64_t)limit {
    const Project& p = _core->project();
    if (track >= p.tracks.size()) { self.selectedClipId = 0U; [self refreshAll]; return; }
    std::uint64_t best = 0U;
    std::int64_t bestDistance = limit + 1;
    for (const auto& c : p.tracks[track].clips) {
        if (c.lengthSamples == 0U) continue;
        const std::int64_t start = c.timelineStartSample;
        const std::int64_t end = start + static_cast<std::int64_t>(c.lengthSamples);
        const std::int64_t distance = sample < start ? start - sample : (sample >= end ? sample - end + 1 : 0);
        if (distance < bestDistance) { bestDistance = distance; best = c.id; }
    }
    self.selectedClipId = best;
    [self refreshAll];   // the editor page follows (it shows the sample editor only while a clip is open)
}

// The pencil of the Sample Editor: the drawn values replace the samples under them. Only the pieces
// under the drawing get a new file, so the rest of the audio is untouched.
- (void)sampleDrawValues:(const std::vector<float>&)values start:(std::int64_t)start channel:(int)channel {
    std::size_t track = 0U; EditSpan span; TimelineRange range;
    if (values.empty() || ![self sampleTarget:@"Pencil" needSelection:NO track:&track span:&span range:&range]) return;
    std::string dir;
    try { dir = sv::processedMediaDirectory(); } catch (const std::exception& e) { [self showError:@"Pencil" detail:e.what()]; return; }
    DrawnSamples drawn;
    drawn.start = start;
    drawn.values = values;
    drawn.channel = channel;
    __block std::vector<std::string> newFiles;
    [self runEdit:@"Draw Samples" rebuild:YES block:^{
        Project& p = self->_core->project();
        const auto ids = AudioRangeEdit::draw(p, track, drawn, dir);
        for (const std::uint64_t id : ids)
            for (const auto& c : p.tracks[track].clips)
                if (c.id == id) newFiles.push_back(c.audioPath);
    }];
    for (const auto& path : newFiles) _core->waveformCache().request(path);
    [self sampleReselectNear:start track:track limit:span.length() + 1];
    [self setStatus:[NSString stringWithFormat:@"Drew %lu sample%s — ⌘Z undoes it", (unsigned long)values.size(), values.size() == 1U ? "" : "s"]];
}

// Checks that there is a sound to work on and returns where. `needSelection` also needs a selected part.
- (BOOL)sampleTarget:(NSString*)label needSelection:(BOOL)need track:(std::size_t*)track span:(EditSpan*)span range:(TimelineRange*)range {
    if (![self sampleEditorActive]) return NO;
    const long t = self.selectedTrack;
    const Project& p = _core->project();
    if (t < 0 || t >= static_cast<long>(p.tracks.size())) return NO;
    if (p.tracks[static_cast<std::size_t>(t)].locked) { [self showError:label detail:"The track is locked."]; return NO; }
    *track = static_cast<std::size_t>(t);
    *span = [self sampleSpan];
    if (span->empty()) return NO;
    *range = [self sampleSelection];
    if (need && !range->valid()) { [self setStatus:@"Select a part of the sound first — drag in the waveform"]; return NO; }
    return YES;
}

- (NSString*)sampleDurationText:(std::int64_t)samples {
    const double rate = _core->project().sampleRate > 0.0 ? _core->project().sampleRate : 48000.0;
    return sv::ns(formatClockTime(static_cast<double>(samples) / rate));
}

// What an audio process (Normalize, Gain, Fade, Stretch ...) will work on: the selected part when
// the Editor has one, otherwise the whole open clip. The process dialogs tell the user which.
- (std::int64_t)processScopeSamples {
    if ([self sampleEditorActive] && [self sampleSelection].valid()) return [self sampleSelection].length();
    ProjectAudioClip* c = [self editedClip];
    return c ? static_cast<std::int64_t>(c->lengthSamples) : 0;
}

- (NSString*)processScopeText {
    const std::int64_t n = [self processScopeSamples];
    if (n <= 0) return @"";
    if ([self sampleEditorActive] && [self sampleSelection].valid())
        return [NSString stringWithFormat:@"Applies to the selected part (%@).", [self sampleDurationText:n]];
    return [NSString stringWithFormat:@"Applies to the whole clip (%@). To change only a part, select it in the Editor first.", [self sampleDurationText:n]];
}

- (BOOL)requireProcessTarget:(NSString*)title {
    if ([self processScopeSamples] > 0) return YES;
    [self showError:title detail:"Select an audio clip first (or open it in the Editor and select a part)."];
    return NO;
}

// =================================================================== edit ==
- (void)sampleCopy:(id)sender {
    (void)sender;
    std::size_t track = 0U; EditSpan span; TimelineRange range;
    if (![self sampleTarget:@"Copy" needSelection:YES track:&track span:&span range:&range]) return;
    _rangeClipboard = AudioRangeEdit::copy(_core->project(), track, range);
    _clipboardValid = NO;   // the whole-clip clipboard must not be pasted instead of this
    [self setStatus:[NSString stringWithFormat:@"Copied %@", [self sampleDurationText:range.length()]]];
}

- (void)sampleCut:(id)sender {
    (void)sender;
    std::size_t track = 0U; EditSpan span; TimelineRange range;
    if (![self sampleTarget:@"Cut" needSelection:YES track:&track span:&span range:&range]) return;
    _rangeClipboard = AudioRangeEdit::copy(_core->project(), track, range);
    _clipboardValid = NO;
    const BOOL ripple = _sampleRipple;
    [self runEdit:@"Cut" rebuild:YES block:^{ AudioRangeEdit::erase(self->_core->project(), track, range, ripple, span.end); }];
    _sampleSel = TimelineRange {};
    [self sampleReselectNear:range.start track:track limit:span.length() + 1];
    [self seekToSample:range.start];
    [_sampleView selectionChanged];
    [self setStatus:[NSString stringWithFormat:@"Cut %@", [self sampleDurationText:range.length()]]];
}

- (void)sampleDelete:(id)sender {
    (void)sender;
    std::size_t track = 0U; EditSpan span; TimelineRange range;
    if (![self sampleTarget:@"Delete" needSelection:YES track:&track span:&span range:&range]) return;
    const BOOL ripple = _sampleRipple;
    [self runEdit:@"Delete" rebuild:YES block:^{ AudioRangeEdit::erase(self->_core->project(), track, range, ripple, span.end); }];
    _sampleSel = TimelineRange {};
    [self sampleReselectNear:range.start track:track limit:span.length() + 1];
    [self seekToSample:range.start];
    [_sampleView selectionChanged];
    [self setStatus:[NSString stringWithFormat:@"Deleted %@", [self sampleDurationText:range.length()]]];
}

- (void)samplePaste:(id)sender {
    (void)sender;
    if (_rangeClipboard.empty()) { [self setStatus:@"Nothing copied from the sample editor yet"]; return; }
    std::size_t track = 0U; EditSpan span; TimelineRange range;
    if (![self sampleTarget:@"Paste" needSelection:NO track:&track span:&span range:&range]) return;
    const RangeClipboard clip = _rangeClipboard;
    const BOOL ripple = _sampleRipple;
    std::int64_t at = range.valid() ? range.start : [self playheadSample];
    if (!range.valid() && (at < span.start || at > span.end)) {
        [self setStatus:@"Click in the waveform where the sound should go, then paste"];
        return;
    }
    const bool replace = range.valid();
    const TimelineRange pasted {at, at + clip.length};
    [self runEdit:@"Paste" rebuild:YES block:^{
        Project& p = self->_core->project();
        std::int64_t windowEnd = span.end;
        if (replace) {
            AudioRangeEdit::erase(p, track, range, ripple, windowEnd);
            if (ripple) windowEnd -= range.length();
        }
        (void)AudioRangeEdit::insert(p, track, at, clip, ripple, windowEnd);
    }];
    self.sampleSelection = pasted;
    [self sampleReselectNear:at track:track limit:span.length() + clip.length + 1];
    [self seekToSample:pasted.end];
    [self setStatus:[NSString stringWithFormat:@"Pasted %@", [self sampleDurationText:clip.length]]];
}

- (void)sampleDuplicate:(id)sender {
    (void)sender;
    std::size_t track = 0U; EditSpan span; TimelineRange range;
    if (![self sampleTarget:@"Duplicate" needSelection:YES track:&track span:&span range:&range]) return;
    const BOOL ripple = _sampleRipple;
    const RangeClipboard clip = AudioRangeEdit::copy(_core->project(), track, range);
    [self runEdit:@"Duplicate Selection" rebuild:YES block:^{
        (void)AudioRangeEdit::insert(self->_core->project(), track, range.end, clip, ripple, span.end);
    }];
    self.sampleSelection = TimelineRange {range.end, range.end + range.length()};
    [self sampleReselectNear:range.end track:track limit:span.length() + range.length() + 1];
    [self setStatus:@"Selection duplicated right after itself"];
}

- (void)sampleCropToSelection:(id)sender {
    (void)sender;
    std::size_t track = 0U; EditSpan span; TimelineRange range;
    if (![self sampleTarget:@"Crop" needSelection:YES track:&track span:&span range:&range]) return;
    [self runEdit:@"Crop to Selection" rebuild:YES block:^{ AudioRangeEdit::crop(self->_core->project(), track, range, span); }];
    [self sampleReselectNear:range.start track:track limit:range.length() + 1];
    [_sampleView selectionChanged];
    [_sampleView zoomFit];
    [self setStatus:@"Everything outside the selection was removed"];
}

- (void)sampleSelectAll:(id)sender {
    (void)sender;
    if ([self keyEditorActive]) { [self keySelectAllNotes]; return; }
    if ([self toneEditorActive]) { [self toneSelectAll:nil]; return; }
    if (![self sampleEditorActive]) return;
    const EditSpan span = [self sampleSpan];
    if (span.empty()) return;
    self.sampleSelection = TimelineRange {span.start, span.end};
}

- (void)sampleLoopSelection:(id)sender {
    (void)sender;
    if (![self sampleEditorActive]) return;
    TimelineRange r = [self sampleSelection];
    if (!r.valid()) { const EditSpan span = [self sampleSpan]; r = TimelineRange {span.start, span.end}; }
    if (!r.valid()) return;
    [self setCycleStart:r.start end:r.end];
    [self setStatus:@"Cycle set to the selection — press Play to loop it"];
}

- (void)sampleZoomIn:(id)sender { (void)sender; [_sampleView zoomBy:0.5]; }
- (void)sampleZoomOut:(id)sender { (void)sender; [_sampleView zoomBy:2.0]; }
- (void)sampleZoomFit:(id)sender { (void)sender; [_sampleView zoomFit]; }
- (void)sampleZoomSelection:(id)sender {
    (void)sender;
    if ([self keyEditorActive]) { [_noteGrid zoomToSelection]; return; }
    if ([self toneEditorActive]) { [_toneView zoomToSelection]; return; }
    [_sampleView zoomToSelection];
}

// ================================================================== fades ==
- (void)sampleSetFadesOfClip:(std::uint64_t)clipId fadeIn:(std::uint64_t)fadeIn fadeOut:(std::uint64_t)fadeOut {
    if (!_core || self.selectedTrack < 0) return;
    Project& p = _core->project();
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    if (track >= p.tracks.size() || p.tracks[track].locked) return;
    try {
        ClipEditor editor(p, track);
        editor.setFades(clipId, fadeIn, fadeOut);
        _core->session().markDirty();
        _gestureNeedsRebuild = YES;
    } catch (...) {}
}

// ================================================================ process ==
// Audio ▸ Normalize, Reverse, Fade … work on the selected part when there is one.
- (BOOL)runRangeProcess:(AudioProcess)process options:(AudioProcessOptions)options {
    std::size_t track = 0U; EditSpan span; TimelineRange range;
    if (![self sampleEditorActive] || ![self sampleSelection].valid()) return NO;
    if (![self sampleTarget:@"Audio Process" needSelection:YES track:&track span:&span range:&range]) return YES;   // locked: handled (refused)
    std::string dir;
    try { dir = sv::processedMediaDirectory(); } catch (const std::exception& e) { [self showError:@"Audio Process" detail:e.what()]; return YES; }
    __block TimelineRange after = range;
    __block std::vector<std::string> newFiles;
    [self runEdit:sv::ns(AudioProcessor::name(process)) rebuild:YES block:^{
        Project& p = self->_core->project();
        const auto ids = AudioRangeEdit::process(p, track, range, process, options, dir, span.end);
        std::int64_t first = range.start, last = range.end;
        bool any = false;
        for (const std::uint64_t id : ids) {
            for (const auto& c : p.tracks[track].clips) {
                if (c.id != id) continue;
                const std::int64_t s = c.timelineStartSample, e = s + static_cast<std::int64_t>(c.lengthSamples);
                first = any ? std::min(first, s) : s;
                last = any ? std::max(last, e) : e;
                any = true;
                newFiles.push_back(c.audioPath);
            }
        }
        after = TimelineRange {first, last};
    }];
    for (const auto& path : newFiles) _core->waveformCache().request(path);
    self.sampleSelection = after;
    [self sampleReselectNear:after.start track:track limit:span.length() + after.length() + 1];
    [self setStatus:[NSString stringWithFormat:@"%s applied to the selection", AudioProcessor::name(process)]];
    return YES;
}

@end
