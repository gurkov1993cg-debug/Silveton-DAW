// Silveton — document, track, clip, MIDI, audio-process and console actions.
#import "SilvetonControllerPrivate.h"
#include "SilvetonMeterDraw.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/ClipEditor.h"
#include "silveton/DiskStream.h"
#include "silveton/MidiPartEditor.h"
#include "silveton/OfflineBounce.h"
#include "silveton/ProjectMediaRelinker.h"
#include "silveton/StemBounce.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <set>
#include <sstream>

using namespace silveton;

@implementation SilvetonController (Actions)

// ================================================================ helpers ==
- (ClipSnapSettings)clipSnap {
    ClipSnapSettings s;
    if (!_snap) { s.mode = ClipSnapMode::Off; return s; }
    s.mode = ClipSnapMode::Musical;
    s.divisionsPerQuarter = _gridDiv;
    return s;
}

- (void)republishMidi {
    if (_core && _core->ready()) (void)_core->runtime().midiScheduler().publish(_core->project());
}

- (void)applyMixerLive {
    if (_core && _core->ready()) _core->engine().applyProjectTrackMixerState(_core->project());
}

- (void)applySolo {
    if (_core && _core->ready()) _core->runtime().applySoloState();
}

- (std::vector<ProjectPluginSlot>*)slotsForStrip:(SVStrip)strip {
    Project& p = _core->project();
    if (strip.kind == SVStripKind::Track) return strip.index < p.tracks.size() ? &p.tracks[strip.index].pluginSlots : nullptr;
    if (strip.kind == SVStripKind::Bus) return strip.index < p.buses.size() ? &p.buses[strip.index].pluginSlots : nullptr;
    return &p.masterPluginSlots;
}

- (IVst3PluginInstance*)instanceForStrip:(SVStrip)strip slot:(std::size_t)slot {
    if (!_core || !_core->ready()) return nullptr;
    auto& rack = _core->runtime().rack();
    try {
        if (strip.kind == SVStripKind::Track) return rack.trackInstance(strip.index, slot);
        if (strip.kind == SVStripKind::Bus) return rack.busInstance(strip.index, slot);
        return rack.masterInstance(slot);
    } catch (...) { return nullptr; }
}

- (NativePlugin*)nativeInstanceForStrip:(SVStrip)strip slot:(std::size_t)slot {
    auto* slots = [self slotsForStrip:strip];
    if (!slots || slot >= slots->size() || !isNativeModulePath((*slots)[slot].modulePath)) return nullptr;
    return dynamic_cast<NativePlugin*>([self instanceForStrip:strip slot:slot]);
}

- (NSString*)stripName:(SVStrip)strip {
    const Project& p = _core->project();
    if (strip.kind == SVStripKind::Track && strip.index < p.tracks.size()) return sv::ns(p.tracks[strip.index].name);
    if (strip.kind == SVStripKind::Bus && strip.index < p.buses.size()) return sv::ns(p.buses[strip.index].name);
    return @"Master";
}

- (void)openInsertEditor:(SVStrip)strip slot:(std::size_t)slot {
    auto* slots = [self slotsForStrip:strip];
    if (!slots || slot >= slots->size()) return;
    const auto& s = (*slots)[slot];
    if (isNativeModulePath(s.modulePath)) {
        __weak SilvetonController* weakSelf = self;
        const SVStrip st = strip;
        const std::size_t index = slot;
        SilvetonNativeResolver resolver = ^NativePlugin* {
            SilvetonController* strong = weakSelf;
            return strong ? [strong nativeInstanceForStrip:st slot:index] : nullptr;
        };
        if (![self nativeInstanceForStrip:strip slot:slot]) {
            [self showError:@"Plug-in" detail:"The processor is not running yet — wait a moment after adding it."];
            return;
        }
        NSString* key = [NSString stringWithFormat:@"%d:%lu:%lu", static_cast<int>(strip.kind), (unsigned long)strip.index, (unsigned long)slot];
        [SilvetonNativeEditor openWithResolver:resolver title:[NSString stringWithFormat:@"%@ — %@", [self stripName:strip], sv::ns(s.classId)] key:key];
        return;
    }
    IVst3PluginInstance* inst = [self instanceForStrip:strip slot:slot];
    if (!inst) { [self showError:@"VST3" detail:"The plug-in instance is unavailable (failed to load or still loading)."]; return; }
    if (!inst->openEditor()) [self showError:@"VST3" detail:"This plug-in has no editor window."];
}

- (void)insertPluginEntry:(const SVPluginEntry&)entry intoStrip:(SVStrip)strip {
    const SVPluginEntry e = entry;
    [self runEdit:@"Add Insert" rebuild:YES block:^{
        Project& p = self->_core->project();
        auto* slots = [self slotsForStrip:strip];
        if (!slots) throw std::runtime_error("no channel selected");
        if (slots->size() >= 16U) throw std::runtime_error("a channel holds at most 16 inserts");
        ProjectPluginSlot slot;
        slot.modulePath = e.modulePath;
        slot.classId = e.classId;
        if (e.instrument) {
            if (strip.kind != SVStripKind::Track) throw std::runtime_error("instruments belong on a track");
            slot.midiInputPort = nextFreeMidiPort(p);
            slots->insert(slots->begin(), slot);   // an instrument is the source: first slot
        } else {
            slots->push_back(slot);
        }
    }];
}

- (void)updateInputMonitoring {
    if (!_core || !_core->ready()) return;
    bool monitor = false;
    for (const auto& t : _core->project().tracks) if (t.recordArm && t.monitor) monitor = true;
    _core->engine().setLowLatencyInputMonitoring(monitor, 0.0F);
}

- (NSMenu*)paletteMenuWithAction:(SEL)action {
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Colour"];
    static NSString* names[16] = {@"Copper", @"Sage", @"Slate", @"Rose", @"Brass", @"Teal", @"Lavender", @"Brick",
                                  @"Moss", @"Ocean", @"Walnut", @"Ice", @"Mustard", @"Plum", @"Pine", @"Dusk"};
    NSMenuItem* autoItem = [m addItemWithTitle:@"Automatic" action:action keyEquivalent:@""];
    autoItem.tag = 0; autoItem.target = self;
    for (int i = 0; i < 16; ++i) {
        NSMenuItem* it = [m addItemWithTitle:names[i] action:action keyEquivalent:@""];
        it.tag = static_cast<NSInteger>(silvetonPaletteColor(static_cast<std::size_t>(i)));
        it.target = self;
        NSImage* sw = [[NSImage alloc] initWithSize:NSMakeSize(12, 12)];
        [sw lockFocus];
        sv::roundFill(NSMakeRect(0, 0, 12, 12), 3, sv::hex(silvetonPaletteColor(static_cast<std::size_t>(i))));
        [sw unlockFocus];
        it.image = sw;
    }
    return m;
}

// ================================================================== file ==
- (void)newProject:(id)sender {
    (void)sender;
    if (!_core) return;
    try {
        if (_core->recording()) _core->stopRecording(true);
        _core->engine().transport().stop();
        [SilvetonNativeEditor closeAll];
        _core->session().newProject(_core->device().config().sampleRate);
        _core->waveformCache().clear();
        self.selectedTrack = -1; self.selectedMidiTrack = -1; self.selectedClipId = 0; self.selectedPartId = 0;
        [self requestRebuild];
        [self refreshAll];
    } catch (const std::exception& e) { [self showError:@"New Project" detail:e.what()]; }
}

- (void)openProject:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.allowedFileTypes = @[@"silveton", @"siv"];
    if ([panel runModal] != NSModalResponseOK) return;
    try {
        if (_core->recording()) _core->stopRecording(true);
        _core->engine().transport().stop();
        [SilvetonNativeEditor closeAll];
        const auto result = _core->session().open(sv::str(panel.URL.path));
        _core->waveformCache().clear();
        self.selectedTrack = -1; self.selectedMidiTrack = -1; self.selectedClipId = 0; self.selectedPartId = 0;
        [self requestRebuild];
        [self refreshAll];
        if (result.recovered) [self showError:@"Project recovered" detail:"A recovery copy was loaded: " + result.loadedPath];
    } catch (const std::exception& e) { [self showError:@"Open Project" detail:e.what()]; }
}

- (void)saveProject:(id)sender {
    (void)sender;
    try {
        if (!_core->session().hasProjectPath()) { [self saveProjectAs:nil]; return; }
        _core->session().save();
        [self updateTitle];
        [self setStatus:@"Saved"];
    } catch (const std::exception& e) { [self showError:@"Save" detail:e.what()]; }
}

- (void)saveProjectAs:(id)sender {
    (void)sender;
    NSSavePanel* panel = [NSSavePanel savePanel];
    panel.allowedFileTypes = @[@"silveton"];
    panel.nameFieldStringValue = @"Song.silveton";
    if ([panel runModal] != NSModalResponseOK) return;
    try { _core->session().saveAs(sv::str(panel.URL.path)); [self updateTitle]; }
    catch (const std::exception& e) { [self showError:@"Save As" detail:e.what()]; }
}

- (void)undo:(id)sender { (void)sender; try { [SilvetonNativeEditor closeAll]; if (_core->session().undo()) [self refreshAll]; } catch (const std::exception& e) { [self showError:@"Undo" detail:e.what()]; } }
- (void)redo:(id)sender { (void)sender; try { [SilvetonNativeEditor closeAll]; if (_core->session().redo()) [self refreshAll]; } catch (const std::exception& e) { [self showError:@"Redo" detail:e.what()]; } }

- (void)importAudio:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.allowedFileTypes = @[@"wav", @"aif", @"aiff"];
    panel.allowsMultipleSelection = YES;
    if ([panel runModal] != NSModalResponseOK) return;
    [self importAudioURLs:panel.URLs atSample:self.playheadSample];
}

- (void)importAudioURLs:(NSArray<NSURL*>*)urls atSample:(std::int64_t)timelineSample {
    if (!_core || urls.count == 0) return;
    // The files are NOT converted and NOT copied: a 44.1/48 kHz file stays exactly as it is
    // on disk. The engine runs at the internal rate (96 kHz) and converts each file while it
    // plays, with the same Studio sinc, one cache page at a time. The clip therefore counts
    // its frames at the project rate (what the engine plays), the file's own rate is kept for
    // information.
    struct Item { std::string media, name; std::uint64_t frames {0U}; std::uint32_t channels {0U}, fileRate {0U}; };
    std::vector<Item> items;
    const double projectRate = _core->project().sampleRate;
    const auto targetRate = projectRate >= 8000.0 ? static_cast<std::uint32_t>(std::llround(projectRate)) : 0U;
    std::set<std::uint32_t> otherRates;
    try {
        for (NSURL* u in urls) {
            Item it;
            it.media = sv::str(u.path);
            it.name = sv::str([[u lastPathComponent] stringByDeletingPathExtension]);
            DiskStreamManager inspect(1U);
            auto& src = inspect.addSource(it.media, 16384U, targetRate);   // frames counted at the project rate
            it.frames = src.frames(); it.channels = src.channels(); it.fileRate = src.nativeSampleRate();
            if (it.channels == 0U || it.channels > 2U) throw std::runtime_error("Silveton imports mono or stereo WAV/AIFF files");
            if (src.rateConverted()) otherRates.insert(it.fileRate);
            items.push_back(std::move(it));
        }
    } catch (const std::exception& e) { [self showError:@"Import Audio" detail:e.what()]; return; }

    __block std::size_t imported = 0U;
    [self runEdit:@"Import Audio" rebuild:YES block:^{
        Project& project = self->_core->project();
        for (const auto& it : items) {
            ProjectTrack t;
            t.name = it.name;
            t.audioPath = it.media;
            ProjectAudioClip c;
            c.id = 1U; c.audioPath = it.media; c.timelineStartSample = std::max<std::int64_t>(0, timelineSample);
            c.lengthSamples = it.frames; c.sourceFrames = it.frames; c.sourceChannels = it.channels; c.sourceSampleRate = it.fileRate;
            t.clips.push_back(c);
            project.addTrack(std::move(t));
            self->_core->waveformCache().request(it.media);
            ++imported;
        }
        if (imported == 0U) throw std::runtime_error("no supported files");
        self.selectedTrack = static_cast<long>(project.tracks.size()) - 1;
        self.selectedClipId = 1U;
    }];
    if (!imported) return;
    NSMutableString* rates = [NSMutableString string];
    for (const auto r : otherRates) [rates appendFormat:@"%@%g kHz", rates.length ? @" / " : @"", r / 1000.0];
    [self setStatus:otherRates.empty()
        ? [NSString stringWithFormat:@"Imported %lu file(s)", (unsigned long)imported]
        : [NSString stringWithFormat:@"Imported %lu file(s) — files stay at %@; Silveton plays them at %.0f kHz", (unsigned long)imported, rates, projectRate / 1000.0]];
}

- (void)importMidi:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.allowedFileTypes = @[@"mid", @"midi", @"smf"];
    if ([panel runModal] != NSModalResponseOK) return;
    try {
        const auto smf = StandardMidiFile::read(sv::str(panel.URL.path), _core->project().sampleRate, true);
        if (smf.tracks.empty()) throw std::runtime_error("the file contains no notes or controllers");
        const bool adoptTempo = _core->project().tracks.empty() && _core->project().midiTracks.empty();
        [self runEdit:@"Import MIDI File" rebuild:YES block:^{
            Project& p = self->_core->project();
            if (adoptTempo) { p.tempoMap = smf.tempoMap; p.tempo = smf.tempoMap.initialTempo(); }
            for (const auto& t : smf.tracks) {
                if (p.tracks.size() >= Project::kMaxTracks) break;
                const bool drums = t.firstChannel == 9;
                ProjectTrack inst;
                inst.name = t.name.empty() ? (drums ? "Drums" : "MIDI") : t.name;
                ProjectPluginSlot synth;
                synth.modulePath = kNativeModulePath;
                synth.classId = "silveton.poly";
                synth.midiInputPort = nextFreeMidiPort(p);
                inst.pluginSlots.push_back(synth);
                const int port = synth.midiInputPort;
                p.addTrack(std::move(inst));
                ProjectMidiTrack mt;
                mt.name = t.name.empty() ? "MIDI" : t.name;
                mt.outputPort = port;
                (void)MidiTrackTools::addPartFromAbsolute(mt, t.sequence, 4.0);
                p.midiTracks.push_back(std::move(mt));
            }
        }];
        [self setStatus:[NSString stringWithFormat:@"Imported %lu MIDI track(s)%@", (unsigned long)smf.tracks.size(), adoptTempo ? @" with tempo map" : @""]];
    } catch (const std::exception& e) { [self showError:@"Import MIDI" detail:e.what()]; }
}

- (void)exportMidi:(id)sender {
    (void)sender;
    const Project& p = _core->project();
    if (p.midiTracks.empty()) { [self showError:@"Export MIDI" detail:"The project has no MIDI tracks."]; return; }
    NSSavePanel* panel = [NSSavePanel savePanel];
    panel.allowedFileTypes = @[@"mid"];
    panel.nameFieldStringValue = @"Silveton.mid";
    if ([panel runModal] != NSModalResponseOK) return;
    try {
        std::vector<MidiSequence> flat;
        flat.reserve(p.midiTracks.size());
        std::vector<SmfExportTrack> tracks;
        for (const auto& mt : p.midiTracks) flat.push_back(sequenceFromRenderPlan(compileMidiArrangement(mt.sequence, mt.parts, p.tempoMap), p.tempoMap));
        for (std::size_t i = 0; i < p.midiTracks.size(); ++i) tracks.push_back({p.midiTracks[i].name, &flat[i]});
        StandardMidiFile::write(sv::str(panel.URL.path), tracks, p.tempoMap, 480U);
        [self setStatus:@"MIDI file exported"];
    } catch (const std::exception& e) { [self showError:@"Export MIDI" detail:e.what()]; }
}

- (OfflineBounceOptions)bounceOptions {
    OfflineBounceOptions o;
    const Project& p = _core->project();
    std::int64_t end = 1;
    for (const auto& t : p.tracks) for (const auto& c : t.clips) end = std::max<std::int64_t>(end, c.timelineStartSample + static_cast<std::int64_t>(c.lengthSamples));
    for (const auto& m : p.midiTracks) {
        for (const auto& part : m.parts) end = std::max(end, p.tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes + part.lengthQuarterNotes));
        for (const auto& n : m.sequence.notes()) end = std::max(end, p.tempoMap.sampleAtQuarterNotes(n.startQuarterNotes + n.durationQuarterNotes));
    }
    o.startSample = 0;
    o.endSample = end;
    if (_core->ready()) {
        const auto& t = _core->engine().transport();
        if (t.cycleEnabled() && t.cycleEndSample() > t.cycleStartSample()) { o.startSample = t.cycleStartSample(); o.endSample = t.cycleEndSample(); }
    }
    o.tailMode = BounceTailMode::Automatic;
    o.preRollSamples = static_cast<std::uint64_t>(p.sampleRate * 0.1);
    return o;
}

- (BOOL)chooseFormat:(OfflineBounceFileOptions*)f panel:(NSSavePanel*)panel {
    NSAlert* a = [[NSAlert alloc] init];
    a.messageText = @"Export Format";
    a.informativeText = @"Range: the loop when it is on, otherwise the whole project (plus effect tails).";
    [a addButtonWithTitle:@"Continue"];
    [a addButtonWithTitle:@"Cancel"];
    NSView* v = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 360, 72)];
    NSPopUpButton* container = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(0, 42, 170, 26) pullsDown:NO];
    [container addItemsWithTitles:@[@"WAV", @"AIFF"]];
    NSPopUpButton* format = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(185, 42, 175, 26) pullsDown:NO];
    [format addItemsWithTitles:@[@"32-bit Float", @"24-bit PCM", @"16-bit PCM", @"32-bit PCM"]];
    NSPopUpButton* rate = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(0, 6, 170, 26) pullsDown:NO];
    [rate addItemsWithTitles:@[@"Project Rate", @"44100", @"48000", @"88200", @"96000"]];
    NSButton* dither = [[NSButton alloc] initWithFrame:NSMakeRect(185, 8, 175, 22)];
    [dither setButtonType:NSButtonTypeSwitch];
    dither.title = @"TPDF Dither";
    for (NSView* sub in @[container, format, rate, dither]) [v addSubview:sub];
    a.accessoryView = v;
    if ([a runModal] != NSAlertFirstButtonReturn) return NO;
    f->container = container.indexOfSelectedItem == 1 ? BounceContainer::Aiff : BounceContainer::Wav;
    switch (format.indexOfSelectedItem) {
        case 1: f->sampleFormat = BounceSampleFormat::Pcm24; break;
        case 2: f->sampleFormat = BounceSampleFormat::Pcm16; break;
        case 3: f->sampleFormat = BounceSampleFormat::Pcm32; break;
        default: f->sampleFormat = BounceSampleFormat::Float32; break;
    }
    if (f->container == BounceContainer::Aiff && f->sampleFormat == BounceSampleFormat::Float32) f->sampleFormat = BounceSampleFormat::Pcm32;
    f->dither = (dither.state == NSControlStateValueOn && f->sampleFormat != BounceSampleFormat::Float32) ? BounceDither::Tpdf : BounceDither::None;
    if (rate.indexOfSelectedItem > 0) f->outputSampleRate = static_cast<std::uint32_t>(rate.titleOfSelectedItem.intValue);
    panel.allowedFileTypes = @[f->container == BounceContainer::Aiff ? @"aiff" : @"wav"];
    return YES;
}

- (void)exportMixdown:(id)sender {
    (void)sender;
    NSSavePanel* panel = [NSSavePanel savePanel];
    panel.nameFieldStringValue = @"Silveton Mix";
    OfflineBounceFileOptions f;
    if (![self chooseFormat:&f panel:panel]) return;
    if ([panel runModal] != NSModalResponseOK) return;
    try {
        sv::AppRuntime::OfflineScope scope(*_core);
        const auto r = OfflineBounce::renderAudioFile(sv::str(panel.URL.path), _core->project(), _core->engine(), &_core->runtime().rack(), [self bounceOptions], f);
        [self setStatus:[NSString stringWithFormat:@"Exported %.1f s, peak %.1f dBFS", r.writtenFrames / std::max(1.0, static_cast<double>(r.outputSampleRate)),
                         20.0 * std::log10(std::max(1e-9, static_cast<double>(r.peak)))]];
    } catch (const std::exception& e) { [self showError:@"Export Mixdown" detail:e.what()]; }
}

- (void)exportStems:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.canChooseFiles = NO; panel.canChooseDirectories = YES; panel.canCreateDirectories = YES;
    panel.prompt = @"Export Stems Here";
    if ([panel runModal] != NSModalResponseOK) return;
    try {
        const Project& p = _core->project();
        std::vector<TrackStemRequest> req;
        for (std::size_t i = 0; i < p.tracks.size(); ++i) {
            std::string n = p.tracks[i].name.empty() ? "Track " + std::to_string(i + 1) : p.tracks[i].name;
            for (auto& ch : n) if (ch == '/' || ch == ':') ch = '_';
            req.push_back({sv::str(panel.URL.path) + "/" + std::to_string(i + 1) + " " + n + ".wav", {i}});
        }
        if (req.empty()) throw std::runtime_error("the project has no tracks");
        sv::AppRuntime::OfflineScope scope(*_core);
        OfflineBounceFileOptions f;
        f.sampleFormat = BounceSampleFormat::Pcm24;
        const auto results = StemBounce::renderTrackStems(_core->project(), _core->engine(), &_core->runtime().rack(), [self bounceOptions], f, req);
        [self setStatus:[NSString stringWithFormat:@"%lu stem(s) exported", (unsigned long)results.size()]];
    } catch (const std::exception& e) { [self showError:@"Export Stems" detail:e.what()]; }
}

- (void)audioSetup:(id)sender {
    (void)sender;
    try {
        const auto devices = CoreAudioDevice::devices();
        NSAlert* a = [[NSAlert alloc] init];
        a.messageText = @"Audio System Setup";
        a.informativeText = @"Device, buffer size and sample rate.";
        [a addButtonWithTitle:@"Apply"];
        [a addButtonWithTitle:@"Cancel"];
        NSView* v = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 360, 70)];
        NSPopUpButton* d = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(0, 40, 360, 26) pullsDown:NO];
        for (const auto& x : devices) [d addItemWithTitle:[NSString stringWithFormat:@"%@  (%u in / %u out)", sv::ns(x.name), x.inputChannels, x.outputChannels]];
        NSPopUpButton* b = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(0, 6, 170, 26) pullsDown:NO];
        for (NSString* s in @[@"64", @"128", @"256", @"512", @"1024", @"2048"]) [b addItemWithTitle:s];
        [b selectItemWithTitle:[NSString stringWithFormat:@"%u", _core->device().config().blockSize]];
        NSPopUpButton* sr = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(185, 6, 175, 26) pullsDown:NO];
        for (NSString* s in @[@"44100", @"48000", @"88200", @"96000"]) [sr addItemWithTitle:s];
        [sr selectItemWithTitle:[NSString stringWithFormat:@"%.0f", _core->device().config().sampleRate]];
        for (NSView* sub in @[d, b, sr]) [v addSubview:sub];
        a.accessoryView = v;
        if ([a runModal] != NSAlertFirstButtonReturn) return;
        const NSInteger idx = d.indexOfSelectedItem;
        if (idx < 0 || idx >= static_cast<NSInteger>(devices.size())) return;
        const auto& dev = devices[static_cast<std::size_t>(idx)];
        AudioDeviceConfig cfg;
        cfg.sampleRate = sr.titleOfSelectedItem.doubleValue;
        cfg.blockSize = static_cast<std::uint32_t>(b.titleOfSelectedItem.intValue);
        cfg.inputChannels = std::min<std::uint32_t>(2U, dev.inputChannels);
        cfg.outputChannels = std::min<std::uint32_t>(2U, dev.outputChannels);
        if (cfg.outputChannels == 0U) throw std::runtime_error("that device has no outputs");
        CoreAudioDeviceOptions opts;
        opts.deviceUid = dev.uid;
        opts.followDefaultOutputDevice = false;
        [SilvetonNativeEditor closeAll];
        _core->restartAudio(cfg, opts);
        [self refreshAll];
    } catch (const std::exception& e) { [self showError:@"Audio Setup" detail:e.what()]; }
}

// ================================================================ tracks ==
- (void)addAudioTrack:(id)sender {
    (void)sender;
    [self runEdit:@"Add Audio Track" rebuild:YES block:^{
        Project& p = self->_core->project();
        ProjectTrack t;
        t.name = "Audio " + std::to_string(p.tracks.size() + 1);
        p.addTrack(std::move(t));
        self.selectedTrack = static_cast<long>(p.tracks.size()) - 1;
        self.selectedMidiTrack = -1;
    }];
}

- (void)addInstrumentTrackWith:(const SVPluginEntry&)entry {
    const SVPluginEntry e = entry;
    [self runEdit:@"Add Instrument Track" rebuild:YES block:^{
        Project& p = self->_core->project();
        const int port = nextFreeMidiPort(p);
        ProjectTrack inst;
        inst.name = e.name;
        ProjectPluginSlot slot;
        slot.modulePath = e.modulePath; slot.classId = e.classId; slot.midiInputPort = port;
        inst.pluginSlots.push_back(slot);
        p.addTrack(std::move(inst));
        ProjectMidiTrack mt;
        mt.name = e.name;
        mt.outputPort = port;
        p.midiTracks.push_back(std::move(mt));
        self.selectedMidiTrack = static_cast<long>(p.midiTracks.size()) - 1;
        self.selectedTrack = -1;
        if (self->_core->midi()) self->_core->midi()->setTargetPort(port);
    }];
}

- (void)addInstrumentTrack:(id)sender {
    SVPluginEntry e;
    e.native = true; e.instrument = true; e.modulePath = kNativeModulePath; e.classId = "silveton.poly"; e.name = "Poly Synth";
    if ([sender isKindOfClass:[NSMenuItem class]] && [[sender representedObject] isKindOfClass:[NSDictionary class]]) {
        NSDictionary* d = [sender representedObject];
        e.native = [d[@"native"] boolValue]; e.modulePath = sv::str(d[@"module"]); e.classId = sv::str(d[@"class"]); e.name = sv::str(d[@"name"]);
    }
    [self addInstrumentTrackWith:e];
}

- (void)addMidiTrack:(id)sender {
    (void)sender;
    [self runEdit:@"Add MIDI Track" rebuild:YES block:^{
        Project& p = self->_core->project();
        ProjectMidiTrack mt;
        mt.name = "MIDI " + std::to_string(p.midiTracks.size() + 1);
        p.midiTracks.push_back(std::move(mt));
        self.selectedMidiTrack = static_cast<long>(p.midiTracks.size()) - 1;
        self.selectedTrack = -1;
    }];
}

- (void)addGroupBus:(id)sender {
    (void)sender;
    [self runEdit:@"Add Group" rebuild:YES block:^{
        ProjectBus b; b.kind = ProjectBusKind::Group; b.name = "Group " + std::to_string(self->_core->project().buses.size() + 1);
        TrackTools::addBus(self->_core->project(), std::move(b));
    }];
}
- (void)addFxBus:(id)sender {
    (void)sender;
    [self runEdit:@"Add FX Channel" rebuild:YES block:^{
        ProjectBus b; b.kind = ProjectBusKind::FxReturn; b.name = "FX " + std::to_string(self->_core->project().buses.size() + 1);
        ProjectPluginSlot verb; verb.modulePath = kNativeModulePath; verb.classId = "silveton.space";
        std::string why;
        if (auto proto = createNativePlugin("silveton.space", why)) { proto->setPlainValue(7, 100.0); verb.componentState = proto->componentState(); }
        b.pluginSlots.push_back(verb);
        TrackTools::addBus(self->_core->project(), std::move(b));
    }];
}
- (void)addFolder:(id)sender {
    (void)sender;
    NSString* name = [self promptText:@"New Folder" message:@"Selected track moves into the folder." initial:@"Folder"];
    if (!name) return;
    [self runEdit:@"Add Folder" rebuild:NO block:^{
        Project& p = self->_core->project();
        const int id = FolderTools::addFolder(p, sv::str(name));
        if (self.selectedTrack >= 0) p.tracks[static_cast<std::size_t>(self.selectedTrack)].folder = id;
        if (self.selectedMidiTrack >= 0) p.midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)].folder = id;
    }];
}

- (void)duplicateTrack:(id)sender {
    (void)sender;
    if (self.selectedTrack < 0) return;
    [self runEdit:@"Duplicate Track" rebuild:YES block:^{
        self.selectedTrack = static_cast<long>(TrackTools::duplicateTrack(self->_core->project(), static_cast<std::size_t>(self.selectedTrack)));
    }];
}

- (void)deleteTrack:(id)sender {
    (void)sender;
    [SilvetonNativeEditor closeAll];
    if (self.selectedTrack >= 0) {
        const auto index = static_cast<std::size_t>(self.selectedTrack);
        [self runEdit:@"Delete Track" rebuild:YES block:^{ TrackTools::removeTrack(self->_core->project(), index); }];
        self.selectedTrack = -1; self.selectedClipId = 0;
    } else if (self.selectedMidiTrack >= 0) {
        const auto index = static_cast<std::size_t>(self.selectedMidiTrack);
        [self runEdit:@"Delete MIDI Track" rebuild:YES block:^{
            auto& v = self->_core->project().midiTracks;
            v.erase(v.begin() + static_cast<std::ptrdiff_t>(index));
        }];
        self.selectedMidiTrack = -1; self.selectedPartId = 0;
    } else if (self.selectedFolder >= 0) {
        const int id = _core->project().folders[static_cast<std::size_t>(self.selectedFolder)].id;
        [self runEdit:@"Delete Folder" rebuild:NO block:^{ (void)FolderTools::removeFolder(self->_core->project(), id); }];
        self.selectedFolder = -1;
    }
    [self refreshAll];
}

- (void)moveTrack:(int)dir {
    if (self.selectedTrack < 0) return;
    const long to = self.selectedTrack + dir;
    if (to < 0 || to >= static_cast<long>(_core->project().tracks.size())) return;
    const auto from = static_cast<std::size_t>(self.selectedTrack);
    [self runEdit:@"Move Track" rebuild:YES block:^{ TrackTools::moveTrack(self->_core->project(), from, static_cast<std::size_t>(to)); }];
    self.selectedTrack = to;
    [self refreshAll];
}
- (void)moveTrackUp:(id)sender { (void)sender; [self moveTrack:-1]; }
- (void)moveTrackDown:(id)sender { (void)sender; [self moveTrack:1]; }

- (void)projectNotes:(id)sender {
    (void)sender;
    NSString* s = [self promptText:@"Project Notes" message:@"" initial:sv::ns(_core->project().notes)];
    if (!s) return;
    [self runEdit:@"Project Notes" rebuild:NO block:^{ self->_core->project().notes = sv::str(s); }];
}

- (void)flattenArranger:(id)sender {
    (void)sender;
    if (_core->project().arrangerChain.empty()) { [self showError:@"Flatten Chain" detail:"Build an arranger chain first (Library ▸ Arranger)."]; return; }
    [SilvetonNativeEditor closeAll];
    [self runEdit:@"Flatten Arranger Chain" rebuild:YES block:^{
        Project flat = ArrangerTools::flattenChain(self->_core->project());
        self->_core->project() = std::move(flat);
    }];
    [self setStatus:@"Arranger chain flattened into the timeline"];
}

// ============================================================ row toggles ==
- (void)toggleMute:(ArrangeRow)row {
    Project& p = _core->project();
    if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) {
        [self runEdit:@"Mute" rebuild:NO block:^{ auto& t = self->_core->project().tracks[row.index]; t.mute = !t.mute; }];
        [self applyMixerLive];
    } else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) {
        [self runEdit:@"Mute MIDI" rebuild:NO block:^{ auto& t = self->_core->project().midiTracks[row.index]; t.mute = !t.mute; }];
        [self republishMidi];
    } else if (row.kind == ArrangeRowKind::Folder && row.index < p.folders.size()) {
        const int id = p.folders[row.index].id;
        bool all = true, any = false;
        for (const auto& t : p.tracks) if (FolderTools::isInside(p, t.folder, id)) { any = true; all &= t.mute; }
        const bool target = !(any && all);
        [self runEdit:@"Mute Folder" rebuild:NO block:^{ FolderTools::setMute(self->_core->project(), id, target); }];
        [self applyMixerLive];
        [self republishMidi];
    }
    [self refreshAll];
}

- (void)toggleSolo:(ArrangeRow)row {
    Project& p = _core->project();
    if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) p.tracks[row.index].solo = !p.tracks[row.index].solo;
    else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) p.midiTracks[row.index].solo = !p.midiTracks[row.index].solo;
    else if (row.kind == ArrangeRowKind::Folder && row.index < p.folders.size()) {
        const int id = p.folders[row.index].id;
        bool any = false;
        for (const auto& t : p.tracks) if (FolderTools::isInside(p, t.folder, id) && t.solo) any = true;
        FolderTools::setSolo(p, id, !any);
    }
    _core->session().markDirty();
    [self applySolo];
    [self refreshAll];
}

- (void)toggleArm:(ArrangeRow)row {
    Project& p = _core->project();
    if (row.kind != ArrangeRowKind::Audio || row.index >= p.tracks.size()) return;
    p.tracks[row.index].recordArm = !p.tracks[row.index].recordArm;
    _core->session().markDirty();
    [self updateInputMonitoring];
    [self refreshAll];
}

- (void)toggleMonitor:(ArrangeRow)row {
    Project& p = _core->project();
    if (row.kind != ArrangeRowKind::Audio || row.index >= p.tracks.size()) return;
    p.tracks[row.index].monitor = !p.tracks[row.index].monitor;
    _core->session().markDirty();
    [self updateInputMonitoring];
    [self refreshAll];
}

- (void)toggleFolderCollapse:(std::size_t)folderIndex {
    Project& p = _core->project();
    if (folderIndex >= p.folders.size()) return;
    p.folders[folderIndex].collapsed = !p.folders[folderIndex].collapsed;
    _core->session().markDirty();
    [self refreshAll];
}

- (void)renameRow:(ArrangeRow)row {
    Project& p = _core->project();
    NSString* current = @"";
    if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) current = sv::ns(p.tracks[row.index].name);
    else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) current = sv::ns(p.midiTracks[row.index].name);
    else if (row.kind == ArrangeRowKind::Folder && row.index < p.folders.size()) current = sv::ns(p.folders[row.index].name);
    else return;
    NSString* name = [self promptText:@"Rename" message:@"" initial:current];
    if (!name.length) return;
    [self runEdit:@"Rename" rebuild:NO block:^{
        Project& pr = self->_core->project();
        if (row.kind == ArrangeRowKind::Audio) pr.tracks[row.index].name = sv::str(name);
        else if (row.kind == ArrangeRowKind::Midi) pr.midiTracks[row.index].name = sv::str(name);
        else pr.folders[row.index].name = sv::str(name);
    }];
}
- (void)renameSelected:(id)sender {
    (void)sender;
    ArrangeRow r;
    if (self.selectedTrack >= 0) { r.kind = ArrangeRowKind::Audio; r.index = static_cast<std::size_t>(self.selectedTrack); }
    else if (self.selectedMidiTrack >= 0) { r.kind = ArrangeRowKind::Midi; r.index = static_cast<std::size_t>(self.selectedMidiTrack); }
    else if (self.selectedFolder >= 0) { r.kind = ArrangeRowKind::Folder; r.index = static_cast<std::size_t>(self.selectedFolder); }
    else return;
    [self renameRow:r];
}

- (void)setRowColour:(NSMenuItem*)item {
    const auto color = static_cast<std::uint32_t>(item.tag);
    const ArrangeRow row = _menuRow;
    [self runEdit:@"Colour" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) p.tracks[row.index].color = color;
        else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) p.midiTracks[row.index].color = color;
        else if (row.kind == ArrangeRowKind::Folder && row.index < p.folders.size()) p.folders[row.index].color = color;
    }];
}

- (void)toggleLock:(id)sender {
    (void)sender;
    if (self.selectedTrack < 0) return;
    [self runEdit:@"Lock Track" rebuild:NO block:^{
        auto& t = self->_core->project().tracks[static_cast<std::size_t>(self.selectedTrack)];
        t.locked = !t.locked;
    }];
}

- (void)moveToFolder:(NSMenuItem*)item {
    const int folder = static_cast<int>(item.tag);
    const ArrangeRow row = _menuRow;
    [self runEdit:@"Move to Folder" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) p.tracks[row.index].folder = folder;
        else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) p.midiTracks[row.index].folder = folder;
    }];
}

- (void)setMidiOutput:(NSMenuItem*)item {
    const int port = static_cast<int>(item.tag);
    const long track = _menuRow.kind == ArrangeRowKind::Midi ? static_cast<long>(_menuRow.index) : self.selectedMidiTrack;
    if (track < 0) return;
    [self runEdit:@"MIDI Output" rebuild:NO block:^{ self->_core->project().midiTracks[static_cast<std::size_t>(track)].outputPort = port; }];
    [self republishMidi];
    if (_core->midi()) _core->midi()->setTargetPort(port);
}

// ================================================================= clips ==
- (void)dragClip:(std::uint64_t)clipId track:(std::size_t)track toSample:(std::int64_t)sample {
    Project& p = _core->project();
    if (track >= p.tracks.size() || p.tracks[track].locked) return;
    try {
        ClipEditor editor(p, track);
        editor.moveClip(clipId, sample, [self clipSnap]);
        _core->session().markDirty();
        _gestureNeedsRebuild = YES;
    } catch (...) {}
}

- (void)dragClipEdge:(std::uint64_t)clipId track:(std::size_t)track leftEdge:(BOOL)left toSample:(std::int64_t)sample {
    Project& p = _core->project();
    if (track >= p.tracks.size() || p.tracks[track].locked) return;
    try {
        ClipEditor editor(p, track);
        if (left) editor.trimLeft(clipId, sample, [self clipSnap]);
        else editor.trimRight(clipId, sample, [self clipSnap]);
        _core->session().markDirty();
        _gestureNeedsRebuild = YES;
    } catch (...) {}
}

- (ProjectAudioClip*)editedClip {
    if (!_core || self.selectedTrack < 0 || self.selectedClipId == 0) return nullptr;
    Project& p = _core->project();
    if (self.selectedTrack >= static_cast<long>(p.tracks.size())) return nullptr;
    for (auto& c : p.tracks[static_cast<std::size_t>(self.selectedTrack)].clips) if (c.id == self.selectedClipId) return &c;
    return nullptr;
}

- (void)clipEdit:(NSString*)label op:(void (^)(ClipEditor& editor))op {
    if (self.selectedTrack < 0 || ![self editedClip]) return;
    if (_core->project().tracks[static_cast<std::size_t>(self.selectedTrack)].locked) { [self showError:label detail:"The track is locked."]; return; }
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    [self runEdit:label rebuild:YES block:^{
        ClipEditor editor(self->_core->project(), track);
        op(editor);
    }];
}

- (void)splitAtPlayhead:(id)sender {
    (void)sender;
    const auto at = self.playheadSample;
    const std::uint64_t id = self.selectedClipId;
    if (id) { [self clipEdit:@"Split" op:^(ClipEditor& e) { self.selectedClipId = e.splitClip(id, at, ClipSnapSettings {}); }]; return; }
    if (self.selectedMidiTrack >= 0 && self.selectedPartId) {
        const auto t = static_cast<std::size_t>(self.selectedMidiTrack);
        const double q = _core->project().tempoMap.quarterNotesAtSample(at);
        const std::uint64_t part = self.selectedPartId;
        [self runEdit:@"Split Part" rebuild:NO block:^{ MidiPartEditor ed(self->_core->project().midiTracks[t].parts); self.selectedPartId = ed.split(part, q); }];
        [self republishMidi];
    }
}
- (void)deleteSelection:(id)sender {
    (void)sender;
    if (self.selectedClipId) {
        const std::uint64_t id = self.selectedClipId;
        [self clipEdit:@"Delete Clip" op:^(ClipEditor& e) { e.removeClip(id); }];
        self.selectedClipId = 0;
    } else if (self.selectedMidiTrack >= 0 && self.selectedPartId) {
        const auto t = static_cast<std::size_t>(self.selectedMidiTrack);
        const std::uint64_t part = self.selectedPartId;
        [self runEdit:@"Delete Part" rebuild:NO block:^{ MidiPartEditor ed(self->_core->project().midiTracks[t].parts); (void)ed.remove(part); }];
        self.selectedPartId = 0;
        [self republishMidi];
    }
    [self refreshAll];
}
- (void)copyClip:(id)sender {
    (void)sender;
    if (ProjectAudioClip* c = [self editedClip]) { _clipboard = *c; _clipboard.id = 0; _clipboardValid = YES; [self setStatus:@"Clip copied"]; }
}
- (void)cutClip:(id)sender { (void)sender; if ([self editedClip]) { [self copyClip:nil]; [self deleteSelection:nil]; } }
- (void)pasteClip:(id)sender {
    (void)sender;
    if (!_clipboardValid) return;
    const ProjectAudioClip clip = _clipboard;
    const std::int64_t at = self.playheadSample;
    [self runEdit:@"Paste Clip" rebuild:YES block:^{
        Project& p = self->_core->project();
        if (self.selectedTrack < 0 || self.selectedTrack >= static_cast<long>(p.tracks.size())) {
            ProjectTrack t;
            t.name = sv::str([[sv::ns(clip.audioPath) lastPathComponent] stringByDeletingPathExtension]);
            p.addTrack(std::move(t));
            self.selectedTrack = static_cast<long>(p.tracks.size()) - 1;
        }
        ClipEditor e(p, static_cast<std::size_t>(self.selectedTrack));
        ProjectAudioClip c = clip;
        c.timelineStartSample = at;
        self.selectedClipId = e.addClip(std::move(c), [self clipSnap]);
    }];
}
- (void)duplicateClip:(id)sender {
    (void)sender;
    ProjectAudioClip* c = [self editedClip];
    if (!c) return;
    const std::int64_t dest = c->timelineStartSample + static_cast<std::int64_t>(c->lengthSamples);
    const std::uint64_t id = c->id;
    [self clipEdit:@"Duplicate Clip" op:^(ClipEditor& e) { self.selectedClipId = e.duplicateClip(id, dest, [self clipSnap]); }];
}
- (void)toggleClipMute:(id)sender {
    (void)sender;
    ProjectAudioClip* c = [self editedClip];
    if (!c) return;
    const bool m = !c->mute;
    const std::uint64_t id = c->id;
    [self clipEdit:@"Mute Clip" op:^(ClipEditor& e) { e.setMute(id, m); }];
}
- (void)clipFades:(id)sender {
    (void)sender;
    ProjectAudioClip* c = [self editedClip];
    if (!c) return;
    const double sr = _core->project().sampleRate;
    NSString* s = [self promptText:@"Clip Fades" message:@"fade in ms, fade out ms"
                           initial:[NSString stringWithFormat:@"%.0f, %.0f", c->fadeInSamples * 1000.0 / sr, c->fadeOutSamples * 1000.0 / sr]];
    if (!s) return;
    NSArray<NSString*>* parts = [s componentsSeparatedByString:@","];
    if (parts.count != 2) return;
    const auto fi = static_cast<std::uint64_t>(std::max(0.0, parts[0].doubleValue) * sr / 1000.0);
    const auto fo = static_cast<std::uint64_t>(std::max(0.0, parts[1].doubleValue) * sr / 1000.0);
    const std::uint64_t id = c->id, len = c->lengthSamples;
    [self clipEdit:@"Clip Fades" op:^(ClipEditor& e) { e.setFades(id, std::min(fi, len), std::min(fo, len)); }];
}
- (void)clipGain:(id)sender {
    (void)sender;
    ProjectAudioClip* c = [self editedClip];
    if (!c) return;
    NSString* s = [self promptText:@"Clip Gain" message:@"dB (-60 … +12)" initial:[NSString stringWithFormat:@"%.1f", c->gainDb]];
    if (!s) return;
    const float g = static_cast<float>(std::clamp(s.doubleValue, -60.0, 12.0));
    const std::uint64_t id = c->id;
    [self clipEdit:@"Clip Gain" op:^(ClipEditor& e) { e.setGainDb(id, g); }];
}

// ============================================================== MIDI parts ==
- (void)dragPart:(std::uint64_t)partId midiTrack:(std::size_t)track toQuarter:(double)quarter {
    Project& p = _core->project();
    if (track >= p.midiTracks.size()) return;
    MidiPartEditor ed(p.midiTracks[track].parts);
    if (ed.move(partId, quarter)) { _core->session().markDirty(); [self republishMidi]; }
}

- (void)createPartForMidiTrack:(std::size_t)track atSample:(std::int64_t)sample {
    const auto pos = _core->project().tempoMap.positionAtSample(sample);
    const double barLen = pos.numerator * 4.0 / pos.denominator;
    [self runEdit:@"Create MIDI Part" rebuild:NO block:^{
        auto& mt = self->_core->project().midiTracks.at(track);
        self.selectedPartId = MidiTrackTools::addEmptyPart(mt, pos.barStartQuarterNotes, barLen);
        self.selectedMidiTrack = static_cast<long>(track);
    }];
    [self republishMidi];
    [self openEditor:nil];
}

- (void)duplicatePart:(id)sender {
    (void)sender;
    if (self.selectedMidiTrack < 0 || !self.selectedPartId) return;
    const auto t = static_cast<std::size_t>(self.selectedMidiTrack);
    const std::uint64_t part = self.selectedPartId;
    [self runEdit:@"Duplicate Part" rebuild:NO block:^{
        auto& parts = self->_core->project().midiTracks[t].parts;
        for (const auto& pr : parts) if (pr.id == part) {
            MidiPartEditor ed(parts);
            self.selectedPartId = ed.duplicate(part, pr.timelineStartQuarterNotes + pr.lengthQuarterNotes);
            break;
        }
    }];
    [self republishMidi];
}

- (void)openEditor:(id)sender {
    (void)sender;
    [self showPage:SVPage::Edit];
}

- (MidiPart*)editedPart {
    if (!_core || self.selectedMidiTrack < 0 || self.selectedMidiTrack >= static_cast<long>(_core->project().midiTracks.size())) return nullptr;
    return MidiTrackTools::findPart(_core->project().midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)], self.selectedPartId);
}
- (MidiSequence*)editedSequence {
    if (!_core || self.selectedMidiTrack < 0 || self.selectedMidiTrack >= static_cast<long>(_core->project().midiTracks.size())) return nullptr;
    auto& mt = _core->project().midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)];
    if (MidiPart* p = [self editedPart]) return &p->sequence;
    if (mt.parts.empty()) return &mt.sequence;
    return nullptr;
}
- (double)editedPartOffsetQuarterNotes {
    if (MidiPart* p = [self editedPart]) return p->timelineStartQuarterNotes - p->sourceOffsetQuarterNotes;
    return 0.0;
}

- (void)noteEdit:(NSString*)label op:(void (^)(MidiSequence& seq))op {
    MidiSequence* seq = [self editedSequence];
    if (!seq) return;
    MidiSequence* target = seq;
    [self runEdit:label rebuild:NO block:^{ op(*target); }];
    [self republishMidi];
    [_noteGrid setNeedsDisplay:YES];
}

- (void)noteGridAddNoteAt:(double)quarter pitch:(int)pitch {
    const double len = 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
    [self noteEdit:@"Add Note" op:^(MidiSequence& seq) {
        MusicalMidiNote n;
        n.startQuarterNotes = std::max(0.0, quarter);
        n.durationQuarterNotes = len;
        n.pitch = static_cast<std::uint8_t>(std::clamp(pitch, 0, 127));
        n.velocity = 100;
        self->_noteGrid.selectedNote = seq.addNote(n);
    }];
}
- (void)noteGridMoveNote:(std::uint64_t)noteId toQuarter:(double)quarter pitch:(int)pitch {
    [self noteEdit:@"Move Note" op:^(MidiSequence& seq) {
        (void)seq.moveNote(noteId, std::max(0.0, quarter));
        (void)seq.setNotePitch(noteId, static_cast<std::uint8_t>(std::clamp(pitch, 0, 127)));
    }];
}
- (void)noteGridResizeNote:(std::uint64_t)noteId length:(double)quarters {
    [self noteEdit:@"Resize Note" op:^(MidiSequence& seq) { (void)seq.resizeNote(noteId, std::max(1.0 / 64.0, quarters)); }];
}
- (void)noteGridDeleteNote:(std::uint64_t)noteId {
    [self noteEdit:@"Delete Note" op:^(MidiSequence& seq) { (void)seq.removeNote(noteId); }];
}
- (void)noteGridSetVelocity:(std::uint64_t)noteId velocity:(int)velocity {
    [self noteEdit:@"Velocity" op:^(MidiSequence& seq) { (void)seq.setNoteVelocity(noteId, static_cast<std::uint8_t>(std::clamp(velocity, 1, 127))); }];
}

- (MidiFunctions::Selection)noteSelection {
    if (_noteGrid.selectedNote) return {_noteGrid.selectedNote};
    return {};
}
- (void)midiQuantize:(id)sender {
    (void)sender;
    const QuantizeSettings q = SVQuantizeState.shared->settings;
    const auto sel = [self noteSelection];
    [self noteEdit:@"Quantize" op:^(MidiSequence& s) { (void)Quantizer::apply(s, q, sel); }];
}
- (void)midiQuantizeSetup:(id)sender { [self showQuantizePanel:sender]; }
- (void)midiQuantizeLength:(id)sender {
    (void)sender;
    QuantizeSettings q = SVQuantizeState.shared->settings;
    q.quantizeStart = false; q.quantizeEnd = false; q.quantizeLength = true;
    const auto sel = [self noteSelection];
    [self noteEdit:@"Quantize Length" op:^(MidiSequence& s) { (void)Quantizer::apply(s, q, sel); }];
}
- (void)midiGrooveApply:(id)sender {
    (void)sender;
    SVQuantizeState* st = SVQuantizeState.shared;
    if (st->groove.offsetQuarterNotes.empty()) { [self showError:@"Groove Quantize" detail:"Pick a groove in the Quantize Panel (or extract one from a part) first."]; return; }
    const GrooveTemplate g = st->groove;
    const double timing = st->grooveTiming, velocity = st->grooveVelocity;
    const auto sel = [self noteSelection];
    [self noteEdit:@"Groove Quantize" op:^(MidiSequence& s) { (void)Quantizer::applyGroove(s, g, timing, velocity, sel); }];
}
- (void)midiGrooveExtract:(id)sender {
    (void)sender;
    MidiSequence* seq = [self editedSequence];
    if (!seq || seq->notes().empty()) { [self showError:@"Extract Groove" detail:"Open a MIDI part that contains notes first."]; return; }
    SVQuantizeState* st = SVQuantizeState.shared;
    const double grid = Quantizer::effectiveGrid(st->settings);
    st->groove = Quantizer::extractGroove(*seq, grid, std::max(4.0, grid), [self noteSelection]);
    st->groove.name = "Extracted groove";
    [self setStatus:@"Groove extracted from the part"];
}
- (void)audioQuantize:(id)sender {
    (void)sender;
    ProjectAudioClip* c = [self editedClip];
    if (!c) { [self showError:@"Audio Quantize" detail:"Select an audio clip first."]; return; }
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    if (_core->project().tracks[track].locked) { [self showError:@"Audio Quantize" detail:"The track is locked."]; return; }
    const std::uint64_t id = c->id;
    SVQuantizeState* st = SVQuantizeState.shared;
    const QuantizeSettings q = st->settings;
    const AudioQuantizeOptions o = st->audio;
    __block std::size_t slices = 0U;
    [self runEdit:@"Audio Quantize" rebuild:YES block:^{ slices = AudioQuantizer::quantizeClip(self->_core->project(), track, id, q, o); }];
    [self setStatus:slices ? [NSString stringWithFormat:@"Audio quantized: %zu slices moved to the grid", slices] : @"No transients found in the clip"];
}
- (void)midiQuantizeSoft:(id)sender {
    (void)sender;
    const double grid = 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
    const double swing = _swingSlider ? _swingSlider.doubleValue / 100.0 : 0.0;
    [self noteEdit:@"Iterative Quantize" op:^(MidiSequence& s) { (void)MidiFunctions::quantize(s, grid, swing, 0.5, false); }];
}
- (void)midiQuantizeEnds:(id)sender {
    (void)sender;
    const double grid = 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
    [self noteEdit:@"Quantize Ends" op:^(MidiSequence& s) { (void)MidiFunctions::quantize(s, grid, 0.0, 1.0, true); }];
}
- (void)midiLegato:(id)sender { (void)sender; [self noteEdit:@"Legato" op:^(MidiSequence& s) { (void)MidiFunctions::legato(s); }]; }
- (void)midiFixedLength:(id)sender {
    (void)sender;
    const double len = 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
    const auto sel = [self noteSelection];
    [self noteEdit:@"Fixed Length" op:^(MidiSequence& s) { (void)MidiFunctions::fixedLength(s, len, sel); }];
}
- (void)midiVelocity:(id)sender {
    (void)sender;
    NSString* v = [self promptText:@"Velocity" message:@"scale × and offset ±, e.g. 1.0, +10  (or a single fixed value like 96)" initial:@"1.0, 0"];
    if (!v) return;
    const auto sel = [self noteSelection];
    NSArray<NSString*>* parts = [v componentsSeparatedByString:@","];
    if (parts.count == 1) {
        const int fixed = std::clamp(v.intValue, 1, 127);
        [self noteEdit:@"Fixed Velocity" op:^(MidiSequence& s) { (void)MidiFunctions::fixedVelocity(s, static_cast<std::uint8_t>(fixed), sel); }];
    } else {
        const double scale = parts[0].doubleValue;
        const int offset = parts[1].intValue;
        [self noteEdit:@"Scale Velocity" op:^(MidiSequence& s) { (void)MidiFunctions::scaleVelocity(s, scale, offset, sel); }];
    }
}
- (void)midiCompress:(id)sender { (void)sender; [self noteEdit:@"Compress Velocity" op:^(MidiSequence& s) { (void)MidiFunctions::compressVelocity(s, 0.5); }]; }
- (void)midiHumanize:(id)sender {
    (void)sender;
    const auto seed = static_cast<std::uint32_t>(_tick * 2654435761U);
    [self noteEdit:@"Humanize" op:^(MidiSequence& s) { (void)MidiFunctions::humanize(s, 0.015, 8, seed); }];
}
- (void)midiDeleteDoubles:(id)sender { (void)sender; [self noteEdit:@"Delete Doubles" op:^(MidiSequence& s) { (void)MidiFunctions::deleteDoubles(s); (void)MidiFunctions::deleteOverlaps(s); }]; }
- (void)midiTranspose:(int)semis {
    const auto sel = [self noteSelection];
    [self noteEdit:@"Transpose" op:^(MidiSequence& s) {
        for (const auto& n : std::vector<MusicalMidiNote>(s.notes()))
            if (sel.empty() || std::find(sel.begin(), sel.end(), n.id) != sel.end())
                (void)s.setNotePitch(n.id, static_cast<std::uint8_t>(std::clamp(static_cast<int>(n.pitch) + semis, 0, 127)));
    }];
}
- (void)midiUp:(id)sender { (void)sender; [self midiTranspose:1]; }
- (void)midiDown:(id)sender { (void)sender; [self midiTranspose:-1]; }
- (void)midiOctaveUp:(id)sender { (void)sender; [self midiTranspose:12]; }
- (void)midiOctaveDown:(id)sender { (void)sender; [self midiTranspose:-12]; }
- (void)midiRetrograde:(id)sender {
    (void)sender;
    MidiPart* part = [self editedPart];
    const double a = part ? part->sourceOffsetQuarterNotes : 0.0;
    double b = part ? a + part->lengthQuarterNotes : 0.0;
    if (!part) if (MidiSequence* s = [self editedSequence]) for (const auto& n : s->notes()) b = std::max(b, n.startQuarterNotes + n.durationQuarterNotes);
    if (b <= a) return;
    [self noteEdit:@"Retrograde" op:^(MidiSequence& s) { (void)MidiFunctions::reverse(s, a, b); }];
}
- (void)midiInvert:(id)sender { (void)sender; [self noteEdit:@"Invert" op:^(MidiSequence& s) { (void)MidiFunctions::invert(s, 66); }]; }

// ========================================================= audio process ==
- (void)runProcess:(AudioProcess)process options:(AudioProcessOptions)options {
    ProjectAudioClip* c = [self editedClip];
    if (!c) { [self showError:@"Audio Process" detail:"Select an audio clip first."]; return; }
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    const std::uint64_t id = c->id;
    std::string dir;
    try { dir = sv::processedMediaDirectory(); } catch (const std::exception& e) { [self showError:@"Audio Process" detail:e.what()]; return; }
    __block std::string newPath;
    [self runEdit:sv::ns(AudioProcessor::name(process)) rebuild:YES block:^{
        newPath = AudioProcessor::processClip(self->_core->project(), track, id, process, options, dir).newPath;
    }];
    if (!newPath.empty()) { _core->waveformCache().request(newPath); [self setStatus:[NSString stringWithFormat:@"%s applied", AudioProcessor::name(process)]]; }
}
- (void)processNormalize:(id)sender { (void)sender; AudioProcessOptions o; o.normalizeTargetDb = -0.3; [self runProcess:AudioProcess::Normalize options:o]; }
- (void)processGain:(id)sender {
    (void)sender;
    NSString* s = [self promptText:@"Gain" message:@"dB" initial:@"-3"];
    if (!s) return;
    AudioProcessOptions o; o.gainDb = std::clamp(s.doubleValue, -60.0, 24.0);
    [self runProcess:AudioProcess::Gain options:o];
}
- (void)processReverse:(id)sender { (void)sender; [self runProcess:AudioProcess::Reverse options:AudioProcessOptions {}]; }
- (void)processInvert:(id)sender { (void)sender; [self runProcess:AudioProcess::InvertPhase options:AudioProcessOptions {}]; }
- (void)processDc:(id)sender { (void)sender; [self runProcess:AudioProcess::RemoveDc options:AudioProcessOptions {}]; }
- (void)processFadeIn:(id)sender { (void)sender; [self runProcess:AudioProcess::FadeIn options:AudioProcessOptions {}]; }
- (void)processFadeOut:(id)sender { (void)sender; [self runProcess:AudioProcess::FadeOut options:AudioProcessOptions {}]; }
- (void)processSilence:(id)sender { (void)sender; [self runProcess:AudioProcess::Silence options:AudioProcessOptions {}]; }
- (void)processMono:(id)sender { (void)sender; [self runProcess:AudioProcess::MonoSum options:AudioProcessOptions {}]; }
- (void)processFlip:(id)sender { (void)sender; [self runProcess:AudioProcess::StereoFlip options:AudioProcessOptions {}]; }
- (void)processStretch:(id)sender {
    (void)sender;
    NSString* s = [self promptText:@"Time Stretch" message:@"new length ÷ old length (0.25 … 4)" initial:@"1.0"];
    if (!s) return;
    AudioProcessOptions o; o.stretchRatio = s.doubleValue;
    [self runProcess:AudioProcess::TimeStretch options:o];
}
- (void)processPitch:(id)sender {
    (void)sender;
    NSString* s = [self promptText:@"Pitch Shift" message:@"semitones (±24). Add 'f' to preserve formants, e.g. 3f" initial:@"0"];
    if (!s) return;
    AudioProcessOptions o; o.semitones = s.doubleValue; o.preserveFormants = [s hasSuffix:@"f"];
    [self runProcess:AudioProcess::PitchShift options:o];
}

- (void)renderInPlace:(id)sender {
    (void)sender;
    if (self.selectedTrack < 0) { [self showError:@"Render in Place" detail:"Select an audio or instrument track."]; return; }
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    OfflineBounceOptions range = [self bounceOptions];
    try {
        const std::string dir = sv::processedMediaDirectory();
        [SilvetonNativeEditor closeAll];
        _core->session().beginEdit("Render in Place");
        {
            sv::AppRuntime::OfflineScope scope(*_core);
            const auto r = AudioProcessor::renderInPlace(_core->project(), _core->engine(), &_core->runtime().rack(), track,
                                                         range.startSample, range.endSample, dir, true);
            _core->waveformCache().request(r.path);
            self.selectedTrack = static_cast<long>(r.newTrackIndex);
        }
        _core->session().commitEdit();
        [self requestRebuild];
    } catch (const std::exception& e) {
        if (_core->session().history().transactionOpen()) _core->session().cancelEdit();
        [self showError:@"Render in Place" detail:e.what()];
    }
    [self refreshAll];
}

// ============================================================ console API ==
- (void)setStrip:(SVStrip)strip gainDb:(double)db {
    Project& p = _core->project();
    const float v = static_cast<float>(std::clamp(db, -96.0, 12.0));
    const std::int64_t at = self.playheadSample;
    if (strip.kind == SVStripKind::Track && strip.index < p.tracks.size()) {
        auto& t = p.tracks[strip.index];
        t.gainDb = v;
        if (t.gainAutomationMode != AutomationMode::Read && t.gainAutomationMode != AutomationMode::Off) {
            _gainWriter.setMode(t.gainAutomationMode);
            _gainWriter.apply(AutomationGestureType::Value, at, v, t.gainAutomationDb);
        }
        [self applyMixerLive];
    } else if (strip.kind == SVStripKind::Bus && strip.index < p.buses.size()) {
        p.buses[strip.index].gainDb = v;
        if (_gestureOpen) _gestureNeedsRebuild = YES; else [self requestRebuild];
    } else if (strip.kind == SVStripKind::Master) {
        p.masterFaderDb = v;
        if (_core->ready()) _core->engine().setMasterFaderDb(v);
    }
    _core->session().markDirty();
    [_console setNeedsDisplay:YES];
}

- (void)setStrip:(SVStrip)strip pan:(double)pan {
    Project& p = _core->project();
    if (strip.kind != SVStripKind::Track || strip.index >= p.tracks.size()) return;
    auto& t = p.tracks[strip.index];
    t.pan = static_cast<float>(std::clamp(pan, -1.0, 1.0));
    if (t.panAutomationMode != AutomationMode::Read && t.panAutomationMode != AutomationMode::Off) {
        _panWriter.setMode(t.panAutomationMode);
        _panWriter.apply(AutomationGestureType::Value, self.playheadSample, t.pan, t.panAutomation);
    }
    [self applyMixerLive];
    _core->session().markDirty();
}

- (void)toggleStripMute:(SVStrip)strip {
    Project& p = _core->project();
    if (strip.kind == SVStripKind::Track) { ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = strip.index; [self toggleMute:r]; return; }
    if (strip.kind == SVStripKind::Bus && strip.index < p.buses.size()) {
        [self runEdit:@"Mute Bus" rebuild:YES block:^{ auto& b = self->_core->project().buses[strip.index]; b.mute = !b.mute; }];
    }
}
- (void)toggleStripSolo:(SVStrip)strip {
    Project& p = _core->project();
    if (strip.kind == SVStripKind::Track) { ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = strip.index; [self toggleSolo:r]; return; }
    if (strip.kind == SVStripKind::Bus && strip.index < p.buses.size()) {
        p.buses[strip.index].solo = !p.buses[strip.index].solo;
        _core->session().markDirty();
        [self applySolo];
        [self refreshAll];
    }
}

- (void)stripInsertClicked:(SVStrip)strip slot:(std::size_t)slot { [self openInsertEditor:strip slot:slot]; }

// Reads the engine once per UI tick and runs the meter ballistics for every
// track and the master. All views draw from this one bank, so they always agree.
- (void)updateMeters {
    const double now = [NSProcessInfo processInfo].systemUptime;
    const double dt = _meterClock > 0.0 ? now - _meterClock : 0.0;
    _meterClock = now;
    if (!_core || !_core->ready()) { _meters.feedMaster(0.0F, 0.0F, dt); return; }
    auto& engine = _core->engine();
    const std::size_t n = engine.trackCount();
    _meters.setTrackCount(n);
    for (std::size_t i = 0U; i < n; ++i) {
        const auto m = engine.takeTrackPeaks(i);   // highest peak since the previous tick
        _meters.feedTrack(i, m.leftPeak, m.rightPeak, dt);
    }
    const auto out = engine.takeOutputPeaks();
    _meters.feedMaster(out.leftPeak, out.rightPeak, dt);
}

- (StereoMeterDisplay)meterDisplayForStrip:(SVStrip)strip {
    if (strip.kind == SVStripKind::Track) return _meters.track(strip.index);
    if (strip.kind == SVStripKind::Master) return _meters.master();
    return {};   // bus meters are not measured by the engine yet
}

- (StereoMeterDisplay)masterMeterDisplay { return _meters.master(); }

// A cheap fingerprint of the track-header meters (segment-snapped), so the
// arrange view repaints that column only when a level visibly moved.
- (std::uint32_t)meterSignature {
    std::uint32_t h = 2166136261U;
    const std::size_t n = _meters.trackCount();
    for (std::size_t i = 0U; i < n; ++i) h = (h ^ sv::meter::signature(_meters.track(i), 40.0, false)) * 16777619U;
    return h;
}

- (void)resetMetersForStrip:(SVStrip)strip all:(BOOL)all {
    if (all) _meters.resetPeaks();
    else if (strip.kind == SVStripKind::Track) _meters.resetTrackPeaks(strip.index);
    else if (strip.kind == SVStripKind::Master) _meters.resetMasterPeaks();
    [_console setNeedsDisplay:YES];
    [_transport setNeedsDisplay:YES];
}

- (NSMenu*)insertMenuForStrip:(SVStrip)strip {
    _menuStrip = strip;
    NSMenu* menu = [[NSMenu alloc] initWithTitle:@"Insert"];
    NSMenuItem* nativeHeader = [menu addItemWithTitle:@"SILVETON NATIVE" action:nil keyEquivalent:@""];
    nativeHeader.enabled = NO;
    for (const auto& info : nativePluginCatalog()) {
        if (info.instrument && strip.kind != SVStripKind::Track) continue;
        NSMenuItem* it = [menu addItemWithTitle:[NSString stringWithFormat:@"%@   ·  %@", sv::ns(info.name), sv::ns(info.category)] action:@selector(insertFromMenu:) keyEquivalent:@""];
        it.target = self;
        it.representedObject = @{@"native": @YES, @"module": sv::ns(kNativeModulePath), @"class": sv::ns(info.classId), @"name": sv::ns(info.name), @"instrument": @(info.instrument)};
    }
    if (_browser && !_browser->catalog().entries().empty()) {
        [menu addItem:[NSMenuItem separatorItem]];
        NSMenuItem* vst = [menu addItemWithTitle:@"VST3" action:nil keyEquivalent:@""];
        NSMenu* sub = [[NSMenu alloc] initWithTitle:@"VST3"];
        for (const auto& e : _browser->catalog().entries()) {
            bool inst = false;
            for (const auto& c : e.subCategories) if (c.find("Instrument") != std::string::npos || c.find("Synth") != std::string::npos) inst = true;
            if (inst && strip.kind != SVStripKind::Track) continue;
            NSMenuItem* it = [sub addItemWithTitle:[NSString stringWithFormat:@"%@ — %@", sv::ns(e.name), sv::ns(e.vendor)] action:@selector(insertFromMenu:) keyEquivalent:@""];
            it.target = self;
            it.representedObject = @{@"native": @NO, @"module": sv::ns(e.modulePath), @"class": sv::ns(e.classId), @"name": sv::ns(e.name), @"instrument": @(inst)};
        }
        vst.submenu = sub;
    }
    return menu;
}

- (void)insertFromMenu:(NSMenuItem*)item {
    NSDictionary* d = item.representedObject;
    SVPluginEntry e;
    e.native = [d[@"native"] boolValue];
    e.instrument = [d[@"instrument"] boolValue];
    e.modulePath = sv::str(d[@"module"]);
    e.classId = sv::str(d[@"class"]);
    e.name = sv::str(d[@"name"]);
    [self insertPluginEntry:e intoStrip:_menuStrip];
}

- (void)toggleBypassFromMenu:(NSMenuItem*)item {
    const auto slot = static_cast<std::size_t>(item.tag);
    const SVStrip strip = _menuStrip;
    [self runEdit:@"Bypass Insert" rebuild:YES block:^{
        auto* slots = [self slotsForStrip:strip];
        if (slots && slot < slots->size()) (*slots)[slot].enabled = !(*slots)[slot].enabled;
    }];
}
- (void)removeInsertFromMenu:(NSMenuItem*)item {
    const auto slot = static_cast<std::size_t>(item.tag);
    const SVStrip strip = _menuStrip;
    [SilvetonNativeEditor closeAll];
    [self runEdit:@"Remove Insert" rebuild:YES block:^{
        auto* slots = [self slotsForStrip:strip];
        if (slots && slot < slots->size()) slots->erase(slots->begin() + static_cast<std::ptrdiff_t>(slot));
    }];
}
- (void)openInsertFromMenu:(NSMenuItem*)item { [self openInsertEditor:_menuStrip slot:static_cast<std::size_t>(item.tag)]; }

- (void)addSendFromMenu:(NSMenuItem*)item {
    const int bus = static_cast<int>(item.tag);
    const SVStrip strip = _menuStrip;
    [self runEdit:@"Add Send" rebuild:YES block:^{
        Project& p = self->_core->project();
        ProjectSend s; s.destinationBus = bus; s.gainDb = -10.0F;
        if (strip.kind == SVStripKind::Track) p.tracks.at(strip.index).sends.push_back(s);
        else if (strip.kind == SVStripKind::Bus) { if (static_cast<std::size_t>(bus) == strip.index) throw std::runtime_error("a bus cannot send to itself"); p.buses.at(strip.index).sends.push_back(s); }
    }];
}
- (void)routeFromMenu:(NSMenuItem*)item {
    const int bus = static_cast<int>(item.tag);
    const SVStrip strip = _menuStrip;
    [self runEdit:@"Output Routing" rebuild:YES block:^{
        Project& p = self->_core->project();
        if (strip.kind == SVStripKind::Track) p.tracks.at(strip.index).outputBus = bus;
        else if (strip.kind == SVStripKind::Bus) { if (bus == static_cast<int>(strip.index)) throw std::runtime_error("a bus cannot feed itself"); p.buses.at(strip.index).outputBus = bus; }
    }];
}
- (void)deleteBusFromMenu:(id)sender {
    (void)sender;
    const SVStrip strip = _menuStrip;
    if (strip.kind != SVStripKind::Bus) return;
    [SilvetonNativeEditor closeAll];
    [self runEdit:@"Delete Bus" rebuild:YES block:^{ TrackTools::removeBus(self->_core->project(), strip.index); }];
}
- (void)renameStripFromMenu:(id)sender {
    (void)sender;
    const SVStrip strip = _menuStrip;
    if (strip.kind == SVStripKind::Master) return;
    NSString* n = [self promptText:@"Rename" message:@"" initial:[self stripName:strip]];
    if (!n.length) return;
    [self runEdit:@"Rename" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (strip.kind == SVStripKind::Track) p.tracks.at(strip.index).name = sv::str(n);
        else p.buses.at(strip.index).name = sv::str(n);
    }];
}

- (NSMenu*)contextMenuForStrip:(SVStrip)strip {
    _menuStrip = strip;
    Project& p = _core->project();
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Channel"];
    auto add = [&](NSMenu* menu, NSString* title, SEL action, NSInteger tag) {
        NSMenuItem* it = [menu addItemWithTitle:title action:action keyEquivalent:@""];
        it.target = self; it.tag = tag;
        return it;
    };
    NSMenuItem* ins = [m addItemWithTitle:@"Add Insert" action:nil keyEquivalent:@""];
    ins.submenu = [self insertMenuForStrip:strip];
    auto* slots = [self slotsForStrip:strip];
    if (slots && !slots->empty()) {
        NSMenuItem* manage = [m addItemWithTitle:@"Inserts" action:nil keyEquivalent:@""];
        NSMenu* sub = [[NSMenu alloc] initWithTitle:@"Inserts"];
        for (std::size_t i = 0; i < slots->size(); ++i) {
            const auto& s = (*slots)[i];
            NSString* name = isNativeModulePath(s.modulePath) ? sv::ns(s.classId) : [sv::ns(s.modulePath) lastPathComponent];
            add(sub, [NSString stringWithFormat:@"Open %@", name], @selector(openInsertFromMenu:), static_cast<NSInteger>(i));
            add(sub, [NSString stringWithFormat:@"%@ %@", s.enabled ? @"Bypass" : @"Enable", name], @selector(toggleBypassFromMenu:), static_cast<NSInteger>(i));
            add(sub, [NSString stringWithFormat:@"Remove %@", name], @selector(removeInsertFromMenu:), static_cast<NSInteger>(i));
            [sub addItem:[NSMenuItem separatorItem]];
        }
        manage.submenu = sub;
    }
    if (strip.kind != SVStripKind::Master) {
        if (!p.buses.empty()) {
            NSMenuItem* send = [m addItemWithTitle:@"Add Send" action:nil keyEquivalent:@""];
            NSMenu* sub = [[NSMenu alloc] initWithTitle:@"Send"];
            for (std::size_t b = 0; b < p.buses.size(); ++b) add(sub, sv::ns(p.buses[b].name), @selector(addSendFromMenu:), static_cast<NSInteger>(b));
            send.submenu = sub;
        }
        NSMenuItem* route = [m addItemWithTitle:@"Output" action:nil keyEquivalent:@""];
        NSMenu* sub = [[NSMenu alloc] initWithTitle:@"Output"];
        add(sub, @"Stereo Out", @selector(routeFromMenu:), -1);
        for (std::size_t b = 0; b < p.buses.size(); ++b)
            if (!(strip.kind == SVStripKind::Bus && strip.index == b)) add(sub, sv::ns(p.buses[b].name), @selector(routeFromMenu:), static_cast<NSInteger>(b));
        route.submenu = sub;
        [m addItem:[NSMenuItem separatorItem]];
        add(m, @"Rename…", @selector(renameStripFromMenu:), 0);
    }
    if (strip.kind == SVStripKind::Bus) add(m, @"Delete Bus", @selector(deleteBusFromMenu:), 0);
    [m addItem:[NSMenuItem separatorItem]];
    add(m, @"Add Group Bus", @selector(addGroupBus:), 0);
    add(m, @"Add FX Channel", @selector(addFxBus:), 0);
    return m;
}

// ============================================================= arrange UI ==
- (NSMenu*)contextMenuForRow:(ArrangeRow)row clip:(std::uint64_t)clipId part:(std::uint64_t)partId atSample:(std::int64_t)sample {
    _menuRow = row;
    _menuSample = sample;
    Project& p = _core->project();
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Arrange"];
    auto add = [&](NSMenu* menu, NSString* title, SEL action, NSInteger tag) {
        NSMenuItem* it = [menu addItemWithTitle:title action:action keyEquivalent:@""];
        it.target = self; it.tag = tag;
        return it;
    };
    const bool audio = row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size();
    const bool midi = row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size();
    const bool folder = row.kind == ArrangeRowKind::Folder && row.index < p.folders.size();
    if (audio && clipId) {
        add(m, @"Open in Sample Editor", @selector(openEditor:), 0);
        add(m, @"Cut", @selector(cutClip:), 0);
        add(m, @"Copy", @selector(copyClip:), 0);
        add(m, @"Duplicate", @selector(duplicateClip:), 0);
        add(m, @"Split at Playhead", @selector(splitAtPlayhead:), 0);
        add(m, @"Mute / Unmute Clip", @selector(toggleClipMute:), 0);
        add(m, @"Clip Gain…", @selector(clipGain:), 0);
        add(m, @"Clip Fades…", @selector(clipFades:), 0);
        NSMenuItem* proc = [m addItemWithTitle:@"Process" action:nil keyEquivalent:@""];
        NSMenu* sub = [[NSMenu alloc] initWithTitle:@"Process"];
        add(sub, @"Normalize", @selector(processNormalize:), 0);
        add(sub, @"Gain…", @selector(processGain:), 0);
        add(sub, @"Fade In", @selector(processFadeIn:), 0);
        add(sub, @"Fade Out", @selector(processFadeOut:), 0);
        add(sub, @"Reverse", @selector(processReverse:), 0);
        add(sub, @"Invert Phase", @selector(processInvert:), 0);
        add(sub, @"Remove DC Offset", @selector(processDc:), 0);
        add(sub, @"Silence", @selector(processSilence:), 0);
        add(sub, @"Mono Sum", @selector(processMono:), 0);
        add(sub, @"Stereo Flip", @selector(processFlip:), 0);
        add(sub, @"Time Stretch…", @selector(processStretch:), 0);
        add(sub, @"Pitch Shift…", @selector(processPitch:), 0);
        proc.submenu = sub;
        [m addItem:[NSMenuItem separatorItem]];
        add(m, @"Delete Clip", @selector(deleteSelection:), 0);
        [m addItem:[NSMenuItem separatorItem]];
    }
    if (midi && partId) {
        add(m, @"Open in Note Editor", @selector(openEditor:), 0);
        add(m, @"Duplicate Part", @selector(duplicatePart:), 0);
        add(m, @"Split Part at Playhead", @selector(splitAtPlayhead:), 0);
        add(m, @"Delete Part", @selector(deleteSelection:), 0);
        [m addItem:[NSMenuItem separatorItem]];
    }
    if (audio || midi || folder) {
        add(m, @"Rename…", @selector(renameSelected:), 0);
        NSMenuItem* col = [m addItemWithTitle:@"Colour" action:nil keyEquivalent:@""];
        col.submenu = [self paletteMenuWithAction:@selector(setRowColour:)];
    }
    if (audio || midi) {
        NSMenuItem* fold = [m addItemWithTitle:@"Folder" action:nil keyEquivalent:@""];
        NSMenu* sub = [[NSMenu alloc] initWithTitle:@"Folder"];
        add(sub, @"(none)", @selector(moveToFolder:), -1);
        for (const auto& f : p.folders) add(sub, sv::ns(f.name), @selector(moveToFolder:), f.id);
        fold.submenu = sub;
    }
    if (midi) {
        NSMenuItem* out = [m addItemWithTitle:@"MIDI Output" action:nil keyEquivalent:@""];
        NSMenu* sub = [[NSMenu alloc] initWithTitle:@"Output"];
        add(sub, @"None", @selector(setMidiOutput:), -1);
        for (const auto& t : p.tracks)
            for (const auto& s : t.pluginSlots)
                if (s.midiInputPort >= 0) add(sub, [NSString stringWithFormat:@"%@ (port %d)", sv::ns(t.name), s.midiInputPort], @selector(setMidiOutput:), s.midiInputPort);
        out.submenu = sub;
        if (!partId) add(m, @"Create Part Here", @selector(createPartFromMenu:), 0);
    }
    if (audio) {
        add(m, @"Duplicate Track", @selector(duplicateTrack:), 0);
        add(m, p.tracks[row.index].locked ? @"Unlock Track" : @"Lock Track", @selector(toggleLock:), 0);
        add(m, @"Render in Place", @selector(renderInPlace:), 0);
        add(m, @"Move Up", @selector(moveTrackUp:), 0);
        add(m, @"Move Down", @selector(moveTrackDown:), 0);
    }
    if (audio || midi || folder) {
        [m addItem:[NSMenuItem separatorItem]];
        add(m, folder ? @"Delete Folder" : @"Delete Track", @selector(deleteTrack:), 0);
        [m addItem:[NSMenuItem separatorItem]];
    }
    if (_clipboardValid) add(m, @"Paste Clip at Playhead", @selector(pasteClip:), 0);
    add(m, @"Add Audio Track", @selector(addAudioTrack:), 0);
    add(m, @"Add Instrument Track", @selector(addInstrumentTrack:), 0);
    add(m, @"Add MIDI Track", @selector(addMidiTrack:), 0);
    add(m, @"Add Folder…", @selector(addFolder:), 0);
    add(m, @"Import Audio…", @selector(importAudio:), 0);
    add(m, @"Add Marker Here", @selector(addMarkerFromMenu:), 0);
    return m;
}
- (void)createPartFromMenu:(id)sender { (void)sender; if (_menuRow.kind == ArrangeRowKind::Midi) [self createPartForMidiTrack:_menuRow.index atSample:[self snapSample:_menuSample]]; }
- (void)addMarkerFromMenu:(id)sender { (void)sender; [self addMarkerAtSample:[self snapSample:_menuSample]]; }

// Markers
- (void)markerClicked:(std::uint64_t)markerId doubleClick:(BOOL)twice {
    const auto* m = MarkerTools::find(_core->project(), markerId);
    if (!m) return;
    if (m->cycle && twice) { [self setCycleStart:m->sample end:m->endSample]; return; }
    [self seekToSample:m->sample];
    if (twice) { _menuMarker = markerId; [self renameMarkerFromMenu:nil]; }
}
- (NSMenu*)contextMenuForMarker:(std::uint64_t)markerId {
    _menuMarker = markerId;
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Marker"];
    for (NSArray* spec in @[@[@"Go to Marker", NSStringFromSelector(@selector(gotoMarkerFromMenu:))],
                            @[@"Rename…", NSStringFromSelector(@selector(renameMarkerFromMenu:))],
                            @[@"Loop from Here to Next Marker", NSStringFromSelector(@selector(loopMarkerFromMenu:))],
                            @[@"Delete Marker", NSStringFromSelector(@selector(deleteMarkerFromMenu:))]]) {
        NSMenuItem* it = [m addItemWithTitle:spec[0] action:NSSelectorFromString(spec[1]) keyEquivalent:@""];
        it.target = self;
    }
    return m;
}
- (void)gotoMarkerFromMenu:(id)sender { (void)sender; if (const auto* m = MarkerTools::find(_core->project(), _menuMarker)) [self seekToSample:m->sample]; }
- (void)renameMarkerFromMenu:(id)sender {
    (void)sender;
    const auto* m = MarkerTools::find(_core->project(), _menuMarker);
    if (!m) return;
    NSString* n = [self promptText:@"Rename Marker" message:@"" initial:sv::ns(m->name)];
    if (!n) return;
    const std::uint64_t id = _menuMarker;
    [self runEdit:@"Rename Marker" rebuild:NO block:^{ (void)MarkerTools::rename(self->_core->project(), id, sv::str(n)); }];
}
- (void)loopMarkerFromMenu:(id)sender {
    (void)sender;
    const auto* m = MarkerTools::find(_core->project(), _menuMarker);
    if (!m) return;
    if (m->cycle) { [self setCycleStart:m->sample end:m->endSample]; return; }
    const auto* next = MarkerTools::next(_core->project(), m->sample);
    if (next) [self setCycleStart:m->sample end:next->sample];
}
- (void)deleteMarkerFromMenu:(id)sender {
    (void)sender;
    const std::uint64_t id = _menuMarker;
    [self runEdit:@"Delete Marker" rebuild:NO block:^{ (void)MarkerTools::remove(self->_core->project(), id); }];
}

// Arranger
- (void)sectionClicked:(std::uint64_t)sectionId doubleClick:(BOOL)twice {
    self.selectedSectionId = sectionId;
    const auto* s = ArrangerTools::find(_core->project(), sectionId);
    if (!s) return;
    if (twice) [self setCycleStart:s->startSample end:s->endSample];
    else [self seekToSample:s->startSample];
    [self refreshAll];
}
- (void)createSectionFrom:(std::int64_t)start to:(std::int64_t)end {
    [self runEdit:@"Add Arranger Section" rebuild:NO block:^{
        self.selectedSectionId = ArrangerTools::addSection(self->_core->project(), "", start, end);
    }];
}
- (NSMenu*)contextMenuForSection:(std::uint64_t)sectionId {
    _menuSection = sectionId;
    self.selectedSectionId = sectionId;
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Section"];
    for (NSArray* spec in @[@[@"Loop Section", NSStringFromSelector(@selector(loopSectionFromMenu:))],
                            @[@"Append to Chain", NSStringFromSelector(@selector(appendSectionFromMenu:))],
                            @[@"Rename…", NSStringFromSelector(@selector(renameSectionFromMenu:))],
                            @[@"Delete Section", NSStringFromSelector(@selector(deleteSectionFromMenu:))]]) {
        NSMenuItem* it = [m addItemWithTitle:spec[0] action:NSSelectorFromString(spec[1]) keyEquivalent:@""];
        it.target = self;
    }
    return m;
}
- (void)loopSectionFromMenu:(id)sender { (void)sender; if (const auto* s = ArrangerTools::find(_core->project(), _menuSection)) [self setCycleStart:s->startSample end:s->endSample]; }
- (void)appendSectionFromMenu:(id)sender {
    (void)sender;
    const std::uint64_t id = _menuSection;
    [self runEdit:@"Append to Chain" rebuild:NO block:^{ ArrangerTools::appendToChain(self->_core->project(), id, 1U); }];
}
- (void)renameSectionFromMenu:(id)sender {
    (void)sender;
    const auto* s = ArrangerTools::find(_core->project(), _menuSection);
    if (!s) return;
    NSString* n = [self promptText:@"Rename Section" message:@"" initial:sv::ns(s->name)];
    if (!n.length) return;
    const std::uint64_t id = _menuSection;
    [self runEdit:@"Rename Section" rebuild:NO block:^{
        for (auto& sec : self->_core->project().arrangerSections) if (sec.id == id) sec.name = sv::str(n);
    }];
}
- (void)deleteSectionFromMenu:(id)sender {
    (void)sender;
    const std::uint64_t id = _menuSection;
    [self runEdit:@"Delete Section" rebuild:NO block:^{ (void)ArrangerTools::removeSection(self->_core->project(), id); }];
}

// Plug-in scan
- (void)scanPlugins:(id)sender {
    (void)sender;
    if (_scannerBusy || !_browser) return;
    _scannerBusy = YES;
    [self setStatus:@"Scanning VST3 plug-ins…"];
    const std::vector<std::string> paths = _core->host().installedModulePaths();
    Vst3PluginBrowserService* browser = _browser.get();
    __weak SilvetonController* weakSelf = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        std::string message;
        try {
            const auto summary = browser->scanModules(paths, true);
            std::ostringstream ss;
            ss << "Scanned " << summary.scannedModules << " module(s): " << summary.discoveredClasses << " plug-in(s), " << summary.failedModules << " failed";
            message = ss.str();
        } catch (const std::exception& e) { message = e.what(); }
        dispatch_async(dispatch_get_main_queue(), ^{
            SilvetonController* s = weakSelf;
            if (!s) return;
            s->_scannerBusy = NO;
            [s setStatus:sv::ns(message)];
            [s reloadPluginResults];
        });
    });
}

@end
