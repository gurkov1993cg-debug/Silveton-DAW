// Silveton — document, track, clip, MIDI, audio-process and console actions.
#import "SilvetonControllerPrivate.h"
#include "SilvetonMeterDraw.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/ClipEditor.h"
#include "silveton/DiskStream.h"
#include "silveton/MidiPartEditor.h"
#include "silveton/TakeComp.h"
#include "silveton/OfflineBounce.h"
#include "silveton/ProjectMediaRelinker.h"
#include "silveton/StemBounce.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <map>
#include <limits>
#include <set>
#include <sstream>

using namespace silveton;

@implementation SilvetonController (Actions)

// ================================================================ helpers ==
- (ClipSnapSettings)clipSnap {
    ClipSnapSettings s;
    if (!_snap) { s.mode = ClipSnapMode::Off; return s; }
    s.mode = ClipSnapMode::Musical;
    s.divisionsPerQuarter = _gridDiv;
    return s;
}

- (void)republishMidi {
    if (_core && _core->ready()) (void)_core->runtime().midiScheduler().publish(_core->project());
}

// Pan, automation and mute changes: refresh the engine's track state AND the live faders.
- (void)applyMixerLive {
    if (!_core || !_core->ready()) return;
    _core->engine().applyProjectTrackMixerState(_core->project());
    (void)_core->engine().applyLiveMixerState(_core->project());
}

// A fader drag: only the live faders (no new voice plan per mouse event). If the graph is
// being replaced right now, fall back to the full refresh; the app repeats it once the new
// graph is live (see timerTick:).
- (void)applyFaderLive {
    if (!_core || !_core->ready()) return;
    if (!_core->engine().applyLiveMixerState(_core->project())) _core->engine().applyProjectTrackMixerState(_core->project());
}

- (void)applySolo {
    if (_core && _core->ready()) _core->runtime().applySoloState();
}

- (std::vector<ProjectPluginSlot>*)slotsForStrip:(SVStrip)strip {
    Project& p = _core->project();
    if (strip.kind == SVStripKind::Track) return strip.index < p.tracks.size() ? &p.tracks[strip.index].pluginSlots : nullptr;
    if (strip.kind == SVStripKind::Bus) return strip.index < p.buses.size() ? &p.buses[strip.index].pluginSlots : nullptr;
    return &p.masterPluginSlots;
}

- (IVst3PluginInstance*)instanceForStrip:(SVStrip)strip slot:(std::size_t)slot {
    if (!_core || !_core->ready()) return nullptr;
    auto& rack = _core->runtime().rack();
    try {
        if (strip.kind == SVStripKind::Track) return rack.trackInstance(strip.index, slot);
        if (strip.kind == SVStripKind::Bus) return rack.busInstance(strip.index, slot);
        return rack.masterInstance(slot);
    } catch (...) { return nullptr; }
}

- (NativePlugin*)nativeInstanceForStrip:(SVStrip)strip slot:(std::size_t)slot {
    auto* slots = [self slotsForStrip:strip];
    if (!slots || slot >= slots->size() || !isNativeModulePath((*slots)[slot].modulePath)) return nullptr;
    return dynamic_cast<NativePlugin*>([self instanceForStrip:strip slot:slot]);
}

- (NSString*)stripName:(SVStrip)strip {
    const Project& p = _core->project();
    if (strip.kind == SVStripKind::Track && strip.index < p.tracks.size()) return sv::ns(p.tracks[strip.index].name);
    if (strip.kind == SVStripKind::Bus && strip.index < p.buses.size()) return sv::ns(p.buses[strip.index].name);
    return @"Master";
}

- (void)openInsertEditor:(SVStrip)strip slot:(std::size_t)slot {
    auto* slots = [self slotsForStrip:strip];
    if (!slots || slot >= slots->size()) return;
    const auto& s = (*slots)[slot];
    if (isNativeModulePath(s.modulePath)) {
        __weak SilvetonController* weakSelf = self;
        const SVStrip st = strip;
        const std::size_t index = slot;
        SilvetonNativeResolver resolver = ^NativePlugin* {
            SilvetonController* strong = weakSelf;
            return strong ? [strong nativeInstanceForStrip:st slot:index] : nullptr;
        };
        if (![self nativeInstanceForStrip:strip slot:slot]) {
            [self showError:@"Plug-in" detail:"The processor is not running yet — wait a moment after adding it."];
            return;
        }
        NSString* key = [NSString stringWithFormat:@"%d:%lu:%lu", static_cast<int>(strip.kind), (unsigned long)strip.index, (unsigned long)slot];
        [SilvetonNativeEditor openWithResolver:resolver title:[NSString stringWithFormat:@"%@ — %@", [self stripName:strip], sv::ns(s.classId)] key:key];
        return;
    }
    IVst3PluginInstance* inst = [self instanceForStrip:strip slot:slot];
    if (!inst) { [self showError:@"VST3" detail:"The plug-in instance is unavailable (failed to load or still loading)."]; return; }
    if (!inst->openEditor()) [self showError:@"VST3" detail:"This plug-in has no editor window."];
}

- (void)insertPluginEntry:(const SVPluginEntry&)entry intoStrip:(SVStrip)strip {
    const SVPluginEntry e = entry;
    [self runEdit:@"Add Insert" rebuild:YES block:^{
        Project& p = self->_core->project();
        auto* slots = [self slotsForStrip:strip];
        if (!slots) throw std::runtime_error("no channel selected");
        if (slots->size() >= 16U) throw std::runtime_error("a channel holds at most 16 inserts");
        ProjectPluginSlot slot;
        slot.modulePath = e.modulePath;
        slot.classId = e.classId;
        if (e.instrument) {
            if (strip.kind != SVStripKind::Track) throw std::runtime_error("instruments belong on a track");
            slot.midiInputPort = nextFreeMidiPort(p);
            slots->insert(slots->begin(), slot);   // an instrument is the source: first slot
        } else {
            slots->push_back(slot);
        }
    }];
}

- (void)updateInputMonitoring {
    if (!_core || !_core->ready()) return;
    bool monitor = false;
    for (const auto& t : _core->project().tracks) if (t.recordArm && t.monitor) monitor = true;
    _core->engine().setLowLatencyInputMonitoring(monitor, 0.0F);
}

- (NSMenu*)paletteMenuWithAction:(SEL)action {
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Colour"];
    static NSString* names[16] = {@"Copper", @"Sage", @"Slate", @"Rose", @"Brass", @"Teal", @"Lavender", @"Brick",
                                  @"Moss", @"Ocean", @"Walnut", @"Ice", @"Mustard", @"Plum", @"Pine", @"Dusk"};
    NSMenuItem* autoItem = [m addItemWithTitle:@"Automatic" action:action keyEquivalent:@""];
    autoItem.tag = 0; autoItem.target = self;
    for (int i = 0; i < 16; ++i) {
        NSMenuItem* it = [m addItemWithTitle:names[i] action:action keyEquivalent:@""];
        it.tag = static_cast<NSInteger>(silvetonPaletteColor(static_cast<std::size_t>(i)));
        it.target = self;
        NSImage* sw = [[NSImage alloc] initWithSize:NSMakeSize(12, 12)];
        [sw lockFocus];
        sv::roundFill(NSMakeRect(0, 0, 12, 12), 3, sv::hex(silvetonPaletteColor(static_cast<std::size_t>(i))));
        [sw unlockFocus];
        it.image = sw;
    }
    return m;
}

// ================================================================== file ==
- (void)setTrackHeight:(id)sender {
    const NSInteger tag = [sender respondsToSelector:@selector(tag)] ? [sender tag] : 0;
    if (tag == -3) { [_arrange resetTrackHeights]; [self setStatus:@"All tracks are back to the normal height"]; return; }
    if (![_arrange setSelectedTrackHeight:static_cast<CGFloat>(tag)]) [self setStatus:@"Click a track first, then change its height"];
}

- (void)newProject:(id)sender {
    (void)sender;
    if (!_core) return;
    try {
        if (_core->recording()) _core->stopRecording(true);
        _core->engine().transport().stop();
        [SilvetonNativeEditor closeAll];
        _core->session().newProject(_core->device().config().sampleRate);
        [_arrange resetTrackHeights];
        [self clearArrangeSelectedEvents];
        _objectClipboard.clear();
        _core->waveformCache().clear();
        self.selectedTrack = -1; self.selectedMidiTrack = -1; self.selectedClipId = 0; self.selectedPartId = 0;
        [self requestRebuild];
        [self refreshAll];
    } catch (const std::exception& e) { [self showError:@"New Project" detail:e.what()]; }
}

- (void)openProject:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.allowedFileTypes = @[@"silveton", @"siv"];
    if ([panel runModal] != NSModalResponseOK) return;
    try {
        if (_core->recording()) _core->stopRecording(true);
        _core->engine().transport().stop();
        [SilvetonNativeEditor closeAll];
        const auto result = _core->session().open(sv::str(panel.URL.path));
        [_arrange resetTrackHeights];
        [self clearArrangeSelectedEvents];
        _objectClipboard.clear();
        _core->waveformCache().clear();
        self.selectedTrack = -1; self.selectedMidiTrack = -1; self.selectedClipId = 0; self.selectedPartId = 0;
        [self requestRebuild];
        [self refreshAll];
        if (result.recovered) [self showError:@"Project recovered" detail:"A recovery copy was loaded: " + result.loadedPath];
    } catch (const std::exception& e) { [self showError:@"Open Project" detail:e.what()]; }
}

- (void)saveProject:(id)sender {
    (void)sender;
    try {
        if (!_core->session().hasProjectPath()) { [self saveProjectAs:nil]; return; }
        _core->session().save();
        [self updateTitle];
        [self setStatus:@"Saved"];
    } catch (const std::exception& e) { [self showError:@"Save" detail:e.what()]; }
}

- (void)saveProjectAs:(id)sender {
    (void)sender;
    NSSavePanel* panel = [NSSavePanel savePanel];
    panel.allowedFileTypes = @[@"silveton"];
    panel.nameFieldStringValue = @"Song.silveton";
    if ([panel runModal] != NSModalResponseOK) return;
    try { _core->session().saveAs(sv::str(panel.URL.path)); [self updateTitle]; }
    catch (const std::exception& e) { [self showError:@"Save As" detail:e.what()]; }
}

- (void)undo:(id)sender { (void)sender; if ([self toneAbsorbUndo]) return; try { [SilvetonNativeEditor closeAll]; if (_core->session().undo()) { [self republishMidi]; [self refreshAll]; } } catch (const std::exception& e) { [self showError:@"Undo" detail:e.what()]; } }
- (void)redo:(id)sender { (void)sender; try { [SilvetonNativeEditor closeAll]; if (_core->session().redo()) { [self republishMidi]; [self refreshAll]; } } catch (const std::exception& e) { [self showError:@"Redo" detail:e.what()]; } }

- (void)importAudio:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.allowedFileTypes = @[@"wav", @"aif", @"aiff"];
    panel.allowsMultipleSelection = YES;
    if ([panel runModal] != NSModalResponseOK) return;
    [self importAudioURLs:panel.URLs atSample:self.playheadSample];
}

- (void)importAudioURLs:(NSArray<NSURL*>*)urls atSample:(std::int64_t)timelineSample {
    if (!_core || urls.count == 0) return;
    // The files are NOT converted and NOT copied: a 44.1/48 kHz file stays exactly as it is
    // on disk. The engine runs at the internal rate (96 kHz) and converts each file while it
    // plays, with the same Studio sinc, one cache page at a time. The clip therefore counts
    // its frames at the project rate (what the engine plays), the file's own rate is kept for
    // information.
    struct Item { std::string media, name; std::uint64_t frames {0U}; std::uint32_t channels {0U}, fileRate {0U}; };
    std::vector<Item> items;
    const double projectRate = _core->project().sampleRate;
    const auto targetRate = projectRate >= 8000.0 ? static_cast<std::uint32_t>(std::llround(projectRate)) : 0U;
    std::set<std::uint32_t> otherRates;
    try {
        for (NSURL* u in urls) {
            Item it;
            it.media = sv::str(u.path);
            it.name = sv::str([[u lastPathComponent] stringByDeletingPathExtension]);
            DiskStreamManager inspect(1U);
            auto& src = inspect.addSource(it.media, 16384U, targetRate);   // frames counted at the project rate
            it.frames = src.frames(); it.channels = src.channels(); it.fileRate = src.nativeSampleRate();
            if (it.channels == 0U || it.channels > 2U) throw std::runtime_error("Silveton imports mono or stereo WAV/AIFF files");
            if (src.rateConverted()) otherRates.insert(it.fileRate);
            items.push_back(std::move(it));
        }
    } catch (const std::exception& e) { [self showError:@"Import Audio" detail:e.what()]; return; }

    __block std::size_t imported = 0U;
    [self runEdit:@"Import Audio" rebuild:YES block:^{
        Project& project = self->_core->project();
        for (const auto& it : items) {
            ProjectTrack t;
            t.name = it.name;
            t.audioPath = it.media;
            ProjectAudioClip c;
            c.id = 1U; c.audioPath = it.media; c.timelineStartSample = std::max<std::int64_t>(0, timelineSample);
            c.lengthSamples = it.frames; c.sourceFrames = it.frames; c.sourceChannels = it.channels; c.sourceSampleRate = it.fileRate;
            t.clips.push_back(c);
            project.addTrack(std::move(t));
            self->_core->waveformCache().request(it.media);
            ++imported;
        }
        if (imported == 0U) throw std::runtime_error("no supported files");
        self.selectedTrack = static_cast<long>(project.tracks.size()) - 1;
        self.selectedClipId = 1U;
    }];
    if (!imported) return;
    NSMutableString* rates = [NSMutableString string];
    for (const auto r : otherRates) [rates appendFormat:@"%@%g kHz", rates.length ? @" / " : @"", r / 1000.0];
    [self setStatus:otherRates.empty()
        ? [NSString stringWithFormat:@"Imported %lu file(s)", (unsigned long)imported]
        : [NSString stringWithFormat:@"Imported %lu file(s) — files stay at %@; Silveton plays them at %.0f kHz", (unsigned long)imported, rates, projectRate / 1000.0]];
}

- (void)importMidi:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.allowedFileTypes = @[@"mid", @"midi", @"smf"];
    if ([panel runModal] != NSModalResponseOK) return;
    try {
        const auto smf = StandardMidiFile::read(sv::str(panel.URL.path), _core->project().sampleRate, true);
        if (smf.tracks.empty()) throw std::runtime_error("the file contains no notes or controllers");
        const bool adoptTempo = _core->project().tracks.empty() && _core->project().midiTracks.empty();
        [self runEdit:@"Import MIDI File" rebuild:YES block:^{
            Project& p = self->_core->project();
            if (adoptTempo) { p.tempoMap = smf.tempoMap; p.tempo = smf.tempoMap.initialTempo(); }
            for (const auto& t : smf.tracks) {
                if (p.tracks.size() >= Project::kMaxTracks) break;
                const bool drums = t.firstChannel == 9;
                ProjectTrack inst;
                inst.name = t.name.empty() ? (drums ? "Drums" : "MIDI") : t.name;
                ProjectPluginSlot synth;
                synth.modulePath = kNativeModulePath;
                synth.classId = "silveton.poly";
                synth.midiInputPort = nextFreeMidiPort(p);
                inst.pluginSlots.push_back(synth);
                const int port = synth.midiInputPort;
                p.addTrack(std::move(inst));
                ProjectMidiTrack mt;
                mt.name = t.name.empty() ? "MIDI" : t.name;
                mt.outputPort = port;
                (void)MidiTrackTools::addPartFromAbsolute(mt, t.sequence, 4.0);
                p.midiTracks.push_back(std::move(mt));
            }
        }];
        [self setStatus:[NSString stringWithFormat:@"Imported %lu MIDI track(s)%@", (unsigned long)smf.tracks.size(), adoptTempo ? @" with tempo map" : @""]];
    } catch (const std::exception& e) { [self showError:@"Import MIDI" detail:e.what()]; }
}

- (void)exportMidi:(id)sender {
    (void)sender;
    const Project& p = _core->project();
    if (p.midiTracks.empty()) { [self showError:@"Export MIDI" detail:"The project has no MIDI tracks."]; return; }
    NSSavePanel* panel = [NSSavePanel savePanel];
    panel.allowedFileTypes = @[@"mid"];
    panel.nameFieldStringValue = @"Silveton.mid";
    if ([panel runModal] != NSModalResponseOK) return;
    try {
        std::vector<MidiSequence> flat;
        flat.reserve(p.midiTracks.size());
        std::vector<SmfExportTrack> tracks;
        for (const auto& mt : p.midiTracks) flat.push_back(sequenceFromRenderPlan(compileMidiArrangement(mt.sequence, mt.parts, p.tempoMap), p.tempoMap));
        for (std::size_t i = 0; i < p.midiTracks.size(); ++i) tracks.push_back({p.midiTracks[i].name, &flat[i]});
        StandardMidiFile::write(sv::str(panel.URL.path), tracks, p.tempoMap, 480U);
        [self setStatus:@"MIDI file exported"];
    } catch (const std::exception& e) { [self showError:@"Export MIDI" detail:e.what()]; }
}

- (OfflineBounceOptions)bounceOptions {
    OfflineBounceOptions o;
    const Project& p = _core->project();
    std::int64_t end = 1;
    for (const auto& t : p.tracks) for (const auto& c : t.clips) end = std::max<std::int64_t>(end, c.timelineStartSample + static_cast<std::int64_t>(c.lengthSamples));
    for (const auto& m : p.midiTracks) {
        for (const auto& part : m.parts) end = std::max(end, p.tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes + part.lengthQuarterNotes));
        for (const auto& n : m.sequence.notes()) end = std::max(end, p.tempoMap.sampleAtQuarterNotes(n.startQuarterNotes + n.durationQuarterNotes));
    }
    o.startSample = 0;
    o.endSample = end;
    if (_core->ready()) {
        const auto& t = _core->engine().transport();
        if (t.cycleEnabled() && t.cycleEndSample() > t.cycleStartSample()) { o.startSample = t.cycleStartSample(); o.endSample = t.cycleEndSample(); }
    }
    o.tailMode = BounceTailMode::Automatic;
    o.preRollSamples = static_cast<std::uint64_t>(p.sampleRate * 0.1);
    return o;
}

- (BOOL)chooseFormat:(OfflineBounceFileOptions*)f panel:(NSSavePanel*)panel {
    SVDialog* d = [SVDialog dialogWithTitle:@"Export Mixdown"
                                   subtitle:@"Range: the loop when it is on, otherwise the whole project plus the tails of the effects."
                                    okTitle:@"Continue"];
    const NSInteger container = [d addChoice:@"File type" items:@[@"WAV", @"AIFF"] selected:0];
    const NSInteger format = [d addChoice:@"Bit depth" items:@[@"32-bit float (no limit on level)", @"24-bit", @"16-bit (CD)", @"32-bit integer"] selected:1];
    const NSInteger rate = [d addChoice:@"Sample rate" items:@[@"Same as the project", @"44100 Hz", @"48000 Hz", @"88200 Hz", @"96000 Hz"] selected:0];
    const NSInteger dither = [d addCheck:@"Dither (hides rounding noise at 16 or 24 bit)" on:NO];
    [d setNote:^NSString*(SVDialog* dlg) {
        if ([dlg choiceAt:container] == 1 && [dlg choiceAt:format] == 0) return @"AIFF has no 32-bit float, so 32-bit integer will be used.";
        if ([dlg choiceAt:format] == 0 && [dlg checkAt:dither]) return @"Dither is not used with 32-bit float.";
        if ([dlg choiceAt:format] == 2) return @"16-bit is the CD standard. Turn Dither on for the cleanest result.";
        return @"The next window asks where to save the file.";
    }];
    if (![d run]) return NO;
    f->container = [d choiceAt:container] == 1 ? BounceContainer::Aiff : BounceContainer::Wav;
    switch ([d choiceAt:format]) {
        case 1: f->sampleFormat = BounceSampleFormat::Pcm24; break;
        case 2: f->sampleFormat = BounceSampleFormat::Pcm16; break;
        case 3: f->sampleFormat = BounceSampleFormat::Pcm32; break;
        default: f->sampleFormat = BounceSampleFormat::Float32; break;
    }
    if (f->container == BounceContainer::Aiff && f->sampleFormat == BounceSampleFormat::Float32) f->sampleFormat = BounceSampleFormat::Pcm32;
    f->dither = ([d checkAt:dither] && f->sampleFormat != BounceSampleFormat::Float32) ? BounceDither::Tpdf : BounceDither::None;
    static const std::uint32_t kRates[] = {0U, 44100U, 48000U, 88200U, 96000U};
    const NSInteger r = [d choiceAt:rate];
    if (r > 0 && r < 5) f->outputSampleRate = kRates[r];
    panel.allowedFileTypes = @[f->container == BounceContainer::Aiff ? @"aiff" : @"wav"];
    return YES;
}

- (void)exportMixdown:(id)sender {
    (void)sender;
    NSSavePanel* panel = [NSSavePanel savePanel];
    panel.nameFieldStringValue = @"Silveton Mix";
    OfflineBounceFileOptions f;
    if (![self chooseFormat:&f panel:panel]) return;
    if ([panel runModal] != NSModalResponseOK) return;
    NSString* outPath = panel.URL.path;
    SVProgress* progress = [SVProgress progressWithTitle:@"Exporting mixdown"];
    try {
        sv::AppRuntime::OfflineScope scope(*_core);
        OfflineBounceOptions options = [self bounceOptions];
        options.progress = [progress](double fraction) { return [progress updateFraction:fraction]; };
        [progress begin];
        struct CloseProgress { SVProgress* p; ~CloseProgress() { [p end]; } } closeProgress {progress};
        const auto r = OfflineBounce::renderAudioFile(sv::str(outPath), _core->project(), _core->engine(), &_core->runtime().rack(), options, f);
        [self setStatus:[NSString stringWithFormat:@"Exported %.1f s, peak %.1f dBFS", r.writtenFrames / std::max(1.0, static_cast<double>(r.outputSampleRate)),
                         20.0 * std::log10(std::max(1e-9, static_cast<double>(r.peak)))]];
    } catch (const BounceCancelled&) {
        [[NSFileManager defaultManager] removeItemAtPath:outPath error:nil];   // the half-written file is useless
        [self setStatus:@"Export cancelled"];
    } catch (const std::exception& e) { [self showError:@"Export Mixdown" detail:e.what()]; }
}

- (void)exportStems:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.canChooseFiles = NO; panel.canChooseDirectories = YES; panel.canCreateDirectories = YES;
    panel.prompt = @"Export Stems Here";
    if ([panel runModal] != NSModalResponseOK) return;
    SVProgress* progress = [SVProgress progressWithTitle:@"Exporting stems"];
    std::vector<TrackStemRequest> stemPaths;
    try {
        const Project& p = _core->project();
        std::vector<TrackStemRequest> req;
        for (std::size_t i = 0; i < p.tracks.size(); ++i) {
            std::string n = p.tracks[i].name.empty() ? "Track " + std::to_string(i + 1) : p.tracks[i].name;
            for (auto& ch : n) if (ch == '/' || ch == ':') ch = '_';
            req.push_back({sv::str(panel.URL.path) + "/" + std::to_string(i + 1) + " " + n + ".wav", {i}});
        }
        if (req.empty()) throw std::runtime_error("the project has no tracks");
        stemPaths = req;
        sv::AppRuntime::OfflineScope scope(*_core);
        OfflineBounceFileOptions f;
        f.sampleFormat = BounceSampleFormat::Pcm24;
        progress.parts = static_cast<NSInteger>(req.size());
        progress.partNoun = @"Stem";
        OfflineBounceOptions options = [self bounceOptions];
        options.progress = [progress](double fraction) { return [progress updateFraction:fraction]; };
        [progress begin];
        struct CloseProgress { SVProgress* p; ~CloseProgress() { [p end]; } } closeProgress {progress};
        const auto results = StemBounce::renderTrackStems(_core->project(), _core->engine(), &_core->runtime().rack(), options, f, req);
        [self setStatus:[NSString stringWithFormat:@"%lu stem(s) exported", (unsigned long)results.size()]];
    } catch (const BounceCancelled&) {
        for (const auto& r : stemPaths) [[NSFileManager defaultManager] removeItemAtPath:sv::ns(r.path) error:nil];
        [self setStatus:@"Export cancelled — the unfinished stems were deleted"];
    } catch (const std::exception& e) { [self showError:@"Export Stems" detail:e.what()]; }
}

- (void)audioSetup:(id)sender {
    (void)sender;
    try {
        const auto allDevices = CoreAudioDevice::devices();
        std::vector<CoreAudioDeviceInfo> devices;
        for (const auto& candidate : allDevices)
            if (candidate.outputChannels != 0U) devices.push_back(candidate);
        if (devices.empty()) throw std::runtime_error("no CoreAudio output devices were found");
        SVDialog* d = [SVDialog dialogWithTitle:@"Audio System Setup"
                                       subtitle:@"Which device plays the sound, how big its buffer is and how fast it runs. A small buffer gives less delay but is harder for the computer."
                                        okTitle:@"Apply"];
        NSMutableArray<NSString*>* names = [NSMutableArray array];
        for (const auto& x : devices) [names addObject:[NSString stringWithFormat:@"%@  (%u in / %u out)", sv::ns(x.name), x.inputChannels, x.outputChannels]];
        const NSInteger device = [d addChoice:@"Device" items:names selected:0];
        NSArray<NSString*>* blocks = @[@"64", @"128", @"256", @"512", @"1024", @"2048"];
        NSArray<NSString*>* rates = @[@"44100", @"48000", @"88200", @"96000"];
        const bool audioReady = _core && _core->ready();
        const auto currentBlock = audioReady ? _core->device().config().blockSize : 256U;
        const auto currentRate = audioReady ? _core->device().config().sampleRate : 48000.0;
        NSUInteger blockNow = [blocks indexOfObject:[NSString stringWithFormat:@"%u", currentBlock]];
        NSUInteger rateNow = [rates indexOfObject:[NSString stringWithFormat:@"%.0f", currentRate]];
        if (blockNow == NSNotFound) blockNow = 2U;
        if (rateNow == NSNotFound) rateNow = 1U;
        const NSInteger blockRow = [d addChoice:@"Buffer size" items:blocks selected:static_cast<NSInteger>(blockNow)];
        const NSInteger rateRow = [d addChoice:@"Sample rate" items:rates selected:static_cast<NSInteger>(rateNow)];
        [d setNote:^NSString*(SVDialog* dlg) {
            const double block = [blocks[static_cast<NSUInteger>([dlg choiceAt:blockRow])] doubleValue];
            const double rate = [rates[static_cast<NSUInteger>([dlg choiceAt:rateRow])] doubleValue];
            return [NSString stringWithFormat:@"Delay of one buffer: about %.1f ms.", block / rate * 1000.0];
        }];
        if (![d run]) return;
        const NSInteger idx = [d choiceAt:device];
        if (idx < 0 || idx >= static_cast<NSInteger>(devices.size())) return;
        const auto& dev = devices[static_cast<std::size_t>(idx)];
        AudioDeviceConfig cfg;
        cfg.sampleRate = rates[static_cast<NSUInteger>([d choiceAt:rateRow])].doubleValue;
        cfg.blockSize = static_cast<std::uint32_t>(blocks[static_cast<NSUInteger>([d choiceAt:blockRow])].intValue);
        cfg.inputChannels = std::min<std::uint32_t>(2U, dev.inputChannels);
        cfg.outputChannels = std::min<std::uint32_t>(2U, dev.outputChannels);
        if (cfg.outputChannels == 0U) throw std::runtime_error("that device has no outputs");
        CoreAudioDeviceOptions opts;
        opts.deviceUid = dev.uid;
        opts.followDefaultOutputDevice = false;
        [SilvetonNativeEditor closeAll];
        try {
            _core->restartAudio(cfg, opts);
        } catch (...) {
            _core->shutdownRealtime(); // allow the next Apply without leaving partial state
            throw;
        }
        [self refreshAll];
        [self setStatus:@"CoreAudio connected — playback is available"];
    } catch (const std::exception& e) { [self showError:@"Audio Setup" detail:e.what()]; }
}

// ================================================================ tracks ==
- (void)addAudioTrack:(id)sender {
    (void)sender;
    [self runEdit:@"Add Audio Track" rebuild:YES block:^{
        Project& p = self->_core->project();
        ProjectTrack t;
        t.name = "Audio " + std::to_string(p.tracks.size() + 1);
        p.addTrack(std::move(t));
        self.selectedTrack = static_cast<long>(p.tracks.size()) - 1;
        self.selectedMidiTrack = -1;
    }];
}

- (void)addInstrumentTrackWith:(const SVPluginEntry&)entry {
    const SVPluginEntry e = entry;
    [self runEdit:@"Add Instrument Track" rebuild:YES block:^{
        Project& p = self->_core->project();
        const int port = nextFreeMidiPort(p);
        ProjectTrack inst;
        inst.name = e.name;
        ProjectPluginSlot slot;
        slot.modulePath = e.modulePath; slot.classId = e.classId; slot.midiInputPort = port;
        inst.pluginSlots.push_back(slot);
        p.addTrack(std::move(inst));
        ProjectMidiTrack mt;
        mt.name = e.name;
        mt.outputPort = port;
        p.midiTracks.push_back(std::move(mt));
        self.selectedMidiTrack = static_cast<long>(p.midiTracks.size()) - 1;
        self.selectedTrack = -1;
        if (self->_core->midi()) self->_core->midi()->setTargetPort(port);
    }];
}

- (void)addInstrumentTrack:(id)sender {
    SVPluginEntry e;
    e.native = true; e.instrument = true; e.modulePath = kNativeModulePath; e.classId = "silveton.poly"; e.name = "Poly Synth";
    if ([sender isKindOfClass:[NSMenuItem class]] && [[sender representedObject] isKindOfClass:[NSDictionary class]]) {
        NSDictionary* d = [sender representedObject];
        e.native = [d[@"native"] boolValue]; e.modulePath = sv::str(d[@"module"]); e.classId = sv::str(d[@"class"]); e.name = sv::str(d[@"name"]);
    }
    [self addInstrumentTrackWith:e];
}

- (void)addMidiTrack:(id)sender {
    (void)sender;
    [self runEdit:@"Add MIDI Track" rebuild:YES block:^{
        Project& p = self->_core->project();
        ProjectMidiTrack mt;
        mt.name = "MIDI " + std::to_string(p.midiTracks.size() + 1);
        p.midiTracks.push_back(std::move(mt));
        self.selectedMidiTrack = static_cast<long>(p.midiTracks.size()) - 1;
        self.selectedTrack = -1;
    }];
}

- (void)addGroupBus:(id)sender {
    (void)sender;
    [self runEdit:@"Add Group" rebuild:YES block:^{
        ProjectBus b; b.kind = ProjectBusKind::Group; b.name = "Group " + std::to_string(self->_core->project().buses.size() + 1);
        TrackTools::addBus(self->_core->project(), std::move(b));
    }];
}
- (void)addFxBus:(id)sender {
    (void)sender;
    [self runEdit:@"Add FX Channel" rebuild:YES block:^{
        ProjectBus b; b.kind = ProjectBusKind::FxReturn; b.name = "FX " + std::to_string(self->_core->project().buses.size() + 1);
        ProjectPluginSlot verb; verb.modulePath = kNativeModulePath; verb.classId = "silveton.space";
        std::string why;
        if (auto proto = createNativePlugin("silveton.space", why)) { proto->setPlainValue(7, 100.0); verb.componentState = proto->componentState(); }
        b.pluginSlots.push_back(verb);
        TrackTools::addBus(self->_core->project(), std::move(b));
    }];
}
- (void)addFolder:(id)sender {
    (void)sender;
    NSString* name = [self promptText:@"New Folder" message:@"Selected track moves into the folder." initial:@"Folder"];
    if (!name) return;
    [self runEdit:@"Add Folder" rebuild:NO block:^{
        Project& p = self->_core->project();
        const int id = FolderTools::addFolder(p, sv::str(name));
        if (self.selectedTrack >= 0) p.tracks[static_cast<std::size_t>(self.selectedTrack)].folder = id;
        if (self.selectedMidiTrack >= 0) p.midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)].folder = id;
    }];
}

- (void)duplicateTrack:(id)sender {
    (void)sender;
    if (self.selectedTrack < 0) return;
    [self runEdit:@"Duplicate Track" rebuild:YES block:^{
        self.selectedTrack = static_cast<long>(TrackTools::duplicateTrack(self->_core->project(), static_cast<std::size_t>(self.selectedTrack)));
    }];
}

- (void)deleteTrack:(id)sender {
    (void)sender;
    [SilvetonNativeEditor closeAll];
    [self clearArrangeSelectedEvents]; // deleted track shifts all later indices
    if (self.selectedTrack >= 0) {
        const auto index = static_cast<std::size_t>(self.selectedTrack);
        [self runEdit:@"Delete Track" rebuild:YES block:^{ TrackTools::removeTrack(self->_core->project(), index); }];
        self.selectedTrack = -1; self.selectedClipId = 0;
    } else if (self.selectedMidiTrack >= 0) {
        const auto index = static_cast<std::size_t>(self.selectedMidiTrack);
        [self runEdit:@"Delete MIDI Track" rebuild:YES block:^{
            auto& v = self->_core->project().midiTracks;
            v.erase(v.begin() + static_cast<std::ptrdiff_t>(index));
        }];
        self.selectedMidiTrack = -1; self.selectedPartId = 0;
    } else if (self.selectedFolder >= 0) {
        const int id = _core->project().folders[static_cast<std::size_t>(self.selectedFolder)].id;
        [self runEdit:@"Delete Folder" rebuild:NO block:^{ (void)FolderTools::removeFolder(self->_core->project(), id); }];
        self.selectedFolder = -1;
    }
    [self refreshAll];
}

// One atomic undoable reorder; no repeated rebuild for a drag across several tracks.
- (void)reorderAudioTrackFrom:(std::size_t)from to:(std::size_t)to {
    if (!_core || from == to) return;
    auto& p = _core->project();
    if (from >= p.tracks.size() || to >= p.tracks.size()) return;
    // When dragging into another folder, follow the destination's grouping.
    const int destinationFolder = p.tracks[to].folder;
    [self clearArrangeSelectedEvents]; // indices change when tracks are reordered
    [self runEdit:@"Reorder Audio Track" rebuild:YES block:^{
        self->_core->project().tracks[from].folder = destinationFolder;
        TrackTools::moveTrack(self->_core->project(), from, to);
    }];
    self.selectedTrack = static_cast<long>(to);
    self.selectedMidiTrack = -1;
    self.selectedFolder = -1;
    [self selectRow:ArrangeRow {ArrangeRowKind::Audio, to, 0}];
    [self refreshAll];
}

- (void)moveTrack:(int)dir {
    if (self.selectedTrack < 0) return;
    const long to = self.selectedTrack + dir;
    if (to < 0 || to >= static_cast<long>(_core->project().tracks.size())) return;
    const auto from = static_cast<std::size_t>(self.selectedTrack);
    [self clearArrangeSelectedEvents];
    [self runEdit:@"Move Track" rebuild:YES block:^{ TrackTools::moveTrack(self->_core->project(), from, static_cast<std::size_t>(to)); }];
    self.selectedTrack = to;
    [self refreshAll];
}
- (void)moveTrackUp:(id)sender { (void)sender; [self moveTrack:-1]; }
- (void)moveTrackDown:(id)sender { (void)sender; [self moveTrack:1]; }

- (void)projectNotes:(id)sender {
    (void)sender;
    NSString* s = [self promptText:@"Project Notes" message:@"" initial:sv::ns(_core->project().notes)];
    if (!s) return;
    [self runEdit:@"Project Notes" rebuild:NO block:^{ self->_core->project().notes = sv::str(s); }];
}

- (void)flattenArranger:(id)sender {
    (void)sender;
    if (_core->project().arrangerChain.empty()) { [self showError:@"Flatten Chain" detail:"Build an arranger chain first (Library ▸ Arranger)."]; return; }
    [SilvetonNativeEditor closeAll];
    [self runEdit:@"Flatten Arranger Chain" rebuild:YES block:^{
        Project flat = ArrangerTools::flattenChain(self->_core->project());
        self->_core->project() = std::move(flat);
    }];
    [self setStatus:@"Arranger chain flattened into the timeline"];
}

// ============================================================ row toggles ==
- (void)toggleMute:(ArrangeRow)row {
    Project& p = _core->project();
    if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) {
        [self runEdit:@"Mute" rebuild:NO block:^{ auto& t = self->_core->project().tracks[row.index]; t.mute = !t.mute; }];
        [self applyMixerLive];
    } else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) {
        [self runEdit:@"Mute MIDI" rebuild:NO block:^{ auto& t = self->_core->project().midiTracks[row.index]; t.mute = !t.mute; }];
        [self republishMidi];
    } else if (row.kind == ArrangeRowKind::Folder && row.index < p.folders.size()) {
        const int id = p.folders[row.index].id;
        bool all = true, any = false;
        for (const auto& t : p.tracks) if (FolderTools::isInside(p, t.folder, id)) { any = true; all &= t.mute; }
        const bool target = !(any && all);
        [self runEdit:@"Mute Folder" rebuild:NO block:^{ FolderTools::setMute(self->_core->project(), id, target); }];
        [self applyMixerLive];
        [self republishMidi];
    }
    [self refreshAll];
}

- (void)toggleSolo:(ArrangeRow)row {
    Project& p = _core->project();
    if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) p.tracks[row.index].solo = !p.tracks[row.index].solo;
    else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) p.midiTracks[row.index].solo = !p.midiTracks[row.index].solo;
    else if (row.kind == ArrangeRowKind::Folder && row.index < p.folders.size()) {
        const int id = p.folders[row.index].id;
        bool any = false;
        for (const auto& t : p.tracks) if (FolderTools::isInside(p, t.folder, id) && t.solo) any = true;
        FolderTools::setSolo(p, id, !any);
    }
    _core->session().markDirty();
    [self applySolo];
    [self refreshAll];
}

- (void)toggleArm:(ArrangeRow)row {
    Project& p = _core->project();
    if (row.kind != ArrangeRowKind::Audio || row.index >= p.tracks.size()) return;
    p.tracks[row.index].recordArm = !p.tracks[row.index].recordArm;
    _core->session().markDirty();
    [self updateInputMonitoring];
    [self refreshAll];
}

- (void)toggleMonitor:(ArrangeRow)row {
    Project& p = _core->project();
    if (row.kind != ArrangeRowKind::Audio || row.index >= p.tracks.size()) return;
    p.tracks[row.index].monitor = !p.tracks[row.index].monitor;
    _core->session().markDirty();
    [self updateInputMonitoring];
    [self refreshAll];
}

- (void)toggleFolderCollapse:(std::size_t)folderIndex {
    Project& p = _core->project();
    if (folderIndex >= p.folders.size()) return;
    p.folders[folderIndex].collapsed = !p.folders[folderIndex].collapsed;
    _core->session().markDirty();
    [self refreshAll];
}

- (void)renameRow:(ArrangeRow)row {
    Project& p = _core->project();
    NSString* current = @"";
    if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) current = sv::ns(p.tracks[row.index].name);
    else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) current = sv::ns(p.midiTracks[row.index].name);
    else if (row.kind == ArrangeRowKind::Folder && row.index < p.folders.size()) current = sv::ns(p.folders[row.index].name);
    else return;
    NSString* name = [self promptText:@"Rename" message:@"" initial:current];
    if (!name.length) return;
    [self runEdit:@"Rename" rebuild:NO block:^{
        Project& pr = self->_core->project();
        if (row.kind == ArrangeRowKind::Audio) pr.tracks[row.index].name = sv::str(name);
        else if (row.kind == ArrangeRowKind::Midi) pr.midiTracks[row.index].name = sv::str(name);
        else pr.folders[row.index].name = sv::str(name);
    }];
}
- (void)renameSelected:(id)sender {
    (void)sender;
    ArrangeRow r;
    if (self.selectedTrack >= 0) { r.kind = ArrangeRowKind::Audio; r.index = static_cast<std::size_t>(self.selectedTrack); }
    else if (self.selectedMidiTrack >= 0) { r.kind = ArrangeRowKind::Midi; r.index = static_cast<std::size_t>(self.selectedMidiTrack); }
    else if (self.selectedFolder >= 0) { r.kind = ArrangeRowKind::Folder; r.index = static_cast<std::size_t>(self.selectedFolder); }
    else return;
    [self renameRow:r];
}

- (void)setRowColour:(NSMenuItem*)item {
    const auto color = static_cast<std::uint32_t>(item.tag);
    const ArrangeRow row = _menuRow;
    [self runEdit:@"Colour" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) p.tracks[row.index].color = color;
        else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) p.midiTracks[row.index].color = color;
        else if (row.kind == ArrangeRowKind::Folder && row.index < p.folders.size()) p.folders[row.index].color = color;
    }];
}

- (void)toggleLock:(id)sender {
    (void)sender;
    if (self.selectedTrack < 0) return;
    [self runEdit:@"Lock Track" rebuild:NO block:^{
        auto& t = self->_core->project().tracks[static_cast<std::size_t>(self.selectedTrack)];
        t.locked = !t.locked;
    }];
}

- (void)moveToFolder:(NSMenuItem*)item {
    const int folder = static_cast<int>(item.tag);
    const ArrangeRow row = _menuRow;
    [self runEdit:@"Move to Folder" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size()) p.tracks[row.index].folder = folder;
        else if (row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size()) p.midiTracks[row.index].folder = folder;
    }];
}

- (void)setMidiOutput:(NSMenuItem*)item {
    const int port = static_cast<int>(item.tag);
    const long track = _menuRow.kind == ArrangeRowKind::Midi ? static_cast<long>(_menuRow.index) : self.selectedMidiTrack;
    if (track < 0) return;
    [self runEdit:@"MIDI Output" rebuild:NO block:^{ self->_core->project().midiTracks[static_cast<std::size_t>(track)].outputPort = port; }];
    [self republishMidi];
    if (_core->midi()) _core->midi()->setTargetPort(port);
}

// ============================================================ automation lanes ==
- (AutomationMode)automationMode:(std::size_t)track lane:(int)lane {
    if (!_core || track >= _core->project().tracks.size()) return AutomationMode::Off;
    const auto& t = _core->project().tracks[track];
    return lane == 0 ? t.gainAutomationMode : (lane == 1 ? t.panAutomationMode : t.muteAutomationMode);
}
- (void)cycleAutomationMode:(std::size_t)track lane:(int)lane {
    if (!_core || track >= _core->project().tracks.size()) return;
    const int next = (static_cast<int>([self automationMode:track lane:lane]) + 1) % 5;
    [self runEdit:@"Automation Mode" rebuild:NO block:^{
        auto& t = self->_core->project().tracks[track];
        const auto m = static_cast<AutomationMode>(next);
        if (lane == 0) t.gainAutomationMode = m; else if (lane == 1) t.panAutomationMode = m; else t.muteAutomationMode = m;
    }];
    [self applyMixerLive];
    static NSString* const names[5] = {@"Off", @"Read", @"Write", @"Touch", @"Latch"};
    [self setStatus:[NSString stringWithFormat:@"%s automation: %@", lane == 0 ? "Volume" : (lane == 1 ? "Pan" : "Mute"), names[next]]];
}
- (void)automationEdit:(NSString*)label track:(std::size_t)track lane:(int)lane op:(void (^)(AutomationLane& lane))op {
    if (!_core || track >= _core->project().tracks.size()) return;
    void (^apply)(void) = ^{
        auto& t = self->_core->project().tracks[track];
        AutomationLane& al = lane == 0 ? t.gainAutomationDb : (lane == 1 ? t.panAutomation : t.muteAutomation);
        op(al);
        AutomationMode& mode = lane == 0 ? t.gainAutomationMode : (lane == 1 ? t.panAutomationMode : t.muteAutomationMode);
        if (mode == AutomationMode::Off && !al.points().empty()) mode = AutomationMode::Read;   // drawn automation is meant to play
    };
    if (_gestureOpen) {   // inside a mouse gesture: change, mark, repaint the lanes only (the gesture is one undo step)
        try { apply(); } catch (const std::exception& e) { [self setStatus:sv::ns(e.what())]; return; }
        _core->session().markDirty();
        [self applyMixerLive];
        [_arrange setNeedsDisplay:YES];
        return;
    }
    [self runEdit:label rebuild:NO block:apply];
    [self applyMixerLive];
}
- (void)toggleAutomationLanes:(id)sender { (void)sender; [_arrange toggleAutomationLanes]; [self refreshAll]; }

// ============================================================== tempo track ==
- (void)toggleTempoTrack:(id)sender { (void)sender; [_arrange toggleTempoTrack]; [self refreshAll]; }
- (void)tempoEdit:(NSString*)label op:(void (^)(TempoMap& map))op {
    if (!_core) return;
    [self runEdit:label rebuild:YES block:^{
        Project& pr = self->_core->project();
        op(pr.tempoMap);
        pr.tempo = pr.tempoMap.initialTempo();
    }];
}
- (void)tempoGestureEdit:(void (^)(TempoMap& map))op {
    if (!_core) return;
    try {
        Project& pr = _core->project();
        op(pr.tempoMap);
        pr.tempo = pr.tempoMap.initialTempo();
    } catch (const std::exception& e) { [self setStatus:sv::ns(e.what())]; return; }
    _core->session().markDirty();
    _gestureNeedsRebuild = YES;   // the engine takes the new map once the mouse is up
    [_arrange setNeedsDisplay:YES];
    [_transport setNeedsDisplay:YES];
}
- (void)tempoTypeValueAt:(std::int64_t)sample {
    if (!_core) return;
    const Project& p = _core->project();
    const double now = sample == 0 ? p.tempoMap.initialTempo() : p.tempoMap.tempoAtSample(sample);
    NSString* s = [self promptText:@"Tempo" message:(sample == 0 ? @"Tempo at the start, in BPM" : @"Tempo from this point on, in BPM") initial:[NSString stringWithFormat:@"%.3f", now]];
    if (!s) return;
    const double bpm = s.doubleValue;
    if (!(bpm >= 20.0 && bpm <= 400.0)) { [self showError:@"Tempo" detail:"Tempo must be between 20 and 400 BPM"]; return; }
    [self tempoEdit:@"Tempo" op:^(TempoMap& tm) { if (sample == 0) tm.setInitialTempo(bpm); else tm.addTempoChange(sample, bpm); }];
}

// ============================================================== take lanes ==
- (void)toggleTakeLanes:(id)sender { (void)sender; [_arrange toggleTakeLanes]; [self refreshAll]; }
// The default crossfade where two takes meet: 10 ms.
- (std::uint64_t)compCrossfadeSamples { return static_cast<std::uint64_t>(std::llround(std::max(8000.0, _core->project().sampleRate) * 0.01)); }
- (void)compUseTake:(std::size_t)track lane:(std::uint64_t)laneId {
    if (!_core || track >= _core->project().tracks.size()) return;
    const std::uint64_t xf = [self compCrossfadeSamples];
    [self runClipEdit:@"Use Take" block:^{
        Project& p = self->_core->project();
        const auto& lanes = p.tracks[track].takeLanes;
        const auto it = std::find_if(lanes.begin(), lanes.end(), [laneId](const ProjectTakeLane& l) { return l.id == laneId; });
        if (it == lanes.end()) throw std::out_of_range("take lane");
        CompEditor editor(p, track);
        for (const auto& clip : it->clips)
            (void)editor.selectRange(laneId, clip.id, clip.timelineStartSample, clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples), xf);
    }];
    [self setStatus:@"The whole take plays now"];
}
- (void)compUseTake:(std::size_t)track lane:(std::uint64_t)laneId clip:(std::uint64_t)clipId from:(std::int64_t)start to:(std::int64_t)end {
    if (!_core || track >= _core->project().tracks.size() || end <= start) return;
    const std::uint64_t xf = [self compCrossfadeSamples];
    [self runClipEdit:@"Use Part of Take" block:^{
        CompEditor editor(self->_core->project(), track);
        (void)editor.selectRange(laneId, clipId, start, end, xf);
    }];
    [self setStatus:[NSString stringWithFormat:@"This part of the take plays now (%@), with a 10 ms crossfade at its edges", [self sampleDurationText:end - start]]];
}

// Crossfade (X): the selected clip and the next clip on the track blend where they meet. When they do
// not overlap, the first one is lengthened into its own file (or the second one is started earlier) by
// 10 ms, so there is something to blend.
- (void)crossfadeClips:(id)sender {
    (void)sender;
    if (!_core) return;
    Project& p = _core->project();
    std::size_t track = 0; std::uint64_t a = 0, bId = 0;
    const auto marked = [self markedClips];
    if (marked.size() >= 2U && marked[0].first == marked[1].first) {
        track = marked[0].first;
        // the earlier of the two first
        const ProjectAudioClip* ca = nullptr; const ProjectAudioClip* cb = nullptr;
        for (const auto& c : p.tracks[track].clips) { if (c.id == marked[0].second) ca = &c; if (c.id == marked[1].second) cb = &c; }
        if (!ca || !cb) return;
        if (ca->timelineStartSample <= cb->timelineStartSample) { a = ca->id; bId = cb->id; } else { a = cb->id; bId = ca->id; }
    } else if (self.selectedTrack >= 0 && self.selectedClipId) {
        track = static_cast<std::size_t>(self.selectedTrack);
        a = self.selectedClipId;
        const ProjectAudioClip* ca = nullptr;
        for (const auto& c : p.tracks[track].clips) if (c.id == a) ca = &c;
        if (!ca) return;
        const std::int64_t aEnd = ca->timelineStartSample + static_cast<std::int64_t>(ca->lengthSamples);
        const ProjectAudioClip* next = nullptr;
        for (const auto& c : p.tracks[track].clips)
            if (c.id != a && c.timelineStartSample >= ca->timelineStartSample && c.timelineStartSample <= aEnd + static_cast<std::int64_t>(p.sampleRate * 0.01) &&
                (!next || c.timelineStartSample < next->timelineStartSample)) next = &c;
        if (!next) { [self setStatus:@"Crossfade: no clip follows the selected one closely enough (they must meet or overlap)"]; return; }
        bId = next->id;
    } else {
        [self setStatus:@"Crossfade: select a clip (the next clip on the track is blended with it), or mark two clips"];
        return;
    }
    if (p.tracks[track].locked) { [self setStatus:@"The track is locked"]; return; }
    const std::uint64_t minXf = static_cast<std::uint64_t>(std::llround(p.sampleRate * 0.01));
    [self runClipEdit:@"Crossfade" block:^{
        Project& pr = self->_core->project();
        auto& clips = pr.tracks[track].clips;
        auto find = [&](std::uint64_t id) -> ProjectAudioClip* { for (auto& c : clips) if (c.id == id) return &c; return nullptr; };
        ProjectAudioClip* ca = find(a); ProjectAudioClip* cb = find(bId);
        if (!ca || !cb) throw std::runtime_error("clip not found");
        std::int64_t aEnd = ca->timelineStartSample + static_cast<std::int64_t>(ca->lengthSamples);
        std::int64_t overlap = aEnd - cb->timelineStartSample;
        ClipEditor e(pr, track);
        if (overlap < static_cast<std::int64_t>(minXf)) {
            // make room: lengthen A into its file, else start B earlier
            const std::uint64_t need = minXf - static_cast<std::uint64_t>(std::max<std::int64_t>(0, overlap));
            const std::uint64_t aTail = ca->sourceFrames - (ca->sourceStartSample + ca->lengthSamples);
            if (aTail >= need) { e.trimRight(a, aEnd + static_cast<std::int64_t>(need), ClipSnapSettings {}); }
            else if (cb->sourceStartSample >= need) { e.trimLeft(bId, cb->timelineStartSample - static_cast<std::int64_t>(need), ClipSnapSettings {}); }
            else throw std::runtime_error("neither file has 10 ms to spare for the blend");
            ca = find(a); cb = find(bId);
            aEnd = ca->timelineStartSample + static_cast<std::int64_t>(ca->lengthSamples);
            overlap = aEnd - cb->timelineStartSample;
        }
        const std::uint64_t xf = static_cast<std::uint64_t>(std::max<std::int64_t>(1, overlap));
        e.setFades(a, ca->fadeInSamples, std::min<std::uint64_t>(xf, ca->lengthSamples));
        e.setFades(bId, std::min<std::uint64_t>(xf, cb->lengthSamples), cb->fadeOutSamples);
    }];
    [self setStatus:@"Crossfade set where the two clips meet (the fades of the clips do the blend)"];
}

// ============================================================ marquee events ==
- (std::vector<SVSelectedEvent>)arrangeSelectedEvents {
    return _arrange ? [_arrange selectedEvents] : std::vector<SVSelectedEvent> {};
}
- (void)clearArrangeSelectedEvents { [_arrange clearSelectedEvents]; }
- (void)selectAllArrangeEvents { [_arrange selectAllEvents]; }

// A rectangular selection is one undoable edit, even when it spans audio and MIDI tracks.
- (void)deleteArrangeEvents {
    const auto selected = [self arrangeSelectedEvents];
    if (selected.empty() || !_core) return;
    [self runClipEdit:@"Delete Selected Events" block:^{
        Project& p = self->_core->project();
        for (const auto& s : selected) {
            if (!s.id) continue;
            if (s.midi) {
                if (s.track < p.midiTracks.size()) {
                    MidiPartEditor e(p.midiTracks[s.track].parts);
                    (void)e.remove(s.id);
                }
            } else if (s.track < p.tracks.size() && !p.tracks[s.track].locked) {
                try { ClipEditor e(p, s.track); e.removeClip(s.id); } catch (...) {}
            }
        }
    }];
    [self clearArrangeSelectedEvents];
    self.selectedClipId = self.selectedPartId = 0;
    [self republishMidi];
}
- (void)copyArrangeEvents {
    _objectClipboard.clear();
    if (!_core) return;
    const Project& p = _core->project();
    std::int64_t earliest = std::numeric_limits<std::int64_t>::max();
    for (const auto& s : [self arrangeSelectedEvents]) {
        SVClipboardEvent piece; piece.source = s;
        if (s.midi) {
            if (s.track >= p.midiTracks.size()) continue;
            const auto& parts = p.midiTracks[s.track].parts;
            auto it = std::find_if(parts.begin(), parts.end(), [&](const MidiPart& part) { return part.id == s.id; });
            if (it == parts.end()) continue;
            piece.part = *it;
            piece.offsetSamples = p.tempoMap.sampleAtQuarterNotes(it->timelineStartQuarterNotes);
        } else {
            if (s.track >= p.tracks.size()) continue;
            const auto& clips = p.tracks[s.track].clips;
            auto it = std::find_if(clips.begin(), clips.end(), [&](const ProjectAudioClip& clip) { return clip.id == s.id; });
            if (it == clips.end()) continue;
            piece.clip = *it;
            piece.offsetSamples = it->timelineStartSample;
        }
        earliest = std::min(earliest, piece.offsetSamples);
        _objectClipboard.push_back(std::move(piece));
    }
    if (_objectClipboard.empty()) return;
    for (auto& piece : _objectClipboard) piece.offsetSamples -= earliest;
    _clipboardValid = NO;
    _rangeClip.clear(); _rangeClipLength = 0;
    _rangeClipboard = RangeClipboard {};
    [self setStatus:[NSString stringWithFormat:@"Copied %lu audio/MIDI events", (unsigned long)_objectClipboard.size()]];
}
- (void)pasteArrangeEvents {
    if (_objectClipboard.empty() || !_core) return;
    const auto pieces = _objectClipboard;
    const std::int64_t at = self.playheadSample;
    __block std::vector<SVSelectedEvent> created;
    [self runClipEdit:@"Paste Selected Events" block:^{
        Project& p = self->_core->project();
        for (const auto& piece : pieces) {
            const std::int64_t dest = std::max<std::int64_t>(0, at + piece.offsetSamples);
            if (piece.source.midi) {
                if (piece.source.track >= p.midiTracks.size()) continue;
                MidiPart part = piece.part;
                part.id = 0;
                part.timelineStartQuarterNotes = p.tempoMap.quarterNotesAtSample(dest);
                MidiPartEditor editor(p.midiTracks[piece.source.track].parts);
                try { const auto id = editor.add(std::move(part)); created.push_back({true, piece.source.track, id}); } catch (...) {}
            } else {
                if (piece.source.track >= p.tracks.size() || p.tracks[piece.source.track].locked) continue;
                ProjectAudioClip clip = piece.clip;
                clip.id = 0;
                clip.timelineStartSample = dest;
                try { ClipEditor editor(p, piece.source.track); const auto id = editor.addClip(std::move(clip)); created.push_back({false, piece.source.track, id}); } catch (...) {}
            }
        }
    }];
    [_arrange setSelectedEvents:created];
    [self republishMidi];
}
// Duplicate at the SAME time position for Option-drag, then move the copies as one gesture.
// Calling this outside a gesture places the copies after the last selected object.
- (void)duplicateArrangeEvents {
    if (!_core) return;
    const auto selected = [self arrangeSelectedEvents];
    if (selected.empty()) return;
    const bool inGesture = _gestureOpen;
    const Project& before = _core->project();
    std::int64_t lo = std::numeric_limits<std::int64_t>::max(), hi = 0;
    for (const auto& s : selected) {
        if (s.midi) {
            if (s.track >= before.midiTracks.size()) continue;
            for (const auto& part : before.midiTracks[s.track].parts) if (part.id == s.id) {
                lo = std::min(lo, before.tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes));
                hi = std::max(hi, before.tempoMap.sampleAtQuarterNotes(part.timelineStartQuarterNotes + part.lengthQuarterNotes));
            }
        } else if (s.track < before.tracks.size()) {
            for (const auto& clip : before.tracks[s.track].clips) if (clip.id == s.id) {
                lo = std::min(lo, clip.timelineStartSample);
                hi = std::max(hi, clip.timelineStartSample + static_cast<std::int64_t>(clip.lengthSamples));
            }
        }
    }
    const std::int64_t shift = inGesture || lo == std::numeric_limits<std::int64_t>::max() ? 0 : std::max<std::int64_t>(1, hi - lo);
    __block std::vector<SVSelectedEvent> created;
    [self runClipEdit:@"Duplicate Selected Events" block:^{
        Project& p = self->_core->project();
        for (const auto& s : selected) {
            if (s.midi) {
                if (s.track >= p.midiTracks.size()) continue;
                auto& parts = p.midiTracks[s.track].parts;
                const auto it = std::find_if(parts.begin(), parts.end(), [&](const MidiPart& part){return part.id == s.id;});
                if (it == parts.end()) continue;
                const auto start = p.tempoMap.sampleAtQuarterNotes(it->timelineStartQuarterNotes);
                MidiPartEditor e(parts);
                try { const auto id = e.duplicate(s.id, p.tempoMap.quarterNotesAtSample(start + shift)); created.push_back({true,s.track,id}); } catch (...) {}
            } else {
                if (s.track >= p.tracks.size() || p.tracks[s.track].locked) continue;
                auto& clips = p.tracks[s.track].clips;
                const auto it = std::find_if(clips.begin(), clips.end(), [&](const ProjectAudioClip& clip){return clip.id == s.id;});
                if (it == clips.end()) continue;
                const auto start = it->timelineStartSample;
                ClipEditor e(p,s.track);
                try { const auto id = e.duplicateClip(s.id, start + shift); created.push_back({false,s.track,id}); } catch (...) {}
            }
        }
    }];
    [_arrange setSelectedEvents:created];
    [self republishMidi];
}
// Positions are always derived from the mouse-down snapshot to prevent drift and jitter.
// Snap is applied once to the reference pointer, not independently to each event.
- (void)moveArrangeEvents:(const std::vector<SVEventMoveOrigin>&)origins deltaSamples:(std::int64_t)delta {
    if (!_core) return;
    Project& p = _core->project();
    bool changed = false, changedMidi = false;
    for (const auto& origin : origins) {
        const auto& s = origin.event;
        const auto pos = std::max<std::int64_t>(0, origin.startSample + delta);
        if (s.midi) {
            if (s.track >= p.midiTracks.size()) continue;
            MidiPartEditor e(p.midiTracks[s.track].parts);
            try { if (e.move(s.id, p.tempoMap.quarterNotesAtSample(pos))) { changed = changedMidi = true; } } catch (...) {}
        } else if (s.track < p.tracks.size() && !p.tracks[s.track].locked) {
            try { ClipEditor e(p, s.track); e.moveClip(s.id, pos); changed = true; } catch (...) {}
        }
    }
    if (changed) {
        _core->session().markDirty();
        if (_gestureOpen) _gestureNeedsClipRefresh = YES; else [self requestClipRefresh];
        if (changedMidi) [self republishMidi];
        [_arrange setNeedsDisplay:YES];
    }
}

// ================================================================= clips ==
- (void)dragClip:(std::uint64_t)clipId track:(std::size_t)track toSample:(std::int64_t)sample {
    Project& p = _core->project();
    if (track >= p.tracks.size() || p.tracks[track].locked) return;
    try {
        ClipEditor editor(p, track);
        editor.moveClip(clipId, sample, [self clipSnap]);
        _core->session().markDirty();
        _gestureNeedsClipRefresh = YES;
    } catch (...) {}
}

- (void)dragClipEdge:(std::uint64_t)clipId track:(std::size_t)track leftEdge:(BOOL)left toSample:(std::int64_t)sample {
    Project& p = _core->project();
    if (track >= p.tracks.size() || p.tracks[track].locked) return;
    try {
        ClipEditor editor(p, track);
        if (left) editor.trimLeft(clipId, sample, [self clipSnap]);
        else editor.trimRight(clipId, sample, [self clipSnap]);
        _core->session().markDirty();
        _gestureNeedsClipRefresh = YES;
    } catch (...) {}
}

- (ProjectAudioClip*)editedClip {
    if (!_core || self.selectedTrack < 0 || self.selectedClipId == 0) return nullptr;
    Project& p = _core->project();
    if (self.selectedTrack >= static_cast<long>(p.tracks.size())) return nullptr;
    for (auto& c : p.tracks[static_cast<std::size_t>(self.selectedTrack)].clips) if (c.id == self.selectedClipId) return &c;
    return nullptr;
}

- (void)clipEdit:(NSString*)label op:(void (^)(ClipEditor& editor))op {
    if (self.selectedTrack < 0 || ![self editedClip]) return;
    if (_core->project().tracks[static_cast<std::size_t>(self.selectedTrack)].locked) { [self showError:label detail:"The track is locked."]; return; }
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    [self runClipEdit:label block:^{
        ClipEditor editor(self->_core->project(), track);
        op(editor);
    }];
}

- (void)splitAtPlayhead:(id)sender {
    (void)sender;
    if ([self keyEditorActive]) { [self keySplitAtCursor:nil]; return; }
    const auto at = self.playheadSample;
    const std::uint64_t id = self.selectedClipId;
    if (id) { [self clipEdit:@"Split" op:^(ClipEditor& e) { self.selectedClipId = e.splitClip(id, at, ClipSnapSettings {}); }]; return; }
    if (self.selectedMidiTrack >= 0 && self.selectedPartId) {
        const auto t = static_cast<std::size_t>(self.selectedMidiTrack);
        const double q = _core->project().tempoMap.quarterNotesAtSample(at);
        const std::uint64_t part = self.selectedPartId;
        [self runEdit:@"Split Part" rebuild:NO block:^{ MidiPartEditor ed(self->_core->project().midiTracks[t].parts); self.selectedPartId = ed.split(part, q); }];
        [self republishMidi];
    }
}
- (void)deleteSelection:(id)sender {
    (void)sender;
    if ([self keyEditorActive]) { [self keyDelete]; return; }   // notes, never the part
    if ([self toneEditorActive]) { [self toneDeleteSelected:nil]; return; }   // the Tone Editor removes tone blocks, never the clip
    if ([self sampleEditorActive]) { [self sampleDelete:nil]; return; }   // the part that is selected, never the whole clip
    if (![self editorFocused] && [_arrange deleteSelectedAutomationPoint]) return;   // a selected automation point
    if (![self editorFocused] && [_arrange deleteSelectedTempoPoint]) return;        // a selected tempo change
    if ([self arrangeRangeActive]) { [self rangeDelete:nil]; return; }    // the marked range of the tracks, not the clip
    if (![self arrangeSelectedEvents].empty()) { [self deleteArrangeEvents]; return; }
    if (self.selectedClipId) {
        const std::uint64_t id = self.selectedClipId;
        [self clipEdit:@"Delete Clip" op:^(ClipEditor& e) { e.removeClip(id); }];
        self.selectedClipId = 0;
    } else if (self.selectedMidiTrack >= 0 && self.selectedPartId) {
        const auto t = static_cast<std::size_t>(self.selectedMidiTrack);
        const std::uint64_t part = self.selectedPartId;
        [self runEdit:@"Delete Part" rebuild:NO block:^{ MidiPartEditor ed(self->_core->project().midiTracks[t].parts); (void)ed.remove(part); }];
        self.selectedPartId = 0;
        [self republishMidi];
    }
    [self refreshAll];
}
- (void)copyClip:(id)sender {
    (void)sender;
    if ([self keyEditorActive]) { [self keyCopy]; return; }
    if ([self sampleEditorActive] && [self sampleSelection].valid()) { [self sampleCopy:nil]; return; }
    if ([self arrangeRangeActive]) { [self rangeCopy:nil]; return; }
    if (![self arrangeSelectedEvents].empty()) { [self copyArrangeEvents]; return; }
    if (ProjectAudioClip* c = [self editedClip]) {
        _clipboard = *c; _clipboard.id = 0; _clipboardValid = YES; _objectClipboard.clear(); _rangeClipboard = RangeClipboard {};
        [self setStatus:@"Clip copied"];
    }
}
- (void)cutClip:(id)sender {
    (void)sender;
    if ([self keyEditorActive]) { [self keyCut]; return; }
    if ([self toneEditorActive]) { [self setStatus:@"Cut, copy and paste work on the waveform — switch to WAVE to use them"]; return; }
    if ([self sampleEditorActive]) { [self sampleCut:nil]; return; }
    if ([self arrangeRangeActive]) { [self rangeCut:nil]; return; }
    if (![self arrangeSelectedEvents].empty()) { [self copyArrangeEvents]; [self deleteArrangeEvents]; return; }
    if ([self editedClip]) { [self copyClip:nil]; [self deleteSelection:nil]; }
}
- (void)pasteClip:(id)sender {
    (void)sender;
    if ([self keyEditorActive]) { [self keyPaste]; return; }
    if ([self toneEditorActive]) { [self setStatus:@"Cut, copy and paste work on the waveform — switch to WAVE to use them"]; return; }
    if ([self sampleEditorActive] && !_rangeClipboard.empty()) { [self samplePaste:nil]; return; }
    if (![self editorFocused] && [self rangeClipboardFull]) { [self rangePaste:nil]; return; }   // a copied range of the tracks
    if (!_objectClipboard.empty() && ![self editorFocused]) { [self pasteArrangeEvents]; return; }
    if (!_clipboardValid) return;
    const ProjectAudioClip clip = _clipboard;
    const std::int64_t at = self.playheadSample;
    [self runClipEdit:@"Paste Clip" block:^{
        Project& p = self->_core->project();
        if (self.selectedTrack < 0 || self.selectedTrack >= static_cast<long>(p.tracks.size())) {
            ProjectTrack t;
            t.name = sv::str([[sv::ns(clip.audioPath) lastPathComponent] stringByDeletingPathExtension]);
            p.addTrack(std::move(t));
            self.selectedTrack = static_cast<long>(p.tracks.size()) - 1;
        }
        ClipEditor e(p, static_cast<std::size_t>(self.selectedTrack));
        ProjectAudioClip c = clip;
        c.timelineStartSample = at;
        self.selectedClipId = e.addClip(std::move(c), [self clipSnap]);
    }];
}
- (void)duplicateClip:(id)sender {
    (void)sender;
    if ([self keyEditorActive]) { [self keyDuplicate]; return; }
    if ([self toneEditorActive]) { [self setStatus:@"Duplicate works on the waveform — switch to WAVE to use it"]; return; }
    if ([self sampleEditorActive] && [self sampleSelection].valid()) { [self sampleDuplicate:nil]; return; }
    if (![self arrangeSelectedEvents].empty()) { [self duplicateArrangeEvents]; return; }
    ProjectAudioClip* c = [self editedClip];
    if (!c) return;
    const std::int64_t dest = c->timelineStartSample + static_cast<std::int64_t>(c->lengthSamples);
    const std::uint64_t id = c->id;
    [self clipEdit:@"Duplicate Clip" op:^(ClipEditor& e) { self.selectedClipId = e.duplicateClip(id, dest, [self clipSnap]); }];
}
- (void)toggleClipMute:(id)sender {
    (void)sender;
    if ([self keyEditorActive]) { [self keyMuteNotes:nil]; return; }
    if (MidiPart* part = [self editedPart]) {
        if (self.selectedMidiTrack < 0) return;
        const auto t = static_cast<std::size_t>(self.selectedMidiTrack);
        const std::uint64_t id = part->id;
        const bool m = !part->muted;
        [self runEdit:@"Mute Part" rebuild:NO block:^{ MidiPartEditor ed(self->_core->project().midiTracks[t].parts); (void)ed.setMuted(id, m); }];
        [self republishMidi];
        return;
    }
    ProjectAudioClip* c = [self editedClip];
    if (!c) return;
    const bool m = !c->mute;
    const std::uint64_t id = c->id;
    [self clipEdit:@"Mute Clip" op:^(ClipEditor& e) { e.setMute(id, m); }];
}
- (void)clipFades:(id)sender {
    (void)sender;
    ProjectAudioClip* c = [self editedClip];
    if (!c) { [self showError:@"Clip Fades" detail:"Select an audio clip first."]; return; }
    const double sr = _core->project().sampleRate;
    const double clipMs = std::max(1.0, std::floor(static_cast<double>(c->lengthSamples) * 1000.0 / sr));
    SVDialog* d = [SVDialog dialogWithTitle:@"Clip Fades"
                                   subtitle:@"Soft start and soft end of this clip. The audio file itself is not changed and you can change the fades again at any time."
                                    okTitle:@"Apply"];
    NSArray<NSNumber*>* quick = @[@0, @10, @50, @100, @500];
    const NSInteger fi = [d addNumber:@"Fade in" unit:@"ms" min:0.0 max:clipMs value:std::min(clipMs, std::round(c->fadeInSamples * 1000.0 / sr)) decimals:0 presets:quick];
    const NSInteger fo = [d addNumber:@"Fade out" unit:@"ms" min:0.0 max:clipMs value:std::min(clipMs, std::round(c->fadeOutSamples * 1000.0 / sr)) decimals:0 presets:quick];
    [d setNote:^NSString*(SVDialog* dlg) {
        if ([dlg numberAt:fi] + [dlg numberAt:fo] > clipMs) return [NSString stringWithFormat:@"The two fades together are longer than the clip (%.0f ms) — they will overlap.", clipMs];
        return [NSString stringWithFormat:@"The clip is %.0f ms long.", clipMs];
    }];
    if (![d run]) return;
    const auto fadeIn = static_cast<std::uint64_t>([d numberAt:fi] * sr / 1000.0);
    const auto fadeOut = static_cast<std::uint64_t>([d numberAt:fo] * sr / 1000.0);
    const std::uint64_t id = c->id, len = c->lengthSamples;
    [self clipEdit:@"Clip Fades" op:^(ClipEditor& e) { e.setFades(id, std::min(fadeIn, len), std::min(fadeOut, len)); }];
}
- (void)clipGain:(id)sender {
    (void)sender;
    ProjectAudioClip* c = [self editedClip];
    if (!c) { [self showError:@"Clip Gain" detail:"Select an audio clip first."]; return; }
    SVDialog* d = [SVDialog dialogWithTitle:@"Clip Gain"
                                   subtitle:@"The volume of this clip. The audio file is not changed — you can come back and change it again."
                                    okTitle:@"Apply"];
    const NSInteger gain = [d addNumber:@"Clip gain" unit:@"dB" min:-60.0 max:12.0 value:c->gainDb decimals:1 presets:@[@-12, @-6, @-3, @0, @3, @6]];
    [d setNote:^NSString*(SVDialog* dlg) {
        const double db = [dlg numberAt:gain];
        return [NSString stringWithFormat:@"Volume × %.2f.", std::pow(10.0, db / 20.0)];
    }];
    if (![d run]) return;
    const float g = static_cast<float>([d numberAt:gain]);
    const std::uint64_t id = c->id;
    [self clipEdit:@"Clip Gain" op:^(ClipEditor& e) { e.setGainDb(id, g); }];
}

// ============================================================== MIDI parts ==
- (void)dragPart:(std::uint64_t)partId midiTrack:(std::size_t)track toQuarter:(double)quarter {
    Project& p = _core->project();
    if (track >= p.midiTracks.size()) return;
    MidiPartEditor ed(p.midiTracks[track].parts);
    if (ed.move(partId, quarter)) { _core->session().markDirty(); [self republishMidi]; }
}

- (void)createPartForMidiTrack:(std::size_t)track atSample:(std::int64_t)sample {
    const auto pos = _core->project().tempoMap.positionAtSample(sample);
    const double barLen = pos.numerator * 4.0 / pos.denominator;
    [self runEdit:@"Create MIDI Part" rebuild:NO block:^{
        auto& mt = self->_core->project().midiTracks.at(track);
        self.selectedPartId = MidiTrackTools::addEmptyPart(mt, pos.barStartQuarterNotes, barLen);
        self.selectedMidiTrack = static_cast<long>(track);
    }];
    [self republishMidi];
    [self openEditor:nil];
}

- (void)duplicatePart:(id)sender {
    (void)sender;
    if (self.selectedMidiTrack < 0 || !self.selectedPartId) return;
    const auto t = static_cast<std::size_t>(self.selectedMidiTrack);
    const std::uint64_t part = self.selectedPartId;
    [self runEdit:@"Duplicate Part" rebuild:NO block:^{
        auto& parts = self->_core->project().midiTracks[t].parts;
        for (const auto& pr : parts) if (pr.id == part) {
            MidiPartEditor ed(parts);
            self.selectedPartId = ed.duplicate(part, pr.timelineStartQuarterNotes + pr.lengthQuarterNotes);
            break;
        }
    }];
    [self republishMidi];
}

// Moves the selected audio clip or MIDI part by one grid step (the grid setting of the Arrange page).
- (void)nudgeSelectionBy:(int)direction {
    if (!_core || !_core->ready()) return;
    const double step = 1.0 / static_cast<double>(std::max<std::uint32_t>(1U, _gridDiv));
    const TempoMap map = _core->project().tempoMap;
    if (ProjectAudioClip* c = [self editedClip]) {
        const std::uint64_t id = c->id;
        const double q = std::max(0.0, map.quarterNotesAtSample(c->timelineStartSample) + direction * step);
        const std::int64_t target = map.sampleAtQuarterNotes(q);
        [self clipEdit:@"Nudge Clip" op:^(ClipEditor& e) { e.moveClip(id, target, [self clipSnap]); }];
        return;
    }
    if (MidiPart* part = [self editedPart]) {
        if (self.selectedMidiTrack < 0) return;
        const auto t = static_cast<std::size_t>(self.selectedMidiTrack);
        const std::uint64_t id = part->id;
        const double to = std::max(0.0, part->timelineStartQuarterNotes + direction * step);
        [self runEdit:@"Nudge Part" rebuild:NO block:^{
            MidiPartEditor ed(self->_core->project().midiTracks[t].parts);
            (void)ed.move(id, to);
        }];
        [self republishMidi];
        return;
    }
    [self setStatus:@"Select an audio clip or a MIDI part to nudge it"];
}
- (void)nudgeLeft:(id)sender { (void)sender; [self nudgeSelectionBy:-1]; }
- (void)nudgeRight:(id)sender { (void)sender; [self nudgeSelectionBy:1]; }

// Double-click on a clip / part, Enter, or "Open in … Editor": the editor opens under the tracks, so the whole
// project stays visible. The EDIT key on the side bar (F4) shows the same editor on a full page.
- (void)openEditor:(id)sender {
    (void)sender;
    [self showEditorInZone];
}

- (MidiPart*)editedPart {
    if (!_core || self.selectedMidiTrack < 0 || self.selectedMidiTrack >= static_cast<long>(_core->project().midiTracks.size())) return nullptr;
    return MidiTrackTools::findPart(_core->project().midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)], self.selectedPartId);
}
- (MidiSequence*)editedSequence {
    if (!_core || self.selectedMidiTrack < 0 || self.selectedMidiTrack >= static_cast<long>(_core->project().midiTracks.size())) return nullptr;
    auto& mt = _core->project().midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)];
    if (MidiPart* p = [self editedPart]) return &p->sequence;
    if (mt.parts.empty()) return &mt.sequence;
    return nullptr;
}
- (double)editedPartOffsetQuarterNotes {
    if (MidiPart* p = [self editedPart]) return p->timelineStartQuarterNotes - p->sourceOffsetQuarterNotes;
    return 0.0;
}

- (void)noteEdit:(NSString*)label op:(void (^)(MidiSequence& seq))op {
    MidiSequence* seq = [self editedSequence];
    if (!seq) return;
    MidiSequence* target = seq;
    [self runEdit:label rebuild:NO block:^{ op(*target); }];
    [self republishMidi];
    [_noteGrid setNeedsDisplay:YES];
}

- (MidiFunctions::Selection)noteSelection {
    return [_noteGrid selection];   // empty = all notes of the part
}
- (void)midiQuantize:(id)sender {
    (void)sender;
    const QuantizeSettings q = SVQuantizeState.shared->settings;
    const auto sel = [self noteSelection];
    [self noteEdit:@"Quantize" op:^(MidiSequence& s) { (void)Quantizer::apply(s, q, sel); }];
}
- (void)midiQuantizeSetup:(id)sender { [self showQuantizePanel:sender]; }
- (void)midiQuantizeLength:(id)sender {
    (void)sender;
    QuantizeSettings q = SVQuantizeState.shared->settings;
    q.quantizeStart = false; q.quantizeEnd = false; q.quantizeLength = true;
    const auto sel = [self noteSelection];
    [self noteEdit:@"Quantize Length" op:^(MidiSequence& s) { (void)Quantizer::apply(s, q, sel); }];
}
- (void)midiGrooveApply:(id)sender {
    (void)sender;
    SVQuantizeState* st = SVQuantizeState.shared;
    if (st->groove.offsetQuarterNotes.empty()) { [self showError:@"Groove Quantize" detail:"Pick a groove in the Quantize Panel (or extract one from a part) first."]; return; }
    const GrooveTemplate g = st->groove;
    const double timing = st->grooveTiming, velocity = st->grooveVelocity;
    const auto sel = [self noteSelection];
    [self noteEdit:@"Groove Quantize" op:^(MidiSequence& s) { (void)Quantizer::applyGroove(s, g, timing, velocity, sel); }];
}
- (void)midiGrooveExtract:(id)sender {
    (void)sender;
    MidiSequence* seq = [self editedSequence];
    if (!seq || seq->notes().empty()) { [self showError:@"Extract Groove" detail:"Open a MIDI part that contains notes first."]; return; }
    SVQuantizeState* st = SVQuantizeState.shared;
    const double grid = Quantizer::effectiveGrid(st->settings);
    st->groove = Quantizer::extractGroove(*seq, grid, std::max(4.0, grid), [self noteSelection]);
    st->groove.name = "Extracted groove";
    [self setStatus:@"Groove extracted from the part"];
}
- (void)audioQuantize:(id)sender {
    (void)sender;
    ProjectAudioClip* c = [self editedClip];
    if (!c) { [self showError:@"Audio Quantize" detail:"Select an audio clip first."]; return; }
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    if (_core->project().tracks[track].locked) { [self showError:@"Audio Quantize" detail:"The track is locked."]; return; }
    const std::uint64_t id = c->id;
    SVQuantizeState* st = SVQuantizeState.shared;
    const QuantizeSettings q = st->settings;
    const AudioQuantizeOptions o = st->audio;
    __block std::size_t slices = 0U;
    [self runEdit:@"Audio Quantize" rebuild:YES block:^{ slices = AudioQuantizer::quantizeClip(self->_core->project(), track, id, q, o); }];
    [self setStatus:slices ? [NSString stringWithFormat:@"Audio quantized: %zu slices moved to the grid", slices] : @"No transients found in the clip"];
}
- (void)midiQuantizeSoft:(id)sender {
    (void)sender;
    const double grid = 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
    const double swing = SVQuantizeState.shared->settings.swing;   // the swing of Quantize Setup
    [self noteEdit:@"Iterative Quantize" op:^(MidiSequence& s) { (void)MidiFunctions::quantize(s, grid, swing, 0.5, false); }];
}
- (void)midiQuantizeEnds:(id)sender {
    (void)sender;
    const double grid = 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
    [self noteEdit:@"Quantize Ends" op:^(MidiSequence& s) { (void)MidiFunctions::quantize(s, grid, 0.0, 1.0, true); }];
}
- (void)midiLegato:(id)sender { (void)sender; [self noteEdit:@"Legato" op:^(MidiSequence& s) { (void)MidiFunctions::legato(s); }]; }
- (void)midiFixedLength:(id)sender {
    (void)sender;
    const double len = 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
    const auto sel = [self noteSelection];
    [self noteEdit:@"Fixed Length" op:^(MidiSequence& s) { (void)MidiFunctions::fixedLength(s, len, sel); }];
}
- (void)midiVelocity:(id)sender {
    (void)sender;
    NSString* v = [self promptText:@"Velocity" message:@"scale × and offset ±, e.g. 1.0, +10  (or a single fixed value like 96)" initial:@"1.0, 0"];
    if (!v) return;
    const auto sel = [self noteSelection];
    NSArray<NSString*>* parts = [v componentsSeparatedByString:@","];
    if (parts.count == 1) {
        const int fixed = std::clamp(v.intValue, 1, 127);
        [self noteEdit:@"Fixed Velocity" op:^(MidiSequence& s) { (void)MidiFunctions::fixedVelocity(s, static_cast<std::uint8_t>(fixed), sel); }];
    } else {
        const double scale = parts[0].doubleValue;
        const int offset = parts[1].intValue;
        [self noteEdit:@"Scale Velocity" op:^(MidiSequence& s) { (void)MidiFunctions::scaleVelocity(s, scale, offset, sel); }];
    }
}
- (void)midiCompress:(id)sender { (void)sender; [self noteEdit:@"Compress Velocity" op:^(MidiSequence& s) { (void)MidiFunctions::compressVelocity(s, 0.5); }]; }
- (void)midiHumanize:(id)sender {
    (void)sender;
    const auto seed = static_cast<std::uint32_t>(_tick * 2654435761U);
    [self noteEdit:@"Humanize" op:^(MidiSequence& s) { (void)MidiFunctions::humanize(s, 0.015, 8, seed); }];
}
- (void)midiDeleteDoubles:(id)sender { (void)sender; [self noteEdit:@"Delete Doubles" op:^(MidiSequence& s) { (void)MidiFunctions::deleteDoubles(s); (void)MidiFunctions::deleteOverlaps(s); }]; }
- (void)midiTranspose:(int)semis {
    const auto sel = [self noteSelection];
    [self noteEdit:@"Transpose" op:^(MidiSequence& s) {
        for (const auto& n : std::vector<MusicalMidiNote>(s.notes()))
            if (sel.empty() || std::find(sel.begin(), sel.end(), n.id) != sel.end())
                (void)s.setNotePitch(n.id, static_cast<std::uint8_t>(std::clamp(static_cast<int>(n.pitch) + semis, 0, 127)));
    }];
}
- (void)midiUp:(id)sender { (void)sender; [self midiTranspose:1]; }
- (void)midiDown:(id)sender { (void)sender; [self midiTranspose:-1]; }
- (void)midiOctaveUp:(id)sender { (void)sender; [self midiTranspose:12]; }
- (void)midiOctaveDown:(id)sender { (void)sender; [self midiTranspose:-12]; }
- (void)midiRetrograde:(id)sender {
    (void)sender;
    MidiPart* part = [self editedPart];
    const double a = part ? part->sourceOffsetQuarterNotes : 0.0;
    double b = part ? a + part->lengthQuarterNotes : 0.0;
    if (!part) if (MidiSequence* s = [self editedSequence]) for (const auto& n : s->notes()) b = std::max(b, n.startQuarterNotes + n.durationQuarterNotes);
    if (b <= a) return;
    [self noteEdit:@"Retrograde" op:^(MidiSequence& s) { (void)MidiFunctions::reverse(s, a, b); }];
}
- (void)midiInvert:(id)sender { (void)sender; [self noteEdit:@"Invert" op:^(MidiSequence& s) { (void)MidiFunctions::invert(s, 66); }]; }

// ========================================================= audio process ==
// The Process windows float over the project: the user marks tracks (click a header, ⌘-click
// adds, ⇧-click a range, ⌘A everything) and clips while the window is open, the note under the
// controls follows, Apply works on all of it. Nothing is chosen inside the window itself.

// What a process will work on right now: every clip of the marked tracks, plus the marked clips of
// other tracks; with nothing marked, the selected clip, or every clip of the selected track.
- (std::vector<std::pair<std::size_t, std::uint64_t>>)processTargets {
    std::vector<std::pair<std::size_t, std::uint64_t>> out;
    if (!_core) return out;
    const Project& p = _core->project();
    std::set<std::size_t> wholeTracks;
    for (std::size_t t : [self markedTracks]) wholeTracks.insert(t);
    std::set<std::pair<std::size_t, std::uint64_t>> picked;
    for (const SVSelectedEvent& e : [self arrangeSelectedEvents]) if (!e.midi && e.id && e.track < p.tracks.size()) picked.insert({e.track, e.id});
    if (wholeTracks.empty() && picked.empty()) {
        if (self.selectedTrack >= 0 && static_cast<std::size_t>(self.selectedTrack) < p.tracks.size()) {
            if (self.selectedClipId) picked.insert({static_cast<std::size_t>(self.selectedTrack), self.selectedClipId});
            else wholeTracks.insert(static_cast<std::size_t>(self.selectedTrack));
        }
    }
    for (std::size_t t : wholeTracks) {
        if (t >= p.tracks.size() || p.tracks[t].locked) continue;
        for (const auto& c : p.tracks[t].clips) picked.insert({t, c.id});
    }
    for (const auto& pc : picked) if (pc.first < p.tracks.size() && !p.tracks[pc.first].locked) out.push_back(pc);
    return out;
}

- (NSString*)processTargetsText:(SVDialog*)d partRow:(NSInteger)partRow {
    if (partRow >= 0 && [d checkAt:partRow])
        return [NSString stringWithFormat:@"Applies to the selected part in the Editor (%@).", [self sampleDurationText:[self sampleSelection].length()]];
    const auto targets = [self processTargets];
    if (targets.empty()) return @"Nothing is marked: click a track or a clip in the project (⌘-click adds a track, ⌘A takes everything).";
    const Project& p = _core->project();
    std::set<std::size_t> tracks;
    std::int64_t total = 0;
    for (const auto& tg : targets) {
        tracks.insert(tg.first);
        for (const auto& c : p.tracks[tg.first].clips) if (c.id == tg.second) total += static_cast<std::int64_t>(c.lengthSamples);
    }
    NSMutableString* names = [NSMutableString string];
    int shown = 0;
    for (std::size_t t : tracks) {
        if (shown == 4) { [names appendString:@", …"]; break; }
        [names appendFormat:@"%@%lu", shown ? @", " : @"", (unsigned long)(t + 1)];
        ++shown;
    }
    return [NSString stringWithFormat:@"Applies to %lu clip%s on track%s %@ (%@ of sound). Mark other tracks or clips in the project while this window is open.",
            (unsigned long)targets.size(), targets.size() == 1U ? "" : "s", tracks.size() == 1U ? "" : "s", names, [self sampleDurationText:total]];
}

// The one choice a process window keeps: only the part selected in the Editor (when there is one).
- (NSInteger)addProcessPartTickTo:(SVDialog*)d {
    if ([self sampleEditorActive] && [self sampleSelection].valid())
        return [d addCheck:[NSString stringWithFormat:@"Only the part selected in the Editor (%@)", [self sampleDurationText:[self sampleSelection].length()]] on:YES];
    return -1;
}

// Shows a process window beside the project. `apply` runs when OK is pressed, with the window still
// holding its values; it is not called on Cancel.
- (void)showProcessDialog:(SVDialog*)d partRow:(NSInteger)partRow process:(AudioProcess)process apply:(AudioProcessOptions (^)(SVDialog* dlg))apply {
    _processDialog = d;
    __weak SilvetonController* weakSelf = self;
    [d runWithCompletion:^(BOOL ok) {
        SilvetonController* me = weakSelf;
        if (!me) return;
        me->_processDialog = nil;
        if (!ok) return;
        const AudioProcessOptions options = apply(d);
        [me runProcess:process options:options onlyPart:(partRow >= 0 && [d checkAt:partRow])];
    }];
}

// Runs the process on everything that is marked: one undo step, a progress window when it is more
// than one clip. New files are written for the processed clips (the originals stay as they are).
- (void)runProcess:(AudioProcess)process options:(AudioProcessOptions)options onlyPart:(BOOL)onlyPart {
    if (onlyPart) { (void)[self runRangeProcess:process options:options]; return; }
    const auto targets = [self processTargets];
    if (targets.empty()) { [self showError:sv::ns(AudioProcessor::name(process)) detail:"Mark a track or a clip in the project first (locked tracks are left alone)."]; return; }
    std::string dir;
    try { dir = sv::processedMediaDirectory(); } catch (const std::exception& e) { [self showError:@"Audio Process" detail:e.what()]; return; }
    SVProgress* progress = targets.size() > 1U ? [SVProgress progressWithTitle:sv::ns(AudioProcessor::name(process))] : nil;
    if (progress) { progress.parts = static_cast<NSInteger>(targets.size()); progress.partNoun = @"Clip"; [progress begin]; }
    __block std::vector<std::string> newPaths;
    __block std::size_t done = 0U;
    __block bool cancelled = false;
    [self runEdit:sv::ns(AudioProcessor::name(process)) rebuild:YES block:^{
        for (const auto& tg : targets) {
            if (progress && ![progress updateFraction:static_cast<double>(done) / static_cast<double>(targets.size())]) { cancelled = true; break; }
            const std::string path = AudioProcessor::processClip(self->_core->project(), tg.first, tg.second, process, options, dir).newPath;
            if (!path.empty()) newPaths.push_back(path);
            ++done;
        }
    }];
    if (progress) [progress end];
    for (const auto& path : newPaths) _core->waveformCache().request(path);
    [self setStatus:[NSString stringWithFormat:@"%s applied to %lu clip%s%@", AudioProcessor::name(process), (unsigned long)done, done == 1U ? "" : "s",
                     cancelled ? @" (stopped — the clips done so far keep the change)" : @""]];
}

// Reverse, Invert Phase, Remove DC, Silence, Mono Sum, Stereo Flip: no settings, only what is marked.
- (void)runSimpleProcess:(AudioProcess)process title:(NSString*)title subtitle:(NSString*)subtitle {
    if (![self requireProcessTarget:title]) return;
    if (_processDialog && [_processDialog isOpen]) { [_processDialog bringToFront]; return; }
    SVDialog* d = [SVDialog dialogWithTitle:title subtitle:subtitle okTitle:@"Apply"];
    const NSInteger part = [self addProcessPartTickTo:d];
    [d setNote:^NSString*(SVDialog* dlg) { return [self processTargetsText:dlg partRow:part]; }];
    [self showProcessDialog:d partRow:part process:process apply:^AudioProcessOptions(SVDialog* dlg) { (void)dlg; return AudioProcessOptions {}; }];
}

- (void)processNormalize:(id)sender {
    (void)sender;
    if (![self requireProcessTarget:@"Normalize"]) return;
    if (_processDialog && [_processDialog isOpen]) { [_processDialog bringToFront]; return; }
    static double lastTarget = -0.3;   // the level of the last Normalize is offered again
    SVDialog* d = [SVDialog dialogWithTitle:@"Normalize"
                                   subtitle:@"Raises or lowers the sound so that its loudest peak reaches the level you choose. The sound itself is not changed, only made louder or quieter."
                                    okTitle:@"Normalize"];
    const NSInteger level = [d addNumber:@"Maximum level" unit:@"dBFS" min:-60.0 max:0.0 value:lastTarget decimals:1
                                 presets:@[@0, @-0.3, @-1, @-3, @-6, @-10]];
    const NSInteger part = [self addProcessPartTickTo:d];
    [d setNote:^NSString*(SVDialog* dlg) {
        return [NSString stringWithFormat:@"The loudest peak will reach %.1f dBFS (0 = the loudest possible level).\n%@", [dlg numberAt:level], [self processTargetsText:dlg partRow:part]];
    }];
    [self showProcessDialog:d partRow:part process:AudioProcess::Normalize apply:^AudioProcessOptions(SVDialog* dlg) {
        lastTarget = [dlg numberAt:level];
        AudioProcessOptions o;
        o.normalizeTargetDb = lastTarget;
        return o;
    }];
}
- (void)processGain:(id)sender {
    (void)sender;
    if (![self requireProcessTarget:@"Gain"]) return;
    if (_processDialog && [_processDialog isOpen]) { [_processDialog bringToFront]; return; }
    static double lastGain = -3.0;
    SVDialog* d = [SVDialog dialogWithTitle:@"Gain" subtitle:@"Makes the sound louder or quieter by a fixed amount." okTitle:@"Apply"];
    const NSInteger amount = [d addNumber:@"Change" unit:@"dB" min:-60.0 max:24.0 value:lastGain decimals:1
                                  presets:@[@-12, @-6, @-3, @0, @3, @6]];
    const NSInteger part = [self addProcessPartTickTo:d];
    [d setNote:^NSString*(SVDialog* dlg) {
        const double db = [dlg numberAt:amount];
        return [NSString stringWithFormat:@"%@ by %.1f dB (volume × %.2f).\n%@", db < 0.0 ? @"Quieter" : @"Louder", std::abs(db), std::pow(10.0, db / 20.0), [self processTargetsText:dlg partRow:part]];
    }];
    [self showProcessDialog:d partRow:part process:AudioProcess::Gain apply:^AudioProcessOptions(SVDialog* dlg) {
        lastGain = [dlg numberAt:amount];
        AudioProcessOptions o; o.gainDb = lastGain;
        return o;
    }];
}
- (void)processReverse:(id)sender { (void)sender; [self runSimpleProcess:AudioProcess::Reverse title:@"Reverse" subtitle:@"Plays the sound backwards."]; }
- (void)processInvert:(id)sender { (void)sender; [self runSimpleProcess:AudioProcess::InvertPhase title:@"Invert Phase" subtitle:@"Turns the waveform upside down (polarity). Useful when two recordings of the same source cancel each other."]; }
- (void)processDc:(id)sender { (void)sender; [self runSimpleProcess:AudioProcess::RemoveDc title:@"Remove DC Offset" subtitle:@"Centres the waveform on zero. Removes a constant shift some converters leave in a recording."]; }
// Fade In / Fade Out: the same question, mirrored. The curve is the only choice that matters.
- (void)runFadeDialog:(BOOL)fadeIn {
    NSString* title = fadeIn ? @"Fade In" : @"Fade Out";
    if (![self requireProcessTarget:title]) return;
    if (_processDialog && [_processDialog isOpen]) { [_processDialog bringToFront]; return; }
    static NSInteger lastCurve = 1;
    SVDialog* d = [SVDialog dialogWithTitle:title
                                   subtitle:fadeIn ? @"The sound rises from silence to full level over the whole clip."
                                                   : @"The sound falls from full level to silence over the whole clip."
                                    okTitle:@"Apply"];
    const NSInteger curve = [d addChoice:@"Curve" items:@[@"Linear", @"Equal power", @"Exponential"] selected:lastCurve];
    const NSInteger part = [self addProcessPartTickTo:d];
    [d setNote:^NSString*(SVDialog* dlg) {
        NSString* what = @"";
        switch ([dlg choiceAt:curve]) {
            case 0: what = @"A straight line. Simple and predictable."; break;
            case 1: what = @"Keeps the loudness even to the ear. Best for most music."; break;
            default: what = fadeIn ? @"Stays quiet for longer, then rises quickly." : @"Falls quickly at first, then lingers quietly."; break;
        }
        return [NSString stringWithFormat:@"%@\n%@", what, [self processTargetsText:dlg partRow:part]];
    }];
    [self showProcessDialog:d partRow:part process:(fadeIn ? AudioProcess::FadeIn : AudioProcess::FadeOut) apply:^AudioProcessOptions(SVDialog* dlg) {
        lastCurve = [dlg choiceAt:curve];
        AudioProcessOptions o;
        o.fadeShape = lastCurve == 0 ? FadeShape::Linear : (lastCurve == 2 ? FadeShape::Exponential : FadeShape::EqualPower);
        return o;
    }];
}
- (void)processFadeIn:(id)sender { (void)sender; [self runFadeDialog:YES]; }
- (void)processFadeOut:(id)sender { (void)sender; [self runFadeDialog:NO]; }
- (void)processSilence:(id)sender { (void)sender; [self runSimpleProcess:AudioProcess::Silence title:@"Silence" subtitle:@"Replaces the sound with silence. The clip stays where it is."]; }
- (void)processMono:(id)sender { (void)sender; [self runSimpleProcess:AudioProcess::MonoSum title:@"Mono Sum" subtitle:@"Mixes left and right into one signal on both sides."]; }
- (void)processFlip:(id)sender { (void)sender; [self runSimpleProcess:AudioProcess::StereoFlip title:@"Stereo Flip" subtitle:@"Swaps the left and right channels."]; }
- (void)processStretch:(id)sender {
    (void)sender;
    if (![self requireProcessTarget:@"Time Stretch"]) return;
    if (_processDialog && [_processDialog isOpen]) { [_processDialog bringToFront]; return; }
    static NSInteger lastQuality = 2;
    SVDialog* d = [SVDialog dialogWithTitle:@"Time Stretch"
                                   subtitle:@"Makes the sound longer or shorter without changing its pitch. 100% keeps the same length."
                                    okTitle:@"Stretch"];
    const NSInteger length = [d addNumber:@"New length" unit:@"% of the original" min:25.0 max:400.0 value:100.0 decimals:1
                                  presets:@[@50, @75, @100, @125, @150, @200]];
    const NSInteger quality = [d addChoice:@"Quality" items:@[@"Draft (fastest)", @"Balanced", @"High (best sound, slower)"] selected:lastQuality];
    const NSInteger part = [self addProcessPartTickTo:d];
    [d setNote:^NSString*(SVDialog* dlg) {
        return [NSString stringWithFormat:@"Every clip becomes %.1f %% of its length. %@", [dlg numberAt:length], [self processTargetsText:dlg partRow:part]];
    }];
    [self showProcessDialog:d partRow:part process:AudioProcess::TimeStretch apply:^AudioProcessOptions(SVDialog* dlg) {
        lastQuality = [dlg choiceAt:quality];
        AudioProcessOptions o;
        o.stretchRatio = [dlg numberAt:length] / 100.0;
        o.quality = static_cast<ElasticAudioQuality>(lastQuality);
        return o;
    }];
}
- (void)processPitch:(id)sender {
    (void)sender;
    if (![self requireProcessTarget:@"Pitch Shift"]) return;
    if (_processDialog && [_processDialog isOpen]) { [_processDialog bringToFront]; return; }
    static NSInteger lastQuality = 2;
    static BOOL lastFormants = NO;
    SVDialog* d = [SVDialog dialogWithTitle:@"Pitch Shift"
                                   subtitle:@"Makes the sound higher or lower without changing its length. 12 semitones are one octave."
                                    okTitle:@"Shift"];
    const NSInteger pitch = [d addNumber:@"Pitch" unit:@"semitones" min:-24.0 max:24.0 value:0.0 decimals:2
                                 presets:@[@-12, @-7, @-1, @1, @7, @12]];
    const NSInteger formants = [d addCheck:@"Keep the voice character (formants)" on:lastFormants];
    const NSInteger quality = [d addChoice:@"Quality" items:@[@"Draft (fastest)", @"Balanced", @"High (best sound, slower)"] selected:lastQuality];
    const NSInteger part = [self addProcessPartTickTo:d];
    [d setNote:^NSString*(SVDialog* dlg) {
        const double st = [dlg numberAt:pitch];
        NSString* what = std::abs(st) < 0.005 ? @"No change." : [NSString stringWithFormat:@"%.2f semitones %@ (%.0f cents).", std::abs(st), st > 0.0 ? @"higher" : @"lower", std::abs(st) * 100.0];
        return [NSString stringWithFormat:@"%@\n%@", what, [self processTargetsText:dlg partRow:part]];
    }];
    [self showProcessDialog:d partRow:part process:AudioProcess::PitchShift apply:^AudioProcessOptions(SVDialog* dlg) {
        lastQuality = [dlg choiceAt:quality];
        lastFormants = [dlg checkAt:formants];
        AudioProcessOptions o;
        o.semitones = [dlg numberAt:pitch];
        o.preserveFormants = lastFormants;
        o.quality = static_cast<ElasticAudioQuality>(lastQuality);
        return o;
    }];
}

- (void)renderInPlace:(id)sender {
    (void)sender;
    if (self.selectedTrack < 0) { [self showError:@"Render in Place" detail:"Select an audio or instrument track."]; return; }
    const auto track = static_cast<std::size_t>(self.selectedTrack);
    OfflineBounceOptions range = [self bounceOptions];
    try {
        const std::string dir = sv::processedMediaDirectory();
        [SilvetonNativeEditor closeAll];
        _core->session().beginEdit("Render in Place");
        {
            sv::AppRuntime::OfflineScope scope(*_core);
            const auto r = AudioProcessor::renderInPlace(_core->project(), _core->engine(), &_core->runtime().rack(), track,
                                                         range.startSample, range.endSample, dir, true);
            _core->waveformCache().request(r.path);
            self.selectedTrack = static_cast<long>(r.newTrackIndex);
        }
        _core->session().commitEdit();
        [self requestRebuild];
    } catch (const std::exception& e) {
        if (_core->session().history().transactionOpen()) _core->session().cancelEdit();
        [self showError:@"Render in Place" detail:e.what()];
    }
    [self refreshAll];
}

// ============================================================ console API ==
- (void)setStrip:(SVStrip)strip gainDb:(double)db {
    Project& p = _core->project();
    const float v = static_cast<float>(std::clamp(db, -96.0, 12.0));
    const std::int64_t at = self.playheadSample;
    if (strip.kind == SVStripKind::Track && strip.index < p.tracks.size()) {
        auto& t = p.tracks[strip.index];
        t.gainDb = v;
        if (t.gainAutomationMode != AutomationMode::Read && t.gainAutomationMode != AutomationMode::Off) {
            _gainWriter.setMode(t.gainAutomationMode);
            _gainWriter.apply(AutomationGestureType::Value, at, v, t.gainAutomationDb);
        }
        [self applyFaderLive];
    } else if (strip.kind == SVStripKind::Bus && strip.index < p.buses.size()) {
        p.buses[strip.index].gainDb = v;
        [self applyFaderLive];   // heard in the next block; no project rebuild
    } else if (strip.kind == SVStripKind::Master) {
        p.masterFaderDb = v;
        [self applyFaderLive];
    }
    _core->session().markDirty();
    [_console invalidateStrip:strip];
    [_dock invalidateStrip:strip];
}

- (void)setStrip:(SVStrip)strip pan:(double)pan {
    Project& p = _core->project();
    if (strip.kind != SVStripKind::Track || strip.index >= p.tracks.size()) return;
    auto& t = p.tracks[strip.index];
    t.pan = static_cast<float>(std::clamp(pan, -1.0, 1.0));
    if (t.panAutomationMode != AutomationMode::Read && t.panAutomationMode != AutomationMode::Off) {
        _panWriter.setMode(t.panAutomationMode);
        _panWriter.apply(AutomationGestureType::Value, self.playheadSample, t.pan, t.panAutomation);
    }
    [self applyMixerLive];
    _core->session().markDirty();
    [_console invalidateStrip:strip];
    [_dock invalidateStrip:strip];
}

- (void)toggleStripMute:(SVStrip)strip {
    Project& p = _core->project();
    if (strip.kind == SVStripKind::Track) { ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = strip.index; [self toggleMute:r]; return; }
    if (strip.kind == SVStripKind::Bus && strip.index < p.buses.size()) {
        [self runEdit:@"Mute Bus" rebuild:NO block:^{ auto& b = self->_core->project().buses[strip.index]; b.mute = !b.mute; }];
        [self applyMixerLive];
    }
}
- (void)toggleStripSolo:(SVStrip)strip {
    Project& p = _core->project();
    if (strip.kind == SVStripKind::Track) { ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = strip.index; [self toggleSolo:r]; return; }
    if (strip.kind == SVStripKind::Bus && strip.index < p.buses.size()) {
        p.buses[strip.index].solo = !p.buses[strip.index].solo;
        _core->session().markDirty();
        [self applySolo];
        [self refreshAll];
    }
}

- (void)stripInsertClicked:(SVStrip)strip slot:(std::size_t)slot { [self openInsertEditor:strip slot:slot]; }

// Reads the engine once per UI tick and runs the meter ballistics for every
// track and the master. All views draw from this one bank, so they always agree.
- (void)updateMeters {
    const double now = [NSProcessInfo processInfo].systemUptime;
    const double dt = _meterClock > 0.0 ? now - _meterClock : 0.0;
    _meterClock = now;
    if (!_core || !_core->ready()) { _meters.feedMaster(0.0F, 0.0F, dt); return; }
    auto& engine = _core->engine();
    const std::size_t n = engine.trackCount();
    _meters.setTrackCount(n);
    for (std::size_t i = 0U; i < n; ++i) {
        const auto m = engine.takeTrackPeaks(i);   // highest peak since the previous tick
        _meters.feedTrack(i, m.leftPeak, m.rightPeak, dt);
    }
    const std::size_t nb = engine.busCount();
    _meters.setBusCount(nb);
    for (std::size_t i = 0U; i < nb; ++i) {
        const auto m = engine.takeBusPeaks(i);
        _meters.feedBus(i, m.leftPeak, m.rightPeak, dt);
    }
    const auto out = engine.takeOutputPeaks();
    _meters.feedMaster(out.leftPeak, out.rightPeak, dt);
}

- (StereoMeterDisplay)meterDisplayForStrip:(SVStrip)strip {
    if (strip.kind == SVStripKind::Track) return _meters.track(strip.index);
    if (strip.kind == SVStripKind::Master) return _meters.master();
    return _meters.bus(strip.index);
}

- (StereoMeterDisplay)masterMeterDisplay { return _meters.master(); }

// A cheap fingerprint of the track-header meters (segment-snapped), so the
// arrange view repaints that column only when a level visibly moved.
- (std::uint32_t)meterSignature {
    std::uint32_t h = 2166136261U;
    const std::size_t n = _meters.trackCount();
    for (std::size_t i = 0U; i < n; ++i) h = (h ^ sv::meter::signature(_meters.track(i), 40.0, false)) * 16777619U;
    return h;
}

- (void)resetMetersForStrip:(SVStrip)strip all:(BOOL)all {
    if (all) _meters.resetPeaks();
    else if (strip.kind == SVStripKind::Track) _meters.resetTrackPeaks(strip.index);
    else if (strip.kind == SVStripKind::Bus) _meters.resetBusPeaks(strip.index);
    else if (strip.kind == SVStripKind::Master) _meters.resetMasterPeaks();
    [_console setNeedsDisplay:YES];
    [_transport setNeedsDisplay:YES];
}

// The plug-in menu, ordered so it can be read: Silveton Native first (by category), then VST3 grouped by
// vendor (a submenu per vendor, A-Z), inside each vendor by category (Instruments, EQ, Dynamics, Reverb,
// Delay, Modulation, Distortion, Tools, Other) and then by name. A vendor with only a few plug-ins is one
// flat list; a vendor with many gets category sections.
namespace {
NSString* categoryOf(const std::vector<std::string>& subs, bool instrument) {
    if (instrument) return @"Instruments";
    for (const auto& c : subs) {
        std::string lower;
        for (char ch : c) lower += static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
        if (lower.find("eq") != std::string::npos || lower.find("filter") != std::string::npos) return @"EQ & Filter";
        if (lower.find("dynamics") != std::string::npos || lower.find("compress") != std::string::npos || lower.find("limit") != std::string::npos || lower.find("gate") != std::string::npos) return @"Dynamics";
        if (lower.find("reverb") != std::string::npos) return @"Reverb";
        if (lower.find("delay") != std::string::npos) return @"Delay";
        if (lower.find("modulation") != std::string::npos || lower.find("chorus") != std::string::npos || lower.find("flang") != std::string::npos || lower.find("phaser") != std::string::npos) return @"Modulation";
        if (lower.find("distortion") != std::string::npos || lower.find("saturat") != std::string::npos || lower.find("amp") != std::string::npos) return @"Distortion & Amps";
        if (lower.find("pitch") != std::string::npos || lower.find("restoration") != std::string::npos || lower.find("analyzer") != std::string::npos || lower.find("tools") != std::string::npos || lower.find("mastering") != std::string::npos) return @"Tools";
        if (lower.find("spatial") != std::string::npos || lower.find("surround") != std::string::npos || lower.find("stereo") != std::string::npos) return @"Spatial";
    }
    return @"Other";
}
NSArray<NSString*>* categoryOrder() {
    return @[@"Instruments", @"EQ & Filter", @"Dynamics", @"Reverb", @"Delay", @"Modulation", @"Distortion & Amps", @"Spatial", @"Tools", @"Other"];
}
}

- (NSMenu*)insertMenuForStrip:(SVStrip)strip {
    _menuStrip = strip;
    NSMenu* menu = [[NSMenu alloc] initWithTitle:@"Insert"];
    auto addEntry = [self](NSMenu* into, NSString* title, NSDictionary* rep) {
        NSMenuItem* it = [into addItemWithTitle:title action:@selector(insertFromMenu:) keyEquivalent:@""];
        it.target = self;
        it.representedObject = rep;
    };
    // ---- Silveton Native, by category
    NSMenuItem* nativeHeader = [menu addItemWithTitle:@"SILVETON NATIVE" action:nil keyEquivalent:@""];
    nativeHeader.enabled = NO;
    {
        std::vector<const NativePluginInfo*> natives;
        for (const auto& info : nativePluginCatalog()) {
            if (info.instrument && strip.kind != SVStripKind::Track) continue;
            natives.push_back(&info);
        }
        std::sort(natives.begin(), natives.end(), [](const NativePluginInfo* a, const NativePluginInfo* b) {
            if (a->category != b->category) return a->category < b->category;
            return a->name < b->name;
        });
        std::string lastCategory;
        for (const NativePluginInfo* info : natives) {
            if (info->category != lastCategory) {
                lastCategory = info->category;
                NSMenuItem* cat = [menu addItemWithTitle:[@"   " stringByAppendingString:sv::ns(info->category).uppercaseString] action:nil keyEquivalent:@""];
                cat.enabled = NO;
            }
            addEntry(menu, [@"      " stringByAppendingString:sv::ns(info->name)],
                     @{@"native": @YES, @"module": sv::ns(kNativeModulePath), @"class": sv::ns(info->classId), @"name": sv::ns(info->name), @"instrument": @(info->instrument)});
        }
    }
    // ---- VST3, by vendor, then category, then name
    if (_browser && !_browser->catalog().entries().empty()) {
        [menu addItem:[NSMenuItem separatorItem]];
        NSMenuItem* vstHeader = [menu addItemWithTitle:@"VST3  ·  BY VENDOR" action:nil keyEquivalent:@""];
        vstHeader.enabled = NO;
        struct Item { const Vst3CatalogEntry* e; bool instrument; NSString* category; };
        std::map<std::string, std::vector<Item>> byVendor;
        for (const auto& e : _browser->catalog().entries()) {
            bool inst = false;
            for (const auto& c : e.subCategories) if (c.find("Instrument") != std::string::npos || c.find("Synth") != std::string::npos) inst = true;
            if (inst && strip.kind != SVStripKind::Track) continue;
            const std::string vendor = e.vendor.empty() ? std::string("Other vendors") : e.vendor;
            byVendor[vendor].push_back({&e, inst, categoryOf(e.subCategories, inst)});
        }
        NSArray<NSString*>* order = categoryOrder();
        for (auto& [vendor, items] : byVendor) {
            std::sort(items.begin(), items.end(), [order](const Item& a, const Item& b) {
                const NSUInteger ca = [order indexOfObject:a.category], cb = [order indexOfObject:b.category];
                if (ca != cb) return ca < cb;
                return a.e->name < b.e->name;
            });
            NSMenuItem* vendorItem = [menu addItemWithTitle:[NSString stringWithFormat:@"%@  (%lu)", sv::ns(vendor), (unsigned long)items.size()] action:nil keyEquivalent:@""];
            NSMenu* sub = [[NSMenu alloc] initWithTitle:sv::ns(vendor)];
            NSString* lastCategory = nil;
            const bool sections = items.size() > 6;
            for (const Item& item : items) {
                if (sections && ![item.category isEqualToString:lastCategory]) {
                    lastCategory = item.category;
                    if (sub.numberOfItems) [sub addItem:[NSMenuItem separatorItem]];
                    NSMenuItem* cat = [sub addItemWithTitle:item.category.uppercaseString action:nil keyEquivalent:@""];
                    cat.enabled = NO;
                }
                addEntry(sub, sv::ns(item.e->name),
                         @{@"native": @NO, @"module": sv::ns(item.e->modulePath), @"class": sv::ns(item.e->classId), @"name": sv::ns(item.e->name), @"instrument": @(item.instrument)});
            }
            vendorItem.submenu = sub;
        }
    }
    return menu;
}

- (void)insertFromMenu:(NSMenuItem*)item {
    NSDictionary* d = item.representedObject;
    SVPluginEntry e;
    e.native = [d[@"native"] boolValue];
    e.instrument = [d[@"instrument"] boolValue];
    e.modulePath = sv::str(d[@"module"]);
    e.classId = sv::str(d[@"class"]);
    e.name = sv::str(d[@"name"]);
    [self insertPluginEntry:e intoStrip:_menuStrip];
}

- (void)toggleBypassFromMenu:(NSMenuItem*)item {
    const auto slot = static_cast<std::size_t>(item.tag);
    const SVStrip strip = _menuStrip;
    [self runEdit:@"Bypass Insert" rebuild:YES block:^{
        auto* slots = [self slotsForStrip:strip];
        if (slots && slot < slots->size()) (*slots)[slot].enabled = !(*slots)[slot].enabled;
    }];
}
- (void)removeInsertFromMenu:(NSMenuItem*)item {
    const auto slot = static_cast<std::size_t>(item.tag);
    const SVStrip strip = _menuStrip;
    [SilvetonNativeEditor closeAll];
    [self runEdit:@"Remove Insert" rebuild:YES block:^{
        auto* slots = [self slotsForStrip:strip];
        if (slots && slot < slots->size()) slots->erase(slots->begin() + static_cast<std::ptrdiff_t>(slot));
    }];
}
- (void)openInsertFromMenu:(NSMenuItem*)item { [self openInsertEditor:_menuStrip slot:static_cast<std::size_t>(item.tag)]; }

- (void)addSendFromMenu:(NSMenuItem*)item {
    const int bus = static_cast<int>(item.tag);
    const SVStrip strip = _menuStrip;
    [self runEdit:@"Add Send" rebuild:YES block:^{
        Project& p = self->_core->project();
        ProjectSend s; s.destinationBus = bus; s.gainDb = -10.0F;
        if (strip.kind == SVStripKind::Track) p.tracks.at(strip.index).sends.push_back(s);
        else if (strip.kind == SVStripKind::Bus) { if (static_cast<std::size_t>(bus) == strip.index) throw std::runtime_error("a bus cannot send to itself"); p.buses.at(strip.index).sends.push_back(s); }
    }];
}
- (void)routeFromMenu:(NSMenuItem*)item {
    const int bus = static_cast<int>(item.tag);
    const SVStrip strip = _menuStrip;
    [self runEdit:@"Output Routing" rebuild:YES block:^{
        Project& p = self->_core->project();
        if (strip.kind == SVStripKind::Track) p.tracks.at(strip.index).outputBus = bus;
        else if (strip.kind == SVStripKind::Bus) { if (bus == static_cast<int>(strip.index)) throw std::runtime_error("a bus cannot feed itself"); p.buses.at(strip.index).outputBus = bus; }
    }];
}
- (void)deleteBusFromMenu:(id)sender {
    (void)sender;
    const SVStrip strip = _menuStrip;
    if (strip.kind != SVStripKind::Bus) return;
    [SilvetonNativeEditor closeAll];
    [self runEdit:@"Delete Bus" rebuild:YES block:^{ TrackTools::removeBus(self->_core->project(), strip.index); }];
}
- (void)renameStripFromMenu:(id)sender { (void)sender; [self renameStrip:_menuStrip]; }
- (void)renameStrip:(SVStrip)strip {
    if (strip.kind == SVStripKind::Master) return;
    NSString* n = [self promptText:@"Rename" message:@"" initial:[self stripName:strip]];
    if (!n.length) return;
    [self runEdit:@"Rename" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (strip.kind == SVStripKind::Track) p.tracks.at(strip.index).name = sv::str(n);
        else p.buses.at(strip.index).name = sv::str(n);
    }];
}

// ============================================================ channel menu ==
// ONE menu for a channel, wherever it is opened: the track header in the Project window, the strip in the
// mixer, the Inspector. Everything a channel can do, always in the same order. (The clip under the mouse
// has its own menu, an empty lane its own; see contextMenuForRow:.)
- (NSMenu*)contextMenuForStrip:(SVStrip)strip {
    _menuStrip = strip;
    Project& p = _core->project();
    const bool track = strip.kind == SVStripKind::Track && strip.index < p.tracks.size();
    const bool bus = strip.kind == SVStripKind::Bus && strip.index < p.buses.size();
    const bool master = strip.kind == SVStripKind::Master;
    if (!track && !bus && !master) return nil;
    if (track) { _menuRow.kind = ArrangeRowKind::Audio; _menuRow.index = strip.index; }
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Channel"];
    auto add = [&](NSMenu* menu, NSString* title, SEL action, NSInteger tag, bool on = false) {
        NSMenuItem* it = [menu addItemWithTitle:title action:action keyEquivalent:@""];
        it.target = self; it.tag = tag;
        it.state = on ? NSControlStateValueOn : NSControlStateValueOff;
        return it;
    };
    auto sub = [&](NSString* title) {
        NSMenuItem* it = [m addItemWithTitle:title action:nil keyEquivalent:@""];
        NSMenu* menu = [[NSMenu alloc] initWithTitle:title];
        it.submenu = menu;
        return menu;
    };
    const ProjectTrack* t = track ? &p.tracks[strip.index] : nullptr;
    const ProjectBus* b = bus ? &p.buses[strip.index] : nullptr;
    // name and colour
    if (!master) {
        add(m, @"Rename…", @selector(renameStripFromMenu:), 0);
        NSMenuItem* col = [m addItemWithTitle:@"Colour" action:nil keyEquivalent:@""];
        col.submenu = [self paletteMenuWithAction:@selector(setStripColourFromMenu:)];
        [m addItem:[NSMenuItem separatorItem]];
    }
    // state
    if (!master) {
        add(m, @"Mute", @selector(stripMuteFromMenu:), 0, track ? t->mute : b->mute);
        add(m, @"Solo", @selector(stripSoloFromMenu:), 0, track ? t->solo : b->solo);
    }
    if (track) {
        add(m, @"Record Enable", @selector(stripArmFromMenu:), 0, t->recordArm);
        add(m, @"Monitor", @selector(stripMonitorFromMenu:), 0, t->monitor);
        add(m, @"Lock", @selector(stripLockFromMenu:), 0, t->locked);
    }
    if (!master) [m addItem:[NSMenuItem separatorItem]];
    // routing and automation
    if (!master) {
        NSMenu* route = sub(@"Output");
        add(route, @"Stereo Out", @selector(routeFromMenu:), -1, (track ? t->outputBus : b->outputBus) < 0);
        for (std::size_t i = 0; i < p.buses.size(); ++i) {
            if (bus && strip.index == i) continue;
            add(route, sv::ns(p.buses[i].name), @selector(routeFromMenu:), static_cast<NSInteger>(i), (track ? t->outputBus : b->outputBus) == static_cast<int>(i));
        }
    }
    if (track) {
        NSMenu* autoMenu = sub(@"Automation");
        NSArray<NSString*>* modes = @[@"Off", @"Read", @"Write", @"Touch", @"Latch"];
        for (NSUInteger i = 0; i < modes.count; ++i)
            add(autoMenu, modes[i], @selector(stripAutomationFromMenu:), static_cast<NSInteger>(i), static_cast<NSUInteger>(t->gainAutomationMode) == i);
    }
    // inserts and sends
    NSMenuItem* ins = [m addItemWithTitle:@"Add Insert" action:nil keyEquivalent:@""];
    ins.submenu = [self insertMenuForStrip:strip];
    _menuStrip = strip;   // insertMenuForStrip: sets it too; keep it the channel's
    auto* slots = [self slotsForStrip:strip];
    if (slots && !slots->empty()) {
        NSMenu* manage = sub(@"Inserts");
        for (std::size_t i = 0; i < slots->size(); ++i) {
            const auto& sl = (*slots)[i];
            NSString* name = sv::ns([self pluginNameOfSlot:sl]);
            if (i) [manage addItem:[NSMenuItem separatorItem]];
            add(manage, [NSString stringWithFormat:@"Open %@", name], @selector(openInsertFromMenu:), static_cast<NSInteger>(i));
            add(manage, [NSString stringWithFormat:@"Bypass %@", name], @selector(toggleBypassFromMenu:), static_cast<NSInteger>(i), !sl.enabled);
            add(manage, [NSString stringWithFormat:@"Remove %@", name], @selector(removeInsertFromMenu:), static_cast<NSInteger>(i));
        }
    }
    if (!master) {
        if (!p.buses.empty()) {
            NSMenu* send = sub(@"Add Send");
            for (std::size_t i = 0; i < p.buses.size(); ++i) {
                if (bus && strip.index == i) continue;
                add(send, sv::ns(p.buses[i].name), @selector(addSendFromMenu:), static_cast<NSInteger>(i));
            }
        }
        const auto* sends = [self sendsOfStrip:strip];
        if (sends && !sends->empty()) {
            NSMenu* manage = sub(@"Sends");
            for (std::size_t i = 0; i < sends->size(); ++i) {
                const auto& sd = (*sends)[i];
                NSString* to = sd.destinationBus >= 0 && static_cast<std::size_t>(sd.destinationBus) < p.buses.size() ? sv::ns(p.buses[static_cast<std::size_t>(sd.destinationBus)].name) : @"?";
                add(manage, [NSString stringWithFormat:@"Remove → %@", to], @selector(removeSendFromMenu:), static_cast<NSInteger>(i));
            }
        }
    }
    // the track in the project
    if (track) {
        [m addItem:[NSMenuItem separatorItem]];
        NSMenu* fold = sub(@"Folder");
        add(fold, @"(none)", @selector(moveToFolder:), -1, t->folder < 0);
        for (const auto& f : p.folders) add(fold, sv::ns(f.name), @selector(moveToFolder:), f.id, t->folder == f.id);
        add(m, @"Duplicate Track", @selector(stripDuplicateFromMenu:), 0);
        add(m, @"Move Up", @selector(stripMoveUpFromMenu:), 0);
        add(m, @"Move Down", @selector(stripMoveDownFromMenu:), 0);
        add(m, @"Render in Place", @selector(stripRenderFromMenu:), 0);
    }
    if (!master) {
        [m addItem:[NSMenuItem separatorItem]];
        add(m, track ? @"Delete Track" : @"Delete Channel", track ? @selector(stripDeleteFromMenu:) : @selector(deleteBusFromMenu:), 0);
    }
    return m;
}
- (void)setStripColourFromMenu:(NSMenuItem*)item {
    const auto color = static_cast<std::uint32_t>(item.tag);
    const SVStrip s = _menuStrip;
    [self runEdit:@"Colour" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (s.kind == SVStripKind::Track && s.index < p.tracks.size()) p.tracks[s.index].color = color;
        else if (s.kind == SVStripKind::Bus && s.index < p.buses.size()) p.buses[s.index].color = color;
    }];
}
- (void)stripMuteFromMenu:(id)sender { (void)sender; [self toggleStripMute:_menuStrip]; }
- (void)stripSoloFromMenu:(id)sender { (void)sender; [self toggleStripSolo:_menuStrip]; }
- (void)stripArmFromMenu:(id)sender {
    (void)sender;
    if (_menuStrip.kind != SVStripKind::Track) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = _menuStrip.index;
    [self toggleArm:r];
}
- (void)stripMonitorFromMenu:(id)sender {
    (void)sender;
    if (_menuStrip.kind != SVStripKind::Track) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = _menuStrip.index;
    [self toggleMonitor:r];
}
// The track commands of the menu bar work on the selected track: the menu's track becomes it first.
- (BOOL)selectMenuTrack {
    if (_menuStrip.kind != SVStripKind::Track || _menuStrip.index >= _core->project().tracks.size()) return NO;
    ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = _menuStrip.index;
    [self selectRow:r];
    return YES;
}
- (void)stripLockFromMenu:(id)sender { if ([self selectMenuTrack]) [self toggleLock:sender]; }
- (void)stripDuplicateFromMenu:(id)sender { if ([self selectMenuTrack]) [self duplicateTrack:sender]; }
- (void)stripMoveUpFromMenu:(id)sender { if ([self selectMenuTrack]) [self moveTrackUp:sender]; }
- (void)stripMoveDownFromMenu:(id)sender { if ([self selectMenuTrack]) [self moveTrackDown:sender]; }
- (void)stripRenderFromMenu:(id)sender { if ([self selectMenuTrack]) [self renderInPlace:sender]; }
- (void)stripDeleteFromMenu:(id)sender { if ([self selectMenuTrack]) [self deleteTrack:sender]; }
- (void)stripAutomationFromMenu:(NSMenuItem*)item {
    if (_menuStrip.kind != SVStripKind::Track) return;
    const auto mode = static_cast<AutomationMode>(std::max<NSInteger>(0, std::min<NSInteger>(4, item.tag)));
    const std::size_t i = _menuStrip.index;
    [self runEdit:@"Automation Mode" rebuild:YES block:^{   // the lanes are part of what the engine plays
        auto& t = self->_core->project().tracks.at(i);
        t.gainAutomationMode = mode; t.panAutomationMode = mode; t.muteAutomationMode = mode;
    }];
    [self applyMixerLive];
}
- (void)removeSendFromMenu:(NSMenuItem*)item {
    const SVStrip s = _menuStrip;
    const auto row = static_cast<std::size_t>(std::max<NSInteger>(0, item.tag));
    _sendRow = -1;
    [self runEdit:@"Remove Send" rebuild:YES block:^{
        auto* sends = [self sendsOfStrip:s];
        if (sends && row < sends->size()) sends->erase(sends->begin() + static_cast<std::ptrdiff_t>(row));
    }];
}

// ============================================================= arrange UI ==
// The right mouse button in the Project window: what is under the mouse decides the menu.
//   the header of a track  → the channel menu (the same one as in the mixer)
//   a clip or a part       → what that clip or part can do
//   an empty lane          → paste, new tracks, import, a marker
- (NSMenu*)contextMenuForRow:(ArrangeRow)row header:(BOOL)header clip:(std::uint64_t)clipId part:(std::uint64_t)partId atSample:(std::int64_t)sample {
    _menuRow = row;
    _menuSample = sample;
    Project& p = _core->project();
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Arrange"];
    auto add = [&](NSMenu* menu, NSString* title, SEL action, NSInteger tag, bool on = false) {
        NSMenuItem* it = [menu addItemWithTitle:title action:action keyEquivalent:@""];
        it.target = self; it.tag = tag;
        it.state = on ? NSControlStateValueOn : NSControlStateValueOff;
        return it;
    };
    const bool audio = row.kind == ArrangeRowKind::Audio && row.index < p.tracks.size();
    const bool midi = row.kind == ArrangeRowKind::Midi && row.index < p.midiTracks.size();
    const bool folder = row.kind == ArrangeRowKind::Folder && row.index < p.folders.size();
    if (header && audio) return [self contextMenuForStrip:SVStrip{SVStripKind::Track, row.index}];
    if (header && midi) {   // the MIDI track's channel menu: the same order, what a MIDI track has
        const auto& mt = p.midiTracks[row.index];
        add(m, @"Rename…", @selector(renameSelected:), 0);
        NSMenuItem* col = [m addItemWithTitle:@"Colour" action:nil keyEquivalent:@""];
        col.submenu = [self paletteMenuWithAction:@selector(setRowColour:)];
        [m addItem:[NSMenuItem separatorItem]];
        add(m, @"Mute", @selector(rowMuteFromMenu:), 0, mt.mute);
        add(m, @"Solo", @selector(rowSoloFromMenu:), 0, mt.solo);
        [m addItem:[NSMenuItem separatorItem]];
        NSMenuItem* out = [m addItemWithTitle:@"MIDI Output" action:nil keyEquivalent:@""];
        NSMenu* sub = [[NSMenu alloc] initWithTitle:@"Output"];
        add(sub, @"None", @selector(setMidiOutput:), -1, mt.outputPort < 0);
        for (const auto& t : p.tracks)
            for (const auto& s : t.pluginSlots)
                if (s.midiInputPort >= 0) add(sub, [NSString stringWithFormat:@"%@ (port %d)", sv::ns(t.name), s.midiInputPort], @selector(setMidiOutput:), s.midiInputPort, mt.outputPort == s.midiInputPort);
        out.submenu = sub;
        NSMenuItem* fold = [m addItemWithTitle:@"Folder" action:nil keyEquivalent:@""];
        NSMenu* fsub = [[NSMenu alloc] initWithTitle:@"Folder"];
        add(fsub, @"(none)", @selector(moveToFolder:), -1, mt.folder < 0);
        for (const auto& f : p.folders) add(fsub, sv::ns(f.name), @selector(moveToFolder:), f.id, mt.folder == f.id);
        fold.submenu = fsub;
        [m addItem:[NSMenuItem separatorItem]];
        add(m, @"Delete Track", @selector(deleteTrack:), 0);
        return m;
    }
    if (header && folder) {
        add(m, @"Rename…", @selector(renameSelected:), 0);
        NSMenuItem* col = [m addItemWithTitle:@"Colour" action:nil keyEquivalent:@""];
        col.submenu = [self paletteMenuWithAction:@selector(setRowColour:)];
        [m addItem:[NSMenuItem separatorItem]];
        add(m, @"Delete Folder", @selector(deleteTrack:), 0);
        return m;
    }
    if ([self arrangeRangeActive]) {   // a marked range: its commands come first
        add(m, @"Cut Range", @selector(rangeCut:), 0);
        add(m, @"Copy Range", @selector(rangeCopy:), 0);
        add(m, @"Delete Range", @selector(rangeDelete:), 0);
        add(m, @"Delete Time", @selector(rangeDeleteTime:), 0);
        add(m, @"Insert Silence", @selector(rangeInsertSilence:), 0);
        add(m, @"Split at Range Edges", @selector(rangeSplit:), 0);
        add(m, @"Crop to Range", @selector(rangeCrop:), 0);
        add(m, @"Set Cycle to Range", @selector(rangeSetCycle:), 0);
        add(m, @"Zoom to Range", @selector(rangeZoom:), 0);
        [m addItem:[NSMenuItem separatorItem]];
    } else if ([self rangeClipboardFull]) {
        add(m, @"Paste Range at Cursor", @selector(rangePaste:), 0);
        [m addItem:[NSMenuItem separatorItem]];
    }
    if (audio && clipId) {   // the clip
        add(m, @"Open in Sample Editor", @selector(openEditor:), 0);
        add(m, @"Open in Tone Editor", @selector(openToneEditor:), 0);
        [m addItem:[NSMenuItem separatorItem]];
        add(m, @"Cut", @selector(cutClip:), 0);
        add(m, @"Copy", @selector(copyClip:), 0);
        add(m, @"Duplicate", @selector(duplicateClip:), 0);
        add(m, @"Split at Cursor", @selector(splitAtPlayhead:), 0);
        add(m, @"Mute / Unmute Clip", @selector(toggleClipMute:), 0);
        add(m, @"Crossfade with Next", @selector(crossfadeClips:), 0);
        add(m, @"Clip Gain…", @selector(clipGain:), 0);
        add(m, @"Clip Fades…", @selector(clipFades:), 0);
        NSMenuItem* proc = [m addItemWithTitle:@"Process" action:nil keyEquivalent:@""];
        NSMenu* sub = [[NSMenu alloc] initWithTitle:@"Process"];
        add(sub, @"Normalize…", @selector(processNormalize:), 0);
        add(sub, @"Gain…", @selector(processGain:), 0);
        add(sub, @"Fade In", @selector(processFadeIn:), 0);
        add(sub, @"Fade Out", @selector(processFadeOut:), 0);
        add(sub, @"Reverse", @selector(processReverse:), 0);
        add(sub, @"Invert Phase", @selector(processInvert:), 0);
        add(sub, @"Remove DC Offset", @selector(processDc:), 0);
        add(sub, @"Silence", @selector(processSilence:), 0);
        add(sub, @"Mono Sum", @selector(processMono:), 0);
        add(sub, @"Stereo Flip", @selector(processFlip:), 0);
        add(sub, @"Time Stretch…", @selector(processStretch:), 0);
        add(sub, @"Pitch Shift…", @selector(processPitch:), 0);
        proc.submenu = sub;
        [m addItem:[NSMenuItem separatorItem]];
        add(m, @"Delete Clip", @selector(deleteSelection:), 0);
        return m;
    }
    if (midi && partId) {   // the part
        add(m, @"Open in Key Editor", @selector(openEditor:), 0);
        [m addItem:[NSMenuItem separatorItem]];
        add(m, @"Cut", @selector(cutClip:), 0);
        add(m, @"Copy", @selector(copyClip:), 0);
        add(m, @"Duplicate Part", @selector(duplicatePart:), 0);
        add(m, @"Split Part at Cursor", @selector(splitAtPlayhead:), 0);
        [m addItem:[NSMenuItem separatorItem]];
        add(m, @"Delete Part", @selector(deleteSelection:), 0);
        return m;
    }
    // an empty lane
    if (_clipboardValid) add(m, @"Paste at Cursor", @selector(pasteClip:), 0);
    if (midi) add(m, @"Create Part Here", @selector(createPartFromMenu:), 0);
    if (m.numberOfItems) [m addItem:[NSMenuItem separatorItem]];
    add(m, @"Add Audio Track", @selector(addAudioTrack:), 0);
    add(m, @"Add Instrument Track", @selector(addInstrumentTrack:), 0);
    add(m, @"Add MIDI Track", @selector(addMidiTrack:), 0);
    add(m, @"Add Group Channel", @selector(addGroupBus:), 0);
    add(m, @"Add FX Channel", @selector(addFxBus:), 0);
    add(m, @"Add Folder…", @selector(addFolder:), 0);
    [m addItem:[NSMenuItem separatorItem]];
    add(m, @"Import Audio…", @selector(importAudio:), 0);
    add(m, @"Add Marker Here", @selector(addMarkerFromMenu:), 0);
    return m;
}
- (void)rowMuteFromMenu:(id)sender { (void)sender; [self toggleMute:_menuRow]; }
- (void)rowSoloFromMenu:(id)sender { (void)sender; [self toggleSolo:_menuRow]; }
- (void)createPartFromMenu:(id)sender { (void)sender; if (_menuRow.kind == ArrangeRowKind::Midi) [self createPartForMidiTrack:_menuRow.index atSample:[self snapSample:_menuSample]]; }
- (void)addMarkerFromMenu:(id)sender { (void)sender; [self addMarkerAtSample:[self snapSample:_menuSample]]; }

// Markers
- (void)markerClicked:(std::uint64_t)markerId doubleClick:(BOOL)twice {
    const auto* m = MarkerTools::find(_core->project(), markerId);
    if (!m) return;
    if (m->cycle && twice) { [self setCycleStart:m->sample end:m->endSample]; return; }
    [self seekToSample:m->sample];
    if (twice) { _menuMarker = markerId; [self renameMarkerFromMenu:nil]; }
}
- (NSMenu*)contextMenuForMarker:(std::uint64_t)markerId {
    _menuMarker = markerId;
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Marker"];
    for (NSArray* spec in @[@[@"Go to Marker", NSStringFromSelector(@selector(gotoMarkerFromMenu:))],
                            @[@"Rename…", NSStringFromSelector(@selector(renameMarkerFromMenu:))],
                            @[@"Loop from Here to Next Marker", NSStringFromSelector(@selector(loopMarkerFromMenu:))],
                            @[@"Delete Marker", NSStringFromSelector(@selector(deleteMarkerFromMenu:))]]) {
        NSMenuItem* it = [m addItemWithTitle:spec[0] action:NSSelectorFromString(spec[1]) keyEquivalent:@""];
        it.target = self;
    }
    return m;
}
- (void)gotoMarkerFromMenu:(id)sender { (void)sender; if (const auto* m = MarkerTools::find(_core->project(), _menuMarker)) [self seekToSample:m->sample]; }
- (void)renameMarkerFromMenu:(id)sender {
    (void)sender;
    const auto* m = MarkerTools::find(_core->project(), _menuMarker);
    if (!m) return;
    NSString* n = [self promptText:@"Rename Marker" message:@"" initial:sv::ns(m->name)];
    if (!n) return;
    const std::uint64_t id = _menuMarker;
    [self runEdit:@"Rename Marker" rebuild:NO block:^{ (void)MarkerTools::rename(self->_core->project(), id, sv::str(n)); }];
}
- (void)loopMarkerFromMenu:(id)sender {
    (void)sender;
    const auto* m = MarkerTools::find(_core->project(), _menuMarker);
    if (!m) return;
    if (m->cycle) { [self setCycleStart:m->sample end:m->endSample]; return; }
    const auto* next = MarkerTools::next(_core->project(), m->sample);
    if (next) [self setCycleStart:m->sample end:next->sample];
}
- (void)deleteMarkerFromMenu:(id)sender {
    (void)sender;
    const std::uint64_t id = _menuMarker;
    [self runEdit:@"Delete Marker" rebuild:NO block:^{ (void)MarkerTools::remove(self->_core->project(), id); }];
}

// Arranger
- (void)sectionClicked:(std::uint64_t)sectionId doubleClick:(BOOL)twice {
    self.selectedSectionId = sectionId;
    const auto* s = ArrangerTools::find(_core->project(), sectionId);
    if (!s) return;
    if (twice) [self setCycleStart:s->startSample end:s->endSample];
    else [self seekToSample:s->startSample];
    [self refreshAll];
}
- (void)createSectionFrom:(std::int64_t)start to:(std::int64_t)end {
    [self runEdit:@"Add Arranger Section" rebuild:NO block:^{
        self.selectedSectionId = ArrangerTools::addSection(self->_core->project(), "", start, end);
    }];
}
- (NSMenu*)contextMenuForSection:(std::uint64_t)sectionId {
    _menuSection = sectionId;
    self.selectedSectionId = sectionId;
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Section"];
    for (NSArray* spec in @[@[@"Loop Section", NSStringFromSelector(@selector(loopSectionFromMenu:))],
                            @[@"Append to Chain", NSStringFromSelector(@selector(appendSectionFromMenu:))],
                            @[@"Rename…", NSStringFromSelector(@selector(renameSectionFromMenu:))],
                            @[@"Delete Section", NSStringFromSelector(@selector(deleteSectionFromMenu:))]]) {
        NSMenuItem* it = [m addItemWithTitle:spec[0] action:NSSelectorFromString(spec[1]) keyEquivalent:@""];
        it.target = self;
    }
    return m;
}
- (void)loopSectionFromMenu:(id)sender { (void)sender; if (const auto* s = ArrangerTools::find(_core->project(), _menuSection)) [self setCycleStart:s->startSample end:s->endSample]; }
- (void)appendSectionFromMenu:(id)sender {
    (void)sender;
    const std::uint64_t id = _menuSection;
    [self runEdit:@"Append to Chain" rebuild:NO block:^{ ArrangerTools::appendToChain(self->_core->project(), id, 1U); }];
}
- (void)renameSectionFromMenu:(id)sender {
    (void)sender;
    const auto* s = ArrangerTools::find(_core->project(), _menuSection);
    if (!s) return;
    NSString* n = [self promptText:@"Rename Section" message:@"" initial:sv::ns(s->name)];
    if (!n.length) return;
    const std::uint64_t id = _menuSection;
    [self runEdit:@"Rename Section" rebuild:NO block:^{
        for (auto& sec : self->_core->project().arrangerSections) if (sec.id == id) sec.name = sv::str(n);
    }];
}
- (void)deleteSectionFromMenu:(id)sender {
    (void)sender;
    const std::uint64_t id = _menuSection;
    [self runEdit:@"Delete Section" rebuild:NO block:^{ (void)ArrangerTools::removeSection(self->_core->project(), id); }];
}

// Plug-in scan
- (void)scanPlugins:(id)sender {
    (void)sender;
    if (_scannerBusy || !_browser) return;
    _scannerBusy = YES;
    [self setStatus:@"Scanning VST3 plug-ins…"];
    const std::vector<std::string> paths = _core->host().installedModulePaths();
    Vst3PluginBrowserService* browser = _browser.get();
    __weak SilvetonController* weakSelf = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        std::string message;
        try {
            const auto summary = browser->scanModules(paths, true);
            std::ostringstream ss;
            ss << "Scanned " << summary.scannedModules << " module(s): " << summary.discoveredClasses << " plug-in(s), " << summary.failedModules << " failed";
            message = ss.str();
        } catch (const std::exception& e) { message = e.what(); }
        dispatch_async(dispatch_get_main_queue(), ^{
            SilvetonController* s = weakSelf;
            if (!s) return;
            s->_scannerBusy = NO;
            [s setStatus:sv::ns(message)];
            [s reloadPluginResults];
        });
    });
}

@end
