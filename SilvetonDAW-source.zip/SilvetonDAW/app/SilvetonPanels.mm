// Silveton — controls, Inspector (left channel panel), Library page, Edit page
// and the main menu. Category of SilvetonController.
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>

#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/NativePlugins.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <set>
#include <string>

using namespace silveton;

// Methods implemented in other files of the controller that are called here.
@interface SilvetonController (PanelsForward)
- (void)routeFromMenu:(NSMenuItem*)item;
- (void)toggleBypassFromMenu:(NSMenuItem*)item;
- (void)removeInsertFromMenu:(NSMenuItem*)item;
- (void)addSendFromMenu:(NSMenuItem*)item;
- (void)setMidiOutput:(NSMenuItem*)item;
- (void)toggleLock:(id)sender;
- (void)loopSectionFromMenu:(id)sender;
- (void)appendSectionFromMenu:(id)sender;
- (void)deleteSectionFromMenu:(id)sender;
- (void)deleteMarkerFromMenu:(id)sender;
- (void)gotoMarkerFromMenu:(id)sender;
- (void)flattenArranger:(id)sender;
- (void)scanPlugins:(id)sender;
- (void)importAudio:(id)sender;
- (void)addInstrumentTrackWith:(const SVPluginEntry&)entry;
- (void)applyMixerLive;
- (void)republishMidi;
- (void)showPreferences:(id)sender;
@end

// ================================================================ controls ==
@implementation SVFlipView
- (BOOL)isFlipped { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    if (self.fillColor) sv::fill(self.bounds, self.fillColor);
}
@end

@implementation SVButton
+ (instancetype)buttonWithTitle:(NSString*)title target:(id)target action:(SEL)action frame:(NSRect)frame {
    SVButton* b = [[SVButton alloc] initWithFrame:frame];
    b.title = title;
    b.target = target;
    b.action = action;
    b.bordered = NO;
    [b setButtonType:NSButtonTypeMomentaryPushIn];
    return b;
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    NSColor* fill = self.accent ? sv::copper() : (self.isHighlighted ? sv::raisedHi() : sv::raised());
    if (!self.isEnabled) fill = sv::panel();
    sv::roundFill(b, 3, fill);
    sv::roundStroke(b, 3, sv::hairline());
    NSFont* f = sv::ui(9.5, true);
    const NSSize sz = sv::textSize(self.title, f);
    NSColor* ink = !self.isEnabled ? sv::inkFaint() : (self.accent ? sv::hex(0x111111) : sv::ink());
    sv::text(self.title, NSMakePoint(NSMidX(b) - sz.width / 2, NSMidY(b) - sz.height / 2), f, ink);
}
@end

@implementation SVToggle
+ (instancetype)toggleWithTitle:(NSString*)title color:(NSColor*)color target:(id)target action:(SEL)action frame:(NSRect)frame {
    SVToggle* b = [[SVToggle alloc] initWithFrame:frame];
    b.title = title;
    b.target = target;
    b.action = action;
    b.onColor = color;
    b.bordered = NO;
    [b setButtonType:NSButtonTypePushOnPushOff];
    return b;
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const BOOL on = self.state == NSControlStateValueOn;
    const NSRect b = self.bounds;
    sv::roundFill(b, 3, on ? (self.onColor ?: sv::copper()) : sv::raised());
    sv::roundStroke(b, 3, sv::hairline());
    NSFont* f = sv::ui(9.5, true);
    const NSSize sz = sv::textSize(self.title, f);
    sv::text(self.title, NSMakePoint(NSMidX(b) - sz.width / 2, NSMidY(b) - sz.height / 2), f, on ? sv::hex(0x111111) : sv::inkDim());
}
@end

@implementation SVResetSlider
- (void)mouseDown:(NSEvent*)event {
    if (event.clickCount >= 2) {
        self.doubleValue = self.resetValue;
        [self sendAction:self.action to:self.target];
        return;
    }
    if (self.beginAction) [NSApp sendAction:self.beginAction to:self.target from:self];
    [super mouseDown:event];
    if (self.endAction) [NSApp sendAction:self.endAction to:self.target from:self];
}
@end

// ================================================================ helpers ==
namespace {
constexpr CGFloat kInspW = 224.0;

NSTextField* makeLabel(NSView* parent, NSString* s, NSRect f, NSFont* font, NSColor* color, NSTextAlignment a = NSTextAlignmentLeft) {
    NSTextField* t = [NSTextField labelWithString:s ?: @""];
    t.frame = f;
    t.font = font;
    t.textColor = color;
    t.alignment = a;
    t.lineBreakMode = NSLineBreakByTruncatingTail;
    [parent addSubview:t];
    return t;
}

NSTextField* makeField(NSView* parent, NSRect f, id target, SEL action) {
    NSTextField* t = [[NSTextField alloc] initWithFrame:f];
    t.font = sv::ui(11);
    t.textColor = sv::ink();
    t.backgroundColor = sv::hex(0x1C1C1E);
    t.drawsBackground = YES;
    t.bezeled = YES;
    t.bezelStyle = NSTextFieldSquareBezel;
    t.target = target;
    t.action = action;
    [parent addSubview:t];
    return t;
}

void sectionBar(NSView* parent, NSString* title, CGFloat y, CGFloat w) {
    SVFlipView* bar = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, y, w, 18)];
    bar.fillColor = sv::hex(0x383839);
    [parent addSubview:bar];
    makeLabel(bar, [@"▾  " stringByAppendingString:title], NSMakeRect(8, 2, w - 16, 14), sv::ui(8.5, true), sv::inkDim());
}

NSPopUpButton* makePopup(NSView* parent, NSRect f, id target, SEL action) {
    NSPopUpButton* p = [[NSPopUpButton alloc] initWithFrame:f pullsDown:NO];
    p.font = sv::ui(10.5);
    p.target = target;
    p.action = action;
    [parent addSubview:p];
    return p;
}

NSTableView* makeTable(NSView* parent, NSRect f, NSArray<NSArray<NSString*>*>* columns, id owner, BOOL header) {
    NSScrollView* sc = [[NSScrollView alloc] initWithFrame:f];
    sc.hasVerticalScroller = YES;
    sc.borderType = NSNoBorder;
    sc.drawsBackground = YES;
    sc.backgroundColor = sv::hex(0x1C1C1E);
    NSTableView* t = [[NSTableView alloc] initWithFrame:sc.bounds];
    t.backgroundColor = sv::hex(0x1C1C1E);
    t.gridColor = sv::hex(0x2A2A2C);
    t.rowHeight = 18;
    t.intercellSpacing = NSMakeSize(0, 1);
    t.allowsEmptySelection = YES;
    t.allowsMultipleSelection = NO;
    t.dataSource = owner;
    t.delegate = owner;
    for (NSArray<NSString*>* c in columns) {
        NSTableColumn* col = [[NSTableColumn alloc] initWithIdentifier:c[0]];
        col.title = c[1];
        col.width = c[2].doubleValue;
        col.minWidth = 16;
        [t addTableColumn:col];
    }
    if (!header) t.headerView = nil;
    sc.documentView = t;
    [parent addSubview:sc];
    return t;
}

NSMenuItem* addItem(NSMenu* menu, NSString* title, SEL sel, NSString* key, NSEventModifierFlags mods, id target) {
    NSMenuItem* it = [menu addItemWithTitle:title action:sel keyEquivalent:key ?: @""];
    it.keyEquivalentModifierMask = mods;
    if (sel != nil && sel != @selector(terminate:) && sel != @selector(orderFrontStandardAboutPanel:)) it.target = target;
    return it;
}

NSString* fkey(unichar c) { return [NSString stringWithCharacters:&c length:1]; }
} // namespace

@implementation SilvetonController (Panels)

// ======================================================= current strip data ==
- (std::vector<ProjectSend>*)sendsOfStrip:(SVStrip)s {
    Project& p = _core->project();
    if (s.kind == SVStripKind::Track && s.index < p.tracks.size()) return &p.tracks[s.index].sends;
    if (s.kind == SVStripKind::Bus && s.index < p.buses.size()) return &p.buses[s.index].sends;
    return nullptr;
}

- (std::string)pluginNameOfSlot:(const ProjectPluginSlot&)slot {
    if (isNativeModulePath(slot.modulePath))
        for (const auto& i : nativePluginCatalog()) if (i.classId == slot.classId) return i.name;
    std::string n = slot.modulePath;
    const auto sl = n.find_last_of('/');
    if (sl != std::string::npos) n = n.substr(sl + 1);
    const auto d = n.find_last_of('.');
    if (d != std::string::npos) n = n.substr(0, d);
    return n.empty() ? slot.classId : n;
}

// ================================================================ inspector ==
- (void)buildChannelPanelIn:(NSRect)frame {
    const CGFloat W = frame.size.width;
    _channelScroll = [[NSScrollView alloc] initWithFrame:frame];
    _channelScroll.hasVerticalScroller = YES;
    _channelScroll.autohidesScrollers = YES;
    _channelScroll.borderType = NSNoBorder;
    _channelScroll.drawsBackground = YES;
    _channelScroll.backgroundColor = sv::panel();
    _channelScroll.autoresizingMask = NSViewHeightSizable | NSViewMaxXMargin;
    SVFlipView* doc = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, W, 760)];
    doc.fillColor = sv::panel();
    _channelScroll.documentView = doc;
    [_arrangePage addSubview:_channelScroll];

    // ------------------------------------------------ audio / bus / master
    _audioPanel = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, W, 760)];
    _audioPanel.fillColor = sv::panel();
    [doc addSubview:_audioPanel];
    SVFlipView* a = _audioPanel;
    sectionBar(a, @"INSPECTOR", 0, W);
    _cpName = makeField(a, NSMakeRect(8, 24, W - 16, 22), self, @selector(inspectorNameEdited:));
    _cpType = makeLabel(a, @"", NSMakeRect(8, 48, W - 16, 12), sv::ui(8, true), sv::inkFaint());
    _cpColor = makePopup(a, NSMakeRect(8, 64, 118, 22), self, @selector(inspectorColourPicked:));
    {
        NSMenu* m = _cpColor.menu;
        [m removeAllItems];
        NSMenuItem* au = [m addItemWithTitle:@"Auto colour" action:nil keyEquivalent:@""];
        au.tag = 0;
        static NSString* names[16] = {@"Copper", @"Sage", @"Slate", @"Rose", @"Brass", @"Teal", @"Lavender", @"Brick",
                                      @"Moss", @"Ocean", @"Walnut", @"Ice", @"Mustard", @"Plum", @"Pine", @"Dusk"};
        for (int i = 0; i < 16; ++i) {
            NSMenuItem* it = [m addItemWithTitle:names[i] action:nil keyEquivalent:@""];
            it.tag = static_cast<NSInteger>(silvetonPaletteColor(static_cast<std::size_t>(i)));
        }
    }
    _cpLock = [SVToggle toggleWithTitle:@"LOCK" color:sv::inkDim() target:self action:@selector(inspectorLock:) frame:NSMakeRect(134, 65, 82, 20)];
    [a addSubview:_cpLock];
    _cpMute = [SVToggle toggleWithTitle:@"M" color:sv::muteTint() target:self action:@selector(inspectorMute:) frame:NSMakeRect(8, 92, 48, 20)];
    _cpSolo = [SVToggle toggleWithTitle:@"S" color:sv::soloTint() target:self action:@selector(inspectorSolo:) frame:NSMakeRect(60, 92, 48, 20)];
    _cpArm = [SVToggle toggleWithTitle:@"●" color:sv::rec() target:self action:@selector(inspectorArm:) frame:NSMakeRect(112, 92, 48, 20)];
    _cpMonitor = [SVToggle toggleWithTitle:@"MON" color:sv::amber() target:self action:@selector(inspectorMonitor:) frame:NSMakeRect(164, 92, 52, 20)];
    for (NSView* v in @[_cpMute, _cpSolo, _cpArm, _cpMonitor]) [a addSubview:v];

    sectionBar(a, @"FADER", 120, W);
    makeLabel(a, @"Volume", NSMakeRect(8, 144, 44, 14), sv::ui(9), sv::inkDim());
    _cpVolume = [[SVResetSlider alloc] initWithFrame:NSMakeRect(54, 142, 98, 18)];
    _cpVolume.minValue = 0.0; _cpVolume.maxValue = 1.0;
    _cpVolume.resetValue = faderPositionForDb(0.0);
    _cpVolume.target = self; _cpVolume.action = @selector(inspectorVolume:);
    _cpVolume.beginAction = @selector(inspectorGestureBegin:); _cpVolume.endAction = @selector(inspectorGestureEnd:);
    [a addSubview:_cpVolume];
    _cpVolumeValue = makeLabel(a, @"", NSMakeRect(154, 144, 62, 14), sv::mono(9.5, true), sv::ink(), NSTextAlignmentRight);
    makeLabel(a, @"Pan", NSMakeRect(8, 168, 44, 14), sv::ui(9), sv::inkDim());
    _cpPan = [[SVResetSlider alloc] initWithFrame:NSMakeRect(54, 166, 98, 18)];
    _cpPan.minValue = -1.0; _cpPan.maxValue = 1.0; _cpPan.resetValue = 0.0;
    _cpPan.target = self; _cpPan.action = @selector(inspectorPan:);
    _cpPan.beginAction = @selector(inspectorGestureBegin:); _cpPan.endAction = @selector(inspectorGestureEnd:);
    [a addSubview:_cpPan];
    _cpPanValue = makeLabel(a, @"", NSMakeRect(154, 168, 62, 14), sv::mono(9.5, true), sv::ink(), NSTextAlignmentRight);

    sectionBar(a, @"ROUTING", 194, W);
    makeLabel(a, @"Output", NSMakeRect(8, 220, 44, 14), sv::ui(9), sv::inkDim());
    _cpOutput = makePopup(a, NSMakeRect(54, 216, W - 62, 22), self, @selector(inspectorOutputPicked:));
    makeLabel(a, @"Auto", NSMakeRect(8, 246, 44, 14), sv::ui(9), sv::inkDim());
    _cpAutomation = makePopup(a, NSMakeRect(54, 242, W - 62, 22), self, @selector(inspectorAutomationPicked:));
    [_cpAutomation addItemsWithTitles:@[@"Off", @"Read", @"Write", @"Touch", @"Latch"]];

    sectionBar(a, @"INSERTS", 274, W);
    _insertTable = makeTable(a, NSMakeRect(6, 296, W - 12, 124), @[@[@"on", @"", @"18"], @[@"name", @"", @"170"]], self, NO);
    _insertTable.doubleAction = @selector(inspectorInsertDouble:);
    _insertTable.target = self;
    {
        const CGFloat bw = (W - 12 - 9) / 4.0;
        NSArray* titles = @[@"+", @"−", @"BYPASS", @"EDIT"];
        NSArray* sels = @[@"inspectorInsertAdd:", @"inspectorInsertRemove:", @"inspectorInsertBypass:", @"inspectorInsertEdit:"];
        for (int i = 0; i < 4; ++i)
            [a addSubview:[SVButton buttonWithTitle:titles[i] target:self action:NSSelectorFromString(sels[i]) frame:NSMakeRect(6 + i * (bw + 3), 424, bw, 20)]];
    }

    sectionBar(a, @"SENDS", 452, W);
    _sendTable = makeTable(a, NSMakeRect(6, 474, W - 12, 70), @[@[@"dest", @"", @"110"], @[@"level", @"", @"60"]], self, NO);
    {
        [a addSubview:[SVButton buttonWithTitle:@"+" target:self action:@selector(inspectorSendAdd:) frame:NSMakeRect(6, 548, 44, 20)]];
        [a addSubview:[SVButton buttonWithTitle:@"−" target:self action:@selector(inspectorSendRemove:) frame:NSMakeRect(53, 548, 44, 20)]];
        _sendPre = [SVToggle toggleWithTitle:@"PRE" color:sv::copper() target:self action:@selector(inspectorSendPre:) frame:NSMakeRect(100, 548, 44, 20)];
        [a addSubview:_sendPre];
    }
    _sendLevel = [[SVResetSlider alloc] initWithFrame:NSMakeRect(6, 572, 140, 18)];
    _sendLevel.minValue = -60.0; _sendLevel.maxValue = 6.0; _sendLevel.resetValue = 0.0;
    _sendLevel.target = self; _sendLevel.action = @selector(inspectorSendLevel:);
    _sendLevel.beginAction = @selector(inspectorGestureBegin:); _sendLevel.endAction = @selector(inspectorGestureEnd:);
    [a addSubview:_sendLevel];
    _sendLevelValue = makeLabel(a, @"", NSMakeRect(150, 574, 66, 14), sv::mono(9.5, true), sv::ink(), NSTextAlignmentRight);

    sectionBar(a, @"NOTEPAD", 600, W);
    _cpNotes = makeField(a, NSMakeRect(8, 622, W - 16, 70), self, @selector(inspectorNotesEdited:));
    [(NSTextFieldCell*)_cpNotes.cell setUsesSingleLineMode:NO];
    [(NSTextFieldCell*)_cpNotes.cell setWraps:YES];
    [(NSTextFieldCell*)_cpNotes.cell setScrollable:NO];

    // ----------------------------------------------------------- MIDI track
    _midiPanel = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, W, 760)];
    _midiPanel.fillColor = sv::panel();
    [doc addSubview:_midiPanel];
    SVFlipView* m = _midiPanel;
    sectionBar(m, @"INSPECTOR · MIDI TRACK", 0, W);
    _mpName = makeField(m, NSMakeRect(8, 24, W - 16, 22), self, @selector(inspectorMidiNameEdited:));
    _mpColor = makePopup(m, NSMakeRect(8, 54, 118, 22), self, @selector(inspectorMidiColourPicked:));
    for (NSMenuItem* it in _cpColor.menu.itemArray) {
        NSMenuItem* copy = [_mpColor.menu addItemWithTitle:it.title action:nil keyEquivalent:@""];
        copy.tag = it.tag;
    }
    _mpMute = [SVToggle toggleWithTitle:@"M" color:sv::muteTint() target:self action:@selector(inspectorMidiMute:) frame:NSMakeRect(134, 55, 38, 20)];
    _mpSolo = [SVToggle toggleWithTitle:@"S" color:sv::soloTint() target:self action:@selector(inspectorMidiSolo:) frame:NSMakeRect(176, 55, 38, 20)];
    [m addSubview:_mpMute]; [m addSubview:_mpSolo];
    sectionBar(m, @"ROUTING", 88, W);
    makeLabel(m, @"Out", NSMakeRect(8, 114, 44, 14), sv::ui(9), sv::inkDim());
    _mpOutput = makePopup(m, NSMakeRect(54, 110, W - 62, 22), self, @selector(inspectorMidiOutputPicked:));
    sectionBar(m, @"MIDI MODIFIERS", 144, W);
    makeLabel(m, @"Transpose", NSMakeRect(8, 170, 70, 14), sv::ui(9), sv::inkDim());
    _mpTranspose = makeField(m, NSMakeRect(100, 166, 60, 22), self, @selector(inspectorMidiModifiers:));
    makeLabel(m, @"semitones", NSMakeRect(164, 170, 56, 14), sv::ui(8), sv::inkFaint());
    makeLabel(m, @"Velocity", NSMakeRect(8, 198, 70, 14), sv::ui(9), sv::inkDim());
    _mpVelocity = makeField(m, NSMakeRect(100, 194, 60, 22), self, @selector(inspectorMidiModifiers:));
    makeLabel(m, @"added to note-on", NSMakeRect(164, 198, 56, 24), sv::ui(8), sv::inkFaint());
    makeLabel(m, @"Double-click a part in the Project window to open it in the Key Editor.", NSMakeRect(8, 236, W - 16, 40), sv::ui(9), sv::inkFaint());
    ((NSTextField*)m.subviews.lastObject).lineBreakMode = NSLineBreakByWordWrapping;
    ((NSTextField*)m.subviews.lastObject).maximumNumberOfLines = 3;
}

// Refresh all inspector controls from the model.
- (void)refreshChannelPanel {
    if (!_core || !_audioPanel) return;
    _updating = YES;
    Project& p = _core->project();
    const BOOL midi = self.selectedMidiTrack >= 0 && self.selectedMidiTrack < static_cast<long>(p.midiTracks.size());
    _audioPanel.hidden = midi;
    _midiPanel.hidden = !midi;
    if (midi) {
        const auto& mt = p.midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)];
        _mpName.stringValue = sv::ns(mt.name);
        [_mpColor selectItemWithTag:mt.color];
        if (_mpColor.indexOfSelectedItem < 0) [_mpColor selectItemAtIndex:0];
        _mpMute.state = mt.mute ? NSControlStateValueOn : NSControlStateValueOff;
        _mpSolo.state = mt.solo ? NSControlStateValueOn : NSControlStateValueOff;
        [_mpOutput removeAllItems];
        [_mpOutput addItemWithTitle:@"No output"];
        _mpOutput.lastItem.tag = -1;
        for (std::size_t i = 0; i < p.tracks.size(); ++i)
            for (const auto& s : p.tracks[i].pluginSlots)
                if (s.midiInputPort >= 0) {
                    [_mpOutput addItemWithTitle:[NSString stringWithFormat:@"→ %@", sv::ns(p.tracks[i].name)]];
                    _mpOutput.lastItem.tag = s.midiInputPort;
                }
        [_mpOutput selectItemWithTag:mt.outputPort];
        if (!_mpTranspose.currentEditor) _mpTranspose.stringValue = [NSString stringWithFormat:@"%d", mt.transpose];
        if (!_mpVelocity.currentEditor) _mpVelocity.stringValue = [NSString stringWithFormat:@"%d", mt.velocityShift];
        _updating = NO;
        return;
    }
    const SVStrip s = _strip;
    std::string name = "Master", type = "MASTER";
    std::uint32_t color = 0;
    double gain = p.masterFaderDb, pan = 0;
    bool mute = false, solo = false, arm = false, mon = false, locked = false, isTrack = false, isBus = false;
    const std::vector<ProjectPluginSlot>* slots = &p.masterPluginSlots;
    int output = -1;
    std::string notes;
    AutomationMode mode = AutomationMode::Read;
    if (s.kind == SVStripKind::Track && s.index < p.tracks.size()) {
        const auto& t = p.tracks[s.index];
        isTrack = true; name = t.name; color = t.color; gain = t.gainDb; pan = t.pan; mute = t.mute; solo = t.solo;
        arm = t.recordArm; mon = t.monitor; locked = t.locked; slots = &t.pluginSlots; output = t.outputBus; notes = t.notes;
        mode = t.gainAutomationMode;
        bool instrument = false;
        for (const auto& sl : t.pluginSlots) if (sl.midiInputPort >= 0) instrument = true;
        type = instrument ? "INSTRUMENT TRACK" : "AUDIO TRACK";
    } else if (s.kind == SVStripKind::Bus && s.index < p.buses.size()) {
        const auto& b = p.buses[s.index];
        isBus = true; name = b.name; color = b.color; gain = b.gainDb; mute = b.mute; solo = b.solo; slots = &b.pluginSlots; output = b.outputBus;
        type = b.kind == ProjectBusKind::Group ? "GROUP CHANNEL" : "FX CHANNEL";
    }
    _cpName.stringValue = sv::ns(name);
    _cpName.enabled = isTrack || isBus;
    _cpType.stringValue = sv::ns(type);
    [_cpColor selectItemWithTag:color];
    if (_cpColor.indexOfSelectedItem < 0) [_cpColor selectItemAtIndex:0];
    _cpColor.enabled = isTrack || isBus;
    _cpMute.state = mute ? NSControlStateValueOn : NSControlStateValueOff;
    _cpSolo.state = solo ? NSControlStateValueOn : NSControlStateValueOff;
    _cpArm.state = arm ? NSControlStateValueOn : NSControlStateValueOff;
    _cpMonitor.state = mon ? NSControlStateValueOn : NSControlStateValueOff;
    _cpLock.state = locked ? NSControlStateValueOn : NSControlStateValueOff;
    _cpMute.enabled = _cpSolo.enabled = isTrack || isBus;
    _cpArm.enabled = _cpMonitor.enabled = _cpLock.enabled = isTrack;
    _cpVolume.doubleValue = faderPositionForDb(gain);
    _cpVolumeValue.stringValue = gain <= -95.9 ? @"-∞ dB" : [NSString stringWithFormat:@"%+.1f dB", gain];
    _cpPan.doubleValue = pan;
    _cpPan.enabled = isTrack;
    _cpPanValue.stringValue = !isTrack ? @"" : (std::abs(pan) < 0.005 ? @"C" : [NSString stringWithFormat:@"%@%d", pan < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(pan) * 100))]);
    [_cpOutput removeAllItems];
    [_cpOutput addItemWithTitle:s.kind == SVStripKind::Master ? @"Device" : @"Stereo Out"];
    _cpOutput.lastItem.tag = -1;
    for (std::size_t i = 0; i < p.buses.size(); ++i) {
        if (isBus && i == s.index) continue;
        [_cpOutput addItemWithTitle:sv::ns(p.buses[i].name)];
        _cpOutput.lastItem.tag = static_cast<NSInteger>(i);
    }
    [_cpOutput selectItemWithTag:output];
    _cpOutput.enabled = isTrack || isBus;
    _cpAutomation.enabled = isTrack;
    [_cpAutomation selectItemAtIndex:static_cast<NSInteger>(mode)];
    _cpNotes.enabled = isTrack;
    if (!_cpNotes.currentEditor) _cpNotes.stringValue = sv::ns(notes);
    _insertSlotCount = slots ? slots->size() : 0U;
    [_insertTable reloadData];
    if (_insertRow >= 0 && _insertRow < static_cast<long>(_insertSlotCount)) [_insertTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(_insertRow)] byExtendingSelection:NO];
    const auto* sends = (isTrack || isBus) ? [self sendsOfStrip:s] : nullptr;
    [_sendTable reloadData];
    if (_sendRow >= 0 && sends && _sendRow < static_cast<long>(sends->size())) {
        [_sendTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(_sendRow)] byExtendingSelection:NO];
        const auto& sd = (*sends)[static_cast<std::size_t>(_sendRow)];
        _sendPre.state = sd.preFader ? NSControlStateValueOn : NSControlStateValueOff;
        _sendLevel.doubleValue = sd.gainDb;
        _sendLevelValue.stringValue = [NSString stringWithFormat:@"%+.1f dB", sd.gainDb];
    } else {
        _sendLevelValue.stringValue = @"";
    }
    _sendPre.enabled = _sendLevel.enabled = sends && _sendRow >= 0 && _sendRow < static_cast<long>(sends->size());
    _updating = NO;
}

// ------------------------------------------------------- inspector actions --
- (void)inspectorGestureBegin:(id)sender { (void)sender; [self beginGesture:@"Inspector"]; }
- (void)inspectorGestureEnd:(id)sender { (void)sender; [self endGesture]; }

- (void)inspectorNameEdited:(NSTextField*)f {
    if (_updating) return;
    const SVStrip s = _strip;
    const std::string n = sv::str(f.stringValue);
    [self runEdit:@"Rename" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (s.kind == SVStripKind::Track && s.index < p.tracks.size()) p.tracks[s.index].name = n;
        else if (s.kind == SVStripKind::Bus && s.index < p.buses.size()) p.buses[s.index].name = n;
    }];
}
- (void)inspectorColourPicked:(NSPopUpButton*)pop {
    if (_updating) return;
    const SVStrip s = _strip;
    const auto color = static_cast<std::uint32_t>(pop.selectedItem.tag);
    [self runEdit:@"Colour" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (s.kind == SVStripKind::Track && s.index < p.tracks.size()) p.tracks[s.index].color = color;
        else if (s.kind == SVStripKind::Bus && s.index < p.buses.size()) p.buses[s.index].color = color;
    }];
}
- (void)inspectorMute:(id)sender { (void)sender; if (!_updating) [self toggleStripMute:_strip]; }
- (void)inspectorSolo:(id)sender { (void)sender; if (!_updating) [self toggleStripSolo:_strip]; }
- (void)inspectorArm:(id)sender {
    (void)sender;
    if (_updating || _strip.kind != SVStripKind::Track) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = _strip.index;
    [self toggleArm:r];
}
- (void)inspectorMonitor:(id)sender {
    (void)sender;
    if (_updating || _strip.kind != SVStripKind::Track) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = _strip.index;
    [self toggleMonitor:r];
}
- (void)inspectorLock:(id)sender { (void)sender; if (!_updating && _strip.kind == SVStripKind::Track) { self.selectedTrack = static_cast<long>(_strip.index); [self toggleLock:nil]; } }
- (void)inspectorVolume:(SVResetSlider*)sl {
    if (_updating) return;
    [self setStrip:_strip gainDb:dbForFaderPosition(sl.doubleValue)];
    const double db = dbForFaderPosition(sl.doubleValue);
    _cpVolumeValue.stringValue = db <= -95.9 ? @"-∞ dB" : [NSString stringWithFormat:@"%+.1f dB", db];
    [_arrange setNeedsDisplay:YES];
}
- (void)inspectorPan:(SVResetSlider*)sl {
    if (_updating) return;
    [self setStrip:_strip pan:sl.doubleValue];
    const double pan = sl.doubleValue;
    _cpPanValue.stringValue = std::abs(pan) < 0.005 ? @"C" : [NSString stringWithFormat:@"%@%d", pan < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(pan) * 100))];
}
- (void)inspectorOutputPicked:(NSPopUpButton*)pop {
    if (_updating) return;
    _menuStrip = _strip;
    [self routeFromMenu:pop.selectedItem];
}
- (void)inspectorAutomationPicked:(NSPopUpButton*)pop {
    if (_updating || _strip.kind != SVStripKind::Track) return;
    const auto mode = static_cast<AutomationMode>(pop.indexOfSelectedItem);
    const std::size_t i = _strip.index;
    [self runEdit:@"Automation Mode" rebuild:NO block:^{
        auto& t = self->_core->project().tracks.at(i);
        t.gainAutomationMode = mode; t.panAutomationMode = mode; t.muteAutomationMode = mode;
    }];
    [self applyMixerLive];
}
- (void)inspectorNotesEdited:(NSTextField*)f {
    if (_updating || _strip.kind != SVStripKind::Track) return;
    const std::size_t i = _strip.index;
    const std::string n = sv::str(f.stringValue);
    [self runEdit:@"Track Notes" rebuild:NO block:^{ self->_core->project().tracks.at(i).notes = n; }];
}

- (void)inspectorInsertAdd:(NSButton*)b {
    NSMenu* menu = [self insertMenuForStrip:_strip];
    [menu popUpMenuPositioningItem:nil atLocation:NSMakePoint(0, b.bounds.size.height) inView:b];
}
- (void)inspectorInsertRemove:(id)sender {
    (void)sender;
    if (_insertRow < 0) return;
    NSMenuItem* it = [[NSMenuItem alloc] init];
    it.tag = _insertRow;
    _menuStrip = _strip;
    _insertRow = -1;
    [self removeInsertFromMenu:it];
}
- (void)inspectorInsertBypass:(id)sender {
    (void)sender;
    if (_insertRow < 0) return;
    NSMenuItem* it = [[NSMenuItem alloc] init];
    it.tag = _insertRow;
    _menuStrip = _strip;
    [self toggleBypassFromMenu:it];
}
- (void)inspectorInsertEdit:(id)sender {
    (void)sender;
    if (_insertRow >= 0) [self openInsertEditor:_strip slot:static_cast<std::size_t>(_insertRow)];
}
- (void)inspectorInsertDouble:(id)sender {
    (void)sender;
    const NSInteger r = _insertTable.clickedRow;
    if (r >= 0 && r < static_cast<NSInteger>(_insertSlotCount)) [self openInsertEditor:_strip slot:static_cast<std::size_t>(r)];
    else if (r < 0 || r >= static_cast<NSInteger>(_insertSlotCount)) {
        NSMenu* menu = [self insertMenuForStrip:_strip];
        [menu popUpMenuPositioningItem:nil atLocation:[NSEvent mouseLocation] inView:nil];
    }
}

- (void)inspectorSendAdd:(NSButton*)b {
    if (_strip.kind == SVStripKind::Master) return;
    _menuStrip = _strip;
    NSMenu* menu = [[NSMenu alloc] initWithTitle:@"Send to"];
    const Project& p = _core->project();
    for (std::size_t i = 0; i < p.buses.size(); ++i) {
        if (_strip.kind == SVStripKind::Bus && i == _strip.index) continue;
        NSMenuItem* it = [menu addItemWithTitle:sv::ns(p.buses[i].name) action:@selector(addSendFromMenu:) keyEquivalent:@""];
        it.tag = static_cast<NSInteger>(i);
        it.target = self;
    }
    if (menu.itemArray.count == 0) { [self setStatus:@"Add a Group or FX channel first (Project ▸ Add FX Channel)"]; return; }
    [menu popUpMenuPositioningItem:nil atLocation:NSMakePoint(0, b.bounds.size.height) inView:b];
}
- (void)inspectorSendRemove:(id)sender {
    (void)sender;
    const SVStrip s = _strip;
    const long row = _sendRow;
    if (row < 0) return;
    _sendRow = -1;
    [self runEdit:@"Remove Send" rebuild:YES block:^{
        auto* sends = [self sendsOfStrip:s];
        if (sends && row < static_cast<long>(sends->size())) sends->erase(sends->begin() + row);
    }];
}
- (void)inspectorSendPre:(id)sender {
    (void)sender;
    if (_updating || _sendRow < 0) return;
    const SVStrip s = _strip;
    const long row = _sendRow;
    [self runEdit:@"Send Pre/Post" rebuild:YES block:^{
        auto* sends = [self sendsOfStrip:s];
        if (sends && row < static_cast<long>(sends->size())) (*sends)[static_cast<std::size_t>(row)].preFader = !(*sends)[static_cast<std::size_t>(row)].preFader;
    }];
}
- (void)inspectorSendLevel:(SVResetSlider*)sl {
    if (_updating || _sendRow < 0) return;
    auto* sends = [self sendsOfStrip:_strip];
    if (!sends || _sendRow >= static_cast<long>(sends->size())) return;
    (*sends)[static_cast<std::size_t>(_sendRow)].gainDb = static_cast<float>(sl.doubleValue);
    _sendLevelValue.stringValue = [NSString stringWithFormat:@"%+.1f dB", sl.doubleValue];
    if (_gestureOpen) _gestureNeedsRebuild = YES; else [self requestRebuild];
    _core->session().markDirty();
    [_sendTable reloadData];
}

- (void)inspectorMidiNameEdited:(NSTextField*)f {
    if (_updating || self.selectedMidiTrack < 0) return;
    const std::size_t i = static_cast<std::size_t>(self.selectedMidiTrack);
    const std::string n = sv::str(f.stringValue);
    [self runEdit:@"Rename" rebuild:NO block:^{ self->_core->project().midiTracks.at(i).name = n; }];
}
- (void)inspectorMidiColourPicked:(NSPopUpButton*)pop {
    if (_updating || self.selectedMidiTrack < 0) return;
    const std::size_t i = static_cast<std::size_t>(self.selectedMidiTrack);
    const auto color = static_cast<std::uint32_t>(pop.selectedItem.tag);
    [self runEdit:@"Colour" rebuild:NO block:^{ self->_core->project().midiTracks.at(i).color = color; }];
}
- (void)inspectorMidiMute:(id)sender {
    (void)sender;
    if (_updating || self.selectedMidiTrack < 0) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Midi; r.index = static_cast<std::size_t>(self.selectedMidiTrack);
    [self toggleMute:r];
}
- (void)inspectorMidiSolo:(id)sender {
    (void)sender;
    if (_updating || self.selectedMidiTrack < 0) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Midi; r.index = static_cast<std::size_t>(self.selectedMidiTrack);
    [self toggleSolo:r];
}
- (void)inspectorMidiOutputPicked:(NSPopUpButton*)pop {
    if (_updating || self.selectedMidiTrack < 0) return;
    _menuRow.kind = ArrangeRowKind::Midi;
    _menuRow.index = static_cast<std::size_t>(self.selectedMidiTrack);
    [self setMidiOutput:pop.selectedItem];
}
- (void)inspectorMidiModifiers:(id)sender {
    (void)sender;
    if (_updating || self.selectedMidiTrack < 0) return;
    const std::size_t i = static_cast<std::size_t>(self.selectedMidiTrack);
    const int tr = std::clamp(_mpTranspose.intValue, -48, 48);
    const int vel = std::clamp(_mpVelocity.intValue, -126, 126);
    [self runEdit:@"MIDI Modifiers" rebuild:NO block:^{
        auto& mt = self->_core->project().midiTracks.at(i);
        mt.transpose = tr; mt.velocityShift = vel;
    }];
    [self republishMidi];
}

// ================================================================ tables ==
- (NSInteger)numberOfRowsInTableView:(NSTableView*)tv {
    if (!_core) return 0;
    const Project& p = _core->project();
    if (tv == _insertTable) return static_cast<NSInteger>(std::min<std::size_t>(16U, _insertSlotCount + 1U));
    if (tv == _sendTable) { const auto* s = (_strip.kind == SVStripKind::Master) ? nullptr : [self sendsOfStrip:_strip]; return s ? static_cast<NSInteger>(s->size()) : 0; }
    if (tv == _pluginTable) return static_cast<NSInteger>(_pluginResults.size());
    if (tv == _poolTable) return static_cast<NSInteger>(_pool.size());
    if (tv == _markerTable) return static_cast<NSInteger>(p.markers.size());
    if (tv == _sectionTable) return static_cast<NSInteger>(p.arrangerSections.size());
    if (tv == _chainTable) return static_cast<NSInteger>(p.arrangerChain.size());
    return 0;
}

- (NSView*)tableView:(NSTableView*)tv viewForTableColumn:(NSTableColumn*)col row:(NSInteger)row {
    if (!_core) return nil;
    const Project& p = _core->project();
    NSString* s = @"";
    NSColor* color = sv::ink();
    NSString* ident = col.identifier;
    const auto r = static_cast<std::size_t>(std::max<NSInteger>(0, row));
    if (tv == _insertTable) {
        if (r < _insertSlotCount) {
            const auto* slots = [self slotsForStrip:_strip];
            if (slots && r < slots->size()) {
                const auto& sl = (*slots)[r];
                if ([ident isEqualToString:@"on"]) { s = sl.enabled ? @"●" : @"○"; color = sl.enabled ? sv::sage() : sv::inkFaint(); }
                else { s = sv::ns([self pluginNameOfSlot:sl]); color = sl.enabled ? sv::ink() : sv::inkFaint(); }
            }
        } else if ([ident isEqualToString:@"name"]) { s = @"—  (double-click to add)"; color = sv::inkFaint(); }
    } else if (tv == _sendTable) {
        const auto* sends = [self sendsOfStrip:_strip];
        if (sends && r < sends->size()) {
            const auto& sd = (*sends)[r];
            if ([ident isEqualToString:@"dest"]) {
                s = (sd.destinationBus >= 0 && static_cast<std::size_t>(sd.destinationBus) < p.buses.size()) ? sv::ns(p.buses[static_cast<std::size_t>(sd.destinationBus)].name) : @"?";
                s = [s stringByAppendingString:sd.preFader ? @"  (pre)" : @""];
            } else s = [NSString stringWithFormat:@"%+.1f", sd.gainDb];
        }
    } else if (tv == _pluginTable) {
        if (r < _pluginResults.size()) {
            const auto& e = _pluginResults[r];
            if ([ident isEqualToString:@"name"]) s = sv::ns(e.name);
            else if ([ident isEqualToString:@"vendor"]) s = sv::ns(e.native ? std::string("Silveton") : e.vendor);
            else s = e.instrument ? @"Instrument" : @"Effect";
            if (e.native) color = sv::copper();
        }
    } else if (tv == _poolTable) {
        if (r < _pool.size()) {
            s = [sv::ns(_pool[r]) lastPathComponent];
        }
    } else if (tv == _markerTable) {
        if (r < p.markers.size()) {
            const auto& m = p.markers[r];
            s = [ident isEqualToString:@"name"] ? sv::ns(m.name.empty() ? std::string("Marker") : m.name) : sv::ns(formatBarsBeats(p.tempoMap, m.sample));
        }
    } else if (tv == _sectionTable) {
        if (r < p.arrangerSections.size()) {
            const auto& sc = p.arrangerSections[r];
            if ([ident isEqualToString:@"name"]) s = sv::ns(sc.name);
            else s = [NSString stringWithFormat:@"%@ → %@", sv::ns(formatBarsBeats(p.tempoMap, sc.startSample)), sv::ns(formatBarsBeats(p.tempoMap, sc.endSample))];
        }
    } else if (tv == _chainTable) {
        if (r < p.arrangerChain.size()) {
            const auto& step = p.arrangerChain[r];
            if (const auto* sc = ArrangerTools::find(p, step.sectionId)) {
                s = [ident isEqualToString:@"name"] ? sv::ns(sc->name) : [NSString stringWithFormat:@"×%u", step.repeats];
            } else s = @"(missing)";
        }
    }
    NSTextField* f = [NSTextField labelWithString:s];
    f.font = sv::ui(10);
    f.textColor = color;
    f.lineBreakMode = NSLineBreakByTruncatingTail;
    return f;
}

- (void)tableViewSelectionDidChange:(NSNotification*)n {
    NSTableView* tv = n.object;
    if (_updating) return;
    if (tv == _insertTable) {
        const NSInteger r = tv.selectedRow;
        _insertRow = (r >= 0 && r < static_cast<NSInteger>(_insertSlotCount)) ? r : -1;
    } else if (tv == _sendTable) {
        _sendRow = tv.selectedRow;
        [self refreshChannelPanel];
    }
}

// =================================================================== library ==
- (void)reloadPluginResults {
    _pluginResults.clear();
    NSString* q = _pluginSearch ? _pluginSearch.stringValue.lowercaseString : @"";
    for (const auto& info : nativePluginCatalog()) {
        if (q.length && [sv::ns(info.name).lowercaseString rangeOfString:q].location == NSNotFound) continue;
        SVPluginEntry e;
        e.native = true; e.instrument = info.instrument; e.modulePath = kNativeModulePath; e.classId = info.classId; e.name = info.name; e.vendor = "Silveton";
        _pluginResults.push_back(e);
    }
    if (_browser) {
        for (const auto& c : _browser->search(sv::str(q))) {
            SVPluginEntry e;
            e.modulePath = c.modulePath; e.classId = c.classId; e.name = c.name; e.vendor = c.vendor;
            for (const auto& sc : c.subCategories) if (sc.find("Instrument") != std::string::npos || sc.find("Synth") != std::string::npos) e.instrument = true;
            _pluginResults.push_back(e);
        }
    }
    [_pluginTable reloadData];
}

- (void)controlTextDidChange:(NSNotification*)n {
    if (n.object == _pluginSearch) [self reloadPluginResults];
}

- (void)libraryAddInsert:(id)sender {
    (void)sender;
    const NSInteger r = _pluginTable.selectedRow;
    if (r < 0 || r >= static_cast<NSInteger>(_pluginResults.size())) { [self setStatus:@"Select a plug-in in the list first"]; return; }
    const SVPluginEntry e = _pluginResults[static_cast<std::size_t>(r)];
    if (e.instrument) { [self addInstrumentTrackWith:e]; return; }
    [self insertPluginEntry:e intoStrip:_strip];
}

- (void)libraryAddInstrument:(id)sender {
    (void)sender;
    const NSInteger r = _pluginTable.selectedRow;
    if (r < 0 || r >= static_cast<NSInteger>(_pluginResults.size())) { [self setStatus:@"Select an instrument in the list first"]; return; }
    const SVPluginEntry e = _pluginResults[static_cast<std::size_t>(r)];
    if (!e.instrument) { [self setStatus:@"That plug-in is an effect — use “Add as Insert”"]; return; }
    [self addInstrumentTrackWith:e];
}

- (void)libraryGoMarker:(id)sender {
    (void)sender;
    const NSInteger r = _markerTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.markers.size())) return;
    _menuMarker = p.markers[static_cast<std::size_t>(r)].id;
    [self gotoMarkerFromMenu:nil];
}
- (void)libraryDeleteMarker:(id)sender {
    (void)sender;
    const NSInteger r = _markerTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.markers.size())) return;
    _menuMarker = p.markers[static_cast<std::size_t>(r)].id;
    [self deleteMarkerFromMenu:nil];
}
- (void)libraryLoopSection:(id)sender {
    (void)sender;
    const NSInteger r = _sectionTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.arrangerSections.size())) return;
    _menuSection = p.arrangerSections[static_cast<std::size_t>(r)].id;
    [self loopSectionFromMenu:nil];
}
- (void)libraryAppendSection:(id)sender {
    (void)sender;
    const NSInteger r = _sectionTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.arrangerSections.size())) return;
    _menuSection = p.arrangerSections[static_cast<std::size_t>(r)].id;
    [self appendSectionFromMenu:nil];
}
- (void)libraryDeleteSection:(id)sender {
    (void)sender;
    const NSInteger r = _sectionTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.arrangerSections.size())) return;
    _menuSection = p.arrangerSections[static_cast<std::size_t>(r)].id;
    [self deleteSectionFromMenu:nil];
}
- (void)libraryRemoveChainStep:(id)sender {
    (void)sender;
    const NSInteger r = _chainTable.selectedRow;
    if (r < 0 || r >= static_cast<NSInteger>(_core->project().arrangerChain.size())) return;
    [self runEdit:@"Remove Chain Step" rebuild:NO block:^{ ArrangerTools::removeChainStep(self->_core->project(), static_cast<std::size_t>(r)); }];
}
- (void)libraryChainUp:(id)sender {
    (void)sender;
    const NSInteger r = _chainTable.selectedRow;
    if (r < 1 || r >= static_cast<NSInteger>(_core->project().arrangerChain.size())) return;
    [self runEdit:@"Move Chain Step" rebuild:NO block:^{ ArrangerTools::moveChainStep(self->_core->project(), static_cast<std::size_t>(r), static_cast<std::size_t>(r - 1)); }];
    [_chainTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(r - 1)] byExtendingSelection:NO];
}

- (void)buildLibraryPage:(NSView*)page {
    const NSRect b = page.bounds;
    const CGFloat H = b.size.height;
    const CGFloat leftW = std::floor(b.size.width * 0.40), midW = std::floor(b.size.width * 0.24);
    const CGFloat rightW = b.size.width - leftW - midW;
    SVFlipView* bg = [[SVFlipView alloc] initWithFrame:b];
    bg.fillColor = sv::canvas();
    bg.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [page addSubview:bg];
    // Plug-ins
    SVFlipView* L = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, leftW, H)];
    L.fillColor = sv::panel();
    L.autoresizingMask = NSViewHeightSizable | NSViewMaxXMargin;
    [bg addSubview:L];
    sectionBar(L, @"PLUG-INS  ·  SILVETON NATIVE + VST3", 0, leftW);
    _pluginSearch = [[NSSearchField alloc] initWithFrame:NSMakeRect(8, 26, leftW - 16, 22)];
    _pluginSearch.delegate = self;
    _pluginSearch.placeholderString = @"Search plug-ins";
    [L addSubview:_pluginSearch];
    _pluginTable = makeTable(L, NSMakeRect(8, 54, leftW - 16, H - 54 - 40), @[@[@"name", @"Name", @"200"], @[@"vendor", @"Vendor", @"120"], @[@"kind", @"Type", @"80"]], self, YES);
    _pluginTable.target = self;
    _pluginTable.doubleAction = @selector(libraryAddInsert:);
    _pluginTable.superview.superview.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    SVButton* b1 = [SVButton buttonWithTitle:@"Add as Insert" target:self action:@selector(libraryAddInsert:) frame:NSMakeRect(8, H - 32, 110, 22)];
    SVButton* b2 = [SVButton buttonWithTitle:@"Add Instrument Track" target:self action:@selector(libraryAddInstrument:) frame:NSMakeRect(122, H - 32, 150, 22)];
    SVButton* b3 = [SVButton buttonWithTitle:@"Scan VST3" target:self action:@selector(scanPlugins:) frame:NSMakeRect(276, H - 32, 90, 22)];
    for (SVButton* x in @[b1, b2, b3]) { x.autoresizingMask = NSViewMinYMargin; [L addSubview:x]; }
    // Pool
    SVFlipView* M = [[SVFlipView alloc] initWithFrame:NSMakeRect(leftW, 0, midW, H)];
    M.fillColor = sv::hex(0x2A2A2C);
    M.autoresizingMask = NSViewHeightSizable | NSViewMinXMargin | NSViewMaxXMargin;
    [bg addSubview:M];
    sectionBar(M, @"POOL  ·  AUDIO IN THIS PROJECT", 0, midW);
    _poolTable = makeTable(M, NSMakeRect(8, 26, midW - 16, H - 26 - 40), @[@[@"file", @"File", @"260"]], self, NO);
    _poolTable.superview.superview.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    SVButton* imp = [SVButton buttonWithTitle:@"Import Audio…" target:self action:@selector(importAudio:) frame:NSMakeRect(8, H - 32, 110, 22)];
    imp.autoresizingMask = NSViewMinYMargin;
    [M addSubview:imp];
    // Markers / arranger
    SVFlipView* R = [[SVFlipView alloc] initWithFrame:NSMakeRect(leftW + midW, 0, rightW, H)];
    R.fillColor = sv::panel();
    R.autoresizingMask = NSViewHeightSizable | NSViewMinXMargin;
    [bg addSubview:R];
    const CGFloat third = std::floor((H - 3 * 18 - 3 * 34) / 3.0);
    CGFloat y = 0;
    sectionBar(R, @"MARKERS", y, rightW); y += 22;
    _markerTable = makeTable(R, NSMakeRect(8, y, rightW - 16, third), @[@[@"name", @"Name", @"130"], @[@"pos", @"Position", @"90"]], self, NO); y += third + 4;
    [R addSubview:[SVButton buttonWithTitle:@"Add at Playhead" target:self action:@selector(addMarkerAtPlayhead:) frame:NSMakeRect(8, y, 112, 20)]];
    [R addSubview:[SVButton buttonWithTitle:@"Go To" target:self action:@selector(libraryGoMarker:) frame:NSMakeRect(124, y, 60, 20)]];
    [R addSubview:[SVButton buttonWithTitle:@"Delete" target:self action:@selector(libraryDeleteMarker:) frame:NSMakeRect(188, y, 60, 20)]];
    y += 30;
    sectionBar(R, @"ARRANGER SECTIONS", y, rightW); y += 22;
    _sectionTable = makeTable(R, NSMakeRect(8, y, rightW - 16, third), @[@[@"name", @"Name", @"110"], @[@"range", @"Range", @"160"]], self, NO); y += third + 4;
    [R addSubview:[SVButton buttonWithTitle:@"Loop" target:self action:@selector(libraryLoopSection:) frame:NSMakeRect(8, y, 56, 20)]];
    [R addSubview:[SVButton buttonWithTitle:@"Add to Chain" target:self action:@selector(libraryAppendSection:) frame:NSMakeRect(68, y, 96, 20)]];
    [R addSubview:[SVButton buttonWithTitle:@"Delete" target:self action:@selector(libraryDeleteSection:) frame:NSMakeRect(168, y, 60, 20)]];
    y += 30;
    sectionBar(R, @"ARRANGER CHAIN  (play order)", y, rightW); y += 22;
    _chainTable = makeTable(R, NSMakeRect(8, y, rightW - 16, third), @[@[@"name", @"Section", @"150"], @[@"rep", @"Repeats", @"60"]], self, NO); y += third + 4;
    [R addSubview:[SVButton buttonWithTitle:@"Move Up" target:self action:@selector(libraryChainUp:) frame:NSMakeRect(8, y, 66, 20)]];
    [R addSubview:[SVButton buttonWithTitle:@"Remove" target:self action:@selector(libraryRemoveChainStep:) frame:NSMakeRect(78, y, 66, 20)]];
    [R addSubview:[SVButton buttonWithTitle:@"Flatten to Timeline" target:self action:@selector(flattenArranger:) frame:NSMakeRect(148, y, 130, 20)]];
}

- (void)refreshLibrary {
    if (!_core || !_poolTable) return;
    const Project& p = _core->project();
    std::set<std::string> seen;
    _pool.clear();
    auto add = [&](const std::string& path) { if (!path.empty() && seen.insert(path).second) _pool.push_back(path); };
    for (const auto& t : p.tracks) { add(t.audioPath); for (const auto& c : t.clips) add(c.audioPath); }
    [_poolTable reloadData];
    [_markerTable reloadData];
    [_sectionTable reloadData];
    [_chainTable reloadData];
    [_pluginTable reloadData];
}

// ================================================================ edit page ==
- (void)fillTools:(SVFlipView*)view titles:(NSArray<NSString*>*)titles selectors:(NSArray<NSString*>*)sels top:(CGFloat)top {
    const CGFloat colW = (view.bounds.size.width - 8 * 3) / 2.0;
    for (NSUInteger i = 0; i < titles.count; ++i) {
        const CGFloat x = 8 + (i % 2) * (colW + 8);
        const CGFloat y = top + (i / 2) * 26;
        [view addSubview:[SVButton buttonWithTitle:titles[i] target:self action:NSSelectorFromString(sels[i]) frame:NSMakeRect(x, y, colW, 22)]];
    }
}

- (void)gridPicked:(NSPopUpButton*)pop {
    static const std::uint32_t divs[4] = {1U, 2U, 4U, 8U};
    const NSInteger i = std::clamp<NSInteger>(pop.indexOfSelectedItem, 0, 3);
    _gridDiv = divs[i];
    [_noteGrid setNeedsDisplay:YES];
    [_arrange setNeedsDisplay:YES];
}
- (void)swingMoved:(NSSlider*)sl { _swingValue.stringValue = [NSString stringWithFormat:@"%.0f %%", sl.doubleValue]; }

- (void)buildEditPage:(NSView*)page {
    const NSRect b = page.bounds;
    const CGFloat toolsW = 224, topH = 32;
    SVFlipView* bg = [[SVFlipView alloc] initWithFrame:b];
    bg.fillColor = sv::canvas();
    bg.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [page addSubview:bg];

    NSScrollView* toolScroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(0, 0, toolsW, b.size.height)];
    toolScroll.hasVerticalScroller = YES; toolScroll.autohidesScrollers = YES; toolScroll.borderType = NSNoBorder;
    toolScroll.drawsBackground = YES; toolScroll.backgroundColor = sv::panel();
    toolScroll.autoresizingMask = NSViewHeightSizable | NSViewMaxXMargin;
    SVFlipView* doc = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, toolsW, 620)];
    doc.fillColor = sv::panel();
    toolScroll.documentView = doc;
    [bg addSubview:toolScroll];

    _midiTools = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, toolsW, 620)];
    _midiTools.fillColor = sv::panel();
    [doc addSubview:_midiTools];
    sectionBar(_midiTools, @"KEY EDITOR · QUANTIZE", 0, toolsW);
    [self fillTools:_midiTools
             titles:@[@"Quantize", @"Soft Quantize", @"Quantize Ends", @"Legato"]
          selectors:@[@"midiQuantize:", @"midiQuantizeSoft:", @"midiQuantizeEnds:", @"midiLegato:"] top:24];
    sectionBar(_midiTools, @"FUNCTIONS", 134, toolsW);
    [self fillTools:_midiTools
             titles:@[@"Fixed Length", @"Velocity…", @"Compress Vel.", @"Humanize", @"Delete Doubles", @"Retrograde", @"Invert"]
          selectors:@[@"midiFixedLength:", @"midiVelocity:", @"midiCompress:", @"midiHumanize:", @"midiDeleteDoubles:", @"midiRetrograde:", @"midiInvert:"] top:158];
    sectionBar(_midiTools, @"TRANSPOSE", 342, toolsW);
    [self fillTools:_midiTools
             titles:@[@"Up 1", @"Down 1", @"Octave +", @"Octave −"]
          selectors:@[@"midiUp:", @"midiDown:", @"midiOctaveUp:", @"midiOctaveDown:"] top:366];
    sectionBar(_midiTools, @"SELECTION", 470, toolsW);
    [self fillTools:_midiTools titles:@[@"Delete Notes"] selectors:@[@"deleteSelection:"] top:494];

    _audioTools = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, toolsW, 620)];
    _audioTools.fillColor = sv::panel();
    [doc addSubview:_audioTools];
    sectionBar(_audioTools, @"SAMPLE EDITOR · OFFLINE PROCESSING", 0, toolsW);
    [self fillTools:_audioTools
             titles:@[@"Normalize", @"Gain…", @"Fade In", @"Fade Out", @"Reverse", @"Invert Phase", @"Remove DC", @"Silence", @"Mono Sum", @"Stereo Flip"]
          selectors:@[@"processNormalize:", @"processGain:", @"processFadeIn:", @"processFadeOut:", @"processReverse:", @"processInvert:", @"processDc:", @"processSilence:", @"processMono:", @"processFlip:"] top:24];
    sectionBar(_audioTools, @"TIME / PITCH", 166, toolsW);
    [self fillTools:_audioTools titles:@[@"Time Stretch…", @"Pitch Shift…"] selectors:@[@"processStretch:", @"processPitch:"] top:190];
    sectionBar(_audioTools, @"CLIP", 226, toolsW);
    [self fillTools:_audioTools titles:@[@"Clip Gain…", @"Fades…", @"Mute Clip", @"Render in Place"] selectors:@[@"clipGain:", @"clipFades:", @"toggleClipMute:", @"renderInPlace:"] top:250];

    // top strip
    SVFlipView* top = [[SVFlipView alloc] initWithFrame:NSMakeRect(toolsW, 0, b.size.width - toolsW, topH)];
    top.fillColor = sv::hex(0x38383B);
    top.autoresizingMask = NSViewWidthSizable | NSViewMaxYMargin;
    [bg addSubview:top];
    _editTitle = makeLabel(top, @"", NSMakeRect(10, 8, 420, 16), sv::ui(11, true), sv::ink());
    _gridPopup = makePopup(top, NSMakeRect(450, 5, 90, 22), self, @selector(gridPicked:));
    [_gridPopup addItemsWithTitles:@[@"Grid 1/4", @"Grid 1/8", @"Grid 1/16", @"Grid 1/32"]];
    [_gridPopup selectItemAtIndex:2];
    makeLabel(top, @"Swing", NSMakeRect(556, 9, 40, 14), sv::ui(9), sv::inkDim());
    _swingSlider = [[NSSlider alloc] initWithFrame:NSMakeRect(596, 7, 120, 18)];
    _swingSlider.minValue = 0; _swingSlider.maxValue = 75; _swingSlider.doubleValue = 0;
    _swingSlider.target = self; _swingSlider.action = @selector(swingMoved:);
    [top addSubview:_swingSlider];
    _swingValue = makeLabel(top, @"0 %", NSMakeRect(720, 9, 40, 14), sv::mono(9.5, true), sv::ink());

    const NSRect content = NSMakeRect(toolsW, topH, b.size.width - toolsW, b.size.height - topH);
    _noteGrid = [[SilvetonNoteGridView alloc] initWithFrame:content];
    _noteGrid.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _noteGrid.controller = self;
    _noteGrid.quarterWidth = 64.0;
    _noteGrid.scrollQuarters = 0.0;
    _noteGrid.scrollPitch = 84.0;
    [bg addSubview:_noteGrid];
    _sampleView = [[SilvetonSampleView alloc] initWithFrame:content];
    _sampleView.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _sampleView.controller = self;
    _sampleView.hidden = YES;
    [bg addSubview:_sampleView];
}

- (void)refreshEditPage {
    if (!_core || !_noteGrid) return;
    const Project& p = _core->project();
    const BOOL midi = self.selectedMidiTrack >= 0 && self.selectedMidiTrack < static_cast<long>(p.midiTracks.size());
    const BOOL audio = !midi && self.selectedTrack >= 0 && self.selectedTrack < static_cast<long>(p.tracks.size()) && self.editedClip != nullptr;
    _noteGrid.hidden = audio;
    _sampleView.hidden = !audio;
    _midiTools.hidden = audio;
    _audioTools.hidden = !audio;
    _swingSlider.enabled = !audio;
    _gridPopup.enabled = !audio;
    if (audio) {
        _editTitle.stringValue = [NSString stringWithFormat:@"Sample Editor — %@", sv::ns(p.tracks[static_cast<std::size_t>(self.selectedTrack)].name)];
    } else if (midi) {
        _editTitle.stringValue = [NSString stringWithFormat:@"Key Editor — %@", sv::ns(p.midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)].name)];
    } else {
        _editTitle.stringValue = @"Editor — select a MIDI part or an audio clip in the Project window";
    }
    [_noteGrid setNeedsDisplay:YES];
    [_sampleView setNeedsDisplay:YES];
}

// ===================================================================== menus ==
- (void)buildMenus {
    NSMenu* main = [[NSMenu alloc] initWithTitle:@"Main"];
    auto top = [&](NSString* title) {
        NSMenuItem* item = [[NSMenuItem alloc] initWithTitle:title action:nil keyEquivalent:@""];
        [main addItem:item];
        NSMenu* m = [[NSMenu alloc] initWithTitle:title];
        item.submenu = m;
        return m;
    };
    const NSEventModifierFlags cmd = NSEventModifierFlagCommand, opt = NSEventModifierFlagOption, shift = NSEventModifierFlagShift, none = 0;

    NSMenu* app = top(@"Silveton");
    addItem(app, @"About Silveton", @selector(orderFrontStandardAboutPanel:), @"", none, self);
    [app addItem:[NSMenuItem separatorItem]];
    addItem(app, @"Preferences…", @selector(showPreferences:), @",", cmd, self);
    addItem(app, @"Studio Setup — Audio System…", @selector(audioSetup:), @"", none, self);
    [app addItem:[NSMenuItem separatorItem]];
    addItem(app, @"Quit Silveton", @selector(terminate:), @"q", cmd, self);

    NSMenu* file = top(@"File");
    addItem(file, @"New Project", @selector(newProject:), @"n", cmd, self);
    addItem(file, @"Open…", @selector(openProject:), @"o", cmd, self);
    addItem(file, @"Save", @selector(saveProject:), @"s", cmd, self);
    addItem(file, @"Save As…", @selector(saveProjectAs:), @"s", cmd | shift, self);
    [file addItem:[NSMenuItem separatorItem]];
    addItem(file, @"Import Audio…", @selector(importAudio:), @"i", cmd, self);
    addItem(file, @"Import MIDI File…", @selector(importMidi:), @"i", cmd | shift, self);
    [file addItem:[NSMenuItem separatorItem]];
    addItem(file, @"Export Audio Mixdown…", @selector(exportMixdown:), @"e", cmd, self);
    addItem(file, @"Export Stems…", @selector(exportStems:), @"e", cmd | shift, self);
    addItem(file, @"Export MIDI File…", @selector(exportMidi:), @"", none, self);

    NSMenu* edit = top(@"Edit");
    addItem(edit, @"Undo", @selector(undo:), @"z", cmd, self);
    addItem(edit, @"Redo", @selector(redo:), @"z", cmd | shift, self);
    [edit addItem:[NSMenuItem separatorItem]];
    addItem(edit, @"Cut", @selector(cutClip:), @"x", cmd, self);
    addItem(edit, @"Copy", @selector(copyClip:), @"c", cmd, self);
    addItem(edit, @"Paste at Cursor", @selector(pasteClip:), @"v", cmd, self);
    addItem(edit, @"Duplicate", @selector(duplicateClip:), @"d", cmd, self);
    addItem(edit, @"Split at Cursor", @selector(splitAtPlayhead:), @"x", opt, self);
    addItem(edit, @"Mute / Unmute", @selector(toggleClipMute:), @"m", cmd, self);
    addItem(edit, @"Delete", @selector(deleteSelection:), @"\x7f", none, self);
    [edit addItem:[NSMenuItem separatorItem]];
    addItem(edit, @"Rename…", @selector(renameSelected:), @"r", cmd, self);
    addItem(edit, @"Lock / Unlock Track", @selector(toggleLock:), @"l", cmd, self);

    NSMenu* proj = top(@"Project");
    addItem(proj, @"Add Audio Track", @selector(addAudioTrack:), @"a", cmd | opt, self);
    addItem(proj, @"Add Instrument Track", @selector(addInstrumentTrack:), @"i", cmd | opt, self);
    addItem(proj, @"Add MIDI Track", @selector(addMidiTrack:), @"m", cmd | opt, self);
    addItem(proj, @"Add Group Channel", @selector(addGroupBus:), @"", none, self);
    addItem(proj, @"Add FX Channel", @selector(addFxBus:), @"", none, self);
    addItem(proj, @"Add Folder", @selector(addFolder:), @"", none, self);
    [proj addItem:[NSMenuItem separatorItem]];
    addItem(proj, @"Duplicate Track", @selector(duplicateTrack:), @"", none, self);
    addItem(proj, @"Remove Track", @selector(deleteTrack:), @"", none, self);
    addItem(proj, @"Move Track Up", @selector(moveTrackUp:), @"", none, self);
    addItem(proj, @"Move Track Down", @selector(moveTrackDown:), @"", none, self);
    [proj addItem:[NSMenuItem separatorItem]];
    addItem(proj, @"Project Notes…", @selector(projectNotes:), @"", none, self);
    addItem(proj, @"Flatten Arranger Chain", @selector(flattenArranger:), @"", none, self);
    [proj addItem:[NSMenuItem separatorItem]];
    addItem(proj, @"Project Setup…", @selector(showPreferences:), @"", none, self);
    addItem(proj, @"Plug-in Manager — Scan VST3", @selector(scanPlugins:), @"", none, self);

    NSMenu* audio = top(@"Audio");
    addItem(audio, @"Normalize", @selector(processNormalize:), @"", none, self);
    addItem(audio, @"Gain…", @selector(processGain:), @"", none, self);
    addItem(audio, @"Fade In", @selector(processFadeIn:), @"", none, self);
    addItem(audio, @"Fade Out", @selector(processFadeOut:), @"", none, self);
    addItem(audio, @"Reverse", @selector(processReverse:), @"", none, self);
    addItem(audio, @"Invert Phase", @selector(processInvert:), @"", none, self);
    addItem(audio, @"Remove DC Offset", @selector(processDc:), @"", none, self);
    addItem(audio, @"Silence", @selector(processSilence:), @"", none, self);
    addItem(audio, @"Mono Sum", @selector(processMono:), @"", none, self);
    addItem(audio, @"Stereo Flip", @selector(processFlip:), @"", none, self);
    addItem(audio, @"Time Stretch…", @selector(processStretch:), @"", none, self);
    addItem(audio, @"Pitch Shift…", @selector(processPitch:), @"", none, self);
    [audio addItem:[NSMenuItem separatorItem]];
    addItem(audio, @"Clip Gain…", @selector(clipGain:), @"", none, self);
    addItem(audio, @"Clip Fades…", @selector(clipFades:), @"", none, self);
    addItem(audio, @"Render in Place", @selector(renderInPlace:), @"", none, self);

    NSMenu* midi = top(@"MIDI");
    addItem(midi, @"Quantize", @selector(midiQuantize:), @"q", none, self);
    addItem(midi, @"Soft Quantize", @selector(midiQuantizeSoft:), @"", none, self);
    addItem(midi, @"Quantize Ends", @selector(midiQuantizeEnds:), @"", none, self);
    addItem(midi, @"Legato", @selector(midiLegato:), @"", none, self);
    addItem(midi, @"Fixed Length", @selector(midiFixedLength:), @"", none, self);
    addItem(midi, @"Velocity…", @selector(midiVelocity:), @"", none, self);
    addItem(midi, @"Compress Velocity", @selector(midiCompress:), @"", none, self);
    addItem(midi, @"Humanize", @selector(midiHumanize:), @"", none, self);
    addItem(midi, @"Delete Doubles", @selector(midiDeleteDoubles:), @"", none, self);
    addItem(midi, @"Retrograde", @selector(midiRetrograde:), @"", none, self);
    addItem(midi, @"Invert", @selector(midiInvert:), @"", none, self);
    [midi addItem:[NSMenuItem separatorItem]];
    addItem(midi, @"Transpose Up", @selector(midiUp:), @"", none, self);
    addItem(midi, @"Transpose Down", @selector(midiDown:), @"", none, self);
    addItem(midi, @"Octave Up", @selector(midiOctaveUp:), @"", none, self);
    addItem(midi, @"Octave Down", @selector(midiOctaveDown:), @"", none, self);
    [midi addItem:[NSMenuItem separatorItem]];
    addItem(midi, @"Open Editor", @selector(openEditor:), @"\r", none, self);

    NSMenu* tr = top(@"Transport");
    addItem(tr, @"Play", @selector(togglePlay:), @" ", none, self);
    addItem(tr, @"Stop", @selector(stop:), @".", none, self);
    addItem(tr, @"Record", @selector(record:), @"*", none, self);
    addItem(tr, @"Cycle", @selector(toggleCycle:), @"/", none, self);
    addItem(tr, @"Metronome Click", @selector(toggleMetronome:), @"c", none, self);
    [tr addItem:[NSMenuItem separatorItem]];
    addItem(tr, @"Go to Start", @selector(goToStart:), @",", none, self);
    addItem(tr, @"Previous Bar", @selector(rewindBar:), fkey(NSLeftArrowFunctionKey), none, self);
    addItem(tr, @"Next Bar", @selector(forwardBar:), fkey(NSRightArrowFunctionKey), none, self);
    addItem(tr, @"Previous Marker", @selector(previousMarker:), fkey(NSLeftArrowFunctionKey), cmd, self);
    addItem(tr, @"Next Marker", @selector(nextMarker:), fkey(NSRightArrowFunctionKey), cmd, self);
    addItem(tr, @"Insert Marker", @selector(addMarkerAtPlayhead:), fkey(NSInsertFunctionKey), none, self);
    addItem(tr, @"Locate…", @selector(gotoPositionDialog:), @"", none, self);
    addItem(tr, @"Tempo…", @selector(editTempo:), @"", none, self);
    addItem(tr, @"Time Signature…", @selector(editSignature:), @"", none, self);

    NSMenu* view = top(@"View");
    addItem(view, @"Project Window", @selector(showArrangePage:), fkey(NSF2FunctionKey), none, self);
    addItem(view, @"MixConsole", @selector(showMixPage:), fkey(NSF3FunctionKey), none, self);
    addItem(view, @"Editor", @selector(showEditPage:), fkey(NSF4FunctionKey), none, self);
    addItem(view, @"Library", @selector(showLibraryPage:), fkey(NSF5FunctionKey), none, self);
    [view addItem:[NSMenuItem separatorItem]];
    addItem(view, @"Inspector", @selector(toggleChannelPanel:), @"", none, self);
    addItem(view, @"Snap", @selector(toggleSnap:), @"j", none, self);
    addItem(view, @"Zoom In", @selector(zoomIn:), @"h", none, self);
    addItem(view, @"Zoom Out", @selector(zoomOut:), @"g", none, self);
    addItem(view, @"Zoom to Project", @selector(zoomToProject:), @"", none, self);

    NSMenu* window = top(@"Window");
    addItem(window, @"Minimize", @selector(performMiniaturize:), @"m", cmd, nil);
    [NSApp setWindowsMenu:window];

    [NSApp setMainMenu:main];
}

@end
