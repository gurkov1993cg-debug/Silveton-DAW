// Silveton — controls, Inspector (left channel panel), Library page, Edit page
// and the main menu. Category of SilvetonController.
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>

#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/NativePlugins.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <vector>
#include <cmath>
#include <set>
#include <string>

using namespace silveton;

// Methods implemented in other files of the controller that are called here.
@interface SilvetonController (PanelsForward)
- (void)routeFromMenu:(NSMenuItem*)item;
- (void)toggleBypassFromMenu:(NSMenuItem*)item;
- (void)removeInsertFromMenu:(NSMenuItem*)item;
- (void)addSendFromMenu:(NSMenuItem*)item;
- (void)setMidiOutput:(NSMenuItem*)item;
- (void)toggleLock:(id)sender;
- (void)loopSectionFromMenu:(id)sender;
- (void)appendSectionFromMenu:(id)sender;
- (void)deleteSectionFromMenu:(id)sender;
- (void)deleteMarkerFromMenu:(id)sender;
- (void)gotoMarkerFromMenu:(id)sender;
- (void)flattenArranger:(id)sender;
- (void)scanPlugins:(id)sender;
- (void)importAudio:(id)sender;
- (void)addInstrumentTrackWith:(const SVPluginEntry&)entry;
- (void)applyMixerLive;
- (void)republishMidi;
- (void)showPreferences:(id)sender;
@end

// ================================================================ controls ==
@implementation SVFlipView
- (BOOL)isFlipped { return YES; }
- (void)setFrameSize:(NSSize)size {
    [super setFrameSize:size];
    if (self.onLayout) self.onLayout();
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    if (self.rail) sv::rail(self.bounds);
    else if (self.fillColor) sv::fill(self.bounds, self.fillColor);
}
@end

@implementation SVSectionHeader
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::fill(b, sv::panel());
    const NSRect plate = NSInsetRect(b, 0.5, 0.5);
    sv::gradientIn([NSBezierPath bezierPathWithRoundedRect:plate xRadius:6.0 yRadius:6.0], sv::hex(0x383C44), sv::hex(0x2B2E35));
    sv::roundStroke(plate, 6.0, sv::hex(0x1A1C20), 1.0);
    NSBezierPath* tri = [NSBezierPath bezierPath];
    if (self.collapsed) {
        [tri moveToPoint:NSMakePoint(9.0, 6.0)]; [tri lineToPoint:NSMakePoint(9.0, 16.0)]; [tri lineToPoint:NSMakePoint(15.0, 11.0)];
    } else {
        [tri moveToPoint:NSMakePoint(7.0, 8.0)]; [tri lineToPoint:NSMakePoint(17.0, 8.0)]; [tri lineToPoint:NSMakePoint(12.0, 14.0)];
    }
    [tri closePath];
    [sv::inkDim() setFill];
    [tri fill];
    sv::engravedIn(self.title ?: @"", NSMakeRect(22.0, 4.0, b.size.width - 30.0, 14.0), sv::ui(10, true), sv::inkDim(), NSTextAlignmentLeft);
}
- (void)mouseDown:(NSEvent*)event { (void)event; [self.stack toggleSection:self]; }
@end

@implementation SVSectionStack {
    NSMutableArray<SVSectionHeader*>* _headers;
    NSMapTable<NSView*, NSValue*>* _original;
    CGFloat _fullHeight;
}
- (void)registerSection:(SVSectionHeader*)header {
    if (!_headers) _headers = [NSMutableArray array];
    [_headers addObject:header];
    header.stack = self;
}
- (void)finishSections {
    _original = [NSMapTable mapTableWithKeyOptions:(NSPointerFunctionsObjectPointerPersonality | NSPointerFunctionsWeakMemory)
                                      valueOptions:NSPointerFunctionsStrongMemory];
    CGFloat bottom = 0.0;
    for (NSView* v in self.subviews) {
        [_original setObject:[NSValue valueWithRect:v.frame] forKey:v];
        bottom = std::max(bottom, NSMaxY(v.frame));
    }
    [_headers sortUsingComparator:^NSComparisonResult(SVSectionHeader* a, SVSectionHeader* b) {
        const CGFloat ya = a.frame.origin.y, yb = b.frame.origin.y;
        return ya < yb ? NSOrderedAscending : (ya > yb ? NSOrderedDescending : NSOrderedSame);
    }];
    _fullHeight = std::max(self.frame.size.height, bottom + 8.0);
    [self relayout];
}
- (void)foldSectionsNamed:(NSArray<NSString*>*)titles {
    for (SVSectionHeader* h in _headers) if ([titles containsObject:h.title]) { h.collapsed = YES; [h setNeedsDisplay:YES]; }
    [self relayout];
}
- (void)toggleSection:(SVSectionHeader*)header {
    header.collapsed = !header.collapsed;
    [header setNeedsDisplay:YES];
    [self relayout];
}
- (void)relayout {
    if (!_original) return;
    const NSUInteger n = _headers.count;
    // the original top of every section, and the height of its contents
    std::vector<CGFloat> top(n, 0.0), contentH(n, 0.0);
    for (NSUInteger i = 0; i < n; ++i) {
        const NSRect hf = [[_original objectForKey:_headers[i]] rectValue];
        top[i] = hf.origin.y;
        const CGFloat next = i + 1 < n ? [[_original objectForKey:_headers[i + 1]] rectValue].origin.y : _fullHeight;
        contentH[i] = std::max<CGFloat>(0.0, next - NSMaxY(hf));
    }
    CGFloat removed = 0.0;
    for (NSView* v in self.subviews) {
        NSValue* ov = [_original objectForKey:v];
        if (!ov) continue;
        NSRect f = ov.rectValue;
        NSInteger section = -1;
        for (NSUInteger i = 0; i < n; ++i) if (top[i] <= f.origin.y + 0.5) section = static_cast<NSInteger>(i);
        CGFloat dy = 0.0;
        BOOL hidden = NO;
        for (NSInteger i = 0; i < section; ++i) if (_headers[static_cast<NSUInteger>(i)].collapsed) dy += contentH[static_cast<NSUInteger>(i)];
        if (section >= 0 && v != _headers[static_cast<NSUInteger>(section)] && _headers[static_cast<NSUInteger>(section)].collapsed) hidden = YES;
        v.hidden = hidden;
        f.origin.y -= dy;
        if (!NSEqualRects(v.frame, f)) v.frame = f;
    }
    for (NSUInteger i = 0; i < n; ++i) if (_headers[i].collapsed) removed += contentH[i];
    NSRect mine = self.frame;
    mine.size.height = std::max<CGFloat>(24.0, _fullHeight - removed);
    if (std::abs(mine.size.height - self.frame.size.height) > 0.5) self.frame = mine;
    if (![self isHidden] && self.superview) {
        NSRect doc = self.superview.frame;
        if (std::abs(doc.size.height - mine.size.height) > 0.5) { doc.size.height = mine.size.height; self.superview.frame = doc; }
    }
    [self setNeedsDisplay:YES];
}
@end

SVSectionHeader* sectionHeader(NSView* parent, NSString* title, CGFloat y, CGFloat w) {
    SVSectionHeader* bar = [[SVSectionHeader alloc] initWithFrame:NSMakeRect(0, y, w, 22)];
    bar.title = title;
    [parent addSubview:bar];
    if ([parent isKindOfClass:[SVSectionStack class]]) [(SVSectionStack*)parent registerSection:bar];
    return bar;
}

@implementation SVButton
+ (instancetype)buttonWithTitle:(NSString*)title target:(id)target action:(SEL)action frame:(NSRect)frame {
    SVButton* b = [[SVButton alloc] initWithFrame:frame];
    b.title = title;
    b.target = target;
    b.action = action;
    b.bordered = NO;
    [b setButtonType:NSButtonTypeMomentaryPushIn];
    return b;
}
- (BOOL)isFlipped { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    NSFont* f = sv::ui(11, true);
    const NSSize sz = sv::textSize(self.title, f);
    if (self.accent && self.isEnabled) {
        // the one main button of a panel: flat amber
        sv::roundFill(b, 6, self.isHighlighted ? sv::hex(0xE09A33) : sv::copper());
        sv::text(self.title, NSMakePoint(NSMidX(b) - sz.width / 2, NSMidY(b) - sz.height / 2), f, sv::hex(0x111111));
        return;
    }
    const BOOL pressed = self.isEnabled && self.isHighlighted;
    sv::keyCap(b, 6.0, pressed, sv::copper());
    NSColor* ink = !self.isEnabled ? sv::inkFaint() : (pressed ? sv::copper() : sv::ink());
    sv::text(self.title, NSMakePoint(NSMidX(b) - sz.width / 2, (b.size.height - 2.0) * 0.5 - sz.height / 2), f, ink);
}
@end

@implementation SVToggle
+ (instancetype)toggleWithTitle:(NSString*)title color:(NSColor*)color target:(id)target action:(SEL)action frame:(NSRect)frame {
    SVToggle* b = [[SVToggle alloc] initWithFrame:frame];
    b.title = title;
    b.target = target;
    b.action = action;
    b.onColor = color;
    b.bordered = NO;
    [b setButtonType:NSButtonTypePushOnPushOff];
    return b;
}
- (BOOL)isFlipped { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const BOOL on = self.state == NSControlStateValueOn;
    const NSRect b = self.bounds;
    NSColor* glow = self.onColor ?: sv::copper();
    sv::keyCap(b, 6.0, on, glow);
    NSFont* f = sv::ui(11, true);
    const NSSize sz = sv::textSize(self.title, f);
    sv::text(self.title, NSMakePoint(NSMidX(b) - sz.width / 2, (b.size.height - 2.0) * 0.5 - sz.height / 2), f, on ? glow : sv::inkDim());
}
@end

@implementation SVResetSlider
- (void)mouseDown:(NSEvent*)event {
    if (event.clickCount >= 2) {
        self.doubleValue = self.resetValue;
        [self sendAction:self.action to:self.target];
        return;
    }
    if (self.beginAction) [NSApp sendAction:self.beginAction to:self.target from:self];
    [super mouseDown:event];
    if (self.endAction) [NSApp sendAction:self.endAction to:self.target from:self];
}
@end

// ================================================================ helpers ==
namespace {
NSTextField* makeLabel(NSView* parent, NSString* s, NSRect f, NSFont* font, NSColor* color, NSTextAlignment a = NSTextAlignmentLeft) {
    NSTextField* t = [NSTextField labelWithString:s ?: @""];
    t.frame = f;
    t.font = font;
    t.textColor = color;
    t.alignment = a;
    t.lineBreakMode = NSLineBreakByTruncatingTail;
    [parent addSubview:t];
    return t;
}

NSTextField* makeField(NSView* parent, NSRect f, id target, SEL action) {
    NSTextField* t = [[NSTextField alloc] initWithFrame:f];
    t.font = sv::ui(12);
    t.textColor = sv::ink();
    t.backgroundColor = sv::laneB();
    t.drawsBackground = YES;
    t.bezeled = YES;
    t.bezelStyle = NSTextFieldSquareBezel;
    t.target = target;
    t.action = action;
    [parent addSubview:t];
    return t;
}

void sectionBar(NSView* parent, NSString* title, CGFloat y, CGFloat w) { (void)sectionHeader(parent, title, y, w); }

NSPopUpButton* makePopup(NSView* parent, NSRect f, id target, SEL action) {
    NSPopUpButton* p = [[NSPopUpButton alloc] initWithFrame:f pullsDown:NO];
    p.font = sv::ui(11);
    p.target = target;
    p.action = action;
    [parent addSubview:p];
    return p;
}

NSTableView* makeTable(NSView* parent, NSRect f, NSArray<NSArray<NSString*>*>* columns, id owner, BOOL header) {
    NSScrollView* sc = [[NSScrollView alloc] initWithFrame:f];
    sc.hasVerticalScroller = YES;
    sc.borderType = NSNoBorder;
    sc.drawsBackground = YES;
    sc.backgroundColor = sv::laneB();
    NSTableView* t = [[NSTableView alloc] initWithFrame:sc.bounds];
    t.backgroundColor = sv::laneB();
    t.gridColor = sv::hex(0x24272D);
    t.rowHeight = 22;
    t.intercellSpacing = NSMakeSize(0, 1);
    t.allowsEmptySelection = YES;
    t.allowsMultipleSelection = NO;
    t.dataSource = owner;
    t.delegate = owner;
    for (NSArray<NSString*>* c in columns) {
        NSTableColumn* col = [[NSTableColumn alloc] initWithIdentifier:c[0]];
        col.title = c[1];
        col.width = c[2].doubleValue;
        col.minWidth = 16;
        [t addTableColumn:col];
    }
    if (!header) t.headerView = nil;
    sc.documentView = t;
    [parent addSubview:sc];
    return t;
}

NSMenuItem* addItem(NSMenu* menu, NSString* title, SEL sel, NSString* key, NSEventModifierFlags mods, id target) {
    NSMenuItem* it = [menu addItemWithTitle:title action:sel keyEquivalent:key ?: @""];
    it.keyEquivalentModifierMask = mods;
    if (sel != nil && sel != @selector(terminate:) && sel != @selector(orderFrontStandardAboutPanel:)) it.target = target;
    return it;
}

NSString* fkey(unichar c) { return [NSString stringWithCharacters:&c length:1]; }
} // namespace

@implementation SilvetonController (Panels)

// ======================================================= current strip data ==
- (std::vector<ProjectSend>*)sendsOfStrip:(SVStrip)s {
    Project& p = _core->project();
    if (s.kind == SVStripKind::Track && s.index < p.tracks.size()) return &p.tracks[s.index].sends;
    if (s.kind == SVStripKind::Bus && s.index < p.buses.size()) return &p.buses[s.index].sends;
    return nullptr;
}

- (std::string)pluginNameOfSlot:(const ProjectPluginSlot&)slot {
    if (isNativeModulePath(slot.modulePath))
        for (const auto& i : nativePluginCatalog()) if (i.classId == slot.classId) return i.name;
    std::string n = slot.modulePath;
    const auto sl = n.find_last_of('/');
    if (sl != std::string::npos) n = n.substr(sl + 1);
    const auto d = n.find_last_of('.');
    if (d != std::string::npos) n = n.substr(0, d);
    return n.empty() ? slot.classId : n;
}

// ================================================================ inspector ==
- (void)buildChannelPanelIn:(NSRect)frame {
    const CGFloat W = kPanelContentW;   // the scroll view is 15 px wider, for the scroller
    _channelScroll = [[NSScrollView alloc] initWithFrame:frame];
    _channelScroll.hasVerticalScroller = YES;
    _channelScroll.autohidesScrollers = YES;
    _channelScroll.borderType = NSNoBorder;
    _channelScroll.drawsBackground = YES;
    _channelScroll.backgroundColor = sv::panel();
    _channelScroll.autoresizingMask = NSViewHeightSizable | NSViewMaxXMargin;
    SVFlipView* doc = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, W, 850)];
    doc.fillColor = sv::panel();
    _channelScroll.documentView = doc;
    [_arrangePage addSubview:_channelScroll];

    // ------------------------------------------------ audio / bus / master
    _audioPanel = [[SVSectionStack alloc] initWithFrame:NSMakeRect(0, 0, W, 800)];
    _audioPanel.fillColor = sv::panel();
    [doc addSubview:_audioPanel];
    SVFlipView* a = _audioPanel;
    // Grid: 8 px margins, 24 px controls, 8 px gaps; label column 8..72, controls from x = 76.
    const CGFloat lx = 8, lw = 64, cx = 76;
    sectionBar(a, @"INSPECTOR", 0, W);
    _cpName = makeField(a, NSMakeRect(8, 28, W - 16, 24), self, @selector(inspectorNameEdited:));
    _cpType = makeLabel(a, @"", NSMakeRect(8, 58, W - 16, 14), sv::ui(10, true), sv::inkFaint());
    _cpColor = makePopup(a, NSMakeRect(8, 78, 132, 24), self, @selector(inspectorColourPicked:));
    {
        NSMenu* m = _cpColor.menu;
        [m removeAllItems];
        NSMenuItem* au = [m addItemWithTitle:@"Auto colour" action:nil keyEquivalent:@""];
        au.tag = 0;
        static NSString* names[16] = {@"Copper", @"Sage", @"Slate", @"Rose", @"Brass", @"Teal", @"Lavender", @"Brick",
                                      @"Moss", @"Ocean", @"Walnut", @"Ice", @"Mustard", @"Plum", @"Pine", @"Dusk"};
        for (int i = 0; i < 16; ++i) {
            NSMenuItem* it = [m addItemWithTitle:names[i] action:nil keyEquivalent:@""];
            it.tag = static_cast<NSInteger>(silvetonPaletteColor(static_cast<std::size_t>(i)));
        }
    }
    _cpLock = [SVToggle toggleWithTitle:@"LOCK" color:sv::inkDim() target:self action:@selector(inspectorLock:) frame:NSMakeRect(148, 79, W - 156, 22)];
    [a addSubview:_cpLock];
    // Four equal toggles: M S ● MON
    const CGFloat tw = (W - 16 - 3 * 4) / 4.0;
    _cpMute = [SVToggle toggleWithTitle:@"M" color:sv::muteTint() target:self action:@selector(inspectorMute:) frame:NSMakeRect(8, 110, tw, 24)];
    _cpSolo = [SVToggle toggleWithTitle:@"S" color:sv::soloTint() target:self action:@selector(inspectorSolo:) frame:NSMakeRect(8 + (tw + 4), 110, tw, 24)];
    _cpArm = [SVToggle toggleWithTitle:@"●" color:sv::rec() target:self action:@selector(inspectorArm:) frame:NSMakeRect(8 + 2 * (tw + 4), 110, tw, 24)];
    _cpMonitor = [SVToggle toggleWithTitle:@"MON" color:sv::amber() target:self action:@selector(inspectorMonitor:) frame:NSMakeRect(8 + 3 * (tw + 4), 110, tw, 24)];
    for (NSView* v in @[_cpMute, _cpSolo, _cpArm, _cpMonitor]) [a addSubview:v];

    sectionBar(a, @"FADER", 146, W);
    makeLabel(a, @"Volume", NSMakeRect(lx, 176, lw, 16), sv::ui(11), sv::inkDim());
    _cpVolume = [[SVResetSlider alloc] initWithFrame:NSMakeRect(cx, 174, 96, 20)];
    _cpVolume.minValue = 0.0; _cpVolume.maxValue = 1.0;
    _cpVolume.resetValue = faderPositionForDb(0.0);
    _cpVolume.target = self; _cpVolume.action = @selector(inspectorVolume:);
    _cpVolume.beginAction = @selector(inspectorGestureBegin:); _cpVolume.endAction = @selector(inspectorGestureEnd:);
    [a addSubview:_cpVolume];
    _cpVolumeValue = makeLabel(a, @"", NSMakeRect(cx + 96 + 4, 176, W - cx - 96 - 4 - 8, 16), sv::mono(11, true), sv::ink(), NSTextAlignmentRight);
    makeLabel(a, @"Pan", NSMakeRect(lx, 204, lw, 16), sv::ui(11), sv::inkDim());
    _cpPan = [[SVResetSlider alloc] initWithFrame:NSMakeRect(cx, 202, 96, 20)];
    _cpPan.minValue = -1.0; _cpPan.maxValue = 1.0; _cpPan.resetValue = 0.0;
    _cpPan.target = self; _cpPan.action = @selector(inspectorPan:);
    _cpPan.beginAction = @selector(inspectorGestureBegin:); _cpPan.endAction = @selector(inspectorGestureEnd:);
    [a addSubview:_cpPan];
    _cpPanValue = makeLabel(a, @"", NSMakeRect(cx + 96 + 4, 204, W - cx - 96 - 4 - 8, 16), sv::mono(11, true), sv::ink(), NSTextAlignmentRight);

    sectionBar(a, @"ROUTING", 234, W);
    makeLabel(a, @"Output", NSMakeRect(lx, 268, lw, 16), sv::ui(11), sv::inkDim());
    _cpOutput = makePopup(a, NSMakeRect(cx, 264, W - cx - 8, 24), self, @selector(inspectorOutputPicked:));
    makeLabel(a, @"Auto", NSMakeRect(lx, 300, lw, 16), sv::ui(11), sv::inkDim());
    _cpAutomation = makePopup(a, NSMakeRect(cx, 296, W - cx - 8, 24), self, @selector(inspectorAutomationPicked:));
    [_cpAutomation addItemsWithTitles:@[@"Off", @"Read", @"Write", @"Touch", @"Latch"]];

    sectionBar(a, @"INSERTS", 332, W);
    // The slots work like the slots of the mixer: click the lamp = bypass, double-click = open the plug-in,
    // click the empty slot = add one, right-click = the slot's menu. No row of buttons under the list.
    _insertTable = makeTable(a, NSMakeRect(6, 358, W - 12, 172), @[@[@"on", @"", @"22"], @[@"name", @"", @"190"]], self, NO);
    _insertTable.target = self;
    _insertTable.action = @selector(inspectorInsertClick:);
    _insertTable.doubleAction = @selector(inspectorInsertDouble:);
    _insertTable.menu = [[NSMenu alloc] initWithTitle:@"Insert"];
    _insertTable.menu.delegate = self;

    sectionBar(a, @"SENDS", 540, W);
    _sendTable = makeTable(a, NSMakeRect(6, 566, W - 12, 84), @[@[@"dest", @"", @"130"], @[@"level", @"", @"70"]], self, NO);
    {
        [a addSubview:[SVButton buttonWithTitle:@"+" target:self action:@selector(inspectorSendAdd:) frame:NSMakeRect(6, 656, 34, 24)]];
        [a addSubview:[SVButton buttonWithTitle:@"−" target:self action:@selector(inspectorSendRemove:) frame:NSMakeRect(44, 656, 34, 24)]];
        _sendPre = [SVToggle toggleWithTitle:@"PRE" color:sv::copper() target:self action:@selector(inspectorSendPre:) frame:NSMakeRect(82, 656, 52, 24)];
        [a addSubview:_sendPre];
    }
    _sendLevel = [[SVResetSlider alloc] initWithFrame:NSMakeRect(6, 688, 150, 20)];
    _sendLevel.minValue = -60.0; _sendLevel.maxValue = 6.0; _sendLevel.resetValue = 0.0;
    _sendLevel.target = self; _sendLevel.action = @selector(inspectorSendLevel:);
    _sendLevel.beginAction = @selector(inspectorGestureBegin:); _sendLevel.endAction = @selector(inspectorGestureEnd:);
    [a addSubview:_sendLevel];
    _sendLevelValue = makeLabel(a, @"", NSMakeRect(160, 690, W - 160 - 8, 16), sv::mono(11, true), sv::ink(), NSTextAlignmentRight);

    sectionBar(a, @"NOTEPAD", 724, W);
    _cpNotes = makeField(a, NSMakeRect(8, 750, W - 16, 80), self, @selector(inspectorNotesEdited:));
    [(NSTextFieldCell*)_cpNotes.cell setUsesSingleLineMode:NO];
    [(NSTextFieldCell*)_cpNotes.cell setWraps:YES];
    [(NSTextFieldCell*)_cpNotes.cell setScrollable:NO];
    [_audioPanel finishSections];
    [_audioPanel foldSectionsNamed:@[@"SENDS", @"NOTEPAD"]];

    // ----------------------------------------------------------- MIDI track
    _midiPanel = [[SVSectionStack alloc] initWithFrame:NSMakeRect(0, 0, W, 330)];
    _midiPanel.fillColor = sv::panel();
    [doc addSubview:_midiPanel];
    SVFlipView* m = _midiPanel;
    sectionBar(m, @"INSPECTOR · MIDI TRACK", 0, W);
    _mpName = makeField(m, NSMakeRect(8, 28, W - 16, 24), self, @selector(inspectorMidiNameEdited:));
    _mpColor = makePopup(m, NSMakeRect(8, 60, 132, 24), self, @selector(inspectorMidiColourPicked:));
    for (NSMenuItem* it in _cpColor.menu.itemArray) {
        NSMenuItem* copy = [_mpColor.menu addItemWithTitle:it.title action:nil keyEquivalent:@""];
        copy.tag = it.tag;
    }
    const CGFloat mw = (W - 148 - 8 - 4) / 2.0;
    _mpMute = [SVToggle toggleWithTitle:@"M" color:sv::muteTint() target:self action:@selector(inspectorMidiMute:) frame:NSMakeRect(148, 61, mw, 22)];
    _mpSolo = [SVToggle toggleWithTitle:@"S" color:sv::soloTint() target:self action:@selector(inspectorMidiSolo:) frame:NSMakeRect(148 + mw + 4, 61, mw, 22)];
    [m addSubview:_mpMute]; [m addSubview:_mpSolo];
    sectionBar(m, @"ROUTING", 96, W);
    makeLabel(m, @"Out", NSMakeRect(lx, 130, lw, 16), sv::ui(11), sv::inkDim());
    _mpOutput = makePopup(m, NSMakeRect(cx, 126, W - cx - 8, 24), self, @selector(inspectorMidiOutputPicked:));
    sectionBar(m, @"MIDI MODIFIERS", 162, W);
    makeLabel(m, @"Transpose", NSMakeRect(lx, 196, lw, 16), sv::ui(11), sv::inkDim());
    _mpTranspose = makeField(m, NSMakeRect(cx, 192, 56, 24), self, @selector(inspectorMidiModifiers:));
    makeLabel(m, @"semitones", NSMakeRect(cx + 56 + 6, 196, W - cx - 56 - 6 - 8, 16), sv::ui(10), sv::inkFaint());
    makeLabel(m, @"Velocity", NSMakeRect(lx, 228, lw, 16), sv::ui(11), sv::inkDim());
    _mpVelocity = makeField(m, NSMakeRect(cx, 224, 56, 24), self, @selector(inspectorMidiModifiers:));
    makeLabel(m, @"added to note-on", NSMakeRect(cx + 56 + 6, 228, W - cx - 56 - 6 - 8, 16), sv::ui(10), sv::inkFaint());
    NSTextField* hint = makeLabel(m, @"Double-click a part in the Project window to open it in the Key Editor.", NSMakeRect(8, 264, W - 16, 50), sv::ui(11), sv::inkFaint());
    hint.lineBreakMode = NSLineBreakByWordWrapping;   // two lines: this one must wrap, not be cut with "…"
    hint.maximumNumberOfLines = 3;
    ((NSTextField*)m.subviews.lastObject).lineBreakMode = NSLineBreakByWordWrapping;
    ((NSTextField*)m.subviews.lastObject).maximumNumberOfLines = 3;
    [_midiPanel finishSections];
}

// Refresh all inspector controls from the model.
- (void)refreshChannelPanel {
    if (!_core || !_audioPanel) return;
    _updating = YES;
    Project& p = _core->project();
    const BOOL midi = self.selectedMidiTrack >= 0 && self.selectedMidiTrack < static_cast<long>(p.midiTracks.size());
    _audioPanel.hidden = midi;
    _midiPanel.hidden = !midi;
    {
        NSView* shown = midi ? _midiPanel : _audioPanel;
        NSRect df = shown.superview.frame;
        if (std::abs(df.size.height - shown.frame.size.height) > 0.5) { df.size.height = shown.frame.size.height; shown.superview.frame = df; }
    }
    if (midi) {
        const auto& mt = p.midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)];
        _mpName.stringValue = sv::ns(mt.name);
        [_mpColor selectItemWithTag:mt.color];
        if (_mpColor.indexOfSelectedItem < 0) [_mpColor selectItemAtIndex:0];
        _mpMute.state = mt.mute ? NSControlStateValueOn : NSControlStateValueOff;
        _mpSolo.state = mt.solo ? NSControlStateValueOn : NSControlStateValueOff;
        [_mpOutput removeAllItems];
        [_mpOutput addItemWithTitle:@"No output"];
        _mpOutput.lastItem.tag = -1;
        for (std::size_t i = 0; i < p.tracks.size(); ++i)
            for (const auto& s : p.tracks[i].pluginSlots)
                if (s.midiInputPort >= 0) {
                    [_mpOutput addItemWithTitle:[NSString stringWithFormat:@"→ %@", sv::ns(p.tracks[i].name)]];
                    _mpOutput.lastItem.tag = s.midiInputPort;
                }
        [_mpOutput selectItemWithTag:mt.outputPort];
        if (!_mpTranspose.currentEditor) _mpTranspose.stringValue = [NSString stringWithFormat:@"%d", mt.transpose];
        if (!_mpVelocity.currentEditor) _mpVelocity.stringValue = [NSString stringWithFormat:@"%d", mt.velocityShift];
        _updating = NO;
        return;
    }
    const SVStrip s = _strip;
    std::string name = "Master", type = "MASTER";
    std::uint32_t color = 0;
    double gain = p.masterFaderDb, pan = 0;
    bool mute = false, solo = false, arm = false, mon = false, locked = false, isTrack = false, isBus = false;
    const std::vector<ProjectPluginSlot>* slots = &p.masterPluginSlots;
    int output = -1;
    std::string notes;
    AutomationMode mode = AutomationMode::Read;
    if (s.kind == SVStripKind::Track && s.index < p.tracks.size()) {
        const auto& t = p.tracks[s.index];
        isTrack = true; name = t.name; color = t.color; gain = t.gainDb; pan = t.pan; mute = t.mute; solo = t.solo;
        arm = t.recordArm; mon = t.monitor; locked = t.locked; slots = &t.pluginSlots; output = t.outputBus; notes = t.notes;
        mode = t.gainAutomationMode;
        bool instrument = false;
        for (const auto& sl : t.pluginSlots) if (sl.midiInputPort >= 0) instrument = true;
        type = instrument ? "INSTRUMENT TRACK" : "AUDIO TRACK";
    } else if (s.kind == SVStripKind::Bus && s.index < p.buses.size()) {
        const auto& b = p.buses[s.index];
        isBus = true; name = b.name; color = b.color; gain = b.gainDb; mute = b.mute; solo = b.solo; slots = &b.pluginSlots; output = b.outputBus;
        type = b.kind == ProjectBusKind::Group ? "GROUP CHANNEL" : "FX CHANNEL";
    }
    _cpName.stringValue = sv::ns(name);
    _cpName.enabled = isTrack || isBus;
    _cpType.stringValue = sv::ns(type);
    [_cpColor selectItemWithTag:color];
    if (_cpColor.indexOfSelectedItem < 0) [_cpColor selectItemAtIndex:0];
    _cpColor.enabled = isTrack || isBus;
    _cpMute.state = mute ? NSControlStateValueOn : NSControlStateValueOff;
    _cpSolo.state = solo ? NSControlStateValueOn : NSControlStateValueOff;
    _cpArm.state = arm ? NSControlStateValueOn : NSControlStateValueOff;
    _cpMonitor.state = mon ? NSControlStateValueOn : NSControlStateValueOff;
    _cpLock.state = locked ? NSControlStateValueOn : NSControlStateValueOff;
    _cpMute.enabled = _cpSolo.enabled = isTrack || isBus;
    _cpArm.enabled = _cpMonitor.enabled = _cpLock.enabled = isTrack;
    _cpVolume.doubleValue = faderPositionForDb(gain);
    _cpVolumeValue.stringValue = gain <= -95.9 ? @"-∞ dB" : [NSString stringWithFormat:@"%+.1f dB", gain];
    _cpPan.doubleValue = pan;
    _cpPan.enabled = isTrack;
    _cpPanValue.stringValue = !isTrack ? @"" : (std::abs(pan) < 0.005 ? @"C" : [NSString stringWithFormat:@"%@%d", pan < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(pan) * 100))]);
    [_cpOutput removeAllItems];
    [_cpOutput addItemWithTitle:s.kind == SVStripKind::Master ? @"Device" : @"Stereo Out"];
    _cpOutput.lastItem.tag = -1;
    for (std::size_t i = 0; i < p.buses.size(); ++i) {
        if (isBus && i == s.index) continue;
        [_cpOutput addItemWithTitle:sv::ns(p.buses[i].name)];
        _cpOutput.lastItem.tag = static_cast<NSInteger>(i);
    }
    [_cpOutput selectItemWithTag:output];
    _cpOutput.enabled = isTrack || isBus;
    _cpAutomation.enabled = isTrack;
    [_cpAutomation selectItemAtIndex:static_cast<NSInteger>(mode)];
    _cpNotes.enabled = isTrack;
    if (!_cpNotes.currentEditor) _cpNotes.stringValue = sv::ns(notes);
    _insertSlotCount = slots ? slots->size() : 0U;
    [_insertTable reloadData];
    if (_insertRow >= 0 && _insertRow < static_cast<long>(_insertSlotCount)) [_insertTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(_insertRow)] byExtendingSelection:NO];
    const auto* sends = (isTrack || isBus) ? [self sendsOfStrip:s] : nullptr;
    [_sendTable reloadData];
    if (_sendRow >= 0 && sends && _sendRow < static_cast<long>(sends->size())) {
        [_sendTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(_sendRow)] byExtendingSelection:NO];
        const auto& sd = (*sends)[static_cast<std::size_t>(_sendRow)];
        _sendPre.state = sd.preFader ? NSControlStateValueOn : NSControlStateValueOff;
        _sendLevel.doubleValue = sd.gainDb;
        _sendLevelValue.stringValue = [NSString stringWithFormat:@"%+.1f dB", sd.gainDb];
    } else {
        _sendLevelValue.stringValue = @"";
    }
    _sendPre.enabled = _sendLevel.enabled = sends && _sendRow >= 0 && _sendRow < static_cast<long>(sends->size());
    _updating = NO;
}

// ------------------------------------------------------- inspector actions --
- (void)inspectorGestureBegin:(id)sender { (void)sender; [self beginGesture:@"Inspector"]; }
- (void)inspectorGestureEnd:(id)sender { (void)sender; [self endGesture]; }

- (void)inspectorNameEdited:(NSTextField*)f {
    if (_updating) return;
    const SVStrip s = _strip;
    const std::string n = sv::str(f.stringValue);
    [self runEdit:@"Rename" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (s.kind == SVStripKind::Track && s.index < p.tracks.size()) p.tracks[s.index].name = n;
        else if (s.kind == SVStripKind::Bus && s.index < p.buses.size()) p.buses[s.index].name = n;
    }];
}
- (void)inspectorColourPicked:(NSPopUpButton*)pop {
    if (_updating) return;
    const SVStrip s = _strip;
    const auto color = static_cast<std::uint32_t>(pop.selectedItem.tag);
    [self runEdit:@"Colour" rebuild:NO block:^{
        Project& p = self->_core->project();
        if (s.kind == SVStripKind::Track && s.index < p.tracks.size()) p.tracks[s.index].color = color;
        else if (s.kind == SVStripKind::Bus && s.index < p.buses.size()) p.buses[s.index].color = color;
    }];
}
- (void)inspectorMute:(id)sender { (void)sender; if (!_updating) [self toggleStripMute:_strip]; }
- (void)inspectorSolo:(id)sender { (void)sender; if (!_updating) [self toggleStripSolo:_strip]; }
- (void)inspectorArm:(id)sender {
    (void)sender;
    if (_updating || _strip.kind != SVStripKind::Track) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = _strip.index;
    [self toggleArm:r];
}
- (void)inspectorMonitor:(id)sender {
    (void)sender;
    if (_updating || _strip.kind != SVStripKind::Track) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Audio; r.index = _strip.index;
    [self toggleMonitor:r];
}
- (void)inspectorLock:(id)sender { (void)sender; if (!_updating && _strip.kind == SVStripKind::Track) { self.selectedTrack = static_cast<long>(_strip.index); [self toggleLock:nil]; } }
- (void)inspectorVolume:(SVResetSlider*)sl {
    if (_updating) return;
    [self setStrip:_strip gainDb:dbForFaderPosition(sl.doubleValue)];
    const double db = dbForFaderPosition(sl.doubleValue);
    _cpVolumeValue.stringValue = db <= -95.9 ? @"-∞ dB" : [NSString stringWithFormat:@"%+.1f dB", db];
    [_arrange setNeedsDisplay:YES];
}
- (void)inspectorPan:(SVResetSlider*)sl {
    if (_updating) return;
    [self setStrip:_strip pan:sl.doubleValue];
    const double pan = sl.doubleValue;
    _cpPanValue.stringValue = std::abs(pan) < 0.005 ? @"C" : [NSString stringWithFormat:@"%@%d", pan < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(pan) * 100))];
}
- (void)inspectorOutputPicked:(NSPopUpButton*)pop {
    if (_updating) return;
    _menuStrip = _strip;
    [self routeFromMenu:pop.selectedItem];
}
- (void)inspectorAutomationPicked:(NSPopUpButton*)pop {
    if (_updating || _strip.kind != SVStripKind::Track) return;
    const auto mode = static_cast<AutomationMode>(pop.indexOfSelectedItem);
    const std::size_t i = _strip.index;
    // the automation lanes are part of what the engine plays, so the playing graph is built again
    [self runEdit:@"Automation Mode" rebuild:YES block:^{
        auto& t = self->_core->project().tracks.at(i);
        t.gainAutomationMode = mode; t.panAutomationMode = mode; t.muteAutomationMode = mode;
    }];
    [self applyMixerLive];
}
- (void)inspectorNotesEdited:(NSTextField*)f {
    if (_updating || _strip.kind != SVStripKind::Track) return;
    const std::size_t i = _strip.index;
    const std::string n = sv::str(f.stringValue);
    [self runEdit:@"Track Notes" rebuild:NO block:^{ self->_core->project().tracks.at(i).notes = n; }];
}

- (void)inspectorInsertClick:(id)sender {
    (void)sender;
    const NSInteger r = _insertTable.clickedRow, col = _insertTable.clickedColumn;
    if (r < 0) return;
    if (r >= static_cast<NSInteger>(_insertSlotCount)) {   // the empty slot: choose a plug-in
        NSMenu* menu = [self insertMenuForStrip:_strip];
        [menu popUpMenuPositioningItem:nil atLocation:[NSEvent mouseLocation] inView:nil];
        return;
    }
    if (col == 0) {   // the lamp: bypass / enable
        NSMenuItem* it = [[NSMenuItem alloc] init];
        it.tag = r;
        _menuStrip = _strip;
        [self toggleBypassFromMenu:it];
    }
}
- (void)inspectorInsertDouble:(id)sender {
    (void)sender;
    const NSInteger r = _insertTable.clickedRow;
    if (r >= 0 && r < static_cast<NSInteger>(_insertSlotCount)) [self openInsertEditor:_strip slot:static_cast<std::size_t>(r)];
    else if (r >= static_cast<NSInteger>(_insertSlotCount)) {
        NSMenu* menu = [self insertMenuForStrip:_strip];
        [menu popUpMenuPositioningItem:nil atLocation:[NSEvent mouseLocation] inView:nil];
    }
}
// The right mouse button on a slot of the Inspector: the slot's part of the channel menu.
- (void)menuNeedsUpdate:(NSMenu*)menu {
    if (menu != _insertTable.menu) return;
    [menu removeAllItems];
    const NSInteger r = _insertTable.clickedRow;
    _menuStrip = _strip;
    if (r < 0 || r >= static_cast<NSInteger>(_insertSlotCount)) {
        NSMenuItem* ins = [menu addItemWithTitle:@"Add Insert" action:nil keyEquivalent:@""];
        ins.submenu = [self insertMenuForStrip:_strip];
        return;
    }
    const auto* slots = [self slotsForStrip:_strip];
    if (!slots || static_cast<std::size_t>(r) >= slots->size()) return;
    const auto& sl = (*slots)[static_cast<std::size_t>(r)];
    NSString* name = sv::ns([self pluginNameOfSlot:sl]);
    auto add = [&](NSString* title, SEL action, bool on) {
        NSMenuItem* it = [menu addItemWithTitle:title action:action keyEquivalent:@""];
        it.target = self; it.tag = r;
        it.state = on ? NSControlStateValueOn : NSControlStateValueOff;
    };
    add([NSString stringWithFormat:@"Open %@", name], @selector(openInsertFromMenu:), false);
    add([NSString stringWithFormat:@"Bypass %@", name], @selector(toggleBypassFromMenu:), !sl.enabled);
    add([NSString stringWithFormat:@"Remove %@", name], @selector(removeInsertFromMenu:), false);
}

- (void)inspectorSendAdd:(NSButton*)b {
    if (_strip.kind == SVStripKind::Master) return;
    _menuStrip = _strip;
    NSMenu* menu = [[NSMenu alloc] initWithTitle:@"Send to"];
    const Project& p = _core->project();
    for (std::size_t i = 0; i < p.buses.size(); ++i) {
        if (_strip.kind == SVStripKind::Bus && i == _strip.index) continue;
        NSMenuItem* it = [menu addItemWithTitle:sv::ns(p.buses[i].name) action:@selector(addSendFromMenu:) keyEquivalent:@""];
        it.tag = static_cast<NSInteger>(i);
        it.target = self;
    }
    if (menu.itemArray.count == 0) { [self setStatus:@"Add a Group or FX channel first (Project ▸ Add FX Channel)"]; return; }
    [menu popUpMenuPositioningItem:nil atLocation:NSMakePoint(0, b.bounds.size.height) inView:b];
}
- (void)inspectorSendRemove:(id)sender {
    (void)sender;
    const SVStrip s = _strip;
    const long row = _sendRow;
    if (row < 0) return;
    _sendRow = -1;
    [self runEdit:@"Remove Send" rebuild:YES block:^{
        auto* sends = [self sendsOfStrip:s];
        if (sends && row < static_cast<long>(sends->size())) sends->erase(sends->begin() + row);
    }];
}
- (void)inspectorSendPre:(id)sender {
    (void)sender;
    if (_updating || _sendRow < 0) return;
    const SVStrip s = _strip;
    const long row = _sendRow;
    [self runEdit:@"Send Pre/Post" rebuild:YES block:^{
        auto* sends = [self sendsOfStrip:s];
        if (sends && row < static_cast<long>(sends->size())) (*sends)[static_cast<std::size_t>(row)].preFader = !(*sends)[static_cast<std::size_t>(row)].preFader;
    }];
}
- (void)inspectorSendLevel:(SVResetSlider*)sl {
    if (_updating || _sendRow < 0) return;
    auto* sends = [self sendsOfStrip:_strip];
    if (!sends || _sendRow >= static_cast<long>(sends->size())) return;
    (*sends)[static_cast<std::size_t>(_sendRow)].gainDb = static_cast<float>(sl.doubleValue);
    _sendLevelValue.stringValue = [NSString stringWithFormat:@"%+.1f dB", sl.doubleValue];
    if (_gestureOpen) _gestureNeedsRebuild = YES; else [self requestRebuild];
    _core->session().markDirty();
    [_sendTable reloadData];
}

- (void)inspectorMidiNameEdited:(NSTextField*)f {
    if (_updating || self.selectedMidiTrack < 0) return;
    const std::size_t i = static_cast<std::size_t>(self.selectedMidiTrack);
    const std::string n = sv::str(f.stringValue);
    [self runEdit:@"Rename" rebuild:NO block:^{ self->_core->project().midiTracks.at(i).name = n; }];
}
- (void)inspectorMidiColourPicked:(NSPopUpButton*)pop {
    if (_updating || self.selectedMidiTrack < 0) return;
    const std::size_t i = static_cast<std::size_t>(self.selectedMidiTrack);
    const auto color = static_cast<std::uint32_t>(pop.selectedItem.tag);
    [self runEdit:@"Colour" rebuild:NO block:^{ self->_core->project().midiTracks.at(i).color = color; }];
}
- (void)inspectorMidiMute:(id)sender {
    (void)sender;
    if (_updating || self.selectedMidiTrack < 0) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Midi; r.index = static_cast<std::size_t>(self.selectedMidiTrack);
    [self toggleMute:r];
}
- (void)inspectorMidiSolo:(id)sender {
    (void)sender;
    if (_updating || self.selectedMidiTrack < 0) return;
    ArrangeRow r; r.kind = ArrangeRowKind::Midi; r.index = static_cast<std::size_t>(self.selectedMidiTrack);
    [self toggleSolo:r];
}
- (void)inspectorMidiOutputPicked:(NSPopUpButton*)pop {
    if (_updating || self.selectedMidiTrack < 0) return;
    _menuRow.kind = ArrangeRowKind::Midi;
    _menuRow.index = static_cast<std::size_t>(self.selectedMidiTrack);
    [self setMidiOutput:pop.selectedItem];
}
- (void)inspectorMidiModifiers:(id)sender {
    (void)sender;
    if (_updating || self.selectedMidiTrack < 0) return;
    const std::size_t i = static_cast<std::size_t>(self.selectedMidiTrack);
    const int tr = std::clamp(_mpTranspose.intValue, -48, 48);
    const int vel = std::clamp(_mpVelocity.intValue, -126, 126);
    [self runEdit:@"MIDI Modifiers" rebuild:NO block:^{
        auto& mt = self->_core->project().midiTracks.at(i);
        mt.transpose = tr; mt.velocityShift = vel;
    }];
    [self republishMidi];
}

// ================================================================ tables ==
- (NSInteger)numberOfRowsInTableView:(NSTableView*)tv {
    if (!_core) return 0;
    const Project& p = _core->project();
    if (tv == _insertTable) return static_cast<NSInteger>(std::min<std::size_t>(16U, _insertSlotCount + 1U));
    if (tv == _sendTable) { const auto* s = (_strip.kind == SVStripKind::Master) ? nullptr : [self sendsOfStrip:_strip]; return s ? static_cast<NSInteger>(s->size()) : 0; }
    if (tv == _pluginTable) return static_cast<NSInteger>(_pluginResults.size());
    if (tv == _poolTable) return static_cast<NSInteger>(_pool.size());
    if (tv == _markerTable) return static_cast<NSInteger>(p.markers.size());
    if (tv == _sectionTable) return static_cast<NSInteger>(p.arrangerSections.size());
    if (tv == _chainTable) return static_cast<NSInteger>(p.arrangerChain.size());
    return 0;
}

- (NSView*)tableView:(NSTableView*)tv viewForTableColumn:(NSTableColumn*)col row:(NSInteger)row {
    if (!_core) return nil;
    const Project& p = _core->project();
    NSString* s = @"";
    NSColor* color = sv::ink();
    NSString* ident = col.identifier;
    const auto r = static_cast<std::size_t>(std::max<NSInteger>(0, row));
    if (tv == _insertTable) {
        if (r < _insertSlotCount) {
            const auto* slots = [self slotsForStrip:_strip];
            if (slots && r < slots->size()) {
                const auto& sl = (*slots)[r];
                if ([ident isEqualToString:@"on"]) { s = sl.enabled ? @"●" : @"○"; color = sl.enabled ? sv::sage() : sv::inkFaint(); }
                else { s = sv::ns([self pluginNameOfSlot:sl]); color = sl.enabled ? sv::ink() : sv::inkFaint(); }
            }
        } else if ([ident isEqualToString:@"name"]) { s = @"—  (click to add)"; color = sv::inkFaint(); }
    } else if (tv == _sendTable) {
        const auto* sends = [self sendsOfStrip:_strip];
        if (sends && r < sends->size()) {
            const auto& sd = (*sends)[r];
            if ([ident isEqualToString:@"dest"]) {
                s = (sd.destinationBus >= 0 && static_cast<std::size_t>(sd.destinationBus) < p.buses.size()) ? sv::ns(p.buses[static_cast<std::size_t>(sd.destinationBus)].name) : @"?";
                s = [s stringByAppendingString:sd.preFader ? @"  (pre)" : @""];
            } else s = [NSString stringWithFormat:@"%+.1f", sd.gainDb];
        }
    } else if (tv == _pluginTable) {
        if (r < _pluginResults.size()) {
            const auto& e = _pluginResults[r];
            if ([ident isEqualToString:@"name"]) s = sv::ns(e.name);
            else if ([ident isEqualToString:@"vendor"]) s = sv::ns(e.native ? std::string("Silveton") : e.vendor);
            else s = e.instrument ? @"Instrument" : @"Effect";
            if (e.native) color = sv::copper();
        }
    } else if (tv == _poolTable) {
        if (r < _pool.size()) {
            s = [sv::ns(_pool[r]) lastPathComponent];
        }
    } else if (tv == _markerTable) {
        if (r < p.markers.size()) {
            const auto& m = p.markers[r];
            s = [ident isEqualToString:@"name"] ? sv::ns(m.name.empty() ? std::string("Marker") : m.name) : sv::ns(formatBarsBeats(p.tempoMap, m.sample));
        }
    } else if (tv == _sectionTable) {
        if (r < p.arrangerSections.size()) {
            const auto& sc = p.arrangerSections[r];
            if ([ident isEqualToString:@"name"]) s = sv::ns(sc.name);
            else s = [NSString stringWithFormat:@"%@ → %@", sv::ns(formatBarsBeats(p.tempoMap, sc.startSample)), sv::ns(formatBarsBeats(p.tempoMap, sc.endSample))];
        }
    } else if (tv == _chainTable) {
        if (r < p.arrangerChain.size()) {
            const auto& step = p.arrangerChain[r];
            if (const auto* sc = ArrangerTools::find(p, step.sectionId)) {
                s = [ident isEqualToString:@"name"] ? sv::ns(sc->name) : [NSString stringWithFormat:@"×%u", step.repeats];
            } else s = @"(missing)";
        }
    }
    NSTextField* f = [NSTextField labelWithString:s];
    f.font = sv::ui(11);
    f.textColor = color;
    f.lineBreakMode = NSLineBreakByTruncatingTail;
    return f;
}

- (void)tableViewSelectionDidChange:(NSNotification*)n {
    NSTableView* tv = n.object;
    if (_updating) return;
    if (tv == _insertTable) {
        const NSInteger r = tv.selectedRow;
        _insertRow = (r >= 0 && r < static_cast<NSInteger>(_insertSlotCount)) ? r : -1;
    } else if (tv == _sendTable) {
        _sendRow = tv.selectedRow;
        [self refreshChannelPanel];
    }
}

// =================================================================== library ==
- (void)reloadPluginResults {
    _pluginResults.clear();
    NSString* q = _pluginSearch ? _pluginSearch.stringValue.lowercaseString : @"";
    for (const auto& info : nativePluginCatalog()) {
        if (q.length && [sv::ns(info.name).lowercaseString rangeOfString:q].location == NSNotFound) continue;
        SVPluginEntry e;
        e.native = true; e.instrument = info.instrument; e.modulePath = kNativeModulePath; e.classId = info.classId; e.name = info.name; e.vendor = "Silveton";
        _pluginResults.push_back(e);
    }
    if (_browser) {
        for (const auto& c : _browser->search(sv::str(q))) {
            SVPluginEntry e;
            e.modulePath = c.modulePath; e.classId = c.classId; e.name = c.name; e.vendor = c.vendor;
            for (const auto& sc : c.subCategories) if (sc.find("Instrument") != std::string::npos || sc.find("Synth") != std::string::npos) e.instrument = true;
            _pluginResults.push_back(e);
        }
    }
    // Silveton first, then the vendors A-Z; inside a vendor the instruments first, then by name.
    std::stable_sort(_pluginResults.begin(), _pluginResults.end(), [](const SVPluginEntry& a, const SVPluginEntry& b) {
        if (a.native != b.native) return a.native;
        if (a.vendor != b.vendor) return a.vendor < b.vendor;
        if (a.instrument != b.instrument) return a.instrument;
        return a.name < b.name;
    });
    [_pluginTable reloadData];
}

- (void)controlTextDidChange:(NSNotification*)n {
    if (n.object == _pluginSearch) [self reloadPluginResults];
}

- (void)libraryAddInsert:(id)sender {
    (void)sender;
    const NSInteger r = _pluginTable.selectedRow;
    if (r < 0 || r >= static_cast<NSInteger>(_pluginResults.size())) { [self setStatus:@"Select a plug-in in the list first"]; return; }
    const SVPluginEntry e = _pluginResults[static_cast<std::size_t>(r)];
    if (e.instrument) { [self addInstrumentTrackWith:e]; return; }
    [self insertPluginEntry:e intoStrip:_strip];
}

- (void)libraryAddInstrument:(id)sender {
    (void)sender;
    const NSInteger r = _pluginTable.selectedRow;
    if (r < 0 || r >= static_cast<NSInteger>(_pluginResults.size())) { [self setStatus:@"Select an instrument in the list first"]; return; }
    const SVPluginEntry e = _pluginResults[static_cast<std::size_t>(r)];
    if (!e.instrument) { [self setStatus:@"That plug-in is an effect — use “Add as Insert”"]; return; }
    [self addInstrumentTrackWith:e];
}

- (void)libraryGoMarker:(id)sender {
    (void)sender;
    const NSInteger r = _markerTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.markers.size())) return;
    _menuMarker = p.markers[static_cast<std::size_t>(r)].id;
    [self gotoMarkerFromMenu:nil];
}
- (void)libraryDeleteMarker:(id)sender {
    (void)sender;
    const NSInteger r = _markerTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.markers.size())) return;
    _menuMarker = p.markers[static_cast<std::size_t>(r)].id;
    [self deleteMarkerFromMenu:nil];
}
- (void)libraryLoopSection:(id)sender {
    (void)sender;
    const NSInteger r = _sectionTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.arrangerSections.size())) return;
    _menuSection = p.arrangerSections[static_cast<std::size_t>(r)].id;
    [self loopSectionFromMenu:nil];
}
- (void)libraryAppendSection:(id)sender {
    (void)sender;
    const NSInteger r = _sectionTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.arrangerSections.size())) return;
    _menuSection = p.arrangerSections[static_cast<std::size_t>(r)].id;
    [self appendSectionFromMenu:nil];
}
- (void)libraryDeleteSection:(id)sender {
    (void)sender;
    const NSInteger r = _sectionTable.selectedRow;
    const Project& p = _core->project();
    if (r < 0 || r >= static_cast<NSInteger>(p.arrangerSections.size())) return;
    _menuSection = p.arrangerSections[static_cast<std::size_t>(r)].id;
    [self deleteSectionFromMenu:nil];
}
- (void)libraryRemoveChainStep:(id)sender {
    (void)sender;
    const NSInteger r = _chainTable.selectedRow;
    if (r < 0 || r >= static_cast<NSInteger>(_core->project().arrangerChain.size())) return;
    [self runEdit:@"Remove Chain Step" rebuild:NO block:^{ ArrangerTools::removeChainStep(self->_core->project(), static_cast<std::size_t>(r)); }];
}
- (void)libraryChainUp:(id)sender {
    (void)sender;
    const NSInteger r = _chainTable.selectedRow;
    if (r < 1 || r >= static_cast<NSInteger>(_core->project().arrangerChain.size())) return;
    [self runEdit:@"Move Chain Step" rebuild:NO block:^{ ArrangerTools::moveChainStep(self->_core->project(), static_cast<std::size_t>(r), static_cast<std::size_t>(r - 1)); }];
    [_chainTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(r - 1)] byExtendingSelection:NO];
}

- (void)buildLibraryPage:(NSView*)page {
    const NSRect b = page.bounds;
    const CGFloat H = b.size.height;
    const CGFloat leftW = std::floor(b.size.width * 0.40), midW = std::floor(b.size.width * 0.24);
    const CGFloat rightW = b.size.width - leftW - midW;
    SVFlipView* bg = [[SVFlipView alloc] initWithFrame:b];
    bg.fillColor = sv::canvas();
    bg.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [page addSubview:bg];
    // Plug-ins
    SVFlipView* L = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, leftW, H)];
    L.fillColor = sv::panel();
    L.autoresizingMask = NSViewHeightSizable | NSViewMaxXMargin;
    [bg addSubview:L];
    sectionBar(L, @"PLUG-INS  ·  SILVETON NATIVE + VST3", 0, leftW);
    _pluginSearch = [[NSSearchField alloc] initWithFrame:NSMakeRect(8, 28, leftW - 16, 24)];
    _pluginSearch.delegate = self;
    _pluginSearch.placeholderString = @"Search plug-ins";
    [L addSubview:_pluginSearch];
    _pluginTable = makeTable(L, NSMakeRect(8, 58, leftW - 16, H - 58 - 44), @[@[@"name", @"Name", @"200"], @[@"vendor", @"Vendor", @"120"], @[@"kind", @"Type", @"80"]], self, YES);
    _pluginTable.target = self;
    _pluginTable.doubleAction = @selector(libraryAddInsert:);
    _pluginTable.superview.superview.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    SVButton* b1 = [SVButton buttonWithTitle:@"Add as Insert" target:self action:@selector(libraryAddInsert:) frame:NSMakeRect(8, H - 34, 112, 24)];
    SVButton* b2 = [SVButton buttonWithTitle:@"Add Instrument Track" target:self action:@selector(libraryAddInstrument:) frame:NSMakeRect(126, H - 34, 160, 24)];
    SVButton* b3 = [SVButton buttonWithTitle:@"Scan VST3" target:self action:@selector(scanPlugins:) frame:NSMakeRect(292, H - 34, 96, 24)];
    for (SVButton* x in @[b1, b2, b3]) { x.autoresizingMask = NSViewMinYMargin; [L addSubview:x]; }
    // Pool
    SVFlipView* M = [[SVFlipView alloc] initWithFrame:NSMakeRect(leftW, 0, midW, H)];
    M.fillColor = sv::panel();
    M.autoresizingMask = NSViewHeightSizable | NSViewMinXMargin | NSViewMaxXMargin;
    [bg addSubview:M];
    sectionBar(M, @"POOL  ·  AUDIO IN THIS PROJECT", 0, midW);
    _poolTable = makeTable(M, NSMakeRect(8, 28, midW - 16, H - 28 - 44), @[@[@"file", @"File", @"260"]], self, NO);
    _poolTable.superview.superview.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    SVButton* imp = [SVButton buttonWithTitle:@"Import Audio…" target:self action:@selector(importAudio:) frame:NSMakeRect(8, H - 34, 120, 24)];
    imp.autoresizingMask = NSViewMinYMargin;
    [M addSubview:imp];
    // Markers / arranger
    SVFlipView* R = [[SVFlipView alloc] initWithFrame:NSMakeRect(leftW + midW, 0, rightW, H)];
    R.fillColor = sv::panel();
    R.autoresizingMask = NSViewHeightSizable | NSViewMinXMargin;
    [bg addSubview:R];
    const CGFloat third = std::floor((H - 3 * 22 - 3 * 36) / 3.0);
    CGFloat y = 0;
    sectionBar(R, @"MARKERS", y, rightW); y += 26;
    _markerTable = makeTable(R, NSMakeRect(8, y, rightW - 16, third), @[@[@"name", @"Name", @"130"], @[@"pos", @"Position", @"90"]], self, NO); y += third + 4;
    [R addSubview:[SVButton buttonWithTitle:@"Add at Playhead" target:self action:@selector(addMarkerAtPlayhead:) frame:NSMakeRect(8, y, 116, 24)]];
    [R addSubview:[SVButton buttonWithTitle:@"Go To" target:self action:@selector(libraryGoMarker:) frame:NSMakeRect(130, y, 62, 24)]];
    [R addSubview:[SVButton buttonWithTitle:@"Delete" target:self action:@selector(libraryDeleteMarker:) frame:NSMakeRect(198, y, 68, 24)]];
    y += 34;
    sectionBar(R, @"ARRANGER SECTIONS", y, rightW); y += 26;
    _sectionTable = makeTable(R, NSMakeRect(8, y, rightW - 16, third), @[@[@"name", @"Name", @"110"], @[@"range", @"Range", @"160"]], self, NO); y += third + 4;
    [R addSubview:[SVButton buttonWithTitle:@"Cycle" target:self action:@selector(libraryLoopSection:) frame:NSMakeRect(8, y, 56, 24)]];
    [R addSubview:[SVButton buttonWithTitle:@"Add to Chain" target:self action:@selector(libraryAppendSection:) frame:NSMakeRect(70, y, 100, 24)]];
    [R addSubview:[SVButton buttonWithTitle:@"Delete" target:self action:@selector(libraryDeleteSection:) frame:NSMakeRect(176, y, 68, 24)]];
    y += 34;
    sectionBar(R, @"ARRANGER CHAIN  (play order)", y, rightW); y += 26;
    _chainTable = makeTable(R, NSMakeRect(8, y, rightW - 16, third), @[@[@"name", @"Section", @"150"], @[@"rep", @"Repeats", @"60"]], self, NO); y += third + 4;
    [R addSubview:[SVButton buttonWithTitle:@"Move Up" target:self action:@selector(libraryChainUp:) frame:NSMakeRect(8, y, 78, 24)]];
    [R addSubview:[SVButton buttonWithTitle:@"Remove" target:self action:@selector(libraryRemoveChainStep:) frame:NSMakeRect(92, y, 74, 24)]];
    [R addSubview:[SVButton buttonWithTitle:@"Flatten to Timeline" target:self action:@selector(flattenArranger:) frame:NSMakeRect(172, y, 140, 24)]];
}

- (void)refreshLibrary {
    if (!_core || !_poolTable) return;
    const Project& p = _core->project();
    std::set<std::string> seen;
    _pool.clear();
    auto add = [&](const std::string& path) { if (!path.empty() && seen.insert(path).second) _pool.push_back(path); };
    for (const auto& t : p.tracks) { add(t.audioPath); for (const auto& c : t.clips) add(c.audioPath); }
    [_poolTable reloadData];
    [_markerTable reloadData];
    [_sectionTable reloadData];
    [_chainTable reloadData];
    [_pluginTable reloadData];
}

// ================================================================ edit page ==
- (void)fillTools:(SVFlipView*)view titles:(NSArray<NSString*>*)titles selectors:(NSArray<NSString*>*)sels top:(CGFloat)top {
    const CGFloat colW = (view.bounds.size.width - 8 * 3) / 2.0;
    for (NSUInteger i = 0; i < titles.count; ++i) {
        const CGFloat x = 8 + (i % 2) * (colW + 8);
        const CGFloat y = top + (i / 2) * 30;
        [view addSubview:[SVButton buttonWithTitle:titles[i] target:self action:NSSelectorFromString(sels[i]) frame:NSMakeRect(x, y, colW, 24)]];
    }
}

- (void)gridPicked:(NSPopUpButton*)pop {
    static const std::uint32_t divs[4] = {1U, 2U, 4U, 8U};
    const NSInteger i = std::clamp<NSInteger>(pop.indexOfSelectedItem, 0, 3);
    _gridDiv = divs[i];
    [_noteGrid setNeedsDisplay:YES];
    [_arrange setNeedsDisplay:YES];
}

- (void)buildEditPage:(NSView*)page {
    const NSRect b = page.bounds;
    const CGFloat docW = kPanelContentW, topH = 36;
    // One view holds the whole editor. It sits on this page (full page) or under the tracks of the Project page.
    // Its settings live in the EDITOR tab of the Inspector (as the Editor inspector of Cubase).
    SVFlipView* bg = [[SVFlipView alloc] initWithFrame:NSMakeRect(kInspectorPanelW, 0, b.size.width - kInspectorPanelW, b.size.height)];
    bg.fillColor = sv::canvas();
    bg.autoresizingMask = NSViewNotSizable;
    [page addSubview:bg];
    _editorRoot = bg;

    _editorScroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(0, 0, kInspectorPanelW, b.size.height)];
    _editorScroll.hasVerticalScroller = YES; _editorScroll.autohidesScrollers = YES; _editorScroll.borderType = NSNoBorder;
    _editorScroll.drawsBackground = YES; _editorScroll.backgroundColor = sv::panel();
    _editorScroll.autoresizingMask = NSViewNotSizable;
    SVFlipView* doc = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, docW, 620)];
    doc.fillColor = sv::panel();
    _editorScroll.documentView = doc;
    [page addSubview:_editorScroll];

    _midiTools = [[SVSectionStack alloc] initWithFrame:NSMakeRect(0, 0, docW, 620)];
    _midiTools.fillColor = sv::panel();
    [doc addSubview:_midiTools];
    [self buildKeyToolsIn:_midiTools width:docW];
    [_midiTools finishSections];
    [_midiTools foldSectionsNamed:@[@"SELECT AND EDIT", @"QUANTIZE", @"FUNCTIONS", @"TRANSPOSE", @"VIEW"]];

    _audioTools = [[SVSectionStack alloc] initWithFrame:NSMakeRect(0, 0, docW, 560)];
    _audioTools.fillColor = sv::panel();
    [doc addSubview:_audioTools];
    sectionBar(_audioTools, @"SAMPLE EDITOR · SELECTION", 0, docW);
    [self fillTools:_audioTools
             titles:@[@"Select All", @"Crop", @"Cut", @"Copy", @"Paste", @"Delete", @"Duplicate", @"Loop Selection"]
          selectors:@[@"sampleSelectAll:", @"sampleCropToSelection:", @"cutClip:", @"copyClip:", @"pasteClip:", @"deleteSelection:", @"duplicateClip:", @"sampleLoopSelection:"] top:28];
    sectionBar(_audioTools, @"PROCESS · SELECTION OR CLIP", 152, docW);
    [self fillTools:_audioTools
             titles:@[@"Normalize…", @"Gain…", @"Fade In", @"Fade Out", @"Reverse", @"Invert Phase", @"Remove DC", @"Silence", @"Mono Sum", @"Stereo Flip"]
          selectors:@[@"processNormalize:", @"processGain:", @"processFadeIn:", @"processFadeOut:", @"processReverse:", @"processInvert:", @"processDc:", @"processSilence:", @"processMono:", @"processFlip:"] top:180];
    sectionBar(_audioTools, @"TIME / PITCH", 334, docW);
    [self fillTools:_audioTools titles:@[@"Time Stretch…", @"Pitch Shift…"] selectors:@[@"processStretch:", @"processPitch:"] top:362];
    sectionBar(_audioTools, @"CLIP", 396, docW);
    [self fillTools:_audioTools titles:@[@"Clip Gain…", @"Fades…", @"Mute Clip", @"Render in Place"] selectors:@[@"clipGain:", @"clipFades:", @"toggleClipMute:", @"renderInPlace:"] top:424];
    sectionBar(_audioTools, @"QUANTIZE", 488, docW);
    [self fillTools:_audioTools titles:@[@"Audio Quantize", @"Quantize Setup…"] selectors:@[@"audioQuantize:", @"showQuantizePanel:"] top:516];
    [_audioTools finishSections];
    [_audioTools foldSectionsNamed:@[@"CLIP", @"QUANTIZE"]];

    _toneTools = [[SVSectionStack alloc] initWithFrame:NSMakeRect(0, 0, docW, 1200)];
    _toneTools.fillColor = sv::panel();
    _toneTools.hidden = YES;
    [doc addSubview:_toneTools];
    [self buildToneToolsIn:_toneTools width:docW];
    [_toneTools finishSections];
    [_toneTools foldSectionsNamed:@[@"FORMANT AND VOLUME", @"TIME", @"MIDI", @"ANALYSIS · HOW THE SEGMENTS ARE FOUND"]];

    const NSRect eb = bg.bounds;   // the editor itself: strip on top, content under it
    // top strip: title, then (right-aligned) grid, WAVE / TONE, FULL PAGE. Placed by layoutEditorStrip,
    // because the strip is much narrower under the tracks than on the full page.
    SVFlipView* top = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, eb.size.width, topH)];
    top.rail = YES;
    top.autoresizingMask = NSViewWidthSizable | NSViewMaxYMargin;
    [bg addSubview:top];
    _editTitle = makeLabel(top, @"", NSMakeRect(10, 10, 480, 16), sv::ui(12, true), sv::ink());
    _gridPopup = makePopup(top, NSMakeRect(500, 6, 96, 24), self, @selector(gridPicked:));
    [_gridPopup addItemsWithTitles:@[@"Grid 1/4", @"Grid 1/8", @"Grid 1/16", @"Grid 1/32"]];
    [_gridPopup selectItemAtIndex:2];
    // WAVE / TONE: the two ways to edit an audio clip (sample editor, or pitch and timing of one voice)
    _toneModeWave = [SVToggle toggleWithTitle:@"WAVE" color:sv::copper() target:self action:@selector(toneSetModeFromButton:) frame:NSMakeRect(0, 5, 62, 26)];
    _toneModeWave.tag = 0;
    _toneModeWave.state = NSControlStateValueOn;
    [top addSubview:_toneModeWave];
    _toneModeTone = [SVToggle toggleWithTitle:@"TONE" color:sv::copper() target:self action:@selector(toneSetModeFromButton:) frame:NSMakeRect(0, 5, 62, 26)];
    _toneModeTone.tag = 1;
    [top addSubview:_toneModeTone];
    _editPlaceButton = [SVButton buttonWithTitle:@"FULL PAGE" target:self action:@selector(toggleEditorPlace:) frame:NSMakeRect(0, 6, 92, 24)];
    [top addSubview:_editPlaceButton];
    for (NSView* v in top.subviews) v.autoresizingMask = NSViewNotSizable;
    __weak SilvetonController* weakSelf = self;
    top.onLayout = ^{ [weakSelf layoutEditorStrip]; };

    const NSRect content = NSMakeRect(0, topH, eb.size.width, eb.size.height - topH);
    _noteGrid = [[SilvetonNoteGridView alloc] initWithFrame:content];
    _noteGrid.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _noteGrid.controller = self;
    _noteGrid.quarterWidth = 64.0;
    _noteGrid.scrollQuarters = 0.0;
    _noteGrid.scrollPitch = 84.0;
    [bg addSubview:_noteGrid];
    _sampleView = [[SilvetonSampleView alloc] initWithFrame:content];
    _sampleView.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _sampleView.controller = self;
    _sampleView.hidden = YES;
    [bg addSubview:_sampleView];
    _toneView = [[SilvetonToneView alloc] initWithFrame:content];
    _toneView.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _toneView.controller = self;
    _toneView.hidden = YES;
    [bg addSubview:_toneView];
}

// Right-aligned cluster, then the title takes what is left.
- (void)layoutEditorStrip {
    NSView* top = _editTitle.superview;
    if (!top) return;
    const CGFloat w = top.bounds.size.width;
    CGFloat x = w - 6.0;
    auto place = [&](NSView* v, CGFloat width, CGFloat y, CGFloat h, CGFloat gapAfter) {
        x -= width;
        v.frame = NSMakeRect(x, y, width, h);
        x -= gapAfter;
    };
    place(_editPlaceButton, 92.0, 6.0, 24.0, 10.0);
    if (![_toneModeTone isHidden]) {
        place(_toneModeTone, 62.0, 5.0, 26.0, 2.0);
        place(_toneModeWave, 62.0, 5.0, 26.0, 10.0);
    }
    place(_gridPopup, 96.0, 6.0, 24.0, 10.0);
    _editTitle.frame = NSMakeRect(10.0, 10.0, std::max<CGFloat>(0.0, x - 10.0), 16.0);
}

- (void)refreshEditPage {
    if (!_core || !_noteGrid) return;
    const Project& p = _core->project();
    const BOOL midi = self.selectedMidiTrack >= 0 && self.selectedMidiTrack < static_cast<long>(p.midiTracks.size());
    const BOOL audio = !midi && self.selectedTrack >= 0 && self.selectedTrack < static_cast<long>(p.tracks.size()) && self.editedClip != nullptr;
    const BOOL tone = audio && _toneMode;
    _noteGrid.hidden = audio;
    _sampleView.hidden = !audio || tone;
    _toneView.hidden = !tone;
    _toneView.compact = _page != SVPage::Edit;
    _midiTools.hidden = audio;
    _audioTools.hidden = !audio || tone;
    _toneTools.hidden = !tone;
    _toneModeWave.hidden = !audio;
    _toneModeTone.hidden = !audio;
    _toneModeWave.state = tone ? NSControlStateValueOff : NSControlStateValueOn;
    _toneModeTone.state = tone ? NSControlStateValueOn : NSControlStateValueOff;
    _gridPopup.enabled = !audio || tone;
    _editPlaceButton.title = _page == SVPage::Edit ? @"IN PROJECT" : @"FULL PAGE";
    [self layoutEditorStrip];
    if (NSView* doc = _toneTools.superview) {
        NSView* shown = tone ? _toneTools : (audio ? _audioTools : _midiTools);
        NSRect f = doc.frame;
        f.size.height = shown.frame.size.height;
        if (std::abs(f.size.height - doc.frame.size.height) > 0.5) doc.frame = f;
    }
    if (tone) {
        _editTitle.stringValue = [NSString stringWithFormat:@"Tone Editor — %@", sv::ns(p.tracks[static_cast<std::size_t>(self.selectedTrack)].name)];
        [self toneSync];
    } else if (audio) {
        _editTitle.stringValue = [NSString stringWithFormat:@"Sample Editor — %@", sv::ns(p.tracks[static_cast<std::size_t>(self.selectedTrack)].name)];
    } else if (midi) {
        _editTitle.stringValue = [NSString stringWithFormat:@"Key Editor — %@", sv::ns(p.midiTracks[static_cast<std::size_t>(self.selectedMidiTrack)].name)];
    } else {
        _editTitle.stringValue = _page == SVPage::Edit ? @"Editor — select an audio clip or a MIDI part in the Project window first"
                                                       : @"Editor — click an audio clip or a MIDI part in the tracks above";
    }
    [_noteGrid selectionChanged];
    [_sampleView setNeedsDisplay:YES];
    [_toneView setNeedsDisplay:YES];
}

// ===================================================================== menus ==
- (void)buildMenus {
    NSMenu* main = [[NSMenu alloc] initWithTitle:@"Main"];
    auto top = [&](NSString* title) {
        NSMenuItem* item = [[NSMenuItem alloc] initWithTitle:title action:nil keyEquivalent:@""];
        [main addItem:item];
        NSMenu* m = [[NSMenu alloc] initWithTitle:title];
        item.submenu = m;
        return m;
    };
    const NSEventModifierFlags cmd = NSEventModifierFlagCommand, opt = NSEventModifierFlagOption, shift = NSEventModifierFlagShift, none = 0;

    NSMenu* app = top(@"Silveton");
    addItem(app, @"About Silveton", @selector(orderFrontStandardAboutPanel:), @"", none, self);
    [app addItem:[NSMenuItem separatorItem]];
    addItem(app, @"Preferences…", @selector(showPreferences:), @",", cmd, self);
    addItem(app, @"Audio System Setup…", @selector(audioSetup:), @"", none, self);
    addItem(app, @"Save Diagnostic Report", @selector(saveDiagnosticReportAction:), @"", none, self);
    [app addItem:[NSMenuItem separatorItem]];
    addItem(app, @"Quit Silveton", @selector(terminate:), @"q", cmd, self);

    NSMenu* file = top(@"File");
    addItem(file, @"New Project", @selector(newProject:), @"n", cmd, self);
    addItem(file, @"Open…", @selector(openProject:), @"o", cmd, self);
    addItem(file, @"Save", @selector(saveProject:), @"s", cmd, self);
    addItem(file, @"Save As…", @selector(saveProjectAs:), @"s", cmd | shift, self);
    [file addItem:[NSMenuItem separatorItem]];
    addItem(file, @"Import Audio…", @selector(importAudio:), @"i", cmd, self);
    addItem(file, @"Import MIDI File…", @selector(importMidi:), @"i", cmd | shift, self);
    [file addItem:[NSMenuItem separatorItem]];
    addItem(file, @"Export Audio Mixdown…", @selector(exportMixdown:), @"e", cmd, self);
    addItem(file, @"Export Stems…", @selector(exportStems:), @"e", cmd | shift, self);
    addItem(file, @"Export MIDI File…", @selector(exportMidi:), @"", none, self);

    // One home for every command, grouped by what it works on (as the menus of Cubase):
    // Edit = the selection, Audio = sounds and the audio editors, MIDI = notes and the Key Editor.
    auto sub = [&](NSMenu* parent, NSString* title) {
        NSMenuItem* item = [parent addItemWithTitle:title action:nil keyEquivalent:@""];
        NSMenu* m = [[NSMenu alloc] initWithTitle:title];
        item.submenu = m;
        return m;
    };

    NSMenu* edit = top(@"Edit");
    addItem(edit, @"Undo", @selector(undo:), @"z", cmd, self);
    addItem(edit, @"Redo", @selector(redo:), @"z", cmd | shift, self);
    [edit addItem:[NSMenuItem separatorItem]];
    addItem(edit, @"Cut", @selector(cutClip:), @"x", cmd, self);
    addItem(edit, @"Copy", @selector(copyClip:), @"c", cmd, self);
    addItem(edit, @"Paste at Cursor", @selector(pasteClip:), @"v", cmd, self);
    addItem(edit, @"Duplicate", @selector(duplicateClip:), @"d", cmd, self);
    addItem(edit, @"Delete", @selector(deleteSelection:), @"\x7f", none, self);
    [edit addItem:[NSMenuItem separatorItem]];
    addItem(edit, @"Split at Cursor", @selector(splitAtPlayhead:), @"x", opt, self);
    addItem(edit, @"Mute / Unmute", @selector(toggleClipMute:), @"m", none, self);   // plain M, as in Cubase; ⌘M stays Minimize
    // The tools of the Project window (the tool row above the tracks; keys 1–8 work when the tracks have the focus).
    NSMenu* toolMenu = sub(edit, @"Tool");
    NSArray<NSString*>* toolTitles = @[@"Object Selection", @"Range Selection", @"Split", @"Glue", @"Erase", @"Zoom", @"Mute", @"Draw"];
    for (NSUInteger i = 0; i < toolTitles.count; ++i)
        addItem(toolMenu, toolTitles[i], @selector(pickArrangeTool:), [NSString stringWithFormat:@"%lu", (unsigned long)(i + 1)], none, self).tag = static_cast<NSInteger>(i);
    // What a marked range can do (as Edit > Range of Cubase). Cut, Copy, Paste and Delete above work on it too.
    NSMenu* range = sub(edit, @"Range");
    addItem(range, @"Cut Time", @selector(rangeCutTime:), @"", none, self);
    addItem(range, @"Delete Time", @selector(rangeDeleteTime:), @"", none, self);
    addItem(range, @"Insert Silence", @selector(rangeInsertSilence:), @"", none, self);
    [range addItem:[NSMenuItem separatorItem]];
    addItem(range, @"Split at Range Edges", @selector(rangeSplit:), @"", none, self);
    addItem(range, @"Crop to Range", @selector(rangeCrop:), @"", none, self);
    [range addItem:[NSMenuItem separatorItem]];
    addItem(range, @"Set Cycle to Range", @selector(rangeSetCycle:), @"p", none, self);
    addItem(range, @"Zoom to Range", @selector(rangeZoom:), @"", none, self);
    NSMenu* nudge = sub(edit, @"Nudge");
    addItem(nudge, @"Left (one grid step)", @selector(nudgeLeft:), @"[", opt, self);
    addItem(nudge, @"Right (one grid step)", @selector(nudgeRight:), @"]", opt, self);
    NSMenu* select = sub(edit, @"Select");
    addItem(select, @"All", @selector(sampleSelectAll:), @"a", cmd, self);
    addItem(select, @"None", @selector(keySelectNone:), @"", none, self);
    addItem(select, @"Invert", @selector(keySelectInvert:), @"", none, self);
    addItem(select, @"Same Pitch", @selector(keySelectSamePitch:), @"", none, self);
    addItem(select, @"From Cursor to End", @selector(keySelectFromCursor:), @"", none, self);
    [edit addItem:[NSMenuItem separatorItem]];
    addItem(edit, @"Rename…", @selector(renameSelected:), @"r", cmd, self);

    NSMenu* proj = top(@"Project");
    addItem(proj, @"Add Audio Track", @selector(addAudioTrack:), @"a", cmd | opt, self);
    addItem(proj, @"Add Instrument Track", @selector(addInstrumentTrack:), @"i", cmd | opt, self);
    addItem(proj, @"Add MIDI Track", @selector(addMidiTrack:), @"m", cmd | opt, self);
    addItem(proj, @"Add Group Channel", @selector(addGroupBus:), @"", none, self);
    addItem(proj, @"Add FX Channel", @selector(addFxBus:), @"", none, self);
    addItem(proj, @"Add Folder", @selector(addFolder:), @"", none, self);
    [proj addItem:[NSMenuItem separatorItem]];
    // The selected track (the same commands as the channel menu of a right click on a track header or a mixer strip).
    addItem(proj, @"Duplicate Track", @selector(duplicateTrack:), @"", none, self);
    addItem(proj, @"Move Track Up", @selector(moveTrackUp:), @"", none, self);
    addItem(proj, @"Move Track Down", @selector(moveTrackDown:), @"", none, self);
    addItem(proj, @"Lock / Unlock Track", @selector(toggleLock:), @"l", cmd, self);
    addItem(proj, @"Render Track in Place", @selector(renderInPlace:), @"", none, self);
    addItem(proj, @"Remove Track", @selector(deleteTrack:), @"", none, self);
    [proj addItem:[NSMenuItem separatorItem]];
    addItem(proj, @"Project Notes…", @selector(projectNotes:), @"", none, self);
    addItem(proj, @"Flatten Arranger Chain", @selector(flattenArranger:), @"", none, self);
    [proj addItem:[NSMenuItem separatorItem]];
    addItem(proj, @"Project Setup…", @selector(showProjectSetup:), @"", none, self);
    addItem(proj, @"Scan VST3 Plug-ins", @selector(scanPlugins:), @"", none, self);

    NSMenu* audio = top(@"Audio");
    NSMenu* process = sub(audio, @"Process");
    addItem(process, @"Normalize…", @selector(processNormalize:), @"", none, self);
    addItem(process, @"Gain…", @selector(processGain:), @"", none, self);
    addItem(process, @"Fade In", @selector(processFadeIn:), @"", none, self);
    addItem(process, @"Fade Out", @selector(processFadeOut:), @"", none, self);
    addItem(process, @"Reverse", @selector(processReverse:), @"", none, self);
    addItem(process, @"Invert Phase", @selector(processInvert:), @"", none, self);
    addItem(process, @"Remove DC Offset", @selector(processDc:), @"", none, self);
    addItem(process, @"Silence", @selector(processSilence:), @"", none, self);
    addItem(process, @"Mono Sum", @selector(processMono:), @"", none, self);
    addItem(process, @"Stereo Flip", @selector(processFlip:), @"", none, self);
    [process addItem:[NSMenuItem separatorItem]];
    addItem(process, @"Time Stretch…", @selector(processStretch:), @"", none, self);
    addItem(process, @"Pitch Shift…", @selector(processPitch:), @"", none, self);
    NSMenu* clip = sub(audio, @"Clip");
    addItem(clip, @"Clip Gain…", @selector(clipGain:), @"", none, self);
    addItem(clip, @"Clip Fades…", @selector(clipFades:), @"", none, self);
    addItem(clip, @"Crossfade", @selector(crossfadeClips:), @"x", none, self);   // X, as in Cubase: the clip and the next one blend
    addItem(audio, @"Audio Quantize", @selector(audioQuantize:), @"q", opt, self);
    [audio addItem:[NSMenuItem separatorItem]];
    addItem(audio, @"Open in Sample Editor", @selector(openEditor:), @"\r", none, self);
    NSMenu* sample = sub(audio, @"Sample Editor");
    addItem(sample, @"Crop to Selection", @selector(sampleCropToSelection:), @"", none, self);
    addItem(sample, @"Loop Selection", @selector(sampleLoopSelection:), @"", none, self);
    addItem(sample, @"Zoom to Fit", @selector(sampleZoomFit:), @"", none, self);
    [sample addItem:[NSMenuItem separatorItem]];
    addItem(sample, @"Zero Crossing Snap", @selector(toggleSampleZeroSnap:), @"", none, self);
    addItem(sample, @"Ripple Edit", @selector(toggleSampleRipple:), @"", none, self);
    [audio addItem:[NSMenuItem separatorItem]];
    addItem(audio, @"Open in Tone Editor", @selector(openToneEditor:), @"t", none, self);
    NSMenu* tone = sub(audio, @"Tone Editor");
    addItem(tone, @"Semitone Up", @selector(toneUp:), @"", none, self);
    addItem(tone, @"Semitone Down", @selector(toneDown:), @"", none, self);
    addItem(tone, @"Octave Up", @selector(toneOctaveUp:), @"", none, self);
    addItem(tone, @"Octave Down", @selector(toneOctaveDown:), @"", none, self);
    [tone addItem:[NSMenuItem separatorItem]];
    addItem(tone, @"Correct Pitch 100 %", @selector(toneSnapFull:), @"", none, self);
    addItem(tone, @"Straighten 100 %", @selector(toneFlattenFull:), @"", none, self);
    addItem(tone, @"Snap Timing to Grid", @selector(toneQuantizeTiming:), @"", none, self);
    addItem(tone, @"Scale Suggestions", @selector(toneDetectScale:), @"", none, self);
    [tone addItem:[NSMenuItem separatorItem]];
    addItem(tone, @"Cut Segment at Cursor", @selector(toneSplitAtPlayhead:), @"", none, self);
    addItem(tone, @"Glue Segments", @selector(toneGlueSelected:), @"", none, self);
    addItem(tone, @"Bypass / Use Segments", @selector(toneBypassSelected:), @"", none, self);
    addItem(tone, @"Reset Segments", @selector(toneResetSelected:), @"", none, self);
    addItem(tone, @"Remove Segments", @selector(toneDeleteSelected:), @"", none, self);
    [tone addItem:[NSMenuItem separatorItem]];
    addItem(tone, @"Extract MIDI from Tones", @selector(toneExtractMidi:), @"", none, self);

    NSMenu* midi = top(@"MIDI");
    addItem(midi, @"Quantize", @selector(midiQuantize:), @"q", none, self);
    addItem(midi, @"Quantize Setup…", @selector(showQuantizePanel:), @"q", shift, self);
    NSMenu* quant = sub(midi, @"More Quantize");
    addItem(quant, @"Soft Quantize", @selector(midiQuantizeSoft:), @"", none, self);
    addItem(quant, @"Quantize Ends", @selector(midiQuantizeEnds:), @"", none, self);
    addItem(quant, @"Quantize Length", @selector(midiQuantizeLength:), @"", none, self);
    [quant addItem:[NSMenuItem separatorItem]];
    addItem(quant, @"Apply Groove Quantize", @selector(midiGrooveApply:), @"", none, self);
    addItem(quant, @"Extract Groove from Part", @selector(midiGrooveExtract:), @"", none, self);
    NSMenu* functions = sub(midi, @"Functions");
    addItem(functions, @"Legato", @selector(midiLegato:), @"", none, self);
    addItem(functions, @"Fixed Length", @selector(midiFixedLength:), @"", none, self);
    addItem(functions, @"Velocity…", @selector(midiVelocity:), @"", none, self);
    addItem(functions, @"Compress Velocity", @selector(midiCompress:), @"", none, self);
    addItem(functions, @"Humanize", @selector(midiHumanize:), @"", none, self);
    addItem(functions, @"Delete Doubles", @selector(midiDeleteDoubles:), @"", none, self);
    addItem(functions, @"Retrograde", @selector(midiRetrograde:), @"", none, self);
    addItem(functions, @"Invert", @selector(midiInvert:), @"", none, self);
    NSMenu* transpose = sub(midi, @"Transpose");
    addItem(transpose, @"Up 1 Semitone", @selector(midiUp:), @"", none, self);
    addItem(transpose, @"Down 1 Semitone", @selector(midiDown:), @"", none, self);
    addItem(transpose, @"Up an Octave", @selector(midiOctaveUp:), @"", none, self);
    addItem(transpose, @"Down an Octave", @selector(midiOctaveDown:), @"", none, self);
    [midi addItem:[NSMenuItem separatorItem]];
    addItem(midi, @"Open in Key Editor", @selector(openEditor:), @"", none, self);
    NSMenu* keyMenu = sub(midi, @"Key Editor");
    addItem(keyMenu, @"Fit Notes to Scale", @selector(keyFitToScale:), @"", none, self);
    addItem(keyMenu, @"Cut Notes at Cursor", @selector(keySplitAtCursor:), @"", none, self);
    addItem(keyMenu, @"Glue Notes", @selector(keyGlueSelected:), @"", none, self);
    addItem(keyMenu, @"Thin Out Controller Lane", @selector(keyThinLane:), @"", none, self);

    NSMenu* tr = top(@"Transport");
    addItem(tr, @"Play", @selector(togglePlay:), @" ", none, self);
    addItem(tr, @"Stop", @selector(stop:), @".", none, self);
    addItem(tr, @"Record", @selector(record:), @"*", none, self);
    addItem(tr, @"Cycle", @selector(toggleCycle:), @"/", none, self);
    addItem(tr, @"Metronome Click", @selector(toggleMetronome:), @"c", none, self);
    [tr addItem:[NSMenuItem separatorItem]];
    addItem(tr, @"Go to Start", @selector(goToStart:), @",", none, self);
    addItem(tr, @"Previous Bar", @selector(rewindBar:), fkey(NSLeftArrowFunctionKey), none, self);
    addItem(tr, @"Next Bar", @selector(forwardBar:), fkey(NSRightArrowFunctionKey), none, self);
    addItem(tr, @"Previous Marker", @selector(previousMarker:), fkey(NSLeftArrowFunctionKey), cmd, self);
    addItem(tr, @"Next Marker", @selector(nextMarker:), fkey(NSRightArrowFunctionKey), cmd, self);
    addItem(tr, @"Insert Marker", @selector(addMarkerAtPlayhead:), fkey(NSInsertFunctionKey), none, self);
    addItem(tr, @"Locate…", @selector(gotoPositionDialog:), @"", none, self);
    addItem(tr, @"Tempo…", @selector(editTempo:), @"", none, self);
    addItem(tr, @"Time Signature…", @selector(editSignature:), @"", none, self);

    NSMenu* view = top(@"View");
    addItem(view, @"Project", @selector(showArrangePage:), fkey(NSF2FunctionKey), none, self);
    addItem(view, @"Mixer", @selector(showMixPage:), fkey(NSF3FunctionKey), none, self);
    addItem(view, @"Editor (Full Page)", @selector(showEditPage:), fkey(NSF4FunctionKey), none, self);
    addItem(view, @"Library", @selector(showLibraryPage:), fkey(NSF5FunctionKey), none, self);
    [view addItem:[NSMenuItem separatorItem]];
    addItem(view, @"Inspector", @selector(toggleChannelPanel:), @"", none, self);
    addItem(view, @"Lower Zone", @selector(toggleLowerZone:), @"", none, self);
    addItem(view, @"Editor Under the Tracks", @selector(toggleEditorZone:), @"e", opt, self);
    addItem(view, @"Mixer Under the Tracks", @selector(toggleDockMixer:), @"", none, self);
    addItem(view, @"Level Panel", @selector(toggleMeterPanel:), @"", none, self);
    addItem(view, @"Snap", @selector(toggleSnap:), @"j", none, self);
    addItem(view, @"Zoom In", @selector(zoomIn:), @"h", none, self);
    addItem(view, @"Zoom Out", @selector(zoomOut:), @"g", none, self);
    addItem(view, @"Zoom to Project", @selector(zoomToProject:), @"", none, self);
    addItem(view, @"Zoom to Selection", @selector(sampleZoomSelection:), @"", none, self);
    addItem(view, @"Automation Lanes", @selector(toggleAutomationLanes:), @"a", opt, self);   // Volume / Pan / Mute under the selected track
    addItem(view, @"Take Lanes", @selector(toggleTakeLanes:), @"t", opt, self);               // the recorded takes under the selected track
    addItem(view, @"Tempo Track", @selector(toggleTempoTrack:), @"", none, self);              // tempo changes as points under the arranger row
    [view addItem:[NSMenuItem separatorItem]];
    addItem(view, @"Zoom Track", @selector(setTrackHeight:), @"z", none, self).tag = -2;
    NSMenuItem* heightItem = [[NSMenuItem alloc] initWithTitle:@"Track Height" action:nil keyEquivalent:@""];
    NSMenu* heights = [[NSMenu alloc] initWithTitle:@"Track Height"];
    addItem(heights, @"Small", @selector(setTrackHeight:), @"", none, self).tag = 32;
    addItem(heights, @"Normal", @selector(setTrackHeight:), @"", none, self).tag = 0;
    addItem(heights, @"Large", @selector(setTrackHeight:), @"", none, self).tag = 96;
    addItem(heights, @"Huge", @selector(setTrackHeight:), @"", none, self).tag = 192;
    addItem(heights, @"Fill the Window", @selector(setTrackHeight:), @"", none, self).tag = -1;
    [heights addItem:[NSMenuItem separatorItem]];
    addItem(heights, @"All Tracks Normal", @selector(setTrackHeight:), @"", none, self).tag = -3;
    heightItem.submenu = heights;
    [view addItem:heightItem];

    NSMenu* window = top(@"Window");
    addItem(window, @"Minimize", @selector(performMiniaturize:), @"m", cmd, nil);
    [NSApp setWindowsMenu:window];

    [NSApp setMainMenu:main];
}

@end
