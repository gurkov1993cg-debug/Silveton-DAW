// Silveton visual language: dense professional DAW surfaces (dark grey panels,
// flat cells, coloured regions), copper accent, custom-drawn controls.
#pragma once
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>

#include "silveton/WaveformCache.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>

namespace sv {

inline NSColor* rgb(double r, double g, double b, double a = 1.0) {
    return [NSColor colorWithCalibratedRed:r green:g blue:b alpha:a];
}
inline NSColor* hex(std::uint32_t v, double a = 1.0) {
    return rgb(((v >> 16) & 0xFF) / 255.0, ((v >> 8) & 0xFF) / 255.0, (v & 0xFF) / 255.0, a);
}

// Surfaces
inline NSColor* canvas()     { return hex(0x232325); }
inline NSColor* panel()      { return hex(0x2E2E31); }
inline NSColor* raised()     { return hex(0x3A3A3E); }
inline NSColor* raisedHi()   { return hex(0x4A4A4F); }
inline NSColor* hairline()   { return hex(0x1A1A1C); }
inline NSColor* laneA()      { return hex(0x232325); }
inline NSColor* laneB()      { return hex(0x272729); }
inline NSColor* laneSel()    { return hex(0x2F2B28); }
// Ink
inline NSColor* ink()        { return hex(0xE6E6E6); }
inline NSColor* inkDim()     { return hex(0xA3A3A8); }
inline NSColor* inkFaint()   { return hex(0x6E6E74); }
// Accents
inline NSColor* copper()     { return hex(0xD9824B); }
inline NSColor* copperDeep() { return hex(0x8E4F2B); }
inline NSColor* sage()       { return hex(0x5FB34E); }
inline NSColor* amber()      { return hex(0xE7B54A); }
inline NSColor* rec()        { return hex(0xE0533F); }
inline NSColor* soloTint()   { return hex(0x5FB34E); }
inline NSColor* muteTint()   { return hex(0xE0B64A); }

inline NSFont* ui(CGFloat size, bool bold = false) {
    return [NSFont systemFontOfSize:size weight:(bold ? NSFontWeightSemibold : NSFontWeightRegular)];
}
inline NSFont* mono(CGFloat size, bool bold = false) {
    return [NSFont monospacedDigitSystemFontOfSize:size weight:(bold ? NSFontWeightMedium : NSFontWeightRegular)];
}

inline NSString* ns(const std::string& s) {
    NSString* r = [[NSString alloc] initWithBytes:s.data() length:s.size() encoding:NSUTF8StringEncoding];
    return r ? r : @"";
}
inline std::string str(NSString* s) {
    if (s == nil) return {};
    const char* p = [s UTF8String];
    return p ? std::string(p) : std::string();
}

inline void fill(NSRect r, NSColor* c) { [c setFill]; NSRectFill(r); }
// Flat, dense professional look: corners never rounder than 3 px.
inline CGFloat flat(CGFloat radius) { return radius > 3.0 ? 3.0 : radius; }
inline void roundFill(NSRect r, CGFloat radius, NSColor* c) {
    radius = flat(radius);
    [c setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}
inline void roundStroke(NSRect r, CGFloat radius, NSColor* c, CGFloat width = 1.0) {
    radius = flat(radius);
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(r, width * 0.5, width * 0.5) xRadius:radius yRadius:radius];
    p.lineWidth = width;
    [p stroke];
}
inline void line(NSPoint a, NSPoint b, NSColor* c, CGFloat width = 1.0) {
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPath];
    p.lineWidth = width;
    [p moveToPoint:a];
    [p lineToPoint:b];
    [p stroke];
}
inline void text(NSString* s, NSPoint at, NSFont* font, NSColor* color) {
    [s drawAtPoint:at withAttributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color}];
}
inline NSSize textSize(NSString* s, NSFont* font) {
    return [s sizeWithAttributes:@{NSFontAttributeName: font}];
}
inline void textIn(NSString* s, NSRect r, NSFont* font, NSColor* color, NSTextAlignment align = NSTextAlignmentLeft) {
    NSMutableParagraphStyle* style = [[NSMutableParagraphStyle alloc] init];
    style.alignment = align;
    style.lineBreakMode = NSLineBreakByTruncatingTail;
    [s drawInRect:r withAttributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color,
                                     NSParagraphStyleAttributeName: style}];
}
// Small pill toggle (M / S / R / I) drawn inside track headers and strips.
inline void pill(NSRect r, NSString* label, bool on, NSColor* onColor) {
    roundFill(r, 4.0, on ? onColor : raisedHi());
    NSFont* f = ui(9.0, true);
    const NSSize sz = textSize(label, f);
    text(label, NSMakePoint(NSMidX(r) - sz.width * 0.5, NSMidY(r) - sz.height * 0.5), f, on ? canvas() : inkDim());
}

inline double clamp01(double v) { return std::max(0.0, std::min(1.0, v)); }
inline double meterNorm(float linear) {
    const double db = linear > 0.0F ? 20.0 * std::log10(static_cast<double>(linear)) : -90.0;
    return clamp01((db + 60.0) / 66.0);  // -60..+6 dB
}

// Real min/max envelope drawing from the background waveform cache.
inline void drawWaveform(const silveton::WaveformOverview& overview, std::uint64_t sourceStart, std::uint64_t sourceLength,
                         NSRect rect, NSColor* color, bool flipped) {
    if (overview.empty() || sourceLength == 0U || rect.size.width < 1.0 || rect.size.height < 2.0 ||
        overview.framesPerPeak == 0U || overview.peaks.empty()) return;
    const std::uint64_t available = sourceStart < overview.frames ? overview.frames - sourceStart : 0U;
    sourceLength = std::min(sourceLength, available);
    if (sourceLength == 0U) return;
    const std::uint32_t channels = std::min<std::uint32_t>(overview.channels, 2U);
    const NSInteger columns = std::max<NSInteger>(1, static_cast<NSInteger>(std::ceil(rect.size.width)));
    [color setStroke];
    for (std::uint32_t channel = 0U; channel < channels; ++channel) {
        if (channel >= overview.peaks.size() || overview.peaks[channel].empty()) continue;
        const CGFloat bandH = rect.size.height / static_cast<CGFloat>(channels);
        const CGFloat center = rect.origin.y + bandH * (static_cast<CGFloat>(channel) + 0.5);
        const CGFloat amplitude = std::max<CGFloat>(1.0, bandH * 0.46);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.0;
        const auto& peaks = overview.peaks[channel];
        for (NSInteger x = 0; x < columns; ++x) {
            const double u0 = static_cast<double>(x) / static_cast<double>(columns);
            const double u1 = static_cast<double>(x + 1) / static_cast<double>(columns);
            const std::uint64_t s0 = sourceStart + static_cast<std::uint64_t>(u0 * static_cast<double>(sourceLength));
            const std::uint64_t s1 = std::min<std::uint64_t>(sourceStart + sourceLength,
                sourceStart + std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::ceil(u1 * static_cast<double>(sourceLength)))));
            const std::uint64_t p0 = s0 / overview.framesPerPeak;
            const std::uint64_t p1 = std::min<std::uint64_t>(peaks.size(), (s1 + overview.framesPerPeak - 1U) / overview.framesPerPeak);
            if (p0 >= p1 || p0 >= peaks.size()) continue;
            float mn = peaks[static_cast<std::size_t>(p0)].minimum, mx = peaks[static_cast<std::size_t>(p0)].maximum;
            for (std::uint64_t pi = p0 + 1U; pi < p1; ++pi) {
                mn = std::min(mn, peaks[static_cast<std::size_t>(pi)].minimum);
                mx = std::max(mx, peaks[static_cast<std::size_t>(pi)].maximum);
            }
            mn = std::max(-1.0F, std::min(1.0F, mn));
            mx = std::max(-1.0F, std::min(1.0F, mx));
            const CGFloat px = rect.origin.x + static_cast<CGFloat>(x) + 0.5;
            const CGFloat sign = flipped ? -1.0 : 1.0;
            [path moveToPoint:NSMakePoint(px, center - sign * static_cast<CGFloat>(mx) * amplitude)];
            [path lineToPoint:NSMakePoint(px, center - sign * static_cast<CGFloat>(mn) * amplitude)];
        }
        [path stroke];
    }
}

} // namespace sv
