// Silveton visual language: dense professional DAW surfaces (dark grey panels,
// flat cells, coloured regions), copper accent, custom-drawn controls.
#pragma once
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>

#include "silveton/WaveformCache.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>

namespace sv {

inline NSColor* rgb(double r, double g, double b, double a = 1.0) {
    return [NSColor colorWithCalibratedRed:r green:g blue:b alpha:a];
}
inline NSColor* hex(std::uint32_t v, double a = 1.0) {
    return rgb(((v >> 16) & 0xFF) / 255.0, ((v >> 8) & 0xFF) / 255.0, (v & 0xFF) / 255.0, a);
}

// Surfaces: calm blue-grey "dark metal" (the sampler's dark theme, toned down).
inline NSColor* canvas()     { return hex(0x1E2025); }
inline NSColor* panel()      { return hex(0x23262C); }
inline NSColor* raised()     { return hex(0x383C44); }
inline NSColor* raisedHi()   { return hex(0x4A4E58); }
inline NSColor* hairline()   { return hex(0x111216); }
inline NSColor* laneA()      { return hex(0x141519); }
inline NSColor* laneB()      { return hex(0x17181C); }
inline NSColor* laneSel()    { return hex(0x1F2127); }
// Ink
inline NSColor* ink()        { return hex(0xE2E4E8); }
inline NSColor* inkDim()     { return hex(0xBEC2CC); }
inline NSColor* inkFaint()   { return hex(0x969CA8); }
// Accents. `copper()` is the one bright accent (amber, like a lit lamp): it is only used for
// things that are ON or selected (playing, cycle, selection, playhead). Everything else is muted.
inline NSColor* copper()     { return hex(0xFFB347); }
inline NSColor* copperDeep() { return hex(0x8F6428); }
inline NSColor* gold()       { return hex(0xDEBA6E); }   // wordmark, section titles, lit page keys
inline NSColor* sage()       { return hex(0x548A64); }
inline NSColor* amber()      { return hex(0xC8AC68); }
inline NSColor* rec()        { return hex(0xD06852); }
inline NSColor* soloTint()   { return hex(0xE2C470); }
inline NSColor* muteTint()   { return hex(0xD4685E); }

// ---- Type scale (points). Nothing in the interface is ever set smaller than
// `caption`: ui()/mono() enforce that floor, so a stray tiny size cannot ship.
namespace type {
constexpr CGFloat caption = 11.0;   // ALL-CAPS micro labels, badges
constexpr CGFloat label   = 12.0;   // control labels, values, buttons
constexpr CGFloat body    = 13.0;   // names, table rows, menus
constexpr CGFloat title   = 14.0;   // section / dialog titles
constexpr CGFloat heading = 16.0;   // page headings
constexpr CGFloat display = 24.0;   // transport counter
}
// Small text on a dark background needs a little more weight to stay crisp on
// a non-Retina screen: below 12 pt the regular face is drawn Medium.
inline NSFont* ui(CGFloat size, bool bold = false) {
    size = std::max(size, type::caption);
    const CGFloat weight = bold ? NSFontWeightSemibold : (size < 12.0 ? NSFontWeightMedium : NSFontWeightRegular);
    return [NSFont systemFontOfSize:size weight:weight];
}
inline NSFont* mono(CGFloat size, bool bold = false) {
    size = std::max(size, type::caption);
    return [NSFont monospacedDigitSystemFontOfSize:size weight:(bold ? NSFontWeightSemibold : NSFontWeightMedium)];
}

inline NSString* ns(const std::string& s) {
    NSString* r = [[NSString alloc] initWithBytes:s.data() length:s.size() encoding:NSUTF8StringEncoding];
    return r ? r : @"";
}
inline std::string str(NSString* s) {
    if (s == nil) return {};
    const char* p = [s UTF8String];
    return p ? std::string(p) : std::string();
}

inline void fill(NSRect r, NSColor* c) { [c setFill]; NSRectFill(r); }
// Flat, dense professional look: corners never rounder than 3 px.
inline CGFloat flat(CGFloat radius) { return radius > 3.0 ? 3.0 : radius; }
inline void roundFill(NSRect r, CGFloat radius, NSColor* c) {
    radius = flat(radius);
    [c setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}
inline void roundStroke(NSRect r, CGFloat radius, NSColor* c, CGFloat width = 1.0) {
    radius = flat(radius);
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(r, width * 0.5, width * 0.5) xRadius:radius yRadius:radius];
    p.lineWidth = width;
    [p stroke];
}
inline void line(NSPoint a, NSPoint b, NSColor* c, CGFloat width = 1.0) {
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPath];
    p.lineWidth = width;
    [p moveToPoint:a];
    [p lineToPoint:b];
    [p stroke];
}
inline void text(NSString* s, NSPoint at, NSFont* font, NSColor* color) {
    [s drawAtPoint:at withAttributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color}];
}
inline NSSize textSize(NSString* s, NSFont* font) {
    return [s sizeWithAttributes:@{NSFontAttributeName: font}];
}
inline void textIn(NSString* s, NSRect r, NSFont* font, NSColor* color, NSTextAlignment align = NSTextAlignmentLeft) {
    NSMutableParagraphStyle* style = [[NSMutableParagraphStyle alloc] init];
    style.alignment = align;
    style.lineBreakMode = NSLineBreakByTruncatingTail;
    [s drawInRect:r withAttributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color,
                                     NSParagraphStyleAttributeName: style}];
}
// A hardware-style key for FLIPPED views: dark base, lighter face on top, soft drop shadow.
// A lit key sinks: darker face with a soft glow of `glow` around the inside of its edge.
inline void keyCap(NSRect r, CGFloat radius, bool lit, NSColor* glow) {
    auto fillRound = [](NSRect q, CGFloat rad, NSColor* c) {
        [c setFill];
        [[NSBezierPath bezierPathWithRoundedRect:q xRadius:rad yRadius:rad] fill];
    };
    fillRound(NSOffsetRect(r, 0, 3.0), radius, rgb(0, 0, 0, 0.18));
    fillRound(NSOffsetRect(r, 0, 1.5), radius, rgb(0, 0, 0, 0.28));
    const NSRect face = NSMakeRect(r.origin.x, r.origin.y, r.size.width, r.size.height - 2.0);
    if (lit) {
        fillRound(r, radius, hex(0x08090A));
        fillRound(face, radius, hex(0x181A1E));
        NSColor* g = glow ? glow : copper();
        for (int k = 0; k < 4; ++k) {
            const CGFloat inset = 2.0 + 3.0 * k;
            if (face.size.width - 2.0 * inset < 3.0 || face.size.height - 2.0 * inset < 3.0) break;
            fillRound(NSInsetRect(face, inset, inset), std::max<CGFloat>(2.0, radius - inset), [g colorWithAlphaComponent:(14.0 + 6.0 * k) / 255.0]);
        }
        [hex(0x464A54) setStroke];
        NSBezierPath* top = [NSBezierPath bezierPath];
        [top moveToPoint:NSMakePoint(face.origin.x + radius, face.origin.y + 1.5)];
        [top lineToPoint:NSMakePoint(NSMaxX(face) - radius, face.origin.y + 1.5)];
        [top stroke];
    } else {
        fillRound(r, radius, hex(0x101114));
        // face: lighter at the top, darker at the bottom (drawn in 2 px bands so it never depends on the flip)
        [NSGraphicsContext saveGraphicsState];
        [[NSBezierPath bezierPathWithRoundedRect:face xRadius:radius yRadius:radius] addClip];
        const int bands = std::max(1, static_cast<int>(std::ceil(face.size.height / 2.0)));
        for (int i = 0; i < bands; ++i) {
            const double t = bands > 1 ? static_cast<double>(i) / (bands - 1) : 0.0;
            const double rr = 74.0 + (60.0 - 74.0) * t, gg = 78.0 + (64.0 - 78.0) * t, bb = 88.0 + (72.0 - 88.0) * t;
            fill(NSMakeRect(face.origin.x, face.origin.y + 2.0 * i, face.size.width, 2.0), rgb(rr / 255.0, gg / 255.0, bb / 255.0));
        }
        [NSGraphicsContext restoreGraphicsState];
        [hex(0x60646E) setStroke];
        NSBezierPath* top = [NSBezierPath bezierPath];
        [top moveToPoint:NSMakePoint(face.origin.x + radius, face.origin.y + 1.5)];
        [top lineToPoint:NSMakePoint(NSMaxX(face) - radius, face.origin.y + 1.5)];
        [top stroke];
    }
}
// ---- Light displays (LCD): dark glass with amber figures -------------------------------------
inline NSColor* lcdDim()   { return hex(0xB8843C); }   // small labels on a display
inline NSColor* lcdValue() { return hex(0xFFCF8A); }   // secondary figures on a display
// Dark display glass with a soft shadow under its top edge (flipped views).
inline void lcd(NSRect r, CGFloat radius = 8.0) {
    [NSGraphicsContext saveGraphicsState];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] addClip];
    const int bands = std::max(1, static_cast<int>(std::ceil(r.size.height / 2.0)));
    for (int i = 0; i < bands; ++i) {
        const double t = bands > 1 ? static_cast<double>(i) / (bands - 1) : 0.0;
        fill(NSMakeRect(r.origin.x, r.origin.y + 2.0 * i, r.size.width, 2.0),
             rgb((13.0 + 10.0 * t) / 255.0, (15.0 + 11.0 * t) / 255.0, (13.0 + 9.0 * t) / 255.0));
    }
    for (int i = 0; i < 4; ++i) fill(NSMakeRect(r.origin.x, r.origin.y + 2.0 * i, r.size.width, 2.0), rgb(0, 0, 0, 0.45 - 0.11 * i));
    [NSGraphicsContext restoreGraphicsState];
    NSBezierPath* edge = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(r, 0.5, 0.5) xRadius:radius yRadius:radius];
    edge.lineWidth = 1.0;
    [hex(0x08090A) setStroke];
    [edge stroke];
}
// A sunken dark slot (plug-in slot, field, fader groove background).
inline void wellFill(NSRect r, CGFloat radius = 3.0) {
    roundFill(r, radius, hex(0x101114));
    roundStroke(r, radius, rgb(1, 1, 1, 0.05), 1.0);
}
// Fader cap: black body, lighter top band, one white line across the middle (flipped views).
inline void faderCap(NSPoint centre, CGFloat halfW, CGFloat halfH) {
    const NSRect o = NSMakeRect(centre.x - halfW, centre.y - halfH, halfW * 2.0, halfH * 2.0);
    roundFill(NSOffsetRect(o, 0, 2.0), 3.0, rgb(0, 0, 0, 0.45));
    roundFill(o, 3.0, hex(0x3C3C40));
    roundFill(NSInsetRect(o, 1.0, 1.0), 2.5, hex(0x1A1A1C));
    roundFill(NSMakeRect(o.origin.x + 3.0, o.origin.y + 3.0, o.size.width - 6.0, halfH - 3.0), 2.0, hex(0x262629));
    fill(NSMakeRect(o.origin.x + 5.0, centre.y - 1.1, o.size.width - 10.0, 2.2), hex(0xECEAE2));
}

// Small pill toggle (M / S / R / I) drawn inside track headers and strips.
inline void pill(NSRect r, NSString* label, bool on, NSColor* onColor) {
    roundFill(r, 4.0, on ? onColor : raisedHi());
    NSFont* f = ui(type::caption, true);
    const NSSize sz = textSize(label, f);
    text(label, NSMakePoint(NSMidX(r) - sz.width * 0.5, NSMidY(r) - sz.height * 0.5), f, on ? canvas() : inkDim());
}

inline double clamp01(double v) { return std::max(0.0, std::min(1.0, v)); }

// Real min/max envelope drawing from the background waveform cache.
// `sourceStart` / `sourceLength` are clip frames, counted at `projectRate` (what the engine
// plays). The overview is built from the file at ITS OWN rate (files are never converted on
// disk), so the range is scaled to file frames when the two rates differ.
inline void drawWaveform(const silveton::WaveformOverview& overview, std::uint64_t sourceStart, std::uint64_t sourceLength,
                         NSRect rect, NSColor* color, bool flipped,
                         CGFloat visibleMinX = -1.0e9, CGFloat visibleMaxX = 1.0e9, double projectRate = 0.0) {
    if (overview.empty() || sourceLength == 0U || rect.size.width < 1.0 || rect.size.height < 2.0 ||
        overview.framesPerPeak == 0U || overview.peaks.empty()) return;
    if (projectRate > 0.0 && overview.sampleRate > 0U && std::abs(static_cast<double>(overview.sampleRate) - projectRate) > 0.5) {
        const double fileFramesPerClipFrame = static_cast<double>(overview.sampleRate) / projectRate;
        sourceStart = static_cast<std::uint64_t>(std::llround(static_cast<double>(sourceStart) * fileFramesPerClipFrame));
        sourceLength = std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::llround(static_cast<double>(sourceLength) * fileFramesPerClipFrame)));
    }
    const std::uint64_t available = sourceStart < overview.frames ? overview.frames - sourceStart : 0U;
    sourceLength = std::min(sourceLength, available);
    if (sourceLength == 0U) return;
    const std::uint32_t channels = std::min<std::uint32_t>(overview.channels, 2U);
    const NSInteger columns = std::max<NSInteger>(1, static_cast<NSInteger>(std::ceil(rect.size.width)));
    // Only the columns that can actually be seen are built (a long clip at a
    // wide zoom is thousands of pixels wide, most of them off-screen).
    const NSInteger xBegin = std::max<NSInteger>(0, static_cast<NSInteger>(std::floor(std::max<CGFloat>(-1.0e8, visibleMinX - rect.origin.x))) - 1);
    const NSInteger xEnd = std::min<NSInteger>(columns, static_cast<NSInteger>(std::ceil(std::min<CGFloat>(1.0e8, visibleMaxX - rect.origin.x))) + 1);
    if (xBegin >= xEnd) return;
    [color setStroke];
    for (std::uint32_t channel = 0U; channel < channels; ++channel) {
        if (channel >= overview.peaks.size() || overview.peaks[channel].empty()) continue;
        const CGFloat bandH = rect.size.height / static_cast<CGFloat>(channels);
        const CGFloat center = rect.origin.y + bandH * (static_cast<CGFloat>(channel) + 0.5);
        const CGFloat amplitude = std::max<CGFloat>(1.0, bandH * 0.46);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.0;
        const auto& peaks = overview.peaks[channel];
        for (NSInteger x = xBegin; x < xEnd; ++x) {
            const double u0 = static_cast<double>(x) / static_cast<double>(columns);
            const double u1 = static_cast<double>(x + 1) / static_cast<double>(columns);
            const std::uint64_t s0 = sourceStart + static_cast<std::uint64_t>(u0 * static_cast<double>(sourceLength));
            const std::uint64_t s1 = std::min<std::uint64_t>(sourceStart + sourceLength,
                sourceStart + std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::ceil(u1 * static_cast<double>(sourceLength)))));
            const std::uint64_t p0 = s0 / overview.framesPerPeak;
            const std::uint64_t p1 = std::min<std::uint64_t>(peaks.size(), (s1 + overview.framesPerPeak - 1U) / overview.framesPerPeak);
            if (p0 >= p1 || p0 >= peaks.size()) continue;
            float mn = peaks[static_cast<std::size_t>(p0)].minimum, mx = peaks[static_cast<std::size_t>(p0)].maximum;
            for (std::uint64_t pi = p0 + 1U; pi < p1; ++pi) {
                mn = std::min(mn, peaks[static_cast<std::size_t>(pi)].minimum);
                mx = std::max(mx, peaks[static_cast<std::size_t>(pi)].maximum);
            }
            mn = std::max(-1.0F, std::min(1.0F, mn));
            mx = std::max(-1.0F, std::min(1.0F, mx));
            const CGFloat px = rect.origin.x + static_cast<CGFloat>(x) + 0.5;
            const CGFloat sign = flipped ? -1.0 : 1.0;
            [path moveToPoint:NSMakePoint(px, center - sign * static_cast<CGFloat>(mx) * amplitude)];
            [path lineToPoint:NSMakePoint(px, center - sign * static_cast<CGFloat>(mn) * amplitude)];
        }
        [path stroke];
    }
}

} // namespace sv
