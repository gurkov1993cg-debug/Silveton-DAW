// Silveton visual language: the flat, dense look of a current professional DAW. Dark neutral
// surfaces, 1 px hairlines, no shadows, no bevels, no glow, no wood, no chrome: a control is a
// flat shape a shade lighter or darker than its panel, and ONE warm accent marks what is on or
// selected. Everything is custom-drawn through the helpers below, so the look lives in one file.
#pragma once
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>

#include "silveton/WaveformCache.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>

namespace sv {

inline NSColor* rgb(double r, double g, double b, double a = 1.0) {
    return [NSColor colorWithCalibratedRed:r green:g blue:b alpha:a];
}
inline NSColor* hex(std::uint32_t v, double a = 1.0) {
    return rgb(((v >> 16) & 0xFF) / 255.0, ((v >> 8) & 0xFF) / 255.0, (v & 0xFF) / 255.0, a);
}

// Surfaces: calm blue-grey "dark metal" (the sampler's dark theme, toned down).
inline NSColor* canvas()     { return hex(0x1E2025); }
inline NSColor* panel()      { return hex(0x23262C); }
inline NSColor* raised()     { return hex(0x383C44); }
inline NSColor* raisedHi()   { return hex(0x4A4E58); }
inline NSColor* hairline()   { return hex(0x111216); }
inline NSColor* laneA()      { return hex(0x141519); }
inline NSColor* laneB()      { return hex(0x17181C); }
inline NSColor* laneSel()    { return hex(0x1F2127); }
// Ink
inline NSColor* ink()        { return hex(0xE2E4E8); }
inline NSColor* inkDim()     { return hex(0xBEC2CC); }
inline NSColor* inkFaint()   { return hex(0x969CA8); }
// Accents. `copper()` is the one bright accent (amber, like a lit lamp): it is only used for
// things that are ON or selected (playing, cycle, selection, playhead). Everything else is muted.
inline NSColor* copper()     { return hex(0xFFB347); }
inline NSColor* copperDeep() { return hex(0x8F6428); }
// Few colours: graphite surfaces, light grey ink, ONE warm accent family (copper / gold / amber are
// shades of the same lamp colour), the standard red for record and clip, muted mute / solo tints.
inline NSColor* gold()       { return hex(0xC9A86A); }   // wordmark, section titles, lit page keys
inline NSColor* sage()       { return hex(0x7E8C82); }
inline NSColor* amber()      { return hex(0xD9A45A); }
inline NSColor* rec()        { return hex(0xC85A4C); }
inline NSColor* soloTint()   { return hex(0xC9A86A); }
inline NSColor* muteTint()   { return hex(0xB86A60); }

// ---- Type scale (points). Nothing in the interface is ever set smaller than
// `caption`: ui()/mono() enforce that floor, so a stray tiny size cannot ship.
namespace type {
constexpr CGFloat caption = 11.0;   // ALL-CAPS micro labels, badges
constexpr CGFloat label   = 12.0;   // control labels, values, buttons
constexpr CGFloat body    = 13.0;   // names, table rows, menus
constexpr CGFloat title   = 14.0;   // section / dialog titles
constexpr CGFloat heading = 16.0;   // page headings
constexpr CGFloat display = 24.0;   // transport counter
}
// Small text on a dark background needs a little more weight to stay crisp on
// a non-Retina screen: below 12 pt the regular face is drawn Medium.
inline NSFont* ui(CGFloat size, bool bold = false) {
    size = std::max(size, type::caption);
    const CGFloat weight = bold ? NSFontWeightSemibold : (size < 12.0 ? NSFontWeightMedium : NSFontWeightRegular);
    return [NSFont systemFontOfSize:size weight:weight];
}
inline NSFont* mono(CGFloat size, bool bold = false) {
    size = std::max(size, type::caption);
    return [NSFont monospacedDigitSystemFontOfSize:size weight:(bold ? NSFontWeightSemibold : NSFontWeightMedium)];
}

inline NSString* ns(const std::string& s) {
    NSString* r = [[NSString alloc] initWithBytes:s.data() length:s.size() encoding:NSUTF8StringEncoding];
    return r ? r : @"";
}
inline std::string str(NSString* s) {
    if (s == nil) return {};
    const char* p = [s UTF8String];
    return p ? std::string(p) : std::string();
}

inline void fill(NSRect r, NSColor* c) { [c setFill]; NSRectFill(r); }
// Flat look: corners are rounded a little (up to 6 px), never pillowed.
inline CGFloat flat(CGFloat radius) { return radius > 6.0 ? 6.0 : radius; }
inline void roundFill(NSRect r, CGFloat radius, NSColor* c) {
    radius = flat(radius);
    [c setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}
inline void roundStroke(NSRect r, CGFloat radius, NSColor* c, CGFloat width = 1.0) {
    radius = flat(radius);
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(r, width * 0.5, width * 0.5) xRadius:radius yRadius:radius];
    p.lineWidth = width;
    [p stroke];
}
inline void line(NSPoint a, NSPoint b, NSColor* c, CGFloat width = 1.0) {
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPath];
    p.lineWidth = width;
    [p moveToPoint:a];
    [p lineToPoint:b];
    [p stroke];
}
inline void text(NSString* s, NSPoint at, NSFont* font, NSColor* color) {
    [s drawAtPoint:at withAttributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color}];
}
inline NSSize textSize(NSString* s, NSFont* font) {
    return [s sizeWithAttributes:@{NSFontAttributeName: font}];
}
inline void textIn(NSString* s, NSRect r, NSFont* font, NSColor* color, NSTextAlignment align = NSTextAlignmentLeft) {
    NSMutableParagraphStyle* style = [[NSMutableParagraphStyle alloc] init];
    style.alignment = align;
    style.lineBreakMode = NSLineBreakByTruncatingTail;
    [s drawInRect:r withAttributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color,
                                     NSParagraphStyleAttributeName: style}];
}
// A flat key (FLIPPED views): a grey face a shade lighter than the panel with a dark hairline.
// Lit: the face takes a quiet tint of `glow` and a 1 px edge in that colour; the caller draws
// the glyph in the same colour. No shadow, no lip, no glow.
inline void keyCap(NSRect r, CGFloat radius, bool lit, NSColor* glow) {
    radius = std::min<CGFloat>(radius, 4.0);
    NSColor* g = glow ? glow : copper();
    if (lit) {
        roundFill(r, radius, [hex(0x1C1E23) blendedColorWithFraction:0.22 ofColor:g]);
        roundStroke(r, radius, [g colorWithAlphaComponent:0.85], 1.0);
    } else {
        roundFill(r, radius, hex(0x3A3E46));
        roundStroke(r, radius, hex(0x1A1C20), 1.0);
    }
}
// ---- Light displays (LCD): dark glass with amber figures -------------------------------------
inline NSColor* lcdDim()   { return hex(0x8A8F9A); }   // small labels on a display
inline NSColor* lcdValue() { return hex(0xD8DBE0); }   // figures on a display: light, not amber
// A display: a flat dark field with a hairline (flipped views). Figures are light grey; only a
// state that is ON (playing, cycle) is shown in the accent.
inline void lcd(NSRect r, CGFloat radius = 8.0) {
    radius = std::min<CGFloat>(radius, 4.0);
    roundFill(r, radius, hex(0x121316));
    roundStroke(r, radius, hex(0x08090A), 1.0);
}
// A sunken dark slot (plug-in slot, field, fader groove background).
inline void wellFill(NSRect r, CGFloat radius = 3.0) {
    roundFill(r, radius, hex(0x101114));
    roundStroke(r, radius, rgb(1, 1, 1, 0.05), 1.0);
}
// Fader cap: black body, lighter top band, one white line across the middle (flipped views).
inline void faderCap(NSPoint centre, CGFloat halfW, CGFloat halfH) {
    const NSRect o = NSMakeRect(centre.x - halfW, centre.y - halfH, halfW * 2.0, halfH * 2.0);
    roundFill(NSOffsetRect(o, 0, 2.0), 3.0, rgb(0, 0, 0, 0.45));
    roundFill(o, 3.0, hex(0x3C3C40));
    roundFill(NSInsetRect(o, 1.0, 1.0), 2.5, hex(0x1A1A1C));
    roundFill(NSMakeRect(o.origin.x + 3.0, o.origin.y + 3.0, o.size.width - 6.0, halfH - 3.0), 2.0, hex(0x262629));
    fill(NSMakeRect(o.origin.x + 5.0, centre.y - 1.1, o.size.width - 10.0, 2.2), hex(0xECEAE2));
}

// ---- Panel surfaces (flipped views): flat plates, dark fields, plain legends, flat keys, a flat knob and
// a flat fader cap. One look for the mixer, the channel strips and the track headers.
// Flat look: one tone (the two colours of the old gradient, averaged), so the callers stay as they are.
inline void bands(NSRect r, std::uint32_t top, std::uint32_t bottom, CGFloat band = 2.0) {
    (void)band;
    fill(r, [hex(top) blendedColorWithFraction:0.5 ofColor:hex(bottom)]);
}
inline void gradientIn(NSBezierPath* path, NSColor* top, NSColor* bottom) {
    [[top blendedColorWithFraction:0.5 ofColor:bottom] setFill];
    [path fill];
}
// Light edge on top and left, dark edge at the bottom and right: the panel stands out of the surface.
inline void bevel(NSRect r, NSColor* light, NSColor* dark) {
    fill(NSMakeRect(r.origin.x, r.origin.y, r.size.width, 1.0), light);
    fill(NSMakeRect(r.origin.x, r.origin.y, 1.0, r.size.height), light);
    fill(NSMakeRect(r.origin.x, NSMaxY(r) - 1.0, r.size.width, 1.0), dark);
    fill(NSMakeRect(NSMaxX(r) - 1.0, r.origin.y, 1.0, r.size.height), dark);
}
// A channel panel (track header, mixer strip): a flat plate a shade lighter than the surface
// with a hairline; the selected one is lighter still with a light edge. `warm` for the master.
inline void brushedPanel(NSRect r, bool selected, bool warm) {
    const CGFloat radius = 3.0;
    roundFill(r, radius, hex(warm ? (selected ? 0x383631 : 0x2F2D2A) : (selected ? 0x353941 : 0x2B2E34)));
    roundStroke(r, radius, hex(selected ? 0x6A6E78 : 0x1A1C20), 1.0);
}
// A bar of the console surface (transport deck, tool row, tab strips): brushed, light top edge, dark bottom edge.
inline void rail(NSRect r) {
    fill(r, hex(0x2A2D33));
    fill(NSMakeRect(r.origin.x, r.origin.y, r.size.width, 1.0), hex(0x373B42));
    fill(NSMakeRect(r.origin.x, NSMaxY(r) - 1.0, r.size.width, 1.0), hex(0x111216));
}
// A sunken dark slot with an inner shadow under its top edge and a light line under its bottom edge.
inline void sunkenWell(NSRect r, CGFloat radius, NSColor* base) {
    radius = std::min<CGFloat>(std::max<CGFloat>(radius, 2.0), 3.0);
    roundFill(r, radius, base);
    roundStroke(r, radius, rgb(0, 0, 0, 0.45), 1.0);
}
inline void sunkenWell(NSRect r, CGFloat radius = 2.0) { sunkenWell(r, radius, hex(0x111216)); }
// Legends: plain text (no shadow — the flat look).
inline void engraved(NSString* s, NSPoint at, NSFont* font, NSColor* color) { text(s, at, font, color); }
inline void engravedIn(NSString* s, NSRect r, NSFont* font, NSColor* color, NSTextAlignment align = NSTextAlignmentLeft) {
    textIn(s, r, font, color, align);
}
// A small key (M, S, record, AUTO...): flat grey face with a hairline; lit = filled with its colour.
inline void consoleKey(NSRect r, NSString* label, bool lit, NSColor* color) {
    const CGFloat kr = 3.0;
    if (lit) {
        roundFill(r, kr, color);
    } else {
        roundFill(r, kr, hex(0x3A3E46));
        roundStroke(r, kr, hex(0x1A1C20), 1.0);
    }
    NSFont* f = ui(type::caption, true);
    const NSSize sz = textSize(label, f);
    text(label, NSMakePoint(NSMidX(r) - sz.width * 0.5, NSMidY(r) - sz.height * 0.5), f, lit ? hex(0x111111) : hex(0xC8CCD4));
}
// A flat knob with a tick scale around it. `value` −1 … 1 (pan), the pointer at the top for 0.
inline void consoleKnob(NSPoint c, CGFloat r, double value) {
    for (int i = -5; i <= 5; ++i) {
        const double ang = (-225.0 + (i + 5) * 27.0) * M_PI / 180.0;
        const CGFloat len = (i % 5 == 0) ? 8.0 : 7.0;
        line(NSMakePoint(c.x + std::cos(ang) * (r + 5.0), c.y + std::sin(ang) * (r + 5.0)),
             NSMakePoint(c.x + std::cos(ang) * (r + len), c.y + std::sin(ang) * (r + len)), i % 5 == 0 ? hex(0x7A7E88) : hex(0x4A4E57));
    }
    [hex(0x1E2025) setFill];
    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x - r, c.y - r, 2.0 * r, 2.0 * r)] fill];
    NSBezierPath* ring = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x - r + 0.5, c.y - r + 0.5, 2.0 * r - 1.0, 2.0 * r - 1.0)];
    ring.lineWidth = 1.0;
    [hex(0x4A4E57) setStroke];
    [ring stroke];
    const double ang = (-90.0 + value * 135.0) * M_PI / 180.0;
    line(NSMakePoint(c.x + std::cos(ang) * 3.0, c.y + std::sin(ang) * 3.0), NSMakePoint(c.x + std::cos(ang) * (r - 3.0), c.y + std::sin(ang) * (r - 3.0)), hex(0xF2F0E8), 2.0);
    if (std::abs(value) > 0.005) {
        NSBezierPath* arc = [NSBezierPath bezierPath];
        const CGFloat a0 = -90.0, a1 = static_cast<CGFloat>(-90.0 + value * 135.0);
        [arc appendBezierPathWithArcWithCenter:c radius:r + 3.0 startAngle:std::min(a0, a1) endAngle:std::max(a0, a1)];
        arc.lineWidth = 2.0;
        [copper() setStroke];
        [arc stroke];
    }
}
// The fader slot: a narrow dark cut in the panel with the thin track inside.
inline void consoleFaderSlot(NSRect slot) {
    const NSRect s = NSMakeRect(std::round(slot.origin.x), slot.origin.y, std::max<CGFloat>(4.0, std::round(slot.size.width)), slot.size.height);
    fill(NSMakeRect(s.origin.x - 1.0, s.origin.y - 1.0, s.size.width + 2.0, s.size.height + 2.0), hex(0x1A1C20));
    fill(s, hex(0x08090B));
    fill(NSMakeRect(NSMidX(s) - 0.5, s.origin.y + 3.0, 1.0, s.size.height - 6.0), hex(0x2A2D33));   // the track
}
// The cap of a fader (flipped views): a flat charcoal block with a hairline and one bright line
// across the middle in a dark groove. No gradient, no ridges, no shadow.
inline void consoleFaderCap(NSPoint centre, CGFloat halfW, CGFloat halfH) {
    const NSRect o = NSMakeRect(std::round(centre.x - halfW), std::round(centre.y - halfH), std::round(halfW * 2.0), std::round(halfH * 2.0));
    const CGFloat cy = std::round(centre.y);
    roundFill(o, 2.0, hex(0x3C4048));
    roundStroke(o, 2.0, hex(0x0B0C0F), 1.0);
    fill(NSMakeRect(o.origin.x + 2.0, o.origin.y + 1.0, o.size.width - 4.0, 1.0), rgb(1, 1, 1, 0.10));   // top edge
    fill(NSMakeRect(o.origin.x + 2.0, cy - 1.5, o.size.width - 4.0, 3.0), hex(0x0B0C0F));
    fill(NSMakeRect(o.origin.x + 3.0, cy - 0.5, o.size.width - 6.0, 1.0), hex(0xF4F2EA));
}

// Small pill toggle (M / S / R / I) drawn inside track headers and strips.
inline void pill(NSRect r, NSString* label, bool on, NSColor* onColor) {
    roundFill(r, 4.0, on ? onColor : raisedHi());
    NSFont* f = ui(type::caption, true);
    const NSSize sz = textSize(label, f);
    text(label, NSMakePoint(NSMidX(r) - sz.width * 0.5, NSMidY(r) - sz.height * 0.5), f, on ? canvas() : inkDim());
}

inline double clamp01(double v) { return std::max(0.0, std::min(1.0, v)); }

// Real min/max envelope drawing from the background waveform cache.
// `sourceStart` / `sourceLength` are clip frames, counted at `projectRate` (what the engine
// plays). The overview is built from the file at ITS OWN rate (files are never converted on
// disk), so the range is scaled to file frames when the two rates differ.
// `gain` raises the picture (the WAVE slider of the tool row; peaks are cut at the band's edge).
// `combine` draws one envelope for all channels (a low track: both channels in one picture is readable,
// two 10 px bands are not).
inline void drawWaveform(const silveton::WaveformOverview& overview, std::uint64_t sourceStart, std::uint64_t sourceLength,
                         NSRect rect, NSColor* color, bool flipped,
                         CGFloat visibleMinX = -1.0e9, CGFloat visibleMaxX = 1.0e9, double projectRate = 0.0,
                         double gain = 1.0, bool combine = false) {
    if (overview.empty() || sourceLength == 0U || rect.size.width < 1.0 || rect.size.height < 2.0 ||
        overview.framesPerPeak == 0U || overview.peaks.empty()) return;
    if (projectRate > 0.0 && overview.sampleRate > 0U && std::abs(static_cast<double>(overview.sampleRate) - projectRate) > 0.5) {
        const double fileFramesPerClipFrame = static_cast<double>(overview.sampleRate) / projectRate;
        sourceStart = static_cast<std::uint64_t>(std::llround(static_cast<double>(sourceStart) * fileFramesPerClipFrame));
        sourceLength = std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::llround(static_cast<double>(sourceLength) * fileFramesPerClipFrame)));
    }
    const std::uint64_t available = sourceStart < overview.frames ? overview.frames - sourceStart : 0U;
    sourceLength = std::min(sourceLength, available);
    if (sourceLength == 0U) return;
    const std::uint32_t fileChannels = std::min<std::uint32_t>(overview.channels, 2U);
    const std::uint32_t channels = combine ? 1U : fileChannels;
    const NSInteger columns = std::max<NSInteger>(1, static_cast<NSInteger>(std::ceil(rect.size.width)));
    // Zoomed in past the coarse envelope: use the fine one (one peak per 128 frames) when the file has it.
    const double framesPerColumn = static_cast<double>(sourceLength) / static_cast<double>(columns);
    const bool fine = overview.fineFramesPerPeak != 0U && !overview.finePeaks.empty() &&
                      framesPerColumn < static_cast<double>(overview.framesPerPeak) * 1.5;
    const std::uint64_t framesPerPeak = fine ? overview.fineFramesPerPeak : overview.framesPerPeak;
    const auto& levels = fine ? overview.finePeaks : overview.peaks;
    // Only the columns that can actually be seen are built (a long clip at a
    // wide zoom is thousands of pixels wide, most of them off-screen).
    const NSInteger xBegin = std::max<NSInteger>(0, static_cast<NSInteger>(std::floor(std::max<CGFloat>(-1.0e8, visibleMinX - rect.origin.x))) - 1);
    const NSInteger xEnd = std::min<NSInteger>(columns, static_cast<NSInteger>(std::ceil(std::min<CGFloat>(1.0e8, visibleMaxX - rect.origin.x))) + 1);
    if (xBegin >= xEnd) return;
    const float g = static_cast<float>(std::max(0.1, gain));
    for (std::uint32_t channel = 0U; channel < channels; ++channel) {
        if (!combine && (channel >= levels.size() || levels[channel].empty())) continue;
        const CGFloat bandH = rect.size.height / static_cast<CGFloat>(channels);
        const CGFloat center = rect.origin.y + bandH * (static_cast<CGFloat>(channel) + 0.5);
        const CGFloat amplitude = std::max<CGFloat>(1.0, bandH * 0.48);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.0;
        for (NSInteger x = xBegin; x < xEnd; ++x) {
            const double u0 = static_cast<double>(x) / static_cast<double>(columns);
            const double u1 = static_cast<double>(x + 1) / static_cast<double>(columns);
            const std::uint64_t s0 = sourceStart + static_cast<std::uint64_t>(u0 * static_cast<double>(sourceLength));
            const std::uint64_t s1 = std::min<std::uint64_t>(sourceStart + sourceLength,
                sourceStart + std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::ceil(u1 * static_cast<double>(sourceLength)))));
            const std::uint64_t p0 = s0 / framesPerPeak;
            float mn = 1.0F, mx = -1.0F;
            bool any = false;
            const std::uint32_t firstCh = combine ? 0U : channel, lastCh = combine ? fileChannels : channel + 1U;
            for (std::uint32_t ch = firstCh; ch < lastCh; ++ch) {
                if (ch >= levels.size()) continue;
                const auto& peaks = levels[ch];
                const std::uint64_t p1 = std::min<std::uint64_t>(peaks.size(), (s1 + framesPerPeak - 1U) / framesPerPeak);
                if (p0 >= p1 || p0 >= peaks.size()) continue;
                for (std::uint64_t pi = p0; pi < p1; ++pi) {
                    mn = std::min(mn, peaks[static_cast<std::size_t>(pi)].minimum);
                    mx = std::max(mx, peaks[static_cast<std::size_t>(pi)].maximum);
                }
                any = true;
            }
            if (!any) continue;
            mn = std::max(-1.0F, std::min(1.0F, mn * g));
            mx = std::max(-1.0F, std::min(1.0F, mx * g));
            const CGFloat px = rect.origin.x + static_cast<CGFloat>(x) + 0.5;
            const CGFloat sign = flipped ? -1.0 : 1.0;
            [path moveToPoint:NSMakePoint(px, center - sign * static_cast<CGFloat>(mx) * amplitude)];
            [path lineToPoint:NSMakePoint(px, center - sign * static_cast<CGFloat>(mn) * amplitude)];
        }
        // a faint centre line, then the sound
        fill(NSMakeRect(std::max(visibleMinX, rect.origin.x), center - 0.5, std::max<CGFloat>(0.0, std::min(visibleMaxX, NSMaxX(rect)) - std::max(visibleMinX, rect.origin.x)), 1.0),
             [color colorWithAlphaComponent:0.22]);
        [color setStroke];
        [path stroke];
    }
}

// Single samples (the Project window zoomed in to the sample): a line through the sample points
// of the piece `window`, dots on the points once there is room for them, a thin zero line.
// `sourceStart` / `sourceLength` are FILE frames of the clip; `rect` is the clip's waveform area.
inline void drawSamples(const silveton::WaveformWindow& window, std::uint64_t sourceStart, std::uint64_t sourceLength,
                        NSRect rect, NSColor* color, CGFloat visibleMinX, CGFloat visibleMaxX, double gain = 1.0) {
    if (sourceLength == 0U || rect.size.width < 1.0 || rect.size.height < 2.0 || window.audio.frames() == 0U) return;
    const std::uint32_t channels = std::min<std::uint32_t>(static_cast<std::uint32_t>(window.audio.channels()), 2U);
    const double pxPerFrame = static_cast<double>(rect.size.width) / static_cast<double>(sourceLength);
    // the file frames whose points can be seen
    const double fFirst = static_cast<double>(sourceStart) + std::max(0.0, (visibleMinX - rect.origin.x) / pxPerFrame) - 2.0;
    const double fLast = static_cast<double>(sourceStart) + std::min(static_cast<double>(sourceLength), (visibleMaxX - rect.origin.x) / pxPerFrame) + 2.0;
    const std::uint64_t wBegin = window.startFrame, wEnd = window.startFrame + window.audio.frames();
    const std::uint64_t first = std::max<std::uint64_t>(wBegin, static_cast<std::uint64_t>(std::max(0.0, fFirst)));
    const std::uint64_t last = std::min<std::uint64_t>(wEnd, static_cast<std::uint64_t>(std::max(0.0, fLast)));
    if (first >= last) return;
    const bool dots = pxPerFrame >= 6.0;
    for (std::uint32_t channel = 0U; channel < channels; ++channel) {
        const CGFloat bandH = rect.size.height / static_cast<CGFloat>(channels);
        const CGFloat center = rect.origin.y + bandH * (static_cast<CGFloat>(channel) + 0.5);
        const CGFloat amplitude = std::max<CGFloat>(1.0, bandH * 0.46);
        const CGFloat zeroLo = std::max(visibleMinX, rect.origin.x), zeroHi = std::min(visibleMaxX, NSMaxX(rect));
        if (zeroHi > zeroLo) fill(NSMakeRect(zeroLo, center - 0.5, zeroHi - zeroLo, 1.0), [color colorWithAlphaComponent:0.25]);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.0;
        path.lineJoinStyle = NSRoundLineJoinStyle;
        bool open = false;
        for (std::uint64_t f = first; f < last; ++f) {
            const float v = std::max(-1.0F, std::min(1.0F, window.audio.sample(channel, static_cast<std::size_t>(f - wBegin)) * static_cast<float>(gain)));
            const CGFloat px = rect.origin.x + static_cast<CGFloat>((static_cast<double>(f - sourceStart) + 0.5) * pxPerFrame);
            const NSPoint pt = NSMakePoint(px, center - static_cast<CGFloat>(v) * amplitude);
            if (!open) { [path moveToPoint:pt]; open = true; } else [path lineToPoint:pt];
        }
        [color setStroke];
        [path stroke];
        if (dots) {
            [color setFill];
            const CGFloat r = pxPerFrame >= 14.0 ? 2.5 : 1.8;
            for (std::uint64_t f = first; f < last; ++f) {
                const float v = std::max(-1.0F, std::min(1.0F, window.audio.sample(channel, static_cast<std::size_t>(f - wBegin)) * static_cast<float>(gain)));
                const CGFloat px = rect.origin.x + static_cast<CGFloat>((static_cast<double>(f - sourceStart) + 0.5) * pxPerFrame);
                [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(px - r, center - static_cast<CGFloat>(v) * amplitude - r, 2.0 * r, 2.0 * r)] fill];
            }
        }
    }
}

} // namespace sv
