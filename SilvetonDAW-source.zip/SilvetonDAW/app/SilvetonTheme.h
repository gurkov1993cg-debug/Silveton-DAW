// Silveton visual language: dense professional DAW surfaces (dark grey panels,
// flat cells, coloured regions), copper accent, custom-drawn controls.
#pragma once
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>

#include "silveton/WaveformCache.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>

namespace sv {

inline NSColor* rgb(double r, double g, double b, double a = 1.0) {
    return [NSColor colorWithCalibratedRed:r green:g blue:b alpha:a];
}
inline NSColor* hex(std::uint32_t v, double a = 1.0) {
    return rgb(((v >> 16) & 0xFF) / 255.0, ((v >> 8) & 0xFF) / 255.0, (v & 0xFF) / 255.0, a);
}

// Surfaces: calm blue-grey "dark metal" (the sampler's dark theme, toned down).
inline NSColor* canvas()     { return hex(0x1E2025); }
inline NSColor* panel()      { return hex(0x23262C); }
inline NSColor* raised()     { return hex(0x383C44); }
inline NSColor* raisedHi()   { return hex(0x4A4E58); }
inline NSColor* hairline()   { return hex(0x111216); }
inline NSColor* laneA()      { return hex(0x141519); }
inline NSColor* laneB()      { return hex(0x17181C); }
inline NSColor* laneSel()    { return hex(0x1F2127); }
// Ink
inline NSColor* ink()        { return hex(0xE2E4E8); }
inline NSColor* inkDim()     { return hex(0xBEC2CC); }
inline NSColor* inkFaint()   { return hex(0x969CA8); }
// Accents. `copper()` is the one bright accent (amber, like a lit lamp): it is only used for
// things that are ON or selected (playing, cycle, selection, playhead). Everything else is muted.
inline NSColor* copper()     { return hex(0xFFB347); }
inline NSColor* copperDeep() { return hex(0x8F6428); }
// Few colours: graphite surfaces, light grey ink, ONE warm accent family (copper / gold / amber are
// shades of the same lamp colour), the standard red for record and clip, muted mute / solo tints.
inline NSColor* gold()       { return hex(0xC9A86A); }   // wordmark, section titles, lit page keys
inline NSColor* sage()       { return hex(0x7E8C82); }
inline NSColor* amber()      { return hex(0xD9A45A); }
inline NSColor* rec()        { return hex(0xC85A4C); }
inline NSColor* soloTint()   { return hex(0xC9A86A); }
inline NSColor* muteTint()   { return hex(0xB86A60); }

// ---- Type scale (points). Nothing in the interface is ever set smaller than
// `caption`: ui()/mono() enforce that floor, so a stray tiny size cannot ship.
namespace type {
constexpr CGFloat caption = 11.0;   // ALL-CAPS micro labels, badges
constexpr CGFloat label   = 12.0;   // control labels, values, buttons
constexpr CGFloat body    = 13.0;   // names, table rows, menus
constexpr CGFloat title   = 14.0;   // section / dialog titles
constexpr CGFloat heading = 16.0;   // page headings
constexpr CGFloat display = 24.0;   // transport counter
}
// Small text on a dark background needs a little more weight to stay crisp on
// a non-Retina screen: below 12 pt the regular face is drawn Medium.
inline NSFont* ui(CGFloat size, bool bold = false) {
    size = std::max(size, type::caption);
    const CGFloat weight = bold ? NSFontWeightSemibold : (size < 12.0 ? NSFontWeightMedium : NSFontWeightRegular);
    return [NSFont systemFontOfSize:size weight:weight];
}
inline NSFont* mono(CGFloat size, bool bold = false) {
    size = std::max(size, type::caption);
    return [NSFont monospacedDigitSystemFontOfSize:size weight:(bold ? NSFontWeightSemibold : NSFontWeightMedium)];
}

inline NSString* ns(const std::string& s) {
    NSString* r = [[NSString alloc] initWithBytes:s.data() length:s.size() encoding:NSUTF8StringEncoding];
    return r ? r : @"";
}
inline std::string str(NSString* s) {
    if (s == nil) return {};
    const char* p = [s UTF8String];
    return p ? std::string(p) : std::string();
}

inline void fill(NSRect r, NSColor* c) { [c setFill]; NSRectFill(r); }
// Soft look: rounded corners are allowed up to 12 px (the user asked for soft shapes, not boxes).
inline CGFloat flat(CGFloat radius) { return radius > 12.0 ? 12.0 : radius; }
inline void roundFill(NSRect r, CGFloat radius, NSColor* c) {
    radius = flat(radius);
    [c setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}
inline void roundStroke(NSRect r, CGFloat radius, NSColor* c, CGFloat width = 1.0) {
    radius = flat(radius);
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(r, width * 0.5, width * 0.5) xRadius:radius yRadius:radius];
    p.lineWidth = width;
    [p stroke];
}
inline void line(NSPoint a, NSPoint b, NSColor* c, CGFloat width = 1.0) {
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPath];
    p.lineWidth = width;
    [p moveToPoint:a];
    [p lineToPoint:b];
    [p stroke];
}
inline void text(NSString* s, NSPoint at, NSFont* font, NSColor* color) {
    [s drawAtPoint:at withAttributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color}];
}
inline NSSize textSize(NSString* s, NSFont* font) {
    return [s sizeWithAttributes:@{NSFontAttributeName: font}];
}
inline void textIn(NSString* s, NSRect r, NSFont* font, NSColor* color, NSTextAlignment align = NSTextAlignmentLeft) {
    NSMutableParagraphStyle* style = [[NSMutableParagraphStyle alloc] init];
    style.alignment = align;
    style.lineBreakMode = NSLineBreakByTruncatingTail;
    [s drawInRect:r withAttributes:@{NSFontAttributeName: font, NSForegroundColorAttributeName: color,
                                     NSParagraphStyleAttributeName: style}];
}
// A hardware-style key for FLIPPED views: dark base, lighter face on top, soft drop shadow.
// A lit key sinks: darker face with a soft glow of `glow` around the inside of its edge.
inline void keyCap(NSRect r, CGFloat radius, bool lit, NSColor* glow) {
    auto fillRound = [](NSRect q, CGFloat rad, NSColor* c) {
        [c setFill];
        [[NSBezierPath bezierPathWithRoundedRect:q xRadius:rad yRadius:rad] fill];
    };
    fillRound(NSOffsetRect(r, 0, 3.0), radius, rgb(0, 0, 0, 0.18));
    fillRound(NSOffsetRect(r, 0, 1.5), radius, rgb(0, 0, 0, 0.28));
    const NSRect face = NSMakeRect(r.origin.x, r.origin.y, r.size.width, r.size.height - 2.0);
    if (lit) {
        fillRound(r, radius, hex(0x08090A));
        fillRound(face, radius, hex(0x181A1E));
        NSColor* g = glow ? glow : copper();
        for (int k = 0; k < 4; ++k) {
            const CGFloat inset = 2.0 + 3.0 * k;
            if (face.size.width - 2.0 * inset < 3.0 || face.size.height - 2.0 * inset < 3.0) break;
            fillRound(NSInsetRect(face, inset, inset), std::max<CGFloat>(2.0, radius - inset), [g colorWithAlphaComponent:(14.0 + 6.0 * k) / 255.0]);
        }
        [hex(0x464A54) setStroke];
        NSBezierPath* top = [NSBezierPath bezierPath];
        [top moveToPoint:NSMakePoint(face.origin.x + radius, face.origin.y + 1.5)];
        [top lineToPoint:NSMakePoint(NSMaxX(face) - radius, face.origin.y + 1.5)];
        [top stroke];
    } else {
        fillRound(r, radius, hex(0x101114));
        // face: lighter at the top, darker at the bottom (flipped views: +y is downwards)
        [[[NSGradient alloc] initWithStartingColor:rgb(74.0 / 255.0, 78.0 / 255.0, 88.0 / 255.0) endingColor:rgb(60.0 / 255.0, 64.0 / 255.0, 72.0 / 255.0)]
            drawInBezierPath:[NSBezierPath bezierPathWithRoundedRect:face xRadius:radius yRadius:radius] angle:90.0];
        [hex(0x60646E) setStroke];
        NSBezierPath* top = [NSBezierPath bezierPath];
        [top moveToPoint:NSMakePoint(face.origin.x + radius, face.origin.y + 1.5)];
        [top lineToPoint:NSMakePoint(NSMaxX(face) - radius, face.origin.y + 1.5)];
        [top stroke];
    }
}
// ---- Light displays (LCD): dark glass with amber figures -------------------------------------
inline NSColor* lcdDim()   { return hex(0xB8843C); }   // small labels on a display
inline NSColor* lcdValue() { return hex(0xFFCF8A); }   // secondary figures on a display
// Dark display glass with a soft shadow under its top edge (flipped views).
inline void lcd(NSRect r, CGFloat radius = 8.0) {
    NSBezierPath* glass = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
    [[[NSGradient alloc] initWithStartingColor:rgb(13.0 / 255.0, 15.0 / 255.0, 13.0 / 255.0) endingColor:rgb(23.0 / 255.0, 26.0 / 255.0, 22.0 / 255.0)] drawInBezierPath:glass angle:90.0];
    [NSGraphicsContext saveGraphicsState];
    [glass addClip];
    [[[NSGradient alloc] initWithStartingColor:rgb(0, 0, 0, 0.45) endingColor:rgb(0, 0, 0, 0.0)] drawInRect:NSMakeRect(r.origin.x, r.origin.y, r.size.width, 8.0) angle:90.0];
    [NSGraphicsContext restoreGraphicsState];
    NSBezierPath* edge = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(r, 0.5, 0.5) xRadius:radius yRadius:radius];
    edge.lineWidth = 1.0;
    [hex(0x08090A) setStroke];
    [edge stroke];
}
// A sunken dark slot (plug-in slot, field, fader groove background).
inline void wellFill(NSRect r, CGFloat radius = 3.0) {
    roundFill(r, radius, hex(0x101114));
    roundStroke(r, radius, rgb(1, 1, 1, 0.05), 1.0);
}
// Fader cap: black body, lighter top band, one white line across the middle (flipped views).
inline void faderCap(NSPoint centre, CGFloat halfW, CGFloat halfH) {
    const NSRect o = NSMakeRect(centre.x - halfW, centre.y - halfH, halfW * 2.0, halfH * 2.0);
    roundFill(NSOffsetRect(o, 0, 2.0), 3.0, rgb(0, 0, 0, 0.45));
    roundFill(o, 3.0, hex(0x3C3C40));
    roundFill(NSInsetRect(o, 1.0, 1.0), 2.5, hex(0x1A1A1C));
    roundFill(NSMakeRect(o.origin.x + 3.0, o.origin.y + 3.0, o.size.width - 6.0, halfH - 3.0), 2.0, hex(0x262629));
    fill(NSMakeRect(o.origin.x + 5.0, centre.y - 1.1, o.size.width - 10.0, 2.2), hex(0xECEAE2));
}

// ---- Console surfaces (flipped views): brushed metal panels, sunken wells, engraved legends, console keys,
// a chrome knob and a machined fader cap. One look for the mixer, the channel strips and the track headers.
// Smooth vertical gradient, `top` at the top of the screen (flipped views: +y runs downwards).
inline void bands(NSRect r, std::uint32_t top, std::uint32_t bottom, CGFloat band = 2.0) {
    (void)band;
    NSGradient* g = [[NSGradient alloc] initWithStartingColor:hex(top) endingColor:hex(bottom)];
    [g drawInRect:r angle:90.0];
}
inline void gradientIn(NSBezierPath* path, NSColor* top, NSColor* bottom) {
    NSGradient* g = [[NSGradient alloc] initWithStartingColor:top endingColor:bottom];
    [g drawInBezierPath:path angle:90.0];
}
// Light edge on top and left, dark edge at the bottom and right: the panel stands out of the surface.
inline void bevel(NSRect r, NSColor* light, NSColor* dark) {
    fill(NSMakeRect(r.origin.x, r.origin.y, r.size.width, 1.0), light);
    fill(NSMakeRect(r.origin.x, r.origin.y, 1.0, r.size.height), light);
    fill(NSMakeRect(r.origin.x, NSMaxY(r) - 1.0, r.size.width, 1.0), dark);
    fill(NSMakeRect(NSMaxX(r) - 1.0, r.origin.y, 1.0, r.size.height), dark);
}
// A channel panel: dark brushed metal, a little lighter at the top. `warm` for the master.
inline void brushedPanel(NSRect r, bool selected, bool warm) {
    const CGFloat radius = 8.0;
    roundFill(NSOffsetRect(r, 0, 2.0), radius, rgb(0, 0, 0, 0.35));   // soft shadow under the panel
    NSBezierPath* body = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
    gradientIn(body, hex(warm ? 0x36352F : 0x33373E), hex(warm ? 0x26252A : 0x23262B));
    [NSGraphicsContext saveGraphicsState];
    [body addClip];
    [rgb(1, 1, 1, 0.02) setFill];
    for (CGFloat y = r.origin.y + 3.0; y < NSMaxY(r) - 2.0; y += 4.0) NSRectFillUsingOperation(NSMakeRect(r.origin.x, y, r.size.width, 1.0), NSCompositingOperationSourceOver);
    [[[NSGradient alloc] initWithStartingColor:rgb(1, 1, 1, 0.07) endingColor:rgb(1, 1, 1, 0.0)] drawInRect:NSMakeRect(r.origin.x, r.origin.y, r.size.width, 18.0) angle:90.0];   // light from above
    [NSGraphicsContext restoreGraphicsState];
    roundStroke(r, radius, hex(selected ? 0x5A5E68 : 0x40444C), 1.0);
    if (selected) roundStroke(NSInsetRect(r, 1.5, 1.5), radius - 1.5, copper(), 1.0);
}
// A bar of the console surface (transport deck, tool row, tab strips): brushed, light top edge, dark bottom edge.
inline void rail(NSRect r) {
    bands(r, 0x2C2F36, 0x1F2126);
    fill(NSMakeRect(r.origin.x, r.origin.y, r.size.width, 1.0), hex(0x4A4E57));
    fill(NSMakeRect(r.origin.x, NSMaxY(r) - 1.0, r.size.width, 1.0), hex(0x0C0D10));
}
// A sunken dark slot with an inner shadow under its top edge and a light line under its bottom edge.
inline void sunkenWell(NSRect r, CGFloat radius, NSColor* base) {
    radius = std::max<CGFloat>(radius, 5.0);
    NSBezierPath* path = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
    [base setFill];
    [path fill];
    [NSGraphicsContext saveGraphicsState];
    [path addClip];
    [[[NSGradient alloc] initWithStartingColor:rgb(0, 0, 0, 0.5) endingColor:rgb(0, 0, 0, 0.0)] drawInRect:NSMakeRect(r.origin.x, r.origin.y, r.size.width, std::min<CGFloat>(6.0, r.size.height)) angle:90.0];   // soft inner shadow
    [NSGraphicsContext restoreGraphicsState];
    roundStroke(r, radius, rgb(1, 1, 1, 0.06), 1.0);
}
inline void sunkenWell(NSRect r, CGFloat radius = 2.0) { sunkenWell(r, radius, hex(0x111216)); }
// Legend printed on the metal: light text with a dark shadow one pixel below.
inline void engraved(NSString* s, NSPoint at, NSFont* font, NSColor* color) {
    text(s, NSMakePoint(at.x, at.y + 1.0), font, hex(0x08090B));
    text(s, at, font, color);
}
inline void engravedIn(NSString* s, NSRect r, NSFont* font, NSColor* color, NSTextAlignment align = NSTextAlignmentLeft) {
    textIn(s, NSOffsetRect(r, 0, 1.0), font, hex(0x08090B), align);
    textIn(s, r, font, color, align);
}
// A console key: dark base, grey face with a top highlight and a small LED in the corner; lit = the key's colour glows.
inline void consoleKey(NSRect r, NSString* label, bool lit, NSColor* color) {
    const CGFloat kr = std::min<CGFloat>(6.0, r.size.height * 0.5);
    roundFill(NSOffsetRect(r, 0, 2.0), kr, rgb(0, 0, 0, 0.45));
    const NSRect face = NSMakeRect(r.origin.x, r.origin.y, r.size.width, r.size.height - 1.0);
    [NSGraphicsContext saveGraphicsState];
    [[NSBezierPath bezierPathWithRoundedRect:face xRadius:kr yRadius:kr] addClip];
    if (lit) {
        gradientIn([NSBezierPath bezierPathWithRoundedRect:face xRadius:kr yRadius:kr],
                   [color blendedColorWithFraction:0.25 ofColor:[NSColor whiteColor]], [color blendedColorWithFraction:0.25 ofColor:[NSColor blackColor]]);
    } else {
        gradientIn([NSBezierPath bezierPathWithRoundedRect:face xRadius:kr yRadius:kr], hex(0x4A4E57), hex(0x33363D));
        [[[NSGradient alloc] initWithStartingColor:rgb(1, 1, 1, 0.14) endingColor:rgb(1, 1, 1, 0.0)] drawInRect:NSMakeRect(face.origin.x, face.origin.y, face.size.width, face.size.height * 0.45) angle:90.0];
    }
    [NSGraphicsContext restoreGraphicsState];
    roundStroke(face, kr, lit ? [color blendedColorWithFraction:0.4 ofColor:[NSColor whiteColor]] : hex(0x5A5E68), 1.0);
    NSFont* f = ui(type::caption, true);
    const NSSize sz = textSize(label, f);
    text(label, NSMakePoint(NSMidX(face) - sz.width * 0.5, NSMidY(face) - sz.height * 0.5), f, lit ? hex(0x111111) : hex(0xC8CCD4));
    if (!lit) {
        [[color blendedColorWithFraction:0.6 ofColor:[NSColor blackColor]] setFill];
        [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(NSMaxX(face) - 7.0, face.origin.y + 3.0, 3.0, 3.0)] fill];
    }
}
// A chrome knob with a tick scale around it. `value` −1 … 1 (pan), the pointer at the top for 0.
inline void consoleKnob(NSPoint c, CGFloat r, double value) {
    for (int i = -5; i <= 5; ++i) {
        const double ang = (-225.0 + (i + 5) * 27.0) * M_PI / 180.0;
        const CGFloat len = (i % 5 == 0) ? 8.0 : 7.0;
        line(NSMakePoint(c.x + std::cos(ang) * (r + 5.0), c.y + std::sin(ang) * (r + 5.0)),
             NSMakePoint(c.x + std::cos(ang) * (r + len), c.y + std::sin(ang) * (r + len)), i % 5 == 0 ? hex(0x8A8F9A) : hex(0x5A5E68));
    }
    [hex(0x08090B) setFill];
    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x - r, c.y - r + 2.0, 2.0 * r, 2.0 * r)] fill];
    {
        NSGradient* body = [[NSGradient alloc] initWithStartingColor:hex(0x5A5E66) endingColor:hex(0x1C1E22)];
        [body drawInBezierPath:[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x - r, c.y - r, 2.0 * r, 2.0 * r)]
              relativeCenterPosition:NSMakePoint(-0.35, -0.35)];   // light from the top-left
    }
    NSBezierPath* hi = [NSBezierPath bezierPath];
    [hi appendBezierPathWithArcWithCenter:c radius:r - 1.0 startAngle:200.0 endAngle:340.0];
    hi.lineWidth = 1.0;
    [hex(0x8A8E97) setStroke];
    [hi stroke];
    [hex(0x101114) setStroke];
    NSBezierPath* ring = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x - r + 3.0, c.y - r + 3.0, 2.0 * (r - 3.0), 2.0 * (r - 3.0))];
    ring.lineWidth = 1.0;
    [ring stroke];
    const double ang = (-90.0 + value * 135.0) * M_PI / 180.0;
    line(NSMakePoint(c.x + std::cos(ang) * 3.0, c.y + std::sin(ang) * 3.0), NSMakePoint(c.x + std::cos(ang) * (r - 4.0), c.y + std::sin(ang) * (r - 4.0)), hex(0xF2F0E8), 2.0);
    if (std::abs(value) > 0.005) {
        NSBezierPath* arc = [NSBezierPath bezierPath];
        const CGFloat a0 = -90.0, a1 = static_cast<CGFloat>(-90.0 + value * 135.0);
        [arc appendBezierPathWithArcWithCenter:c radius:r + 3.0 startAngle:std::min(a0, a1) endAngle:std::max(a0, a1)];
        arc.lineWidth = 2.0;
        [copper() setStroke];
        [arc stroke];
    }
}
// A machined fader cap: metal gradient, dark outline, ridges and a white centre line (flipped views).
// The fader slot: a narrow dark cut in the panel with a light catch on its right edge and the thin
// metal track inside — not a wide rounded groove.
inline void consoleFaderSlot(NSRect slot) {
    const NSRect s = NSMakeRect(std::round(slot.origin.x), slot.origin.y, std::max<CGFloat>(4.0, std::round(slot.size.width)), slot.size.height);
    fill(NSMakeRect(s.origin.x - 1.0, s.origin.y - 1.0, s.size.width + 2.0, s.size.height + 2.0), hex(0x101216));   // the shadow of the cut
    fill(s, hex(0x040506));
    fill(NSMakeRect(NSMaxX(s), s.origin.y, 1.0, s.size.height), hex(0x3A3E46));                                     // light catches the far edge
    fill(NSMakeRect(NSMidX(s) - 0.5, s.origin.y + 3.0, 1.0, s.size.height - 6.0), hex(0x22252B));                   // the track
    fill(NSMakeRect(s.origin.x, s.origin.y, s.size.width, 2.0), rgb(0, 0, 0, 0.6));                                  // deeper at the top
}
// The cap of a long-throw fader (flipped views): a tall charcoal cap, flat face with fine grip ridges,
// the indicator a bright hairline in a recessed groove across the middle, sides bevelled, a soft shadow.
inline void consoleFaderCap(NSPoint centre, CGFloat halfW, CGFloat halfH) {
    const NSRect o = NSMakeRect(std::round(centre.x - halfW), std::round(centre.y - halfH), std::round(halfW * 2.0), std::round(halfH * 2.0));
    const CGFloat cy = std::round(centre.y);
    const CGFloat radius = std::min<CGFloat>(3.0, halfW * 0.3);
    // shadow: two soft layers below and a little to the right
    roundFill(NSOffsetRect(NSInsetRect(o, -1.0, 0.0), 1.0, 4.0), radius + 1.0, rgb(0, 0, 0, 0.22));
    roundFill(NSOffsetRect(o, 0.0, 2.0), radius, rgb(0, 0, 0, 0.45));
    // body: charcoal, lit from above
    gradientIn([NSBezierPath bezierPathWithRoundedRect:o xRadius:radius yRadius:radius], hex(0x3B3E45), hex(0x15171B));
    roundStroke(o, radius, hex(0x08090B), 1.0);
    // the flat face, a shade lighter, inset: the bevel of the sides
    const NSRect face = NSInsetRect(o, 2.0, 2.0);
    gradientIn([NSBezierPath bezierPathWithRoundedRect:face xRadius:std::max<CGFloat>(1.0, radius - 1.0) yRadius:std::max<CGFloat>(1.0, radius - 1.0)], hex(0x474A52), hex(0x1E2025));
    fill(NSMakeRect(face.origin.x + 1.0, face.origin.y, face.size.width - 2.0, 1.0), rgb(1, 1, 1, 0.18));   // top edge catches the light
    // grip ridges above and below the middle (engraved: dark line, light line under it)
    const CGFloat step = halfH >= 14.0 ? 4.0 : 3.0;
    for (CGFloat k = step * 2.0; k < halfH - 4.0; k += step) {
        for (CGFloat sign : {-1.0, 1.0}) {
            const CGFloat ry = cy + sign * k;
            fill(NSMakeRect(face.origin.x + 2.0, ry, face.size.width - 4.0, 1.0), rgb(0, 0, 0, 0.55));
            fill(NSMakeRect(face.origin.x + 2.0, ry + 1.0, face.size.width - 4.0, 1.0), rgb(1, 1, 1, 0.07));
        }
    }
    // the indicator: a recessed groove with a bright hairline
    fill(NSMakeRect(face.origin.x + 1.0, cy - 2.0, face.size.width - 2.0, 4.0), hex(0x0B0C0F));
    fill(NSMakeRect(face.origin.x + 1.0, cy + 2.0, face.size.width - 2.0, 1.0), rgb(1, 1, 1, 0.10));
    fill(NSMakeRect(face.origin.x + 2.0, cy - 0.5, face.size.width - 4.0, 1.0), hex(0xF4F2EA));
}

// Small pill toggle (M / S / R / I) drawn inside track headers and strips.
inline void pill(NSRect r, NSString* label, bool on, NSColor* onColor) {
    roundFill(r, 4.0, on ? onColor : raisedHi());
    NSFont* f = ui(type::caption, true);
    const NSSize sz = textSize(label, f);
    text(label, NSMakePoint(NSMidX(r) - sz.width * 0.5, NSMidY(r) - sz.height * 0.5), f, on ? canvas() : inkDim());
}

inline double clamp01(double v) { return std::max(0.0, std::min(1.0, v)); }

// Real min/max envelope drawing from the background waveform cache.
// `sourceStart` / `sourceLength` are clip frames, counted at `projectRate` (what the engine
// plays). The overview is built from the file at ITS OWN rate (files are never converted on
// disk), so the range is scaled to file frames when the two rates differ.
// `gain` raises the picture (the WAVE slider of the tool row; peaks are cut at the band's edge).
// `combine` draws one envelope for all channels (a low track: both channels in one picture is readable,
// two 10 px bands are not).
inline void drawWaveform(const silveton::WaveformOverview& overview, std::uint64_t sourceStart, std::uint64_t sourceLength,
                         NSRect rect, NSColor* color, bool flipped,
                         CGFloat visibleMinX = -1.0e9, CGFloat visibleMaxX = 1.0e9, double projectRate = 0.0,
                         double gain = 1.0, bool combine = false) {
    if (overview.empty() || sourceLength == 0U || rect.size.width < 1.0 || rect.size.height < 2.0 ||
        overview.framesPerPeak == 0U || overview.peaks.empty()) return;
    if (projectRate > 0.0 && overview.sampleRate > 0U && std::abs(static_cast<double>(overview.sampleRate) - projectRate) > 0.5) {
        const double fileFramesPerClipFrame = static_cast<double>(overview.sampleRate) / projectRate;
        sourceStart = static_cast<std::uint64_t>(std::llround(static_cast<double>(sourceStart) * fileFramesPerClipFrame));
        sourceLength = std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::llround(static_cast<double>(sourceLength) * fileFramesPerClipFrame)));
    }
    const std::uint64_t available = sourceStart < overview.frames ? overview.frames - sourceStart : 0U;
    sourceLength = std::min(sourceLength, available);
    if (sourceLength == 0U) return;
    const std::uint32_t fileChannels = std::min<std::uint32_t>(overview.channels, 2U);
    const std::uint32_t channels = combine ? 1U : fileChannels;
    const NSInteger columns = std::max<NSInteger>(1, static_cast<NSInteger>(std::ceil(rect.size.width)));
    // Zoomed in past the coarse envelope: use the fine one (one peak per 128 frames) when the file has it.
    const double framesPerColumn = static_cast<double>(sourceLength) / static_cast<double>(columns);
    const bool fine = overview.fineFramesPerPeak != 0U && !overview.finePeaks.empty() &&
                      framesPerColumn < static_cast<double>(overview.framesPerPeak) * 1.5;
    const std::uint64_t framesPerPeak = fine ? overview.fineFramesPerPeak : overview.framesPerPeak;
    const auto& levels = fine ? overview.finePeaks : overview.peaks;
    // Only the columns that can actually be seen are built (a long clip at a
    // wide zoom is thousands of pixels wide, most of them off-screen).
    const NSInteger xBegin = std::max<NSInteger>(0, static_cast<NSInteger>(std::floor(std::max<CGFloat>(-1.0e8, visibleMinX - rect.origin.x))) - 1);
    const NSInteger xEnd = std::min<NSInteger>(columns, static_cast<NSInteger>(std::ceil(std::min<CGFloat>(1.0e8, visibleMaxX - rect.origin.x))) + 1);
    if (xBegin >= xEnd) return;
    const float g = static_cast<float>(std::max(0.1, gain));
    for (std::uint32_t channel = 0U; channel < channels; ++channel) {
        if (!combine && (channel >= levels.size() || levels[channel].empty())) continue;
        const CGFloat bandH = rect.size.height / static_cast<CGFloat>(channels);
        const CGFloat center = rect.origin.y + bandH * (static_cast<CGFloat>(channel) + 0.5);
        const CGFloat amplitude = std::max<CGFloat>(1.0, bandH * 0.48);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.0;
        for (NSInteger x = xBegin; x < xEnd; ++x) {
            const double u0 = static_cast<double>(x) / static_cast<double>(columns);
            const double u1 = static_cast<double>(x + 1) / static_cast<double>(columns);
            const std::uint64_t s0 = sourceStart + static_cast<std::uint64_t>(u0 * static_cast<double>(sourceLength));
            const std::uint64_t s1 = std::min<std::uint64_t>(sourceStart + sourceLength,
                sourceStart + std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::ceil(u1 * static_cast<double>(sourceLength)))));
            const std::uint64_t p0 = s0 / framesPerPeak;
            float mn = 1.0F, mx = -1.0F;
            bool any = false;
            const std::uint32_t firstCh = combine ? 0U : channel, lastCh = combine ? fileChannels : channel + 1U;
            for (std::uint32_t ch = firstCh; ch < lastCh; ++ch) {
                if (ch >= levels.size()) continue;
                const auto& peaks = levels[ch];
                const std::uint64_t p1 = std::min<std::uint64_t>(peaks.size(), (s1 + framesPerPeak - 1U) / framesPerPeak);
                if (p0 >= p1 || p0 >= peaks.size()) continue;
                for (std::uint64_t pi = p0; pi < p1; ++pi) {
                    mn = std::min(mn, peaks[static_cast<std::size_t>(pi)].minimum);
                    mx = std::max(mx, peaks[static_cast<std::size_t>(pi)].maximum);
                }
                any = true;
            }
            if (!any) continue;
            mn = std::max(-1.0F, std::min(1.0F, mn * g));
            mx = std::max(-1.0F, std::min(1.0F, mx * g));
            const CGFloat px = rect.origin.x + static_cast<CGFloat>(x) + 0.5;
            const CGFloat sign = flipped ? -1.0 : 1.0;
            [path moveToPoint:NSMakePoint(px, center - sign * static_cast<CGFloat>(mx) * amplitude)];
            [path lineToPoint:NSMakePoint(px, center - sign * static_cast<CGFloat>(mn) * amplitude)];
        }
        // a faint centre line, then the sound
        fill(NSMakeRect(std::max(visibleMinX, rect.origin.x), center - 0.5, std::max<CGFloat>(0.0, std::min(visibleMaxX, NSMaxX(rect)) - std::max(visibleMinX, rect.origin.x)), 1.0),
             [color colorWithAlphaComponent:0.22]);
        [color setStroke];
        [path stroke];
    }
}

// Single samples (the Project window zoomed in to the sample): a line through the sample points
// of the piece `window`, dots on the points once there is room for them, a thin zero line.
// `sourceStart` / `sourceLength` are FILE frames of the clip; `rect` is the clip's waveform area.
inline void drawSamples(const silveton::WaveformWindow& window, std::uint64_t sourceStart, std::uint64_t sourceLength,
                        NSRect rect, NSColor* color, CGFloat visibleMinX, CGFloat visibleMaxX, double gain = 1.0) {
    if (sourceLength == 0U || rect.size.width < 1.0 || rect.size.height < 2.0 || window.audio.frames() == 0U) return;
    const std::uint32_t channels = std::min<std::uint32_t>(static_cast<std::uint32_t>(window.audio.channels()), 2U);
    const double pxPerFrame = static_cast<double>(rect.size.width) / static_cast<double>(sourceLength);
    // the file frames whose points can be seen
    const double fFirst = static_cast<double>(sourceStart) + std::max(0.0, (visibleMinX - rect.origin.x) / pxPerFrame) - 2.0;
    const double fLast = static_cast<double>(sourceStart) + std::min(static_cast<double>(sourceLength), (visibleMaxX - rect.origin.x) / pxPerFrame) + 2.0;
    const std::uint64_t wBegin = window.startFrame, wEnd = window.startFrame + window.audio.frames();
    const std::uint64_t first = std::max<std::uint64_t>(wBegin, static_cast<std::uint64_t>(std::max(0.0, fFirst)));
    const std::uint64_t last = std::min<std::uint64_t>(wEnd, static_cast<std::uint64_t>(std::max(0.0, fLast)));
    if (first >= last) return;
    const bool dots = pxPerFrame >= 6.0;
    for (std::uint32_t channel = 0U; channel < channels; ++channel) {
        const CGFloat bandH = rect.size.height / static_cast<CGFloat>(channels);
        const CGFloat center = rect.origin.y + bandH * (static_cast<CGFloat>(channel) + 0.5);
        const CGFloat amplitude = std::max<CGFloat>(1.0, bandH * 0.46);
        const CGFloat zeroLo = std::max(visibleMinX, rect.origin.x), zeroHi = std::min(visibleMaxX, NSMaxX(rect));
        if (zeroHi > zeroLo) fill(NSMakeRect(zeroLo, center - 0.5, zeroHi - zeroLo, 1.0), [color colorWithAlphaComponent:0.25]);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.0;
        path.lineJoinStyle = NSRoundLineJoinStyle;
        bool open = false;
        for (std::uint64_t f = first; f < last; ++f) {
            const float v = std::max(-1.0F, std::min(1.0F, window.audio.sample(channel, static_cast<std::size_t>(f - wBegin)) * static_cast<float>(gain)));
            const CGFloat px = rect.origin.x + static_cast<CGFloat>((static_cast<double>(f - sourceStart) + 0.5) * pxPerFrame);
            const NSPoint pt = NSMakePoint(px, center - static_cast<CGFloat>(v) * amplitude);
            if (!open) { [path moveToPoint:pt]; open = true; } else [path lineToPoint:pt];
        }
        [color setStroke];
        [path stroke];
        if (dots) {
            [color setFill];
            const CGFloat r = pxPerFrame >= 14.0 ? 2.5 : 1.8;
            for (std::uint64_t f = first; f < last; ++f) {
                const float v = std::max(-1.0F, std::min(1.0F, window.audio.sample(channel, static_cast<std::size_t>(f - wBegin)) * static_cast<float>(gain)));
                const CGFloat px = rect.origin.x + static_cast<CGFloat>((static_cast<double>(f - sourceStart) + 0.5) * pxPerFrame);
                [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(px - r, center - static_cast<CGFloat>(v) * amplitude - r, 2.0 * r, 2.0 * r)] fill];
            }
        }
    }
}

} // namespace sv
