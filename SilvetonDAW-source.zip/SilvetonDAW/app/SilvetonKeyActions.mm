// Silveton — Key Editor: the part of the controller behind the note grid. It keeps the tool and the settings of
// the panel, hears the notes while they are clicked, copies and pastes notes, and turns the playhead into the
// grid's own time. The grid is SilvetonNoteGrid.mm; the editing rules are KeyEditing (tested without any window code).
#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include "silveton/KeyEditing.h"
#include "silveton/MidiInput.h"

#include <algorithm>
#include <cmath>

using namespace silveton;

namespace {

NSTextField* keyLabel(NSView* parent, NSString* s, NSRect f, NSFont* font, NSColor* color, NSTextAlignment a = NSTextAlignmentLeft) {
    NSTextField* t = [NSTextField labelWithString:s ?: @""];
    t.frame = f;
    t.font = font;
    t.textColor = color;
    t.alignment = a;
    t.lineBreakMode = NSLineBreakByTruncatingTail;
    [parent addSubview:t];
    return t;
}

void keySection(NSView* parent, NSString* title, CGFloat y, CGFloat w) {
    SVFlipView* bar = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, y, w, 22)];
    bar.fillColor = sv::hex(0x2B2E35);
    [parent addSubview:bar];
    keyLabel(bar, [@"▾  " stringByAppendingString:title], NSMakeRect(8, 4, w - 16, 14), sv::ui(10, true), sv::inkDim());
}

NSPopUpButton* keyPopup(NSView* parent, NSRect f, id target, SEL action) {
    NSPopUpButton* p = [[NSPopUpButton alloc] initWithFrame:f pullsDown:NO];
    p.font = sv::ui(11);
    p.target = target;
    p.action = action;
    [parent addSubview:p];
    return p;
}

NSString* const kToolNames[7] = {@"Select", @"Draw", @"Erase", @"Cut", @"Glue", @"Mute", @"Line"};
NSString* const kToolHints[7] = {
    @"Click a note to pick it, drag to move it, drag its right end to make it longer. A frame over empty space picks many notes. Option-drag copies.",
    @"Click to make a note, drag sideways to make it longer. In a controller lane: draw freely.",
    @"Click a note, or drag across notes, to remove them. In a controller lane: drag across points.",
    @"Click in a note to cut it in two at the grid.",
    @"Click a note to join it with the next note of the same pitch.",
    @"Click a note, or drag across notes, to silence or sound them.",
    @"Drag in a controller lane to draw a line, curve, sine, triangle or square wave.",
};
const int kInsertDivs[8] = {0, -1, 1, 2, 4, 8, 16, 32};
const double kPeriods[5] = {0.25, 0.5, 1.0, 2.0, 4.0};

} // namespace

@implementation SilvetonController (Key)

// ================================================================== state ==
- (SVKeyState*)keyState { return &_key; }
- (SVKeyTool)keyTool { return _key.tool; }

- (void)setKeyTool:(SVKeyTool)tool {
    _key.tool = tool;
    [self keyToolsChanged];
    const int i = std::clamp(static_cast<int>(tool), 0, 6);
    [self setStatus:[NSString stringWithFormat:@"%@ tool — %@", kToolNames[i], kToolHints[i]]];
}

- (void)keyToolsChanged {
    for (int i = 0; i < 7; ++i) _keyToolButtons[i].state = static_cast<int>(_key.tool) == i ? NSControlStateValueOn : NSControlStateValueOff;
    _keyHint.stringValue = kToolHints[std::clamp(static_cast<int>(_key.tool), 0, 6)];
    _keyListen.state = _key.listen ? NSControlStateValueOn : NSControlStateValueOff;
    _keyFollow.state = _key.follow ? NSControlStateValueOn : NSControlStateValueOff;
    _keyScaleRows.state = _key.scaleRows ? NSControlStateValueOn : NSControlStateValueOff;
    _keyScaleSnap.state = _key.scaleSnap ? NSControlStateValueOn : NSControlStateValueOff;
    const int kind = std::clamp(static_cast<int>(_key.scale.kind), 0, static_cast<int>(ToneScaleKind::Count) - 1);
    [_keyScalePop selectItemAtIndex:kind];
    [_keyRootPop selectItemAtIndex:((_key.scale.root % 12) + 12) % 12];
    [_keyChordPop selectItemAtIndex:std::clamp(_key.chord, 0, static_cast<int>(ChordKind::Count) - 1)];
    [_keyShapePop selectItemAtIndex:static_cast<int>(_key.shape)];
    _keyVelSlider.integerValue = _key.insertVelocity;
    _keyVelValue.stringValue = [NSString stringWithFormat:@"%d", _key.insertVelocity];
    [_noteGrid setNeedsDisplay:YES];
}

- (void)keyStatus:(NSString*)text { [self setStatus:text]; }

- (BOOL)keyEditorActive {
    if (!_core || _page != SVPage::Edit || !_noteGrid || [_noteGrid isHidden]) return NO;
    return self.selectedMidiTrack >= 0 && self.selectedMidiTrack < static_cast<long>(_core->project().midiTracks.size());
}

- (std::vector<std::uint64_t>)keySelectedNotes { return [_noteGrid selection]; }
- (void)keySetSelectedNotes:(const std::vector<std::uint64_t>&)ids { [_noteGrid setSelection:ids]; }

- (NSNumber*)keyAskControllerNumber {
    NSString* s = [self promptText:@"Controller" message:@"Controller number (0 – 127), e.g. 74 for the filter cutoff" initial:@"1"];
    if (!s) return nil;
    return @(std::clamp(s.intValue, 0, 127));
}

// ================================================================== timing ==
- (double)keyPlayheadQuarter {
    if (!_core) return 0.0;
    return _core->project().tempoMap.quarterNotesAtSample(self.playheadSample) - [self editedPartOffsetQuarterNotes];
}

- (void)keySeekToQuarter:(double)quarter {
    if (!_core) return;
    const double tq = std::max(0.0, quarter + [self editedPartOffsetQuarterNotes]);
    [self seekToSample:std::max<std::int64_t>(0, _core->project().tempoMap.sampleAtQuarterNotes(tq))];
}

- (double)keyBarQuarters {
    if (!_core) return 4.0;
    const auto& tm = _core->project().tempoMap;
    const double num = tm.numeratorAtSample(self.playheadSample), den = tm.denominatorAtSample(self.playheadSample);
    return (num > 0.0 && den > 0.0) ? num * 4.0 / den : 4.0;
}

- (BOOL)keyCycleStart:(double*)start end:(double*)end {
    if (!_core || !_core->ready()) return NO;
    const auto& t = _core->engine().transport();
    if (t.cycleEndSample() <= t.cycleStartSample()) return NO;
    const auto& tm = _core->project().tempoMap;
    const double offset = [self editedPartOffsetQuarterNotes];
    if (start) *start = tm.quarterNotesAtSample(t.cycleStartSample()) - offset;
    if (end) *end = tm.quarterNotesAtSample(t.cycleEndSample()) - offset;
    return YES;
}

- (BOOL)keyPartRange:(double*)start end:(double*)end {
    MidiPart* part = [self editedPart];
    if (!part) return NO;
    if (start) *start = part->sourceOffsetQuarterNotes;
    if (end) *end = part->sourceOffsetQuarterNotes + part->lengthQuarterNotes;
    return YES;
}

- (double)keyInsertLength {
    if (_key.insertDiv > 0) return 4.0 / _key.insertDiv;
    if (_key.insertDiv < 0) return std::max(KeyEditing::kShortestNote, _key.lastLength);
    return 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
}

// ================================================================ audition ==
- (void)keyAudition:(int)pitch velocity:(int)velocity on:(BOOL)on {
    if (!_core || !_core->ready()) return;
    const long t = self.selectedMidiTrack;
    if (t < 0 || t >= static_cast<long>(_core->project().midiTracks.size())) return;
    const int port = _core->project().midiTracks[static_cast<std::size_t>(t)].outputPort;
    if (port < 0) return;
    TimedMidiInputEvent e;
    e.port = port;
    e.status = on ? 0x90U : 0x80U;
    e.data1 = static_cast<std::uint8_t>(std::clamp(pitch, 0, 127));
    e.data2 = on ? static_cast<std::uint8_t>(std::clamp(velocity, 1, 127)) : 0U;
    (void)_core->runtime().midiInput().pushAudition(e);
}

// =============================================================== the panel ==
- (void)keyToolPicked:(SVToggle*)sender { [self setKeyTool:static_cast<SVKeyTool>(std::clamp<NSInteger>(sender.tag, 0, 6))]; }
- (void)keyInsertPicked:(NSPopUpButton*)pop { _key.insertDiv = kInsertDivs[std::clamp<NSInteger>(pop.indexOfSelectedItem, 0, 7)]; }
- (void)keyChordPicked:(NSPopUpButton*)pop { _key.chord = static_cast<int>(std::clamp<NSInteger>(pop.indexOfSelectedItem, 0, static_cast<NSInteger>(ChordKind::Count) - 1)); }
- (void)keyVelocityMoved:(NSSlider*)sl {
    _key.insertVelocity = std::clamp(static_cast<int>(std::lround(sl.doubleValue)), 1, 127);
    _keyVelValue.stringValue = [NSString stringWithFormat:@"%d", _key.insertVelocity];
}
- (void)keyListenToggled:(SVToggle*)sender { _key.listen = sender.state == NSControlStateValueOn; if (!_key.listen) [_noteGrid stopAudition]; }
- (void)keyFollowToggled:(SVToggle*)sender { _key.follow = sender.state == NSControlStateValueOn; }
- (void)keyScalePicked:(NSPopUpButton*)pop {
    _key.scale.kind = static_cast<ToneScaleKind>(std::clamp<NSInteger>(pop.indexOfSelectedItem, 0, static_cast<NSInteger>(ToneScaleKind::Count) - 1));
    if (!_key.scale.chromatic() && !_key.scaleRows) { _key.scaleRows = YES; [self keyToolsChanged]; }
    [_noteGrid setNeedsDisplay:YES];
}
- (void)keyRootPicked:(NSPopUpButton*)pop { _key.scale.root = static_cast<int>(std::clamp<NSInteger>(pop.indexOfSelectedItem, 0, 11)); [_noteGrid setNeedsDisplay:YES]; }
- (void)keyScaleRowsToggled:(SVToggle*)sender { _key.scaleRows = sender.state == NSControlStateValueOn; [_noteGrid setNeedsDisplay:YES]; }
- (void)keyScaleSnapToggled:(SVToggle*)sender { _key.scaleSnap = sender.state == NSControlStateValueOn; }
- (void)keyShapePicked:(NSPopUpButton*)pop {
    _key.shape = static_cast<LaneShape>(std::clamp<NSInteger>(pop.indexOfSelectedItem, 0, static_cast<NSInteger>(LaneShape::Count) - 1));
    if (_key.tool != SVKeyTool::Line) [self setKeyTool:SVKeyTool::Line];
}
- (void)keyPeriodPicked:(NSPopUpButton*)pop { _key.period = kPeriods[std::clamp<NSInteger>(pop.indexOfSelectedItem, 0, 4)]; }
- (void)keyThinLane:(id)sender { (void)sender; [_noteGrid thinActiveLane]; }
- (void)keyClearLane:(id)sender { (void)sender; [_noteGrid clearActiveLane]; }
- (void)keyZoomIn:(id)sender { (void)sender; [_noteGrid zoomBy:0.7]; }
- (void)keyZoomOut:(id)sender { (void)sender; [_noteGrid zoomBy:1.0 / 0.7]; }
- (void)keyZoomFit:(id)sender { (void)sender; [_noteGrid zoomFit]; }
- (void)keyZoomSelection:(id)sender { (void)sender; [_noteGrid zoomToSelection]; }

- (void)keyDetectScale:(id)sender {
    (void)sender;
    MidiSequence* seq = [self editedSequence];
    if (!seq || seq->notes().empty()) { [self showError:@"Detect Key" detail:"Open a MIDI part that contains notes first."]; return; }
    double total = 0.0;
    for (const auto& n : seq->notes()) total += n.durationQuarterNotes;
    ToneScale best;
    double bestCover = -1.0;
    for (const ToneScaleKind kind : {ToneScaleKind::Major, ToneScaleKind::NaturalMinor}) {
        for (int root = 0; root < 12; ++root) {
            ToneScale s;
            s.kind = kind;
            s.root = root;
            double inside = 0.0;
            for (const auto& n : seq->notes()) if (s.contains(n.pitch)) inside += n.durationQuarterNotes;
            if (inside > bestCover + 1.0e-9) { bestCover = inside; best = s; }
        }
    }
    _key.scale = best;
    _key.scaleRows = YES;
    [self keyToolsChanged];
    [self setStatus:[NSString stringWithFormat:@"Key found: %@ — %.0f %% of the music is inside it", sv::ns(best.name()), total > 0.0 ? 100.0 * bestCover / total : 0.0]];
}

- (void)keyFitToScale:(id)sender {
    (void)sender;
    if (_key.scale.chromatic()) { [self setStatus:@"Pick a scale first (SCALE section of the panel)"]; return; }
    const auto ids = [_noteGrid selection];
    __block std::size_t changed = 0U;
    const ToneScale scale = _key.scale;
    [self noteEdit:@"Fit Notes to Scale" op:^(MidiSequence& s) { changed = KeyEditing::fitToScale(s, ids, scale); }];
    [self setStatus:changed ? [NSString stringWithFormat:@"%zu notes moved into %@", changed, sv::ns(scale.name())] : @"All notes are already in the scale"];
}

// ============================================================ editing notes ==
- (BOOL)keyNeedNotes:(const std::vector<std::uint64_t>&)ids {
    if (!ids.empty()) return YES;
    [self setStatus:@"Select notes first"];
    return NO;
}

- (void)keyCopy {
    MidiSequence* seq = [self editedSequence];
    const auto ids = [_noteGrid selection];
    if (!seq || ![self keyNeedNotes:ids]) return;
    _key.clipboard = KeyEditing::copyNotes(*seq, ids);
    [self setStatus:[NSString stringWithFormat:@"%zu notes copied", _key.clipboard.notes.size()]];
}
- (void)keyCut {
    const auto ids = [_noteGrid selection];
    if (![self keyNeedNotes:ids]) return;
    [self keyCopy];
    [self noteEdit:@"Cut Notes" op:^(MidiSequence& s) { (void)KeyEditing::removeNotes(s, ids); }];
    [_noteGrid setSelection:std::vector<std::uint64_t> {}];
}
- (void)keyPaste {
    if (_key.clipboard.empty()) { [self setStatus:@"Nothing to paste — copy some notes first"]; return; }
    if (![self editedSequence]) return;
    double at = std::max(0.0, [self keyPlayheadQuarter]);
    if (_snap) {
        const double step = 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
        at = std::max(0.0, std::round(at / step) * step);
    }
    const NoteClip clip = _key.clipboard;
    __block std::vector<std::uint64_t> made;
    [self noteEdit:@"Paste Notes" op:^(MidiSequence& s) { made = KeyEditing::pasteNotes(s, clip, at); }];
    [_noteGrid setSelection:made];
    [self setStatus:[NSString stringWithFormat:@"%zu notes pasted at the cursor", made.size()]];
}
- (void)keyDuplicate {
    const auto ids = [_noteGrid selection];
    if (![self keyNeedNotes:ids]) return;
    __block std::vector<std::uint64_t> made;
    [self noteEdit:@"Duplicate Notes" op:^(MidiSequence& s) { made = KeyEditing::duplicateNotes(s, ids); }];
    [_noteGrid setSelection:made];
}
- (void)keyDelete {
    if (![_noteGrid hasSelection]) { [self setStatus:@"Select notes first — the part itself stays (remove it in the Project window)"]; return; }
    [_noteGrid deleteSelected];
}
- (void)keySelectAllNotes {
    if (MidiSequence* seq = [self editedSequence]) [_noteGrid setSelection:KeyEditing::allIds(*seq)];
}
- (void)keySelectInvert:(id)sender {
    (void)sender;
    if (MidiSequence* seq = [self editedSequence]) [_noteGrid setSelection:KeyEditing::invertSelection(*seq, [_noteGrid selection])];
}
- (void)keySelectSamePitch:(id)sender {
    (void)sender;
    MidiSequence* seq = [self editedSequence];
    const auto ids = [_noteGrid selection];
    if (seq && [self keyNeedNotes:ids]) [_noteGrid setSelection:KeyEditing::selectSamePitch(*seq, ids)];
}
- (void)keySelectFromCursor:(id)sender {
    (void)sender;
    if (MidiSequence* seq = [self editedSequence]) [_noteGrid setSelection:KeyEditing::selectFrom(*seq, [self keyPlayheadQuarter])];
}
- (void)keySelectNone:(id)sender { (void)sender; [_noteGrid setSelection:std::vector<std::uint64_t> {}]; }

- (void)keyMuteNotes:(id)sender {
    (void)sender;
    const auto ids = [_noteGrid selection];
    if (![self keyNeedNotes:ids]) return;
    [self noteEdit:@"Mute Notes" op:^(MidiSequence& s) { (void)KeyEditing::muteNotes(s, ids, 2); }];
}
- (void)keySplitAtCursor:(id)sender {
    (void)sender;
    MidiSequence* seq = [self editedSequence];
    if (!seq) return;
    std::vector<std::uint64_t> ids = [_noteGrid selection];
    if (ids.empty()) ids = KeyEditing::allIds(*seq);
    double at = [self keyPlayheadQuarter];
    if (_snap) {
        const double step = 1.0 / std::max<std::uint32_t>(1U, _gridDiv);
        at = std::round(at / step) * step;
    }
    __block std::vector<std::uint64_t> rights;
    [self noteEdit:@"Cut Notes at Cursor" op:^(MidiSequence& s) { rights = KeyEditing::splitNotes(s, ids, at); }];
    [self setStatus:rights.empty() ? @"No note sounds at the cursor" : [NSString stringWithFormat:@"%zu notes cut at the cursor", rights.size()]];
}
- (void)keyGlueSelected:(id)sender {
    (void)sender;
    const auto ids = [_noteGrid selection];
    if (![self keyNeedNotes:ids]) return;
    __block std::vector<std::uint64_t> kept;
    [self noteEdit:@"Glue Notes" op:^(MidiSequence& s) { kept = KeyEditing::glueNotes(s, ids); }];
    [_noteGrid setSelection:kept];
    [self setStatus:kept.size() < ids.size() ? [NSString stringWithFormat:@"%zu notes joined", ids.size() - kept.size()] : @"No notes touch each other"];
}

// ============================================================ building the panel ==
- (CGFloat)keyToolsHeight { return _midiTools ? _midiTools.frame.size.height : 620.0; }

- (void)buildKeyToolsIn:(SVFlipView*)view width:(CGFloat)W {
    CGFloat y = 0.0;
    const CGFloat colW = (W - 8.0 * 3.0) / 2.0;
    auto button = [&](NSString* title, SEL action, int column, int columns, CGFloat rowY) {
        const CGFloat w = (W - 8.0 * (columns + 1)) / columns;
        [view addSubview:[SVButton buttonWithTitle:title target:self action:action frame:NSMakeRect(8 + column * (w + 8), rowY, w, 24)]];
    };
    auto grid = [&](NSArray<NSString*>* titles, NSArray<NSString*>* sels) {
        for (NSUInteger i = 0; i < titles.count; ++i) {
            const CGFloat x = 8.0 + (i % 2) * (colW + 8.0);
            [view addSubview:[SVButton buttonWithTitle:titles[i] target:self action:NSSelectorFromString(sels[i])
                                                 frame:NSMakeRect(x, y + (i / 2) * 30.0, colW, 24.0)]];
        }
        y += std::ceil(titles.count / 2.0) * 30.0 + 6.0;
    };

    keySection(view, @"KEY EDITOR · TOOLS", y, W);
    y += 28.0;
    for (int i = 0; i < 7; ++i) {
        const CGFloat x = 8.0 + (i % 2) * (colW + 8.0);
        SVToggle* t = [SVToggle toggleWithTitle:[NSString stringWithFormat:@"%d  %@", i + 1, kToolNames[i]] color:sv::copper() target:self action:@selector(keyToolPicked:)
                                          frame:NSMakeRect(x, y + (i / 2) * 30.0, colW, 24.0)];
        t.tag = i;
        t.state = i == 0 ? NSControlStateValueOn : NSControlStateValueOff;
        [view addSubview:t];
        _keyToolButtons[i] = t;
    }
    y += 4 * 30.0 + 2.0;
    _keyHint = keyLabel(view, kToolHints[0], NSMakeRect(8, y, W - 16, 52), sv::ui(11), sv::inkDim());
    _keyHint.maximumNumberOfLines = 4;
    _keyHint.lineBreakMode = NSLineBreakByWordWrapping;
    y += 58.0;

    keySection(view, @"NEW NOTES", y, W);
    y += 30.0;
    keyLabel(view, @"Length", NSMakeRect(8, y + 4, 60, 16), sv::ui(11), sv::inkDim());
    _keyInsertPop = keyPopup(view, NSMakeRect(72, y, W - 80, 24), self, @selector(keyInsertPicked:));
    [_keyInsertPop addItemsWithTitles:@[@"One Grid Step", @"Last Length Used", @"1/1", @"1/2", @"1/4", @"1/8", @"1/16", @"1/32"]];
    y += 30.0;
    keyLabel(view, @"Chord", NSMakeRect(8, y + 4, 60, 16), sv::ui(11), sv::inkDim());
    _keyChordPop = keyPopup(view, NSMakeRect(72, y, W - 80, 24), self, @selector(keyChordPicked:));
    for (int k = 0; k < static_cast<int>(ChordKind::Count); ++k) [_keyChordPop addItemWithTitle:[NSString stringWithUTF8String:KeyEditing::chordName(static_cast<ChordKind>(k))]];
    y += 30.0;
    keyLabel(view, @"Velocity", NSMakeRect(8, y + 2, 60, 16), sv::ui(11), sv::inkDim());
    SVResetSlider* vel = [[SVResetSlider alloc] initWithFrame:NSMakeRect(72, y, W - 72 - 44, 20)];
    vel.minValue = 1; vel.maxValue = 127; vel.doubleValue = 100; vel.resetValue = 100; vel.continuous = YES;
    vel.target = self; vel.action = @selector(keyVelocityMoved:);
    [view addSubview:vel];
    _keyVelSlider = vel;
    _keyVelValue = keyLabel(view, @"100", NSMakeRect(W - 40, y + 2, 32, 16), sv::mono(11, true), sv::ink(), NSTextAlignmentRight);
    y += 28.0;
    _keyListen = [SVToggle toggleWithTitle:@"Hear Notes" color:sv::copper() target:self action:@selector(keyListenToggled:) frame:NSMakeRect(8, y, colW, 24)];
    _keyListen.state = NSControlStateValueOn;
    [view addSubview:_keyListen];
    _keyFollow = [SVToggle toggleWithTitle:@"Follow Play" color:sv::copper() target:self action:@selector(keyFollowToggled:) frame:NSMakeRect(16 + colW, y, colW, 24)];
    _keyFollow.state = NSControlStateValueOn;
    [view addSubview:_keyFollow];
    y += 36.0;

    keySection(view, @"SCALE", y, W);
    y += 30.0;
    _keyScalePop = keyPopup(view, NSMakeRect(8, y, 132, 24), self, @selector(keyScalePicked:));
    for (int k = 0; k < static_cast<int>(ToneScaleKind::Count); ++k) [_keyScalePop addItemWithTitle:sv::ns(ToneScale::kindName(static_cast<ToneScaleKind>(k)))];
    _keyRootPop = keyPopup(view, NSMakeRect(148, y, W - 156, 24), self, @selector(keyRootPicked:));
    [_keyRootPop addItemsWithTitles:@[@"C", @"C#", @"D", @"D#", @"E", @"F", @"F#", @"G", @"G#", @"A", @"A#", @"B"]];
    y += 32.0;
    _keyScaleRows = [SVToggle toggleWithTitle:@"Scale Rows" color:sv::copper() target:self action:@selector(keyScaleRowsToggled:) frame:NSMakeRect(8, y, colW, 24)];
    [view addSubview:_keyScaleRows];
    _keyScaleSnap = [SVToggle toggleWithTitle:@"Snap to Scale" color:sv::copper() target:self action:@selector(keyScaleSnapToggled:) frame:NSMakeRect(16 + colW, y, colW, 24)];
    [view addSubview:_keyScaleSnap];
    y += 30.0;
    button(@"Fit Notes to Scale", @selector(keyFitToScale:), 0, 2, y);
    button(@"Detect Key", @selector(keyDetectScale:), 1, 2, y);
    y += 36.0;

    keySection(view, @"CONTROLLER LANES", y, W);
    y += 30.0;
    keyLabel(view, @"Line", NSMakeRect(8, y + 4, 40, 16), sv::ui(11), sv::inkDim());
    _keyShapePop = keyPopup(view, NSMakeRect(48, y, 96, 24), self, @selector(keyShapePicked:));
    for (int k = 0; k < static_cast<int>(LaneShape::Count); ++k) [_keyShapePop addItemWithTitle:[NSString stringWithUTF8String:KeyEditing::laneShapeName(static_cast<LaneShape>(k))]];
    keyLabel(view, @"Wave", NSMakeRect(152, y + 4, 36, 16), sv::ui(11), sv::inkDim());
    _keyPeriodPop = keyPopup(view, NSMakeRect(190, y, W - 198, 24), self, @selector(keyPeriodPicked:));
    [_keyPeriodPop addItemsWithTitles:@[@"1/16", @"1/8", @"1/4", @"1/2", @"1 bar"]];
    [_keyPeriodPop selectItemAtIndex:2];
    y += 32.0;
    button(@"Thin Out Lane", @selector(keyThinLane:), 0, 2, y);
    button(@"Clear Lane", @selector(keyClearLane:), 1, 2, y);
    y += 30.0;
    keyLabel(view, @"Click the name of a lane to choose what it shows, or to add more lanes.", NSMakeRect(8, y, W - 16, 28), sv::ui(10), sv::inkFaint()).lineBreakMode = NSLineBreakByWordWrapping;
    y += 36.0;

    keySection(view, @"SELECT AND EDIT", y, W);
    y += 28.0;
    grid(@[@"Select All", @"Invert", @"Same Pitch", @"From Cursor", @"Copy", @"Paste", @"Duplicate", @"Delete", @"Cut at Cursor", @"Glue", @"Mute", @"Deselect"],
         @[@"sampleSelectAll:", @"keySelectInvert:", @"keySelectSamePitch:", @"keySelectFromCursor:", @"copyClip:", @"pasteClip:", @"duplicateClip:", @"deleteSelection:",
           @"keySplitAtCursor:", @"keyGlueSelected:", @"keyMuteNotes:", @"keySelectNone:"]);

    keySection(view, @"QUANTIZE", y, W);
    y += 28.0;
    grid(@[@"Quantize", @"Quantize Setup…", @"Soft Quantize", @"Quantize Ends", @"Quantize Length", @"Legato", @"Apply Groove", @"Extract Groove"],
         @[@"midiQuantize:", @"showQuantizePanel:", @"midiQuantizeSoft:", @"midiQuantizeEnds:", @"midiQuantizeLength:", @"midiLegato:", @"midiGrooveApply:", @"midiGrooveExtract:"]);

    keySection(view, @"FUNCTIONS", y, W);
    y += 28.0;
    grid(@[@"Fixed Length", @"Velocity…", @"Compress Vel.", @"Humanize", @"Delete Doubles", @"Retrograde", @"Invert"],
         @[@"midiFixedLength:", @"midiVelocity:", @"midiCompress:", @"midiHumanize:", @"midiDeleteDoubles:", @"midiRetrograde:", @"midiInvert:"]);

    keySection(view, @"TRANSPOSE", y, W);
    y += 28.0;
    grid(@[@"Up 1", @"Down 1", @"Octave +", @"Octave −"], @[@"midiUp:", @"midiDown:", @"midiOctaveUp:", @"midiOctaveDown:"]);

    keySection(view, @"VIEW", y, W);
    y += 28.0;
    grid(@[@"Zoom In", @"Zoom Out", @"Zoom Fit", @"Zoom Notes"], @[@"keyZoomIn:", @"keyZoomOut:", @"keyZoomFit:", @"keyZoomSelection:"]);

    NSRect f = view.frame;
    f.size.height = y + 8.0;
    view.frame = f;
    [self keyToolsChanged];
}

@end
