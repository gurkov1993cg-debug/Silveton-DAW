// Silveton Key Editor — what the note grid and the KEY panel share. Main thread only.
#pragma once

#include "silveton/KeyEditing.h"

#include <cstdint>
#include <vector>

enum class SVKeyTool : int {
    Select = 0,   // pick notes, move them, stretch them, rubber band
    Draw,         // click to make a note, drag to make it longer
    Erase,        // click or sweep over notes to remove them
    Cut,          // click in a note to cut it in two
    Glue,         // click a note to join it with the next one of the same pitch
    Mute,         // click or sweep over notes to silence or sound them
    Line          // draws shapes in the controller lanes
};

struct SVKeyState {
    SVKeyTool tool {SVKeyTool::Select};
    silveton::ToneScale scale;                 // for the scale rows, "Snap to Scale" and "Fit Notes to Scale"
    bool scaleRows {false};                    // dim the rows of notes outside the scale
    bool scaleSnap {false};                    // new notes (and chords) are pulled onto the scale
    silveton::LaneShape shape {silveton::LaneShape::Line};   // the Line tool
    double period {1.0};                       // length of one wave of Sine / Triangle / Square (quarter notes)
    int chord {0};                             // ChordKind of the notes the Draw tool makes
    int insertDiv {0};                         // 0 = length of one grid step, -1 = last length used, else 1,2,4,8,16,32 (1/N note)
    int insertVelocity {100};
    double lastLength {0.25};                  // the length of the note edited last (quarter notes)
    bool listen {true};                        // sound the notes that are clicked, drawn or moved
    bool follow {true};                        // the grid turns its page with the playhead
    silveton::NoteClip clipboard;
};
