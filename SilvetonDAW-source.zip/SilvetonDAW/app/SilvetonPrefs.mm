// Silveton — Preferences window organised like Cubase: a category list on the
// left, the settings of the chosen category on the right.
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>

#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include "silveton/CoreAudioDevice.h"
#include "silveton/CoreMidiInput.h"

#include <algorithm>
#include <cmath>
#include <string>

using namespace silveton;

@interface SilvetonController (PrefsForward)
- (void)scanPlugins:(id)sender;
- (void)toggleSnap:(id)sender;
@end

@interface SVPrefs : NSObject <NSTableViewDataSource, NSTableViewDelegate, NSWindowDelegate>
@property(nonatomic, weak) SilvetonController* owner;
@property(nonatomic, strong) NSWindow* window;
@property(nonatomic, strong) NSTableView* list;
@property(nonatomic, strong) NSView* content;
@property(nonatomic, strong) NSArray<NSString*>* categories;
// controls of the current page
@property(nonatomic, strong) NSPopUpButton* devicePopup;
@property(nonatomic, strong) NSPopUpButton* bufferPopup;
@property(nonatomic, strong) NSPopUpButton* ratePopup;
@property(nonatomic, strong) NSPopUpButton* processPopup;
@property(nonatomic, strong) NSTextField* autosaveField;
@property(nonatomic, strong) NSButton* snapCheck;
@property(nonatomic, strong) NSPopUpButton* gridPopup;
@property(nonatomic, strong) NSButton* clickCheck;
@property(nonatomic, strong) NSTextField* clickLevel;
@property(nonatomic, strong) NSTextField* accentLevel;
@property(nonatomic, strong) NSTextField* countIn;
@property(nonatomic, strong) NSPopUpButton* panLaw;
+ (instancetype)shared;
- (void)show;
- (void)showAtPage:(NSInteger)page;
@end

namespace {
NSTextField* lbl(NSView* p, NSString* s, NSRect f, NSFont* font, NSColor* c, NSTextAlignment a = NSTextAlignmentLeft) {
    NSTextField* t = [NSTextField labelWithString:s ?: @""];
    t.frame = f; t.font = font; t.textColor = c; t.alignment = a;
    [p addSubview:t];
    return t;
}
NSTextField* fld(NSView* p, NSRect f, NSString* v) {
    NSTextField* t = [[NSTextField alloc] initWithFrame:f];
    t.font = sv::ui(11);
    t.textColor = sv::ink();
    t.backgroundColor = sv::hex(0x1C1C1E);
    t.drawsBackground = YES;
    t.bezeled = YES;
    t.stringValue = v ?: @"";
    [p addSubview:t];
    return t;
}
NSPopUpButton* pop(NSView* p, NSRect f, NSArray<NSString*>* items) {
    NSPopUpButton* b = [[NSPopUpButton alloc] initWithFrame:f pullsDown:NO];
    b.font = sv::ui(11);
    [b addItemsWithTitles:items];
    [p addSubview:b];
    return b;
}
NSButton* check(NSView* p, NSString* title, NSRect f, BOOL on) {
    NSButton* b = [[NSButton alloc] initWithFrame:f];
    [b setButtonType:NSButtonTypeSwitch];
    b.title = title;
    b.state = on ? NSControlStateValueOn : NSControlStateValueOff;
    [p addSubview:b];
    return b;
}
void heading(NSView* p, NSString* s, CGFloat y) {
    lbl(p, s, NSMakeRect(20, y, 520, 22), sv::ui(sv::type::heading, true), sv::ink());
}
}

static SVPrefs* gPrefs = nil;

@implementation SVPrefs
+ (instancetype)shared {
    if (!gPrefs) gPrefs = [[SVPrefs alloc] init];
    return gPrefs;
}

- (void)show {
    if (!self.window) {
        self.categories = @[@"General", @"Audio System", @"MIDI", @"Metronome", @"Project Setup", @"VST Plug-ins", @"Key Commands"];
        self.window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, 780, 520)
                                                  styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable
                                                    backing:NSBackingStoreBuffered defer:NO];
        self.window.title = @"Preferences";
        self.window.delegate = self;
        self.window.releasedWhenClosed = NO;
        if (@available(macOS 10.14, *)) self.window.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
        else self.window.appearance = [NSAppearance appearanceNamed:@"NSAppearanceNameVibrantDark"];
        SVFlipView* root = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, 780, 520)];
        root.fillColor = sv::canvas();
        self.window.contentView = root;
        NSScrollView* sc = [[NSScrollView alloc] initWithFrame:NSMakeRect(0, 0, 200, 520)];
        sc.borderType = NSNoBorder;
        sc.drawsBackground = YES;
        sc.backgroundColor = sv::panel();
        NSTableView* t = [[NSTableView alloc] initWithFrame:sc.bounds];
        t.backgroundColor = sv::panel();
        t.rowHeight = 26;
        t.headerView = nil;
        t.dataSource = self;
        t.delegate = self;
        NSTableColumn* col = [[NSTableColumn alloc] initWithIdentifier:@"c"];
        col.width = 190;
        [t addTableColumn:col];
        sc.documentView = t;
        [root addSubview:sc];
        self.list = t;
        self.content = [[SVFlipView alloc] initWithFrame:NSMakeRect(200, 0, 580, 520)];
        ((SVFlipView*)self.content).fillColor = sv::canvas();
        [root addSubview:self.content];
        [self.window center];
    }
    [self.list selectRowIndexes:[NSIndexSet indexSetWithIndex:1] byExtendingSelection:NO];   // open on Audio System
    [self.list selectRowIndexes:[NSIndexSet indexSetWithIndex:0] byExtendingSelection:NO];
    [self.window makeKeyAndOrderFront:nil];
}

- (void)showAtPage:(NSInteger)page {
    [self show];
    if (page > 0 && page < static_cast<NSInteger>(self.categories.count))
        [self.list selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(page)] byExtendingSelection:NO];
}

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tv { (void)tv; return static_cast<NSInteger>(self.categories.count); }
- (NSView*)tableView:(NSTableView*)tv viewForTableColumn:(NSTableColumn*)col row:(NSInteger)row {
    (void)tv; (void)col;
    NSView* cell = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 190, 26)];
    NSTextField* f = [NSTextField labelWithString:self.categories[static_cast<NSUInteger>(row)]];
    f.font = sv::ui(12, true);
    f.textColor = sv::ink();
    f.frame = NSMakeRect(12, 5, 170, 16);          // 12 pt text is ~15 px tall: centred in the 26 px row
    f.lineBreakMode = NSLineBreakByTruncatingTail;
    [cell addSubview:f];
    return cell;
}
- (void)tableViewSelectionDidChange:(NSNotification*)n {
    (void)n;
    const NSInteger r = self.list.selectedRow;
    if (r >= 0) [self buildPage:r];
}

- (void)buildPage:(NSInteger)index {
    for (NSView* v in [self.content.subviews copy]) [v removeFromSuperview];
    SilvetonController* c = self.owner;
    if (!c || !c->_core) return;
    NSView* p = self.content;
    Project& project = c->_core->project();
    heading(p, self.categories[static_cast<NSUInteger>(index)], 18);
    CGFloat y = 56;
    switch (index) {
        case 0: {   // General
            lbl(p, @"Autosave every (seconds)", NSMakeRect(20, y + 3, 200, 16), sv::ui(11), sv::inkDim());
            self.autosaveField = fld(p, NSMakeRect(230, y, 70, 22), [NSString stringWithFormat:@"%.0f", c->_core->session().autosaveIntervalSeconds()]);
            y += 40;
            self.snapCheck = check(p, @"Snap to grid", NSMakeRect(20, y, 200, 20), c.snapEnabled);
            y += 34;
            lbl(p, @"Grid", NSMakeRect(20, y + 3, 100, 16), sv::ui(11), sv::inkDim());
            self.gridPopup = pop(p, NSMakeRect(230, y, 120, 22), @[@"1/4", @"1/8", @"1/16", @"1/32"]);
            const std::uint32_t d = c.gridDivisionsPerQuarter;
            [self.gridPopup selectItemAtIndex:d <= 1 ? 0 : (d == 2 ? 1 : (d == 4 ? 2 : 3))];
            y += 60;
            [p addSubview:[SVButton buttonWithTitle:@"Apply" target:self action:@selector(applyGeneral:) frame:NSMakeRect(230, y, 90, 24)]];
            break;
        }
        case 1: {   // Audio System
            const auto devices = CoreAudioDevice::devices();
            lbl(p, @"Audio device", NSMakeRect(20, y + 3, 180, 16), sv::ui(11), sv::inkDim());
            NSMutableArray* names = [NSMutableArray array];
            for (const auto& d : devices) [names addObject:[NSString stringWithFormat:@"%@  (%u in / %u out)", sv::ns(d.name), d.inputChannels, d.outputChannels]];
            if (names.count == 0) [names addObject:@"No audio device found"];
            self.devicePopup = pop(p, NSMakeRect(200, y, 360, 22), names);
            y += 36;
            lbl(p, @"Buffer size (samples)", NSMakeRect(20, y + 3, 180, 16), sv::ui(11), sv::inkDim());
            self.bufferPopup = pop(p, NSMakeRect(200, y, 120, 22), @[@"64", @"128", @"256", @"512", @"1024", @"2048"]);
            double cardRate = 48000.0;
            if (c->_core->ready()) {
                [self.bufferPopup selectItemWithTitle:[NSString stringWithFormat:@"%u", c->_core->device().config().blockSize]];
                cardRate = c->_core->device().config().sampleRate;
            }
            y += 36;
            lbl(p, @"Sound-card sample rate", NSMakeRect(20, y + 3, 180, 16), sv::ui(11), sv::inkDim());
            self.ratePopup = pop(p, NSMakeRect(200, y, 120, 22), @[@"44100", @"48000", @"88200", @"96000"]);
            [self.ratePopup selectItemWithTitle:[NSString stringWithFormat:@"%.0f", cardRate]];
            y += 36;
            lbl(p, @"Program processing", NSMakeRect(20, y + 3, 180, 16), sv::ui(11), sv::inkDim());
            self.processPopup = pop(p, NSMakeRect(200, y, 360, 22), @[@"96 kHz — Studio sinc (the sampler's interpolation)", @"Same as the sound card"]);
            [self.processPopup selectItemAtIndex:c->_core->internalSampleRate() > 0.0 ? 0 : 1];
            y += 44;
            [p addSubview:[SVButton buttonWithTitle:@"Apply" target:self action:@selector(applyAudio:) frame:NSMakeRect(200, y, 90, 24)]];
            y += 44;
            NSString* info = @"";
            if (c->_core->ready()) {
                const auto& cfg = c->_core->device().config();
                info = [NSString stringWithFormat:@"Card: %.0f Hz, %u samples\nProject / processing: %.0f Hz", cfg.sampleRate, cfg.blockSize, project.sampleRate];
                if (c->_core->rateBridgeActive())
                    info = [info stringByAppendingFormat:@"\nRate converters add about %.1f ms in total (recording is compensated).",
                            c->_core->runtime().rateBridge().addedLatencyDeviceFrames() * 1000.0 / cfg.sampleRate];
            }
            NSTextField* t = lbl(p, info, NSMakeRect(20, y, 540, 60), sv::ui(11), sv::inkDim());
            t.maximumNumberOfLines = 4;
            break;
        }
        case 2: {   // MIDI
            lbl(p, @"MIDI inputs (all connected inputs are active)", NSMakeRect(20, y, 400, 16), sv::ui(11), sv::inkDim());
            y += 24;
            NSMutableString* s = [NSMutableString string];
            if (c->_core->midi()) {
                for (const auto& src : c->_core->midi()->sources()) [s appendFormat:@"%@  %@\n", src.connected ? @"●" : @"○", sv::ns(src.name)];
            }
            if (s.length == 0) [s appendString:@"No MIDI inputs found"];
            NSTextField* t = lbl(p, s, NSMakeRect(20, y, 540, 200), sv::mono(11), sv::ink());
            t.maximumNumberOfLines = 12;
            y += 220;
            [p addSubview:[SVButton buttonWithTitle:@"Reconnect inputs" target:self action:@selector(reconnectMidi:) frame:NSMakeRect(20, y, 130, 24)]];
            break;
        }
        case 3: {   // Metronome
            self.clickCheck = check(p, @"Metronome click on", NSMakeRect(20, y, 220, 20), project.metronomeEnabled);
            y += 36;
            lbl(p, @"Click level (dB)", NSMakeRect(20, y + 3, 180, 16), sv::ui(11), sv::inkDim());
            self.clickLevel = fld(p, NSMakeRect(230, y, 70, 22), [NSString stringWithFormat:@"%.1f", project.metronomeGainDb]);
            y += 34;
            lbl(p, @"Accent level (dB)", NSMakeRect(20, y + 3, 180, 16), sv::ui(11), sv::inkDim());
            self.accentLevel = fld(p, NSMakeRect(230, y, 70, 22), [NSString stringWithFormat:@"%.1f", project.metronomeAccentGainDb]);
            y += 34;
            lbl(p, @"Count-in (bars)", NSMakeRect(20, y + 3, 180, 16), sv::ui(11), sv::inkDim());
            self.countIn = fld(p, NSMakeRect(230, y, 70, 22), [NSString stringWithFormat:@"%u", project.countInBars]);
            y += 50;
            [p addSubview:[SVButton buttonWithTitle:@"Apply" target:self action:@selector(applyMetronome:) frame:NSMakeRect(230, y, 90, 24)]];
            break;
        }
        case 4: {   // Project Setup
            const auto tp = project.tempoMap.positionAtSample(0);
            NSString* path = c->_core->session().hasProjectPath() ? sv::ns(c->_core->session().projectPath()) : @"(not saved yet)";
            NSString* txt = [NSString stringWithFormat:
                @"Project file:   %@\nSample rate:   %.0f Hz   (32-bit float processing)\nStart tempo:    %.2f BPM\nTime signature: %u/%u\nRecordings:     %@",
                path, project.sampleRate, tp.bpm, tp.numerator, tp.denominator, sv::ns(sv::recordingsDirectory())];
            NSTextField* t = lbl(p, txt, NSMakeRect(20, y, 540, 120), sv::mono(11), sv::ink());
            t.lineBreakMode = NSLineBreakByCharWrapping;   // a long folder path wraps instead of being cut
            t.maximumNumberOfLines = 8;
            y += 140;
            lbl(p, @"Pan law", NSMakeRect(20, y + 3, 180, 16), sv::ui(11), sv::inkDim());
            self.panLaw = pop(p, NSMakeRect(230, y, 140, 22), @[@"-2.5 dB", @"-3 dB", @"-4.5 dB", @"-6 dB"]);
            [self.panLaw selectItemAtIndex:static_cast<NSInteger>(project.panDepth)];
            y += 44;
            [p addSubview:[SVButton buttonWithTitle:@"Apply" target:self action:@selector(applyProject:) frame:NSMakeRect(230, y, 90, 24)]];
            break;
        }
        case 5: {   // VST Plug-ins
            const std::size_t found = c->_browser ? c->_browser->catalog().entries().size() : 0U;
            const std::size_t quarantined = c->_browser ? c->_browser->quarantine().entries().size() : 0U;
            lbl(p, [NSString stringWithFormat:@"%lu VST3 plug-in(s) known\n%lu in quarantine (crashed or failed while scanning)\n9 Silveton Native processors are always available.",
                    (unsigned long)found, (unsigned long)quarantined], NSMakeRect(20, y, 540, 60), sv::ui(11), sv::ink());
            y += 80;
            [p addSubview:[SVButton buttonWithTitle:@"Scan VST3 plug-ins" target:self action:@selector(scan:) frame:NSMakeRect(20, y, 150, 24)]];
            y += 40;
            lbl(p, @"Scanning runs in a separate process, so a faulty plug-in cannot crash Silveton.", NSMakeRect(20, y, 540, 16), sv::ui(11), sv::inkFaint());
            break;
        }
        default: {  // Key Commands
            NSArray* rows = @[
                @"Space — Play / Stop", @".  — Stop (twice: go to start)", @",  — Go to start", @"*  — Record", @"/  — Cycle on/off",
                @"C  — Metronome click", @"M  — Mute / Unmute", @"Insert — Add marker", @"J  — Snap on/off", @"G / H — Zoom out / in",
                @"⌥X — Split at cursor", @"⌘D — Duplicate", @"⌘Z / ⇧⌘Z — Undo / Redo", @"F2 — Project window", @"F3 — MixConsole",
                @"F4 — Editor", @"F5 — Library", @"Return — Open editor for the selected part or clip", @"⌘, — Preferences"];
            NSString* joined = [rows componentsJoinedByString:@"\n"];
            NSTextField* t = lbl(p, joined, NSMakeRect(20, y, 540, 400), sv::mono(11), sv::ink());
            t.maximumNumberOfLines = 24;
            break;
        }
    }
}

- (void)applyGeneral:(id)sender {
    (void)sender;
    SilvetonController* c = self.owner;
    if (!c || !c->_core) return;
    const double secs = std::max(15.0, std::min(3600.0, self.autosaveField.doubleValue));
    c->_core->session().setAutosaveIntervalSeconds(secs);
    const BOOL wantSnap = self.snapCheck.state == NSControlStateValueOn;
    if (wantSnap != c.snapEnabled) [c toggleSnap:nil];
    static const std::uint32_t divs[4] = {1U, 2U, 4U, 8U};
    c->_gridDiv = divs[std::clamp<NSInteger>(self.gridPopup.indexOfSelectedItem, 0, 3)];
    [c refreshAll];
    [c setStatus:@"General preferences applied"];
}

- (void)applyAudio:(id)sender {
    (void)sender;
    SilvetonController* c = self.owner;
    if (!c || !c->_core) return;
    try {
        const auto devices = CoreAudioDevice::devices();
        const NSInteger idx = self.devicePopup.indexOfSelectedItem;
        if (idx < 0 || idx >= static_cast<NSInteger>(devices.size())) return;
        const auto& dev = devices[static_cast<std::size_t>(idx)];
        AudioDeviceConfig cfg;
        cfg.sampleRate = self.ratePopup.titleOfSelectedItem.doubleValue;
        cfg.blockSize = static_cast<std::uint32_t>(self.bufferPopup.titleOfSelectedItem.intValue);
        cfg.inputChannels = std::min<std::uint32_t>(2U, dev.inputChannels);
        cfg.outputChannels = std::min<std::uint32_t>(2U, dev.outputChannels);
        if (cfg.outputChannels == 0U) throw std::runtime_error("that device has no outputs");
        CoreAudioDeviceOptions opts;
        opts.deviceUid = dev.uid;
        opts.followDefaultOutputDevice = false;
        [SilvetonNativeEditor closeAll];
        c->_core->setInternalSampleRate(self.processPopup.indexOfSelectedItem == 0 ? 96000.0 : 0.0);
        c->_core->restartAudio(cfg, opts);
        [c refreshAll];
        [c setStatus:@"Audio system restarted"];
        [self buildPage:1];
    } catch (const std::exception& e) {
        [c showError:@"Audio System" detail:e.what()];
    }
}

- (void)reconnectMidi:(id)sender {
    (void)sender;
    SilvetonController* c = self.owner;
    if (c && c->_core && c->_core->midi()) { c->_core->midi()->connectAll(); [self buildPage:2]; }
}

- (void)applyMetronome:(id)sender {
    (void)sender;
    SilvetonController* c = self.owner;
    if (!c || !c->_core) return;
    const bool on = self.clickCheck.state == NSControlStateValueOn;
    const float click = static_cast<float>(std::clamp(self.clickLevel.doubleValue, -60.0, 0.0));
    const float accent = static_cast<float>(std::clamp(self.accentLevel.doubleValue, -60.0, 0.0));
    const std::uint32_t bars = static_cast<std::uint32_t>(std::clamp(self.countIn.intValue, 0, 8));
    [c runEdit:@"Metronome Setup" rebuild:NO block:^{
        Project& p = c->_core->project();
        p.metronomeEnabled = on; p.metronomeGainDb = click; p.metronomeAccentGainDb = accent; p.countInBars = bars;
    }];
    if (c->_core->ready()) {
        c->_core->engine().setMetronomeEnabled(on);
        c->_core->engine().setMetronomeGainDb(click, accent);
    }
}

- (void)applyProject:(id)sender {
    (void)sender;
    SilvetonController* c = self.owner;
    if (!c || !c->_core) return;
    const auto depth = static_cast<PanDepth>(self.panLaw.indexOfSelectedItem);
    [c runEdit:@"Pan Law" rebuild:NO block:^{ c->_core->project().panDepth = depth; }];
    if (c->_core->ready()) c->_core->engine().setPanDepth(depth);
}

- (void)scan:(id)sender { (void)sender; [self.owner scanPlugins:nil]; }
- (void)windowWillClose:(NSNotification*)n { (void)n; }
@end

@implementation SilvetonController (Prefs)
- (void)showPreferences:(id)sender {
    (void)sender;
    SVPrefs* p = [SVPrefs shared];
    p.owner = self;
    [p show];
}
- (void)showProjectSetup:(id)sender {
    (void)sender;
    SVPrefs* p = [SVPrefs shared];
    p.owner = self;
    [p showAtPage:4];   // "Project Setup" page
}
@end
