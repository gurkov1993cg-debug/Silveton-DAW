#import "SilvetonViews.h"
#include "SilvetonMeterDraw.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/NativePlugins.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

using namespace silveton;

// ============================================================== Console ==
namespace {
constexpr CGFloat kStripW = 112.0;
constexpr CGFloat kCompactStripW = 100.0;   // the mixer under the tracks
constexpr CGFloat kStripGap = 8.0;
constexpr int kInsertRows = 6;

struct StripGeom {
    NSRect frame, cap, inserts[kInsertRows], sends, pan, mute, solo, fader, meter, lamp, meterZone, readout, output;
};

StripGeom geometry(CGFloat x, CGFloat height, bool compact) {
    StripGeom g;
    if (compact) {
        const CGFloat W = kCompactStripW;
        g.frame = NSMakeRect(x, 6, W, height - 12);
        g.cap = NSMakeRect(x, 6, W, 32);
        for (int i = 0; i < kInsertRows; ++i) g.inserts[i] = i < 3 ? NSMakeRect(x + 6, 40 + i * 19, W - 12, 17) : NSZeroRect;
        g.sends = NSZeroRect;
        g.pan = NSMakeRect(x + W / 2 - 13, 100, 26, 26);
        g.mute = NSMakeRect(x + 6, 104, 28, 18);
        g.solo = NSMakeRect(x + W - 34, 104, 28, 18);
        const CGFloat faderTop = 140, faderBottom = height - 52;
        const CGFloat meterH = std::max<CGFloat>(40, faderBottom - faderTop);
        g.fader = NSMakeRect(x + 16, faderTop, 20, meterH);
        g.meter = NSMakeRect(x + 52, faderTop, 16, meterH);
        g.lamp = NSMakeRect(x + 52, faderTop - 9, 16, 5);
        g.meterZone = NSMakeRect(x + 50, faderTop - 10, 20, meterH + 12);
        g.readout = NSMakeRect(x + 6, faderBottom + 10, W - 12, 17);
        g.output = NSMakeRect(x + 4, faderBottom + 29, W - 8, 14);
        return g;
    }
    g.frame = NSMakeRect(x, 8, kStripW, height - 16);
    g.cap = NSMakeRect(x, 8, kStripW, 36);
    for (int i = 0; i < kInsertRows; ++i) g.inserts[i] = NSMakeRect(x + 6, 52 + i * 22, kStripW - 12, 20);
    g.sends = NSMakeRect(x + 6, 52 + kInsertRows * 22 + 2, kStripW - 12, 18);
    g.pan = NSMakeRect(x + kStripW / 2 - 17, 52 + kInsertRows * 22 + 26, 34, 34);
    const CGFloat btnY = g.pan.origin.y + 34 + 20;          // room for the pan read-out under the knob
    g.mute = NSMakeRect(x + 8, btnY, 44, 20);
    g.solo = NSMakeRect(x + kStripW - 52, btnY, 44, 20);
    const CGFloat faderTop = btnY + 32;
    const CGFloat faderBottom = height - 72;
    g.fader = NSMakeRect(x + 28, faderTop, 20, std::max<CGFloat>(40, faderBottom - faderTop));
    const CGFloat meterH = std::max<CGFloat>(40, faderBottom - faderTop);
    g.meter = NSMakeRect(x + 66, faderTop, 16, meterH);
    g.lamp = NSMakeRect(x + 66, faderTop - 9, 16, 5);                         // clip lamp above the bars
    g.meterZone = NSMakeRect(x + 64, faderTop - 10, 20, meterH + 12);         // the part the 30 Hz timer repaints
    g.readout = NSMakeRect(x + 6, faderBottom + 12, kStripW - 12, 18);   // below the lowest fader-cap position
    g.output = NSMakeRect(x + 6, faderBottom + 34, kStripW - 12, 18);
    return g;
}

std::string pluginDisplayName(const ProjectPluginSlot& slot) {
    if (isNativeModulePath(slot.modulePath))
        for (const auto& i : nativePluginCatalog()) if (i.classId == slot.classId) return i.name;
    std::string n = slot.modulePath;
    const auto s = n.find_last_of('/');
    if (s != std::string::npos) n = n.substr(s + 1);
    const auto d = n.find_last_of('.');
    if (d != std::string::npos) n = n.substr(0, d);
    return n.empty() ? slot.classId : n;
}
} // namespace

@implementation SilvetonConsoleView {
    std::vector<SVStrip> _strips;
    SVStrip _dragStrip;
    int _dragWhat;   // 1 fader, 2 pan
    double _dragStartValue;
    NSPoint _dragStart;
    BOOL _gesture;
    std::vector<std::uint32_t> _meterSig;   // what each strip's meter looked like when last painted
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (CGFloat)stripW { return self.compact ? kCompactStripW : kStripW; }

- (void)rebuildStrips {
    _strips.clear();
    const Project* p = self.controller.project;
    if (!p) return;
    for (std::size_t i = 0; i < p->tracks.size(); ++i) _strips.push_back({SVStripKind::Track, i});
    for (std::size_t i = 0; i < p->buses.size(); ++i) _strips.push_back({SVStripKind::Bus, i});
    _strips.push_back({SVStripKind::Master, 0});
}

- (CGFloat)xForStrip:(std::size_t)i {
    // Master is pinned to the right edge.
    if (i + 1 == _strips.size()) return self.bounds.size.width - [self stripW] - 12;
    return 12 + static_cast<CGFloat>(i) * ([self stripW] + kStripGap) - self.scrollX;
}

// The 30 Hz timer invalidates only thin meter columns. Each invalid rectangle
// is painted on its own, and a rectangle that lies inside a meter column skips
// all the static text/controls of that strip (see `meterOnly` below).
- (void)tickMeters {
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    [self rebuildStrips];
    if (_meterSig.size() != _strips.size()) _meterSig.assign(_strips.size(), 0U);
    const NSRect b = self.bounds;
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        const CGFloat x = [self xForStrip:i];
        if (x + [self stripW] < 0 || x > b.size.width) continue;
        const StripGeom g = geometry(x, b.size.height, self.compact);
        const std::uint32_t sig = sv::meter::signature([c meterDisplayForStrip:_strips[i]], g.meter.size.height, true);
        if (sig == _meterSig[i]) continue;
        _meterSig[i] = sig;
        [self setNeedsDisplayInRect:g.meterZone];
    }
}

- (void)drawRect:(NSRect)dirty {
    const NSRect* rects = nullptr;
    NSInteger count = 0;
    [self getRectsBeingDrawn:&rects count:&count];
    if (count <= 0 || count > 32 || !rects) { [self paintRect:dirty]; return; }
    for (NSInteger i = 0; i < count; ++i) {
        [NSGraphicsContext saveGraphicsState];
        NSRectClip(rects[i]);
        [self paintRect:rects[i]];
        [NSGraphicsContext restoreGraphicsState];
    }
}

- (void)paintRect:(NSRect)dirty {
    const NSRect b = self.bounds;
    sv::fill(dirty, sv::canvas());
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    [self rebuildStrips];
    const Project& p = *c.project;
    const SVStrip selected = c.selectedStrip;
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(0, 0, b.size.width - [self stripW] - 24, b.size.height));
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        if (i + 1 == _strips.size()) {
            [NSGraphicsContext restoreGraphicsState];
            sv::line(NSMakePoint(b.size.width - [self stripW] - 18.5, 8), NSMakePoint(b.size.width - [self stripW] - 18.5, b.size.height - 8), sv::hairline());
        }
        const CGFloat x = [self xForStrip:i];
        if (x + [self stripW] < 0 || x > b.size.width) continue;
        const SVStrip s = _strips[i];
        const StripGeom g = geometry(x, b.size.height, self.compact);
        if (!NSIntersectsRect(dirty, NSInsetRect(g.frame, -2, -2))) continue;
        const bool meterOnly = NSContainsRect(g.meterZone, dirty);
        std::string name;
        std::uint32_t color = 0;
        double gain = 0, pan = 0;
        bool mute = false, solo = false, hasPan = false;
        const std::vector<ProjectPluginSlot>* slots = nullptr;
        std::size_t sendCount = 0;
        std::string output = "Stereo Out";
        if (s.kind == SVStripKind::Track) {
            const auto& t = p.tracks[s.index];
            name = t.name; color = effectiveTrackColor(p, s.index); gain = t.gainDb; pan = t.pan; mute = t.mute; solo = t.solo;
            hasPan = true; slots = &t.pluginSlots; sendCount = t.sends.size();
            if (t.outputBus >= 0 && static_cast<std::size_t>(t.outputBus) < p.buses.size()) output = p.buses[static_cast<std::size_t>(t.outputBus)].name;
        } else if (s.kind == SVStripKind::Bus) {
            const auto& bus = p.buses[s.index];
            name = bus.name; color = bus.color ? bus.color : (bus.kind == ProjectBusKind::Group ? 0x8A8FB8U : 0x5FB3A8U);
            gain = bus.gainDb; mute = bus.mute; solo = bus.solo; slots = &bus.pluginSlots; sendCount = bus.sends.size();
            if (bus.outputBus >= 0 && static_cast<std::size_t>(bus.outputBus) < p.buses.size()) output = p.buses[static_cast<std::size_t>(bus.outputBus)].name;
        } else {
            name = "MASTER"; color = 0xD9824BU; gain = p.masterFaderDb; slots = &p.masterPluginSlots; output = "Device";
        }
        const bool isSel = selected == s;
        sv::roundFill(g.frame, 6, isSel ? sv::hex(0x2E323A) : sv::panel());
        sv::roundStroke(g.frame, 6, isSel ? sv::inkDim() : sv::hairline(), 1.0);
        if (!meterOnly) {
            sv::roundFill(NSMakeRect(g.cap.origin.x, g.cap.origin.y, g.cap.size.width, 5), 3, [sv::hex(color) blendedColorWithFraction:0.25 ofColor:sv::hex(0x9AA0AC)]);
            sv::textIn(sv::ns(name.empty() ? std::string("—") : name), NSMakeRect(x + 6, g.cap.origin.y + 6, [self stripW] - 12, 18), sv::ui(12, true), sv::ink(), NSTextAlignmentCenter);
            if (s.kind == SVStripKind::Bus && !self.compact)
                sv::textIn(p.buses[s.index].kind == ProjectBusKind::Group ? @"GROUP" : @"FX", NSMakeRect(x, 31, [self stripW], 12), sv::ui(10, true), sv::inkFaint(), NSTextAlignmentCenter);
            const int shownRows = self.compact ? 3 : kInsertRows;
            for (int k = 0; k < shownRows; ++k) {
                const NSRect r = g.inserts[k];
                const bool have = slots && static_cast<std::size_t>(k) < slots->size();
                if (have) sv::roundFill(r, 4, sv::hex(0x2B2E35)); else sv::wellFill(r, 4.0);
                const CGFloat textY = r.origin.y + (r.size.height - 15.0) * 0.5;
                if (have) {
                    const auto& slot = (*slots)[static_cast<std::size_t>(k)];
                    [(slot.enabled ? sv::copper() : sv::inkFaint()) setFill];
                    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(r.origin.x + 6, NSMidY(r) - 2.5, 5, 5)] fill];
                    sv::textIn(sv::ns(pluginDisplayName(slot)), NSMakeRect(r.origin.x + 16, textY, r.size.width - 18, 15), sv::ui(self.compact ? 10 : 11), slot.enabled ? sv::ink() : sv::inkFaint());
                } else if (!slots || static_cast<std::size_t>(k) == slots->size()) {
                    sv::textIn(@"+ insert", NSMakeRect(r.origin.x, textY, r.size.width, 15), sv::ui(self.compact ? 10 : 11), sv::inkFaint(), NSTextAlignmentCenter);
                }
            }
            if (!self.compact) sv::textIn(sendCount ? [NSString stringWithFormat:@"%lu send%@", (unsigned long)sendCount, sendCount == 1 ? @"" : @"s"] : @"no sends",
                       NSMakeRect(g.sends.origin.x, g.sends.origin.y + 2, g.sends.size.width, 15), sv::ui(11), sv::inkDim(), NSTextAlignmentCenter);
            if (hasPan) {
                const NSPoint ctr = NSMakePoint(NSMidX(g.pan), NSMidY(g.pan));
                const CGFloat rad = g.pan.size.width * 0.5;
                NSBezierPath* knob = [NSBezierPath bezierPathWithOvalInRect:g.pan];
                [sv::hex(0x121317) setFill];
                [knob fill];
                [sv::hex(0x383C44) setStroke];
                knob.lineWidth = 1.0;
                [knob stroke];
                NSBezierPath* arc = [NSBezierPath bezierPath];
                // Flipped view: angles measured clockwise from +x in screen space.
                const CGFloat a0 = 270.0, a1 = 270.0 + pan * 135.0;
                [arc appendBezierPathWithArcWithCenter:ctr radius:rad - 3.5 startAngle:std::min(a0, a1) endAngle:std::max(a0, a1)];
                arc.lineWidth = 2.5;
                [sv::copper() setStroke];
                [arc stroke];
                const double ang = (270.0 + pan * 135.0) * M_PI / 180.0;
                sv::line(ctr, NSMakePoint(ctr.x + (rad - 3.0) * std::cos(ang), ctr.y + (rad - 3.0) * std::sin(ang)), sv::hex(0xECEAE2), 2);
                if (!self.compact) {
                    NSString* ps = std::abs(pan) < 0.005 ? @"C" : [NSString stringWithFormat:@"%@%d", pan < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(pan) * 100))];
                    sv::textIn(ps, NSMakeRect(x, NSMaxY(g.pan) + 2, [self stripW], 15), sv::mono(11), sv::inkDim(), NSTextAlignmentCenter);
                }
            }
            if (s.kind != SVStripKind::Master) {
                sv::pill(g.mute, self.compact ? @"M" : @"MUTE", mute, sv::muteTint());
                sv::pill(g.solo, self.compact ? @"S" : @"SOLO", solo, sv::soloTint());
            }
            // Fader: groove + dB ticks + cap
            const NSRect groove = NSMakeRect(NSMidX(g.fader) - 2, g.fader.origin.y, 4, g.fader.size.height);
            sv::roundFill(groove, 2, sv::hex(0x0B0C0E));
            for (double db : {12.0, 6.0, 0.0, -6.0, -12.0, -24.0, -40.0, -60.0}) {
                const CGFloat ty = NSMaxY(g.fader) - g.fader.size.height * faderPositionForDb(db);
                sv::line(NSMakePoint(g.fader.origin.x - 6, ty), NSMakePoint(g.fader.origin.x - 1, ty), db == 0.0 ? sv::inkDim() : sv::inkFaint());
            }
            const CGFloat capY = NSMaxY(g.fader) - g.fader.size.height * faderPositionForDb(gain);
            sv::faderCap(NSMakePoint(NSMidX(g.fader), capY), 16.0, 9.0);
            // dB scale to the right of the meter, on the same positions as the fader scale
            CGFloat lastLabelY = -1.0e9;
            for (double db : {6.0, 0.0, -6.0, -12.0, -24.0, -40.0, -60.0}) {
                const CGFloat ty = std::round(NSMaxY(g.meter) - g.meter.size.height * sv::meter::position(db));
                NSColor* tone = db == 0.0 ? sv::inkDim() : sv::inkFaint();
                sv::line(NSMakePoint(g.meter.origin.x + 19, ty + 0.5), NSMakePoint(g.meter.origin.x + 22, ty + 0.5), tone);
                if (ty - lastLabelY < 12.0) continue;
                lastLabelY = ty;
                sv::textIn(sv::meter::dbLabel(db), NSMakeRect(g.meter.origin.x + 24, ty - 6, 20, 12), sv::mono(10), tone, NSTextAlignmentLeft);
            }
        }
        // Meter: clip lamp + two LED bars (the master/track level from the shared meter bank)
        const StereoMeterDisplay md = [c meterDisplayForStrip:s];
        sv::meter::drawClipLamp(g.lamp, md.clip());
        for (int ch = 0; ch < 2; ++ch) {
            const MeterChannelDisplay& m = ch == 0 ? md.left : md.right;
            sv::meter::drawBar(NSMakeRect(g.meter.origin.x + ch * 9, g.meter.origin.y, 7, g.meter.size.height),
                               true, m.levelDb, m.holdDb, m.clip, true);
        }
        if (!meterOnly) {
            sv::lcd(g.readout, 4.0);
            sv::textIn(gain <= -95.9 ? @"-∞ dB" : [NSString stringWithFormat:@"%+.1f dB", gain],
                       NSMakeRect(g.readout.origin.x, g.readout.origin.y + 2, g.readout.size.width, 14), sv::mono(11, true), sv::lcdValue(), NSTextAlignmentCenter);
            sv::textIn(sv::ns("→ " + output), g.output, sv::ui(10), sv::inkDim(), NSTextAlignmentCenter);
        }
    }
}

- (long)stripAt:(NSPoint)p {
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        const CGFloat x = [self xForStrip:i];
        if (p.x >= x && p.x <= x + [self stripW]) {
            if (i + 1 != _strips.size() && p.x > self.bounds.size.width - [self stripW] - 24) continue;
            return static_cast<long>(i);
        }
    }
    return -1;
}

- (double)stripGain:(SVStrip)s {
    const Project* p = self.controller.project;
    if (s.kind == SVStripKind::Track) return p->tracks[s.index].gainDb;
    if (s.kind == SVStripKind::Bus) return p->buses[s.index].gainDb;
    return p->masterFaderDb;
}

- (void)mouseDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (!c.project) return;
    [self rebuildStrips];
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    const long idx = [self stripAt:pt];
    if (idx < 0) return;
    const SVStrip s = _strips[static_cast<std::size_t>(idx)];
    [c selectStrip:s];
    const StripGeom g = geometry([self xForStrip:static_cast<std::size_t>(idx)], self.bounds.size.height, self.compact);
    if (NSPointInRect(pt, g.meterZone)) {   // click: clear this strip's clip lamp; Option-click: all strips
        [c resetMetersForStrip:s all:(event.modifierFlags & NSEventModifierFlagOption) != 0];
        return;
    }
    for (int k = 0; k < kInsertRows; ++k) {
        if (!NSPointInRect(pt, g.inserts[k])) continue;
        const std::vector<ProjectPluginSlot>* slots = s.kind == SVStripKind::Track ? &c.project->tracks[s.index].pluginSlots
                                                   : s.kind == SVStripKind::Bus ? &c.project->buses[s.index].pluginSlots
                                                                                : &c.project->masterPluginSlots;
        if (static_cast<std::size_t>(k) < slots->size()) [c stripInsertClicked:s slot:static_cast<std::size_t>(k)];
        else if (NSMenu* menu = [c insertMenuForStrip:s]) [NSMenu popUpContextMenu:menu withEvent:event forView:self];
        [self setNeedsDisplay:YES];
        return;
    }
    if (s.kind != SVStripKind::Master && NSPointInRect(pt, g.mute)) { [c toggleStripMute:s]; [self setNeedsDisplay:YES]; return; }
    if (s.kind != SVStripKind::Master && NSPointInRect(pt, g.solo)) { [c toggleStripSolo:s]; [self setNeedsDisplay:YES]; return; }
    if (s.kind == SVStripKind::Track && NSPointInRect(pt, g.pan)) {
        if (event.clickCount >= 2) { [c setStrip:s pan:0.0]; [self setNeedsDisplay:YES]; return; }
        _dragWhat = 2; _dragStrip = s; _dragStart = pt; _dragStartValue = c.project->tracks[s.index].pan;
        return;
    }
    if (NSPointInRect(pt, NSInsetRect(g.fader, -12, -10))) {
        if (event.clickCount >= 2) { [c setStrip:s gainDb:0.0]; [self setNeedsDisplay:YES]; return; }
        _dragWhat = 1; _dragStrip = s; _dragStart = pt; _dragStartValue = faderPositionForDb([self stripGain:s]);
        return;
    }
    _dragWhat = 0;
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent*)event {
    if (_dragWhat == 0) return;
    SilvetonController* c = self.controller;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (!_gesture) { [c beginGesture:_dragWhat == 1 ? @"Fader" : @"Pan"]; _gesture = YES; }
    const bool fine = (event.modifierFlags & NSEventModifierFlagShift) != 0;
    if (_dragWhat == 1) {
        const StripGeom g = geometry(0, self.bounds.size.height, self.compact);
        const double scale = fine ? 0.2 : 1.0;
        const double pos = sv::clamp01(_dragStartValue - (pt.y - _dragStart.y) / g.fader.size.height * scale);
        [c setStrip:_dragStrip gainDb:dbForFaderPosition(pos)];
    } else {
        const double v = std::max(-1.0, std::min(1.0, _dragStartValue - (pt.y - _dragStart.y) / (fine ? 600.0 : 120.0)));
        [c setStrip:_dragStrip pan:v];
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_gesture) { [self.controller endGesture]; _gesture = NO; }
    _dragWhat = 0;
}

- (NSMenu*)menuForEvent:(NSEvent*)event {
    [self rebuildStrips];
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    const long idx = [self stripAt:pt];
    if (idx < 0) return nil;
    const SVStrip s = _strips[static_cast<std::size_t>(idx)];
    [self.controller selectStrip:s];
    return [self.controller contextMenuForStrip:s];
}

- (void)scrollWheel:(NSEvent*)event {
    double d = event.scrollingDeltaX;
    if (std::abs(d) < 0.001) d = event.scrollingDeltaY;
    if (!event.hasPreciseScrollingDeltas) d *= 12;
    const double maxScroll = std::max(0.0, static_cast<double>(_strips.size()) * ([self stripW] + kStripGap) - (self.bounds.size.width - [self stripW] - 40));
    self.scrollX = std::max(0.0, std::min(maxScroll, self.scrollX - d));
    [self setNeedsDisplay:YES];
}
@end

// ======================================================= Native editor ==
@interface SVParamSlider : NSSlider
@property(nonatomic, assign) std::uint32_t paramId;
@property(nonatomic, weak) id editorOwner;
@end

@interface SilvetonNativeEditor ()
@property(nonatomic, copy) SilvetonNativeResolver resolver;
@property(nonatomic, copy) NSString* editorKey;
@property(nonatomic, copy) NSString* classId;
- (void)beginParam:(std::uint32_t)paramId;
- (void)endParam:(std::uint32_t)paramId;
- (void)resetParam:(std::uint32_t)paramId;
@end

@implementation SVParamSlider
- (void)mouseDown:(NSEvent*)event {
    SilvetonNativeEditor* ed = self.editorOwner;
    if (event.clickCount >= 2) { [ed resetParam:self.paramId]; return; }
    [ed beginParam:self.paramId];
    [super mouseDown:event];
    [ed endParam:self.paramId];
}
@end

static NSMutableDictionary<NSString*, SilvetonNativeEditor*>* gNativeEditors = nil;

@implementation SilvetonNativeEditor {
    NSMutableArray* _controls;     // index = param id
    NSMutableArray<NSTextField*>* _values;
    NSTextField* _meterLabel;
}

+ (void)openWithResolver:(SilvetonNativeResolver)resolver title:(NSString*)title key:(NSString*)key {
    if (!gNativeEditors) gNativeEditors = [NSMutableDictionary dictionary];
    NativePlugin* plugin = resolver ? resolver() : nullptr;
    if (!plugin) return;
    SilvetonNativeEditor* existing = gNativeEditors[key];
    if (existing && [existing.classId isEqualToString:sv::ns(plugin->classId())]) { [existing makeKeyAndOrderFront:nil]; return; }
    if (existing) { [existing close]; [gNativeEditors removeObjectForKey:key]; }
    const auto& params = plugin->parameters();
    const CGFloat rowH = 30, width = 440;
    const CGFloat height = 70 + rowH * static_cast<CGFloat>(params.size()) + 20;
    SilvetonNativeEditor* ed = [[SilvetonNativeEditor alloc] initWithContentRect:NSMakeRect(200, 200, width, height)
                                                                     styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskUtilityWindow
                                                                       backing:NSBackingStoreBuffered defer:NO];
    ed.resolver = resolver;
    ed.editorKey = key;
    ed.classId = sv::ns(plugin->classId());
    ed.title = title;
    ed.releasedWhenClosed = NO;
    ed.backgroundColor = sv::panel();
    ed.hidesOnDeactivate = NO;
    [ed buildFor:plugin width:width height:height rowHeight:rowH];
    gNativeEditors[key] = ed;
    [ed center];
    [ed makeKeyAndOrderFront:nil];
}

- (NSTextField*)labelWith:(NSString*)s frame:(NSRect)f font:(NSFont*)font color:(NSColor*)color align:(NSTextAlignment)a {
    NSTextField* l = [[NSTextField alloc] initWithFrame:f];
    l.stringValue = s; l.editable = NO; l.selectable = NO; l.bezeled = NO; l.drawsBackground = NO;
    l.font = font; l.textColor = color; l.alignment = a;
    return l;
}

- (void)buildFor:(NativePlugin*)plugin width:(CGFloat)width height:(CGFloat)height rowHeight:(CGFloat)rowH {
    NSView* root = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, width, height)];
    self.contentView = root;
    _controls = [NSMutableArray array];
    _values = [NSMutableArray array];
    NSString* header = sv::ns(plugin->info().name).uppercaseString;
    [root addSubview:[self labelWith:header frame:NSMakeRect(18, height - 40, width - 36 - 176, 20) font:sv::ui(13, true) color:sv::copper() align:NSTextAlignmentLeft]];
    [root addSubview:[self labelWith:@"SILVETON NATIVE" frame:NSMakeRect(18, height - 56, 200, 14) font:sv::ui(10, true) color:sv::inkFaint() align:NSTextAlignmentLeft]];
    _meterLabel = [self labelWith:@"" frame:NSMakeRect(width - 190, height - 40, 172, 18) font:sv::mono(11, true) color:sv::amber() align:NSTextAlignmentRight];
    [root addSubview:_meterLabel];
    const auto& params = plugin->parameters();
    for (std::size_t i = 0; i < params.size(); ++i) {
        const auto& prm = params[i];
        const CGFloat y = height - 80 - static_cast<CGFloat>(i) * rowH;
        [root addSubview:[self labelWith:sv::ns(prm.name) frame:NSMakeRect(18, y, 128, 18) font:sv::ui(12) color:sv::ink() align:NSTextAlignmentLeft]];
        NSControl* ctl = nil;
        if (prm.scale == NativeParamScale::Toggle) {
            NSButton* b = [[NSButton alloc] initWithFrame:NSMakeRect(156, y - 2, 180, 22)];
            [b setButtonType:NSButtonTypeSwitch];
            b.title = @"";
            b.target = self; b.action = @selector(toggleChanged:); b.tag = static_cast<NSInteger>(prm.id);
            ctl = b;
        } else if (prm.scale == NativeParamScale::Choice) {
            NSPopUpButton* pop = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(152, y - 3, 190, 24) pullsDown:NO];
            for (const auto& ch : prm.choices) [pop addItemWithTitle:sv::ns(ch)];
            pop.target = self; pop.action = @selector(choiceChanged:); pop.tag = static_cast<NSInteger>(prm.id);
            pop.font = sv::ui(11);
            ctl = pop;
        } else {
            SVParamSlider* s = [[SVParamSlider alloc] initWithFrame:NSMakeRect(154, y - 2, 190, 22)];
            s.minValue = 0; s.maxValue = 1; s.continuous = YES;
            s.paramId = prm.id; s.editorOwner = self;
            s.target = self; s.action = @selector(sliderChanged:); s.tag = static_cast<NSInteger>(prm.id);
            ctl = s;
        }
        [root addSubview:ctl];
        [_controls addObject:ctl];
        NSTextField* v = [self labelWith:@"" frame:NSMakeRect(350, y, width - 366, 18) font:sv::mono(11) color:sv::inkDim() align:NSTextAlignmentRight];
        [root addSubview:v];
        [_values addObject:v];
    }
    [self syncFrom:plugin];
}

- (void)syncFrom:(NativePlugin*)plugin {
    const auto& params = plugin->parameters();
    for (std::size_t i = 0; i < params.size() && i < _controls.count; ++i) {
        id ctl = _controls[i];
        const auto id = static_cast<std::uint32_t>(i);
        if ([ctl isKindOfClass:[NSPopUpButton class]]) [(NSPopUpButton*)ctl selectItemAtIndex:static_cast<NSInteger>(plugin->plainValue(id) - params[i].minValue)];
        else if ([ctl isKindOfClass:[SVParamSlider class]]) { if (![(NSSlider*)ctl isHighlighted]) [(NSSlider*)ctl setDoubleValue:plugin->normalizedValue(id)]; }
        else if ([ctl isKindOfClass:[NSButton class]]) [(NSButton*)ctl setState:plugin->plainValue(id) >= 0.5 ? NSControlStateValueOn : NSControlStateValueOff];
        _values[i].stringValue = sv::ns(plugin->formatValue(id));
    }
    const float gr = plugin->meter(0);
    if (plugin->classId() == "silveton.press" || plugin->classId() == "silveton.ceiling")
        _meterLabel.stringValue = [NSString stringWithFormat:@"GR %.1f dB", gr];
    else if (plugin->classId() == "silveton.gate")
        _meterLabel.stringValue = [NSString stringWithFormat:@"GAIN %.1f dB", gr];
}

- (NativePlugin*)plugin {
    NativePlugin* p = self.resolver ? self.resolver() : nullptr;
    if (p && ![sv::ns(p->classId()) isEqualToString:self.classId]) return nullptr;
    return p;
}
- (void)beginParam:(std::uint32_t)paramId { if (auto* p = [self plugin]) p->beginEdit(paramId); }
- (void)endParam:(std::uint32_t)paramId { if (auto* p = [self plugin]) p->endEdit(paramId); }
- (void)resetParam:(std::uint32_t)paramId {
    if (auto* p = [self plugin]) {
        const auto& prm = p->parameters()[paramId];
        p->beginEdit(paramId); p->setFromEditor(paramId, prm.defaultValue); p->endEdit(paramId);
        [self syncFrom:p];
    }
}
- (void)sliderChanged:(NSSlider*)sender {
    NativePlugin* p = [self plugin];
    if (!p) return;
    const auto id = static_cast<std::uint32_t>(sender.tag);
    p->setFromEditor(id, NativePlugin::toPlain(p->parameters()[id], sender.doubleValue));
    _values[id].stringValue = sv::ns(p->formatValue(id));
}
- (void)choiceChanged:(NSPopUpButton*)sender {
    NativePlugin* p = [self plugin];
    if (!p) return;
    const auto id = static_cast<std::uint32_t>(sender.tag);
    p->beginEdit(id); p->setFromEditor(id, p->parameters()[id].minValue + sender.indexOfSelectedItem); p->endEdit(id);
    _values[id].stringValue = sv::ns(p->formatValue(id));
}
- (void)toggleChanged:(NSButton*)sender {
    NativePlugin* p = [self plugin];
    if (!p) return;
    const auto id = static_cast<std::uint32_t>(sender.tag);
    p->beginEdit(id); p->setFromEditor(id, sender.state == NSControlStateValueOn ? 1.0 : 0.0); p->endEdit(id);
    _values[id].stringValue = sv::ns(p->formatValue(id));
}

+ (void)refreshAll {
    if (!gNativeEditors) return;
    NSMutableArray<NSString*>* dead = [NSMutableArray array];
    for (NSString* key in gNativeEditors) {
        SilvetonNativeEditor* ed = gNativeEditors[key];
        if (!ed.isVisible) { [dead addObject:key]; continue; }
        NativePlugin* p = [ed plugin];
        if (!p) { [ed close]; [dead addObject:key]; continue; }
        [ed syncFrom:p];
    }
    for (NSString* key in dead) [gNativeEditors removeObjectForKey:key];
}
+ (void)closeAll {
    if (!gNativeEditors) return;
    for (NSString* key in gNativeEditors) [gNativeEditors[key] close];
    [gNativeEditors removeAllObjects];
}
@end
