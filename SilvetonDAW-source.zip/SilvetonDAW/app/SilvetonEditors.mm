#import "SilvetonViews.h"
#include "SilvetonMeterDraw.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/NativePlugins.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

using namespace silveton;

// ============================================================== Console ==
namespace {
constexpr CGFloat kStripW = 116.0;
constexpr CGFloat kCompactStripW = 100.0;   // the mixer under the tracks
constexpr CGFloat kStripGap = 8.0;   // air between the rounded panels
constexpr int kInsertRows = 6;
constexpr int kSendRows = 2;

struct StripGeom {
    NSRect frame, cap, plate, inserts[kInsertRows], sends[kSendRows], pan, mute, solo, fader, meter, lamp, meterZone, readout, output;
    int insertRows {kInsertRows};
    int sendRows {kSendRows};
};

// The strip is laid out like a console channel: name plate on top, inserts and sends, the pan knob, the keys,
// then the fader next to its legend and the meter window, the gain read-out and the output under them.
StripGeom geometry(CGFloat x, CGFloat height, bool compact) {
    StripGeom g;
    const CGFloat W = compact ? kCompactStripW : kStripW;
    g.frame = NSMakeRect(x, 4, W, height - 8);
    g.cap = NSMakeRect(x, 4, W, 40);
    g.plate = NSMakeRect(x + 6, 17, W - 12, 22);
    CGFloat y = 48;
    g.insertRows = compact ? 3 : kInsertRows;
    y += 13;   // "INSERTS"
    for (int i = 0; i < kInsertRows; ++i) {
        g.inserts[i] = i < g.insertRows ? NSMakeRect(x + 6, y, W - 12, 18) : NSZeroRect;
        if (i < g.insertRows) y += 20;
    }
    g.sendRows = compact ? 0 : kSendRows;
    if (g.sendRows) y += 15;   // "SENDS"
    for (int i = 0; i < kSendRows; ++i) {
        g.sends[i] = i < g.sendRows ? NSMakeRect(x + 6, y, W - 12, 16) : NSZeroRect;
        if (i < g.sendRows) y += 18;
    }
    y += 8;
    const CGFloat knobR = compact ? 11 : 13;
    g.pan = NSMakeRect(x + W / 2 - knobR - 2, y + 2, 2 * knobR + 4, 2 * knobR + 4);
    y += 2 * knobR + (compact ? 20 : 26);
    g.mute = NSMakeRect(x + 8, y, W / 2 - 12, 20);
    g.solo = NSMakeRect(x + W / 2 + 4, y, W / 2 - 12, 20);
    y += 30;
    const CGFloat faderTop = y, faderBottom = height - 76;
    const CGFloat fh = std::max<CGFloat>(40, faderBottom - faderTop);
    g.fader = NSMakeRect(x + 12, faderTop, 20, fh);            // the cap travels on x + 22
    g.meter = NSMakeRect(x + W - 37, faderTop, 24, fh);        // two 10 px bars inside the meter window
    g.lamp = NSMakeRect(x + W - 35, faderTop - 9, 20, 4);
    g.meterZone = NSMakeRect(x + W - 40, faderTop - 12, 30, fh + 16);
    g.readout = NSMakeRect(x + 6, faderBottom + 12, W - 12, 20);
    g.output = NSMakeRect(x + 4, faderBottom + 38, W - 8, 14);
    return g;
}

std::string pluginDisplayName(const ProjectPluginSlot& slot) {
    if (isNativeModulePath(slot.modulePath))
        for (const auto& i : nativePluginCatalog()) if (i.classId == slot.classId) return i.name;
    std::string n = slot.modulePath;
    const auto s = n.find_last_of('/');
    if (s != std::string::npos) n = n.substr(s + 1);
    const auto d = n.find_last_of('.');
    if (d != std::string::npos) n = n.substr(0, d);
    return n.empty() ? slot.classId : n;
}
} // namespace

@implementation SilvetonConsoleView {
    std::vector<SVStrip> _strips;
    SVStrip _dragStrip;
    int _dragWhat;   // 1 fader, 2 pan
    double _dragStartValue;
    NSPoint _dragStart;
    BOOL _gesture;
    std::vector<std::uint32_t> _meterSig;   // what each strip's meter looked like when last painted
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (CGFloat)stripW { return self.compact ? kCompactStripW : kStripW; }

- (void)rebuildStrips {
    _strips.clear();
    const Project* p = self.controller.project;
    if (!p) return;
    for (std::size_t i = 0; i < p->tracks.size(); ++i) _strips.push_back({SVStripKind::Track, i});
    for (std::size_t i = 0; i < p->buses.size(); ++i) _strips.push_back({SVStripKind::Bus, i});
    _strips.push_back({SVStripKind::Master, 0});
}

- (CGFloat)xForStrip:(std::size_t)i {
    // Master is pinned to the right edge.
    if (i + 1 == _strips.size()) return self.bounds.size.width - [self stripW] - 12;
    return 12 + static_cast<CGFloat>(i) * ([self stripW] + kStripGap) - self.scrollX;
}

// The 30 Hz timer invalidates only thin meter columns. Each invalid rectangle
// is painted on its own, and a rectangle that lies inside a meter column skips
// all the static text/controls of that strip (see `meterOnly` below).
- (void)tickMeters {
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    [self rebuildStrips];
    if (_meterSig.size() != _strips.size()) _meterSig.assign(_strips.size(), 0U);
    const NSRect b = self.bounds;
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        const CGFloat x = [self xForStrip:i];
        if (x + [self stripW] < 0 || x > b.size.width) continue;
        const StripGeom g = geometry(x, b.size.height, self.compact);
        const std::uint32_t sig = sv::meter::signature([c meterDisplayForStrip:_strips[i]], g.meter.size.height, true);
        if (sig == _meterSig[i]) continue;
        _meterSig[i] = sig;
        [self setNeedsDisplayInRect:g.meterZone];
    }
}

// One channel changed (a fader or pan move): only its plate is painted again.
- (void)invalidateStrip:(SVStrip)strip {
    [self rebuildStrips];
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        if (!(_strips[i] == strip)) continue;
        const StripGeom g = geometry([self xForStrip:i], self.bounds.size.height, self.compact);
        [self setNeedsDisplayInRect:NSInsetRect(g.frame, -6, -6)];
        return;
    }
    [self setNeedsDisplay:YES];
}

- (void)drawRect:(NSRect)dirty {
    const NSRect* rects = nullptr;
    NSInteger count = 0;
    [self getRectsBeingDrawn:&rects count:&count];
    if (count <= 0 || count > 32 || !rects) { [self paintRect:dirty]; return; }
    for (NSInteger i = 0; i < count; ++i) {
        [NSGraphicsContext saveGraphicsState];
        NSRectClip(rects[i]);
        [self paintRect:rects[i]];
        [NSGraphicsContext restoreGraphicsState];
    }
}

- (void)paintRect:(NSRect)dirty {
    const NSRect b = self.bounds;
    sv::fill(dirty, sv::hex(0x16181C));   // the console's surface under the channels
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    [self rebuildStrips];
    const Project& p = *c.project;
    const SVStrip selected = c.selectedStrip;
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(0, 0, b.size.width - [self stripW] - 24, b.size.height));
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        if (i + 1 == _strips.size()) {
            [NSGraphicsContext restoreGraphicsState];
            sv::line(NSMakePoint(b.size.width - [self stripW] - 18.5, 8), NSMakePoint(b.size.width - [self stripW] - 18.5, b.size.height - 8), sv::hairline());
        }
        const CGFloat x = [self xForStrip:i];
        if (x + [self stripW] < 0 || x > b.size.width) continue;
        const SVStrip s = _strips[i];
        const StripGeom g = geometry(x, b.size.height, self.compact);
        if (!NSIntersectsRect(dirty, NSInsetRect(g.frame, -2, -2))) continue;
        const bool meterOnly = NSContainsRect(g.meterZone, dirty);
        std::string name;
        std::uint32_t color = 0;
        double gain = 0, pan = 0;
        bool mute = false, solo = false, hasPan = false;
        const std::vector<ProjectPluginSlot>* slots = nullptr;
        std::size_t sendCount = 0;
        std::string output = "Stereo Out";
        if (s.kind == SVStripKind::Track) {
            const auto& t = p.tracks[s.index];
            name = t.name; color = effectiveTrackColor(p, s.index); gain = t.gainDb; pan = t.pan; mute = t.mute; solo = t.solo;
            hasPan = true; slots = &t.pluginSlots; sendCount = t.sends.size();
            if (t.outputBus >= 0 && static_cast<std::size_t>(t.outputBus) < p.buses.size()) output = p.buses[static_cast<std::size_t>(t.outputBus)].name;
        } else if (s.kind == SVStripKind::Bus) {
            const auto& bus = p.buses[s.index];
            name = bus.name; color = bus.color ? bus.color : (bus.kind == ProjectBusKind::Group ? 0x8A8FB8U : 0x5FB3A8U);
            gain = bus.gainDb; mute = bus.mute; solo = bus.solo; slots = &bus.pluginSlots; sendCount = bus.sends.size();
            if (bus.outputBus >= 0 && static_cast<std::size_t>(bus.outputBus) < p.buses.size()) output = p.buses[static_cast<std::size_t>(bus.outputBus)].name;
        } else {
            name = "MASTER"; color = 0xD9824BU; gain = p.masterFaderDb; slots = &p.masterPluginSlots; output = "Device";
        }
        const bool isSel = selected == s;
        const bool master = s.kind == SVStripKind::Master;
        const CGFloat W = [self stripW];
        sv::brushedPanel(g.frame, isSel, master);
        if (!meterOnly) {
            // colour LED bar and the name plate
            NSColor* tint = sv::hex(color);
            sv::roundFill(NSMakeRect(x + 8, g.cap.origin.y + 3, W - 16, 5), 2.5, tint);
            sv::roundFill(NSMakeRect(x + 10, g.cap.origin.y + 3, W - 20, 2), 1.0, [tint blendedColorWithFraction:0.5 ofColor:[NSColor whiteColor]]);
            sv::sunkenWell(g.plate, 6.0);
            sv::engravedIn(sv::ns(name.empty() ? std::string("—") : name), NSMakeRect(g.plate.origin.x + 2, g.plate.origin.y + 3, g.plate.size.width - 4, 16),
                           sv::ui(11, true), master ? sv::lcdValue() : sv::hex(0xECE8DC), NSTextAlignmentCenter);
            // inserts
            sv::engraved(@"INSERTS", NSMakePoint(x + 8, g.inserts[0].origin.y - 13), sv::ui(sv::type::caption, true), sv::hex(0x8A8F9A));
            for (int k = 0; k < g.insertRows; ++k) {
                const NSRect r = g.inserts[k];
                sv::sunkenWell(r, 5.0);
                const bool have = slots && static_cast<std::size_t>(k) < slots->size();
                const CGFloat textY = r.origin.y + (r.size.height - 14.0) * 0.5;
                if (have) {
                    const auto& slot = (*slots)[static_cast<std::size_t>(k)];
                    [(slot.enabled ? sv::copper() : sv::hex(0x3A3D44)) setFill];
                    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(r.origin.x + 5, NSMidY(r) - 2.5, 5, 5)] fill];
                    if (slot.enabled) { [sv::copperDeep() setStroke]; [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(r.origin.x + 4, NSMidY(r) - 3.5, 7, 7)] stroke]; }
                    sv::textIn(sv::ns(pluginDisplayName(slot)), NSMakeRect(r.origin.x + 15, textY, r.size.width - 17, 14), sv::ui(sv::type::caption), slot.enabled ? sv::ink() : sv::hex(0x7A7E88));
                } else if (!slots || static_cast<std::size_t>(k) == slots->size()) {
                    sv::textIn(@"+", NSMakeRect(r.origin.x, textY, r.size.width, 14), sv::ui(sv::type::caption, true), sv::hex(0x4A4E57), NSTextAlignmentCenter);
                }
            }
            // sends
            if (g.sendRows) {
                sv::engraved(@"SENDS", NSMakePoint(x + 8, g.sends[0].origin.y - 13), sv::ui(sv::type::caption, true), sv::hex(0x8A8F9A));
                const std::vector<ProjectSend>* sends = s.kind == SVStripKind::Track ? &p.tracks[s.index].sends : (s.kind == SVStripKind::Bus ? &p.buses[s.index].sends : nullptr);
                for (int k = 0; k < g.sendRows; ++k) {
                    sv::sunkenWell(g.sends[k], 5.0);
                    if (sends && static_cast<std::size_t>(k) < sends->size()) {
                        const auto& send = (*sends)[static_cast<std::size_t>(k)];
                        NSString* to = send.destinationBus >= 0 && static_cast<std::size_t>(send.destinationBus) < p.buses.size() ? sv::ns(p.buses[static_cast<std::size_t>(send.destinationBus)].name) : @"?";
                        NSString* txt = [NSString stringWithFormat:@"%@  %+.0f", to, static_cast<double>(send.gainDb)];
                        sv::textIn(txt, NSMakeRect(g.sends[k].origin.x + 5, g.sends[k].origin.y + 1, g.sends[k].size.width - 8, 14), sv::ui(sv::type::caption), send.enabled ? sv::hex(0xC8CCD4) : sv::hex(0x7A7E88));
                    }
                }
            }
            // pan knob
            if (hasPan) {
                const NSPoint ctr = NSMakePoint(NSMidX(g.pan), NSMidY(g.pan));
                sv::consoleKnob(ctr, g.pan.size.width * 0.5 - 2.0, pan);
                NSString* ps = std::abs(pan) < 0.005 ? @"C" : [NSString stringWithFormat:@"%@%d", pan < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(pan) * 100))];
                sv::engravedIn(ps, NSMakeRect(x, NSMaxY(g.pan) + 4, W, 13), sv::mono(sv::type::caption), sv::hex(0xB4B9C4), NSTextAlignmentCenter);
            }
            // keys
            if (!master) {
                sv::consoleKey(g.mute, @"MUTE", mute, sv::muteTint());
                sv::consoleKey(g.solo, @"SOLO", solo, sv::soloTint());
            }
            // fader: the slot, the printed scale beside it, the cap
            const CGFloat gx = std::round(NSMidX(g.fader));
            const CGFloat capHalfH = self.compact ? 16.0 : 20.0, capHalfW = self.compact ? 10.0 : 12.0;
            sv::consoleFaderSlot(NSMakeRect(gx - 2, g.fader.origin.y - 2, 4, g.fader.size.height + 4));
            // scale: a tick every mark, the number only where there is room; 0 dB is the long bright one
            struct Mark { double db; const char* label; bool major; };
            static const Mark marks[] = {{12.0, "12", true}, {9.0, "", false}, {6.0, "6", true}, {3.0, "", false}, {0.0, "0", true}, {-3.0, "", false},
                                         {-6.0, "6", true}, {-9.0, "", false}, {-12.0, "12", true}, {-18.0, "", false}, {-24.0, "24", true}, {-30.0, "", false},
                                         {-40.0, "40", true}, {-50.0, "", false}, {-60.0, "60", true}, {-96.0, "\xe2\x88\x9e", true}};
            CGFloat lastLabelY = -1.0e9;
            const CGFloat tx = gx + capHalfW + 3.0;
            for (const Mark& m : marks) {
                const CGFloat ty = std::round(NSMaxY(g.fader) - g.fader.size.height * faderPositionForDb(m.db)) + 0.5;
                const bool zero = m.db == 0.0;
                const CGFloat len = zero ? 7.0 : (m.major ? 5.0 : 3.0);
                sv::line(NSMakePoint(tx, ty), NSMakePoint(tx + len, ty), zero ? sv::hex(0xC9CCD2) : (m.major ? sv::hex(0x7E838D) : sv::hex(0x585C64)));
                if (!m.major || std::abs(ty - lastLabelY) < 11.0) continue;
                lastLabelY = ty;
                sv::engraved([NSString stringWithUTF8String:m.label], NSMakePoint(tx + 9.0, ty - 6.0), sv::mono(sv::type::caption), zero ? sv::hex(0xD6D9DE) : sv::hex(0x8A8F9A));
            }
            const CGFloat capY = NSMaxY(g.fader) - g.fader.size.height * faderPositionForDb(gain);
            sv::consoleFaderCap(NSMakePoint(gx, capY), capHalfW, capHalfH);
            // meter window
            sv::sunkenWell(g.meterZone, 7.0, sv::hex(0x08090B));
            for (double db : {0.0, -6.0, -12.0, -24.0, -40.0}) {
                const CGFloat ty = std::round(NSMaxY(g.meter) - g.meter.size.height * sv::meter::position(db)) + 0.5;
                sv::line(NSMakePoint(NSMaxX(g.meterZone) + 1, ty), NSMakePoint(NSMaxX(g.meterZone) + 3, ty), sv::hex(0x6A6E78));
            }
        }
        // Meter: clip lamp + two LED bars (the master/track level from the shared meter bank)
        const StereoMeterDisplay md = [c meterDisplayForStrip:s];
        sv::meter::drawClipLamp(g.lamp, md.clip());
        for (int ch = 0; ch < 2; ++ch) {
            const MeterChannelDisplay& m = ch == 0 ? md.left : md.right;
            sv::meter::drawBar(NSMakeRect(g.meter.origin.x + ch * 14, g.meter.origin.y, 10, g.meter.size.height),
                               true, m.levelDb, m.holdDb, m.clip, true);
        }
        if (!meterOnly) {
            sv::sunkenWell(g.readout, 6.0, sv::hex(0x0F0E0C));
            sv::textIn(gain <= -95.9 ? @"-∞ dB" : [NSString stringWithFormat:@"%+.1f dB", gain],
                       NSMakeRect(g.readout.origin.x, g.readout.origin.y + 3, g.readout.size.width, 14), sv::mono(sv::type::caption, true), sv::lcdValue(), NSTextAlignmentCenter);
            sv::engravedIn(sv::ns("→ " + output), g.output, sv::ui(sv::type::caption), sv::hex(0x8A8F9A), NSTextAlignmentCenter);
        }
    }
}

- (long)stripAt:(NSPoint)p {
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        const CGFloat x = [self xForStrip:i];
        if (p.x >= x && p.x <= x + [self stripW]) {
            if (i + 1 != _strips.size() && p.x > self.bounds.size.width - [self stripW] - 24) continue;
            return static_cast<long>(i);
        }
    }
    return -1;
}

- (double)stripGain:(SVStrip)s {
    const Project* p = self.controller.project;
    if (s.kind == SVStripKind::Track) return p->tracks[s.index].gainDb;
    if (s.kind == SVStripKind::Bus) return p->buses[s.index].gainDb;
    return p->masterFaderDb;
}

- (void)mouseDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (!c.project) return;
    [self rebuildStrips];
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    const long idx = [self stripAt:pt];
    if (idx < 0) return;
    const SVStrip s = _strips[static_cast<std::size_t>(idx)];
    [c selectStrip:s];
    const StripGeom g = geometry([self xForStrip:static_cast<std::size_t>(idx)], self.bounds.size.height, self.compact);
    if (NSPointInRect(pt, g.meterZone)) {   // click: clear this strip's clip lamp; Option-click: all strips
        [c resetMetersForStrip:s all:(event.modifierFlags & NSEventModifierFlagOption) != 0];
        return;
    }
    for (int k = 0; k < kInsertRows; ++k) {
        if (!NSPointInRect(pt, g.inserts[k])) continue;
        const std::vector<ProjectPluginSlot>* slots = s.kind == SVStripKind::Track ? &c.project->tracks[s.index].pluginSlots
                                                   : s.kind == SVStripKind::Bus ? &c.project->buses[s.index].pluginSlots
                                                                                : &c.project->masterPluginSlots;
        if (static_cast<std::size_t>(k) < slots->size()) [c stripInsertClicked:s slot:static_cast<std::size_t>(k)];
        else if (NSMenu* menu = [c insertMenuForStrip:s]) [NSMenu popUpContextMenu:menu withEvent:event forView:self];
        [self setNeedsDisplay:YES];
        return;
    }
    if (s.kind != SVStripKind::Master && NSPointInRect(pt, g.mute)) { [c toggleStripMute:s]; [self setNeedsDisplay:YES]; return; }
    if (s.kind != SVStripKind::Master && NSPointInRect(pt, g.solo)) { [c toggleStripSolo:s]; [self setNeedsDisplay:YES]; return; }
    if (s.kind == SVStripKind::Track && NSPointInRect(pt, g.pan)) {
        if (event.clickCount >= 2) { [c setStrip:s pan:0.0]; [self setNeedsDisplay:YES]; return; }
        _dragWhat = 2; _dragStrip = s; _dragStart = pt; _dragStartValue = c.project->tracks[s.index].pan;
        return;
    }
    if (NSPointInRect(pt, NSInsetRect(g.fader, -12, -10))) {
        if (event.clickCount >= 2) { [c setStrip:s gainDb:0.0]; [self setNeedsDisplay:YES]; return; }
        _dragWhat = 1; _dragStrip = s; _dragStart = pt; _dragStartValue = faderPositionForDb([self stripGain:s]);
        return;
    }
    _dragWhat = 0;
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent*)event {
    if (_dragWhat == 0) return;
    SilvetonController* c = self.controller;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (!_gesture) { [c beginGesture:_dragWhat == 1 ? @"Fader" : @"Pan"]; _gesture = YES; }
    const bool fine = (event.modifierFlags & NSEventModifierFlagShift) != 0;
    if (_dragWhat == 1) {
        const StripGeom g = geometry(0, self.bounds.size.height, self.compact);
        const double scale = fine ? 0.2 : 1.0;
        const double pos = sv::clamp01(_dragStartValue - (pt.y - _dragStart.y) / g.fader.size.height * scale);
        [c setStrip:_dragStrip gainDb:dbForFaderPosition(pos)];
    } else {
        const double v = std::max(-1.0, std::min(1.0, _dragStartValue - (pt.y - _dragStart.y) / (fine ? 600.0 : 120.0)));
        [c setStrip:_dragStrip pan:v];
    }
    [self invalidateStrip:_dragStrip];   // only this channel is painted again (the whole console at 60 Hz starved the audio threads)
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_gesture) { [self.controller endGesture]; _gesture = NO; }
    _dragWhat = 0;
}

- (NSMenu*)menuForEvent:(NSEvent*)event {
    [self rebuildStrips];
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    const long idx = [self stripAt:pt];
    if (idx < 0) return nil;
    const SVStrip s = _strips[static_cast<std::size_t>(idx)];
    [self.controller selectStrip:s];
    return [self.controller contextMenuForStrip:s];
}

- (void)scrollWheel:(NSEvent*)event {
    double d = event.scrollingDeltaX;
    if (std::abs(d) < 0.001) d = event.scrollingDeltaY;
    if (!event.hasPreciseScrollingDeltas) d *= 12;
    const double maxScroll = std::max(0.0, static_cast<double>(_strips.size()) * ([self stripW] + kStripGap) - (self.bounds.size.width - [self stripW] - 40));
    self.scrollX = std::max(0.0, std::min(maxScroll, self.scrollX - d));
    [self setNeedsDisplay:YES];
}
@end

// ======================================================= Native editor ==
@interface SVParamSlider : NSSlider
@property(nonatomic, assign) std::uint32_t paramId;
@property(nonatomic, weak) id editorOwner;
@end

@interface SilvetonNativeEditor ()
@property(nonatomic, copy) SilvetonNativeResolver resolver;
@property(nonatomic, copy) NSString* editorKey;
@property(nonatomic, copy) NSString* classId;
- (void)beginParam:(std::uint32_t)paramId;
- (void)endParam:(std::uint32_t)paramId;
- (void)resetParam:(std::uint32_t)paramId;
@end

@implementation SVParamSlider
- (void)mouseDown:(NSEvent*)event {
    SilvetonNativeEditor* ed = self.editorOwner;
    if (event.clickCount >= 2) { [ed resetParam:self.paramId]; return; }
    [ed beginParam:self.paramId];
    [super mouseDown:event];
    [ed endParam:self.paramId];
}
@end

static NSMutableDictionary<NSString*, SilvetonNativeEditor*>* gNativeEditors = nil;

@implementation SilvetonNativeEditor {
    NSMutableArray* _controls;     // index = param id
    NSMutableArray<NSTextField*>* _values;
    NSTextField* _meterLabel;
}

+ (void)openWithResolver:(SilvetonNativeResolver)resolver title:(NSString*)title key:(NSString*)key {
    if (!gNativeEditors) gNativeEditors = [NSMutableDictionary dictionary];
    NativePlugin* plugin = resolver ? resolver() : nullptr;
    if (!plugin) return;
    SilvetonNativeEditor* existing = gNativeEditors[key];
    if (existing && [existing.classId isEqualToString:sv::ns(plugin->classId())]) { [existing makeKeyAndOrderFront:nil]; return; }
    if (existing) { [existing close]; [gNativeEditors removeObjectForKey:key]; }
    const auto& params = plugin->parameters();
    const CGFloat rowH = 30, width = 440;
    const CGFloat height = 70 + rowH * static_cast<CGFloat>(params.size()) + 20;
    SilvetonNativeEditor* ed = [[SilvetonNativeEditor alloc] initWithContentRect:NSMakeRect(200, 200, width, height)
                                                                     styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskUtilityWindow
                                                                       backing:NSBackingStoreBuffered defer:NO];
    ed.resolver = resolver;
    ed.editorKey = key;
    ed.classId = sv::ns(plugin->classId());
    ed.title = title;
    ed.releasedWhenClosed = NO;
    ed.backgroundColor = sv::panel();
    ed.hidesOnDeactivate = NO;
    [ed buildFor:plugin width:width height:height rowHeight:rowH];
    gNativeEditors[key] = ed;
    [ed center];
    [ed makeKeyAndOrderFront:nil];
}

- (NSTextField*)labelWith:(NSString*)s frame:(NSRect)f font:(NSFont*)font color:(NSColor*)color align:(NSTextAlignment)a {
    NSTextField* l = [[NSTextField alloc] initWithFrame:f];
    l.stringValue = s; l.editable = NO; l.selectable = NO; l.bezeled = NO; l.drawsBackground = NO;
    l.font = font; l.textColor = color; l.alignment = a;
    return l;
}

- (void)buildFor:(NativePlugin*)plugin width:(CGFloat)width height:(CGFloat)height rowHeight:(CGFloat)rowH {
    NSView* root = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, width, height)];
    self.contentView = root;
    _controls = [NSMutableArray array];
    _values = [NSMutableArray array];
    NSString* header = sv::ns(plugin->info().name).uppercaseString;
    [root addSubview:[self labelWith:header frame:NSMakeRect(18, height - 40, width - 36 - 176, 20) font:sv::ui(13, true) color:sv::copper() align:NSTextAlignmentLeft]];
    [root addSubview:[self labelWith:@"SILVETON NATIVE" frame:NSMakeRect(18, height - 56, 200, 14) font:sv::ui(10, true) color:sv::inkFaint() align:NSTextAlignmentLeft]];
    _meterLabel = [self labelWith:@"" frame:NSMakeRect(width - 190, height - 40, 172, 18) font:sv::mono(11, true) color:sv::amber() align:NSTextAlignmentRight];
    [root addSubview:_meterLabel];
    const auto& params = plugin->parameters();
    for (std::size_t i = 0; i < params.size(); ++i) {
        const auto& prm = params[i];
        const CGFloat y = height - 80 - static_cast<CGFloat>(i) * rowH;
        [root addSubview:[self labelWith:sv::ns(prm.name) frame:NSMakeRect(18, y, 128, 18) font:sv::ui(12) color:sv::ink() align:NSTextAlignmentLeft]];
        NSControl* ctl = nil;
        if (prm.scale == NativeParamScale::Toggle) {
            NSButton* b = [[NSButton alloc] initWithFrame:NSMakeRect(156, y - 2, 180, 22)];
            [b setButtonType:NSButtonTypeSwitch];
            b.title = @"";
            b.target = self; b.action = @selector(toggleChanged:); b.tag = static_cast<NSInteger>(prm.id);
            ctl = b;
        } else if (prm.scale == NativeParamScale::Choice) {
            NSPopUpButton* pop = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(152, y - 3, 190, 24) pullsDown:NO];
            for (const auto& ch : prm.choices) [pop addItemWithTitle:sv::ns(ch)];
            pop.target = self; pop.action = @selector(choiceChanged:); pop.tag = static_cast<NSInteger>(prm.id);
            pop.font = sv::ui(11);
            ctl = pop;
        } else {
            SVParamSlider* s = [[SVParamSlider alloc] initWithFrame:NSMakeRect(154, y - 2, 190, 22)];
            s.minValue = 0; s.maxValue = 1; s.continuous = YES;
            s.paramId = prm.id; s.editorOwner = self;
            s.target = self; s.action = @selector(sliderChanged:); s.tag = static_cast<NSInteger>(prm.id);
            ctl = s;
        }
        [root addSubview:ctl];
        [_controls addObject:ctl];
        NSTextField* v = [self labelWith:@"" frame:NSMakeRect(350, y, width - 366, 18) font:sv::mono(11) color:sv::inkDim() align:NSTextAlignmentRight];
        [root addSubview:v];
        [_values addObject:v];
    }
    [self syncFrom:plugin];
}

- (void)syncFrom:(NativePlugin*)plugin {
    const auto& params = plugin->parameters();
    for (std::size_t i = 0; i < params.size() && i < _controls.count; ++i) {
        id ctl = _controls[i];
        const auto id = static_cast<std::uint32_t>(i);
        if ([ctl isKindOfClass:[NSPopUpButton class]]) [(NSPopUpButton*)ctl selectItemAtIndex:static_cast<NSInteger>(plugin->plainValue(id) - params[i].minValue)];
        else if ([ctl isKindOfClass:[SVParamSlider class]]) { if (![(NSSlider*)ctl isHighlighted]) [(NSSlider*)ctl setDoubleValue:plugin->normalizedValue(id)]; }
        else if ([ctl isKindOfClass:[NSButton class]]) [(NSButton*)ctl setState:plugin->plainValue(id) >= 0.5 ? NSControlStateValueOn : NSControlStateValueOff];
        _values[i].stringValue = sv::ns(plugin->formatValue(id));
    }
    const float gr = plugin->meter(0);
    if (plugin->classId() == "silveton.press" || plugin->classId() == "silveton.ceiling")
        _meterLabel.stringValue = [NSString stringWithFormat:@"GR %.1f dB", gr];
    else if (plugin->classId() == "silveton.gate")
        _meterLabel.stringValue = [NSString stringWithFormat:@"GAIN %.1f dB", gr];
}

- (NativePlugin*)plugin {
    NativePlugin* p = self.resolver ? self.resolver() : nullptr;
    if (p && ![sv::ns(p->classId()) isEqualToString:self.classId]) return nullptr;
    return p;
}
- (void)beginParam:(std::uint32_t)paramId { if (auto* p = [self plugin]) p->beginEdit(paramId); }
- (void)endParam:(std::uint32_t)paramId { if (auto* p = [self plugin]) p->endEdit(paramId); }
- (void)resetParam:(std::uint32_t)paramId {
    if (auto* p = [self plugin]) {
        const auto& prm = p->parameters()[paramId];
        p->beginEdit(paramId); p->setFromEditor(paramId, prm.defaultValue); p->endEdit(paramId);
        [self syncFrom:p];
    }
}
- (void)sliderChanged:(NSSlider*)sender {
    NativePlugin* p = [self plugin];
    if (!p) return;
    const auto id = static_cast<std::uint32_t>(sender.tag);
    p->setFromEditor(id, NativePlugin::toPlain(p->parameters()[id], sender.doubleValue));
    _values[id].stringValue = sv::ns(p->formatValue(id));
}
- (void)choiceChanged:(NSPopUpButton*)sender {
    NativePlugin* p = [self plugin];
    if (!p) return;
    const auto id = static_cast<std::uint32_t>(sender.tag);
    p->beginEdit(id); p->setFromEditor(id, p->parameters()[id].minValue + sender.indexOfSelectedItem); p->endEdit(id);
    _values[id].stringValue = sv::ns(p->formatValue(id));
}
- (void)toggleChanged:(NSButton*)sender {
    NativePlugin* p = [self plugin];
    if (!p) return;
    const auto id = static_cast<std::uint32_t>(sender.tag);
    p->beginEdit(id); p->setFromEditor(id, sender.state == NSControlStateValueOn ? 1.0 : 0.0); p->endEdit(id);
    _values[id].stringValue = sv::ns(p->formatValue(id));
}

+ (void)refreshAll {
    if (!gNativeEditors) return;
    NSMutableArray<NSString*>* dead = [NSMutableArray array];
    for (NSString* key in gNativeEditors) {
        SilvetonNativeEditor* ed = gNativeEditors[key];
        if (!ed.isVisible) { [dead addObject:key]; continue; }
        NativePlugin* p = [ed plugin];
        if (!p) { [ed close]; [dead addObject:key]; continue; }
        [ed syncFrom:p];
    }
    for (NSString* key in dead) [gNativeEditors removeObjectForKey:key];
}
+ (void)closeAll {
    if (!gNativeEditors) return;
    for (NSString* key in gNativeEditors) [gNativeEditors[key] close];
    [gNativeEditors removeAllObjects];
}
@end
