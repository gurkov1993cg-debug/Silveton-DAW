#import "SilvetonViews.h"
#include "SilvetonMeterDraw.h"
#include "SilvetonTheme.h"

#include "silveton/Arrangement.h"
#include "silveton/NativePlugins.h"
#include "silveton/UiModel.h"

#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

using namespace silveton;

// ============================================================== Console ==
namespace {
constexpr CGFloat kStripW = 112.0;
constexpr CGFloat kStripGap = 8.0;
constexpr int kInsertRows = 6;

struct StripGeom {
    NSRect frame, cap, inserts[kInsertRows], sends, pan, mute, solo, fader, meter, lamp, meterZone, readout, output;
};

StripGeom geometry(CGFloat x, CGFloat height) {
    StripGeom g;
    g.frame = NSMakeRect(x, 8, kStripW, height - 16);
    g.cap = NSMakeRect(x, 8, kStripW, 36);
    for (int i = 0; i < kInsertRows; ++i) g.inserts[i] = NSMakeRect(x + 6, 52 + i * 22, kStripW - 12, 20);
    g.sends = NSMakeRect(x + 6, 52 + kInsertRows * 22 + 2, kStripW - 12, 18);
    g.pan = NSMakeRect(x + kStripW / 2 - 17, 52 + kInsertRows * 22 + 26, 34, 34);
    const CGFloat btnY = g.pan.origin.y + 34 + 20;          // room for the pan read-out under the knob
    g.mute = NSMakeRect(x + 8, btnY, 44, 20);
    g.solo = NSMakeRect(x + kStripW - 52, btnY, 44, 20);
    const CGFloat faderTop = btnY + 32;
    const CGFloat faderBottom = height - 72;
    g.fader = NSMakeRect(x + 28, faderTop, 20, std::max<CGFloat>(40, faderBottom - faderTop));
    const CGFloat meterH = std::max<CGFloat>(40, faderBottom - faderTop);
    g.meter = NSMakeRect(x + 66, faderTop, 16, meterH);
    g.lamp = NSMakeRect(x + 66, faderTop - 9, 16, 5);                         // clip lamp above the bars
    g.meterZone = NSMakeRect(x + 64, faderTop - 10, 20, meterH + 12);         // the part the 30 Hz timer repaints
    g.readout = NSMakeRect(x + 6, faderBottom + 12, kStripW - 12, 18);   // below the lowest fader-cap position
    g.output = NSMakeRect(x + 6, faderBottom + 34, kStripW - 12, 18);
    return g;
}

std::string pluginDisplayName(const ProjectPluginSlot& slot) {
    if (isNativeModulePath(slot.modulePath))
        for (const auto& i : nativePluginCatalog()) if (i.classId == slot.classId) return i.name;
    std::string n = slot.modulePath;
    const auto s = n.find_last_of('/');
    if (s != std::string::npos) n = n.substr(s + 1);
    const auto d = n.find_last_of('.');
    if (d != std::string::npos) n = n.substr(0, d);
    return n.empty() ? slot.classId : n;
}
} // namespace

@implementation SilvetonConsoleView {
    std::vector<SVStrip> _strips;
    SVStrip _dragStrip;
    int _dragWhat;   // 1 fader, 2 pan
    double _dragStartValue;
    NSPoint _dragStart;
    BOOL _gesture;
    std::vector<std::uint32_t> _meterSig;   // what each strip's meter looked like when last painted
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }

- (void)rebuildStrips {
    _strips.clear();
    const Project* p = self.controller.project;
    if (!p) return;
    for (std::size_t i = 0; i < p->tracks.size(); ++i) _strips.push_back({SVStripKind::Track, i});
    for (std::size_t i = 0; i < p->buses.size(); ++i) _strips.push_back({SVStripKind::Bus, i});
    _strips.push_back({SVStripKind::Master, 0});
}

- (CGFloat)xForStrip:(std::size_t)i {
    // Master is pinned to the right edge.
    if (i + 1 == _strips.size()) return self.bounds.size.width - kStripW - 12;
    return 12 + static_cast<CGFloat>(i) * (kStripW + kStripGap) - self.scrollX;
}

// The 30 Hz timer invalidates only thin meter columns. Each invalid rectangle
// is painted on its own, and a rectangle that lies inside a meter column skips
// all the static text/controls of that strip (see `meterOnly` below).
- (void)tickMeters {
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    [self rebuildStrips];
    if (_meterSig.size() != _strips.size()) _meterSig.assign(_strips.size(), 0U);
    const NSRect b = self.bounds;
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        const CGFloat x = [self xForStrip:i];
        if (x + kStripW < 0 || x > b.size.width) continue;
        const StripGeom g = geometry(x, b.size.height);
        const std::uint32_t sig = sv::meter::signature([c meterDisplayForStrip:_strips[i]], g.meter.size.height, true);
        if (sig == _meterSig[i]) continue;
        _meterSig[i] = sig;
        [self setNeedsDisplayInRect:g.meterZone];
    }
}

- (void)drawRect:(NSRect)dirty {
    const NSRect* rects = nullptr;
    NSInteger count = 0;
    [self getRectsBeingDrawn:&rects count:&count];
    if (count <= 0 || count > 32 || !rects) { [self paintRect:dirty]; return; }
    for (NSInteger i = 0; i < count; ++i) {
        [NSGraphicsContext saveGraphicsState];
        NSRectClip(rects[i]);
        [self paintRect:rects[i]];
        [NSGraphicsContext restoreGraphicsState];
    }
}

- (void)paintRect:(NSRect)dirty {
    const NSRect b = self.bounds;
    sv::fill(dirty, sv::canvas());
    SilvetonController* c = self.controller;
    if (!c || !c.project) return;
    [self rebuildStrips];
    const Project& p = *c.project;
    const SVStrip selected = c.selectedStrip;
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(0, 0, b.size.width - kStripW - 24, b.size.height));
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        if (i + 1 == _strips.size()) {
            [NSGraphicsContext restoreGraphicsState];
            sv::line(NSMakePoint(b.size.width - kStripW - 18.5, 8), NSMakePoint(b.size.width - kStripW - 18.5, b.size.height - 8), sv::hairline());
        }
        const CGFloat x = [self xForStrip:i];
        if (x + kStripW < 0 || x > b.size.width) continue;
        const SVStrip s = _strips[i];
        const StripGeom g = geometry(x, b.size.height);
        if (!NSIntersectsRect(dirty, NSInsetRect(g.frame, -2, -2))) continue;
        const bool meterOnly = NSContainsRect(g.meterZone, dirty);
        std::string name;
        std::uint32_t color = 0;
        double gain = 0, pan = 0;
        bool mute = false, solo = false, hasPan = false;
        const std::vector<ProjectPluginSlot>* slots = nullptr;
        std::size_t sendCount = 0;
        std::string output = "Stereo Out";
        if (s.kind == SVStripKind::Track) {
            const auto& t = p.tracks[s.index];
            name = t.name; color = effectiveTrackColor(p, s.index); gain = t.gainDb; pan = t.pan; mute = t.mute; solo = t.solo;
            hasPan = true; slots = &t.pluginSlots; sendCount = t.sends.size();
            if (t.outputBus >= 0 && static_cast<std::size_t>(t.outputBus) < p.buses.size()) output = p.buses[static_cast<std::size_t>(t.outputBus)].name;
        } else if (s.kind == SVStripKind::Bus) {
            const auto& bus = p.buses[s.index];
            name = bus.name; color = bus.color ? bus.color : (bus.kind == ProjectBusKind::Group ? 0x8A8FB8U : 0x5FB3A8U);
            gain = bus.gainDb; mute = bus.mute; solo = bus.solo; slots = &bus.pluginSlots; sendCount = bus.sends.size();
            if (bus.outputBus >= 0 && static_cast<std::size_t>(bus.outputBus) < p.buses.size()) output = p.buses[static_cast<std::size_t>(bus.outputBus)].name;
        } else {
            name = "MASTER"; color = 0xD9824BU; gain = p.masterFaderDb; slots = &p.masterPluginSlots; output = "Device";
        }
        const bool isSel = selected == s;
        sv::roundFill(g.frame, 10, isSel ? sv::raised() : sv::panel());
        sv::roundStroke(g.frame, 10, isSel ? sv::copper() : sv::hairline(), isSel ? 1.5 : 1.0);
        if (!meterOnly) {
            sv::roundFill(NSMakeRect(g.cap.origin.x, g.cap.origin.y, g.cap.size.width, 5), 3, sv::hex(color));
            sv::textIn(sv::ns(name.empty() ? std::string("—") : name), NSMakeRect(x + 6, 14, kStripW - 12, 18), sv::ui(12, true), sv::ink(), NSTextAlignmentCenter);
            if (s.kind == SVStripKind::Bus)
                sv::textIn(p.buses[s.index].kind == ProjectBusKind::Group ? @"GROUP" : @"FX", NSMakeRect(x, 31, kStripW, 12), sv::ui(10, true), sv::inkFaint(), NSTextAlignmentCenter);
            for (int k = 0; k < kInsertRows; ++k) {
                const NSRect r = g.inserts[k];
                const bool have = slots && static_cast<std::size_t>(k) < slots->size();
                sv::roundFill(r, 4, have ? sv::raisedHi() : sv::hex(0x18171B));
                if (have) {
                    const auto& slot = (*slots)[static_cast<std::size_t>(k)];
                    sv::fill(NSMakeRect(r.origin.x, r.origin.y + 3, 3, r.size.height - 6), slot.enabled ? sv::sage() : sv::inkFaint());
                    sv::textIn(sv::ns(pluginDisplayName(slot)), NSMakeRect(r.origin.x + 8, r.origin.y + 3, r.size.width - 10, 15), sv::ui(11), slot.enabled ? sv::ink() : sv::inkFaint());
                } else if (!slots || static_cast<std::size_t>(k) == slots->size()) {
                    sv::textIn(@"+ insert", NSMakeRect(r.origin.x, r.origin.y + 3, r.size.width, 15), sv::ui(11), sv::inkFaint(), NSTextAlignmentCenter);
                }
            }
            sv::textIn(sendCount ? [NSString stringWithFormat:@"%lu send%@", (unsigned long)sendCount, sendCount == 1 ? @"" : @"s"] : @"no sends",
                       NSMakeRect(g.sends.origin.x, g.sends.origin.y + 2, g.sends.size.width, 15), sv::ui(11), sv::inkDim(), NSTextAlignmentCenter);
            if (hasPan) {
                sv::roundFill(g.pan, 17, sv::hex(0x121114));
                NSBezierPath* arc = [NSBezierPath bezierPath];
                const NSPoint ctr = NSMakePoint(NSMidX(g.pan), NSMidY(g.pan));
                // Flipped view: angles measured clockwise from +x in screen space.
                const CGFloat a0 = 270.0, a1 = 270.0 + pan * 135.0;
                [arc appendBezierPathWithArcWithCenter:ctr radius:13 startAngle:std::min(a0, a1) endAngle:std::max(a0, a1)];
                arc.lineWidth = 3;
                [sv::copper() setStroke];
                [arc stroke];
                const double ang = (270.0 + pan * 135.0) * M_PI / 180.0;
                sv::line(ctr, NSMakePoint(ctr.x + 12 * std::cos(ang), ctr.y + 12 * std::sin(ang)), sv::ink(), 2);
                NSString* ps = std::abs(pan) < 0.005 ? @"C" : [NSString stringWithFormat:@"%@%d", pan < 0 ? @"L" : @"R", static_cast<int>(std::lround(std::abs(pan) * 100))];
                sv::textIn(ps, NSMakeRect(x, NSMaxY(g.pan) + 2, kStripW, 15), sv::mono(11), sv::inkDim(), NSTextAlignmentCenter);
            }
            if (s.kind != SVStripKind::Master) {
                sv::pill(g.mute, @"MUTE", mute, sv::muteTint());
                sv::pill(g.solo, @"SOLO", solo, sv::soloTint());
            }
            // Fader: groove + dB ticks + cap
            const NSRect groove = NSMakeRect(NSMidX(g.fader) - 2, g.fader.origin.y, 4, g.fader.size.height);
            sv::roundFill(groove, 2, sv::hex(0x0E0D10));
            for (double db : {12.0, 6.0, 0.0, -6.0, -12.0, -24.0, -40.0, -60.0}) {
                const CGFloat ty = NSMaxY(g.fader) - g.fader.size.height * faderPositionForDb(db);
                sv::line(NSMakePoint(g.fader.origin.x - 6, ty), NSMakePoint(g.fader.origin.x - 1, ty), db == 0.0 ? sv::inkDim() : sv::inkFaint());
            }
            const CGFloat capY = NSMaxY(g.fader) - g.fader.size.height * faderPositionForDb(gain);
            const NSRect cap = NSMakeRect(g.fader.origin.x - 6, capY - 9, 32, 18);
            sv::roundFill(cap, 4, sv::raisedHi());
            sv::roundStroke(cap, 4, sv::hairline());
            sv::fill(NSMakeRect(cap.origin.x + 4, capY - 0.5, cap.size.width - 8, 1.5), sv::copper());
            // dB scale to the right of the meter, on the same positions as the fader scale
            CGFloat lastLabelY = -1.0e9;
            for (double db : {6.0, 0.0, -6.0, -12.0, -24.0, -40.0, -60.0}) {
                const CGFloat ty = std::round(NSMaxY(g.meter) - g.meter.size.height * sv::meter::position(db));
                NSColor* tone = db == 0.0 ? sv::inkDim() : sv::inkFaint();
                sv::line(NSMakePoint(g.meter.origin.x + 19, ty + 0.5), NSMakePoint(g.meter.origin.x + 22, ty + 0.5), tone);
                if (ty - lastLabelY < 12.0) continue;
                lastLabelY = ty;
                sv::textIn(sv::meter::dbLabel(db), NSMakeRect(g.meter.origin.x + 24, ty - 6, 20, 12), sv::mono(10), tone, NSTextAlignmentLeft);
            }
        }
        // Meter: clip lamp + two LED bars (the master/track level from the shared meter bank)
        const StereoMeterDisplay md = [c meterDisplayForStrip:s];
        sv::meter::drawClipLamp(g.lamp, md.clip());
        for (int ch = 0; ch < 2; ++ch) {
            const MeterChannelDisplay& m = ch == 0 ? md.left : md.right;
            sv::meter::drawBar(NSMakeRect(g.meter.origin.x + ch * 9, g.meter.origin.y, 7, g.meter.size.height),
                               true, m.levelDb, m.holdDb, m.clip, true);
        }
        if (!meterOnly) {
            sv::textIn(gain <= -95.9 ? @"-∞ dB" : [NSString stringWithFormat:@"%+.1f dB", gain], g.readout, sv::mono(11, true), sv::ink(), NSTextAlignmentCenter);
            sv::textIn(sv::ns("→ " + output), g.output, sv::ui(10), sv::inkDim(), NSTextAlignmentCenter);
        }
    }
}

- (long)stripAt:(NSPoint)p {
    for (std::size_t i = 0; i < _strips.size(); ++i) {
        const CGFloat x = [self xForStrip:i];
        if (p.x >= x && p.x <= x + kStripW) {
            if (i + 1 != _strips.size() && p.x > self.bounds.size.width - kStripW - 24) continue;
            return static_cast<long>(i);
        }
    }
    return -1;
}

- (double)stripGain:(SVStrip)s {
    const Project* p = self.controller.project;
    if (s.kind == SVStripKind::Track) return p->tracks[s.index].gainDb;
    if (s.kind == SVStripKind::Bus) return p->buses[s.index].gainDb;
    return p->masterFaderDb;
}

- (void)mouseDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (!c.project) return;
    [self rebuildStrips];
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    const long idx = [self stripAt:pt];
    if (idx < 0) return;
    const SVStrip s = _strips[static_cast<std::size_t>(idx)];
    [c selectStrip:s];
    const StripGeom g = geometry([self xForStrip:static_cast<std::size_t>(idx)], self.bounds.size.height);
    if (NSPointInRect(pt, g.meterZone)) {   // click: clear this strip's clip lamp; Option-click: all strips
        [c resetMetersForStrip:s all:(event.modifierFlags & NSEventModifierFlagOption) != 0];
        return;
    }
    for (int k = 0; k < kInsertRows; ++k) {
        if (!NSPointInRect(pt, g.inserts[k])) continue;
        const std::vector<ProjectPluginSlot>* slots = s.kind == SVStripKind::Track ? &c.project->tracks[s.index].pluginSlots
                                                   : s.kind == SVStripKind::Bus ? &c.project->buses[s.index].pluginSlots
                                                                                : &c.project->masterPluginSlots;
        if (static_cast<std::size_t>(k) < slots->size()) [c stripInsertClicked:s slot:static_cast<std::size_t>(k)];
        else if (NSMenu* menu = [c insertMenuForStrip:s]) [NSMenu popUpContextMenu:menu withEvent:event forView:self];
        [self setNeedsDisplay:YES];
        return;
    }
    if (s.kind != SVStripKind::Master && NSPointInRect(pt, g.mute)) { [c toggleStripMute:s]; [self setNeedsDisplay:YES]; return; }
    if (s.kind != SVStripKind::Master && NSPointInRect(pt, g.solo)) { [c toggleStripSolo:s]; [self setNeedsDisplay:YES]; return; }
    if (s.kind == SVStripKind::Track && NSPointInRect(pt, g.pan)) {
        if (event.clickCount >= 2) { [c setStrip:s pan:0.0]; [self setNeedsDisplay:YES]; return; }
        _dragWhat = 2; _dragStrip = s; _dragStart = pt; _dragStartValue = c.project->tracks[s.index].pan;
        return;
    }
    if (NSPointInRect(pt, NSInsetRect(g.fader, -12, -10))) {
        if (event.clickCount >= 2) { [c setStrip:s gainDb:0.0]; [self setNeedsDisplay:YES]; return; }
        _dragWhat = 1; _dragStrip = s; _dragStart = pt; _dragStartValue = faderPositionForDb([self stripGain:s]);
        return;
    }
    _dragWhat = 0;
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent*)event {
    if (_dragWhat == 0) return;
    SilvetonController* c = self.controller;
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    if (!_gesture) { [c beginGesture:_dragWhat == 1 ? @"Fader" : @"Pan"]; _gesture = YES; }
    const bool fine = (event.modifierFlags & NSEventModifierFlagShift) != 0;
    if (_dragWhat == 1) {
        const StripGeom g = geometry(0, self.bounds.size.height);
        const double scale = fine ? 0.2 : 1.0;
        const double pos = sv::clamp01(_dragStartValue - (pt.y - _dragStart.y) / g.fader.size.height * scale);
        [c setStrip:_dragStrip gainDb:dbForFaderPosition(pos)];
    } else {
        const double v = std::max(-1.0, std::min(1.0, _dragStartValue - (pt.y - _dragStart.y) / (fine ? 600.0 : 120.0)));
        [c setStrip:_dragStrip pan:v];
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_gesture) { [self.controller endGesture]; _gesture = NO; }
    _dragWhat = 0;
}

- (NSMenu*)menuForEvent:(NSEvent*)event {
    [self rebuildStrips];
    const NSPoint pt = [self convertPoint:event.locationInWindow fromView:nil];
    const long idx = [self stripAt:pt];
    if (idx < 0) return nil;
    const SVStrip s = _strips[static_cast<std::size_t>(idx)];
    [self.controller selectStrip:s];
    return [self.controller contextMenuForStrip:s];
}

- (void)scrollWheel:(NSEvent*)event {
    double d = event.scrollingDeltaX;
    if (std::abs(d) < 0.001) d = event.scrollingDeltaY;
    if (!event.hasPreciseScrollingDeltas) d *= 12;
    const double maxScroll = std::max(0.0, static_cast<double>(_strips.size()) * (kStripW + kStripGap) - (self.bounds.size.width - kStripW - 40));
    self.scrollX = std::max(0.0, std::min(maxScroll, self.scrollX - d));
    [self setNeedsDisplay:YES];
}
@end

// ============================================================ Note grid ==
namespace {
constexpr CGFloat kKeysW = 56.0;
constexpr CGFloat kGridRulerH = 26.0;
constexpr CGFloat kVelH = 104.0;
constexpr CGFloat kPitchH = 14.0;
bool isBlack(int pitch) { const int pc = pitch % 12; return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10; }
const char* kNoteNames[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
}

@implementation SilvetonNoteGridView {
    int _mode;   // 0 none, 1 move, 2 resize, 3 velocity
    double _grabQ;
    int _grabPitch;
    BOOL _gesture;
}
- (instancetype)initWithFrame:(NSRect)frame {
    if ((self = [super initWithFrame:frame])) { _quarterWidth = 96.0; _scrollPitch = 84.0; }
    return self;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (CGFloat)gridBottom { return self.bounds.size.height - kVelH; }
- (double)quarterForX:(CGFloat)x { return (x - kKeysW) / self.quarterWidth + self.scrollQuarters; }
- (CGFloat)xForQuarter:(double)q { return kKeysW + (q - self.scrollQuarters) * self.quarterWidth; }
- (int)pitchForY:(CGFloat)y { return std::clamp(static_cast<int>(std::floor(self.scrollPitch - (y - kGridRulerH) / kPitchH)) + 1, 0, 127); }
- (CGFloat)yForPitch:(int)pitch { return kGridRulerH + (self.scrollPitch - pitch) * kPitchH; }
- (double)snap:(double)q {
    SilvetonController* c = self.controller;
    if (!c.snapEnabled) return std::max(0.0, q);
    const double div = std::max<std::uint32_t>(1U, c.gridDivisionsPerQuarter);
    return std::max(0.0, std::round(q * div) / div);
}

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    SilvetonController* c = self.controller;
    MidiSequence* seq = c ? c.editedSequence : nullptr;
    const CGFloat gridBottom = [self gridBottom];
    // pitch rows
    for (int pitch = 127; pitch >= 0; --pitch) {
        const CGFloat y = [self yForPitch:pitch];
        if (y > gridBottom || y + kPitchH < kGridRulerH) continue;
        sv::fill(NSMakeRect(kKeysW, y, b.size.width - kKeysW, kPitchH), isBlack(pitch) ? sv::laneA() : sv::laneB());
        if (pitch % 12 == 0) sv::line(NSMakePoint(kKeysW, y + kPitchH - 0.5), NSMakePoint(b.size.width, y + kPitchH - 0.5), sv::hairline());
    }
    // vertical grid (quarters, sixteenths)
    const double div = std::max<std::uint32_t>(1U, c ? c.gridDivisionsPerQuarter : 4U);
    const double q0 = std::floor(self.scrollQuarters), q1 = [self quarterForX:b.size.width];
    const double offset = c ? c.editedPartOffsetQuarterNotes : 0.0;
    for (double q = q0; q <= q1; q += 1.0 / div) {
        const CGFloat x = std::floor([self xForQuarter:q]) + 0.5;
        const double tq = q + offset;
        const bool bar = std::abs(std::fmod(tq, 4.0)) < 1e-6;
        const bool beat = std::abs(tq - std::round(tq)) < 1e-6;
        sv::line(NSMakePoint(x, kGridRulerH), NSMakePoint(x, b.size.height), bar ? sv::hex(0x3A3640) : (beat ? sv::hex(0x2A282E) : sv::hex(0x211F25)));
        if (bar) sv::text([NSString stringWithFormat:@"%ld", static_cast<long>(std::llround(tq / 4.0)) + 1], NSMakePoint(x + 4, 6), sv::mono(11), sv::ink());
    }
    sv::fill(NSMakeRect(0, 0, b.size.width, kGridRulerH), [sv::panel() colorWithAlphaComponent:0.92]);
    for (double q = q0; q <= q1; q += 1.0) {
        const double tq = q + offset;
        if (std::abs(std::fmod(tq, 4.0)) < 1e-6)
            sv::text([NSString stringWithFormat:@"%ld", static_cast<long>(std::llround(tq / 4.0)) + 1], NSMakePoint([self xForQuarter:q] + 4, 6), sv::mono(11), sv::ink());
    }
    // velocity lane frame
    sv::fill(NSMakeRect(0, gridBottom, b.size.width, kVelH), sv::panel());
    sv::line(NSMakePoint(0, gridBottom + 0.5), NSMakePoint(b.size.width, gridBottom + 0.5), sv::hairline());
    sv::text(@"VELOCITY", NSMakePoint(8, gridBottom + 7), sv::ui(10, true), sv::inkFaint());
    if (seq) {
        [NSGraphicsContext saveGraphicsState];
        NSRectClip(NSMakeRect(kKeysW, kGridRulerH, b.size.width - kKeysW, gridBottom - kGridRulerH));
        for (const auto& n : seq->notes()) {
            const CGFloat x0 = [self xForQuarter:n.startQuarterNotes], x1 = [self xForQuarter:n.startQuarterNotes + n.durationQuarterNotes];
            const CGFloat y = [self yForPitch:n.pitch];
            const NSRect r = NSMakeRect(x0, y + 1, std::max<CGFloat>(4, x1 - x0 - 1), kPitchH - 2);
            NSColor* col = [sv::copperDeep() blendedColorWithFraction:n.velocity / 127.0 ofColor:sv::amber()];
            sv::roundFill(r, 3, n.muted ? sv::inkFaint() : col);
            if (n.id == self.selectedNote) sv::roundStroke(r, 3, sv::ink(), 1.5);
        }
        [NSGraphicsContext restoreGraphicsState];
        [NSGraphicsContext saveGraphicsState];
        NSRectClip(NSMakeRect(kKeysW, gridBottom, b.size.width - kKeysW, kVelH));
        for (const auto& n : seq->notes()) {
            const CGFloat x = [self xForQuarter:n.startQuarterNotes];
            const CGFloat h = (kVelH - 24) * n.velocity / 127.0;
            sv::fill(NSMakeRect(x, b.size.height - 4 - h, 3, h), n.id == self.selectedNote ? sv::ink() : sv::copper());
            sv::roundFill(NSMakeRect(x - 2, b.size.height - 4 - h - 3, 7, 5), 2, n.id == self.selectedNote ? sv::ink() : sv::amber());
        }
        [NSGraphicsContext restoreGraphicsState];
    } else {
        sv::textIn(@"Select a MIDI part (double-click it in Arrange) to edit notes", NSMakeRect(kKeysW, gridBottom * 0.45, b.size.width - kKeysW, 20),
                   sv::ui(13, true), sv::inkDim(), NSTextAlignmentCenter);
    }
    // keyboard
    for (int pitch = 127; pitch >= 0; --pitch) {
        const CGFloat y = [self yForPitch:pitch];
        if (y > gridBottom || y + kPitchH < kGridRulerH) continue;
        sv::fill(NSMakeRect(0, y, kKeysW - 1, kPitchH - 0.5), isBlack(pitch) ? sv::hex(0x1A191C) : sv::hex(0xD8D2CB));
        if (pitch % 12 == 0)
            sv::text([NSString stringWithFormat:@"%s%d", kNoteNames[0], pitch / 12 - 2], NSMakePoint(kKeysW - 28, y), sv::ui(10, true), sv::canvas());
    }
}

- (const MusicalMidiNote*)noteAt:(NSPoint)p {
    MidiSequence* seq = self.controller.editedSequence;
    if (!seq || p.y > [self gridBottom] || p.y < kGridRulerH) return nullptr;
    const int pitch = [self pitchForY:p.y];
    const double q = [self quarterForX:p.x];
    for (const auto& n : seq->notes())
        if (n.pitch == pitch && q >= n.startQuarterNotes && q <= n.startQuarterNotes + n.durationQuarterNotes) return &n;
    return nullptr;
}

- (void)mouseDown:(NSEvent*)event {
    [self.window makeFirstResponder:self];
    SilvetonController* c = self.controller;
    MidiSequence* seq = c.editedSequence;
    if (!seq) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    _mode = 0;
    if (p.x < kKeysW) return;
    if (p.y > [self gridBottom]) {
        // velocity lane: pick the nearest note start
        const double q = [self quarterForX:p.x];
        std::uint64_t best = 0; double bestD = 1e9;
        for (const auto& n : seq->notes()) {
            const double d = std::abs(n.startQuarterNotes - q) * self.quarterWidth;
            if (d < bestD && d < 8) { bestD = d; best = n.id; }
        }
        if (best) { self.selectedNote = best; _mode = 3; [self mouseDragged:event]; }
        return;
    }
    const MusicalMidiNote* hit = [self noteAt:p];
    if (hit) {
        self.selectedNote = hit->id;
        if ((event.modifierFlags & NSEventModifierFlagOption) || event.clickCount >= 2) {
            [c noteGridDeleteNote:hit->id];
            self.selectedNote = 0;
            [self setNeedsDisplay:YES];
            return;
        }
        const CGFloat x1 = [self xForQuarter:hit->startQuarterNotes + hit->durationQuarterNotes];
        _mode = (x1 - p.x < 6) ? 2 : 1;
        _grabQ = [self quarterForX:p.x] - hit->startQuarterNotes;
        _grabPitch = [self pitchForY:p.y] - hit->pitch;
    } else {
        [c noteGridAddNoteAt:[self snap:std::floor([self quarterForX:p.x] * std::max<std::uint32_t>(1U, c.gridDivisionsPerQuarter)) /
                                        std::max<std::uint32_t>(1U, c.gridDivisionsPerQuarter)]
                       pitch:[self pitchForY:p.y]];
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (_mode == 0 || !self.selectedNote || !c.editedSequence) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (!_gesture) { [c beginGesture:_mode == 3 ? @"Note Velocity" : @"Edit Notes"]; _gesture = YES; }
    if (_mode == 1) {
        [c noteGridMoveNote:self.selectedNote toQuarter:[self snap:[self quarterForX:p.x] - _grabQ] pitch:[self pitchForY:p.y] - _grabPitch];
    } else if (_mode == 2) {
        for (const auto& n : c.editedSequence->notes())
            if (n.id == self.selectedNote) {
                const double end = [self snap:[self quarterForX:p.x]];
                const double minLen = 1.0 / std::max<std::uint32_t>(1U, c.gridDivisionsPerQuarter);
                [c noteGridResizeNote:n.id length:std::max(minLen * 0.5, end - n.startQuarterNotes)];
                break;
            }
    } else if (_mode == 3) {
        const double v = (self.bounds.size.height - 4 - p.y) / (kVelH - 18) * 127.0;
        [c noteGridSetVelocity:self.selectedNote velocity:std::clamp(static_cast<int>(std::lround(v)), 1, 127)];
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_gesture) { [self.controller endGesture]; _gesture = NO; }
    _mode = 0;
}

- (void)keyDown:(NSEvent*)event {
    NSString* ch = event.charactersIgnoringModifiers;
    if (self.selectedNote && ch.length && ([ch characterAtIndex:0] == 127 || [ch characterAtIndex:0] == NSDeleteFunctionKey)) {
        [self.controller noteGridDeleteNote:self.selectedNote];
        self.selectedNote = 0;
        [self setNeedsDisplay:YES];
        return;
    }
    [super keyDown:event];
}

- (void)scrollWheel:(NSEvent*)event {
    const NSEventModifierFlags mods = event.modifierFlags & NSEventModifierFlagDeviceIndependentFlagsMask;
    double dx = event.scrollingDeltaX, dy = event.scrollingDeltaY;
    if (!event.hasPreciseScrollingDeltas) { dx *= 12; dy *= 12; }
    if (mods & (NSEventModifierFlagCommand | NSEventModifierFlagOption)) {
        self.quarterWidth = std::clamp(self.quarterWidth * std::pow(1.08, dy / 4.0), 12.0, 800.0);
    } else {
        if (mods & NSEventModifierFlagShift) { dx = dy; dy = 0; }
        self.scrollQuarters = std::max(0.0, self.scrollQuarters - dx / self.quarterWidth);
        self.scrollPitch = std::clamp(self.scrollPitch + dy / kPitchH, 20.0, 127.0);
    }
    [self setNeedsDisplay:YES];
}
@end

// ========================================================== Sample view ==
@implementation SilvetonSampleView
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    SilvetonController* c = self.controller;
    ProjectAudioClip* clip = c ? c.editedClip : nullptr;
    if (!clip) {
        sv::textIn(@"Select an audio clip in Arrange to edit it here", NSMakeRect(0, b.size.height * 0.45, b.size.width, 20),
                   sv::ui(13, true), sv::inkDim(), NSTextAlignmentCenter);
        return;
    }
    const NSRect wave = NSInsetRect(b, 16, 16);
    sv::roundFill(wave, 10, sv::panel());
    const double midY = NSMidY(wave);
    sv::line(NSMakePoint(wave.origin.x, midY), NSMakePoint(NSMaxX(wave), midY), sv::hairline());
    c.core->waveformCache().request(clip->audioPath);
    if (auto ov = c.core->waveformCache().find(clip->audioPath))
        sv::drawWaveform(*ov, clip->sourceStartSample, clip->lengthSamples, NSInsetRect(wave, 4, 10), sv::copper(), false,
                         -1.0e9, 1.0e9, c.project ? c.project->sampleRate : 0.0);
    else
        sv::textIn(@"Building waveform…", NSMakeRect(wave.origin.x, midY - 8, wave.size.width, 16), sv::ui(11), sv::inkDim(), NSTextAlignmentCenter);
    const double len = std::max<double>(1.0, static_cast<double>(clip->lengthSamples));
    if (clip->fadeInSamples) {
        const CGFloat fx = wave.origin.x + wave.size.width * (clip->fadeInSamples / len);
        sv::line(NSMakePoint(wave.origin.x, NSMaxY(wave)), NSMakePoint(fx, wave.origin.y), sv::amber(), 1.5);
    }
    if (clip->fadeOutSamples) {
        const CGFloat fx = NSMaxX(wave) - wave.size.width * (clip->fadeOutSamples / len);
        sv::line(NSMakePoint(fx, wave.origin.y), NSMakePoint(NSMaxX(wave), NSMaxY(wave)), sv::amber(), 1.5);
    }
    const double sr = c.project->sampleRate > 0 ? c.project->sampleRate : 48000.0;
    NSString* info = [NSString stringWithFormat:@"%@   ·   %@ long   ·   gain %+.1f dB%@",
                      [sv::ns(clip->audioPath) lastPathComponent], sv::ns(formatClock(len / sr)), clip->gainDb, clip->mute ? @"   ·   MUTED" : @""];
    sv::textIn(info, NSMakeRect(wave.origin.x + 12, wave.origin.y + 8, wave.size.width - 24, 16), sv::ui(11, true), sv::inkDim());
}
@end

// ======================================================= Native editor ==
@interface SVParamSlider : NSSlider
@property(nonatomic, assign) std::uint32_t paramId;
@property(nonatomic, weak) id editorOwner;
@end

@interface SilvetonNativeEditor ()
@property(nonatomic, copy) SilvetonNativeResolver resolver;
@property(nonatomic, copy) NSString* editorKey;
@property(nonatomic, copy) NSString* classId;
- (void)beginParam:(std::uint32_t)paramId;
- (void)endParam:(std::uint32_t)paramId;
- (void)resetParam:(std::uint32_t)paramId;
@end

@implementation SVParamSlider
- (void)mouseDown:(NSEvent*)event {
    SilvetonNativeEditor* ed = self.editorOwner;
    if (event.clickCount >= 2) { [ed resetParam:self.paramId]; return; }
    [ed beginParam:self.paramId];
    [super mouseDown:event];
    [ed endParam:self.paramId];
}
@end

static NSMutableDictionary<NSString*, SilvetonNativeEditor*>* gNativeEditors = nil;

@implementation SilvetonNativeEditor {
    NSMutableArray* _controls;     // index = param id
    NSMutableArray<NSTextField*>* _values;
    NSTextField* _meterLabel;
}

+ (void)openWithResolver:(SilvetonNativeResolver)resolver title:(NSString*)title key:(NSString*)key {
    if (!gNativeEditors) gNativeEditors = [NSMutableDictionary dictionary];
    NativePlugin* plugin = resolver ? resolver() : nullptr;
    if (!plugin) return;
    SilvetonNativeEditor* existing = gNativeEditors[key];
    if (existing && [existing.classId isEqualToString:sv::ns(plugin->classId())]) { [existing makeKeyAndOrderFront:nil]; return; }
    if (existing) { [existing close]; [gNativeEditors removeObjectForKey:key]; }
    const auto& params = plugin->parameters();
    const CGFloat rowH = 30, width = 440;
    const CGFloat height = 70 + rowH * static_cast<CGFloat>(params.size()) + 20;
    SilvetonNativeEditor* ed = [[SilvetonNativeEditor alloc] initWithContentRect:NSMakeRect(200, 200, width, height)
                                                                     styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskUtilityWindow
                                                                       backing:NSBackingStoreBuffered defer:NO];
    ed.resolver = resolver;
    ed.editorKey = key;
    ed.classId = sv::ns(plugin->classId());
    ed.title = title;
    ed.releasedWhenClosed = NO;
    ed.backgroundColor = sv::panel();
    ed.hidesOnDeactivate = NO;
    [ed buildFor:plugin width:width height:height rowHeight:rowH];
    gNativeEditors[key] = ed;
    [ed center];
    [ed makeKeyAndOrderFront:nil];
}

- (NSTextField*)labelWith:(NSString*)s frame:(NSRect)f font:(NSFont*)font color:(NSColor*)color align:(NSTextAlignment)a {
    NSTextField* l = [[NSTextField alloc] initWithFrame:f];
    l.stringValue = s; l.editable = NO; l.selectable = NO; l.bezeled = NO; l.drawsBackground = NO;
    l.font = font; l.textColor = color; l.alignment = a;
    return l;
}

- (void)buildFor:(NativePlugin*)plugin width:(CGFloat)width height:(CGFloat)height rowHeight:(CGFloat)rowH {
    NSView* root = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, width, height)];
    self.contentView = root;
    _controls = [NSMutableArray array];
    _values = [NSMutableArray array];
    NSString* header = sv::ns(plugin->info().name).uppercaseString;
    [root addSubview:[self labelWith:header frame:NSMakeRect(18, height - 40, width - 36 - 176, 20) font:sv::ui(13, true) color:sv::copper() align:NSTextAlignmentLeft]];
    [root addSubview:[self labelWith:@"SILVETON NATIVE" frame:NSMakeRect(18, height - 56, 200, 14) font:sv::ui(10, true) color:sv::inkFaint() align:NSTextAlignmentLeft]];
    _meterLabel = [self labelWith:@"" frame:NSMakeRect(width - 190, height - 40, 172, 18) font:sv::mono(11, true) color:sv::amber() align:NSTextAlignmentRight];
    [root addSubview:_meterLabel];
    const auto& params = plugin->parameters();
    for (std::size_t i = 0; i < params.size(); ++i) {
        const auto& prm = params[i];
        const CGFloat y = height - 80 - static_cast<CGFloat>(i) * rowH;
        [root addSubview:[self labelWith:sv::ns(prm.name) frame:NSMakeRect(18, y, 128, 18) font:sv::ui(12) color:sv::ink() align:NSTextAlignmentLeft]];
        NSControl* ctl = nil;
        if (prm.scale == NativeParamScale::Toggle) {
            NSButton* b = [[NSButton alloc] initWithFrame:NSMakeRect(156, y - 2, 180, 22)];
            [b setButtonType:NSButtonTypeSwitch];
            b.title = @"";
            b.target = self; b.action = @selector(toggleChanged:); b.tag = static_cast<NSInteger>(prm.id);
            ctl = b;
        } else if (prm.scale == NativeParamScale::Choice) {
            NSPopUpButton* pop = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(152, y - 3, 190, 24) pullsDown:NO];
            for (const auto& ch : prm.choices) [pop addItemWithTitle:sv::ns(ch)];
            pop.target = self; pop.action = @selector(choiceChanged:); pop.tag = static_cast<NSInteger>(prm.id);
            pop.font = sv::ui(11);
            ctl = pop;
        } else {
            SVParamSlider* s = [[SVParamSlider alloc] initWithFrame:NSMakeRect(154, y - 2, 190, 22)];
            s.minValue = 0; s.maxValue = 1; s.continuous = YES;
            s.paramId = prm.id; s.editorOwner = self;
            s.target = self; s.action = @selector(sliderChanged:); s.tag = static_cast<NSInteger>(prm.id);
            ctl = s;
        }
        [root addSubview:ctl];
        [_controls addObject:ctl];
        NSTextField* v = [self labelWith:@"" frame:NSMakeRect(350, y, width - 366, 18) font:sv::mono(11) color:sv::inkDim() align:NSTextAlignmentRight];
        [root addSubview:v];
        [_values addObject:v];
    }
    [self syncFrom:plugin];
}

- (void)syncFrom:(NativePlugin*)plugin {
    const auto& params = plugin->parameters();
    for (std::size_t i = 0; i < params.size() && i < _controls.count; ++i) {
        id ctl = _controls[i];
        const auto id = static_cast<std::uint32_t>(i);
        if ([ctl isKindOfClass:[NSPopUpButton class]]) [(NSPopUpButton*)ctl selectItemAtIndex:static_cast<NSInteger>(plugin->plainValue(id) - params[i].minValue)];
        else if ([ctl isKindOfClass:[SVParamSlider class]]) { if (![(NSSlider*)ctl isHighlighted]) [(NSSlider*)ctl setDoubleValue:plugin->normalizedValue(id)]; }
        else if ([ctl isKindOfClass:[NSButton class]]) [(NSButton*)ctl setState:plugin->plainValue(id) >= 0.5 ? NSControlStateValueOn : NSControlStateValueOff];
        _values[i].stringValue = sv::ns(plugin->formatValue(id));
    }
    const float gr = plugin->meter(0);
    if (plugin->classId() == "silveton.press" || plugin->classId() == "silveton.ceiling")
        _meterLabel.stringValue = [NSString stringWithFormat:@"GR %.1f dB", gr];
    else if (plugin->classId() == "silveton.gate")
        _meterLabel.stringValue = [NSString stringWithFormat:@"GAIN %.1f dB", gr];
}

- (NativePlugin*)plugin {
    NativePlugin* p = self.resolver ? self.resolver() : nullptr;
    if (p && ![sv::ns(p->classId()) isEqualToString:self.classId]) return nullptr;
    return p;
}
- (void)beginParam:(std::uint32_t)paramId { if (auto* p = [self plugin]) p->beginEdit(paramId); }
- (void)endParam:(std::uint32_t)paramId { if (auto* p = [self plugin]) p->endEdit(paramId); }
- (void)resetParam:(std::uint32_t)paramId {
    if (auto* p = [self plugin]) {
        const auto& prm = p->parameters()[paramId];
        p->beginEdit(paramId); p->setFromEditor(paramId, prm.defaultValue); p->endEdit(paramId);
        [self syncFrom:p];
    }
}
- (void)sliderChanged:(NSSlider*)sender {
    NativePlugin* p = [self plugin];
    if (!p) return;
    const auto id = static_cast<std::uint32_t>(sender.tag);
    p->setFromEditor(id, NativePlugin::toPlain(p->parameters()[id], sender.doubleValue));
    _values[id].stringValue = sv::ns(p->formatValue(id));
}
- (void)choiceChanged:(NSPopUpButton*)sender {
    NativePlugin* p = [self plugin];
    if (!p) return;
    const auto id = static_cast<std::uint32_t>(sender.tag);
    p->beginEdit(id); p->setFromEditor(id, p->parameters()[id].minValue + sender.indexOfSelectedItem); p->endEdit(id);
    _values[id].stringValue = sv::ns(p->formatValue(id));
}
- (void)toggleChanged:(NSButton*)sender {
    NativePlugin* p = [self plugin];
    if (!p) return;
    const auto id = static_cast<std::uint32_t>(sender.tag);
    p->beginEdit(id); p->setFromEditor(id, sender.state == NSControlStateValueOn ? 1.0 : 0.0); p->endEdit(id);
    _values[id].stringValue = sv::ns(p->formatValue(id));
}

+ (void)refreshAll {
    if (!gNativeEditors) return;
    NSMutableArray<NSString*>* dead = [NSMutableArray array];
    for (NSString* key in gNativeEditors) {
        SilvetonNativeEditor* ed = gNativeEditors[key];
        if (!ed.isVisible) { [dead addObject:key]; continue; }
        NativePlugin* p = [ed plugin];
        if (!p) { [ed close]; [dead addObject:key]; continue; }
        [ed syncFrom:p];
    }
    for (NSString* key in dead) [gNativeEditors removeObjectForKey:key];
}
+ (void)closeAll {
    if (!gNativeEditors) return;
    for (NSString* key in gNativeEditors) [gNativeEditors[key] close];
    [gNativeEditors removeAllObjects];
}
@end
