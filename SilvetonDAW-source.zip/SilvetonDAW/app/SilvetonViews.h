#pragma once
#import <AppKit/AppKit.h>
#include "SilvetonController.h"

// Top bar: wordmark, page switcher, project title and status.
@interface SilvetonPageBar : NSView
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, copy) NSString* projectTitle;
@property(nonatomic, copy) NSString* statusText;
@property(nonatomic, assign) int page;
@end

// Bottom transport deck: counters, tempo/meter, transport keys, master meter.
@interface SilvetonTransportDeck : NSView
@property(nonatomic, weak) SilvetonController* controller;
- (void)tick;   // called by the UI timer (~30 Hz)
@end

// Arrange canvas: track headers, ruler, marker & arranger lanes, clips/parts.
@interface SilvetonArrangeView : NSView
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, assign) double scrollSeconds;
@property(nonatomic, assign) double scrollY;
- (BOOL)ensurePlayheadVisible;   // YES when the view scrolled
- (void)tickAnimation;           // invalidates only the playhead stripe and the level meters
@end

// Mixing console: custom-drawn channel strips.
@interface SilvetonConsoleView : NSView
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, assign) double scrollX;
- (void)tickMeters;   // called by the UI timer: invalidates only the meter columns that visibly moved
@end

// Note grid (piano roll) with velocity lane.
@interface SilvetonNoteGridView : NSView
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, assign) double quarterWidth;
@property(nonatomic, assign) double scrollQuarters;
@property(nonatomic, assign) double scrollPitch;   // top visible pitch
@property(nonatomic, assign) std::uint64_t selectedNote;
@end

// Sample editor: waveform of the selected clip with fades.
@interface SilvetonSampleView : NSView
@property(nonatomic, weak) SilvetonController* controller;
@end

// Generated editor window for Silveton Native processors.
// The plug-in is resolved through `resolver` every time it is touched, so a
// runtime rebuild (which replaces instances) can never leave a dangling pointer.
typedef silveton::NativePlugin* (^SilvetonNativeResolver)(void);
@interface SilvetonNativeEditor : NSPanel
+ (void)openWithResolver:(SilvetonNativeResolver)resolver title:(NSString*)title key:(NSString*)key;
+ (void)refreshAll;   // re-sync values (automation) and drop editors whose slot changed
+ (void)closeAll;
@end
