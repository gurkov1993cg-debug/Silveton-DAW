#pragma once
#import <AppKit/AppKit.h>
#include "SilvetonController.h"

#include <cstdint>
#include <vector>

// Wooden side bar on the left: wordmark and the page keys (PROJECT, MIX, EDIT, LIBRARY, SETUP).
@interface SilvetonSideBar : NSView   // keys: PROJECT, MIX, LIBRARY, SETUP
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, assign) int page;
@end

// Thin strip along the bottom of the window: the status line (left), project name and sample rate (right).
@interface SilvetonPageBar : NSView
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, copy) NSString* projectTitle;
@property(nonatomic, copy) NSString* statusText;
@end

// Transport deck along the top: light displays for position, tempo, cycle range and project, transport keys, master meter.
@interface SilvetonTransportDeck : NSView
@property(nonatomic, weak) SilvetonController* controller;
- (void)tick;   // called by the UI timer (~30 Hz)
@end

// Arrange canvas: track headers, ruler, marker & arranger lanes, clips/parts.
@interface SilvetonArrangeView : NSView
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, assign) double scrollSeconds;
@property(nonatomic, assign) double scrollY;
- (BOOL)ensurePlayheadVisible;   // YES when the view scrolled
- (void)tickAnimation;           // invalidates only the playhead stripe and the level meters
// Height of the selected track's row. > 0 = that many pixels, 0 = back to normal, -1 = fill the
// window ("zoom this track"), -2 = zoom on / off. NO when no track is selected.
- (BOOL)setSelectedTrackHeight:(CGFloat)height;
- (void)resetTrackHeights;       // every track back to the normal height
// Project-window multi-selection. IDs are track-local; selection is not saved in the song.
- (std::vector<SVSelectedEvent>)selectedEvents;
- (void)setSelectedEvents:(const std::vector<SVSelectedEvent>&)events;
- (void)clearSelectedEvents;
- (void)selectAllEvents;
// The range selection (Range Selection tool, key 2): a span of time over one or more tracks.
- (BOOL)hasRange;
- (silveton::TimelineRange)range;
- (std::vector<silveton::ArrangeRow>)rangeRows;   // top to bottom, folders left out
- (void)setRange:(silveton::TimelineRange)range rows:(const std::vector<silveton::ArrangeRow>&)rows;
- (void)clearRange;
- (BOOL)automationPointSelected;
- (BOOL)deleteSelectedAutomationPoint;   // YES when a point was removed
- (void)toggleAutomationLanes;           // of the selected track
- (void)toggleTakeLanes;                 // the recorded takes of the selected track
- (void)toggleTempoTrack;                // the tempo track under the arranger row
- (BOOL)tempoTrackShown;
- (BOOL)deleteSelectedTempoPoint;        // YES when a tempo change was removed
- (void)zoomToSamples:(std::int64_t)start to:(std::int64_t)end;   // the span fills the lanes
- (void)zoomAroundX:(CGFloat)x factor:(double)factor;             // the time under x stays where it is
@end

// Mixing console: custom-drawn channel strips. `compact` = the shorter, narrower strips of the mixer
// that sits under the tracks on the Project page (3 inserts, no sends line).
@interface SilvetonConsoleView : NSView
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, assign) double scrollX;
@property(nonatomic, assign) BOOL compact;
- (void)tickMeters;   // called by the UI timer: invalidates only the meter columns that visibly moved
- (void)invalidateStrip:(SVStrip)strip;   // repaints that one channel (a fader or pan move), not the whole console
@end

// Note grid (piano roll, "Key Editor"): notes with many-note selection and seven tools, a keyboard that sounds the
// notes, a playhead, and up to four lanes under the notes for velocity and controllers (see SilvetonNoteGrid.mm).
@interface SilvetonNoteGridView : NSView
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, assign) double quarterWidth;
@property(nonatomic, assign) double scrollQuarters;
@property(nonatomic, assign) double scrollPitch;   // top visible pitch
@property(nonatomic, assign) CGFloat rowHeight;    // height of one pitch row
- (std::vector<std::uint64_t>)selection;           // the selected notes (sorted by id)
- (void)setSelection:(const std::vector<std::uint64_t>&)ids;
- (BOOL)hasSelection;                              // notes or controller points are selected
- (void)selectionChanged;                          // forget notes that no longer exist (after undo, delete, another part)
- (void)tick;                                      // UI timer (~30 Hz): playhead and page turn
- (void)zoomBy:(double)factor;                     // < 1 zooms in, > 1 zooms out (around the middle)
- (void)zoomFit;                                   // all notes of the part
- (void)zoomToSelection;
- (void)deleteSelected;                            // selected notes, or the selected controller points of the lane in use
- (void)thinActiveLane;                            // removes controller points that lie on a straight line
- (void)clearActiveLane;                           // removes all controller points of the lane in use (velocity lane: nothing)
- (void)stopAudition;
@end

// Sample editor: zoomable waveform of the edited audio (down to single samples), time ruler,
// range selection, fade handles, overview strip and read-outs.
@interface SilvetonSampleView : NSView
@property(nonatomic, weak) SilvetonController* controller;
- (void)tick;                         // UI timer (~30 Hz): playhead, follow, loading detail
- (void)zoomBy:(double)factor;        // < 1 zooms in, > 1 zooms out (around the middle of the view)
- (void)zoomFit;
- (void)zoomToSelection;
- (void)selectionChanged;             // the controller changed the selection or the audio
@end

// Tone Editor: the pitch and timing of one voice as blocks on a piano grid (see SilvetonToneView.mm).
@interface SilvetonToneView : NSView
@property(nonatomic, weak) SilvetonController* controller;
@property(nonatomic, assign) BOOL showOriginalPitch;    // the pitch as sung (thin line)
@property(nonatomic, assign) BOOL showCorrectedPitch;   // the pitch after the changes (bright line)
@property(nonatomic, assign) BOOL showWaveform;         // the sound under the grid
@property(nonatomic, assign) BOOL showScale;            // dim the rows of notes that are not in the scale
@property(nonatomic, assign) BOOL compact;              // under the tracks: no wave strip and no read-out line
- (void)tick;                         // UI timer (~30 Hz): playhead, progress of the analysis
- (void)sessionChanged;               // another sound was opened
- (void)sessionLoaded;                // its analysis arrived: show all of it
- (void)zoomBy:(double)factor;        // < 1 zooms in, > 1 zooms out (around the middle)
- (void)zoomFit;
- (void)zoomToSelection;
- (void)selectionChanged;
@end

// Generated editor window for Silveton Native processors.
// The plug-in is resolved through `resolver` every time it is touched, so a
// runtime rebuild (which replaces instances) can never leave a dangling pointer.
typedef silveton::NativePlugin* (^SilvetonNativeResolver)(void);
@interface SilvetonNativeEditor : NSPanel
+ (void)openWithResolver:(SilvetonNativeResolver)resolver title:(NSString*)title key:(NSString*)key;
+ (void)refreshAll;   // re-sync values (automation) and drop editors whose slot changed
+ (void)closeAll;
@end

// A page whose children are laid out by hand: `onLayout` runs whenever the page changes size.
@interface SilvetonLayoutView : NSView
@property(nonatomic, copy) void (^onLayout)(void);
@end

// Tool row above the tracks on the Project page: snap, grid, track height, zoom, panel switches.
@interface SilvetonToolBar : NSView
@property(nonatomic, weak) SilvetonController* controller;
@end

// Tab strip along the bottom of the lower zone (Project page): MIXER / EDITOR, FULL PAGE (editor) and HIDE.
@interface SilvetonZoneBar : NSView
@property(nonatomic, weak) SilvetonController* controller;
@end

// Thin bar between the tracks and the lower zone: drag it to change the height of the zone.
@interface SilvetonZoneSplitter : NSView
@property(nonatomic, weak) SilvetonController* controller;
@end

// The two keys on top of the Inspector: TRACK (the selected track) and EDITOR (the open editor's settings).
@interface SilvetonInspectorTabs : NSView
@property(nonatomic, weak) SilvetonController* controller;
@end

// Info line under the tool row: the facts of the selected clip or part (file, start, end, length, fades, gain,
// mute). Double-click a field to change it.
@interface SilvetonInfoLine : NSView
@property(nonatomic, weak) SilvetonController* controller;
@end

// Right-hand level panel on the Project page: master peak read-out, big stereo meter, details of the selected clip.
@interface SilvetonMeterPanel : NSView
@property(nonatomic, weak) SilvetonController* controller;
- (void)tick;   // UI timer: repaints only the meter when it visibly moved
@end
