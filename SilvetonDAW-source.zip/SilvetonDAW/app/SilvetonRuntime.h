// Application runtime: owns project session, CoreAudio device, engine,
// VST3 host + Silveton Native factory, MIDI input and the recorder.
#pragma once
#import <Foundation/Foundation.h>

#include "silveton/Arrangement.h"
#include "silveton/AudioEngine.h"
#include "silveton/CoreAudioDevice.h"
#include "silveton/CoreMidiInput.h"
#include "silveton/DawRuntimeCoordinator.h"
#include "silveton/NativePlugins.h"
#include "silveton/ProjectSession.h"
#include "silveton/RecordingWorkflow.h"
#include "silveton/Vst3Host.h"
#include "silveton/WaveformCache.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>

namespace sv {

inline std::string ensureDirectory(NSURL* dir) {
    NSError* error = nil;
    if (![[NSFileManager defaultManager] createDirectoryAtURL:dir withIntermediateDirectories:YES attributes:nil error:&error])
        throw std::runtime_error(error ? std::string([[error localizedDescription] UTF8String]) : std::string("cannot create directory"));
    return std::string([[dir path] UTF8String]);
}

inline std::string appSupportDirectory() {
    NSArray<NSURL*>* urls = [[NSFileManager defaultManager] URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask];
    if (urls.count == 0) throw std::runtime_error("cannot locate Application Support directory");
    return ensureDirectory([urls[0] URLByAppendingPathComponent:@"Silveton" isDirectory:YES]);
}

inline std::string musicSubdirectory(NSString* name) {
    NSArray<NSURL*>* urls = [[NSFileManager defaultManager] URLsForDirectory:NSMusicDirectory inDomains:NSUserDomainMask];
    NSURL* base = urls.count ? urls[0] : [NSURL fileURLWithPath:NSHomeDirectory()];
    return ensureDirectory([base URLByAppendingPathComponent:name isDirectory:YES]);
}

inline std::string recordingsDirectory() { return musicSubdirectory(@"Silveton Recordings"); }
inline std::string processedMediaDirectory() { return musicSubdirectory(@"Silveton Recordings/Processed"); }

class AppRuntime final {
public:
    AppRuntime() : session_(48000.0), host_(), factory_(&host_) {}
    ~AppRuntime() { shutdown(); }

    silveton::ProjectSession& session() noexcept { return session_; }
    silveton::Project& project() noexcept { return session_.project(); }
    silveton::Vst3Host& host() noexcept { return host_; }
    silveton::AudioEngine& engine() { if (!engine_) throw std::logic_error("audio engine unavailable"); return *engine_; }
    silveton::DawRuntimeCoordinator& runtime() { if (!runtime_) throw std::logic_error("runtime unavailable"); return *runtime_; }
    silveton::CoreAudioDevice& device() { if (!device_) throw std::logic_error("CoreAudio unavailable"); return *device_; }
    bool ready() const noexcept { return engine_ && runtime_ && device_; }
    silveton::CoreMidiInput* midi() noexcept { return midi_.get(); }
    silveton::RecordingWorkflow* recording() noexcept { return recording_.get(); }
    silveton::WaveformCache& waveformCache() noexcept { return waveformCache_; }
    long recordingTrackIndex() const noexcept { return recording_ ? static_cast<long>(recordingTrackIndex_) : -1; }
    std::int64_t recordingStartSample() const noexcept { return recordingStartSample_; }

    // Internal processing rate (default 96 kHz, 0 = follow the card). Takes
    // effect on the next restartAudio().
    void setInternalSampleRate(double rate) noexcept { internalRate_ = rate; }
    double internalSampleRate() const noexcept { return internalRate_; }
    bool rateBridgeActive() const noexcept { return runtime_ && runtime_->rateBridgeActive(); }

    void startDefault() {
        silveton::AudioDeviceConfig requested;
        requested.sampleRate = session_.project().sampleRate;
        requested.blockSize = 256U;
        const std::uint32_t defaultOutput = silveton::CoreAudioDevice::defaultOutputDeviceId();
        const auto devices = silveton::CoreAudioDevice::devices();
        const auto it = std::find_if(devices.begin(), devices.end(),
                                     [defaultOutput](const silveton::CoreAudioDeviceInfo& info) { return info.id == defaultOutput; });
        if (it != devices.end()) {
            requested.inputChannels = std::min<std::uint32_t>(2U, it->inputChannels);
            requested.outputChannels = std::min<std::uint32_t>(2U, it->outputChannels);
            if (requested.outputChannels == 0U) throw std::runtime_error("default CoreAudio device has no output channels");
        } else {
            requested.inputChannels = 0U;
            requested.outputChannels = 2U;
        }
        // With a fixed internal rate the card keeps its own rate (the bridge
        // converts); the project is not tied to the card.
        const bool cardHasRate = it != devices.end() && std::isfinite(it->nominalSampleRate) && it->nominalSampleRate > 0.0;
        if (internalRate_ > 0.0 && cardHasRate) requested.sampleRate = it->nominalSampleRate;
        silveton::CoreAudioDeviceOptions options;
        options.followDefaultOutputDevice = true;
        try {
            restartAudio(requested, options);
        } catch (const std::exception&) {
            if (!cardHasRate || std::abs(it->nominalSampleRate - requested.sampleRate) <= 0.01)
                throw;
            if (internalRate_ <= 0.0) session_.newProject(it->nominalSampleRate);
            requested.sampleRate = it->nominalSampleRate;
            restartAudio(requested, options);
        }
    }

    void restartAudio(const silveton::AudioDeviceConfig& requested, const silveton::CoreAudioDeviceOptions& options) {
        shutdownRealtime();
        deviceOptions_ = options;
        requestedConfig_ = requested;
        device_ = std::make_unique<silveton::CoreAudioDevice>(requestedConfig_, deviceOptions_);
        engine_ = std::make_unique<silveton::AudioEngine>();
        runtime_ = std::make_unique<silveton::DawRuntimeCoordinator>(session_, *engine_, factory_);
        runtime_->setInternalSampleRate(internalRate_);
        runtime_->prepare(device_->config());
        midi_ = std::make_unique<silveton::CoreMidiInput>(runtime_->midiInput(), runtime_->clockMapper());
        midi_->connectAll();
        device_->start(runtime_->audioCallback());
    }

    void rebuildProjectSafely() {
        if (!ready()) return;
        const bool playing = engine_->transport().isPlaying();
        engine_->transport().stop();
        const bool wasRunning = device_->isRunning();
        if (wasRunning) device_->stop();
        runtime_->rebuildProject();
        if (wasRunning) device_->start(runtime_->audioCallback());
        if (playing) engine_->transport().play();
    }

    void service() {
        if (!ready()) return;
        if (runtime_->projectRebuildRequested() && !recording_) rebuildProjectSafely();
        (void)runtime_->service();
        const auto status = device_->status();
        if (status.needsReopen && !recording_) {
            const auto requested = requestedConfig_;
            const auto options = deviceOptions_;
            restartAudio(requested, options);
        }
    }

    // Offline work (export, stems, render in place) needs a stopped device and
    // every pending realtime publication adopted. Restarts on scope exit.
    class OfflineScope {
    public:
        explicit OfflineScope(AppRuntime& rt) : rt_(rt) {
            if (rt_.recording_) throw std::runtime_error("stop recording first");
            rt_.engine().transport().stop();
            if (rt_.runtime().projectRebuildRequested()) rt_.rebuildProjectSafely();
            restart_ = rt_.device().isRunning();
            if (restart_) rt_.device().stop();
            rt_.engine().adoptPendingRealtimeStateAtBlockBoundary();
            if (rt_.runtime().rack().publicationStatePending()) rt_.runtime().rack().adoptPublicationStateAtBlockBoundary();
            (void)rt_.runtime().service();
        }
        ~OfflineScope() {
            try {
                rt_.runtime().applySoloState();
                if (restart_) rt_.device().start(rt_.runtime().audioCallback());
            } catch (...) {}
        }
        OfflineScope(const OfflineScope&) = delete;
        OfflineScope& operator=(const OfflineScope&) = delete;
    private:
        AppRuntime& rt_;
        bool restart_ {false};
    };

    void beginRecording(std::size_t trackIndex) {
        if (recording_) throw std::logic_error("recording already active");
        if (!ready()) throw std::logic_error("audio device unavailable");
        if (trackIndex >= session_.project().tracks.size()) throw std::out_of_range("record track");
        const std::uint32_t channels = std::min<std::uint32_t>(2U, device_->config().inputChannels);
        if (channels == 0U) throw std::runtime_error("the selected audio device has no inputs — choose one in Audio Setup");
        NSDateFormatter* fmt = [[NSDateFormatter alloc] init];
        fmt.dateFormat = @"yyyyMMdd_HHmmss";
        const std::string path = recordingsDirectory() + "/Take_" + std::string([[fmt stringFromDate:[NSDate date]] UTF8String]) + ".wav";
        recordingTrackIndex_ = trackIndex;
        recordingStartSample_ = engine_->transport().positionSamples();
        session_.beginEdit("Record Take");
        try {
            recording_ = std::make_unique<silveton::RecordingWorkflow>(*engine_, session_.project(), trackIndex);
            recording_->start(path, channels);
            engine_->transport().play();
        } catch (...) {
            recording_.reset();
            recordingTrackIndex_ = std::numeric_limits<std::size_t>::max();
            recordingStartSample_ = 0;
            session_.cancelEdit();
            throw;
        }
    }

    void stopRecording(bool commit = true) {
        if (!recording_) return;
        engine_->transport().stop();
        try {
            if (commit) {
                const auto ids = recording_->stopAndCommitTakes();
                if (!ids.empty()) recording_->promoteTakeToComp(ids.back(), 0U);
                const std::string recordedPath = recording_->audioPath();
                recording_.reset();
                recordingTrackIndex_ = std::numeric_limits<std::size_t>::max();
                recordingStartSample_ = 0;
                session_.commitEdit();
                waveformCache_.request(recordedPath);
                if (runtime_) runtime_->requestProjectRebuild();
            } else {
                (void)recording_->stopAndCommitTakes();
                recording_.reset();
                recordingTrackIndex_ = std::numeric_limits<std::size_t>::max();
                recordingStartSample_ = 0;
                session_.cancelEdit();
            }
        } catch (...) {
            recording_.reset();
            recordingTrackIndex_ = std::numeric_limits<std::size_t>::max();
            recordingStartSample_ = 0;
            if (session_.history().transactionOpen()) session_.cancelEdit();
            throw;
        }
    }

    void shutdownRealtime() noexcept {
        if (recording_) { try { stopRecording(false); } catch (...) { recording_.reset(); } }
        if (midi_) midi_->disconnectAll();
        midi_.reset();
        if (engine_) engine_->transport().stop();
        if (device_) device_->stop();
        runtime_.reset();
        engine_.reset();
        device_.reset();
    }
    void shutdown() noexcept { shutdownRealtime(); }

private:
    silveton::ProjectSession session_;
    silveton::Vst3Host host_;
    silveton::CompositeInstanceFactory factory_;
    std::unique_ptr<silveton::CoreAudioDevice> device_;
    std::unique_ptr<silveton::AudioEngine> engine_;
    std::unique_ptr<silveton::DawRuntimeCoordinator> runtime_;
    std::unique_ptr<silveton::CoreMidiInput> midi_;
    std::unique_ptr<silveton::RecordingWorkflow> recording_;
    silveton::WaveformCache waveformCache_;
    std::size_t recordingTrackIndex_ {std::numeric_limits<std::size_t>::max()};
    std::int64_t recordingStartSample_ {0};
    silveton::AudioDeviceConfig requestedConfig_ {};
    silveton::CoreAudioDeviceOptions deviceOptions_ {};
    double internalRate_ {96000.0};
};

} // namespace sv
