// Silveton — the one dialog every question goes through (SVDialog): dark window, header with
// title and one-line explanation, labelled rows (slider + number + unit + quick values, choice,
// tick box, text), a note that updates while you change values, and Cancel / OK.
// Return = OK, Esc = Cancel. Numbers can be typed ("," or "." as the decimal sign) or dragged.
#import "SilvetonControllerPrivate.h"
#include "SilvetonTheme.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <vector>

namespace {

constexpr CGFloat kDialogW = 500.0;
constexpr CGFloat kPad = 22.0;
constexpr CGFloat kLabelW = 128.0;
constexpr CGFloat kControlX = kPad + kLabelW + 8.0;
constexpr CGFloat kRowH = 34.0;

enum RowKind { RowNumber, RowChoice, RowCheck, RowText };

struct Row {
    RowKind kind {RowNumber};
    NSSlider* slider {nil};
    NSTextField* field {nil};
    NSPopUpButton* popup {nil};
    NSButton* check {nil};
    NSArray<NSNumber*>* presets {nil};
    double min {0.0};
    double max {1.0};
    double value {0.0};
    int decimals {1};
};

NSString* numberText(double v, int decimals) {
    const double step = std::pow(10.0, -decimals);
    if (std::abs(v) < step * 0.5) v = 0.0;   // never "-0.0"
    return [NSString stringWithFormat:@"%.*f", decimals, v];
}

// Quick-value buttons: "-6", "+3", "0".
NSString* presetText(double v, bool signedValues) {
    if (v == 0.0) return @"0";
    NSString* body = [NSString stringWithFormat:@"%g", v];
    return (signedValues && v > 0.0) ? [@"+" stringByAppendingString:body] : body;
}

} // namespace

@interface SVDialog () {
    NSWindow* _window;
    SVFlipView* _root;
    NSTextField* _noteLabel;
    SVButton* _ok;
    SVButton* _cancel;
    std::vector<Row> _rows;
    CGFloat _y;
    SVDialogNote _note;
    BOOL _finished;
    BOOL _accepted;
}
@end

@implementation SVDialog

+ (instancetype)dialogWithTitle:(NSString*)title subtitle:(NSString*)subtitle okTitle:(NSString*)okTitle {
    SVDialog* d = [[SVDialog alloc] init];
    [d buildWithTitle:title subtitle:subtitle okTitle:okTitle];
    return d;
}

- (void)buildWithTitle:(NSString*)title subtitle:(NSString*)subtitle okTitle:(NSString*)okTitle {
    _window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, kDialogW, 200)
                                          styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable
                                            backing:NSBackingStoreBuffered defer:NO];
    _window.title = title ?: @"Silveton";
    _window.delegate = self;
    _window.releasedWhenClosed = NO;
    if (@available(macOS 10.14, *)) _window.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
    else _window.appearance = [NSAppearance appearanceNamed:@"NSAppearanceNameVibrantDark"];
    _root = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, kDialogW, 200)];
    _root.fillColor = sv::canvas();
    _window.contentView = _root;

    // Header: an accent bar, the title, and one or two lines that say what this does.
    NSTextField* heading = [NSTextField labelWithString:title ?: @""];
    heading.font = sv::ui(sv::type::heading, true);
    heading.textColor = sv::ink();
    heading.frame = NSMakeRect(kPad + 12.0, 16.0, kDialogW - 2.0 * kPad - 12.0, 22.0);
    CGFloat headerH = 48.0;
    NSTextField* sub = nil;
    if (subtitle.length) {
        sub = [NSTextField labelWithString:subtitle];
        sub.font = sv::ui(sv::type::label);
        sub.textColor = sv::inkDim();
        sub.lineBreakMode = NSLineBreakByWordWrapping;
        sub.maximumNumberOfLines = 3;
        const CGFloat w = kDialogW - 2.0 * kPad - 12.0;
        const NSRect box = [subtitle boundingRectWithSize:NSMakeSize(w, 1000.0) options:NSStringDrawingUsesLineFragmentOrigin
                                               attributes:@{NSFontAttributeName: sv::ui(sv::type::label)}];
        const CGFloat h = std::ceil(box.size.height) + 4.0;
        sub.frame = NSMakeRect(kPad + 12.0, 40.0, w, h);
        headerH = 40.0 + h + 14.0;
    }
    SVFlipView* band = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, kDialogW, headerH)];
    band.fillColor = sv::panel();
    [_root addSubview:band];
    SVFlipView* accent = [[SVFlipView alloc] initWithFrame:NSMakeRect(kPad, 18.0, 4.0, 18.0)];
    accent.fillColor = sv::copper();
    [_root addSubview:accent];
    SVFlipView* rule = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, headerH - 1.0, kDialogW, 1.0)];
    rule.fillColor = sv::hairline();
    [_root addSubview:rule];
    [_root addSubview:heading];
    if (sub) [_root addSubview:sub];
    _y = headerH + 18.0;

    _cancel = [SVButton buttonWithTitle:@"Cancel" target:self action:@selector(cancelPressed:) frame:NSMakeRect(0, 0, 92, 28)];
    _cancel.keyEquivalent = @"\033";
    _ok = [SVButton buttonWithTitle:okTitle ?: @"OK" target:self action:@selector(okPressed:) frame:NSMakeRect(0, 0, 112, 28)];
    _ok.accent = YES;
    _ok.keyEquivalent = @"\r";
}

// ================================================================== rows ==
- (NSTextField*)labelAtY:(CGFloat)y text:(NSString*)text {
    NSTextField* l = [NSTextField labelWithString:text ?: @""];
    l.font = sv::ui(sv::type::body);
    l.textColor = sv::ink();
    l.frame = NSMakeRect(kPad, y + 4.0, kLabelW, 18.0);
    [_root addSubview:l];
    return l;
}

- (NSTextField*)fieldAtFrame:(NSRect)f {
    NSTextField* t = [[NSTextField alloc] initWithFrame:f];
    t.font = sv::mono(12, true);
    t.textColor = sv::ink();
    t.backgroundColor = sv::laneB();
    t.drawsBackground = YES;
    t.bezeled = YES;
    t.bezelStyle = NSTextFieldSquareBezel;
    t.alignment = NSTextAlignmentRight;
    [_root addSubview:t];
    return t;
}

- (NSInteger)addNumber:(NSString*)label unit:(NSString*)unit min:(double)min max:(double)max value:(double)value
              decimals:(int)decimals presets:(NSArray<NSNumber*>*)presets {
    const NSInteger index = static_cast<NSInteger>(_rows.size());
    Row row;
    row.kind = RowNumber;
    row.min = min; row.max = max; row.decimals = decimals;
    row.value = std::min(std::max(value, min), max);
    row.presets = presets;
    [self labelAtY:_y text:label];

    const CGFloat sliderW = 168.0, fieldW = 74.0;
    row.slider = [[SVResetSlider alloc] initWithFrame:NSMakeRect(kControlX, _y + 3.0, sliderW, 20.0)];
    row.slider.minValue = min; row.slider.maxValue = max; row.slider.doubleValue = row.value;
    row.slider.continuous = YES;
    row.slider.tag = index;
    row.slider.target = self; row.slider.action = @selector(sliderMoved:);
    ((SVResetSlider*)row.slider).resetValue = row.value;
    [_root addSubview:row.slider];

    row.field = [self fieldAtFrame:NSMakeRect(kControlX + sliderW + 10.0, _y + 1.0, fieldW, 24.0)];
    row.field.stringValue = numberText(row.value, decimals);
    row.field.tag = index;
    row.field.target = self; row.field.action = @selector(fieldEdited:);
    if (unit.length) {
        NSTextField* u = [NSTextField labelWithString:unit];
        u.font = sv::ui(sv::type::label);
        u.textColor = sv::inkDim();
        u.frame = NSMakeRect(kControlX + sliderW + 10.0 + fieldW + 6.0, _y + 5.0, kDialogW - (kControlX + sliderW + 10.0 + fieldW + 6.0) - kPad, 16.0);
        [_root addSubview:u];
    }
    _y += kRowH;

    if (presets.count) {
        const bool signedValues = min < 0.0;
        CGFloat x = kControlX;
        for (NSUInteger i = 0U; i < presets.count; ++i) {
            const double p = presets[i].doubleValue;
            NSString* text = presetText(p, signedValues);
            const CGFloat w = std::max<CGFloat>(40.0, std::ceil(sv::textSize(text, sv::ui(11, true)).width) + 18.0);
            SVButton* b = [SVButton buttonWithTitle:text target:self action:@selector(presetPressed:) frame:NSMakeRect(x, _y - 4.0, w, 22.0)];
            b.tag = index * 100 + static_cast<NSInteger>(i);
            [_root addSubview:b];
            x += w + 6.0;
        }
        _y += 28.0;
    }
    _rows.push_back(row);
    return index;
}

- (NSInteger)addChoice:(NSString*)label items:(NSArray<NSString*>*)items selected:(NSInteger)selected {
    const NSInteger index = static_cast<NSInteger>(_rows.size());
    Row row;
    row.kind = RowChoice;
    [self labelAtY:_y text:label];
    row.popup = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(kControlX, _y, kDialogW - kControlX - kPad, 26.0) pullsDown:NO];
    row.popup.font = sv::ui(sv::type::body);
    [row.popup addItemsWithTitles:items];
    [row.popup selectItemAtIndex:std::min<NSInteger>(std::max<NSInteger>(selected, 0), static_cast<NSInteger>(items.count) - 1)];
    row.popup.tag = index;
    row.popup.target = self; row.popup.action = @selector(choiceChanged:);
    [_root addSubview:row.popup];
    _y += kRowH;
    _rows.push_back(row);
    return index;
}

- (NSInteger)addCheck:(NSString*)label on:(BOOL)on {
    const NSInteger index = static_cast<NSInteger>(_rows.size());
    Row row;
    row.kind = RowCheck;
    row.check = [[NSButton alloc] initWithFrame:NSMakeRect(kControlX, _y + 2.0, kDialogW - kControlX - kPad, 22.0)];
    [row.check setButtonType:NSButtonTypeSwitch];
    row.check.title = label;
    row.check.font = sv::ui(sv::type::body);
    row.check.state = on ? NSControlStateValueOn : NSControlStateValueOff;
    row.check.tag = index;
    row.check.target = self; row.check.action = @selector(choiceChanged:);
    [_root addSubview:row.check];
    _y += kRowH;
    _rows.push_back(row);
    return index;
}

- (NSInteger)addText:(NSString*)label value:(NSString*)value {
    const NSInteger index = static_cast<NSInteger>(_rows.size());
    Row row;
    row.kind = RowText;
    [self labelAtY:_y text:label];
    row.field = [self fieldAtFrame:NSMakeRect(kControlX, _y + 1.0, kDialogW - kControlX - kPad, 24.0)];
    row.field.alignment = NSTextAlignmentLeft;
    row.field.font = sv::ui(sv::type::body);
    row.field.stringValue = value ?: @"";
    row.field.tag = index;
    _y += kRowH;
    _rows.push_back(row);
    return index;
}

- (void)setNote:(SVDialogNote)note { _note = [note copy]; }

// ============================================================== callbacks ==
- (void)setNumber:(double)value row:(NSInteger)index {
    Row& row = _rows[static_cast<std::size_t>(index)];
    const double step = std::pow(10.0, -row.decimals);
    row.value = std::min(std::max(std::round(value / step) * step, row.min), row.max);
    row.slider.doubleValue = row.value;
    row.field.stringValue = numberText(row.value, row.decimals);
    [self refreshNote];
}

- (void)sliderMoved:(NSSlider*)sender { [self setNumber:sender.doubleValue row:sender.tag]; }

- (void)fieldEdited:(NSTextField*)sender {
    const NSInteger index = sender.tag;
    NSScanner* scanner = [NSScanner scannerWithString:[sender.stringValue stringByReplacingOccurrencesOfString:@"," withString:@"."]];
    double v = 0.0;
    if ([scanner scanDouble:&v]) [self setNumber:v row:index];
    else [self setNumber:_rows[static_cast<std::size_t>(index)].value row:index];   // not a number: put the old value back
}

- (void)presetPressed:(NSButton*)sender {
    const NSInteger index = sender.tag / 100, which = sender.tag % 100;
    const Row& row = _rows[static_cast<std::size_t>(index)];
    if (which < static_cast<NSInteger>(row.presets.count)) [self setNumber:row.presets[static_cast<NSUInteger>(which)].doubleValue row:index];
}

- (void)choiceChanged:(id)sender { (void)sender; [self refreshNote]; }

- (void)refreshNote {
    if (_noteLabel == nil || !_note) return;
    _noteLabel.stringValue = _note(self) ?: @"";
}

- (void)okPressed:(id)sender {
    (void)sender;
    [_window makeFirstResponder:nil];   // takes over a number that is still being typed
    for (std::size_t i = 0U; i < _rows.size(); ++i)
        if (_rows[i].kind == RowNumber) [self fieldEdited:_rows[i].field];
    _accepted = YES;
    [self finish];
}
- (void)cancelPressed:(id)sender { (void)sender; _accepted = NO; [self finish]; }
- (void)windowWillClose:(NSNotification*)note { (void)note; if (!_finished) { _accepted = NO; [self finish]; } }
- (void)finish {
    if (_finished) return;
    _finished = YES;
    [NSApp stopModalWithCode:_accepted ? NSModalResponseOK : NSModalResponseCancel];
}

// ================================================================== run ==
- (BOOL)run {
    // Note, then the buttons.
    if (_note) {
        _noteLabel = [NSTextField labelWithString:@""];
        _noteLabel.font = sv::ui(sv::type::label);
        _noteLabel.textColor = sv::amber();
        _noteLabel.lineBreakMode = NSLineBreakByWordWrapping;
        _noteLabel.maximumNumberOfLines = 3;
        _noteLabel.frame = NSMakeRect(kPad, _y, kDialogW - 2.0 * kPad, 44.0);
        [_root addSubview:_noteLabel];
        [self refreshNote];
        _y += 52.0;
    }
    const CGFloat footerH = 60.0;
    SVFlipView* rule = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, _y + 2.0, kDialogW, 1.0)];
    rule.fillColor = sv::hairline();
    [_root addSubview:rule];
    SVFlipView* foot = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, _y + 3.0, kDialogW, footerH - 3.0)];
    foot.fillColor = sv::panel();
    [_root addSubview:foot positioned:NSWindowBelow relativeTo:nil];
    const CGFloat total = _y + footerH;
    _ok.frame = NSMakeRect(kDialogW - kPad - 112.0, _y + 18.0, 112.0, 28.0);
    _cancel.frame = NSMakeRect(kDialogW - kPad - 112.0 - 10.0 - 92.0, _y + 18.0, 92.0, 28.0);
    [_root addSubview:_cancel];
    [_root addSubview:_ok];

    [_window setContentSize:NSMakeSize(kDialogW, total)];
    _root.frame = NSMakeRect(0, 0, kDialogW, total);
    [_window center];
    // The first number (or text) is ready to type.
    for (const Row& row : _rows)
        if (row.field != nil) { [_window makeFirstResponder:row.field]; [row.field selectText:nil]; break; }
    [_window makeKeyAndOrderFront:nil];
    [NSApp runModalForWindow:_window];
    [_window orderOut:nil];
    return _accepted;
}

// =============================================================== results ==
- (double)numberAt:(NSInteger)row { return _rows[static_cast<std::size_t>(row)].value; }
- (NSInteger)choiceAt:(NSInteger)row { return _rows[static_cast<std::size_t>(row)].popup.indexOfSelectedItem; }
- (BOOL)checkAt:(NSInteger)row { return _rows[static_cast<std::size_t>(row)].check.state == NSControlStateValueOn; }
- (NSString*)textAt:(NSInteger)row {
    return [_rows[static_cast<std::size_t>(row)].field.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

@end


// ====================================================== SVProgress =========
namespace {
constexpr CGFloat kProgressW = 460.0;
BOOL gProgressActive = NO;

NSString* clockText(double seconds) {
    const long total = static_cast<long>(std::max(0.0, std::round(seconds)));
    if (total >= 3600) return [NSString stringWithFormat:@"%ld:%02ld:%02ld", total / 3600, (total / 60) % 60, total % 60];
    return [NSString stringWithFormat:@"%ld:%02ld", total / 60, total % 60];
}
} // namespace

@interface SVProgress () {
    NSWindow* _window;
    SVFlipView* _root;
    SVFlipView* _track;
    SVFlipView* _fill;
    NSTextField* _percent;
    NSTextField* _status;
    NSTextField* _times;
    SVButton* _cancel;
    NSModalSession _session;
    BOOL _open;
    BOOL _cancelled;
    std::chrono::steady_clock::time_point _start;
}
@end

@implementation SVProgress

+ (BOOL)isActive { return gProgressActive; }

+ (instancetype)progressWithTitle:(NSString*)title {
    SVProgress* p = [[SVProgress alloc] init];
    p.partNoun = @"Part";
    [p buildWithTitle:title];
    return p;
}

- (void)buildWithTitle:(NSString*)title {
    const CGFloat barW = kProgressW - 2.0 * kPad;
    const CGFloat headerH = 50.0;
    const CGFloat barY = 112.0;
    const CGFloat footY = 166.0;
    const CGFloat total = footY + 60.0;
    _window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, kProgressW, total)
                                          styleMask:NSWindowStyleMaskTitled backing:NSBackingStoreBuffered defer:NO];
    _window.title = title ?: @"Silveton";
    _window.delegate = self;
    _window.releasedWhenClosed = NO;
    if (@available(macOS 10.14, *)) _window.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
    else _window.appearance = [NSAppearance appearanceNamed:@"NSAppearanceNameVibrantDark"];
    _root = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, kProgressW, total)];
    _root.fillColor = sv::canvas();
    _window.contentView = _root;

    SVFlipView* band = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, 0, kProgressW, headerH)];
    band.fillColor = sv::panel();
    [_root addSubview:band];
    SVFlipView* accent = [[SVFlipView alloc] initWithFrame:NSMakeRect(kPad, 17.0, 4.0, 18.0)];
    accent.fillColor = sv::copper();
    [_root addSubview:accent];
    SVFlipView* rule = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, headerH - 1.0, kProgressW, 1.0)];
    rule.fillColor = sv::hairline();
    [_root addSubview:rule];
    NSTextField* heading = [NSTextField labelWithString:title ?: @""];
    heading.font = sv::ui(sv::type::heading, true);
    heading.textColor = sv::ink();
    heading.frame = NSMakeRect(kPad + 12.0, 15.0, kProgressW - 2.0 * kPad - 12.0, 22.0);
    [_root addSubview:heading];

    _percent = [NSTextField labelWithString:@"0%"];
    _percent.font = sv::mono(sv::type::display, true);
    _percent.textColor = sv::ink();
    _percent.frame = NSMakeRect(kPad, headerH + 18.0, 150.0, 32.0);
    [_root addSubview:_percent];

    _times = [NSTextField labelWithString:@"Starting…"];
    _times.font = sv::mono(sv::type::label);
    _times.textColor = sv::inkDim();
    _times.alignment = NSTextAlignmentRight;
    _times.frame = NSMakeRect(kPad + 150.0, headerH + 27.0, barW - 150.0, 16.0);
    [_root addSubview:_times];

    _track = [[SVFlipView alloc] initWithFrame:NSMakeRect(kPad, barY, barW, 12.0)];
    _track.fillColor = sv::hairline();
    [_root addSubview:_track];
    _fill = [[SVFlipView alloc] initWithFrame:NSMakeRect(kPad, barY, 0.0, 12.0)];
    _fill.fillColor = sv::copper();
    [_root addSubview:_fill];

    _status = [NSTextField labelWithString:@"Rendering the mix…"];
    _status.font = sv::ui(sv::type::label);
    _status.textColor = sv::inkDim();
    _status.frame = NSMakeRect(kPad, barY + 20.0, barW, 16.0);
    [_root addSubview:_status];

    SVFlipView* footRule = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, footY, kProgressW, 1.0)];
    footRule.fillColor = sv::hairline();
    [_root addSubview:footRule];
    SVFlipView* foot = [[SVFlipView alloc] initWithFrame:NSMakeRect(0, footY + 1.0, kProgressW, 59.0)];
    foot.fillColor = sv::panel();
    [_root addSubview:foot];
    _cancel = [SVButton buttonWithTitle:@"Cancel" target:self action:@selector(cancelPressed:)
                                  frame:NSMakeRect(kProgressW - kPad - 100.0, footY + 17.0, 100.0, 28.0)];
    _cancel.keyEquivalent = @"\033";
    [_root addSubview:_cancel];
}

- (void)cancelPressed:(id)sender {
    (void)sender;
    _cancelled = YES;
    _cancel.enabled = NO;
    _status.stringValue = @"Cancelling…";
}

- (BOOL)windowShouldClose:(id)sender { (void)sender; [self cancelPressed:nil]; return NO; }

- (void)begin {
    _start = std::chrono::steady_clock::now();
    [_window center];
    [_window makeKeyAndOrderFront:nil];
    _session = [NSApp beginModalSessionForWindow:_window];
    _open = YES;
    gProgressActive = YES;
    [NSApp runModalSession:_session];
}

- (BOOL)updateFraction:(double)fraction {
    if (!_open) return YES;
    fraction = std::min(1.0, std::max(0.0, fraction));
    const double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - _start).count();
    const CGFloat barW = kProgressW - 2.0 * kPad;
    _fill.frame = NSMakeRect(kPad, _fill.frame.origin.y, std::round(barW * fraction), 12.0);
    _percent.stringValue = [NSString stringWithFormat:@"%d%%", static_cast<int>(fraction * 100.0)];
    NSString* left = @"calculating the time left…";
    if (fraction >= 0.02 && elapsed >= 1.5) left = [NSString stringWithFormat:@"about %@ left", clockText(elapsed * (1.0 - fraction) / fraction)];
    if (fraction >= 0.999) left = @"finishing the file…";
    _times.stringValue = [NSString stringWithFormat:@"%@ passed  ·  %@", clockText(elapsed), left];
    if (!_cancelled) {
        if (_parts > 1) {
            const NSInteger part = std::min<NSInteger>(_parts, static_cast<NSInteger>(fraction * static_cast<double>(_parts)) + 1);
            _status.stringValue = [NSString stringWithFormat:@"%@ %ld of %ld", _partNoun ?: @"Part", static_cast<long>(part), static_cast<long>(_parts)];
        } else {
            _status.stringValue = @"Rendering the mix at full quality…";
        }
    }
    [_window displayIfNeeded];
    // Lets the window draw and the Cancel button click while the job keeps the main thread busy.
    if ([NSApp runModalSession:_session] != NSModalResponseContinue) _cancelled = YES;
    return !_cancelled;
}

- (void)end {
    if (!_open) return;
    _open = NO;
    gProgressActive = NO;
    [NSApp endModalSession:_session];
    [_window orderOut:nil];
}

@end
