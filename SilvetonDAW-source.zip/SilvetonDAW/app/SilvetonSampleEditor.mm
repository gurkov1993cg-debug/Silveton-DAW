// Silveton — the Sample Editor window.
//
// Shows the audio of the edited clip and the clips that touch it (the "span") as one piece of
// sound: time ruler, waveform that zooms from the whole span down to single samples, range
// selection (with zero-crossing snap), fade handles, an overview strip and read-outs.
// All the maths (zoom, ruler, columns, peaks, zero crossings) lives in SampleEditorModel and the
// editing itself in AudioRangeEdit; this file only draws and turns mouse and keys into those calls.
#import "SilvetonViews.h"
#include "SilvetonTheme.h"

#include "silveton/AudioRangeEdit.h"
#include "silveton/SampleEditorModel.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <memory>
#include <string>
#include <vector>

using namespace silveton;

namespace {

constexpr CGFloat kToolbarH = 32.0;
constexpr CGFloat kRulerH = 24.0;
constexpr CGFloat kGutterW = 52.0;
constexpr CGFloat kOverviewH = 52.0;
constexpr CGFloat kReadoutH = 28.0;
constexpr CGFloat kHandle = 10.0;
constexpr CGFloat kEdgeGrab = 5.0;
constexpr CGFloat kDragThreshold = 3.0;

enum class Drag { None, Select, Scrub, Overview, FadeIn, FadeOut, Pencil };
enum class Tool { ZoomOut, ZoomIn, Fit, ZoomSelection, ZeroSnap, Ripple, SelectAll, Crop, Loop, Pencil };

struct ToolItem {
    Tool tool;
    const char* label;
    NSRect rect;
    bool on;
    bool enabled;
};

// What the editor shows right now: the clips of the span with the data to draw them.
struct PieceSet {
    std::vector<PieceView> views;
    std::vector<ProjectAudioClip> clips;
    std::vector<std::shared_ptr<const WaveformOverview>> overviews;
    std::vector<std::shared_ptr<const WaveformDetail>> details;
    std::size_t channels {1U};
    std::uint32_t fileRate {0U};
    bool detailLoading {false};       // single samples are being read in the background
    bool detailUnavailable {false};   // the zoom needs single samples but the file cannot give them
};

// One point of a pencil stroke: where (view samples) and the value that was drawn there.
struct StrokePoint {
    double rel;
    float value;
};

struct FadeHandle {
    NSRect rect;
    std::uint64_t clipId;
    bool fadeIn;
};

std::int64_t absoluteOf(double rel, std::int64_t origin) { return origin + static_cast<std::int64_t>(std::llround(rel)); }

NSString* dbText(float peak) {
    if (peak < 0.0F) return @"—";
    if (peak < 1.0e-6F) return @"−∞ dBFS";
    const double db = 20.0 * std::log10(static_cast<double>(peak));
    return [NSString stringWithFormat:@"%+.1f dBFS", db];
}

NSString* timeText(double samples, double rate) { return sv::ns(formatClockTime(samples / std::max(1.0, rate))); }

} // namespace

@interface SilvetonSampleView () {
    SampleViewport _vp;
    EditSpan _span;
    std::int64_t _origin;            // timeline sample of view position 0
    long _track;
    BOOL _hasView;
    NSTrackingArea* _tracking;
    Drag _drag;
    double _downX;
    double _anchorRaw;               // where the mouse went down (relative sample)
    double _anchor;                  // fixed end of the selection while it is dragged
    BOOL _moved;
    std::uint64_t _fadeClip;
    double _lastMouseX;
    double _hoverRel;
    BOOL _hovering;
    std::int64_t _lastPlayhead;
    std::vector<std::string> _pendingOverview;
    std::vector<std::string> _pendingDetail;
    std::vector<std::string> _shownMedia;
    TimelineRange _sel;              // the selection as of the last sync (one span walk per event, not one per use)
    TimelineRange _peakKey;
    BOOL _peakKeyDetail;
    float _peakValue;
    BOOL _peakValid;
    BOOL _pencil;                    // draw samples with the mouse (needs the zoom where single samples show)
    std::vector<StrokePoint> _stroke;
    int _strokeChannel;              // channel being drawn, -1 = all
    std::size_t _strokeBand;         // the channel band the mouse went down in (gives the height scale)
    std::size_t _strokeBands;
    double _strokeGain;              // clip gain of the piece (the picture shows gain-scaled samples)
}
@end

@implementation SilvetonSampleView

- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (BOOL)acceptsFirstMouse:(NSEvent*)event { (void)event; return YES; }

- (void)updateTrackingAreas {
    [super updateTrackingAreas];
    if (_tracking) [self removeTrackingArea:_tracking];
    _tracking = [[NSTrackingArea alloc] initWithRect:self.bounds
                                             options:NSTrackingMouseMoved | NSTrackingMouseEnteredAndExited | NSTrackingActiveInKeyWindow | NSTrackingInVisibleRect
                                               owner:self userInfo:nil];
    [self addTrackingArea:_tracking];
}

// ================================================================ geometry ==
- (NSRect)waveRect {
    const NSRect b = self.bounds;
    const CGFloat y = kToolbarH + kRulerH;
    return NSMakeRect(kGutterW, y, std::max<CGFloat>(1.0, b.size.width - kGutterW),
                      std::max<CGFloat>(40.0, b.size.height - y - kOverviewH - kReadoutH - 10.0));
}
- (NSRect)rulerRect { const NSRect w = [self waveRect]; return NSMakeRect(w.origin.x, kToolbarH, w.size.width, kRulerH); }
- (NSRect)overviewRect { const NSRect w = [self waveRect]; return NSMakeRect(w.origin.x, NSMaxY(w) + 6.0, w.size.width, kOverviewH); }
- (NSRect)readoutRect { const NSRect b = self.bounds; return NSMakeRect(0, b.size.height - kReadoutH, b.size.width, kReadoutH); }

- (double)rateOfProject {
    SilvetonController* c = self.controller;
    return c.project && c.project->sampleRate > 0.0 ? c.project->sampleRate : 48000.0;
}

// View x -> relative sample, and back.
- (double)relAtX:(CGFloat)x { return _vp.sampleAtX(x - [self waveRect].origin.x); }
- (CGFloat)xAtRel:(double)rel { return [self waveRect].origin.x + _vp.xAtSample(rel); }

// ================================================================== state ==
- (const ProjectAudioClip*)clipWithId:(std::uint64_t)clipId {
    SilvetonController* c = self.controller;
    if (!c.project || c.selectedTrack < 0 || c.selectedTrack >= static_cast<long>(c.project->tracks.size())) return nullptr;
    for (const auto& clip : c.project->tracks[static_cast<std::size_t>(c.selectedTrack)].clips)
        if (clip.id == clipId) return &clip;
    return nullptr;
}

// Follows the controller: which sound is open, how wide the window is. The zoom survives edits
// (cut, paste, process) as long as the span is still the same piece of the track.
- (BOOL)syncSpan {
    SilvetonController* c = self.controller;
    _sel = TimelineRange {};
    if (!c || !c.project || ![c editedClip]) { _hasView = NO; return NO; }
    const EditSpan span = [c sampleSpan];
    if (span.empty()) { _hasView = NO; return NO; }
    const double width = std::max<double>(1.0, [self waveRect].size.width);
    const long track = c.selectedTrack;
    const bool same = _hasView && track == _track && span.start <= _span.end && span.end >= _span.start;
    if (!same) {
        _vp = SampleViewport {};
        _vp.configure(static_cast<double>(span.length()), width);
        _vp.fitAll();
        _peakValid = NO;
        _lastPlayhead = -1;
    } else {
        const double absFirst = static_cast<double>(_origin) + _vp.first;
        _vp.configure(static_cast<double>(span.length()), width);
        _vp.first = absFirst - static_cast<double>(span.start);
        _vp.clamp();
    }
    _span = span;
    _origin = span.start;
    _track = track;
    _hasView = YES;

    // Only the media of this span keep their decoded samples in memory.
    std::vector<std::string> media;
    for (const std::uint64_t id : span.clipIds)
        if (const ProjectAudioClip* clip = [self clipWithId:id])
            if (std::find(media.begin(), media.end(), clip->audioPath) == media.end()) media.push_back(clip->audioPath);
    std::sort(media.begin(), media.end());
    if (media != _shownMedia) { _shownMedia = media; c.core->waveformCache().releaseDetailsExcept(media); }
    _sel = [c sampleSelection];
    return YES;
}

- (PieceSet)buildPieces {
    PieceSet set;
    SilvetonController* c = self.controller;
    auto& cache = c.core->waveformCache();
    const double rate = [self rateOfProject];
    const BOOL zeroSnap = [c sampleZeroSnap];
    _pendingOverview.clear();
    _pendingDetail.clear();
    for (const std::uint64_t id : _span.clipIds) {
        const ProjectAudioClip* clip = [self clipWithId:id];
        if (clip == nullptr) continue;
        cache.request(clip->audioPath);
        auto overview = cache.find(clip->audioPath);
        auto detail = cache.findDetail(clip->audioPath);
        if (!overview) _pendingOverview.push_back(clip->audioPath);
        if (overview) {
            const double fileSamplesPerPixel = _vp.samplesPerPixel * static_cast<double>(overview->sampleRate) / rate;
            const bool zoomNeeds = fileSamplesPerPixel < static_cast<double>(overview->framesPerPeak);
            if ((zoomNeeds || zeroSnap) && !detail) {
                if (cache.detailFailed(clip->audioPath)) { if (zoomNeeds) set.detailUnavailable = true; }
                else { cache.requestDetail(clip->audioPath); _pendingDetail.push_back(clip->audioPath); set.detailLoading = true; }
            }
            set.channels = std::max<std::size_t>(set.channels, std::min<std::size_t>(2U, overview->channels));
            if (set.fileRate == 0U) set.fileRate = overview->sampleRate;
        } else if (detail) {
            set.channels = std::max<std::size_t>(set.channels, std::min<std::size_t>(2U, detail->audio.channels()));
        }
        set.clips.push_back(*clip);
        set.overviews.push_back(std::move(overview));
        set.details.push_back(std::move(detail));
    }
    for (std::size_t i = 0U; i < set.clips.size(); ++i) {
        const ProjectAudioClip& clip = set.clips[i];
        PieceView v;
        v.startRel = static_cast<double>(clip.timelineStartSample - _origin);
        v.length = static_cast<double>(clip.lengthSamples);
        v.sourceStart = static_cast<double>(clip.sourceStartSample);
        v.projectRate = rate;
        v.overview = set.overviews[i].get();
        v.detail = set.details[i].get();
        set.views.push_back(v);
    }
    return set;
}

- (const PieceView*)pieceAt:(double)rel in:(const PieceSet&)set {
    for (const PieceView& v : set.views) if (rel >= v.startRel && rel <= v.endRel()) return &v;
    return nullptr;
}

// Selection edges jump to where the sound crosses zero (no click at a cut). Needs the real samples.
- (double)snapRel:(double)rel in:(const PieceSet&)set {
    SilvetonController* c = self.controller;
    rel = std::min(std::max(rel, 0.0), static_cast<double>(_span.length()));
    if (![c sampleZeroSnap]) return rel;
    const PieceView* v = [self pieceAt:rel in:set];
    if (v == nullptr) return rel;
    const double reach = std::min(10.0 * _vp.samplesPerPixel, 0.01 * [self rateOfProject]);
    return std::min(std::max(nearestZeroCrossing(*v, rel, std::max(1.0, reach)), 0.0), static_cast<double>(_span.length()));
}

- (float)selectionPeak:(const PieceSet&)set selection:(TimelineRange)sel {
    const BOOL haveDetail = !set.details.empty() && set.details.front() != nullptr;
    if (_peakValid && _peakKey.start == sel.start && _peakKey.end == sel.end && _peakKeyDetail == haveDetail) return _peakValue;
    float peak = -1.0F;
    const double a = static_cast<double>(sel.start - _origin), b = static_cast<double>(sel.end - _origin);
    for (const PieceView& v : set.views) peak = std::max(peak, peakInRange(v, a, b));
    _peakKey = sel; _peakKeyDetail = haveDetail; _peakValue = peak; _peakValid = YES;
    return peak;
}

// ================================================================= toolbar ==
- (std::vector<ToolItem>)toolItems {
    SilvetonController* c = self.controller;
    const bool sel = _sel.valid();
    struct Def { Tool tool; const char* label; bool on; bool enabled; bool gap; };
    const Def defs[] = {
        {Tool::ZoomOut, "Zoom −", false, true, false},
        {Tool::ZoomIn, "Zoom +", false, true, false},
        {Tool::Fit, "Fit", false, true, false},
        {Tool::ZoomSelection, "Zoom Selection", false, sel, false},
        {Tool::ZeroSnap, "Zero Snap", static_cast<bool>([c sampleZeroSnap]), true, true},
        {Tool::Ripple, "Ripple", static_cast<bool>([c sampleRipple]), true, false},
        {Tool::SelectAll, "Select All", false, true, true},
        {Tool::Crop, "Crop", false, sel, false},
        {Tool::Loop, "Loop", false, true, false},
        {Tool::Pencil, "Pencil", static_cast<bool>(_pencil), true, true},
    };
    std::vector<ToolItem> items;
    CGFloat x = 8.0;
    NSFont* font = sv::ui(11, true);
    for (const Def& d : defs) {
        if (d.gap) x += 10.0;
        const CGFloat w = std::ceil(sv::textSize([NSString stringWithUTF8String:d.label], font).width) + 22.0;
        items.push_back({d.tool, d.label, NSMakeRect(x, 4.0, w, kToolbarH - 8.0), d.on, d.enabled});
        x += w + 5.0;
    }
    return items;
}

- (void)performTool:(Tool)tool {
    SilvetonController* c = self.controller;
    switch (tool) {
        case Tool::ZoomOut: [self zoomBy:2.0]; break;
        case Tool::ZoomIn: [self zoomBy:0.5]; break;
        case Tool::Fit: [self zoomFit]; break;
        case Tool::ZoomSelection: [self zoomToSelection]; break;
        case Tool::ZeroSnap: [c toggleSampleZeroSnap:nil]; break;
        case Tool::Ripple: [c toggleSampleRipple:nil]; break;
        case Tool::SelectAll: [c sampleSelectAll:nil]; break;
        case Tool::Crop: [c sampleCropToSelection:nil]; break;
        case Tool::Loop: [c sampleLoopSelection:nil]; break;
        case Tool::Pencil: _pencil = !_pencil; break;
    }
    [self setNeedsDisplay:YES];
}

- (void)drawToolbar:(NSRect)dirty set:(const PieceSet&)set {
    const NSRect bar = NSMakeRect(0, 0, self.bounds.size.width, kToolbarH);
    if (!NSIntersectsRect(dirty, bar)) return;
    sv::fill(bar, sv::hex(0x2B2E35));
    NSFont* font = sv::ui(11, true);
    CGFloat right = 8.0;
    for (const ToolItem& item : [self toolItems]) {
        NSColor* back = item.on ? sv::copper() : sv::raised();
        sv::roundFill(item.rect, 3.0, back);
        NSColor* ink = !item.enabled ? sv::inkFaint() : (item.on ? sv::canvas() : sv::ink());
        sv::textIn([NSString stringWithUTF8String:item.label], NSMakeRect(item.rect.origin.x, item.rect.origin.y + 5.0, item.rect.size.width, 16.0), font, ink,
                   NSTextAlignmentCenter);
        right = NSMaxX(item.rect);
    }
    // What is open: file, layout, rates.
    if (!set.clips.empty()) {
        const ProjectAudioClip& first = set.clips.front();
        NSString* name = [sv::ns(first.audioPath) lastPathComponent];
        NSString* layout = set.channels > 1U ? @"Stereo" : @"Mono";
        NSString* rates = set.fileRate > 0U && std::abs(static_cast<double>(set.fileRate) - [self rateOfProject]) > 0.5
            ? [NSString stringWithFormat:@"file %.1f kHz → project %.1f kHz", set.fileRate / 1000.0, [self rateOfProject] / 1000.0]
            : [NSString stringWithFormat:@"%.1f kHz", [self rateOfProject] / 1000.0];
        NSString* info = [NSString stringWithFormat:@"%@  ·  %@  ·  %@  ·  %lu piece%s", name, layout, rates,
                          (unsigned long)set.clips.size(), set.clips.size() == 1U ? "" : "s"];
        const CGFloat x = right + 16.0;
        sv::textIn(info, NSMakeRect(x, 8.0, std::max<CGFloat>(10.0, bar.size.width - x - 10.0), 16.0), sv::ui(11), sv::inkDim(), NSTextAlignmentRight);
    }
}

// =================================================================== ruler ==
- (void)drawRuler:(NSRect)ruler dirty:(NSRect)dirty {
    const NSRect full = NSMakeRect(0, ruler.origin.y, self.bounds.size.width, ruler.size.height);
    if (!NSIntersectsRect(dirty, full)) return;
    sv::fill(full, sv::panel());
    sv::line(NSMakePoint(0, NSMaxY(ruler) - 0.5), NSMakePoint(NSMaxX(ruler), NSMaxY(ruler) - 0.5), sv::hairline());
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(ruler);
    const auto ticks = buildRuler(_vp, [self rateOfProject], 96.0, static_cast<double>(_origin));
    for (const RulerTick& t : ticks) {
        const CGFloat x = std::floor(ruler.origin.x + _vp.xAtSample(t.sample)) + 0.5;
        if (x < ruler.origin.x - 1.0 || x > NSMaxX(ruler) + 1.0) continue;
        sv::line(NSMakePoint(x, NSMaxY(ruler) - (t.major ? 11.0 : 5.0)), NSMakePoint(x, NSMaxY(ruler)), sv::inkFaint());
        if (t.major && !t.label.empty()) sv::text(sv::ns(t.label), NSMakePoint(x + 4.0, ruler.origin.y + 3.0), sv::mono(10), sv::inkDim());
    }
    // Selection bar under the numbers.
    const TimelineRange sel = _sel;
    if (sel.valid()) {
        const CGFloat a = [self xAtRel:static_cast<double>(sel.start - _origin)], b = [self xAtRel:static_cast<double>(sel.end - _origin)];
        sv::fill(NSMakeRect(a, NSMaxY(ruler) - 4.0, std::max<CGFloat>(1.0, b - a), 4.0), sv::copper());
    }
    [NSGraphicsContext restoreGraphicsState];
}

// ==================================================================== wave ==
- (std::vector<FadeHandle>)fadeHandles:(const PieceSet&)set {
    std::vector<FadeHandle> handles;
    const NSRect wave = [self waveRect];
    const CGFloat top = wave.origin.y + 3.0;
    for (const ProjectAudioClip& clip : set.clips) {
        const ClipFadeGeometry g = AudioRangeEdit::fadeGeometry(clip);
        const CGFloat xIn = [self xAtRel:g.fadeInEnd - static_cast<double>(_origin)];
        const CGFloat xOut = [self xAtRel:g.fadeOutStart - static_cast<double>(_origin)];
        handles.push_back({NSMakeRect(xIn, top, kHandle, kHandle), clip.id, true});
        handles.push_back({NSMakeRect(xOut - kHandle, top, kHandle, kHandle), clip.id, false});
    }
    return handles;
}

- (void)drawAmplitudeScale:(NSRect)wave channels:(std::size_t)channels {
    const CGFloat bandH = wave.size.height / static_cast<CGFloat>(channels);
    NSFont* font = sv::mono(10);
    for (std::size_t ch = 0U; ch < channels; ++ch) {
        const CGFloat center = wave.origin.y + bandH * (static_cast<CGFloat>(ch) + 0.5);
        const CGFloat amp = bandH * 0.46;
        struct Mark { double level; const char* text; };
        const Mark marks[] = {{1.0, "0 dB"}, {0.5, "−6"}, {0.0, "−∞"}, {-0.5, "−6"}, {-1.0, "0 dB"}};
        const bool roomy = bandH >= 110.0;
        for (const Mark& m : marks) {
            if (!roomy && std::abs(m.level) == 0.5) continue;
            const CGFloat y = center - static_cast<CGFloat>(m.level) * amp;
            sv::line(NSMakePoint(kGutterW - 5.0, y), NSMakePoint(kGutterW, y), sv::inkFaint());
            if (m.level < 0.0 && !roomy && m.level != -1.0) continue;
            sv::textIn([NSString stringWithUTF8String:m.text], NSMakeRect(0, y - 6.0 + (m.level > 0.9 ? 6.0 : (m.level < -0.9 ? -6.0 : 0.0)), kGutterW - 8.0, 12.0),
                       font, sv::inkFaint(), NSTextAlignmentRight);
        }
        if (channels > 1U) sv::text(ch == 0U ? @"L" : @"R", NSMakePoint(6.0, center - 7.0), sv::ui(11, true), sv::inkDim());
    }
}

- (void)drawPiece:(const PieceView&)v clip:(const ProjectAudioClip&)clip channels:(std::size_t)channels wave:(NSRect)wave dirty:(NSRect)dirty {
    const double x0 = _vp.xAtSample(v.startRel), x1 = _vp.xAtSample(v.endRel());
    const double dirtyA = std::max(0.0, dirty.origin.x - wave.origin.x - 2.0);
    const double dirtyB = std::min<double>(wave.size.width, NSMaxX(dirty) - wave.origin.x + 2.0);
    const double visA = std::max(x0, dirtyA), visB = std::min(x1, dirtyB);
    if (visB <= visA) return;
    const std::size_t firstColumn = static_cast<std::size_t>(std::floor(visA));
    const std::size_t columns = static_cast<std::size_t>(std::max(1.0, std::ceil(visB) - std::floor(visA)));
    const CGFloat bandH = wave.size.height / static_cast<CGFloat>(channels);
    const CGFloat amp = bandH * 0.46;
    const float gain = static_cast<float>(std::pow(10.0, static_cast<double>(clip.gainDb) / 20.0));
    NSColor* color = clip.mute ? sv::inkFaint() : sv::copper();
    const double pxPerSample = pixelsPerFileSample(v, _vp);
    std::vector<ColumnPeak> peaks;
    for (std::size_t ch = 0U; ch < channels; ++ch) {
        const CGFloat center = wave.origin.y + bandH * (static_cast<CGFloat>(ch) + 0.5);
        if (v.detail != nullptr && pxPerSample >= 2.0 && v.detail->audio.frames() > 0U) {
            // Single samples: a line through them, with a dot (and a stem) on each when there is room.
            const auto& audio = v.detail->audio;
            const float* data = audio.channelData(std::min<std::size_t>(ch, audio.channels() - 1U));
            const double relA = std::max(_vp.sampleAtX(visA), v.startRel), relB = std::min(_vp.sampleAtX(visB), v.endRel());
            const long long frames = static_cast<long long>(audio.frames());
            long long n0 = std::max<long long>(static_cast<long long>(std::floor(v.nativePosition(relA))) - 1,
                                               static_cast<long long>(std::ceil(v.nativePosition(v.startRel))));
            long long n1 = std::min<long long>(static_cast<long long>(std::ceil(v.nativePosition(relB))) + 1,
                                               static_cast<long long>(std::floor(v.nativePosition(v.endRel()))));
            n0 = std::max<long long>(0, n0);
            n1 = std::min<long long>(frames - 1, n1);
            if (n1 < n0) continue;
            NSBezierPath* path = [NSBezierPath bezierPath];
            path.lineWidth = 1.4;
            NSBezierPath* dots = [NSBezierPath bezierPath];
            NSBezierPath* stems = [NSBezierPath bezierPath];
            bool started = false;
            for (long long n = n0; n <= n1; ++n) {
                const double value = std::min(1.0, std::max(-1.0, static_cast<double>(data[n]) * gain));
                const CGFloat x = wave.origin.x + _vp.xAtSample(v.relPosition(static_cast<double>(n)));
                const CGFloat y = center - static_cast<CGFloat>(value) * amp;
                if (!started) { [path moveToPoint:NSMakePoint(x, y)]; started = true; } else [path lineToPoint:NSMakePoint(x, y)];
                if (pxPerSample >= 7.0) {
                    [dots appendBezierPath:[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(x - 2.5, y - 2.5, 5.0, 5.0)]];
                    [stems moveToPoint:NSMakePoint(x, center)];
                    [stems lineToPoint:NSMakePoint(x, y)];
                }
            }
            if (pxPerSample >= 7.0) { [sv::inkFaint() setStroke]; stems.lineWidth = 1.0; [stems stroke]; }
            [color setStroke];
            [path stroke];
            if (pxPerSample >= 7.0) { [color setFill]; [dots fill]; }
            continue;
        }
        columnPeaks(v, _vp, ch, firstColumn, columns, peaks);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.0;
        NSBezierPath* over = [NSBezierPath bezierPath];   // clipped peaks
        over.lineWidth = 1.0;
        for (std::size_t i = 0U; i < columns; ++i) {
            if (!peaks[i].valid) continue;
            const CGFloat x = wave.origin.x + static_cast<CGFloat>(firstColumn + i) + 0.5;
            const float mx = peaks[i].maximum * gain, mn = peaks[i].minimum * gain;
            CGFloat yTop = center - static_cast<CGFloat>(std::min(1.0F, mx)) * amp;
            CGFloat yBottom = center - static_cast<CGFloat>(std::max(-1.0F, mn)) * amp;
            if (yBottom - yTop < 1.0) { yTop -= 0.5; yBottom += 0.5; }
            [path moveToPoint:NSMakePoint(x, yTop)];
            [path lineToPoint:NSMakePoint(x, yBottom)];
            if (mx >= 0.999F) { [over moveToPoint:NSMakePoint(x, yTop)]; [over lineToPoint:NSMakePoint(x, yTop + 3.0)]; }
            if (mn <= -0.999F) { [over moveToPoint:NSMakePoint(x, yBottom)]; [over lineToPoint:NSMakePoint(x, yBottom - 3.0)]; }
        }
        [color setStroke];
        [path stroke];
        [sv::rec() setStroke];
        [over stroke];
    }
}

- (void)drawFades:(const PieceSet&)set wave:(NSRect)wave {
    const CGFloat bottom = NSMaxY(wave) - 3.0, height = wave.size.height - 6.0;
    NSBezierPath* path = [NSBezierPath bezierPath];
    path.lineWidth = 1.5;
    for (const ProjectAudioClip& clip : set.clips) {
        const double start = static_cast<double>(clip.timelineStartSample);
        const double end = start + static_cast<double>(clip.lengthSamples);
        const ClipFadeGeometry g = AudioRangeEdit::fadeGeometry(clip);
        auto curve = [&](double from, double to) {
            const CGFloat xa = [self xAtRel:from - static_cast<double>(_origin)], xb = [self xAtRel:to - static_cast<double>(_origin)];
            if (xb < wave.origin.x - 4.0 || xa > NSMaxX(wave) + 4.0 || to <= from) return;
            const int steps = static_cast<int>(std::min(96.0, std::max(8.0, (xb - xa) / 3.0)));
            for (int k = 0; k <= steps; ++k) {
                const double t = from + (to - from) * static_cast<double>(k) / static_cast<double>(steps);
                const double gain = AudioRangeEdit::fadeGain(clip, std::min(t, end - 1.0e-6));
                const NSPoint p = NSMakePoint([self xAtRel:t - static_cast<double>(_origin)], bottom - static_cast<CGFloat>(gain) * height);
                if (k == 0) [path moveToPoint:p]; else [path lineToPoint:p];
            }
        };
        if (clip.fadeInSamples != 0U) curve(start, g.fadeInEnd);
        if (clip.fadeOutSamples != 0U) curve(g.fadeOutStart, end);
    }
    [sv::amber() setStroke];
    [path stroke];
    for (const FadeHandle& h : [self fadeHandles:set]) {
        if (NSMaxX(h.rect) < wave.origin.x || h.rect.origin.x > NSMaxX(wave)) continue;
        const ProjectAudioClip* clip = nullptr;
        for (const ProjectAudioClip& cl : set.clips) if (cl.id == h.clipId) { clip = &cl; break; }
        const bool active = clip != nullptr && (h.fadeIn ? clip->fadeInSamples : clip->fadeOutSamples) != 0U;
        sv::roundFill(h.rect, 2.0, active ? sv::amber() : sv::raisedHi());
        sv::roundStroke(h.rect, 2.0, sv::amber(), 1.0);
    }
}

- (void)drawWave:(NSRect)wave set:(const PieceSet&)set dirty:(NSRect)dirty {
    const NSRect full = NSMakeRect(0, wave.origin.y, NSMaxX(wave), wave.size.height);
    if (!NSIntersectsRect(dirty, full)) return;
    SilvetonController* c = self.controller;
    const std::size_t channels = std::max<std::size_t>(1U, set.channels);
    sv::fill(NSMakeRect(0, wave.origin.y, kGutterW, wave.size.height), sv::panel());
    sv::fill(wave, sv::hex(0x121317));
    [self drawAmplitudeScale:wave channels:channels];

    [NSGraphicsContext saveGraphicsState];
    NSRectClip(wave);
    const CGFloat bandH = wave.size.height / static_cast<CGFloat>(channels);
    for (std::size_t ch = 0U; ch < channels; ++ch) {
        const CGFloat center = wave.origin.y + bandH * (static_cast<CGFloat>(ch) + 0.5);
        const CGFloat amp = bandH * 0.46;
        sv::line(NSMakePoint(wave.origin.x, std::floor(center) + 0.5), NSMakePoint(NSMaxX(wave), std::floor(center) + 0.5), sv::hex(0x383C44));
        for (const double level : {0.5, -0.5}) {
            const CGFloat y = std::floor(center - static_cast<CGFloat>(level) * amp) + 0.5;
            sv::line(NSMakePoint(wave.origin.x, y), NSMakePoint(NSMaxX(wave), y), sv::hex(0x23262C));
        }
        if (ch > 0U) sv::line(NSMakePoint(wave.origin.x, wave.origin.y + bandH * static_cast<CGFloat>(ch)), NSMakePoint(NSMaxX(wave), wave.origin.y + bandH * static_cast<CGFloat>(ch)), sv::hairline(), 2.0);
    }

    for (std::size_t i = 0U; i < set.views.size(); ++i) [self drawPiece:set.views[i] clip:set.clips[i] channels:channels wave:wave dirty:dirty];

    // Where one piece ends and the next begins.
    for (std::size_t i = 1U; i < set.views.size(); ++i) {
        const CGFloat x = std::floor([self xAtRel:set.views[i].startRel]) + 0.5;
        if (x < wave.origin.x || x > NSMaxX(wave)) continue;
        sv::line(NSMakePoint(x, wave.origin.y), NSMakePoint(x, NSMaxY(wave)), sv::hex(0x5A5E68), 1.0);
    }
    [self drawFades:set wave:wave];
    [self drawStroke:wave];

    // The selected part.
    const TimelineRange sel = _sel;
    if (sel.valid()) {
        const CGFloat a = [self xAtRel:static_cast<double>(sel.start - _origin)], b = [self xAtRel:static_cast<double>(sel.end - _origin)];
        NSRect r = NSMakeRect(a, wave.origin.y, std::max<CGFloat>(1.0, b - a), wave.size.height);
        [[sv::copper() colorWithAlphaComponent:0.24] setFill];
        [[NSBezierPath bezierPathWithRect:r] fill];
        sv::line(NSMakePoint(std::floor(a) + 0.5, wave.origin.y), NSMakePoint(std::floor(a) + 0.5, NSMaxY(wave)), sv::copper(), 1.5);
        sv::line(NSMakePoint(std::floor(b) + 0.5, wave.origin.y), NSMakePoint(std::floor(b) + 0.5, NSMaxY(wave)), sv::copper(), 1.5);
    }

    // Playhead (also the cursor where Paste goes when nothing is selected).
    const double playRel = static_cast<double>([c playheadSample] - _origin);
    const CGFloat px = std::floor([self xAtRel:playRel]) + 0.5;
    if (px >= wave.origin.x - 1.0 && px <= NSMaxX(wave) + 1.0) sv::line(NSMakePoint(px, wave.origin.y), NSMakePoint(px, NSMaxY(wave)), sv::rec(), 1.5);

    // Messages over the waveform.
    NSString* note = nil;
    if (!_pendingOverview.empty()) note = @"Building waveform…";
    else if (set.detailUnavailable) note = @"This file is too long to show single samples — zoom out, or split it first";
    else if (_pencil && ![self pencilCanDraw:set]) note = @"Pencil is on — zoom in until you see the single samples, then drag to draw (⌥ draws both channels)";
    else if (set.detailLoading && _vp.samplesPerPixel < 64.0) note = @"Reading the samples… (the zoomed-in picture sharpens in a moment)";
    if (note) sv::textIn(note, NSMakeRect(wave.origin.x + 12.0, wave.origin.y + 8.0, wave.size.width - 24.0, 16.0), sv::ui(11, true), sv::amber());
    [NSGraphicsContext restoreGraphicsState];

    // Playhead triangle in the ruler.
    if (px >= wave.origin.x - 1.0 && px <= NSMaxX(wave) + 1.0) {
        const NSRect ruler = [self rulerRect];
        NSBezierPath* tri = [NSBezierPath bezierPath];
        [tri moveToPoint:NSMakePoint(px - 5.0, ruler.origin.y + 1.0)];
        [tri lineToPoint:NSMakePoint(px + 5.0, ruler.origin.y + 1.0)];
        [tri lineToPoint:NSMakePoint(px, ruler.origin.y + 9.0)];
        [tri closePath];
        [sv::rec() setFill];
        [tri fill];
    }
}

// ================================================================ overview ==
- (void)drawOverview:(NSRect)ov set:(const PieceSet&)set dirty:(NSRect)dirty {
    if (!NSIntersectsRect(dirty, NSMakeRect(0, ov.origin.y, self.bounds.size.width, ov.size.height))) return;
    sv::fill(NSMakeRect(0, ov.origin.y, self.bounds.size.width, ov.size.height), sv::canvas());
    sv::fill(ov, sv::hex(0x121317));
    sv::text(@"OVERVIEW", NSMakePoint(8.0, ov.origin.y + 6.0), sv::ui(10, true), sv::inkFaint());

    SampleViewport whole;
    whole.configure(static_cast<double>(_span.length()), ov.size.width);
    whole.fitAll();
    const std::size_t channels = std::max<std::size_t>(1U, set.channels);
    const CGFloat bandH = ov.size.height / static_cast<CGFloat>(channels);
    std::vector<ColumnPeak> peaks;
    const std::size_t columns = static_cast<std::size_t>(std::max(1.0, std::floor(ov.size.width)));
    for (std::size_t ch = 0U; ch < channels; ++ch) {
        const CGFloat center = ov.origin.y + bandH * (static_cast<CGFloat>(ch) + 0.5);
        const CGFloat amp = bandH * 0.44;
        NSBezierPath* path = [NSBezierPath bezierPath];
        for (const PieceView& piece : set.views) {
            PieceView coarse = piece;
            coarse.detail = nullptr;   // the overview strip is always drawn from the envelope
            columnPeaks(coarse, whole, ch, 0U, columns, peaks);
            for (std::size_t i = 0U; i < columns; ++i) {
                if (!peaks[i].valid) continue;
                const CGFloat x = ov.origin.x + static_cast<CGFloat>(i) + 0.5;
                CGFloat yTop = center - peaks[i].maximum * amp, yBottom = center - peaks[i].minimum * amp;
                if (yBottom - yTop < 1.0) { yTop -= 0.5; yBottom += 0.5; }
                [path moveToPoint:NSMakePoint(x, yTop)];
                [path lineToPoint:NSMakePoint(x, yBottom)];
            }
        }
        [sv::inkDim() setStroke];
        [path stroke];
    }
    SilvetonController* c = self.controller;
    const TimelineRange sel = _sel;
    if (sel.valid()) {
        const CGFloat a = ov.origin.x + whole.xAtSample(static_cast<double>(sel.start - _origin)), b = ov.origin.x + whole.xAtSample(static_cast<double>(sel.end - _origin));
        [[sv::copper() colorWithAlphaComponent:0.30] setFill];
        [[NSBezierPath bezierPathWithRect:NSMakeRect(a, ov.origin.y, std::max<CGFloat>(1.0, b - a), ov.size.height)] fill];
    }
    // The part the waveform shows now.
    const CGFloat va = ov.origin.x + whole.xAtSample(_vp.first), vb = ov.origin.x + whole.xAtSample(_vp.first + _vp.visibleSamples());
    const NSRect window = NSMakeRect(va, ov.origin.y, std::max<CGFloat>(3.0, std::min(vb, NSMaxX(ov)) - va), ov.size.height);
    [[NSColor colorWithCalibratedWhite:1.0 alpha:0.10] setFill];
    [[NSBezierPath bezierPathWithRect:window] fill];
    sv::roundStroke(window, 2.0, sv::amber(), 1.5);
    const CGFloat px = std::floor(ov.origin.x + whole.xAtSample(static_cast<double>([c playheadSample] - _origin))) + 0.5;
    if (px >= ov.origin.x && px <= NSMaxX(ov)) sv::line(NSMakePoint(px, ov.origin.y), NSMakePoint(px, NSMaxY(ov)), sv::rec(), 1.5);
}

// ================================================================= read-out ==
- (void)drawReadout:(NSRect)bar set:(const PieceSet&)set dirty:(NSRect)dirty {
    if (!NSIntersectsRect(dirty, bar)) return;
    sv::fill(bar, sv::hex(0x2B2E35));
    SilvetonController* c = self.controller;
    const double rate = [self rateOfProject];
    NSFont* font = sv::mono(11, true);
    const TimelineRange sel = _sel;
    NSString* left;
    if (sel.valid()) {
        const float peak = _drag == Drag::None ? [self selectionPeak:set selection:sel] : -2.0F;
        left = [NSString stringWithFormat:@"Selection  %@ – %@     Length %@  (%lld samples)     Peak %@",
                timeText(static_cast<double>(sel.start), rate), timeText(static_cast<double>(sel.end), rate), timeText(static_cast<double>(sel.length()), rate),
                (long long)sel.length(), peak == -2.0F ? @"…" : dbText(peak)];
    } else {
        const std::int64_t pos = [c playheadSample];
        left = [NSString stringWithFormat:@"Cursor  %@  (sample %lld)", timeText(static_cast<double>(pos), rate), (long long)pos];
    }
    sv::textIn(left, NSMakeRect(10.0, 6.0, bar.size.width * 0.66, 16.0), font, sv::ink());

    NSString* right = @"";
    if (!set.views.empty()) {
        const double pps = pixelsPerFileSample(set.views.front(), _vp);
        NSString* zoom = pps >= 1.0 ? [NSString stringWithFormat:@"%.1f px per sample", pps]
                                    : [NSString stringWithFormat:@"%.0f samples per px", 1.0 / pps];
        right = zoom;
        if (_hovering) {
            const PieceView* v = [self pieceAt:_hoverRel in:set];
            NSString* level = @"";
            if (v != nullptr) {
                const float peak = peakInRange(*v, _hoverRel - _vp.samplesPerPixel * 0.5, _hoverRel + _vp.samplesPerPixel * 0.5);
                if (peak >= 0.0F) level = [@"  " stringByAppendingString:dbText(peak)];
            }
            right = [NSString stringWithFormat:@"%@%@     %@", timeText(static_cast<double>(_origin) + _hoverRel, rate), level, zoom];
        }
    }
    sv::textIn(right, NSMakeRect(bar.size.width * 0.5, 6.0, bar.size.width * 0.5 - 10.0, 16.0), font, sv::inkDim(), NSTextAlignmentRight);
}

// =================================================================== draw ==
- (void)drawRect:(NSRect)dirty {
    const NSRect b = self.bounds;
    sv::fill(dirty, sv::canvas());
    SilvetonController* c = self.controller;
    if (!c || ![self syncSpan]) {
        sv::textIn(@"Select an audio clip in the Project window, then open it here (Return)",
                   NSMakeRect(0, b.size.height * 0.45, b.size.width, 20.0), sv::ui(13, true), sv::inkDim(), NSTextAlignmentCenter);
        return;
    }
    const PieceSet set = [self buildPieces];
    [self drawToolbar:dirty set:set];
    [self drawRuler:[self rulerRect] dirty:dirty];
    [self drawWave:[self waveRect] set:set dirty:dirty];
    [self drawOverview:[self overviewRect] set:set dirty:dirty];
    [self drawReadout:[self readoutRect] set:set dirty:dirty];
}

// =================================================================== zoom ==
- (void)selectionChanged { _peakValid = NO; [self setNeedsDisplay:YES]; }

- (void)zoomBy:(double)factor {
    if (![self syncSpan]) return;
    const NSRect wave = [self waveRect];
    _vp.zoomAbout(wave.size.width * 0.5, factor);
    [self setNeedsDisplay:YES];
}
- (void)zoomFit { if (![self syncSpan]) return; _vp.fitAll(); [self setNeedsDisplay:YES]; }
- (void)zoomToSelection {
    if (![self syncSpan]) return;
    const TimelineRange sel = _sel;
    if (!sel.valid()) return;
    _vp.zoomToRange(static_cast<double>(sel.start - _origin), static_cast<double>(sel.end - _origin));
    [self setNeedsDisplay:YES];
}

- (void)centerOnX:(CGFloat)x inOverview:(NSRect)ov {
    const double rel = (x - ov.origin.x) / std::max(1.0, ov.size.width) * static_cast<double>(_span.length());
    _vp.first = rel - _vp.visibleSamples() * 0.5;
    _vp.clamp();
}

// ================================================================== timer ==
- (void)invalidatePlayheadAt:(std::int64_t)pos {
    const NSRect wave = [self waveRect], ov = [self overviewRect];
    const double rel = static_cast<double>(pos - _origin);
    const CGFloat x = [self xAtRel:rel];
    if (x >= wave.origin.x - 8.0 && x <= NSMaxX(wave) + 8.0)
        [self setNeedsDisplayInRect:NSMakeRect(x - 7.0, kToolbarH, 14.0, NSMaxY(wave) - kToolbarH)];
    const CGFloat ox = ov.origin.x + rel / std::max(1.0, static_cast<double>(_span.length())) * ov.size.width;
    [self setNeedsDisplayInRect:NSMakeRect(ox - 4.0, ov.origin.y, 8.0, ov.size.height)];
}

- (void)tick {
    SilvetonController* c = self.controller;
    if (!c || !c.core || !c.core->ready() || ![self syncSpan]) return;
    auto& cache = c.core->waveformCache();
    bool arrived = false;
    for (const auto& path : _pendingOverview) if (cache.find(path) || cache.failed(path)) arrived = true;
    for (const auto& path : _pendingDetail) if (cache.findDetail(path) || cache.detailFailed(path)) arrived = true;
    if (arrived) { [self setNeedsDisplay:YES]; return; }

    const std::int64_t pos = [c playheadSample];
    const double rel = static_cast<double>(pos - _origin);
    const bool playing = c.core->engine().transport().isPlaying();
    if (playing && _drag == Drag::None && rel >= 0.0 && rel <= static_cast<double>(_span.length())) {
        const double before = _vp.first;
        _vp.ensureVisible(rel);   // page turn
        if (_vp.first != before) { _lastPlayhead = pos; [self setNeedsDisplay:YES]; return; }
    }
    if (pos != _lastPlayhead) {
        if (_lastPlayhead >= 0) [self invalidatePlayheadAt:_lastPlayhead];
        [self invalidatePlayheadAt:pos];
        [self setNeedsDisplayInRect:[self readoutRect]];
        _lastPlayhead = pos;
    }
    if (_drag == Drag::Select) [self autoScrollWhileSelecting];
}

// While a selection is dragged past the edge of the window the view keeps scrolling.
- (void)autoScrollWhileSelecting {
    const NSRect wave = [self waveRect];
    const NSPoint mouse = [self convertPoint:[self.window mouseLocationOutsideOfEventStream] fromView:nil];
    CGFloat over = 0.0;
    if (mouse.x < wave.origin.x) over = mouse.x - wave.origin.x;
    else if (mouse.x > NSMaxX(wave)) over = mouse.x - NSMaxX(wave);
    if (over == 0.0) return;
    const CGFloat speed = std::min<CGFloat>(60.0, std::max<CGFloat>(3.0, std::abs(over) / 3.0));
    _vp.scrollPixels(over < 0.0 ? -speed : speed);
    [self updateSelectionAtX:std::min(std::max(mouse.x, wave.origin.x), NSMaxX(wave))];
    [self setNeedsDisplay:YES];
}

// ================================================================== mouse ==
- (void)updateSelectionAtX:(CGFloat)x {
    SilvetonController* c = self.controller;
    const PieceSet set = [self buildPieces];
    const double current = [self snapRel:[self relAtX:x] in:set];
    const double lo = std::min(_anchor, current), hi = std::max(_anchor, current);
    c.sampleSelection = TimelineRange {absoluteOf(lo, _origin), absoluteOf(hi, _origin)};
}

- (NSInteger)fadeHandleIndexAt:(NSPoint)p in:(const std::vector<FadeHandle>&)handles {
    NSInteger best = -1;
    CGFloat bestDistance = 1.0e9;
    for (NSUInteger i = 0U; i < handles.size(); ++i) {
        if (!NSPointInRect(p, NSInsetRect(handles[i].rect, -3.0, -3.0))) continue;
        const CGFloat d = std::abs(p.x - NSMidX(handles[i].rect));
        if (d < bestDistance) { bestDistance = d; best = static_cast<NSInteger>(i); }
    }
    return best;
}

// ================================================================= pencil ==
// True when the picture shows single samples (at least 2 pixels per sample) - the pencil only draws then.
- (BOOL)pencilCanDraw:(const PieceSet&)set {
    for (const PieceView& v : set.views)
        if (v.detail != nullptr && v.detail->audio.frames() > 0U && pixelsPerFileSample(v, _vp) >= 2.0) return YES;
    return NO;
}

- (void)addStrokePoint:(NSPoint)p {
    const NSRect wave = [self waveRect];
    const double rel = std::min(std::max([self relAtX:p.x], 0.0), static_cast<double>(_span.length()));
    const CGFloat bandH = wave.size.height / static_cast<CGFloat>(_strokeBands);
    const CGFloat center = wave.origin.y + bandH * (static_cast<CGFloat>(_strokeBand) + 0.5);
    const double shown = static_cast<double>(center - p.y) / static_cast<double>(bandH * 0.46);   // -1..1 as drawn
    const float value = static_cast<float>(std::min(1.0, std::max(-1.0, shown / _strokeGain)));
    if (!_stroke.empty() && _stroke.back().rel == rel && _stroke.back().value == value) return;
    _stroke.push_back({rel, value});
}

- (void)beginStrokeAt:(NSPoint)p event:(NSEvent*)event set:(const PieceSet&)set {
    const NSRect wave = [self waveRect];
    const double rel = std::min(std::max([self relAtX:p.x], 0.0), static_cast<double>(_span.length()));
    const PieceView* v = [self pieceAt:rel in:set];
    if (v == nullptr || v->detail == nullptr || pixelsPerFileSample(*v, _vp) < 2.0) {
        [self.controller setStatus:@"Pencil: zoom in until the single samples show (Zoom + or ⌥ and scroll)"];
        return;
    }
    _strokeBands = std::max<std::size_t>(1U, set.channels);
    const CGFloat bandH = wave.size.height / static_cast<CGFloat>(_strokeBands);
    _strokeBand = std::min<std::size_t>(_strokeBands - 1U, static_cast<std::size_t>(std::max<double>(0.0, std::floor((p.y - wave.origin.y) / bandH))));
    const bool everyChannel = _strokeBands == 1U || (event.modifierFlags & NSEventModifierFlagOption) != 0;
    _strokeChannel = everyChannel ? -1 : static_cast<int>(_strokeBand);
    const std::size_t index = static_cast<std::size_t>(v - set.views.data());
    _strokeGain = std::max(1.0e-3, std::pow(10.0, static_cast<double>(set.clips[index].gainDb) / 20.0));
    _stroke.clear();
    _drag = Drag::Pencil;
    [self addStrokePoint:p];
    [self setNeedsDisplay:YES];
}

// The mouse went up: turn the stroke into one value per sample and hand it to the controller.
- (void)commitStroke {
    if (_stroke.empty()) return;
    double lo = _stroke.front().rel, hi = _stroke.front().rel;
    for (const StrokePoint& s : _stroke) { lo = std::min(lo, s.rel); hi = std::max(hi, s.rel); }
    std::int64_t first = static_cast<std::int64_t>(std::ceil(lo)), last = static_cast<std::int64_t>(std::floor(hi));
    if (last < first) first = last = static_cast<std::int64_t>(std::llround(_stroke.front().rel));   // a click between two samples
    std::vector<float> values(static_cast<std::size_t>(last - first + 1), _stroke.front().value);
    if (_stroke.size() == 1U) {
        values.assign(1U, _stroke.front().value);
    } else {
        for (std::size_t i = 1U; i < _stroke.size(); ++i) {   // a straight line between neighbouring points; later ones win
            const StrokePoint a = _stroke[i - 1U], b = _stroke[i];
            const std::int64_t s0 = static_cast<std::int64_t>(std::ceil(std::min(a.rel, b.rel))), s1 = static_cast<std::int64_t>(std::floor(std::max(a.rel, b.rel)));
            for (std::int64_t s = std::max(s0, first); s <= std::min(s1, last); ++s) {
                const double t = b.rel == a.rel ? 1.0 : (static_cast<double>(s) - a.rel) / (b.rel - a.rel);
                values[static_cast<std::size_t>(s - first)] = static_cast<float>(a.value + t * (b.value - a.value));
            }
        }
    }
    const int channel = _strokeChannel;
    _stroke.clear();
    [self.controller sampleDrawValues:values start:absoluteOf(static_cast<double>(first), _origin) channel:channel];
}

// The line being drawn, over the waveform.
- (void)drawStroke:(NSRect)wave {
    if (_drag != Drag::Pencil || _stroke.empty()) return;
    const CGFloat bandH = wave.size.height / static_cast<CGFloat>(_strokeBands);
    const CGFloat amp = bandH * 0.46;
    for (std::size_t band = 0U; band < _strokeBands; ++band) {
        if (_strokeChannel >= 0 && band != _strokeBand) continue;
        const CGFloat center = wave.origin.y + bandH * (static_cast<CGFloat>(band) + 0.5);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 2.0;
        for (std::size_t i = 0U; i < _stroke.size(); ++i) {
            const NSPoint pt = NSMakePoint([self xAtRel:_stroke[i].rel], center - static_cast<CGFloat>(_stroke[i].value * _strokeGain) * amp);
            if (i == 0U) [path moveToPoint:pt]; else [path lineToPoint:pt];
        }
        if (_stroke.size() == 1U) {
            const NSPoint pt = NSMakePoint([self xAtRel:_stroke[0].rel], center - static_cast<CGFloat>(_stroke[0].value * _strokeGain) * amp);
            [path appendBezierPathWithOvalInRect:NSMakeRect(pt.x - 3.0, pt.y - 3.0, 6.0, 6.0)];
        }
        [sv::amber() setStroke];
        [path stroke];
    }
}

- (void)mouseDown:(NSEvent*)event {
    [self.window makeFirstResponder:self];
    SilvetonController* c = self.controller;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (![self syncSpan]) return;
    for (const ToolItem& item : [self toolItems]) {
        if (NSPointInRect(p, item.rect)) { if (item.enabled) [self performTool:item.tool]; return; }
    }
    const NSRect wave = [self waveRect], ruler = [self rulerRect], ov = [self overviewRect];
    _downX = p.x;
    _lastMouseX = p.x;
    _moved = NO;
    const double spanLength = static_cast<double>(_span.length());

    if (NSPointInRect(p, ruler)) {
        _drag = Drag::Scrub;
        [c seekToSample:absoluteOf(std::min(std::max([self relAtX:p.x], 0.0), spanLength), _origin)];
        [self setNeedsDisplay:YES];
        return;
    }
    if (NSPointInRect(p, ov)) {
        _drag = Drag::Overview;
        [self centerOnX:p.x inOverview:ov];
        [self setNeedsDisplay:YES];
        return;
    }
    if (!NSPointInRect(p, wave)) return;

    const PieceSet set = [self buildPieces];
    const auto handles = [self fadeHandles:set];
    const NSInteger handle = [self fadeHandleIndexAt:p in:handles];
    if (handle >= 0) {
        _drag = handles[static_cast<std::size_t>(handle)].fadeIn ? Drag::FadeIn : Drag::FadeOut;
        _fadeClip = handles[static_cast<std::size_t>(handle)].clipId;
        [c beginGesture:@"Clip Fade"];
        return;
    }

    if (_pencil) { [self beginStrokeAt:p event:event set:set]; return; }

    const TimelineRange sel = _sel;
    const double rel = [self relAtX:p.x];
    const BOOL shift = (event.modifierFlags & NSEventModifierFlagShift) != 0;
    if (sel.valid()) {
        const double a = static_cast<double>(sel.start - _origin), b = static_cast<double>(sel.end - _origin);
        const CGFloat xa = [self xAtRel:a], xb = [self xAtRel:b];
        const bool nearA = std::abs(p.x - xa) <= kEdgeGrab, nearB = std::abs(p.x - xb) <= kEdgeGrab;
        if (nearA || nearB || shift) {
            // Move one edge of the selection; the other one stays.
            const bool takeStart = (nearA && !nearB) ? true : ((nearB && !nearA) ? false : std::abs(rel - a) < std::abs(rel - b));
            _anchor = takeStart ? b : a;
            _anchorRaw = _anchor;
            _drag = Drag::Select;
            _moved = YES;
            if (shift && !nearA && !nearB) [self updateSelectionAtX:p.x];
            return;
        }
    } else if (shift) {
        // Extend from the cursor.
        _anchor = std::min(std::max(static_cast<double>([c playheadSample] - _origin), 0.0), spanLength);
        _anchorRaw = _anchor;
        _drag = Drag::Select;
        _moved = YES;
        [self updateSelectionAtX:p.x];
        return;
    }

    if (event.clickCount >= 2) {
        // Double click: the whole piece under the mouse.
        if (const PieceView* v = [self pieceAt:rel in:set]) {
            c.sampleSelection = TimelineRange {absoluteOf(v->startRel, _origin), absoluteOf(v->endRel(), _origin)};
            _drag = Drag::None;
            return;
        }
    }
    // A click puts the cursor there (and clears the selection); dragging selects.
    _drag = Drag::Select;
    _anchorRaw = std::min(std::max(rel, 0.0), spanLength);
    _anchor = _anchorRaw;
    c.sampleSelection = TimelineRange {};
    [c seekToSample:absoluteOf(_anchorRaw, _origin)];
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (_drag == Drag::None || ![self syncSpan]) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const NSRect wave = [self waveRect];
    _lastMouseX = p.x;
    switch (_drag) {
        case Drag::Scrub: {
            const double rel = std::min(std::max([self relAtX:p.x], 0.0), static_cast<double>(_span.length()));
            [c seekToSample:absoluteOf(rel, _origin)];
            [self setNeedsDisplay:YES];
            break;
        }
        case Drag::Overview:
            [self centerOnX:p.x inOverview:[self overviewRect]];
            [self setNeedsDisplay:YES];
            break;
        case Drag::Select: {
            if (!_moved) {
                if (std::abs(p.x - _downX) < kDragThreshold) return;
                _moved = YES;
                const PieceSet set = [self buildPieces];
                _anchor = [self snapRel:_anchorRaw in:set];
            }
            [self updateSelectionAtX:std::min(std::max(p.x, wave.origin.x), NSMaxX(wave))];
            break;
        }
        case Drag::FadeIn:
        case Drag::FadeOut: {
            const ProjectAudioClip* clip = [self clipWithId:_fadeClip];
            if (clip == nullptr) break;
            const double t = static_cast<double>(_origin) + [self relAtX:p.x];
            const double start = static_cast<double>(clip->timelineStartSample), length = static_cast<double>(clip->lengthSamples);
            std::uint64_t fadeIn = clip->fadeInSamples, fadeOut = clip->fadeOutSamples;
            if (_drag == Drag::FadeIn) fadeIn = static_cast<std::uint64_t>(std::llround(std::min(std::max(t - start, 0.0), length)));
            else fadeOut = static_cast<std::uint64_t>(std::llround(std::min(std::max(start + length - t, 0.0), length)));
            [c sampleSetFadesOfClip:_fadeClip fadeIn:fadeIn fadeOut:fadeOut];
            [self setNeedsDisplay:YES];
            break;
        }
        case Drag::Pencil:
            [self addStrokePoint:p];
            [self setNeedsDisplay:YES];
            break;
        case Drag::None: break;
    }
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    const Drag was = _drag;
    _drag = Drag::None;
    if (was == Drag::FadeIn || was == Drag::FadeOut) [self.controller endGesture];
    if (was == Drag::Pencil) [self commitStroke];
    if (was == Drag::Select && _moved) [self selectionChanged];
    [self setNeedsDisplay:YES];
}

- (void)mouseMoved:(NSEvent*)event {
    if (![self syncSpan]) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const NSRect wave = [self waveRect];
    _hovering = NSPointInRect(p, wave);
    if (_hovering) _hoverRel = [self relAtX:p.x];
    [self setNeedsDisplayInRect:[self readoutRect]];

    NSCursor* cursor = [NSCursor arrowCursor];
    if (_hovering) {
        cursor = [NSCursor crosshairCursor];
        const PieceSet set = [self buildPieces];
        if ([self fadeHandleIndexAt:p in:[self fadeHandles:set]] >= 0) cursor = [NSCursor pointingHandCursor];
        const TimelineRange sel = _sel;
        if (sel.valid()) {
            const CGFloat xa = [self xAtRel:static_cast<double>(sel.start - _origin)], xb = [self xAtRel:static_cast<double>(sel.end - _origin)];
            if (std::abs(p.x - xa) <= kEdgeGrab || std::abs(p.x - xb) <= kEdgeGrab) cursor = [NSCursor resizeLeftRightCursor];
        }
    }
    [cursor set];
}

- (void)mouseExited:(NSEvent*)event {
    (void)event;
    _hovering = NO;
    [[NSCursor arrowCursor] set];
    [self setNeedsDisplayInRect:[self readoutRect]];
}

- (void)scrollWheel:(NSEvent*)event {
    if (![self syncSpan]) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const NSRect wave = [self waveRect];
    double dx = event.scrollingDeltaX, dy = event.scrollingDeltaY;
    if (!event.hasPreciseScrollingDeltas) { dx *= 12.0; dy *= 12.0; }
    const NSEventModifierFlags mods = event.modifierFlags;
    if (mods & (NSEventModifierFlagCommand | NSEventModifierFlagOption | NSEventModifierFlagControl)) {
        // Zoom around the mouse.
        _vp.zoomAbout(std::min(std::max(p.x - wave.origin.x, 0.0), wave.size.width), std::exp(-dy * 0.015));
    } else {
        _vp.scrollPixels(-(std::abs(dx) > std::abs(dy) ? dx : dy));
    }
    [self setNeedsDisplay:YES];
}

- (void)magnifyWithEvent:(NSEvent*)event {
    if (![self syncSpan]) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const NSRect wave = [self waveRect];
    _vp.zoomAbout(std::min(std::max(p.x - wave.origin.x, 0.0), wave.size.width), std::max(0.2, 1.0 - event.magnification));
    [self setNeedsDisplay:YES];
}

// ================================================================== keys ==
- (void)keyDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    NSString* chars = event.charactersIgnoringModifiers;
    const unichar ch = chars.length ? [chars characterAtIndex:0] : 0;
    if (event.keyCode == 53) { c.sampleSelection = TimelineRange {}; return; }   // Esc
    if (![self syncSpan]) { [super keyDown:event]; return; }
    if (ch == NSHomeFunctionKey) { _vp.first = 0.0; [self setNeedsDisplay:YES]; return; }
    if (ch == NSEndFunctionKey) { _vp.first = _vp.length; _vp.clamp(); [self setNeedsDisplay:YES]; return; }
    if (ch == '+' || ch == '=') { [self zoomBy:0.5]; return; }
    if (ch == '-') { [self zoomBy:2.0]; return; }
    if (ch == '0') { [self zoomFit]; return; }
    [super keyDown:event];
}

// ============================================================ context menu ==
- (NSMenu*)menuForEvent:(NSEvent*)event {
    (void)event;
    SilvetonController* c = self.controller;
    if (![c sampleEditorActive]) return nil;
    NSMenu* menu = [[NSMenu alloc] initWithTitle:@""];
    auto add = [&](NSString* title, SEL action) {
        NSMenuItem* item = [menu addItemWithTitle:title action:action keyEquivalent:@""];
        item.target = c;
    };
    add(@"Cut", @selector(cutClip:));
    add(@"Copy", @selector(copyClip:));
    add(@"Paste", @selector(pasteClip:));
    add(@"Delete", @selector(deleteSelection:));
    [menu addItem:[NSMenuItem separatorItem]];
    add(@"Select All", @selector(sampleSelectAll:));
    add(@"Crop to Selection", @selector(sampleCropToSelection:));
    add(@"Loop Selection", @selector(sampleLoopSelection:));
    [menu addItem:[NSMenuItem separatorItem]];
    add(@"Zoom to Selection", @selector(sampleZoomSelection:));
    add(@"Zoom to Fit", @selector(sampleZoomFit:));
    [menu addItem:[NSMenuItem separatorItem]];
    add(@"Zero Crossing Snap", @selector(toggleSampleZeroSnap:));
    add(@"Ripple", @selector(toggleSampleRipple:));
    return menu;
}

@end
