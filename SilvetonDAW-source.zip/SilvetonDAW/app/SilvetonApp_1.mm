#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

#include "silveton/AudioEngine.h"
#include "silveton/ClipEditor.h"
#include "silveton/CoreAudioDevice.h"
#include "silveton/CoreMidiInput.h"
#include "silveton/DawRuntimeCoordinator.h"
#include "silveton/DiskStream.h"
#include "silveton/MidiEditor.h"
#include "silveton/MidiPartEditor.h"
#include "silveton/OfflineBounce.h"
#include "silveton/ProjectMediaRelinker.h"
#include "silveton/ProjectSession.h"
#include "silveton/RecordingWorkflow.h"
#include "silveton/StemBounce.h"
#include "silveton/Vst3Host.h"
#include "silveton/Vst3PluginCatalog.h"
#include "silveton/Vst3PresetLibrary.h"
#include "silveton/WaveformCache.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

using namespace silveton;

namespace {

NSString* nsString(const std::string& s) {
    return [[NSString alloc] initWithBytes:s.data() length:s.size() encoding:NSUTF8StringEncoding] ?: @"";
}

std::string stdString(NSString* s) {
    if (s == nil) return {};
    const char* p = [s UTF8String];
    return p ? std::string(p) : std::string();
}

NSColor* bgColor() { return [NSColor colorWithCalibratedRed:0.070 green:0.080 blue:0.095 alpha:1.0]; }
NSColor* panelColor() { return [NSColor colorWithCalibratedRed:0.105 green:0.120 blue:0.145 alpha:1.0]; }
NSColor* panel2Color() { return [NSColor colorWithCalibratedRed:0.135 green:0.150 blue:0.175 alpha:1.0]; }
NSColor* accentColor() { return [NSColor colorWithCalibratedRed:0.20 green:0.62 blue:0.95 alpha:1.0]; }
NSColor* textColor() { return [NSColor colorWithCalibratedWhite:0.91 alpha:1.0]; }
NSColor* dimTextColor() { return [NSColor colorWithCalibratedWhite:0.62 alpha:1.0]; }

void drawWaveformOverview(const WaveformOverview& overview,
                          std::uint64_t sourceStart,
                          std::uint64_t sourceLength,
                          NSRect rect,
                          NSColor* color) {
    if (overview.empty() || sourceLength == 0U || rect.size.width < 1.0 || rect.size.height < 2.0 ||
        overview.framesPerPeak == 0U || overview.peaks.empty()) return;
    const std::uint64_t available = sourceStart < overview.frames ? overview.frames - sourceStart : 0U;
    sourceLength = std::min(sourceLength, available);
    if (sourceLength == 0U) return;

    const std::uint32_t channels = std::min<std::uint32_t>(overview.channels, 2U);
    const NSInteger columns = std::max<NSInteger>(1, static_cast<NSInteger>(std::ceil(rect.size.width)));
    [color setStroke];
    for (std::uint32_t channel = 0U; channel < channels; ++channel) {
        if (channel >= overview.peaks.size() || overview.peaks[channel].empty()) continue;
        const CGFloat bandH = rect.size.height / static_cast<CGFloat>(channels);
        const CGFloat center = rect.origin.y + bandH * (static_cast<CGFloat>(channel) + 0.5);
        const CGFloat amplitude = std::max<CGFloat>(1.0, bandH * 0.45);
        NSBezierPath* path = [NSBezierPath bezierPath];
        path.lineWidth = 1.0;
        const auto& peaks = overview.peaks[channel];
        for (NSInteger x = 0; x < columns; ++x) {
            const double u0 = static_cast<double>(x) / static_cast<double>(columns);
            const double u1 = static_cast<double>(x + 1) / static_cast<double>(columns);
            const std::uint64_t sample0 = sourceStart + static_cast<std::uint64_t>(u0 * static_cast<double>(sourceLength));
            const std::uint64_t sample1 = std::min<std::uint64_t>(
                sourceStart + sourceLength,
                sourceStart + std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::ceil(u1 * static_cast<double>(sourceLength)))));
            const std::uint64_t firstPeak = sample0 / overview.framesPerPeak;
            const std::uint64_t lastPeak = std::min<std::uint64_t>(
                static_cast<std::uint64_t>(peaks.size()),
                (sample1 + overview.framesPerPeak - 1U) / overview.framesPerPeak);
            if (firstPeak >= lastPeak || firstPeak >= peaks.size()) continue;
            float minimum = peaks[static_cast<std::size_t>(firstPeak)].minimum;
            float maximum = peaks[static_cast<std::size_t>(firstPeak)].maximum;
            for (std::uint64_t pi = firstPeak + 1U; pi < lastPeak; ++pi) {
                minimum = std::min(minimum, peaks[static_cast<std::size_t>(pi)].minimum);
                maximum = std::max(maximum, peaks[static_cast<std::size_t>(pi)].maximum);
            }
            minimum = std::clamp(minimum, -1.0F, 1.0F);
            maximum = std::clamp(maximum, -1.0F, 1.0F);
            const CGFloat px = rect.origin.x + static_cast<CGFloat>(x) + 0.5;
            [path moveToPoint:NSMakePoint(px, center - static_cast<CGFloat>(maximum) * amplitude)];
            [path lineToPoint:NSMakePoint(px, center - static_cast<CGFloat>(minimum) * amplitude)];
        }
        [path stroke];
    }
}

void showError(NSString* title, const std::string& detail) {
    NSAlert* alert = [[NSAlert alloc] init];
    alert.alertStyle = NSAlertStyleCritical;
    alert.messageText = title ?: @"Silveton";
    alert.informativeText = nsString(detail);
    [alert addButtonWithTitle:@"OK"];
    [alert runModal];
}

void showInfo(NSString* title, NSString* detail) {
    NSAlert* alert = [[NSAlert alloc] init];
    alert.alertStyle = NSAlertStyleInformational;
    alert.messageText = title ?: @"Silveton";
    alert.informativeText = detail ?: @"";
    [alert addButtonWithTitle:@"OK"];
    [alert runModal];
}

std::string appSupportDirectory() {
    NSArray<NSURL*>* urls = [[NSFileManager defaultManager] URLsForDirectory:NSApplicationSupportDirectory
                                                                  inDomains:NSUserDomainMask];
    if (urls.count == 0) throw std::runtime_error("cannot locate Application Support directory");
    NSURL* dir = [urls[0] URLByAppendingPathComponent:@"Silveton" isDirectory:YES];
    NSError* error = nil;
    if (![[NSFileManager defaultManager] createDirectoryAtURL:dir
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:&error]) {
        throw std::runtime_error(stdString(error.localizedDescription));
    }
    return stdString(dir.path);
}

std::string recordingsDirectory() {
    NSArray<NSURL*>* urls = [[NSFileManager defaultManager] URLsForDirectory:NSMusicDirectory
                                                                  inDomains:NSUserDomainMask];
    NSURL* base = urls.count ? urls[0] : [NSURL fileURLWithPath:NSHomeDirectory()];
    NSURL* dir = [base URLByAppendingPathComponent:@"Silveton Recordings" isDirectory:YES];
    NSError* error = nil;
    if (![[NSFileManager defaultManager] createDirectoryAtURL:dir
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:&error]) {
        throw std::runtime_error(stdString(error.localizedDescription));
    }
    return stdString(dir.path);
}

std::string importedMediaDirectory(const std::string& supportDir) {
    NSString* path = [nsString(supportDir) stringByAppendingPathComponent:@"Imported Media"];
    NSError* error = nil;
    if (![[NSFileManager defaultManager] createDirectoryAtPath:path
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:&error]) {
        throw std::runtime_error(stdString(error.localizedDescription));
    }
    return stdString(path);
}

bool isSupportedAudioURL(NSURL* url) {
    if (!url || !url.isFileURL) return false;
    NSString* ext = url.pathExtension.lowercaseString;
    return [ext isEqualToString:@"wav"] || [ext isEqualToString:@"aif"] || [ext isEqualToString:@"aiff"];
}

std::string sanitizedFileName(std::string name) {
    if (name.empty()) name = "Track";
    for (char& c : name) {
        const unsigned char u = static_cast<unsigned char>(c);
        if (u < 32U || c == '/' || c == ':' || c == '\\') c = '_';
    }
    return name;
}

std::int64_t projectEndSample(const Project& project) {
    std::int64_t end = 0;
    for (const auto& track : project.tracks) {
        for (const auto& clip : track.clips) {
            if (clip.timelineStartSample < 0) continue;
            const auto length = static_cast<std::int64_t>(std::min<std::uint64_t>(
                clip.lengthSamples, static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max())));
            if (clip.timelineStartSample <= std::numeric_limits<std::int64_t>::max() - length)
                end = std::max(end, clip.timelineStartSample + length);
        }
    }
    for (const auto& mt : project.midiTracks) {
        if (mt.parts.empty()) {
            for (const auto& n : mt.sequence.notes()) {
                const double q = n.startQuarterNotes + n.durationQuarterNotes;
                end = std::max(end, project.tempoMap.sampleAtQuarterNotes(q));
            }
        } else {
            for (const auto& part : mt.parts)
                end = std::max(end, project.tempoMap.sampleAtQuarterNotes(
                    part.timelineStartQuarterNotes + part.lengthQuarterNotes));
        }
    }
    return std::max<std::int64_t>(end, 1);
}

int nextMidiPort(const Project& project) {
    int result = 0;
    auto consider = [&](const std::vector<ProjectPluginSlot>& slots) {
        for (const auto& s : slots) if (s.midiInputPort >= result) result = s.midiInputPort + 1;
    };
    for (const auto& t : project.tracks) consider(t.pluginSlots);
    for (const auto& b : project.buses) consider(b.pluginSlots);
    consider(project.masterPluginSlots);
    return result;
}

bool looksLikeInstrument(const Vst3CatalogEntry& entry) {
    for (const auto& c : entry.subCategories) {
        std::string l = c;
        std::transform(l.begin(), l.end(), l.begin(), [](unsigned char ch){ return static_cast<char>(std::tolower(ch)); });
        if (l.find("instrument") != std::string::npos || l.find("synth") != std::string::npos)
            return true;
    }
    return false;
}

class AppRuntime final {
public:
    AppRuntime() : session_(48000.0), host_() {}
    ~AppRuntime() { shutdown(); }

    ProjectSession& session() noexcept { return session_; }
    Vst3Host& host() noexcept { return host_; }
    AudioEngine& engine() { if (!engine_) throw std::logic_error("audio engine unavailable"); return *engine_; }
    DawRuntimeCoordinator& runtime() { if (!runtime_) throw std::logic_error("runtime unavailable"); return *runtime_; }
    CoreAudioDevice& device() { if (!device_) throw std::logic_error("CoreAudio unavailable"); return *device_; }
    CoreMidiInput* midi() noexcept { return midi_.get(); }
    RecordingWorkflow* recording() noexcept { return recording_.get(); }
    WaveformCache& waveformCache() noexcept { return waveformCache_; }
    [[nodiscard]] NSInteger recordingTrackIndex() const noexcept {
        return recording_ ? static_cast<NSInteger>(recordingTrackIndex_) : -1;
    }
    [[nodiscard]] std::int64_t recordingStartSample() const noexcept { return recordingStartSample_; }

    void startDefault() {
        AudioDeviceConfig requested;
        requested.sampleRate = session_.project().sampleRate;
        requested.blockSize = 256U;

        // The macOS default output device is not guaranteed to expose inputs.
        // Built-in Output, HDMI and many USB playback devices report 0 input
        // channels.  Requiring 2-in/2-out here made Silveton abort before the
        // window could open.  Start with the channels the selected output
        // device actually owns; recording remains disabled until an input-capable
        // device is selected from Audio Device.
        const std::uint32_t defaultOutput = CoreAudioDevice::defaultOutputDeviceId();
        const auto devices = CoreAudioDevice::devices();
        const auto it = std::find_if(devices.begin(), devices.end(),
                                     [defaultOutput](const CoreAudioDeviceInfo& info) {
                                         return info.id == defaultOutput;
                                     });
        if (it != devices.end()) {
            requested.inputChannels = std::min<std::uint32_t>(2U, it->inputChannels);
            requested.outputChannels = std::min<std::uint32_t>(2U, it->outputChannels);
            if (requested.outputChannels == 0U)
                throw std::runtime_error("default CoreAudio device has no output channels");
        } else {
            requested.inputChannels = 0U;
            requested.outputChannels = 2U;
        }

        CoreAudioDeviceOptions options;
        options.followDefaultOutputDevice = true;
        try {
            restartAudio(requested, options);
        } catch (const std::exception&) {
            // An empty new project may safely follow the hardware rate when a
            // driver refuses the initial 48 kHz request.  This avoids a launch
            // failure while still keeping project/device rates identical.
            if (it == devices.end() || !std::isfinite(it->nominalSampleRate) ||
                it->nominalSampleRate <= 0.0 ||
                std::abs(it->nominalSampleRate - requested.sampleRate) <= 0.01)
                throw;
            session_.newProject(it->nominalSampleRate);
            requested.sampleRate = it->nominalSampleRate;
            restartAudio(requested, options);
        }
    }

    void restartAudio(const AudioDeviceConfig& requested, const CoreAudioDeviceOptions& options) {
        shutdownRealtime();
        deviceOptions_ = options;
        requestedConfig_ = requested;
        device_ = std::make_unique<CoreAudioDevice>(requestedConfig_, deviceOptions_);
        engine_ = std::make_unique<AudioEngine>();
        runtime_ = std::make_unique<DawRuntimeCoordinator>(session_, *engine_, host_);
        runtime_->prepare(device_->config());
        midi_ = std::make_unique<CoreMidiInput>(runtime_->midiInput(), runtime_->clockMapper());
        midi_->connectAll();
        device_->start(runtime_->audioCallback());
    }

    void rebuildProjectSafely() {
        if (!device_ || !runtime_ || !engine_) return;
        const bool playing = engine_->transport().isPlaying();
        engine_->transport().stop();
        const bool wasRunning = device_->isRunning();
        if (wasRunning) device_->stop();
        runtime_->rebuildProject();
        if (wasRunning) device_->start(runtime_->audioCallback());
        if (playing) engine_->transport().play();
    }

    void service() {
        if (!runtime_ || !device_) return;
        if (runtime_->projectRebuildRequested()) rebuildProjectSafely();
        (void)runtime_->service();
        const auto status = device_->status();
        if (status.needsReopen && !recording_) {
            const AudioDeviceConfig requested = requestedConfig_;
            const CoreAudioDeviceOptions options = deviceOptions_;
            restartAudio(requested, options);
        }
    }

    void beginRecording(std::size_t trackIndex) {
        if (recording_) throw std::logic_error("recording already active");
        if (!device_ || !runtime_) throw std::logic_error("audio device unavailable");
        if (trackIndex >= session_.project().tracks.size()) throw std::out_of_range("record track");
        const std::uint32_t channels = std::min<std::uint32_t>(2U, device_->config().inputChannels);
        if (channels == 0U) throw std::runtime_error("selected CoreAudio device has no input channels");
        NSString* stamp = [[NSDate date] descriptionWithLocale:[NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"]];
        NSString* safe = [[stamp stringByReplacingOccurrencesOfString:@":" withString:@"-"]
                              stringByReplacingOccurrencesOfString:@" " withString:@"_"];
        const std::string path = recordingsDirectory() + "/Take_" + stdString(safe) + ".wav";
        recordingTrackIndex_ = trackIndex;
        recordingStartSample_ = engine_->transport().positionSamples();
        session_.beginEdit("Record Take");
        try {
            recording_ = std::make_unique<RecordingWorkflow>(*engine_, session_.project(), trackIndex);
            recording_->start(path, channels);
            engine_->transport().play();
        } catch (...) {
            recording_.reset();
            recordingTrackIndex_ = std::numeric_limits<std::size_t>::max();
            recordingStartSample_ = 0;
            session_.cancelEdit();
            throw;
        }
    }

    void stopRecording(bool commit = true) {
        if (!recording_) return;
        engine_->transport().stop();
        try {
            if (commit) {
                const auto ids = recording_->stopAndCommitTakes();
                if (!ids.empty()) recording_->promoteTakeToComp(ids.back(), 0U);
                const std::string recordedPath = recording_->audioPath();
                recording_.reset();
                recordingTrackIndex_ = std::numeric_limits<std::size_t>::max();
                recordingStartSample_ = 0;
                session_.commitEdit();
                waveformCache_.request(recordedPath);
                if (runtime_) runtime_->requestProjectRebuild();
            } else {
                (void)recording_->stopAndCommitTakes();
                recording_.reset();
                recordingTrackIndex_ = std::numeric_limits<std::size_t>::max();
                recordingStartSample_ = 0;
                session_.cancelEdit();
            }
        } catch (...) {
            recording_.reset();
            recordingTrackIndex_ = std::numeric_limits<std::size_t>::max();
            recordingStartSample_ = 0;
            if (session_.history().transactionOpen()) session_.cancelEdit();
            throw;
        }
    }

    void shutdownRealtime() noexcept {
        if (recording_) {
            try { stopRecording(false); } catch (...) { recording_.reset(); }
        }
        if (midi_) midi_->disconnectAll();
        midi_.reset();
        if (engine_) engine_->transport().stop();
        if (device_) device_->stop();
        runtime_.reset();
        engine_.reset();
        device_.reset();
    }

    void shutdown() noexcept { shutdownRealtime(); }

private:
    ProjectSession session_;
    Vst3Host host_;
    std::unique_ptr<CoreAudioDevice> device_;
    std::unique_ptr<AudioEngine> engine_;
    std::unique_ptr<DawRuntimeCoordinator> runtime_;
    std::unique_ptr<CoreMidiInput> midi_;
    std::unique_ptr<RecordingWorkflow> recording_;
    WaveformCache waveformCache_;
    std::size_t recordingTrackIndex_ {std::numeric_limits<std::size_t>::max()};
    std::int64_t recordingStartSample_ {0};
    AudioDeviceConfig requestedConfig_ {};
    CoreAudioDeviceOptions deviceOptions_ {};
};

} // namespace


@protocol SilvetonTableContextMenuDelegate <NSObject>
- (NSMenu*)tableView:(NSTableView*)tableView contextMenuForRow:(NSInteger)row;
@end

@interface SilvetonTableView : NSTableView
@end

@implementation SilvetonTableView
- (NSMenu*)menuForEvent:(NSEvent*)event {
    const NSPoint point = [self convertPoint:event.locationInWindow fromView:nil];
    const NSInteger row = [self rowAtPoint:point];
    if (row >= 0 && row < self.numberOfRows) {
        [self selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(row)] byExtendingSelection:NO];
    }
    id delegate = self.delegate;
    if ([delegate conformsToProtocol:@protocol(SilvetonTableContextMenuDelegate)] &&
        [delegate respondsToSelector:@selector(tableView:contextMenuForRow:)]) {
        return [(id<SilvetonTableContextMenuDelegate>)delegate tableView:self contextMenuForRow:row];
    }
    return [super menuForEvent:event];
}
@end

@interface SilvetonResetSlider : NSSlider
@property(nonatomic,assign) double resetValue;
@property(nonatomic,assign) SEL beginAction;
@property(nonatomic,assign) SEL endAction;
@end

@implementation SilvetonResetSlider
- (void)mouseDown:(NSEvent*)event {
    if (self.beginAction != nil) [NSApp sendAction:self.beginAction to:self.target from:self];
    if (event.clickCount >= 2) {
        self.doubleValue = self.resetValue;
        [self sendAction:self.action to:self.target];
    } else {
        [super mouseDown:event];
    }
    if (self.endAction != nil) [NSApp sendAction:self.endAction to:self.target from:self];
}
@end

@interface SilvetonMeterView : NSView
- (void)setLeftPeak:(float)left rightPeak:(float)right;
@end

@implementation SilvetonMeterView {
    float _left;
    float _right;
    float _holdLeft;
    float _holdRight;
    CFTimeInterval _holdTimeLeft;
    CFTimeInterval _holdTimeRight;
}
- (BOOL)isOpaque { return YES; }
- (void)setLeftPeak:(float)left rightPeak:(float)right {
    _left = std::max(0.0F, left);
    _right = std::max(0.0F, right);
    const CFTimeInterval now = CACurrentMediaTime();
    if (_left >= _holdLeft) { _holdLeft = _left; _holdTimeLeft = now; }
    if (_right >= _holdRight) { _holdRight = _right; _holdTimeRight = now; }
    if (now - _holdTimeLeft > 1.2) _holdLeft *= 0.94F;
    if (now - _holdTimeRight > 1.2) _holdRight *= 0.94F;
    [self setNeedsDisplay:YES];
}
- (void)drawBar:(NSRect)r value:(float)value hold:(float)hold {
    [[NSColor colorWithCalibratedWhite:0.04 alpha:1.0] setFill]; NSRectFill(r);
    const float db = value > 0.0F ? 20.0F * std::log10(value) : -80.0F;
    const float norm = std::clamp((db + 60.0F) / 60.0F, 0.0F, 1.0F);
    const NSInteger segments = 30;
    const CGFloat gap = 1.0;
    const CGFloat h = (r.size.height - gap * (segments - 1)) / segments;
    for (NSInteger i=0;i<segments;++i) {
        const float threshold = static_cast<float>(i + 1) / static_cast<float>(segments);
        if (threshold > norm) break;
        NSColor* c = threshold < 0.72F ? [NSColor colorWithCalibratedRed:0.18 green:0.80 blue:0.36 alpha:1.0]
                    : threshold < 0.90F ? [NSColor colorWithCalibratedRed:0.94 green:0.76 blue:0.18 alpha:1.0]
                    : [NSColor colorWithCalibratedRed:0.95 green:0.22 blue:0.20 alpha:1.0];
        [c setFill];
        NSRectFill(NSMakeRect(r.origin.x, r.origin.y + i*(h+gap), r.size.width, h));
    }
    const float holdDb = hold > 0.0F ? 20.0F * std::log10(hold) : -80.0F;
    const float holdNorm = std::clamp((holdDb + 60.0F) / 60.0F, 0.0F, 1.0F);
    if (holdNorm > 0.0F) {
        [[NSColor whiteColor] setFill];
        NSRectFill(NSMakeRect(r.origin.x, r.origin.y + holdNorm * r.size.height - 1.0, r.size.width, 1.0));
    }
}
- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    [bgColor() setFill]; NSRectFill(self.bounds);
    const CGFloat gap=4.0, w=(self.bounds.size.width-gap)/2.0;
    [self drawBar:NSMakeRect(0,0,w,self.bounds.size.height) value:_left hold:_holdLeft];
    [self drawBar:NSMakeRect(w+gap,0,w,self.bounds.size.height) value:_right hold:_holdRight];
}
@end

@class SilvetonWorkspaceView;
@protocol SilvetonWorkspaceDropDelegate <NSObject>
- (void)workspace:(SilvetonWorkspaceView*)view importAudioURLs:(NSArray<NSURL*>*)urls;
@end

@interface SilvetonWorkspaceView : NSView
@property(nonatomic,weak) id<SilvetonWorkspaceDropDelegate> dropDelegate;
@end

@implementation SilvetonWorkspaceView
- (instancetype)initWithFrame:(NSRect)frame {
    if((self=[super initWithFrame:frame])) [self registerForDraggedTypes:@[NSPasteboardTypeFileURL]];
    return self;
}
- (NSArray<NSURL*>*)audioURLsFromDraggingInfo:(id<NSDraggingInfo>)sender {
    NSArray* urls=[sender.draggingPasteboard readObjectsForClasses:@[[NSURL class]]
                                                            options:@{NSPasteboardURLReadingFileURLsOnlyKey:@YES}];
    NSMutableArray<NSURL*>* audio=[NSMutableArray array];
    for(NSURL* u in urls) if(isSupportedAudioURL(u)) [audio addObject:u];
    return audio;
}
- (NSDragOperation)draggingEntered:(id<NSDraggingInfo>)sender {
    return [self audioURLsFromDraggingInfo:sender].count>0?NSDragOperationCopy:NSDragOperationNone;
}
- (NSDragOperation)draggingUpdated:(id<NSDraggingInfo>)sender {
    return [self audioURLsFromDraggingInfo:sender].count>0?NSDragOperationCopy:NSDragOperationNone;
}
- (BOOL)performDragOperation:(id<NSDraggingInfo>)sender {
    NSArray<NSURL*>* urls=[self audioURLsFromDraggingInfo:sender];
    if(urls.count==0)return NO;
    if([self.dropDelegate respondsToSelector:@selector(workspace:importAudioURLs:)]) {
        [self.dropDelegate workspace:self importAudioURLs:urls];
        return YES;
    }
    return NO;
}
@end

@class SilvetonTimelineView;
@protocol SilvetonTimelineDelegate <NSObject>
- (void)timeline:(SilvetonTimelineView*)view selectedTrack:(NSInteger)track clipId:(uint64_t)clipId seekSample:(int64_t)sample;
- (void)timeline:(SilvetonTimelineView*)view moveClip:(uint64_t)clipId track:(NSInteger)track toSample:(int64_t)sample;
- (void)timeline:(SilvetonTimelineView*)view importAudioURLs:(NSArray<NSURL*>*)urls atSample:(int64_t)sample;
- (void)timeline:(SilvetonTimelineView*)view requestZoomPixelsPerSecond:(double)pixelsPerSecond;
- (NSMenu*)timeline:(SilvetonTimelineView*)view contextMenuForTrack:(NSInteger)track clipId:(uint64_t)clipId sample:(int64_t)sample;
@end

@interface SilvetonTimelineView : NSView
@property(nonatomic,assign) Project* project;
@property(nonatomic,assign) NSInteger selectedTrack;
@property(nonatomic,assign) uint64_t selectedClipId;
@property(nonatomic,assign) double pixelsPerSecond;
@property(nonatomic,assign) WaveformCache* waveformCache;
@property(nonatomic,assign) RecordingWorkflow* recordingWorkflow;
@property(nonatomic,assign) NSInteger recordingTrack;
@property(nonatomic,assign) int64_t recordingStartSample;
@property(nonatomic,assign) int64_t playheadSample;
@property(nonatomic,weak) id<SilvetonTimelineDelegate> delegate;
@end

@implementation SilvetonTimelineView {
    BOOL _draggingClip;
    NSInteger _dragTrack;
    uint64_t _dragClip;
    BOOL _externalAudioDrag;
}
- (instancetype)initWithFrame:(NSRect)frame {
    if((self=[super initWithFrame:frame])){
        _pixelsPerSecond=90.0;_selectedTrack=-1;_recordingTrack=-1;
        [self registerForDraggedTypes:@[NSPasteboardTypeFileURL]];
    }
    return self;
}
- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (void)requestZoomFactor:(double)factor {
    if(!std::isfinite(factor)||factor<=0.0)return;
    const double next=std::clamp(_pixelsPerSecond*factor,25.0,350.0);
    if(std::abs(next-_pixelsPerSecond)<0.01)return;
    if([self.delegate respondsToSelector:@selector(timeline:requestZoomPixelsPerSecond:)])
        [self.delegate timeline:self requestZoomPixelsPerSecond:next];
    else { _pixelsPerSecond=next; [self setNeedsDisplay:YES]; }
}
- (void)magnifyWithEvent:(NSEvent*)event {
    [self requestZoomFactor:std::max(0.20,1.0+event.magnification)];
}
- (void)scrollWheel:(NSEvent*)event {
    const NSEventModifierFlags mods=event.modifierFlags & NSEventModifierFlagDeviceIndependentFlagsMask;
    if((mods & NSEventModifierFlagOption)||(mods & NSEventModifierFlagCommand)) {
        const double delta=event.scrollingDeltaY;
        if(std::abs(delta)>0.001)[self requestZoomFactor:std::pow(1.08,-delta/4.0)];
        return;
    }
    [super scrollWheel:event];
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty; [bgColor() setFill]; NSRectFill(self.bounds);
    [[NSColor colorWithCalibratedRed:0.09 green:0.105 blue:0.125 alpha:1.0] setFill];
    NSRectFill(NSMakeRect(0,0,self.bounds.size.width,24.0));
    if(!_project) return;
    const CGFloat rowH=54.0; const double sr=_project->sampleRate > 0.0 ? _project->sampleRate : 48000.0;
    const CGFloat width=self.bounds.size.width;
    NSDictionary* attrs=@{NSForegroundColorAttributeName:dimTextColor(),NSFontAttributeName:[NSFont monospacedDigitSystemFontOfSize:9.0 weight:NSFontWeightRegular]};
    const double secondsVisible=width/std::max(1.0,_pixelsPerSecond);
    const std::int64_t lastVisibleSample=static_cast<std::int64_t>(std::ceil(secondsVisible*sr));
    const double lastQuarter=std::max(0.0,_project->tempoMap.quarterNotesAtSample(lastVisibleSample));
    const NSInteger quarterLines=static_cast<NSInteger>(std::ceil(lastQuarter))+2;
    for(NSInteger q=0;q<=quarterLines;++q){
        const std::int64_t sample=_project->tempoMap.sampleAtQuarterNotes(static_cast<double>(q));
        if(sample<0)continue;
        const CGFloat x=static_cast<CGFloat>((static_cast<double>(sample)/sr)*_pixelsPerSecond);
        if(x>width+2.0)break;
        const auto pos=_project->tempoMap.positionAtSample(sample);
        const BOOL barLine=(pos.beat==1U&&std::abs(pos.beatFraction)<0.01);
        [(barLine?[NSColor colorWithCalibratedWhite:0.28 alpha:1.0]:[NSColor colorWithCalibratedWhite:0.15 alpha:1.0]) setStroke];
        NSBezierPath* p=[NSBezierPath bezierPath];p.lineWidth=barLine?1.0:0.5;[p moveToPoint:NSMakePoint(x,0)];[p lineToPoint:NSMakePoint(x,self.bounds.size.height)];[p stroke];
        if(barLine)[[NSString stringWithFormat:@"%lld",static_cast<long long>(pos.bar)] drawAtPoint:NSMakePoint(x+4,4) withAttributes:attrs];
    }
    for(std::size_t i=0;i<_project->tracks.size();++i){
        const CGFloat y=24.0+i*rowH;
        NSColor* row=(static_cast<NSInteger>(i)==_selectedTrack)?[NSColor colorWithCalibratedRed:0.105 green:0.155 blue:0.205 alpha:1.0]:[NSColor colorWithCalibratedRed:0.082 green:0.092 blue:0.108 alpha:1.0];
        [row setFill];NSRectFill(NSMakeRect(0,y,width,rowH-1));
        const auto& t=_project->tracks[i];
        NSDictionary* nameAttrs=@{NSForegroundColorAttributeName:[NSColor colorWithCalibratedWhite:0.76 alpha:0.72],NSFontAttributeName:[NSFont systemFontOfSize:9.0 weight:NSFontWeightMedium]};
        [nsString(t.name) drawAtPoint:NSMakePoint(6.0,y+3.0) withAttributes:nameAttrs];
        for(const auto& c:t.clips){
            const CGFloat x=static_cast<CGFloat>((static_cast<double>(c.timelineStartSample)/sr)*_pixelsPerSecond);
            const CGFloat cw=std::max<CGFloat>(3.0,static_cast<CGFloat>((static_cast<double>(c.lengthSamples)/sr)*_pixelsPerSecond));
            NSRect cr=NSMakeRect(x,y+14,cw,rowH-19);
            NSColor* cc=(c.id==_selectedClipId&&static_cast<NSInteger>(i)==_selectedTrack)?accentColor():[NSColor colorWithCalibratedRed:0.18 green:0.42 blue:0.62 alpha:1.0];
            [cc setFill];[[NSBezierPath bezierPathWithRoundedRect:cr xRadius:4 yRadius:4] fill];
            if(_waveformCache){
                _waveformCache->request(c.audioPath);
                const auto overview=_waveformCache->find(c.audioPath);
                if(overview) drawWaveformOverview(*overview,c.sourceStartSample,c.lengthSamples,NSInsetRect(cr,2.0,2.0),[NSColor colorWithCalibratedWhite:0.92 alpha:0.88]);
            }
            if(c.mute){[[NSColor colorWithCalibratedWhite:0.15 alpha:0.55] setFill];NSRectFillUsingOperation(cr,NSCompositingOperationSourceOver);}
        }
        if(_recordingWorkflow && static_cast<NSInteger>(i)==_recordingTrack){
            const auto status=_recordingWorkflow->status();
            if(status.framesAccepted>0U){
                const CGFloat x=static_cast<CGFloat>((static_cast<double>(_recordingStartSample)/sr)*_pixelsPerSecond);
                const CGFloat cw=std::max<CGFloat>(3.0,static_cast<CGFloat>((static_cast<double>(status.framesAccepted)/sr)*_pixelsPerSecond));
                NSRect rr=NSMakeRect(x,y+14,cw,rowH-19);
                [[NSColor colorWithCalibratedRed:0.55 green:0.12 blue:0.14 alpha:0.88] setFill];
                [[NSBezierPath bezierPathWithRoundedRect:rr xRadius:4 yRadius:4] fill];
                const auto liveOverview=_recordingWorkflow->waveformPreview(0U,status.framesAccepted,
                    static_cast<std::size_t>(std::max<CGFloat>(64.0,std::min<CGFloat>(4096.0,cw))));
                drawWaveformOverview(liveOverview,0U,liveOverview.frames,NSInsetRect(rr,2.0,2.0),[NSColor colorWithCalibratedWhite:0.96 alpha:0.95]);
                [[NSColor colorWithCalibratedRed:1.0 green:0.30 blue:0.30 alpha:1.0] setStroke];
                NSBezierPath* outline=[NSBezierPath bezierPathWithRoundedRect:rr xRadius:4 yRadius:4];outline.lineWidth=1.5;[outline stroke];
            }
        }
    }
    const CGFloat playheadX=static_cast<CGFloat>((static_cast<double>(std::max<int64_t>(0,_playheadSample))/sr)*_pixelsPerSecond);
    if(playheadX>=0.0&&playheadX<=width){
        [accentColor() setStroke];NSBezierPath* ph=[NSBezierPath bezierPath];ph.lineWidth=1.5;[ph moveToPoint:NSMakePoint(playheadX,0)];[ph lineToPoint:NSMakePoint(playheadX,self.bounds.size.height)];[ph stroke];
        [accentColor() setFill];NSBezierPath* head=[NSBezierPath bezierPath];[head moveToPoint:NSMakePoint(playheadX-5,0)];[head lineToPoint:NSMakePoint(playheadX+5,0)];[head lineToPoint:NSMakePoint(playheadX,8)];[head closePath];[head fill];
    }
    if(_project->tracks.empty()) {
        NSString* title=@"DROP WAV / AIFF HERE";
        NSString* sub=@"Drop from Finder • auto-conform to project rate • ⇧⌘I import • Space play/stop • J snap • G/H zoom";
        NSDictionary* ta=@{NSForegroundColorAttributeName:[NSColor colorWithCalibratedWhite:0.78 alpha:1.0],NSFontAttributeName:[NSFont systemFontOfSize:18.0 weight:NSFontWeightSemibold]};
        NSDictionary* sa=@{NSForegroundColorAttributeName:dimTextColor(),NSFontAttributeName:[NSFont systemFontOfSize:11.0]};
        NSSize ts=[title sizeWithAttributes:ta]; NSSize ss=[sub sizeWithAttributes:sa];
        const CGFloat cy=std::max<CGFloat>(70.0,self.bounds.size.height*0.42);
        [title drawAtPoint:NSMakePoint((self.bounds.size.width-ts.width)*0.5,cy) withAttributes:ta];
        [sub drawAtPoint:NSMakePoint((self.bounds.size.width-ss.width)*0.5,cy+30.0) withAttributes:sa];
    }
    if(_externalAudioDrag) {
        [accentColor() setStroke];
        NSBezierPath* border=[NSBezierPath bezierPathWithRoundedRect:NSInsetRect(self.bounds,6.0,6.0) xRadius:8.0 yRadius:8.0];
        border.lineWidth=3.0;[border stroke];
    }
}

- (NSArray<NSURL*>*)draggedAudioURLs:(id<NSDraggingInfo>)sender {
    NSArray* urls=[sender.draggingPasteboard readObjectsForClasses:@[[NSURL class]]
                                                            options:@{NSPasteboardURLReadingFileURLsOnlyKey:@YES}];
    NSMutableArray<NSURL*>* audio=[NSMutableArray array];
    for(NSURL* u in urls) if(isSupportedAudioURL(u)) [audio addObject:u];
    return audio;
}
- (NSDragOperation)draggingEntered:(id<NSDraggingInfo>)sender {
    _externalAudioDrag=([self draggedAudioURLs:sender].count>0);[self setNeedsDisplay:YES];
    return _externalAudioDrag?NSDragOperationCopy:NSDragOperationNone;
}
- (NSDragOperation)draggingUpdated:(id<NSDraggingInfo>)sender { return [self draggedAudioURLs:sender].count>0?NSDragOperationCopy:NSDragOperationNone; }
- (void)draggingExited:(id<NSDraggingInfo>)sender {(void)sender;_externalAudioDrag=NO;[self setNeedsDisplay:YES];}
- (BOOL)performDragOperation:(id<NSDraggingInfo>)sender {
    NSArray<NSURL*>* urls=[self draggedAudioURLs:sender];_externalAudioDrag=NO;[self setNeedsDisplay:YES];
    if(urls.count==0||!_project)return NO;
    NSPoint p=[self convertPoint:sender.draggingLocation fromView:nil];
    const double sr=_project->sampleRate>0.0?_project->sampleRate:48000.0;
    const int64_t sample=std::max<int64_t>(0,static_cast<int64_t>(std::llround((p.x/std::max(1.0,_pixelsPerSecond))*sr)));
    if([self.delegate respondsToSelector:@selector(timeline:importAudioURLs:atSample:)])
        [self.delegate timeline:self importAudioURLs:urls atSample:sample];
    return YES;
}

- (void)mouseDown:(NSEvent*)event {
    [[self window] makeFirstResponder:self];
    if(!_project) return;
    const NSPoint p=[self convertPoint:event.locationInWindow fromView:nil];
    const CGFloat rowH=54.0;
    NSInteger track=static_cast<NSInteger>(std::floor((p.y-24.0)/rowH));
    if(track<0||track>=static_cast<NSInteger>(_project->tracks.size())) return;
    const double sr=_project->sampleRate>0.0?_project->sampleRate:48000.0;
    const int64_t sample=static_cast<int64_t>(std::llround((p.x/std::max(1.0,_pixelsPerSecond))*sr));
    uint64_t hit=0;
    for(const auto& c:_project->tracks[static_cast<std::size_t>(track)].clips){
        if(sample>=c.timelineStartSample && sample<c.timelineStartSample+static_cast<int64_t>(c.lengthSamples)){hit=c.id;break;}
    }
    _selectedTrack=track;_selectedClipId=hit;_dragTrack=track;_dragClip=hit;_draggingClip=hit!=0;
    if([self.delegate respondsToSelector:@selector(timeline:selectedTrack:clipId:seekSample:)])
        [self.delegate timeline:self selectedTrack:track clipId:hit seekSample:sample];
    [self setNeedsDisplay:YES];
}
- (void)mouseDragged:(NSEvent*)event {
    if(!_draggingClip||!_project||_dragTrack<0) return;
    const NSPoint p=[self convertPoint:event.locationInWindow fromView:nil];
    const double sr=_project->sampleRate>0.0?_project->sampleRate:48000.0;
    const int64_t sample=std::max<int64_t>(0,static_cast<int64_t>(std::llround((p.x/std::max(1.0,_pixelsPerSecond))*sr)));
    if([self.delegate respondsToSelector:@selector(timeline:moveClip:track:toSample:)])
        [self.delegate timeline:self moveClip:_dragClip track:_dragTrack toSample:sample];
}
- (void)mouseUp:(NSEvent*)event {(void)event;_draggingClip=NO;_dragClip=0;}
- (NSMenu*)menuForEvent:(NSEvent*)event {
    NSInteger track=-1;
    uint64_t hit=0;
    int64_t sample=0;
    if(_project){
        const NSPoint p=[self convertPoint:event.locationInWindow fromView:nil];
        const CGFloat rowH=54.0;
        track=static_cast<NSInteger>(std::floor((p.y-24.0)/rowH));
        const double sr=_project->sampleRate>0.0?_project->sampleRate:48000.0;
        sample=std::max<int64_t>(0,static_cast<int64_t>(std::llround((p.x/std::max(1.0,_pixelsPerSecond))*sr)));
        if(track>=0&&track<static_cast<NSInteger>(_project->tracks.size())){
            for(const auto& c:_project->tracks[static_cast<std::size_t>(track)].clips){
                if(sample>=c.timelineStartSample&&sample<c.timelineStartSample+static_cast<int64_t>(c.lengthSamples)){hit=c.id;break;}
            }
            if([self.delegate respondsToSelector:@selector(timeline:selectedTrack:clipId:seekSample:)])
                [self.delegate timeline:self selectedTrack:track clipId:hit seekSample:sample];
        }
    }
    if([self.delegate respondsToSelector:@selector(timeline:contextMenuForTrack:clipId:sample:)])
        return [self.delegate timeline:self contextMenuForTrack:track clipId:hit sample:sample];
    return [super menuForEvent:event];
}
@end

@class SilvetonPianoRollView;
@protocol SilvetonPianoRollDelegate <NSObject>
- (void)pianoRoll:(SilvetonPianoRollView*)view addNoteAtQuarter:(double)q pitch:(uint8_t)pitch;
- (void)pianoRoll:(SilvetonPianoRollView*)view selectedNote:(uint64_t)noteId;
- (void)pianoRoll:(SilvetonPianoRollView*)view moveNote:(uint64_t)noteId toQuarter:(double)q pitch:(uint8_t)pitch;
@end

@interface SilvetonPianoRollView : NSView
@property(nonatomic,assign) MidiSequence* sequence;
@property(nonatomic,assign) uint64_t selectedNoteId;
@property(nonatomic,weak) id<SilvetonPianoRollDelegate> delegate;
@end

@implementation SilvetonPianoRollView {
    BOOL _dragging;
    uint64_t _dragNote;
}
- (BOOL)isFlipped{return YES;}
- (BOOL)isOpaque{return YES;}
- (void)drawRect:(NSRect)dirty{
    (void)dirty;[bgColor() setFill];NSRectFill(self.bounds);
    const CGFloat keyH=8.0;const CGFloat qW=72.0;
    for(int p=0;p<128;++p){const CGFloat y=(127-p)*keyH;const int pc=p%12;const BOOL black=(pc==1||pc==3||pc==6||pc==8||pc==10);[(black?[NSColor colorWithCalibratedWhite:0.095 alpha:1]:[NSColor colorWithCalibratedWhite:0.13 alpha:1]) setFill];NSRectFill(NSMakeRect(0,y,self.bounds.size.width,keyH-0.5));}
    for(int q=0;q<64;++q){[[NSColor colorWithCalibratedWhite:(q%4==0?0.30:0.20) alpha:1] setStroke];NSBezierPath*p=[NSBezierPath bezierPath];[p moveToPoint:NSMakePoint(q*qW,0)];[p lineToPoint:NSMakePoint(q*qW,self.bounds.size.height)];[p stroke];}
    if(!_sequence)return;
    for(const auto& n:_sequence->notes()){if(n.muted)continue;NSRect r=NSMakeRect(n.startQuarterNotes*qW,(127-n.pitch)*keyH,std::max(4.0,n.durationQuarterNotes*qW),keyH-1);[(n.id==_selectedNoteId?accentColor():[NSColor colorWithCalibratedRed:0.23 green:0.63 blue:0.88 alpha:1]) setFill];[[NSBezierPath bezierPathWithRoundedRect:r xRadius:2 yRadius:2] fill];}
}
- (void)mouseDown:(NSEvent*)e{
    if(!_sequence)return;NSPoint p=[self convertPoint:e.locationInWindow fromView:nil];const CGFloat keyH=8.0,qW=72.0;const uint8_t pitch=static_cast<uint8_t>(std::clamp<int>(127-static_cast<int>(p.y/keyH),0,127));const double q=std::max(0.0,p.x/qW);uint64_t hit=0;for(const auto& n:_sequence->notes()){if(pitch==n.pitch&&q>=n.startQuarterNotes&&q<n.startQuarterNotes+n.durationQuarterNotes){hit=n.id;break;}}_selectedNoteId=hit;_dragNote=hit;_dragging=hit!=0;if(hit&&[self.delegate respondsToSelector:@selector(pianoRoll:selectedNote:)])[self.delegate pianoRoll:self selectedNote:hit];else if(!hit&&[self.delegate respondsToSelector:@selector(pianoRoll:addNoteAtQuarter:pitch:)])[self.delegate pianoRoll:self addNoteAtQuarter:q pitch:pitch];[self setNeedsDisplay:YES];}
- (void)mouseDragged:(NSEvent*)e{if(!_dragging||!_dragNote)return;NSPoint p=[self convertPoint:e.locationInWindow fromView:nil];const double q=std::max(0.0,p.x/72.0);const uint8_t pitch=static_cast<uint8_t>(std::clamp<int>(127-static_cast<int>(p.y/8.0),0,127));if([self.delegate respondsToSelector:@selector(pianoRoll:moveNote:toQuarter:pitch:)])[self.delegate pianoRoll:self moveNote:_dragNote toQuarter:q pitch:pitch];}
- (void)mouseUp:(NSEvent*)e{(void)e;_dragging=NO;_dragNote=0;}
@end

@interface SilvetonAppDelegate : NSObject <NSApplicationDelegate,NSTableViewDataSource,NSTableViewDelegate,NSSearchFieldDelegate,SilvetonWorkspaceDropDelegate,SilvetonTimelineDelegate,SilvetonPianoRollDelegate,SilvetonTableContextMenuDelegate>
@end

@implementation SilvetonAppDelegate {
    std::unique_ptr<AppRuntime> _core;
    std::unique_ptr<Vst3PluginBrowserService> _browser;
    Vst3PresetLibrary _presets;
    std::string _supportDir;
    std::string _presetDir;
    NSTimer* _timer;

    NSWindow* _window;
    NSView* _leftZone;
    NSView* _rightZone;
    NSView* _dockView;
    NSView* _mixerDock;
    NSView* _clipDock;
    NSView* _midiDock;
    NSSegmentedControl* _dockTabs;
    NSTableView* _trackTable;
    NSTableView* _pluginTable;
    NSTableView* _insertTable;
    NSTableView* _mixerTable;
    NSTableView* _midiTrackTable;
    NSTableView* _sendTable;
    NSSlider* _mixerGainSlider;
    NSTextField* _mixerGainValue;
    NSSlider* _mixerPanSlider;
    NSButton* _mixerMuteButton;
    NSPopUpButton* _mixerOutputPopup;
    NSSlider* _sendGainSlider;
    NSPopUpButton* _sendDestinationPopup;
    NSButton* _sendEnabledButton;
    NSButton* _sendPreButton;
    NSSearchField* _pluginSearch;
    SilvetonTimelineView* _timeline;
    SilvetonPianoRollView* _pianoRoll;
    SilvetonMeterView* _masterMeter;
    SilvetonMeterView* _trackMeter;
    NSTextField* _timeLabel;
    NSSlider* _volumeSlider;
    NSSlider* _panSlider;
    NSTextField* _volumeValue;
    NSTextField* _panValue;
    NSButton* _muteButton;
    NSButton* _metronomeButton;
    NSButton* _snapButton;
    NSPopUpButton* _gridPopup;
    NSSlider* _zoomSlider;
    NSPopUpButton* _midiPortPopup;
    NSTextField* _statusLabel;
    NSTextField* _projectFormatLabel;
    NSSlider* _clipGainSlider;
    NSTextField* _clipGainValue;
    NSTextField* _clipFadeInValue;
    NSTextField* _clipFadeOutValue;
    NSButton* _clipMuteButton;
    NSTextField* _clipInfoLabel;

    NSInteger _selectedTrack;
    NSInteger _selectedPluginResult;
    NSInteger _selectedInsert;
    NSInteger _selectedMidiTrack;
    NSInteger _selectedMixerRow;
    NSInteger _selectedSend;
    uint64_t _selectedClipId;
    uint64_t _selectedMidiNote;
    std::vector<Vst3CatalogEntry> _pluginResults;
    BOOL _updatingControls;
    BOOL _scannerBusy;
    BOOL _snapEnabled;
    BOOL _clipClipboardValid;
    BOOL _lowerZoneVisible;
    ProjectAudioClip _clipClipboard;
    AutomationWriter _trackGainWriter;
    AutomationWriter _trackPanWriter;
    AutomationWriter _trackMuteWriter;
}

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    try {
        @try {
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
        _selectedTrack=-1;_selectedPluginResult=-1;_selectedInsert=-1;_selectedMidiTrack=-1;_selectedMixerRow=-1;_selectedSend=-1;
        _snapEnabled=YES;_clipClipboardValid=NO;_lowerZoneVisible=NO;
        _supportDir=appSupportDirectory();
        _presetDir=_supportDir+"/Presets";
        [[NSFileManager defaultManager] createDirectoryAtPath:nsString(_presetDir) withIntermediateDirectories:YES attributes:nil error:nil];
        _core=std::make_unique<AppRuntime>();
        _core->startDefault();
        [self configureBrowser];
        [self buildMenu];
        [self buildMainWindow];
        [self refreshAll];
        _timer=[NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(timerTick:) userInfo:nil repeats:YES];
        [_window makeKeyAndOrderFront:nil];
        [NSApp activateIgnoringOtherApps:YES];
        } @catch (NSException* e) {
            throw std::runtime_error(stdString(e.reason));
        }
    } catch (const std::exception& e) {
        showError(@"Silveton failed to start", e.what());
        [NSApp terminate:nil];
    }
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender {(void)sender;return YES;}
- (void)applicationWillTerminate:(NSNotification*)notification {
    (void)notification;
    [_timer invalidate];_timer=nil;
    try {
        if(_browser)_browser->save();
        _presets.saveIndex(_supportDir+"/preset-index.txt");
        if(_core){ if(_core->recording())_core->stopRecording(true); _core->shutdown(); }
    } catch (...) {}
}

- (void)configureBrowser {
    NSString* scanner=[[NSBundle mainBundle] pathForResource:@"silveton_vst3_scanner" ofType:nil];
    if(!scanner) scanner=@"silveton_vst3_scanner";
    _browser=std::make_unique<Vst3PluginBrowserService>(stdString(scanner),_supportDir+"/vst3-cache.txt",_supportDir+"/vst3-quarantine.txt",7000U);
    try{_browser->load();}catch(const std::exception&){/* keep empty in-memory catalog; scan can rebuild */}
    try{_presets.loadIndex(_supportDir+"/preset-index.txt");}catch(const std::exception&){}
    try{_presets.scanDirectory(_presetDir,true);}catch(const std::exception&){}
}

- (NSButton*)button:(NSString*)title action:(SEL)action frame:(NSRect)frame {
    NSButton* b=[[NSButton alloc] initWithFrame:frame];
    b.title=title;b.target=self;b.action=action;b.font=[NSFont systemFontOfSize:11 weight:NSFontWeightMedium];
    b.bordered=NO;b.wantsLayer=YES;b.layer.cornerRadius=5.0;b.layer.borderWidth=1.0;
    b.layer.backgroundColor=[NSColor colorWithCalibratedRed:0.14 green:0.17 blue:0.205 alpha:1.0].CGColor;
    b.layer.borderColor=[NSColor colorWithCalibratedRed:0.22 green:0.26 blue:0.31 alpha:1.0].CGColor;
    b.attributedTitle=[[NSAttributedString alloc]initWithString:title attributes:@{NSForegroundColorAttributeName:textColor(),NSFontAttributeName:b.font}];
    return b;
}
- (NSTextField*)label:(NSString*)text frame:(NSRect)frame size:(CGFloat)size {
    NSTextField* l=[[NSTextField alloc] initWithFrame:frame];l.stringValue=text;l.editable=NO;l.selectable=NO;l.bezeled=NO;l.drawsBackground=NO;l.textColor=textColor();l.font=[NSFont systemFontOfSize:size];return l;
}
- (NSTextField*)numericField:(double)value frame:(NSRect)frame action:(SEL)action {
    NSTextField* f=[[NSTextField alloc] initWithFrame:frame];
    f.doubleValue=value;f.alignment=NSTextAlignmentRight;f.font=[NSFont monospacedDigitSystemFontOfSize:11 weight:NSFontWeightRegular];
    f.textColor=textColor();f.backgroundColor=[NSColor colorWithCalibratedRed:0.055 green:0.064 blue:0.078 alpha:1.0];
    f.bezeled=NO;f.drawsBackground=YES;f.wantsLayer=YES;f.layer.cornerRadius=4.0;f.layer.borderWidth=1.0;f.layer.borderColor=[NSColor colorWithCalibratedRed:0.20 green:0.24 blue:0.29 alpha:1.0].CGColor;
    f.target=self;f.action=action;f.continuous=NO;
    return f;
}
- (NSTableView*)tableWithIdentifier:(NSString*)identifier {
    NSTableView* t=[[SilvetonTableView alloc] initWithFrame:NSZeroRect];t.identifier=identifier;t.delegate=self;t.dataSource=self;t.backgroundColor=panelColor();t.rowHeight=27.0;t.headerView=nil;t.focusRingType=NSFocusRingTypeNone;t.allowsMultipleSelection=NO;t.gridStyleMask=NSTableViewSolidHorizontalGridLineMask;t.gridColor=[NSColor colorWithCalibratedWhite:0.16 alpha:0.55];
    NSTableColumn* c=[[NSTableColumn alloc] initWithIdentifier:@"main"];c.width=240;[t addTableColumn:c];return t;
}
- (NSScrollView*)scrollFor:(NSView*)document frame:(NSRect)frame {
    NSScrollView*s=[[NSScrollView alloc]initWithFrame:frame];s.documentView=document;s.hasVerticalScroller=YES;s.hasHorizontalScroller=YES;s.borderType=NSNoBorder;s.drawsBackground=YES;s.backgroundColor=panelColor();s.scrollerStyle=NSScrollerStyleOverlay;return s;
}

- (void)buildMenu {
    NSMenu* main=[[NSMenu alloc]initWithTitle:@"Main"];

    NSMenuItem* appItem=[[NSMenuItem alloc]initWithTitle:@"Silveton" action:nil keyEquivalent:@""];
    [main addItem:appItem];
    NSMenu* app=[[NSMenu alloc]initWithTitle:@"Silveton"];
    [app addItemWithTitle:@"About Silveton" action:@selector(orderFrontStandardAboutPanel:) keyEquivalent:@""];
    [app addItem:[NSMenuItem separatorItem]];
    [app addItemWithTitle:@"Quit Silveton" action:@selector(terminate:) keyEquivalent:@"q"];
    appItem.submenu=app;

    NSMenuItem* fileItem=[[NSMenuItem alloc]initWithTitle:@"File" action:nil keyEquivalent:@""];
    [main addItem:fileItem];
    NSMenu* file=[[NSMenu alloc]initWithTitle:@"File"];
    [file addItemWithTitle:@"New Project" action:@selector(newProject:) keyEquivalent:@"n"];
    [file addItemWithTitle:@"Open…" action:@selector(openProject:) keyEquivalent:@"o"];
    [file addItemWithTitle:@"Save" action:@selector(saveProject:) keyEquivalent:@"s"];
    NSMenuItem* saveAs=[file addItemWithTitle:@"Save As…" action:@selector(saveProjectAs:) keyEquivalent:@"s"];
    saveAs.keyEquivalentModifierMask=NSEventModifierFlagCommand|NSEventModifierFlagShift;
    [file addItem:[NSMenuItem separatorItem]];
    NSMenuItem* import=[file addItemWithTitle:@"Import Audio…" action:@selector(importAudio:) keyEquivalent:@"i"];
    import.keyEquivalentModifierMask=NSEventModifierFlagCommand|NSEventModifierFlagShift;
    [file addItem:[NSMenuItem separatorItem]];
    NSMenuItem* export=[file addItemWithTitle:@"Export Master…" action:@selector(exportMaster:) keyEquivalent:@"e"];
    export.keyEquivalentModifierMask=NSEventModifierFlagCommand|NSEventModifierFlagShift;
    [file addItemWithTitle:@"Export Track Stems…" action:@selector(exportStems:) keyEquivalent:@""];
    fileItem.submenu=file;

    NSMenuItem* editItem=[[NSMenuItem alloc]initWithTitle:@"Edit" action:nil keyEquivalent:@""];
    [main addItem:editItem];
    NSMenu* edit=[[NSMenu alloc]initWithTitle:@"Edit"];
    [edit addItemWithTitle:@"Undo" action:@selector(undo:) keyEquivalent:@"z"];
    NSMenuItem* redo=[edit addItemWithTitle:@"Redo" action:@selector(redo:) keyEquivalent:@"z"];
    redo.keyEquivalentModifierMask=NSEventModifierFlagCommand|NSEventModifierFlagShift;
    [edit addItem:[NSMenuItem separatorItem]];
    [edit addItemWithTitle:@"Cut Clip" action:@selector(cutSelectedClip:) keyEquivalent:@"x"];
    [edit addItemWithTitle:@"Copy Clip" action:@selector(copySelectedClip:) keyEquivalent:@"c"];
    [edit addItemWithTitle:@"Paste Clip at Playhead" action:@selector(pasteClip:) keyEquivalent:@"v"];
    [edit addItemWithTitle:@"Duplicate Clip" action:@selector(duplicateSelectedClip:) keyEquivalent:@"d"];
    [edit addItem:[NSMenuItem separatorItem]];
    [edit addItemWithTitle:@"Split Clip at Playhead" action:@selector(splitSelectedClip:) keyEquivalent:@"t"];
    NSMenuItem* deleteItem=[edit addItemWithTitle:@"Delete Selected Clip" action:@selector(deleteSelectedClip:) keyEquivalent:@"\x7f"];
    deleteItem.keyEquivalentModifierMask=0;
    editItem.submenu=edit;

    NSMenuItem* viewItem=[[NSMenuItem alloc]initWithTitle:@"View" action:nil keyEquivalent:@""];
    [main addItem:viewItem];
    NSMenu* view=[[NSMenu alloc]initWithTitle:@"View"];
    NSMenuItem* mixer=[view addItemWithTitle:@"Mixer Lower Zone" action:@selector(showMixer:) keyEquivalent:@"m"];
    mixer.keyEquivalentModifierMask=NSEventModifierFlagOption;
    NSMenuItem* midi=[view addItemWithTitle:@"MIDI Editor Lower Zone" action:@selector(showMidiEditor:) keyEquivalent:@"p"];
    midi.keyEquivalentModifierMask=NSEventModifierFlagOption;
    NSMenuItem* lower=[view addItemWithTitle:@"Show / Hide Lower Zone" action:@selector(toggleLowerZone:) keyEquivalent:@"l"];
    lower.keyEquivalentModifierMask=NSEventModifierFlagOption;
    [view addItem:[NSMenuItem separatorItem]];
    NSMenuItem* zoomOut=[view addItemWithTitle:@"Zoom Out" action:@selector(zoomOut:) keyEquivalent:@"g"];
    zoomOut.keyEquivalentModifierMask=0;
    NSMenuItem* zoomIn=[view addItemWithTitle:@"Zoom In" action:@selector(zoomIn:) keyEquivalent:@"h"];
    zoomIn.keyEquivalentModifierMask=0;
    viewItem.submenu=view;

    NSMenuItem* trItem=[[NSMenuItem alloc]initWithTitle:@"Transport" action:nil keyEquivalent:@""];
    [main addItem:trItem];
    NSMenu* tr=[[NSMenu alloc]initWithTitle:@"Transport"];
    NSMenuItem* playStop=[tr addItemWithTitle:@"Play / Stop" action:@selector(togglePlay:) keyEquivalent:@" "];
    playStop.keyEquivalentModifierMask=0;
    NSMenuItem* stop=[tr addItemWithTitle:@"Stop" action:@selector(stop:) keyEquivalent:@"."];
    stop.keyEquivalentModifierMask=0;
    NSMenuItem* record=[tr addItemWithTitle:@"Record" action:@selector(record:) keyEquivalent:@"*"];
    record.keyEquivalentModifierMask=0;
    NSMenuItem* startItem=[tr addItemWithTitle:@"Go to Project Start" action:@selector(goToStart:) keyEquivalent:@"\r"];
    startItem.keyEquivalentModifierMask=0;
    trItem.submenu=tr;

    NSMenuItem* projItem=[[NSMenuItem alloc]initWithTitle:@"Project" action:nil keyEquivalent:@""];
    [main addItem:projItem];
    NSMenu* proj=[[NSMenu alloc]initWithTitle:@"Project"];
    NSMenuItem* snap=[proj addItemWithTitle:@"Snap On / Off" action:@selector(toggleSnap:) keyEquivalent:@"j"];
    snap.keyEquivalentModifierMask=0;
    [proj addItem:[NSMenuItem separatorItem]];
    [proj addItemWithTitle:@"Audio Device…" action:@selector(audioSettings:) keyEquivalent:@","];
    [proj addItemWithTitle:@"Project Setup…" action:@selector(projectSetup:) keyEquivalent:@","];
    [proj addItemWithTitle:@"Scan VST3 Plug-ins" action:@selector(scanPlugins:) keyEquivalent:@""];
    projItem.submenu=proj;

    for (NSMenu* owned in @[file,edit,view,tr,proj]) {
        for (NSMenuItem* item in owned.itemArray) if (item.action != nil) item.target=self;
    }
    [NSApp setMainMenu:main];
}

- (void)buildMainWindow {
    _window=[[NSWindow alloc]initWithContentRect:NSMakeRect(70,60,1480,920)
                                      styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable
                                        backing:NSBackingStoreBuffered defer:NO];
    _window.title=@"Silveton";
    _window.minSize=NSMakeSize(1180,700);
    _window.backgroundColor=bgColor();
    if (@available(macOS 10.14, *)) _window.appearance=[NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
    _window.titlebarAppearsTransparent=YES;

    const CGFloat windowW=1480.0;
    const CGFloat windowH=920.0;
    const CGFloat toolbarH=64.0;
    const CGFloat dockH=230.0;

    SilvetonWorkspaceView* root=[[SilvetonWorkspaceView alloc]initWithFrame:NSMakeRect(0,0,windowW,windowH)];
    root.dropDelegate=self;
    root.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
    root.wantsLayer=YES;
    root.layer.backgroundColor=bgColor().CGColor;
    _window.contentView=root;
    const CGFloat leftW=235.0;
    const CGFloat rightW=310.0;
    const CGFloat contentTop=windowH-toolbarH;

    // One transport/header strip. Every control is wired to the realtime engine.
    NSView* toolbar=[[NSView alloc]initWithFrame:NSMakeRect(0,contentTop,windowW,toolbarH)];
    toolbar.autoresizingMask=NSViewWidthSizable|NSViewMinYMargin;
    toolbar.wantsLayer=YES;
    toolbar.layer.backgroundColor=panelColor().CGColor;
    [root addSubview:toolbar];
    NSTextField* brand=[self label:@"SILVETON" frame:NSMakeRect(12,22,86,22) size:13];
    brand.font=[NSFont systemFontOfSize:13 weight:NSFontWeightSemibold];
    brand.textColor=accentColor();
    [toolbar addSubview:brand];
    [toolbar addSubview:[self button:@"▶" action:@selector(togglePlay:) frame:NSMakeRect(108,16,44,32)]];
    [toolbar addSubview:[self button:@"■" action:@selector(stop:) frame:NSMakeRect(156,16,44,32)]];
    [toolbar addSubview:[self button:@"● REC" action:@selector(record:) frame:NSMakeRect(204,16,70,32)]];
    _metronomeButton=[[NSButton alloc]initWithFrame:NSMakeRect(282,18,94,28)];
    _metronomeButton.buttonType=NSSwitchButton;
    _metronomeButton.title=@"Metronome";
    _metronomeButton.font=[NSFont systemFontOfSize:11 weight:NSFontWeightMedium];
    _metronomeButton.target=self;
    _metronomeButton.action=@selector(toggleMetronome:);
    [toolbar addSubview:_metronomeButton];

    _timeLabel=[self label:@"00:00.000" frame:NSMakeRect(394,25,148,27) size:20];
    _timeLabel.font=[NSFont monospacedDigitSystemFontOfSize:20 weight:NSFontWeightMedium];
    [toolbar addSubview:_timeLabel];
    _projectFormatLabel=[self label:@"48.0 kHz  •  120.00 BPM" frame:NSMakeRect(395,7,165,16) size:9];
    _projectFormatLabel.textColor=dimTextColor();
    [toolbar addSubview:_projectFormatLabel];

    [toolbar addSubview:[self label:@"ZOOM" frame:NSMakeRect(570,27,40,16) size:9]];
    _zoomSlider=[[NSSlider alloc]initWithFrame:NSMakeRect(610,20,126,28)];
    _zoomSlider.minValue=25;_zoomSlider.maxValue=350;_zoomSlider.doubleValue=90;
    _zoomSlider.target=self;_zoomSlider.action=@selector(zoomChanged:);
    [toolbar addSubview:_zoomSlider];

    _snapButton=[self button:@"SNAP" action:@selector(toggleSnap:) frame:NSMakeRect(748,17,58,30)];
    _snapButton.buttonType=NSButtonTypePushOnPushOff;_snapButton.state=NSControlStateValueOn;
    [toolbar addSubview:_snapButton];
    _gridPopup=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(811,18,90,28) pullsDown:NO];
    [_gridPopup addItemsWithTitles:@[@"Grid 1/4",@"Grid 1/8",@"Grid 1/16",@"Grid 1/32"]];
    [_gridPopup selectItemAtIndex:2];
    _gridPopup.font=[NSFont systemFontOfSize:10 weight:NSFontWeightMedium];
    _gridPopup.target=self;_gridPopup.action=@selector(gridChanged:);
    [toolbar addSubview:_gridPopup];

    [toolbar addSubview:[self button:@"Mixer" action:@selector(showMixer:) frame:NSMakeRect(914,16,62,32)]];
    [toolbar addSubview:[self button:@"MIDI" action:@selector(showMidiEditor:) frame:NSMakeRect(980,16,58,32)]];
    [toolbar addSubview:[self button:@"Audio Device…" action:@selector(audioSettings:) frame:NSMakeRect(1044,16,105,32)]];
    [toolbar addSubview:[self button:@"Export" action:@selector(exportMaster:) frame:NSMakeRect(1155,16,66,32)]];
    _statusLabel=[self label:@"Ready" frame:NSMakeRect(1232,24,230,20) size:10];
    _statusLabel.textColor=dimTextColor();
    _statusLabel.autoresizingMask=NSViewWidthSizable;
    [toolbar addSubview:_statusLabel];

    // Left: project tracks + plug-in browser. This replaces floating browser/tool windows.
    NSView* left=[[NSView alloc]initWithFrame:NSMakeRect(0,dockH,leftW,contentTop-dockH)];
    _leftZone=left;
    left.autoresizingMask=NSViewHeightSizable|NSViewMaxXMargin;
    left.wantsLayer=YES;left.layer.backgroundColor=panelColor().CGColor;
    [root addSubview:left];
    const CGFloat leftH=left.bounds.size.height;
    [left addSubview:[self label:@"PROJECT" frame:NSMakeRect(10,leftH-28,100,18) size:11]];
    _trackTable=[self tableWithIdentifier:@"tracks"];
    _trackTable.rowHeight=54.0;
    NSScrollView* ts=[self scrollFor:_trackTable frame:NSMakeRect(0,leftH*0.48,leftW,leftH*0.46)];
    ts.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
    [left addSubview:ts];
    [left addSubview:[self button:@"+ Audio" action:@selector(importAudio:) frame:NSMakeRect(8,leftH*0.48-34,72,27)]];
    [left addSubview:[self button:@"+ MIDI" action:@selector(addMidiTrack:) frame:NSMakeRect(82,leftH*0.48-34,64,27)]];
    [left addSubview:[self button:@"− Track" action:@selector(removeSelectedTrack:) frame:NSMakeRect(148,leftH*0.48-34,69,27)]];
    [left addSubview:[self label:@"PLUG-INS" frame:NSMakeRect(10,leftH*0.48-63,100,18) size:11]];
    _pluginSearch=[[NSSearchField alloc]initWithFrame:NSMakeRect(8,leftH*0.48-92,leftW-16,25)];
    _pluginSearch.delegate=self;_pluginSearch.target=self;_pluginSearch.action=@selector(pluginSearchChanged:);_pluginSearch.font=[NSFont systemFontOfSize:11];
    [left addSubview:_pluginSearch];
    _pluginTable=[self tableWithIdentifier:@"plugins"];
    NSScrollView* ps=[self scrollFor:_pluginTable frame:NSMakeRect(0,39,leftW,leftH*0.48-136)];
    ps.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
    [left addSubview:ps];
    [left addSubview:[self button:@"Scan" action:@selector(scanPlugins:) frame:NSMakeRect(8,7,62,27)]];
    [left addSubview:[self button:@"Add Insert" action:@selector(addSelectedPlugin:) frame:NSMakeRect(76,7,92,27)]];

    // Center: Arrange is always the primary workspace.
    _timeline=[[SilvetonTimelineView alloc]initWithFrame:NSMakeRect(leftW,dockH,windowW-leftW-rightW,contentTop-dockH)];
    _timeline.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
    _timeline.delegate=self;
    [root addSubview:_timeline];

    // Right: context inspector. Track controls, true meters and real VST3 insert chain.
    NSView* right=[[NSView alloc]initWithFrame:NSMakeRect(windowW-rightW,dockH,rightW,contentTop-dockH)];
    _rightZone=right;
    right.autoresizingMask=NSViewHeightSizable|NSViewMinXMargin;
    right.wantsLayer=YES;right.layer.backgroundColor=panelColor().CGColor;
    [root addSubview:right];
    const CGFloat rightH=right.bounds.size.height;
    [right addSubview:[self label:@"INSPECTOR" frame:NSMakeRect(10,rightH-28,100,18) size:11]];
    [right addSubview:[self label:@"Volume" frame:NSMakeRect(10,rightH-62,52,18) size:10]];
    SilvetonResetSlider* volume=[[SilvetonResetSlider alloc]initWithFrame:NSMakeRect(62,rightH-68,160,26)];
    volume.minValue=-60;volume.maxValue=12;volume.doubleValue=0;volume.resetValue=0;volume.continuous=YES;
    volume.target=self;volume.action=@selector(trackVolumeChanged:);volume.beginAction=@selector(trackVolumeGestureBegin:);volume.endAction=@selector(trackVolumeGestureEnd:);
    _volumeSlider=volume;[right addSubview:_volumeSlider];
    _volumeValue=[self numericField:0 frame:NSMakeRect(226,rightH-66,66,22) action:@selector(trackVolumeFieldChanged:)];
    [right addSubview:_volumeValue];
    [right addSubview:[self label:@"Pan" frame:NSMakeRect(10,rightH-95,52,18) size:10]];
    SilvetonResetSlider* pan=[[SilvetonResetSlider alloc]initWithFrame:NSMakeRect(62,rightH-101,160,26)];
    pan.minValue=-1;pan.maxValue=1;pan.doubleValue=0;pan.resetValue=0;pan.continuous=YES;
    pan.target=self;pan.action=@selector(trackPanChanged:);pan.beginAction=@selector(trackPanGestureBegin:);pan.endAction=@selector(trackPanGestureEnd:);
    _panSlider=pan;[right addSubview:_panSlider];
    _panValue=[self numericField:0 frame:NSMakeRect(226,rightH-99,66,22) action:@selector(trackPanFieldChanged:)];
    [right addSubview:_panValue];
    _muteButton=[[NSButton alloc]initWithFrame:NSMakeRect(10,rightH-135,70,26)];
    _muteButton.buttonType=NSSwitchButton;_muteButton.title=@"Mute";_muteButton.target=self;_muteButton.action=@selector(trackMuteChanged:);
    [right addSubview:_muteButton];
    [right addSubview:[self button:@"Split @ Playhead" action:@selector(splitSelectedClip:) frame:NSMakeRect(90,rightH-137,112,28)]];
    [right addSubview:[self button:@"Delete Clip" action:@selector(deleteSelectedClip:) frame:NSMakeRect(206,rightH-137,94,28)]];
    _trackMeter=[[SilvetonMeterView alloc]initWithFrame:NSMakeRect(10,rightH-260,34,112)];[right addSubview:_trackMeter];
    [right addSubview:[self label:@"Track" frame:NSMakeRect(8,rightH-278,45,15) size:9]];
    _masterMeter=[[SilvetonMeterView alloc]initWithFrame:NSMakeRect(58,rightH-260,38,112)];[right addSubview:_masterMeter];
    [right addSubview:[self label:@"Master" frame:NSMakeRect(55,rightH-278,50,15) size:9]];
    [right addSubview:[self label:@"INSERTS" frame:NSMakeRect(115,rightH-166,90,18) size:10]];
    _insertTable=[self tableWithIdentifier:@"inserts"];
    NSScrollView* is=[self scrollFor:_insertTable frame:NSMakeRect(108,rightH-284,194,112)];
    is.autoresizingMask=NSViewWidthSizable;
    [right addSubview:is];
    [right addSubview:[self button:@"Open" action:@selector(openSelectedPluginEditor:) frame:NSMakeRect(108,rightH-318,52,27)]];
    [right addSubview:[self button:@"Remove" action:@selector(removeSelectedInsert:) frame:NSMakeRect(164,rightH-318,62,27)]];
    [right addSubview:[self button:@"Load" action:@selector(loadPreset:) frame:NSMakeRect(230,rightH-318,52,27)]];
    [right addSubview:[self button:@"Save" action:@selector(savePreset:) frame:NSMakeRect(108,rightH-349,52,27)]];
    [right addSubview:[self button:@"Export Stems…" action:@selector(exportStems:) frame:NSMakeRect(164,rightH-349,118,27)]];

    // Bottom dock: Mixer and MIDI live in the same main window instead of floating windows.
    _dockView=[[NSView alloc]initWithFrame:NSMakeRect(0,0,windowW,dockH)];
    _dockView.autoresizingMask=NSViewWidthSizable|NSViewMaxYMargin;
    _dockView.wantsLayer=YES;_dockView.layer.backgroundColor=panel2Color().CGColor;
    [root addSubview:_dockView];
    _dockTabs=[[NSSegmentedControl alloc]initWithFrame:NSMakeRect(12,dockH-34,260,25)];
    _dockTabs.segmentCount=3;
    [_dockTabs setLabel:@"Mixer" forSegment:0];
    [_dockTabs setLabel:@"Audio Clip" forSegment:1];
    [_dockTabs setLabel:@"MIDI Editor" forSegment:2];
    _dockTabs.selectedSegment=0;
    _dockTabs.target=self;_dockTabs.action=@selector(dockTabChanged:);
    [_dockView addSubview:_dockTabs];

    const CGFloat dockContentH=dockH-40.0;
    _mixerDock=[[NSView alloc]initWithFrame:NSMakeRect(0,0,windowW,dockContentH)];
    _mixerDock.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
    [_dockView addSubview:_mixerDock];
    _mixerTable=[self tableWithIdentifier:@"mixer"];
    NSScrollView* mixerList=[self scrollFor:_mixerTable frame:NSMakeRect(0,38,270,dockContentH-38)];
    mixerList.autoresizingMask=NSViewHeightSizable;
    [_mixerDock addSubview:mixerList];
    [_mixerDock addSubview:[self button:@"+ Group" action:@selector(addGroupBus:) frame:NSMakeRect(8,5,72,28)]];
    [_mixerDock addSubview:[self button:@"+ FX" action:@selector(addFxBus:) frame:NSMakeRect(84,5,58,28)]];
    [_mixerDock addSubview:[self button:@"− Bus" action:@selector(removeSelectedBus:) frame:NSMakeRect(146,5,62,28)]];
    [_mixerDock addSubview:[self label:@"GAIN" frame:NSMakeRect(290,dockContentH-28,55,16) size:9]];
    SilvetonResetSlider* gain=[[SilvetonResetSlider alloc]initWithFrame:NSMakeRect(290,dockContentH-58,230,26)];
    gain.minValue=-60;gain.maxValue=12;gain.resetValue=0;gain.target=self;gain.action=@selector(mixerGainChanged:);_mixerGainSlider=gain;[_mixerDock addSubview:gain];
    _mixerGainValue=[self numericField:0 frame:NSMakeRect(528,dockContentH-56,64,22) action:@selector(mixerGainFieldChanged:)];[_mixerDock addSubview:_mixerGainValue];
    [_mixerDock addSubview:[self label:@"PAN" frame:NSMakeRect(290,dockContentH-88,55,16) size:9]];
    SilvetonResetSlider* mixPan=[[SilvetonResetSlider alloc]initWithFrame:NSMakeRect(290,dockContentH-118,230,26)];
    mixPan.minValue=-1;mixPan.maxValue=1;mixPan.resetValue=0;mixPan.target=self;mixPan.action=@selector(mixerPanChanged:);_mixerPanSlider=mixPan;[_mixerDock addSubview:mixPan];
    _mixerMuteButton=[[NSButton alloc]initWithFrame:NSMakeRect(528,dockContentH-116,70,24)];_mixerMuteButton.buttonType=NSSwitchButton;_mixerMuteButton.title=@"Mute";_mixerMuteButton.target=self;_mixerMuteButton.action=@selector(mixerMuteChanged:);[_mixerDock addSubview:_mixerMuteButton];
    [_mixerDock addSubview:[self label:@"OUTPUT" frame:NSMakeRect(290,dockContentH-148,70,16) size:9]];
    _mixerOutputPopup=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(290,dockContentH-180,305,26) pullsDown:NO];_mixerOutputPopup.target=self;_mixerOutputPopup.action=@selector(mixerOutputChanged:);[_mixerDock addSubview:_mixerOutputPopup];
    [_mixerDock addSubview:[self label:@"SENDS" frame:NSMakeRect(625,dockContentH-28,70,16) size:9]];
    _sendTable=[self tableWithIdentifier:@"sends"];
    NSScrollView* sends=[self scrollFor:_sendTable frame:NSMakeRect(625,72,330,dockContentH-104)];
    sends.autoresizingMask=NSViewHeightSizable;[_mixerDock addSubview:sends];
    [_mixerDock addSubview:[self button:@"+ Send" action:@selector(addSend:) frame:NSMakeRect(625,39,64,27)]];
    [_mixerDock addSubview:[self button:@"− Send" action:@selector(removeSend:) frame:NSMakeRect(693,39,64,27)]];
    _sendDestinationPopup=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(764,39,191,27) pullsDown:NO];_sendDestinationPopup.target=self;_sendDestinationPopup.action=@selector(sendDestinationChanged:);[_mixerDock addSubview:_sendDestinationPopup];
    _sendEnabledButton=[[NSButton alloc]initWithFrame:NSMakeRect(625,9,55,24)];_sendEnabledButton.buttonType=NSSwitchButton;_sendEnabledButton.title=@"On";_sendEnabledButton.target=self;_sendEnabledButton.action=@selector(sendFlagsChanged:);[_mixerDock addSubview:_sendEnabledButton];
    _sendPreButton=[[NSButton alloc]initWithFrame:NSMakeRect(683,9,58,24)];_sendPreButton.buttonType=NSSwitchButton;_sendPreButton.title=@"Pre";_sendPreButton.target=self;_sendPreButton.action=@selector(sendFlagsChanged:);[_mixerDock addSubview:_sendPreButton];
    SilvetonResetSlider* sg=[[SilvetonResetSlider alloc]initWithFrame:NSMakeRect(748,8,207,25)];sg.minValue=-60;sg.maxValue=12;sg.resetValue=0;sg.target=self;sg.action=@selector(sendGainChanged:);_sendGainSlider=sg;[_mixerDock addSubview:sg];

    _clipDock=[[NSView alloc]initWithFrame:NSMakeRect(0,0,windowW,dockContentH)];
    _clipDock.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
    _clipDock.hidden=YES;
    [_dockView addSubview:_clipDock];
    [_clipDock addSubview:[self label:@"SELECTED AUDIO CLIP" frame:NSMakeRect(14,dockContentH-28,150,18) size:10]];
    _clipInfoLabel=[self label:@"No audio clip selected" frame:NSMakeRect(14,dockContentH-55,520,20) size:11];
    _clipInfoLabel.textColor=dimTextColor();[_clipDock addSubview:_clipInfoLabel];
    [_clipDock addSubview:[self label:@"Clip Gain" frame:NSMakeRect(14,dockContentH-91,70,18) size:10]];
    SilvetonResetSlider* clipGain=[[SilvetonResetSlider alloc]initWithFrame:NSMakeRect(86,dockContentH-98,260,28)];
    clipGain.minValue=-60;clipGain.maxValue=12;clipGain.resetValue=0;clipGain.continuous=NO;clipGain.target=self;clipGain.action=@selector(clipGainChanged:);_clipGainSlider=clipGain;[_clipDock addSubview:clipGain];
    _clipGainValue=[self numericField:0 frame:NSMakeRect(354,dockContentH-95,70,24) action:@selector(clipGainFieldChanged:)];[_clipDock addSubview:_clipGainValue];
    _clipMuteButton=[[NSButton alloc]initWithFrame:NSMakeRect(442,dockContentH-96,90,24)];_clipMuteButton.buttonType=NSSwitchButton;_clipMuteButton.title=@"Clip Mute";_clipMuteButton.target=self;_clipMuteButton.action=@selector(clipMuteChanged:);[_clipDock addSubview:_clipMuteButton];
    [_clipDock addSubview:[self label:@"Fade In ms" frame:NSMakeRect(14,dockContentH-132,72,18) size:10]];
    _clipFadeInValue=[self numericField:0 frame:NSMakeRect(88,dockContentH-136,82,24) action:@selector(clipFadesChanged:)];[_clipDock addSubview:_clipFadeInValue];
    [_clipDock addSubview:[self label:@"Fade Out ms" frame:NSMakeRect(190,dockContentH-132,78,18) size:10]];
    _clipFadeOutValue=[self numericField:0 frame:NSMakeRect(270,dockContentH-136,82,24) action:@selector(clipFadesChanged:)];[_clipDock addSubview:_clipFadeOutValue];
    [_clipDock addSubview:[self button:@"Trim Start @ Playhead" action:@selector(trimSelectedClipLeft:) frame:NSMakeRect(14,52,142,30)]];
    [_clipDock addSubview:[self button:@"Trim End @ Playhead" action:@selector(trimSelectedClipRight:) frame:NSMakeRect(162,52,138,30)]];
    [_clipDock addSubview:[self button:@"Split @ Playhead" action:@selector(splitSelectedClip:) frame:NSMakeRect(306,52,118,30)]];
    [_clipDock addSubview:[self button:@"Delete Clip" action:@selector(deleteSelectedClip:) frame:NSMakeRect(430,52,92,30)]];
    NSTextField* clipHelp=[self label:@"All clip edits are nondestructive project edits and rebuild the immutable playback plan; source audio is never overwritten." frame:NSMakeRect(14,16,760,22) size:10];
    clipHelp.textColor=dimTextColor();[_clipDock addSubview:clipHelp];

    _midiDock=[[NSView alloc]initWithFrame:NSMakeRect(0,0,windowW,dockContentH)];
    _midiDock.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
    _midiDock.hidden=YES;
    [_dockView addSubview:_midiDock];
    _midiTrackTable=[self tableWithIdentifier:@"miditracks"];
    NSScrollView* midiList=[self scrollFor:_midiTrackTable frame:NSMakeRect(0,38,210,dockContentH-38)];
    midiList.autoresizingMask=NSViewHeightSizable;[_midiDock addSubview:midiList];
    [_midiDock addSubview:[self button:@"+ MIDI Track" action:@selector(addMidiTrack:) frame:NSMakeRect(8,5,92,28)]];
    _pianoRoll=[[SilvetonPianoRollView alloc]initWithFrame:NSMakeRect(210,36,windowW-210,dockContentH-36)];
    _pianoRoll.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;_pianoRoll.delegate=self;[_midiDock addSubview:_pianoRoll];
    [_midiDock addSubview:[self button:@"Delete Note" action:@selector(deleteMidiNote:) frame:NSMakeRect(220,4,86,28)]];
    [_midiDock addSubview:[self button:@"Quantize 1/16" action:@selector(quantizeMidi:) frame:NSMakeRect(312,4,96,28)]];
    [_midiDock addSubview:[self label:@"Output" frame:NSMakeRect(430,10,45,18) size:11]];
    _midiPortPopup=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(478,4,180,28) pullsDown:NO];_midiPortPopup.target=self;_midiPortPopup.action=@selector(midiPortChanged:);[_midiDock addSubview:_midiPortPopup];

    root.autoresizesSubviews=YES;
    [self setLowerZoneVisible:NO];
}

- (void)setLowerZoneVisible:(BOOL)visible {
    if(!_window||!_leftZone||!_rightZone||!_timeline||!_dockView)return;
    NSRect bounds=_window.contentView.bounds;
    const CGFloat toolbarH=64.0;
    const CGFloat dockH=230.0;
    const CGFloat leftW=_leftZone.frame.size.width>0?_leftZone.frame.size.width:235.0;
    const CGFloat rightW=_rightZone.frame.size.width>0?_rightZone.frame.size.width:310.0;
    const CGFloat contentH=std::max<CGFloat>(0.0,bounds.size.height-toolbarH);
    const CGFloat bottom=visible?std::min(dockH,contentH*0.45):0.0;
    _dockView.hidden=!visible;
    _dockView.frame=NSMakeRect(0,0,bounds.size.width,bottom);
    _leftZone.frame=NSMakeRect(0,bottom,leftW,std::max<CGFloat>(0.0,contentH-bottom));
    _timeline.frame=NSMakeRect(leftW,bottom,std::max<CGFloat>(0.0,bounds.size.width-leftW-rightW),std::max<CGFloat>(0.0,contentH-bottom));
    _rightZone.frame=NSMakeRect(std::max<CGFloat>(0.0,bounds.size.width-rightW),bottom,rightW,std::max<CGFloat>(0.0,contentH-bottom));
    _lowerZoneVisible=visible;
}

- (void)toggleLowerZone:(id)sender {(void)sender;[self setLowerZoneVisible:!_lowerZoneVisible];}

- (void)dockTabChanged:(id)sender {
    (void)sender;
    const NSInteger selected=_dockTabs.selectedSegment;
    _mixerDock.hidden=(selected!=0);
    _clipDock.hidden=(selected!=1);
    _midiDock.hidden=(selected!=2);
    if(selected==0){
        [_mixerTable reloadData];
        if(_selectedMixerRow<0&&[self numberOfRowsInTableView:_mixerTable]>0)_selectedMixerRow=0;
        if(_selectedMixerRow>=0)[_mixerTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(_selectedMixerRow)] byExtendingSelection:NO];
        [self refreshMixerInspector];
    } else if(selected==1){
        [self refreshClipInspector];
    } else {
        [_midiTrackTable reloadData];
        if(_selectedMidiTrack<0&&!_core->session().project().midiTracks.empty())_selectedMidiTrack=0;
        [self updatePianoRollBinding];
    }
}

- (void)refreshAll {
    if(!_core)return;_updatingControls=YES;
    Project& p=_core->session().project();
    _timeline.project=&p;_timeline.selectedTrack=_selectedTrack;_timeline.selectedClipId=_selectedClipId;_timeline.pixelsPerSecond=_zoomSlider.doubleValue;_timeline.waveformCache=&_core->waveformCache();_timeline.recordingWorkflow=_core->recording();_timeline.recordingTrack=_core->recordingTrackIndex();_timeline.recordingStartSample=_core->recordingStartSample();_timeline.playheadSample=_core->engine().transport().positionSamples();
    [_trackTable reloadData];[_insertTable reloadData];[_mixerTable reloadData];[_midiTrackTable reloadData];
    _pluginResults=_browser?_browser->search(stdString(_pluginSearch.stringValue)):std::vector<Vst3CatalogEntry>{};[_pluginTable reloadData];
    if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))_selectedTrack=-1;
    if(_selectedTrack>=0){const auto&t=p.tracks[static_cast<std::size_t>(_selectedTrack)];_volumeSlider.doubleValue=t.gainDb;_panSlider.doubleValue=t.pan;_muteButton.state=t.mute?NSControlStateValueOn:NSControlStateValueOff;_volumeValue.doubleValue=t.gainDb;_panValue.doubleValue=t.pan*100.0;}
    else{_volumeSlider.doubleValue=0;_panSlider.doubleValue=0;_muteButton.state=NSControlStateValueOff;_volumeValue.stringValue=@"";_panValue.stringValue=@"";}
    _metronomeButton.state=p.metronomeEnabled?NSControlStateValueOn:NSControlStateValueOff;
    if(_snapButton)_snapButton.state=_snapEnabled?NSControlStateValueOn:NSControlStateValueOff;
    if(_projectFormatLabel)_projectFormatLabel.stringValue=[NSString stringWithFormat:@"%.1f kHz  •  %.2f BPM",p.sampleRate/1000.0,p.tempoMap.tempoAtSample(_core->engine().transport().positionSamples())];
    _timeline.needsDisplay=YES;_pianoRoll.needsDisplay=YES;
    [self refreshClipInspector];
    _updatingControls=NO;
    [self updateWindowTitle];
}
- (void)updateWindowTitle {if(!_core)return;NSString*name=_core->session().hasProjectPath()?[[nsString(_core->session().projectPath()) lastPathComponent] stringByDeletingPathExtension]:@"Untitled";_window.title=[NSString stringWithFormat:@"%@%@ — Silveton",name,_core->session().dirty()?@" *":@""];}

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView {
    if(!_core)return 0;const Project&p=_core->session().project();
    if(tableView==_trackTable)return static_cast<NSInteger>(p.tracks.size());
    if(tableView==_mixerTable)return static_cast<NSInteger>(p.tracks.size()+p.buses.size()+1U);
    if(tableView==_sendTable){
        if(_selectedMixerRow<0)return 0;
        const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);
        if(r<p.tracks.size())return static_cast<NSInteger>(p.tracks[r].sends.size());
        const std::size_t b=r-p.tracks.size();
        if(b<p.buses.size())return static_cast<NSInteger>(p.buses[b].sends.size());
        return 0;
    }
    if(tableView==_pluginTable)return static_cast<NSInteger>(_pluginResults.size());
    if(tableView==_insertTable){if(_selectedTrack<0||_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return 0;return static_cast<NSInteger>(p.tracks[static_cast<std::size_t>(_selectedTrack)].pluginSlots.size());}
    if(tableView==_midiTrackTable)return static_cast<NSInteger>(p.midiTracks.size());
    return 0;
}
- (NSView*)tableView:(NSTableView*)tableView viewForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableColumn;const Project&p=_core->session().project();
    if(tableView==_trackTable){
        NSTableCellView* cell=[tableView makeViewWithIdentifier:@"trackCell" owner:self];
        if(!cell){
            cell=[[NSTableCellView alloc]initWithFrame:NSMakeRect(0,0,tableView.bounds.size.width,54)];
            cell.identifier=@"trackCell";
            NSTextField* title=[self label:@"" frame:NSMakeRect(9,8,tableView.bounds.size.width-18,18) size:11];
            title.font=[NSFont systemFontOfSize:11 weight:NSFontWeightSemibold];title.tag=1;title.autoresizingMask=NSViewWidthSizable;[cell addSubview:title];
            NSTextField* detail=[self label:@"" frame:NSMakeRect(9,30,tableView.bounds.size.width-18,15) size:9];
            detail.textColor=dimTextColor();detail.tag=2;detail.autoresizingMask=NSViewWidthSizable;[cell addSubview:detail];
        }
        NSTextField* title=[cell viewWithTag:1];NSTextField* detail=[cell viewWithTag:2];
        const auto&t=p.tracks[static_cast<std::size_t>(row)];
        title.stringValue=[NSString stringWithFormat:@"%02ld   %@%@",(long)row+1,nsString(t.name),t.mute?@"   MUTE":@""];
        NSString* route=@"Master";
        if(t.outputBus>=0&&static_cast<std::size_t>(t.outputBus)<p.buses.size())route=nsString(p.buses[static_cast<std::size_t>(t.outputBus)].name);
        detail.stringValue=[NSString stringWithFormat:@"AUDIO   •   → %@   •   %.1f dB",route,t.gainDb];
        return cell;
    }
    NSTableCellView* cell=[tableView makeViewWithIdentifier:@"cell" owner:self];
    if(!cell){cell=[[NSTableCellView alloc]initWithFrame:NSMakeRect(0,0,tableView.bounds.size.width,25)];cell.identifier=@"cell";NSTextField*l=[self label:@"" frame:NSMakeRect(7,3,tableView.bounds.size.width-14,19) size:11];l.tag=1;l.autoresizingMask=NSViewWidthSizable;[cell addSubview:l];}
    NSTextField*l=[cell viewWithTag:1];
    if(tableView==_mixerTable){
        const std::size_t r=static_cast<std::size_t>(row);
        if(r<p.tracks.size()){const auto&t=p.tracks[r];l.stringValue=[NSString stringWithFormat:@"TRK %02ld  %@%s",(long)row+1,nsString(t.name),t.mute?"  [M]":""];}
        else if(r<p.tracks.size()+p.buses.size()){const auto&b=p.buses[r-p.tracks.size()];l.stringValue=[NSString stringWithFormat:@"%@  %@%s",b.kind==ProjectBusKind::Group?@"GROUP":@"FX",nsString(b.name),b.mute?"  [M]":""];}
        else l.stringValue=[NSString stringWithFormat:@"MASTER  %.1f dB",p.masterFaderDb];
    }
    else if(tableView==_sendTable){
        const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);const ProjectSend* send=nullptr;
        if(r<p.tracks.size()&&static_cast<std::size_t>(row)<p.tracks[r].sends.size())send=&p.tracks[r].sends[static_cast<std::size_t>(row)];
        else if(r>=p.tracks.size()&&r<p.tracks.size()+p.buses.size()){const auto&ss=p.buses[r-p.tracks.size()].sends;if(static_cast<std::size_t>(row)<ss.size())send=&ss[static_cast<std::size_t>(row)];}
        if(send){NSString*dest=send->destinationBus>=0&&static_cast<std::size_t>(send->destinationBus)<p.buses.size()?nsString(p.buses[static_cast<std::size_t>(send->destinationBus)].name):@"Invalid";l.stringValue=[NSString stringWithFormat:@"→ %@   %.1f dB   %@%s",dest,send->gainDb,send->preFader?@"PRE":@"POST",send->enabled?"":" [OFF]"];}
    }
    else if(tableView==_pluginTable){const auto&e=_pluginResults[static_cast<std::size_t>(row)];l.stringValue=[NSString stringWithFormat:@"%@ — %@",nsString(e.name),nsString(e.vendor)];}
    else if(tableView==_insertTable){const auto&s=p.tracks[static_cast<std::size_t>(_selectedTrack)].pluginSlots[static_cast<std::size_t>(row)];std::string name=s.classId;if(_browser){for(const auto&e:_browser->catalog().entries())if(e.modulePath==s.modulePath&&e.classId==s.classId){name=e.name;break;}}l.stringValue=[NSString stringWithFormat:@"%ld. %@%s",(long)row+1,nsString(name),s.enabled?"":" [BYPASS]"];}
    else if(tableView==_midiTrackTable){const auto&m=p.midiTracks[static_cast<std::size_t>(row)];l.stringValue=[NSString stringWithFormat:@"%02ld  %@  → MIDI %d",(long)row+1,nsString(m.name),m.outputPort];}
    return cell;
}
- (void)tableViewSelectionDidChange:(NSNotification*)notification {
    NSTableView*t=notification.object;
    if(t==_trackTable){_selectedTrack=t.selectedRow;if(_selectedTrack<0)_selectedTrack=-1;_selectedClipId=0;[_trackTable selectRowIndexes:(_selectedTrack>=0?[NSIndexSet indexSetWithIndex:_selectedTrack]:[NSIndexSet indexSet]) byExtendingSelection:NO];[self refreshAll];}
    else if(t==_mixerTable){_selectedMixerRow=t.selectedRow;_selectedSend=-1;[self refreshMixerInspector];}
    else if(t==_sendTable){_selectedSend=t.selectedRow;[self refreshMixerInspector];}
    else if(t==_pluginTable){_selectedPluginResult=t.selectedRow;}
    else if(t==_insertTable){_selectedInsert=t.selectedRow;}
    else if(t==_midiTrackTable){_selectedMidiTrack=t.selectedRow;[self updatePianoRollBinding];}
}

- (NSMenu*)timeline:(SilvetonTimelineView*)view contextMenuForTrack:(NSInteger)track clipId:(uint64_t)clipId sample:(int64_t)sample {
    (void)view;if(!_core)return nil;_core->engine().transport().seekSamples(std::max<int64_t>(0,sample));
    NSMenu*menu=[[NSMenu alloc]initWithTitle:@"Arrange"];
    if(track>=0&&track<static_cast<NSInteger>(_core->session().project().tracks.size())){_selectedTrack=track;_selectedClipId=clipId;[_trackTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(track)] byExtendingSelection:NO];}
    if(clipId!=0){
        ProjectAudioClip*clip=[self selectedClipMutable];
        NSMenuItem*cut=[menu addItemWithTitle:@"Cut" action:@selector(cutSelectedClip:) keyEquivalent:@""];cut.target=self;
        NSMenuItem*copy=[menu addItemWithTitle:@"Copy" action:@selector(copySelectedClip:) keyEquivalent:@""];copy.target=self;
        NSMenuItem*dup=[menu addItemWithTitle:@"Duplicate" action:@selector(duplicateSelectedClip:) keyEquivalent:@""];dup.target=self;
        [menu addItem:[NSMenuItem separatorItem]];
        NSMenuItem*split=[menu addItemWithTitle:@"Split at Cursor" action:@selector(splitSelectedClip:) keyEquivalent:@""];split.target=self;
        NSMenuItem*mute=[menu addItemWithTitle:(clip&&clip->mute?@"Unmute Clip":@"Mute Clip") action:@selector(toggleSelectedClipMuteFromMenu:) keyEquivalent:@""];mute.target=self;
        [menu addItem:[NSMenuItem separatorItem]];
        NSMenuItem*del=[menu addItemWithTitle:@"Delete Clip" action:@selector(deleteSelectedClip:) keyEquivalent:@""];del.target=self;
    }else{
        if(_clipClipboardValid){NSMenuItem*paste=[menu addItemWithTitle:@"Paste Clip Here" action:@selector(pasteClip:) keyEquivalent:@""];paste.target=self;[menu addItem:[NSMenuItem separatorItem]];}
        NSMenuItem*imp=[menu addItemWithTitle:@"Import Audio Here…" action:@selector(importAudio:) keyEquivalent:@""];imp.target=self;
        if(track>=0){[menu addItem:[NSMenuItem separatorItem]];NSMenuItem*rename=[menu addItemWithTitle:@"Rename Track…" action:@selector(renameSelectedTrack:) keyEquivalent:@""];rename.target=self;const bool muted=_core->session().project().tracks[static_cast<std::size_t>(track)].mute;NSMenuItem*mute=[menu addItemWithTitle:(muted?@"Unmute Track":@"Mute Track") action:@selector(toggleSelectedTrackMuteFromMenu:) keyEquivalent:@""];mute.target=self;}
    }
    return menu;
}

- (NSMenu*)tableView:(NSTableView*)tableView contextMenuForRow:(NSInteger)row {
    NSMenu*menu=[[NSMenu alloc]initWithTitle:@"Silveton"];
    if(tableView==_trackTable){
        if(row<0){NSMenuItem*imp=[menu addItemWithTitle:@"Import Audio…" action:@selector(importAudio:) keyEquivalent:@""];imp.target=self;return menu;}
        _selectedTrack=row;_selectedClipId=0;const auto&p=_core->session().project();
        NSMenuItem*rename=[menu addItemWithTitle:@"Rename Track…" action:@selector(renameSelectedTrack:) keyEquivalent:@""];rename.target=self;
        NSMenuItem*dup=[menu addItemWithTitle:@"Duplicate Track" action:@selector(duplicateSelectedTrack:) keyEquivalent:@""];dup.target=self;
        const bool muted=row<static_cast<NSInteger>(p.tracks.size())?p.tracks[static_cast<std::size_t>(row)].mute:false;
        NSMenuItem*mute=[menu addItemWithTitle:(muted?@"Unmute Track":@"Mute Track") action:@selector(toggleSelectedTrackMuteFromMenu:) keyEquivalent:@""];mute.target=self;
        [menu addItem:[NSMenuItem separatorItem]];
        NSMenuItem*del=[menu addItemWithTitle:@"Delete Track" action:@selector(removeSelectedTrack:) keyEquivalent:@""];del.target=self;return menu;
    }
    if(tableView==_pluginTable){
        if(row>=0){_selectedPluginResult=row;if(_selectedTrack>=0){NSMenuItem*add=[menu addItemWithTitle:@"Add as Insert" action:@selector(addSelectedPlugin:) keyEquivalent:@""];add.target=self;}}
        NSMenuItem*scan=[menu addItemWithTitle:@"Rescan VST3 Plug-ins" action:@selector(scanPlugins:) keyEquivalent:@""];scan.target=self;return menu;
    }
    if(tableView==_insertTable){
        if(row<0)return nil;_selectedInsert=row;const auto&p=_core->session().project();if(_selectedTrack<0||_selectedTrack>=static_cast<NSInteger>(p.tracks.size())||row>=static_cast<NSInteger>(p.tracks[static_cast<std::size_t>(_selectedTrack)].pluginSlots.size()))return nil;
        const auto&slot=p.tracks[static_cast<std::size_t>(_selectedTrack)].pluginSlots[static_cast<std::size_t>(row)];
        if([self selectedPluginInstance]){NSMenuItem*open=[menu addItemWithTitle:@"Open Plug-in Editor" action:@selector(openSelectedPluginEditor:) keyEquivalent:@""];open.target=self;NSMenuItem*load=[menu addItemWithTitle:@"Load Preset…" action:@selector(loadPreset:) keyEquivalent:@""];load.target=self;NSMenuItem*save=[menu addItemWithTitle:@"Save Preset…" action:@selector(savePreset:) keyEquivalent:@""];save.target=self;}
        NSMenuItem*bypass=[menu addItemWithTitle:(slot.enabled?@"Bypass Insert":@"Enable Insert") action:@selector(toggleSelectedInsertBypass:) keyEquivalent:@""];bypass.target=self;
        [menu addItem:[NSMenuItem separatorItem]];NSMenuItem*remove=[menu addItemWithTitle:@"Remove Insert" action:@selector(removeSelectedInsert:) keyEquivalent:@""];remove.target=self;return menu;
    }
    if(tableView==_sendTable){
        if(_selectedMixerRow>=0&&!_core->session().project().buses.empty()){NSMenuItem*add=[menu addItemWithTitle:@"Add Send" action:@selector(addSend:) keyEquivalent:@""];add.target=self;}
        if(row>=0){_selectedSend=row;NSMenuItem*remove=[menu addItemWithTitle:@"Remove Send" action:@selector(removeSend:) keyEquivalent:@""];remove.target=self;}return menu.numberOfItems?menu:nil;
    }
    if(tableView==_mixerTable){
        _selectedMixerRow=row;NSMenuItem*g=[menu addItemWithTitle:@"Add Group Bus" action:@selector(addGroupBus:) keyEquivalent:@""];g.target=self;NSMenuItem*f=[menu addItemWithTitle:@"Add FX Bus" action:@selector(addFxBus:) keyEquivalent:@""];f.target=self;const auto&p=_core->session().project();if(row>=static_cast<NSInteger>(p.tracks.size())&&row<static_cast<NSInteger>(p.tracks.size()+p.buses.size())){[menu addItem:[NSMenuItem separatorItem]];NSMenuItem*d=[menu addItemWithTitle:@"Delete Bus" action:@selector(removeSelectedBus:) keyEquivalent:@""];d.target=self;}return menu;
    }
    if(tableView==_midiTrackTable){if(row<0)return nil;_selectedMidiTrack=row;NSMenuItem*d=[menu addItemWithTitle:@"Delete MIDI Track" action:@selector(removeSelectedMidiTrack:) keyEquivalent:@""];d.target=self;return menu;}
    return nil;
}

- (void)timerTick:(NSTimer*)timer {(void)timer;if(!_core)return;try{_core->service();AudioEngine&e=_core->engine();const auto m=e.outputMeter();[_masterMeter setLeftPeak:m.leftPeak rightPeak:m.rightPeak];if(_selectedTrack>=0&&_selectedTrack<static_cast<NSInteger>(e.trackCount())){const auto tm=e.trackMeter(static_cast<std::size_t>(_selectedTrack));[_trackMeter setLeftPeak:tm.leftPeak rightPeak:tm.rightPeak];}else [_trackMeter setLeftPeak:0 rightPeak:0];const double sec=e.transport().positionSeconds();const NSInteger min=static_cast<NSInteger>(sec/60.0);const double rem=sec-min*60.0;_timeLabel.stringValue=[NSString stringWithFormat:@"%02ld:%06.3f",(long)min,rem];if(_projectFormatLabel){const auto&p=_core->session().project();_projectFormatLabel.stringValue=[NSString stringWithFormat:@"%.1f kHz  •  %.2f BPM",p.sampleRate/1000.0,p.tempoMap.tempoAtSample(e.transport().positionSamples())];}if(_core->recording())_statusLabel.stringValue=[NSString stringWithFormat:@"Recording — %llu frames",(unsigned long long)_core->recording()->status().framesAccepted];else{const auto st=_core->runtime().status();if(!st.media.issues.empty())_statusLabel.stringValue=[NSString stringWithFormat:@"%lu offline media item(s)",(unsigned long)st.media.issues.size()];else _statusLabel.stringValue=@"Ready";}_timeline.recordingWorkflow=_core->recording();_timeline.recordingTrack=_core->recordingTrackIndex();_timeline.recordingStartSample=_core->recordingStartSample();_timeline.playheadSample=_core->engine().transport().positionSamples();[_timeline setNeedsDisplay:YES];[self updateWindowTitle];(void)_core->session().serviceAutosave([NSProcessInfo processInfo].systemUptime);}catch(const std::exception&e){_statusLabel.stringValue=nsString(e.what());}}

- (ClipSnapSettings)currentClipSnapSettings {
    ClipSnapSettings snap;
    if(!_snapEnabled){snap.mode=ClipSnapMode::Off;return snap;}
    snap.mode=ClipSnapMode::Musical;
    switch(_gridPopup ? _gridPopup.indexOfSelectedItem : 2){
        case 0:snap.divisionsPerQuarter=1U;break;
        case 1:snap.divisionsPerQuarter=2U;break;
        case 3:snap.divisionsPerQuarter=8U;break;
        default:snap.divisionsPerQuarter=4U;break;
    }
    return snap;
}
- (void)play:(id)sender {(void)sender;if(!_core)return;_core->engine().transport().play();}
- (void)togglePlay:(id)sender {(void)sender;if(!_core)return;if(_core->engine().transport().isPlaying())[self stop:nil];else [self play:nil];}
- (void)stop:(id)sender {(void)sender;if(!_core)return;try{if(_core->recording())_core->stopRecording(true);_core->engine().transport().stop();}catch(const std::exception&e){showError(@"Stop/Record error",e.what());}}
- (void)goToStart:(id)sender {(void)sender;if(!_core)return;_core->engine().transport().seekSamples(0);[_timeline setNeedsDisplay:YES];}
- (void)record:(id)sender {(void)sender;if(!_core)return;try{if(_core->recording()){_core->stopRecording(true);[self refreshAll];return;}if(_selectedTrack<0||_selectedTrack>=static_cast<NSInteger>(_core->session().project().tracks.size()))throw std::runtime_error("select an audio track before recording");_core->beginRecording(static_cast<std::size_t>(_selectedTrack));}catch(const std::exception&e){showError(@"Recording error",e.what());}}
- (void)toggleMetronome:(id)sender {(void)sender;if(_updatingControls||!_core)return;auto&p=_core->session().project();_core->session().beginEdit("Metronome");p.metronomeEnabled=_metronomeButton.state==NSControlStateValueOn;_core->session().commitEdit();_core->engine().setMetronomeEnabled(p.metronomeEnabled);}
- (void)toggleSnap:(id)sender {
    if(sender==_snapButton)_snapEnabled=_snapButton.state==NSControlStateValueOn;
    else _snapEnabled=!_snapEnabled;
    if(_snapButton)_snapButton.state=_snapEnabled?NSControlStateValueOn:NSControlStateValueOff;
    _statusLabel.stringValue=_snapEnabled?@"Snap enabled":@"Snap disabled";
}
- (void)gridChanged:(id)sender {(void)sender;if(_gridPopup)_statusLabel.stringValue=[NSString stringWithFormat:@"%@",_gridPopup.titleOfSelectedItem];}
- (void)zoomChanged:(id)sender {(void)sender;_timeline.pixelsPerSecond=_zoomSlider.doubleValue;[_timeline setNeedsDisplay:YES];}
- (void)zoomIn:(id)sender {(void)sender;if(!_zoomSlider)return;_zoomSlider.doubleValue=std::min(_zoomSlider.maxValue,_zoomSlider.doubleValue*1.25);[self zoomChanged:_zoomSlider];}
- (void)zoomOut:(id)sender {(void)sender;if(!_zoomSlider)return;_zoomSlider.doubleValue=std::max(_zoomSlider.minValue,_zoomSlider.doubleValue/1.25);[self zoomChanged:_zoomSlider];}

- (void)trackVolumeGestureBegin:(id)sender {(void)sender;if(_updatingControls||_selectedTrack<0)return;auto&p=_core->session().project();if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return;if(!_core->session().history().transactionOpen())_core->session().beginEdit("Track Volume");auto&t=p.tracks[static_cast<std::size_t>(_selectedTrack)];_trackGainWriter.setMode(t.gainAutomationMode);_trackGainWriter.apply(AutomationGestureType::Begin,_core->engine().transport().positionSamples(),t.gainDb,t.gainAutomationDb);}
- (void)trackVolumeChanged:(id)sender {(void)sender;if(_updatingControls||_selectedTrack<0)return;auto&p=_core->session().project();if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return;auto&t=p.tracks[static_cast<std::size_t>(_selectedTrack)];t.gainDb=static_cast<float>(_volumeSlider.doubleValue);_trackGainWriter.setMode(t.gainAutomationMode);_trackGainWriter.apply(AutomationGestureType::Value,_core->engine().transport().positionSamples(),t.gainDb,t.gainAutomationDb);_core->session().markDirty();_core->engine().applyProjectTrackMixerState(p);_volumeValue.doubleValue=_volumeSlider.doubleValue;}
- (void)trackVolumeGestureEnd:(id)sender {(void)sender;if(_selectedTrack<0)return;auto&p=_core->session().project();if(_selectedTrack<static_cast<NSInteger>(p.tracks.size())){auto&t=p.tracks[static_cast<std::size_t>(_selectedTrack)];_trackGainWriter.apply(AutomationGestureType::End,_core->engine().transport().positionSamples(),t.gainDb,t.gainAutomationDb);}if(_core->session().history().transactionOpen())_core->session().commitEdit();}
- (void)trackPanGestureBegin:(id)sender {(void)sender;if(_updatingControls||_selectedTrack<0)return;auto&p=_core->session().project();if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return;if(!_core->session().history().transactionOpen())_core->session().beginEdit("Track Pan");auto&t=p.tracks[static_cast<std::size_t>(_selectedTrack)];_trackPanWriter.setMode(t.panAutomationMode);_trackPanWriter.apply(AutomationGestureType::Begin,_core->engine().transport().positionSamples(),t.pan,t.panAutomation);}
- (void)trackPanChanged:(id)sender {(void)sender;if(_updatingControls||_selectedTrack<0)return;auto&p=_core->session().project();if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return;auto&t=p.tracks[static_cast<std::size_t>(_selectedTrack)];t.pan=static_cast<float>(_panSlider.doubleValue);_trackPanWriter.setMode(t.panAutomationMode);_trackPanWriter.apply(AutomationGestureType::Value,_core->engine().transport().positionSamples(),t.pan,t.panAutomation);_core->session().markDirty();_core->engine().applyProjectTrackMixerState(p);_panValue.doubleValue=t.pan*100.0;}
- (void)trackPanGestureEnd:(id)sender {(void)sender;if(_selectedTrack<0)return;auto&p=_core->session().project();if(_selectedTrack<static_cast<NSInteger>(p.tracks.size())){auto&t=p.tracks[static_cast<std::size_t>(_selectedTrack)];_trackPanWriter.apply(AutomationGestureType::End,_core->engine().transport().positionSamples(),t.pan,t.panAutomation);}if(_core->session().history().transactionOpen())_core->session().commitEdit();}
- (void)trackVolumeFieldChanged:(id)sender {(void)sender;if(_selectedTrack<0)return;[self trackVolumeGestureBegin:_volumeSlider];_volumeSlider.doubleValue=std::clamp(_volumeValue.doubleValue,-60.0,12.0);[self trackVolumeChanged:_volumeSlider];[self trackVolumeGestureEnd:_volumeSlider];}
- (void)trackPanFieldChanged:(id)sender {(void)sender;if(_selectedTrack<0)return;[self trackPanGestureBegin:_panSlider];_panSlider.doubleValue=std::clamp(_panValue.doubleValue/100.0,-1.0,1.0);[self trackPanChanged:_panSlider];[self trackPanGestureEnd:_panSlider];}
- (void)trackMuteChanged:(id)sender {(void)sender;if(_updatingControls||_selectedTrack<0)return;auto&p=_core->session().project();if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return;auto&t=p.tracks[static_cast<std::size_t>(_selectedTrack)];_core->session().beginEdit("Track Mute");t.mute=_muteButton.state==NSControlStateValueOn;_trackMuteWriter.setMode(t.muteAutomationMode);const auto sample=_core->engine().transport().positionSamples();_trackMuteWriter.apply(AutomationGestureType::Begin,sample,t.mute?1.0F:0.0F,t.muteAutomation);_trackMuteWriter.apply(AutomationGestureType::Value,sample,t.mute?1.0F:0.0F,t.muteAutomation);_trackMuteWriter.apply(AutomationGestureType::End,sample,t.mute?1.0F:0.0F,t.muteAutomation);_core->session().commitEdit();_core->engine().applyProjectTrackMixerState(p);[_trackTable reloadData];}

- (void)newProject:(id)sender {(void)sender;if(!_core)return;try{if(_core->recording())_core->stopRecording(true);_core->engine().transport().stop();_core->session().newProject(_core->device().config().sampleRate);_core->waveformCache().clear();_selectedTrack=-1;_selectedClipId=0;[self refreshAll];}catch(const std::exception&e){showError(@"New project",e.what());}}
- (void)openProject:(id)sender {(void)sender;NSOpenPanel*p=[NSOpenPanel openPanel];p.allowedFileTypes=@[@"silveton",@"siv"];p.allowsMultipleSelection=NO;if([p runModal]!=NSModalResponseOK)return;try{if(_core->recording())_core->stopRecording(true);_core->engine().transport().stop();auto result=_core->session().open(stdString(p.URL.path));_core->waveformCache().clear();_selectedTrack=-1;_selectedClipId=0;[self refreshAll];if(result.recovered)showInfo(@"Project recovered",[NSString stringWithFormat:@"Loaded recovery copy:\n%@",nsString(result.loadedPath)]);}catch(const std::exception&e){showError(@"Open project",e.what());}}
- (void)saveProject:(id)sender {(void)sender;try{if(!_core->session().hasProjectPath()){[self saveProjectAs:nil];return;}_core->session().save();[self updateWindowTitle];}catch(const std::exception&e){showError(@"Save project",e.what());}}
- (void)saveProjectAs:(id)sender {(void)sender;NSSavePanel*p=[NSSavePanel savePanel];p.allowedFileTypes=@[@"silveton"];p.nameFieldStringValue=@"Project.silveton";if([p runModal]!=NSModalResponseOK)return;try{_core->session().saveAs(stdString(p.URL.path));[self updateWindowTitle];}catch(const std::exception&e){showError(@"Save project",e.what());}}
- (void)undo:(id)sender {(void)sender;try{if(_core->session().undo())[self refreshAll];}catch(const std::exception&e){showError(@"Undo",e.what());}}
- (void)redo:(id)sender {(void)sender;try{if(_core->session().redo())[self refreshAll];}catch(const std::exception&e){showError(@"Redo",e.what());}}

- (void)importAudioURLs:(NSArray<NSURL*>*)urls atSample:(int64_t)timelineSample {
    if(!_core||urls.count==0)return;
    Project& project=_core->session().project();
    std::size_t imported=0U,conformed=0U;
    try {
        _core->session().beginEdit("Import Audio");
        const std::string mediaDir=importedMediaDirectory(_supportDir);
        for(NSURL* u in urls) {
            if(!isSupportedAudioURL(u))continue;
            const std::string sourcePath=stdString(u.path);
            DiskStreamManager inspect(1U);auto& src=inspect.addSource(sourcePath);
            std::string mediaPath=sourcePath;
            std::uint64_t frames=src.frames();
            std::uint32_t channels=src.channels();
            std::uint32_t rate=src.sampleRate();
            if(channels==0U||channels>2U)throw std::runtime_error("Silveton import supports mono/stereo WAV and AIFF files");
            if(std::abs(static_cast<double>(rate)-project.sampleRate)>0.5) {
                NSString* base=[[[u lastPathComponent] stringByDeletingPathExtension] stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
                NSString* file=[NSString stringWithFormat:@"%@_%@_%uHz.wav",base,[NSUUID UUID].UUIDString,static_cast<unsigned>(std::llround(project.sampleRate))];
                mediaPath=mediaDir+"/"+stdString(file);
                const auto meta=ProjectMediaRelinker::conformSourceToProjectRate(project,sourcePath,mediaPath);
                frames=meta.sourceFrames;channels=meta.sourceChannels;rate=meta.sourceSampleRate;++conformed;
            }
            ProjectTrack t;t.name=stdString([[u lastPathComponent]stringByDeletingPathExtension]);t.audioPath=mediaPath;
            ProjectAudioClip c;c.id=1U;c.audioPath=mediaPath;c.timelineStartSample=std::max<int64_t>(0,timelineSample);c.lengthSamples=frames;c.sourceFrames=frames;c.sourceChannels=channels;c.sourceSampleRate=rate;t.clips.push_back(c);
            project.addTrack(std::move(t));
            _core->waveformCache().request(mediaPath);
            ++imported;
        }
        if(imported==0U)throw std::runtime_error("no supported WAV/AIFF files were selected");
        _core->session().commitEdit();
        _core->runtime().requestProjectRebuild();
        _selectedTrack=static_cast<NSInteger>(project.tracks.size())-1;_selectedClipId=1U;
        _statusLabel.stringValue=[NSString stringWithFormat:@"Imported %lu file(s)%@",(unsigned long)imported,conformed? [NSString stringWithFormat:@" — %lu conformed to %.0f Hz",(unsigned long)conformed,project.sampleRate] : @""];
        [self refreshAll];
    } catch(const std::exception& e) {
        if(_core->session().history().transactionOpen())_core->session().cancelEdit();
        showError(@"Import audio",e.what());
    }
}
- (void)importAudio:(id)sender {
    (void)sender;NSOpenPanel*p=[NSOpenPanel openPanel];p.allowedFileTypes=@[@"wav",@"aif",@"aiff"];p.allowsMultipleSelection=YES;if([p runModal]!=NSModalResponseOK)return;
    [self importAudioURLs:p.URLs atSample:_core->engine().transport().positionSamples()];
}
- (void)timeline:(SilvetonTimelineView*)view importAudioURLs:(NSArray<NSURL*>*)urls atSample:(int64_t)sample {(void)view;[self importAudioURLs:urls atSample:sample];}
- (void)timeline:(SilvetonTimelineView*)view requestZoomPixelsPerSecond:(double)pixelsPerSecond {(void)view;if(!_zoomSlider)return;_zoomSlider.doubleValue=std::clamp(pixelsPerSecond,_zoomSlider.minValue,_zoomSlider.maxValue);[self zoomChanged:_zoomSlider];}
- (void)workspace:(SilvetonWorkspaceView*)view importAudioURLs:(NSArray<NSURL*>*)urls {(void)view;if(!_core)return;[self importAudioURLs:urls atSample:_core->engine().transport().positionSamples()];}
- (void)addMidiTrack:(id)sender {(void)sender;try{ProjectMidiTrack m;m.name="MIDI "+std::to_string(_core->session().project().midiTracks.size()+1);m.outputPort=-1;_core->session().beginEdit("Add MIDI Track");_core->session().project().midiTracks.push_back(std::move(m));_core->session().commitEdit();_selectedMidiTrack=static_cast<NSInteger>(_core->session().project().midiTracks.size())-1;[self refreshAll];}catch(const std::exception&e){showError(@"Add MIDI track",e.what());}}
- (void)removeSelectedTrack:(id)sender {(void)sender;if(_selectedTrack<0)return;try{auto&p=_core->session().project();if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return;_core->session().beginEdit("Delete Track");p.tracks.erase(p.tracks.begin()+_selectedTrack);_core->session().commitEdit();_selectedTrack=std::min<NSInteger>(_selectedTrack,static_cast<NSInteger>(p.tracks.size())-1);_selectedClipId=0;[self refreshAll];}catch(const std::exception&e){showError(@"Delete track",e.what());}}
- (void)renameSelectedTrack:(id)sender {(void)sender;if(!_core||_selectedTrack<0)return;auto&p=_core->session().project();if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return;NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Rename Track";[a addButtonWithTitle:@"Rename"];[a addButtonWithTitle:@"Cancel"];NSTextField*f=[[NSTextField alloc]initWithFrame:NSMakeRect(0,0,320,24)];f.stringValue=nsString(p.tracks[static_cast<std::size_t>(_selectedTrack)].name);a.accessoryView=f;if([a runModal]!=NSAlertFirstButtonReturn)return;NSString*trim=[f.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];if(trim.length==0)return;try{_core->session().beginEdit("Rename Track");p.tracks[static_cast<std::size_t>(_selectedTrack)].name=stdString(trim);_core->session().commitEdit();[self refreshAll];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Rename track",e.what());}}
- (void)duplicateSelectedTrack:(id)sender {(void)sender;if(!_core||_selectedTrack<0)return;try{auto&p=_core->session().project();if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return;if(p.tracks.size()>=Project::kMaxTracks)throw std::length_error("Silveton track limit is 256");ProjectTrack copy=p.tracks[static_cast<std::size_t>(_selectedTrack)];copy.name += " Copy";_core->session().beginEdit("Duplicate Track");p.addTrack(std::move(copy));_core->session().commitEdit();_selectedTrack=static_cast<NSInteger>(p.tracks.size())-1;_selectedClipId=0;_core->runtime().requestProjectRebuild();[self refreshAll];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Duplicate track",e.what());}}
- (void)toggleSelectedTrackMuteFromMenu:(id)sender {(void)sender;if(!_core||_selectedTrack<0)return;auto&p=_core->session().project();if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return;_muteButton.state=p.tracks[static_cast<std::size_t>(_selectedTrack)].mute?NSControlStateValueOff:NSControlStateValueOn;[self trackMuteChanged:_muteButton];[self refreshAll];}
- (void)toggleSelectedClipMuteFromMenu:(id)sender {(void)sender;ProjectAudioClip*clip=[self selectedClipMutable];if(!clip)return;_clipMuteButton.state=clip->mute?NSControlStateValueOff:NSControlStateValueOn;[self clipMuteChanged:_clipMuteButton];}
- (void)toggleSelectedInsertBypass:(id)sender {(void)sender;if(!_core||_selectedTrack<0||_selectedInsert<0)return;try{auto&p=_core->session().project();auto&slots=p.tracks[static_cast<std::size_t>(_selectedTrack)].pluginSlots;if(_selectedInsert>=static_cast<NSInteger>(slots.size()))return;_core->session().beginEdit("Toggle Insert Bypass");slots[static_cast<std::size_t>(_selectedInsert)].enabled=!slots[static_cast<std::size_t>(_selectedInsert)].enabled;_core->session().commitEdit();_core->runtime().requestProjectRebuild();[self refreshAll];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Insert bypass",e.what());}}
- (void)removeSelectedMidiTrack:(id)sender {(void)sender;if(!_core||_selectedMidiTrack<0)return;try{auto&p=_core->session().project();if(_selectedMidiTrack>=static_cast<NSInteger>(p.midiTracks.size()))return;_core->session().beginEdit("Delete MIDI Track");p.midiTracks.erase(p.midiTracks.begin()+_selectedMidiTrack);_core->session().commitEdit();_selectedMidiTrack=std::min<NSInteger>(_selectedMidiTrack,static_cast<NSInteger>(p.midiTracks.size())-1);_selectedMidiNote=0;[self refreshAll];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Delete MIDI track",e.what());}}

- (void)timeline:(SilvetonTimelineView*)view selectedTrack:(NSInteger)track clipId:(uint64_t)clipId seekSample:(int64_t)sample {(void)view;_selectedTrack=track;_selectedClipId=clipId;_core->engine().transport().seekSamples(std::max<int64_t>(0,sample));[_trackTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(track)] byExtendingSelection:NO];if(clipId!=0&&_dockTabs){[self setLowerZoneVisible:YES];_dockTabs.selectedSegment=1;[self dockTabChanged:_dockTabs];}[self refreshAll];}
- (void)timeline:(SilvetonTimelineView*)view moveClip:(uint64_t)clipId track:(NSInteger)track toSample:(int64_t)sample {(void)view;if(track<0)return;try{Project&p=_core->session().project();ClipEditor editor(p,static_cast<std::size_t>(track));editor.moveClip(clipId,sample,[self currentClipSnapSettings]);_core->session().markDirty();_core->runtime().requestProjectRebuild();}catch(...){/* drag remains on last valid position */}}
- (void)splitSelectedClip:(id)sender {(void)sender;if(_selectedTrack<0||_selectedClipId==0)return;try{_core->session().beginEdit("Split Clip");ClipEditor e(_core->session().project(),static_cast<std::size_t>(_selectedTrack));_selectedClipId=e.splitClip(_selectedClipId,_core->engine().transport().positionSamples(),[self currentClipSnapSettings]);_core->session().commitEdit();_core->runtime().requestProjectRebuild();[self refreshAll];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Split clip",e.what());}}
- (void)deleteSelectedClip:(id)sender {(void)sender;if(_selectedTrack<0||_selectedClipId==0)return;try{_core->session().beginEdit("Delete Clip");ClipEditor e(_core->session().project(),static_cast<std::size_t>(_selectedTrack));e.removeClip(_selectedClipId);_core->session().commitEdit();_core->runtime().requestProjectRebuild();_selectedClipId=0;[self refreshAll];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Delete clip",e.what());}}

- (void)copySelectedClip:(id)sender {
    (void)sender;ProjectAudioClip* clip=[self selectedClipMutable];if(!clip)return;
    _clipClipboard=*clip;_clipClipboard.id=0U;_clipClipboardValid=YES;
    _statusLabel.stringValue=@"Clip copied";
}
- (void)cutSelectedClip:(id)sender {
    (void)sender;if(![self selectedClipMutable])return;[self copySelectedClip:nil];[self deleteSelectedClip:nil];
    _statusLabel.stringValue=@"Clip cut";
}
- (void)pasteClip:(id)sender {
    (void)sender;if(!_core||!_clipClipboardValid)return;
    try {
        Project& p=_core->session().project();
        _core->session().beginEdit("Paste Clip");
        if(_selectedTrack<0||_selectedTrack>=static_cast<NSInteger>(p.tracks.size())) {
            ProjectTrack track;
            NSString* name=[[nsString(_clipClipboard.audioPath) lastPathComponent] stringByDeletingPathExtension];
            track.name=stdString(name.length?name:@"Audio");
            track.audioPath=_clipClipboard.audioPath;
            p.addTrack(std::move(track));
            _selectedTrack=static_cast<NSInteger>(p.tracks.size())-1;
        }
        ClipEditor e(p,static_cast<std::size_t>(_selectedTrack));
        ProjectAudioClip pasted=_clipClipboard;
        pasted.id=0U;
        pasted.timelineStartSample=_core->engine().transport().positionSamples();
        _selectedClipId=e.addClip(std::move(pasted),[self currentClipSnapSettings]);
        _core->session().commitEdit();
        _core->runtime().requestProjectRebuild();
        [self refreshAll];
        _statusLabel.stringValue=@"Clip pasted";
    } catch(const std::exception& e) {
        if(_core->session().history().transactionOpen())_core->session().cancelEdit();
        showError(@"Paste clip",e.what());
    }
}
- (void)duplicateSelectedClip:(id)sender {
    (void)sender;ProjectAudioClip* clip=[self selectedClipMutable];if(!clip)return;
    try {
        const std::int64_t destination=clip->timelineStartSample+static_cast<std::int64_t>(clip->lengthSamples);
        _core->session().beginEdit("Duplicate Clip");
        ClipEditor e(_core->session().project(),static_cast<std::size_t>(_selectedTrack));
        _selectedClipId=e.duplicateClip(_selectedClipId,destination,[self currentClipSnapSettings]);
        _core->session().commitEdit();
        _core->runtime().requestProjectRebuild();
        [self refreshAll];
        _statusLabel.stringValue=@"Clip duplicated";
    } catch(const std::exception& e) {
        if(_core->session().history().transactionOpen())_core->session().cancelEdit();
        showError(@"Duplicate clip",e.what());
    }
}

- (ProjectAudioClip*)selectedClipMutable {
    if(!_core||_selectedTrack<0||_selectedClipId==0)return nullptr;
    Project& p=_core->session().project();
    if(_selectedTrack>=static_cast<NSInteger>(p.tracks.size()))return nullptr;
    auto& clips=p.tracks[static_cast<std::size_t>(_selectedTrack)].clips;
    for(auto& clip:clips)if(clip.id==_selectedClipId)return &clip;
    return nullptr;
}
- (void)refreshClipInspector {
    if(!_clipDock||!_core)return;
    ProjectAudioClip* clip=[self selectedClipMutable];
    const BOOL enabled=clip!=nullptr;
    _clipGainSlider.enabled=enabled;_clipGainValue.enabled=enabled;_clipFadeInValue.enabled=enabled;_clipFadeOutValue.enabled=enabled;_clipMuteButton.enabled=enabled;
    if(!clip){_clipInfoLabel.stringValue=@"No audio clip selected";_clipGainSlider.doubleValue=0;_clipGainValue.stringValue=@"";_clipFadeInValue.stringValue=@"";_clipFadeOutValue.stringValue=@"";_clipMuteButton.state=NSControlStateValueOff;return;}
    const double sr=_core->session().project().sampleRate>0.0?_core->session().project().sampleRate:48000.0;
    _clipGainSlider.doubleValue=clip->gainDb;_clipGainValue.doubleValue=clip->gainDb;_clipMuteButton.state=clip->mute?NSControlStateValueOn:NSControlStateValueOff;
    _clipFadeInValue.doubleValue=1000.0*static_cast<double>(clip->fadeInSamples)/sr;
    _clipFadeOutValue.doubleValue=1000.0*static_cast<double>(clip->fadeOutSamples)/sr;
    const double start=static_cast<double>(clip->timelineStartSample)/sr;
    const double len=static_cast<double>(clip->lengthSamples)/sr;
    _clipInfoLabel.stringValue=[NSString stringWithFormat:@"Clip %llu   Start %.3f s   Length %.3f s   %@",(unsigned long long)clip->id,start,len,nsString(clip->audioPath)];
}
- (void)clipGainChanged:(id)sender {(void)sender;ProjectAudioClip*clip=[self selectedClipMutable];if(!clip)return;try{_core->session().beginEdit("Clip Gain");ClipEditor e(_core->session().project(),static_cast<std::size_t>(_selectedTrack));const float gain=static_cast<float>(std::clamp(_clipGainSlider.doubleValue,-60.0,12.0));e.setGainDb(_selectedClipId,gain);_core->session().commitEdit();_core->runtime().requestProjectRebuild();[self refreshClipInspector];[_timeline setNeedsDisplay:YES];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Clip Gain",e.what());}}
- (void)clipGainFieldChanged:(id)sender {(void)sender;_clipGainSlider.doubleValue=std::clamp(_clipGainValue.doubleValue,-60.0,12.0);[self clipGainChanged:_clipGainSlider];}
- (void)clipMuteChanged:(id)sender {(void)sender;if(![self selectedClipMutable])return;try{_core->session().beginEdit("Clip Mute");ClipEditor e(_core->session().project(),static_cast<std::size_t>(_selectedTrack));e.setMute(_selectedClipId,_clipMuteButton.state==NSControlStateValueOn);_core->session().commitEdit();_core->runtime().requestProjectRebuild();[self refreshClipInspector];[_timeline setNeedsDisplay:YES];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Clip Mute",e.what());}}
- (void)clipFadesChanged:(id)sender {(void)sender;ProjectAudioClip*clip=[self selectedClipMutable];if(!clip)return;try{const double sr=_core->session().project().sampleRate>0.0?_core->session().project().sampleRate:48000.0;const double inMs=std::max(0.0,_clipFadeInValue.doubleValue);const double outMs=std::max(0.0,_clipFadeOutValue.doubleValue);const std::uint64_t fi=std::min<std::uint64_t>(clip->lengthSamples,static_cast<std::uint64_t>(std::llround(inMs*sr/1000.0)));const std::uint64_t fo=std::min<std::uint64_t>(clip->lengthSamples,static_cast<std::uint64_t>(std::llround(outMs*sr/1000.0)));_core->session().beginEdit("Clip Fades");ClipEditor e(_core->session().project(),static_cast<std::size_t>(_selectedTrack));e.setFades(_selectedClipId,fi,fo);_core->session().commitEdit();_core->runtime().requestProjectRebuild();[self refreshClipInspector];[_timeline setNeedsDisplay:YES];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Clip Fades",e.what());}}
- (void)trimSelectedClipLeft:(id)sender {(void)sender;if(![self selectedClipMutable])return;try{_core->session().beginEdit("Trim Clip Start");ClipEditor e(_core->session().project(),static_cast<std::size_t>(_selectedTrack));e.trimLeft(_selectedClipId,_core->engine().transport().positionSamples(),[self currentClipSnapSettings]);_core->session().commitEdit();_core->runtime().requestProjectRebuild();[self refreshAll];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Trim Clip",e.what());}}
- (void)trimSelectedClipRight:(id)sender {(void)sender;if(![self selectedClipMutable])return;try{_core->session().beginEdit("Trim Clip End");ClipEditor e(_core->session().project(),static_cast<std::size_t>(_selectedTrack));e.trimRight(_selectedClipId,_core->engine().transport().positionSamples(),[self currentClipSnapSettings]);_core->session().commitEdit();_core->runtime().requestProjectRebuild();[self refreshAll];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Trim Clip",e.what());}}

- (void)pluginSearchChanged:(id)sender {(void)sender;if(!_browser)return;_pluginResults=_browser->search(stdString(_pluginSearch.stringValue));[_pluginTable reloadData];}
- (void)scanPlugins:(id)sender {(void)sender;if(_scannerBusy||!_browser)return;_scannerBusy=YES;_statusLabel.stringValue=@"Scanning VST3 plug-ins…";std::vector<std::string> paths=_core->host().installedModulePaths();__weak SilvetonAppDelegate* weakSelf=self;dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{SilvetonAppDelegate* strongSelf=weakSelf;if(!strongSelf)return;std::string error;try{auto summary=strongSelf->_browser->scanModules(paths,true);std::ostringstream ss;ss<<"Scanned "<<summary.scannedModules<<" module(s), "<<summary.discoveredClasses<<" plug-in class(es); "<<summary.failedModules<<" failed";error=ss.str();}catch(const std::exception&e){error=e.what();}dispatch_async(dispatch_get_main_queue(),^{SilvetonAppDelegate* s=weakSelf;if(!s)return;s->_scannerBusy=NO;s->_statusLabel.stringValue=nsString(error);[s pluginSearchChanged:nil];});});}
- (void)addSelectedPlugin:(id)sender {(void)sender;if(_selectedTrack<0||_selectedPluginResult<0||_selectedPluginResult>=static_cast<NSInteger>(_pluginResults.size()))return;try{auto&p=_core->session().project();const auto&e=_pluginResults[static_cast<std::size_t>(_selectedPluginResult)];ProjectPluginSlot slot;slot.modulePath=e.modulePath;slot.classId=e.classId;if(looksLikeInstrument(e))slot.midiInputPort=nextMidiPort(p);_core->session().beginEdit("Add VST3 Insert");p.tracks[static_cast<std::size_t>(_selectedTrack)].pluginSlots.push_back(slot);_core->session().commitEdit();_selectedInsert=static_cast<NSInteger>(p.tracks[static_cast<std::size_t>(_selectedTrack)].pluginSlots.size())-1;[self refreshAll];}catch(const std::exception&e){showError(@"Add VST3",e.what());}}
- (void)removeSelectedInsert:(id)sender {(void)sender;if(_selectedTrack<0||_selectedInsert<0)return;try{auto&p=_core->session().project();auto&slots=p.tracks[static_cast<std::size_t>(_selectedTrack)].pluginSlots;if(_selectedInsert>=static_cast<NSInteger>(slots.size()))return;_core->session().beginEdit("Remove VST3 Insert");slots.erase(slots.begin()+_selectedInsert);_core->session().commitEdit();_selectedInsert=-1;[self refreshAll];}catch(const std::exception&e){showError(@"Remove VST3",e.what());}}
- (IVst3PluginInstance*)selectedPluginInstance {if(!_core||_selectedTrack<0||_selectedInsert<0)return nullptr;return _core->runtime().rack().trackInstance(static_cast<std::size_t>(_selectedTrack),static_cast<std::size_t>(_selectedInsert));}
- (void)openSelectedPluginEditor:(id)sender {(void)sender;try{auto*i=[self selectedPluginInstance];if(!i)throw std::runtime_error("selected plug-in instance is unavailable");if(!i->openEditor())throw std::runtime_error("plug-in did not provide an editor window");}catch(const std::exception&e){showError(@"VST3 editor",e.what());}}
- (void)savePreset:(id)sender {(void)sender;auto*i=[self selectedPluginInstance];if(!i)return;NSSavePanel*p=[NSSavePanel savePanel];p.directoryURL=[NSURL fileURLWithPath:nsString(_presetDir) isDirectory:YES];p.allowedFileTypes=@[@"vstpreset"];p.nameFieldStringValue=@"Preset.vstpreset";if([p runModal]!=NSModalResponseOK)return;try{if(!_presets.savePreset(*i,stdString(p.URL.path),stdString([[p.URL lastPathComponent]stringByDeletingPathExtension])))throw std::runtime_error("plug-in refused preset save");_presets.saveIndex(_supportDir+"/preset-index.txt");}catch(const std::exception&e){showError(@"Save preset",e.what());}}
- (void)loadPreset:(id)sender {(void)sender;auto*i=[self selectedPluginInstance];if(!i)return;NSOpenPanel*p=[NSOpenPanel openPanel];p.directoryURL=[NSURL fileURLWithPath:nsString(_presetDir) isDirectory:YES];p.allowedFileTypes=@[@"vstpreset"];p.allowsMultipleSelection=NO;if([p runModal]!=NSModalResponseOK)return;try{if(!_presets.loadPreset(*i,stdString(p.URL.path)))throw std::runtime_error("preset does not belong to this plug-in or could not be loaded");_presets.saveIndex(_supportDir+"/preset-index.txt");_core->session().markDirty();}catch(const std::exception&e){showError(@"Load preset",e.what());}}

- (void)showMixer:(id)sender {
    (void)sender;
    if(!_dockTabs||!_mixerDock)return;
    [self setLowerZoneVisible:YES];
    _dockTabs.selectedSegment=0;
    [self dockTabChanged:_dockTabs];
}

- (ProjectSend*)selectedSendMutable {
    if(!_core||_selectedMixerRow<0||_selectedSend<0)return nullptr;
    Project&p=_core->session().project();const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);
    if(r<p.tracks.size()){auto&ss=p.tracks[r].sends;return static_cast<std::size_t>(_selectedSend)<ss.size()?&ss[static_cast<std::size_t>(_selectedSend)]:nullptr;}
    const std::size_t b=r-p.tracks.size();if(b<p.buses.size()){auto&ss=p.buses[b].sends;return static_cast<std::size_t>(_selectedSend)<ss.size()?&ss[static_cast<std::size_t>(_selectedSend)]:nullptr;}return nullptr;
}
- (void)refreshMixerInspector {
    if(!_mixerDock||!_core)return;Project&p=_core->session().project();const std::size_t rows=p.tracks.size()+p.buses.size()+1U;
    if(_selectedMixerRow<0||static_cast<std::size_t>(_selectedMixerRow)>=rows){_selectedMixerRow=-1;return;}
    const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);double gain=0,pan=0;bool mute=false;int out=-1;bool panEnabled=false;bool outputEnabled=false;
    if(r<p.tracks.size()){const auto&t=p.tracks[r];gain=t.gainDb;pan=t.pan;mute=t.mute;out=t.outputBus;panEnabled=true;outputEnabled=true;}
    else if(r<p.tracks.size()+p.buses.size()){const auto&b=p.buses[r-p.tracks.size()];gain=b.gainDb;mute=b.mute;out=b.outputBus;outputEnabled=true;}
    else gain=p.masterFaderDb;
    _mixerGainSlider.doubleValue=gain;_mixerGainValue.doubleValue=gain;_mixerPanSlider.doubleValue=pan;_mixerPanSlider.enabled=panEnabled;_mixerMuteButton.state=mute?NSControlStateValueOn:NSControlStateValueOff;_mixerMuteButton.enabled=r< p.tracks.size()+p.buses.size();
    [_mixerOutputPopup removeAllItems];[_mixerOutputPopup addItemWithTitle:@"Master"];_mixerOutputPopup.lastItem.tag=0;for(std::size_t i=0;i<p.buses.size();++i){if(r>=p.tracks.size()&&r-p.tracks.size()==i)continue;[_mixerOutputPopup addItemWithTitle:nsString(p.buses[i].name)];_mixerOutputPopup.lastItem.tag=static_cast<NSInteger>(i)+1;}
    _mixerOutputPopup.enabled=outputEnabled;NSInteger outputIndex=[_mixerOutputPopup indexOfItemWithTag:out<0?0:static_cast<NSInteger>(out)+1];if(outputIndex>=0)[_mixerOutputPopup selectItemAtIndex:outputIndex];
    [_sendTable reloadData];ProjectSend*send=[self selectedSendMutable];BOOL sendOn=send!=nullptr;[_sendDestinationPopup removeAllItems];for(std::size_t i=0;i<p.buses.size();++i){[_sendDestinationPopup addItemWithTitle:nsString(p.buses[i].name)];_sendDestinationPopup.lastItem.tag=static_cast<NSInteger>(i);}
    _sendDestinationPopup.enabled=sendOn;_sendGainSlider.enabled=sendOn;_sendEnabledButton.enabled=sendOn;_sendPreButton.enabled=sendOn;if(send){NSInteger si=[_sendDestinationPopup indexOfItemWithTag:send->destinationBus];if(si>=0)[_sendDestinationPopup selectItemAtIndex:si];_sendGainSlider.doubleValue=send->gainDb;_sendEnabledButton.state=send->enabled?NSControlStateValueOn:NSControlStateValueOff;_sendPreButton.state=send->preFader?NSControlStateValueOn:NSControlStateValueOff;}else{_sendGainSlider.doubleValue=0;_sendEnabledButton.state=NSControlStateValueOff;_sendPreButton.state=NSControlStateValueOff;}
}
- (void)mixerGainChanged:(id)sender {(void)sender;if(_selectedMixerRow<0)return;Project&p=_core->session().project();const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);const float v=static_cast<float>(_mixerGainSlider.doubleValue);if(r<p.tracks.size()){p.tracks[r].gainDb=v;_core->engine().applyProjectTrackMixerState(p);}else if(r<p.tracks.size()+p.buses.size()){p.buses[r-p.tracks.size()].gainDb=v;_core->runtime().requestProjectRebuild();}else{p.masterFaderDb=v;_core->runtime().requestProjectRebuild();}_mixerGainValue.doubleValue=v;_core->session().markDirty();[_mixerTable reloadData];}
- (void)mixerGainFieldChanged:(id)sender {(void)sender;_mixerGainSlider.doubleValue=std::clamp(_mixerGainValue.doubleValue,-60.0,12.0);[self mixerGainChanged:_mixerGainSlider];}
- (void)mixerPanChanged:(id)sender {(void)sender;if(_selectedMixerRow<0)return;Project&p=_core->session().project();const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);if(r>=p.tracks.size())return;p.tracks[r].pan=static_cast<float>(_mixerPanSlider.doubleValue);_core->session().markDirty();_core->engine().applyProjectTrackMixerState(p);}
- (void)mixerMuteChanged:(id)sender {(void)sender;if(_selectedMixerRow<0)return;Project&p=_core->session().project();const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);const bool v=_mixerMuteButton.state==NSControlStateValueOn;if(r<p.tracks.size()){p.tracks[r].mute=v;_core->engine().applyProjectTrackMixerState(p);}else if(r<p.tracks.size()+p.buses.size()){p.buses[r-p.tracks.size()].mute=v;_core->runtime().requestProjectRebuild();}else return;_core->session().markDirty();[_mixerTable reloadData];}
- (void)mixerOutputChanged:(id)sender {(void)sender;if(_selectedMixerRow<0)return;Project&p=_core->session().project();const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);const NSInteger tag=_mixerOutputPopup.selectedItem.tag;const int out=tag<=0?-1:static_cast<int>(tag-1);if(r<p.tracks.size())p.tracks[r].outputBus=out;else if(r<p.tracks.size()+p.buses.size())p.buses[r-p.tracks.size()].outputBus=out;else return;_core->session().markDirty();_core->runtime().requestProjectRebuild();}
- (void)addGroupBus:(id)sender {(void)sender;try{ProjectBus b;b.kind=ProjectBusKind::Group;b.name="Group "+std::to_string(_core->session().project().buses.size()+1);_core->session().beginEdit("Add Group Bus");_core->session().project().buses.push_back(std::move(b));_core->session().commitEdit();[_mixerTable reloadData];[self refreshMixerInspector];}catch(const std::exception&e){showError(@"Add Group",e.what());}}
- (void)addFxBus:(id)sender {(void)sender;try{ProjectBus b;b.kind=ProjectBusKind::FxReturn;b.name="FX "+std::to_string(_core->session().project().buses.size()+1);_core->session().beginEdit("Add FX Bus");_core->session().project().buses.push_back(std::move(b));_core->session().commitEdit();[_mixerTable reloadData];[self refreshMixerInspector];}catch(const std::exception&e){showError(@"Add FX",e.what());}}
- (void)removeSelectedBus:(id)sender {(void)sender;if(_selectedMixerRow<0)return;Project&p=_core->session().project();const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);if(r<p.tracks.size()||r>=p.tracks.size()+p.buses.size())return;const std::size_t bi=r-p.tracks.size();try{_core->session().beginEdit("Delete Bus");for(auto&t:p.tracks){if(t.outputBus==static_cast<int>(bi))t.outputBus=-1;else if(t.outputBus>static_cast<int>(bi))--t.outputBus;t.sends.erase(std::remove_if(t.sends.begin(),t.sends.end(),[&](const ProjectSend&send){return send.destinationBus==static_cast<int>(bi);}),t.sends.end());for(auto&send:t.sends)if(send.destinationBus>static_cast<int>(bi))--send.destinationBus;}for(auto&b:p.buses){if(b.outputBus==static_cast<int>(bi))b.outputBus=-1;else if(b.outputBus>static_cast<int>(bi))--b.outputBus;b.sends.erase(std::remove_if(b.sends.begin(),b.sends.end(),[&](const ProjectSend&send){return send.destinationBus==static_cast<int>(bi);}),b.sends.end());for(auto&send:b.sends)if(send.destinationBus>static_cast<int>(bi))--send.destinationBus;}p.buses.erase(p.buses.begin()+static_cast<std::ptrdiff_t>(bi));_core->session().commitEdit();_selectedMixerRow=-1;_selectedSend=-1;[_mixerTable reloadData];[self refreshMixerInspector];}catch(const std::exception&e){if(_core->session().history().transactionOpen())_core->session().cancelEdit();showError(@"Delete Bus",e.what());}}
- (void)addSend:(id)sender {(void)sender;if(_selectedMixerRow<0)return;Project&p=_core->session().project();if(p.buses.empty()){showInfo(@"No destination bus",@"Create a Group or FX bus first.");return;}const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);ProjectSend send;send.destinationBus=0;try{_core->session().beginEdit("Add Send");if(r<p.tracks.size())p.tracks[r].sends.push_back(send);else if(r<p.tracks.size()+p.buses.size())p.buses[r-p.tracks.size()].sends.push_back(send);else{_core->session().cancelEdit();return;}_core->session().commitEdit();_selectedSend=0;[_sendTable reloadData];[self refreshMixerInspector];}catch(const std::exception&e){showError(@"Add Send",e.what());}}
- (void)removeSend:(id)sender {(void)sender;ProjectSend*selected=[self selectedSendMutable];if(!selected)return;Project&p=_core->session().project();const std::size_t r=static_cast<std::size_t>(_selectedMixerRow);try{_core->session().beginEdit("Remove Send");if(r<p.tracks.size())p.tracks[r].sends.erase(p.tracks[r].sends.begin()+_selectedSend);else p.buses[r-p.tracks.size()].sends.erase(p.buses[r-p.tracks.size()].sends.begin()+_selectedSend);_core->session().commitEdit();_selectedSend=-1;[self refreshMixerInspector];}catch(const std::exception&e){showError(@"Remove Send",e.what());}}
- (void)sendDestinationChanged:(id)sender {(void)sender;ProjectSend*s=[self selectedSendMutable];if(!s||!_sendDestinationPopup.selectedItem)return;s->destinationBus=static_cast<int>(_sendDestinationPopup.selectedItem.tag);_core->session().markDirty();_core->runtime().requestProjectRebuild();[_sendTable reloadData];}
- (void)sendGainChanged:(id)sender {(void)sender;ProjectSend*s=[self selectedSendMutable];if(!s)return;s->gainDb=static_cast<float>(_sendGainSlider.doubleValue);_core->session().markDirty();_core->runtime().requestProjectRebuild();[_sendTable reloadData];}
- (void)sendFlagsChanged:(id)sender {(void)sender;ProjectSend*s=[self selectedSendMutable];if(!s)return;s->enabled=_sendEnabledButton.state==NSControlStateValueOn;s->preFader=_sendPreButton.state==NSControlStateValueOn;_core->session().markDirty();_core->runtime().requestProjectRebuild();[_sendTable reloadData];}


- (void)showMidiEditor:(id)sender {
    (void)sender;
    if(!_dockTabs||!_midiDock)return;
    [self setLowerZoneVisible:YES];
    _dockTabs.selectedSegment=2;
    [self dockTabChanged:_dockTabs];
}

- (void)updatePianoRollBinding {if(!_pianoRoll||!_core)return;auto&p=_core->session().project();if(_selectedMidiTrack>=0&&_selectedMidiTrack<static_cast<NSInteger>(p.midiTracks.size())){auto&mt=p.midiTracks[static_cast<std::size_t>(_selectedMidiTrack)];_pianoRoll.sequence=&mt.sequence;}else _pianoRoll.sequence=nullptr;_pianoRoll.selectedNoteId=_selectedMidiNote;[_pianoRoll setNeedsDisplay:YES];[self refreshMidiPorts];}
- (void)refreshMidiPorts {if(!_midiPortPopup||!_core)return;[_midiPortPopup removeAllItems];[_midiPortPopup addItemWithTitle:@"None"];std::vector<int>ports;auto add=[&](const std::vector<ProjectPluginSlot>&slots){for(const auto&s:slots)if(s.midiInputPort>=0&&std::find(ports.begin(),ports.end(),s.midiInputPort)==ports.end())ports.push_back(s.midiInputPort);};const auto&p=_core->session().project();for(const auto&t:p.tracks)add(t.pluginSlots);for(const auto&b:p.buses)add(b.pluginSlots);add(p.masterPluginSlots);std::sort(ports.begin(),ports.end());for(int port:ports)[_midiPortPopup addItemWithTitle:[NSString stringWithFormat:@"MIDI %d",port]];if(_selectedMidiTrack>=0&&_selectedMidiTrack<static_cast<NSInteger>(p.midiTracks.size())){int target=p.midiTracks[static_cast<std::size_t>(_selectedMidiTrack)].outputPort;if(target<0)[_midiPortPopup selectItemAtIndex:0];else{NSInteger idx=0;for(NSUInteger i=1;i<_midiPortPopup.numberOfItems;++i)if([[_midiPortPopup itemTitleAtIndex:i] isEqualToString:[NSString stringWithFormat:@"MIDI %d",target]]){idx=static_cast<NSInteger>(i);break;}[_midiPortPopup selectItemAtIndex:idx];}}}
- (void)midiPortChanged:(id)sender {(void)sender;if(_selectedMidiTrack<0)return;auto&p=_core->session().project();if(_selectedMidiTrack>=static_cast<NSInteger>(p.midiTracks.size()))return;NSInteger idx=_midiPortPopup.indexOfSelectedItem;int port=-1;if(idx>0){NSString*t=[_midiPortPopup titleOfSelectedItem];port=std::max(0,[[t substringFromIndex:5] intValue]);}p.midiTracks[static_cast<std::size_t>(_selectedMidiTrack)].outputPort=port;_core->session().markDirty();_core->runtime().requestProjectRebuild();if(_core->midi())_core->midi()->setTargetPort(port);}
- (void)pianoRoll:(SilvetonPianoRollView*)view addNoteAtQuarter:(double)q pitch:(uint8_t)pitch {(void)view;if(_selectedMidiTrack<0)return;try{auto&seq=_core->session().project().midiTracks[static_cast<std::size_t>(_selectedMidiTrack)].sequence;MidiEditor ed(seq);MusicalMidiNote n;n.startQuarterNotes=std::round(q*4.0)/4.0;n.durationQuarterNotes=0.25;n.pitch=pitch;n.velocity=100;_core->session().beginEdit("Add MIDI Note");_selectedMidiNote=ed.addNote(n);_core->session().commitEdit();[self updatePianoRollBinding];}catch(const std::exception&e){showError(@"MIDI editor",e.what());}}
- (void)pianoRoll:(SilvetonPianoRollView*)view selectedNote:(uint64_t)noteId {(void)view;_selectedMidiNote=noteId;}
- (void)pianoRoll:(SilvetonPianoRollView*)view moveNote:(uint64_t)noteId toQuarter:(double)q pitch:(uint8_t)pitch {(void)view;if(_selectedMidiTrack<0)return;auto&seq=_core->session().project().midiTracks[static_cast<std::size_t>(_selectedMidiTrack)].sequence;MidiEditor ed(seq);(void)ed.moveNote(noteId,std::round(q*4.0)/4.0);(void)ed.setPitch(noteId,pitch);_core->session().markDirty();_core->runtime().requestProjectRebuild();[_pianoRoll setNeedsDisplay:YES];}
- (void)deleteMidiNote:(id)sender {(void)sender;if(_selectedMidiTrack<0||_selectedMidiNote==0)return;try{_core->session().beginEdit("Delete MIDI Note");MidiEditor ed(_core->session().project().midiTracks[static_cast<std::size_t>(_selectedMidiTrack)].sequence);(void)ed.deleteNote(_selectedMidiNote);_core->session().commitEdit();_selectedMidiNote=0;[self updatePianoRollBinding];}catch(const std::exception&e){showError(@"Delete MIDI note",e.what());}}
- (void)quantizeMidi:(id)sender {(void)sender;if(_selectedMidiTrack<0)return;try{_core->session().beginEdit("Quantize MIDI");MidiEditor ed(_core->session().project().midiTracks[static_cast<std::size_t>(_selectedMidiTrack)].sequence);ed.quantize(4.0,1.0);_core->session().commitEdit();[self updatePianoRollBinding];}catch(const std::exception&e){showError(@"Quantize MIDI",e.what());}}

- (void)audioSettings:(id)sender {(void)sender;try{auto devices=CoreAudioDevice::devices();NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Audio Device";a.informativeText=@"Choose CoreAudio device, buffer size and sample rate. Device sample rate may differ from Project rate – source will be conformed.";[a addButtonWithTitle:@"Apply"];[a addButtonWithTitle:@"Cancel"];NSView*v=[[NSView alloc]initWithFrame:NSMakeRect(0,0,360,104)];NSPopUpButton*d=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(0,72,360,26)];for(const auto&x:devices)[d addItemWithTitle:nsString(x.name)];NSPopUpButton*b=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(0,39,170,26)];for(NSString*s in @[@"64",@"128",@"256",@"512",@"1024"])[b addItemWithTitle:s];[b selectItemWithTitle:[NSString stringWithFormat:@"%u",_core->device().config().blockSize]];NSPopUpButton*sr=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(185,39,175,26)];for(NSString*s in @[@"44100",@"48000",@"88200",@"96000"])[sr addItemWithTitle:s];[sr selectItemWithTitle:[NSString stringWithFormat:@"%.0f",_core->device().config().sampleRate]];[v addSubview:d];[v addSubview:b];[v addSubview:sr];a.accessoryView=v;if([a runModal]!=NSAlertFirstButtonReturn)return;NSInteger idx=d.indexOfSelectedItem;if(idx<0||idx>=static_cast<NSInteger>(devices.size()))return;AudioDeviceConfig cfg;cfg.sampleRate=sr.titleOfSelectedItem.doubleValue;cfg.blockSize=static_cast<uint32_t>(b.titleOfSelectedItem.intValue);const auto& selectedDevice=devices[static_cast<std::size_t>(idx)];cfg.inputChannels=std::min<uint32_t>(2U,selectedDevice.inputChannels);cfg.outputChannels=std::min<uint32_t>(2U,selectedDevice.outputChannels);if(cfg.outputChannels==0U)throw std::runtime_error("selected CoreAudio device has no output channels");CoreAudioDeviceOptions opts;opts.deviceUid=selectedDevice.uid;opts.followDefaultOutputDevice=false;_core->restartAudio(cfg,opts);[self refreshAll];}catch(const std::exception&e){showError(@"Audio Device",e.what());}}

- (void)projectSetup:(id)sender {(void)sender;if(!_core)return;try{NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Project Setup";a.informativeText=@"Sample rate, Pan Law, Record bit depth. Device vs Project rate are distinct – import conform uses Silveton resampler.";[a addButtonWithTitle:@"Apply"];[a addButtonWithTitle:@"Cancel"];NSView*v=[[NSView alloc]initWithFrame:NSMakeRect(0,0,420,160)];NSTextField*l1=[self label:@"Project Sample Rate" frame:NSMakeRect(0,128,180,20) size:11];NSTextField*l2=[self label:@"Pan Law (center gain)" frame:NSMakeRect(0,88,180,20) size:11];NSTextField*l3=[self label:@"Record Bit Depth" frame:NSMakeRect(0,48,180,20) size:11];NSPopUpButton*sr=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(200,124,200,26)];[sr addItemsWithTitles:@[@"44100",@"48000",@"88200",@"96000",@"176400",@"192000"]];[sr selectItemWithTitle:[NSString stringWithFormat:@"%.0f",_core->session().project().sampleRate]];NSPopUpButton*pan=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(200,84,200,26)];[pan addItemsWithTitles:@[@"-2.5 dB (Pro Tools-like)",@"-3.0 dB (default)",@"-4.5 dB",@"-6.0 dB (linear)"]];PanDepth curPan=_core->session().project().panDepth;NSInteger panIdx=1;if(curPan==PanDepth::Minus2_5dB)panIdx=0;else if(curPan==PanDepth::Minus4_5dB)panIdx=2;else if(curPan==PanDepth::Minus6dB)panIdx=3;[pan selectItemAtIndex:panIdx];NSPopUpButton*rec=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(200,44,200,26)];[rec addItemsWithTitles:@[@"16-bit PCM",@"24-bit PCM",@"32-bit PCM",@"32-bit Float (default)"]];RecordFormat curRec=_core->session().project().recordFormat;NSInteger recIdx=3;if(curRec==RecordFormat::Int16)recIdx=0;else if(curRec==RecordFormat::Int24)recIdx=1;else if(curRec==RecordFormat::Int32)recIdx=2;[rec selectItemAtIndex:recIdx];NSTextField*info=[self label:@"Changing sample rate rebuilds graph & tempo map. Pan law affects mono pan curve. Record format is used for next recordings." frame:NSMakeRect(0,6,420,28) size:9];info.textColor=dimTextColor();[v addSubview:l1];[v addSubview:l2];[v addSubview:l3];[v addSubview:sr];[v addSubview:pan];[v addSubview:rec];[v addSubview:info];a.accessoryView=v;if([a runModal]!=NSAlertFirstButtonReturn)return;double newRate=sr.titleOfSelectedItem.doubleValue;if(!std::isfinite(newRate)||newRate<8000.0||newRate>192000.0)throw std::runtime_error("invalid project sample rate");PanDepth newPan=PanDepth::Minus3dB;switch(pan.indexOfSelectedItem){case 0:newPan=PanDepth::Minus2_5dB;break;case 2:newPan=PanDepth::Minus4_5dB;break;case 3:newPan=PanDepth::Minus6dB;break;default:newPan=PanDepth::Minus3dB;break;}RecordFormat newRec=RecordFormat::Float32;switch(rec.indexOfSelectedItem){case 0:newRec=RecordFormat::Int16;break;case 1:newRec=RecordFormat::Int24;break;case 2:newRec=RecordFormat::Int32;break;default:newRec=RecordFormat::Float32;break;}_core->session().beginEdit("Project Setup");_core->session().project().sampleRate=newRate;_core->session().project().tempoMap.setSampleRate(newRate);_core->session().project().panDepth=newPan;_core->session().project().recordFormat=newRec;_core->session().commitEdit();[self refreshAll];}catch(const std::exception&e){showError(@"Project Setup",e.what());}}

- (OfflineBounceOptions)defaultBounceOptions {OfflineBounceOptions o;o.startSample=0;o.endSample=projectEndSample(_core->session().project());o.tailMode=BounceTailMode::Automatic;o.preRollSamples=static_cast<uint64_t>(_core->session().project().sampleRate*0.1);return o;}
- (OfflineBounceFileOptions)chooseExportFormatWithPanel:(NSSavePanel*)panel cancelled:(BOOL*)cancelled {OfflineBounceFileOptions f;*cancelled=NO;NSAlert*a=[[NSAlert alloc]init];a.messageText=@"Export Format";[a addButtonWithTitle:@"Continue"];[a addButtonWithTitle:@"Cancel"];NSView*v=[[NSView alloc]initWithFrame:NSMakeRect(0,0,360,105)];NSPopUpButton*container=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(0,74,170,26)];[container addItemsWithTitles:@[@"WAV",@"AIFF"]];NSPopUpButton*format=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(185,74,175,26)];[format addItemsWithTitles:@[@"32-bit Float",@"24-bit PCM",@"16-bit PCM",@"32-bit PCM"]];NSPopUpButton*rate=[[NSPopUpButton alloc]initWithFrame:NSMakeRect(0,38,170,26)];[rate addItemsWithTitles:@[@"Project Rate",@"44100",@"48000",@"88200",@"96000"]];NSButton*dither=[[NSButton alloc]initWithFrame:NSMakeRect(185,40,175,22)];dither.buttonType=NSSwitchButton;dither.title=@"TPDF Dither";[v addSubview:container];[v addSubview:format];[v addSubview:rate];[v addSubview:dither];a.accessoryView=v;if([a runModal]!=NSAlertFirstButtonReturn){*cancelled=YES;return f;}f.container=container.indexOfSelectedItem==1?BounceContainer::Aiff:BounceContainer::Wav;switch(format.indexOfSelectedItem){case 1:f.sampleFormat=BounceSampleFormat::Pcm24;break;case 2:f.sampleFormat=BounceSampleFormat::Pcm16;break;case 3:f.sampleFormat=BounceSampleFormat::Pcm32;break;default:f.sampleFormat=BounceSampleFormat::Float32;break;}if(f.container==BounceContainer::Aiff&&f.sampleFormat==BounceSampleFormat::Float32)f.sampleFormat=BounceSampleFormat::Pcm32;f.dither=(dither.state==NSControlStateValueOn&&f.sampleFormat!=BounceSampleFormat::Float32)?BounceDither::Tpdf:BounceDither::None;if(rate.indexOfSelectedItem>0)f.outputSampleRate=static_cast<uint32_t>(rate.titleOfSelectedItem.intValue);panel.allowedFileTypes=@[f.container==BounceContainer::Aiff?@"aiff":@"wav"];return f;}
- (void)exportMaster:(id)sender {(void)sender;if(!_core)return;NSSavePanel*p=[NSSavePanel savePanel];p.nameFieldStringValue=@"Silveton Mix.wav";BOOL cancelled=NO;auto file=[self chooseExportFormatWithPanel:p cancelled:&cancelled];if(cancelled||[p runModal]!=NSModalResponseOK)return;try{if(_core->recording())throw std::runtime_error("stop recording before export");_core->engine().transport().stop();BOOL running=_core->device().isRunning();if(running)_core->device().stop();struct Restart{AppRuntime*c;BOOL r;~Restart(){if(r)try{c->device().start(c->runtime().audioCallback());}catch(...){}}}restart{_core.get(),running};auto result=OfflineBounce::renderAudioFile(stdString(p.URL.path),_core->session().project(),_core->engine(),&_core->runtime().rack(),[self defaultBounceOptions],file);showInfo(@"Export complete",[NSString stringWithFormat:@"%llu frames written\nPeak %.3f",(unsigned long long)result.writtenFrames,result.peak]);}catch(const std::exception&e){showError(@"Export",e.what());}}
- (void)exportStems:(id)sender {(void)sender;if(!_core)return;NSOpenPanel*p=[NSOpenPanel openPanel];p.canChooseFiles=NO;p.canChooseDirectories=YES;p.canCreateDirectories=YES;if([p runModal]!=NSModalResponseOK)return;try{if(_core->recording())throw std::runtime_error("stop recording before export");std::vector<TrackStemRequest> req;const auto&project=_core->session().project();for(std::size_t i=0;i<project.tracks.size();++i){TrackStemRequest r;r.trackIndices={i};r.path=stdString(p.URL.path)+"/"+sanitizedFileName(project.tracks[i].name)+".wav";req.push_back(std::move(r));}if(req.empty())throw std::runtime_error("project has no audio tracks");_core->engine().transport().stop();BOOL running=_core->device().isRunning();if(running)_core->device().stop();struct Restart{AppRuntime*c;BOOL r;~Restart(){if(r)try{c->device().start(c->runtime().audioCallback());}catch(...){}}}restart{_core.get(),running};OfflineBounceFileOptions f;f.container=BounceContainer::Wav;f.sampleFormat=BounceSampleFormat::Float32;auto results=StemBounce::renderTrackStems(_core->session().project(),_core->engine(),&_core->runtime().rack(),[self defaultBounceOptions],f,req);showInfo(@"Stem export complete",[NSString stringWithFormat:@"%lu track stem(s) written",(unsigned long)results.size()]);}catch(const std::exception&e){showError(@"Stem export",e.what());}}

- (BOOL)validateMenuItem:(NSMenuItem*)item {
    SEL a=item.action;
    if(a==@selector(copySelectedClip:)||a==@selector(cutSelectedClip:)||a==@selector(duplicateSelectedClip:)||a==@selector(splitSelectedClip:)||a==@selector(deleteSelectedClip:))
        return [self selectedClipMutable]!=nullptr;
    if(a==@selector(pasteClip:))return _clipClipboardValid;
    if(a==@selector(record:))return _core!=nullptr&&_selectedTrack>=0&&_selectedTrack<static_cast<NSInteger>(_core->session().project().tracks.size());
    return YES;
}

@end

int main(int argc,const char*argv[]){(void)argc;(void)argv;@autoreleasepool{NSApplication*app=[NSApplication sharedApplication];SilvetonAppDelegate*delegate=[[SilvetonAppDelegate alloc]init];app.delegate=delegate;[app run];}return 0;}
