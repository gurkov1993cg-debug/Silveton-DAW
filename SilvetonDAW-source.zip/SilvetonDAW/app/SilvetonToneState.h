// Silveton Tone Editor — what the window and the controller share about the sound that is open.
// Everything here is touched on the main thread only, except the three shared pointers that the
// background jobs read (`audio`, `analysis`) and the two flags they poll.
#pragma once

#include "silveton/ToneEdit.h"
#include "silveton/ToneProject.h"

#include <atomic>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

enum class SVToneTool : int {
    Select = 0,   // pick blocks, drag them up and down, drag their edges
    Time,         // drag blocks left and right, stretch them, bend the sound with points
    Cut,          // click in a block to cut it in two
    Glue,         // click a block to join it with the next one
    Erase,        // click a block to remove it
    Draw          // drag over a gap to make a new block
};

// The sliders of the Tone Editor panel (index = the slider's tag).
enum SVToneParam : int {
    SVToneParamSnap = 0, SVToneParamFlatten, SVToneParamVibrato, SVToneParamTilt, SVToneParamMove,
    SVToneParamFormant, SVToneParamGain, SVToneParamTransition, SVToneParamTimingAmount,
    SVToneParamSensitivity, SVToneParamSplitSensitivity, SVToneParamLowest, SVToneParamHighest, SVToneParamMinBlock,
    SVToneParamCount
};

struct SVToneSession {
    enum class Phase { Loading, Ready, Failed };

    std::size_t track {0U};
    std::uint64_t clipId {0U};
    std::string clipName;
    silveton::ToneSource source;
    std::shared_ptr<const silveton::AudioBuffer> audio;        // the original sound at the project rate
    std::shared_ptr<const silveton::ToneAnalysis> analysis;
    silveton::ToneEdit edit;
    std::string renderedPath;          // the file the clip is known to play (used to see undo / redo)
    std::int64_t origin {0};           // timeline sample of position 0
    double rate {48000.0};
    Phase phase {Phase::Loading};
    std::string message;               // why it failed, or a hint

    std::shared_ptr<std::atomic<bool>> stop {std::make_shared<std::atomic<bool>>(false)};          // analysis
    std::shared_ptr<std::atomic<float>> progress {std::make_shared<std::atomic<float>>(0.0F)};
    std::shared_ptr<std::atomic<bool>> renderStop {std::make_shared<std::atomic<bool>>(false)};     // render

    std::uint64_t editGeneration {0U};     // counts the user's changes
    std::uint64_t timerGeneration {0U};    // restarts the quiet-time wait before a render
    bool dirty {false};                    // the edit differs from what the clip plays
    bool rendering {false};
    bool dragging {false};                 // a mouse drag is going on: no render until it ends
    std::string pendingLabel {"Tone Edit"};

    std::vector<std::uint32_t> selected;
    bool selectedHas(std::uint32_t id) const {
        for (const std::uint32_t s : selected) if (s == id) return true;
        return false;
    }
};
