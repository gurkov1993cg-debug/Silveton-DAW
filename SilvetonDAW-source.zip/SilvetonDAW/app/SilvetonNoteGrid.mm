// Silveton Key Editor — the note grid.
// Notes sit on a piano grid with the keyboard on the left, the playhead over them and up to four lanes below
// (velocity and controllers). Seven tools: Select, Draw, Erase, Cut, Glue, Mute and Line. Everything that changes the
// notes goes through KeyEditing (the tested core) and the controller's undo steps; this file only handles mouse, keys and drawing.
#import "SilvetonViews.h"
#include "SilvetonKeyState.h"
#include "SilvetonTheme.h"

#include "silveton/KeyEditing.h"

#include <algorithm>
#include <cmath>
#include <unordered_set>
#include <vector>

using namespace silveton;

namespace {
constexpr CGFloat kKeysW = 84.0;
constexpr CGFloat kRulerH = 28.0;
constexpr CGFloat kLaneMax = 84.0;
constexpr CGFloat kLaneMin = 48.0;
constexpr std::size_t kMaxLanes = 4U;
constexpr CGFloat kDragStart = 3.0;
constexpr CGFloat kEdgeGrab = 6.0;
constexpr CGFloat kPointGrab = 8.0;
constexpr CGFloat kMinRow = 8.0;
constexpr CGFloat kMaxRow = 34.0;

enum class Gesture {
    None, Seek, Keyboard, Move, Resize, Create, Rubber, Sweep, SweepMute,
    VelBar, VelPaint, LaneRubber, LanePoints, LanePaint, LaneLine, LaneSweep
};

bool isBlack(int pitch) { const int pc = pitch % 12; return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10; }

NSString* positionText(double tq, double barQ) {
    if (!(barQ > 0.0)) barQ = 4.0;
    tq = std::max(0.0, tq);
    const double bars = std::floor(tq / barQ + 1.0e-9);
    const double within = tq - bars * barQ;
    long beat = static_cast<long>(std::floor(within + 1.0e-9));
    long ticks = std::lround((within - static_cast<double>(beat)) * 480.0);
    if (ticks >= 480) { ticks -= 480; ++beat; }
    return [NSString stringWithFormat:@"%ld.%ld.%03ld", static_cast<long>(bars) + 1, beat + 1, ticks];
}

NSString* lengthText(double q) {
    struct V { double q; const char* name; };
    static const V values[] = {{4.0, "1/1"}, {3.0, "1/2."}, {2.0, "1/2"}, {1.5, "1/4."}, {1.0, "1/4"}, {0.75, "1/8."},
                               {0.5, "1/8"}, {0.375, "1/16."}, {0.25, "1/16"}, {0.125, "1/32"}, {0.0625, "1/64"}};
    for (const auto& v : values) if (std::abs(q - v.q) < 1.0e-6) return [NSString stringWithUTF8String:v.name];
    return [NSString stringWithFormat:@"%.3f beats", q];
}

NSString* laneTitle(const KeyLane& lane) {
    NSString* full = [NSString stringWithUTF8String:lane.name().c_str()];
    NSRange r = [full rangeOfString:@" ("];
    return (r.location == NSNotFound ? full : [full substringToIndex:r.location]).uppercaseString;
}
NSString* laneSubtitle(const KeyLane& lane) {
    if (lane.kind != KeyLane::Kind::Controller) return @"";
    return [NSString stringWithFormat:@"CC %d", static_cast<int>(lane.number)];
}
} // namespace

@implementation SilvetonNoteGridView {
    std::unordered_set<std::uint64_t> _sel;
    std::unordered_set<std::uint64_t> _selMsg;
    std::vector<KeyLane> _lanes;
    std::size_t _activeLane;

    Gesture _g;
    NSPoint _down, _last, _mouse;
    NSEventModifierFlags _downFlags, _lastFlags;
    BOOL _moved, _gestureOpen, _mouseIn, _copyOnDrag;
    double _downQ, _grabOffsetQ, _lineQ0, _paintQ;
    int _downPitch, _lineV0, _paintV, _grabVelocity, _grabValue;
    std::uint64_t _grab, _collapseTo;
    std::vector<MusicalMidiNote> _orig;
    std::vector<MusicalMidiMessage> _origMsgs;
    NSRect _rubber;
    BOOL _rubberAdd;
    std::unordered_set<std::uint64_t> _rubberBase;
    int _sweepMute;
    int _auditionPitch;
    int _hoverPitch;
    CGFloat _lastPlayX;
    double _lineQ1;
    int _lineV1;
    NSTrackingArea* _tracking;
}

- (instancetype)initWithFrame:(NSRect)frame {
    if ((self = [super initWithFrame:frame])) {
        _quarterWidth = 96.0;
        _scrollPitch = 84.0;
        _rowHeight = 14.0;
        _lanes.push_back(KeyLane::velocity());
        _activeLane = 0U;
        _g = Gesture::None;
        _auditionPitch = -1;
        _hoverPitch = -1;
        _lastPlayX = -1000.0;
        _rubber = NSZeroRect;
    }
    return self;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (BOOL)acceptsFirstMouse:(NSEvent*)event { (void)event; return YES; }

- (void)updateTrackingAreas {
    [super updateTrackingAreas];
    if (_tracking) [self removeTrackingArea:_tracking];
    _tracking = [[NSTrackingArea alloc] initWithRect:self.bounds
                                             options:NSTrackingMouseMoved | NSTrackingMouseEnteredAndExited | NSTrackingActiveInKeyWindow | NSTrackingInVisibleRect
                                               owner:self userInfo:nil];
    [self addTrackingArea:_tracking];
}

// ================================================================ geometry ==
- (MidiSequence*)seq { return [self.controller editedSequence]; }
- (CGFloat)laneHeight {
    const CGFloat room = self.bounds.size.height - kRulerH - 150.0;
    return std::clamp(room / static_cast<CGFloat>(_lanes.size()), kLaneMin, kLaneMax);
}
- (CGFloat)gridBottom { return self.bounds.size.height - [self laneHeight] * static_cast<CGFloat>(_lanes.size()); }
- (NSRect)laneRect:(std::size_t)i {
    const CGFloat h = [self laneHeight];
    return NSMakeRect(0, [self gridBottom] + h * static_cast<CGFloat>(i), self.bounds.size.width, h);
}
- (long)laneAtY:(CGFloat)y {
    const CGFloat top = [self gridBottom];
    if (y < top) return -1;
    const long i = static_cast<long>(std::floor((y - top) / [self laneHeight]));
    return i < static_cast<long>(_lanes.size()) ? i : static_cast<long>(_lanes.size()) - 1;
}
- (NSRect)plotRect:(std::size_t)i {
    const NSRect r = [self laneRect:i];
    return NSMakeRect(kKeysW, r.origin.y + 7.0, r.size.width - kKeysW, r.size.height - 14.0);
}
- (double)quarterForX:(CGFloat)x { return (x - kKeysW) / self.quarterWidth + self.scrollQuarters; }
- (CGFloat)xForQuarter:(double)q { return kKeysW + (q - self.scrollQuarters) * self.quarterWidth; }
- (int)pitchForY:(CGFloat)y { return std::clamp(static_cast<int>(std::floor(self.scrollPitch - (y - kRulerH) / self.rowHeight)) + 1, 0, 127); }
- (CGFloat)yForPitch:(int)pitch { return kRulerH + (self.scrollPitch - pitch) * self.rowHeight; }
- (double)gridStep { return 1.0 / std::max<std::uint32_t>(1U, [self.controller gridDivisionsPerQuarter]); }
- (double)snap:(double)q {
    if (![self.controller snapEnabled]) return std::max(0.0, q);
    const double step = [self gridStep];
    return std::max(0.0, std::round(q / step) * step);
}
- (double)snapDown:(double)q {
    if (![self.controller snapEnabled]) return std::max(0.0, q);
    const double step = [self gridStep];
    return std::max(0.0, std::floor(q / step + 1.0e-9) * step);
}
- (int)valueForY:(CGFloat)y lane:(std::size_t)i {
    const NSRect plot = [self plotRect:i];
    const double t = std::clamp((NSMaxY(plot) - y) / std::max<CGFloat>(1.0, plot.size.height), 0.0, 1.0);
    const KeyLane& lane = _lanes[i];
    const int v = static_cast<int>(std::lround(t * lane.maxValue()));
    return lane.kind == KeyLane::Kind::Velocity ? std::clamp(v, 1, 127) : v;
}
- (CGFloat)yForValue:(int)v lane:(std::size_t)i {
    const NSRect plot = [self plotRect:i];
    return NSMaxY(plot) - static_cast<CGFloat>(v) / static_cast<CGFloat>(_lanes[i].maxValue()) * plot.size.height;
}
- (BOOL)inGrid:(NSPoint)p { return p.x >= kKeysW && p.y >= kRulerH && p.y < [self gridBottom]; }

- (const MusicalMidiNote*)noteAt:(NSPoint)p {
    MidiSequence* seq = [self seq];
    if (!seq || ![self inGrid:p]) return nullptr;
    const int pitch = [self pitchForY:p.y];
    const MusicalMidiNote* found = nullptr;
    for (const auto& n : seq->notes()) {
        if (n.pitch != pitch) continue;
        const CGFloat x0 = [self xForQuarter:n.startQuarterNotes];
        const CGFloat x1 = std::max([self xForQuarter:n.startQuarterNotes + n.durationQuarterNotes], x0 + 4.0);
        if (p.x >= x0 && p.x <= x1) found = &n;
    }
    return found;
}

- (SVKeyState*)state { return [self.controller keyState]; }

// ============================================================== selection ==
- (std::vector<std::uint64_t>)selection {
    std::vector<std::uint64_t> out(_sel.begin(), _sel.end());
    std::sort(out.begin(), out.end());
    return out;
}
- (void)setSelection:(const std::vector<std::uint64_t>&)ids {
    _sel = std::unordered_set<std::uint64_t>(ids.begin(), ids.end());
    [self setNeedsDisplay:YES];
}
- (BOOL)hasSelection { return !_sel.empty() || !_selMsg.empty(); }
- (void)selectionChanged {
    MidiSequence* seq = [self seq];
    std::unordered_set<std::uint64_t> alive;
    std::unordered_set<std::uint64_t> aliveMsg;
    if (seq) {
        for (const auto& n : seq->notes()) if (_sel.count(n.id)) alive.insert(n.id);
        for (const auto& m : seq->messages()) if (_selMsg.count(m.id)) aliveMsg.insert(m.id);
    }
    if (alive.size() != _sel.size() || aliveMsg.size() != _selMsg.size()) {
        _sel = std::move(alive);
        _selMsg = std::move(aliveMsg);
    }
    [self setNeedsDisplay:YES];
}
- (void)selectIds:(const std::vector<std::uint64_t>&)ids add:(BOOL)add {
    if (!add) _sel.clear();
    for (const std::uint64_t id : ids) _sel.insert(id);
    _selMsg.clear();
    [self setNeedsDisplay:YES];
}

// ================================================================ audition ==
- (void)auditionPitch:(int)pitch velocity:(int)velocity {
    SVKeyState* st = [self state];
    if (!st || !st->listen) return;
    if (pitch == _auditionPitch) return;
    [self stopAudition];
    [self.controller keyAudition:pitch velocity:velocity on:YES];
    _auditionPitch = pitch;
}
- (void)stopAudition {
    if (_auditionPitch >= 0) [self.controller keyAudition:_auditionPitch velocity:0 on:NO];
    _auditionPitch = -1;
}

// ================================================================== drawing ==
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    SilvetonController* c = self.controller;
    const NSRect b = self.bounds;
    sv::fill(b, sv::canvas());
    MidiSequence* seq = c ? [c editedSequence] : nullptr;
    SVKeyState* st = c ? [c keyState] : nullptr;
    const CGFloat gridBottom = [self gridBottom];
    const double offset = c ? [c editedPartOffsetQuarterNotes] : 0.0;
    const double barQ = c ? [c keyBarQuarters] : 4.0;

    [self drawRows:st gridBottom:gridBottom];
    [self drawVerticalLines:offset barQ:barQ gridBottom:gridBottom];

    if (!seq) {
        sv::textIn(@"Select a MIDI part (double-click it in the Project window) to edit its notes",
                   NSMakeRect(kKeysW, gridBottom * 0.45, b.size.width - kKeysW, 20), sv::ui(13, true), sv::inkDim(), NSTextAlignmentCenter);
        [self drawKeyboard:gridBottom];
        [self drawRulerOffset:offset barQ:barQ seq:nullptr];
        [self drawLaneFrames];
        return;
    }

    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(kKeysW, kRulerH, b.size.width - kKeysW, gridBottom - kRulerH));
    [self drawPartShade:gridBottom];
    [self drawNotes:seq gridBottom:gridBottom];
    [self drawGhost:st gridBottom:gridBottom];
    if (!NSIsEmptyRect(_rubber) && (_g == Gesture::Rubber)) {
        sv::fill(_rubber, [sv::copper() colorWithAlphaComponent:0.12]);
        sv::roundStroke(_rubber, 0, sv::copper(), 1.0);
    }
    [NSGraphicsContext restoreGraphicsState];

    [self drawKeyboard:gridBottom];
    [self drawLaneFrames];
    for (std::size_t i = 0U; i < _lanes.size(); ++i) [self drawLane:i seq:seq];
    [self drawRulerOffset:offset barQ:barQ seq:seq];
    [self drawPlayhead:gridBottom];
}

- (void)drawRows:(SVKeyState*)st gridBottom:(CGFloat)gridBottom {
    const NSRect b = self.bounds;
    const int top = std::clamp(static_cast<int>(std::ceil(self.scrollPitch)) + 1, 0, 127);
    const int bottom = std::clamp(static_cast<int>(std::floor(self.scrollPitch - (gridBottom - kRulerH) / self.rowHeight)) - 1, 0, 127);
    const bool scaleOn = st && st->scaleRows && !st->scale.chromatic();
    for (int pitch = top; pitch >= bottom; --pitch) {
        const CGFloat y = [self yForPitch:pitch];
        if (y > gridBottom || y + self.rowHeight < kRulerH) continue;
        sv::fill(NSMakeRect(kKeysW, y, b.size.width - kKeysW, self.rowHeight), isBlack(pitch) ? sv::laneA() : sv::laneB());
        if (scaleOn) {
            if (!st->scale.contains(pitch)) sv::fill(NSMakeRect(kKeysW, y, b.size.width - kKeysW, self.rowHeight), [NSColor colorWithCalibratedWhite:0.0 alpha:0.30]);
            else if (pitch % 12 == ((st->scale.root % 12) + 12) % 12) sv::fill(NSMakeRect(kKeysW, y, b.size.width - kKeysW, self.rowHeight), [sv::copper() colorWithAlphaComponent:0.10]);
        }
        if (pitch == _hoverPitch && _mouseIn) sv::fill(NSMakeRect(kKeysW, y, b.size.width - kKeysW, self.rowHeight), [NSColor colorWithCalibratedWhite:1.0 alpha:0.05]);
        if (pitch % 12 == 0) sv::line(NSMakePoint(kKeysW, y + self.rowHeight - 0.5), NSMakePoint(b.size.width, y + self.rowHeight - 0.5), sv::hairline());
    }
}

- (void)drawVerticalLines:(double)offset barQ:(double)barQ gridBottom:(CGFloat)gridBottom {
    const NSRect b = self.bounds;
    double step = [self gridStep];
    while (step * self.quarterWidth < 8.0) step *= 2.0;
    const double q1 = [self quarterForX:b.size.width];
    for (long i = static_cast<long>(std::floor(self.scrollQuarters / step));; ++i) {
        const double q = static_cast<double>(i) * step;
        if (q > q1) break;
        const CGFloat x = std::floor([self xForQuarter:q]) + 0.5;
        if (x < kKeysW) continue;
        const double tq = q + offset;
        double m = std::fmod(tq, barQ);
        if (m < 0.0) m += barQ;
        const bool bar = m < 1.0e-6 || m > barQ - 1.0e-6;
        const bool beat = std::abs(tq - std::round(tq)) < 1.0e-6;
        NSColor* col = bar ? sv::hex(0x2E3138) : (beat ? sv::hex(0x24272D) : sv::hex(0x1C1D22));
        sv::line(NSMakePoint(x, kRulerH), NSMakePoint(x, gridBottom), col);
    }
}

- (void)drawPartShade:(CGFloat)gridBottom {
    double a = 0.0, e = 0.0;
    if (![self.controller keyPartRange:&a end:&e]) return;
    const CGFloat xa = [self xForQuarter:a], xe = [self xForQuarter:e];
    NSColor* shade = [NSColor colorWithCalibratedWhite:0.0 alpha:0.38];
    if (xa > kKeysW) sv::fill(NSMakeRect(kKeysW, kRulerH, xa - kKeysW, gridBottom - kRulerH), shade);
    if (xe < self.bounds.size.width) sv::fill(NSMakeRect(std::max(kKeysW, xe), kRulerH, self.bounds.size.width - std::max(kKeysW, xe), gridBottom - kRulerH), shade);
    sv::line(NSMakePoint(std::floor(xa) + 0.5, kRulerH), NSMakePoint(std::floor(xa) + 0.5, gridBottom), sv::copperDeep());
    sv::line(NSMakePoint(std::floor(xe) + 0.5, kRulerH), NSMakePoint(std::floor(xe) + 0.5, gridBottom), sv::copperDeep());
}

- (void)drawNotes:(MidiSequence*)seq gridBottom:(CGFloat)gridBottom {
    const CGFloat width = self.bounds.size.width;
    const BOOL label = self.rowHeight >= 16.0;
    for (const auto& n : seq->notes()) {
        const CGFloat x0 = [self xForQuarter:n.startQuarterNotes];
        const CGFloat x1 = [self xForQuarter:n.startQuarterNotes + n.durationQuarterNotes];
        if (x1 < kKeysW || x0 > width) continue;
        const CGFloat y = [self yForPitch:n.pitch];
        if (y > gridBottom || y + self.rowHeight < kRulerH) continue;
        const NSRect r = NSMakeRect(x0, y + 1, std::max<CGFloat>(4, x1 - x0 - 1), self.rowHeight - 2);
        const BOOL sel = _sel.count(n.id) != 0U;
        NSColor* col = [sv::copperDeep() blendedColorWithFraction:n.velocity / 127.0 ofColor:sv::amber()];
        if (n.muted) col = [sv::inkFaint() colorWithAlphaComponent:0.55];
        else if (sel) col = [col blendedColorWithFraction:0.35 ofColor:sv::ink()];
        sv::roundFill(r, 3, col);
        if (r.size.width > 12.0) sv::fill(NSMakeRect(NSMaxX(r) - 2.0, r.origin.y + 1.0, 2.0, r.size.height - 2.0), [NSColor colorWithCalibratedWhite:0.0 alpha:0.25]);
        if (sel) sv::roundStroke(r, 3, sv::ink(), 1.5);
        if (label && r.size.width >= 28.0)
            sv::text([NSString stringWithUTF8String:KeyEditing::noteName(n.pitch).c_str()], NSMakePoint(r.origin.x + 4.0, r.origin.y + (r.size.height - 12.0) * 0.5),
                     sv::mono(10, true), sv::canvas());
    }
}

- (void)drawGhost:(SVKeyState*)st gridBottom:(CGFloat)gridBottom {
    if (!st || st->tool != SVKeyTool::Draw || !_mouseIn || _g != Gesture::None || ![self inGrid:_mouse]) return;
    if ([self noteAt:_mouse]) return;
    int pitch = [self pitchForY:_mouse.y];
    if (st->scaleSnap) pitch = KeyEditing::pitchInScale(pitch, st->scale);
    const double q = [self snapDown:[self quarterForX:_mouse.x]];
    const CGFloat x0 = [self xForQuarter:q], x1 = [self xForQuarter:q + [self.controller keyInsertLength]];
    const CGFloat y = [self yForPitch:pitch];
    if (y > gridBottom) return;
    sv::roundStroke(NSMakeRect(x0, y + 1, std::max<CGFloat>(4, x1 - x0 - 1), self.rowHeight - 2), 3, [sv::copper() colorWithAlphaComponent:0.7], 1.0);
}

- (void)drawKeyboard:(CGFloat)gridBottom {
    const int top = std::clamp(static_cast<int>(std::ceil(self.scrollPitch)) + 1, 0, 127);
    const int bottom = std::clamp(static_cast<int>(std::floor(self.scrollPitch - (gridBottom - kRulerH) / self.rowHeight)) - 1, 0, 127);
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(0, kRulerH, kKeysW, gridBottom - kRulerH));
    sv::fill(NSMakeRect(0, kRulerH, kKeysW, gridBottom - kRulerH), sv::panel());
    std::unordered_set<int> selectedPitches;
    if (MidiSequence* seq = [self seq]) for (const auto& n : seq->notes()) if (_sel.count(n.id)) selectedPitches.insert(n.pitch);
    for (int pitch = top; pitch >= bottom; --pitch) {
        const CGFloat y = [self yForPitch:pitch];
        const BOOL playing = pitch == _auditionPitch;
        const BOOL hot = playing || selectedPitches.count(pitch) != 0U;
        NSColor* white = playing ? sv::copper() : (hot ? sv::hex(0xE8D4A8) : sv::hex(0xCED0D4));
        sv::fill(NSMakeRect(0, y, kKeysW - 1, self.rowHeight - 0.5), white);
        if (isBlack(pitch)) sv::fill(NSMakeRect(0, y, (kKeysW - 1) * 0.62, self.rowHeight - 0.5), playing ? sv::copperDeep() : sv::hex(0x15161A));
        if (pitch % 12 == 0)
            sv::text([NSString stringWithUTF8String:KeyEditing::noteName(pitch).c_str()], NSMakePoint(kKeysW - 28.0, y + (self.rowHeight - 12.0) * 0.5), sv::ui(10, true), sv::canvas());
    }
    [NSGraphicsContext restoreGraphicsState];
}

- (void)drawRulerOffset:(double)offset barQ:(double)barQ seq:(MidiSequence*)seq {
    const NSRect b = self.bounds;
    sv::fill(NSMakeRect(0, 0, b.size.width, kRulerH), sv::panel());
    sv::line(NSMakePoint(0, kRulerH - 0.5), NSMakePoint(b.size.width, kRulerH - 0.5), sv::hairline());
    double a = 0.0, e = 0.0;
    if ([self.controller keyCycleStart:&a end:&e]) {
        const CGFloat xa = std::max(kKeysW, [self xForQuarter:a]), xe = [self xForQuarter:e];
        if (xe > xa) {
            sv::fill(NSMakeRect(xa, 0, xe - xa, kRulerH), [sv::copper() colorWithAlphaComponent:0.25]);
            sv::fill(NSMakeRect(xa, kRulerH - 3, xe - xa, 3), sv::copper());
        }
    }
    sv::text(@"BARS", NSMakePoint(8, 8), sv::ui(10, true), sv::inkFaint());
    const double q1 = [self quarterForX:b.size.width];
    for (long i = static_cast<long>(std::floor(self.scrollQuarters));; ++i) {
        const double q = static_cast<double>(i);
        if (q > q1) break;
        const CGFloat x = [self xForQuarter:q];
        if (x < kKeysW) continue;
        const double tq = q + offset;
        double m = std::fmod(tq, barQ);
        if (m < 0.0) m += barQ;
        if (m < 1.0e-6 || m > barQ - 1.0e-6) {
            sv::line(NSMakePoint(std::floor(x) + 0.5, 4), NSMakePoint(std::floor(x) + 0.5, kRulerH), sv::inkFaint());
            sv::text([NSString stringWithFormat:@"%ld", static_cast<long>(std::llround(tq / barQ)) + 1], NSMakePoint(x + 4, 6), sv::mono(11), sv::ink());
        } else if (self.quarterWidth >= 22.0) {
            sv::line(NSMakePoint(std::floor(x) + 0.5, kRulerH - 6), NSMakePoint(std::floor(x) + 0.5, kRulerH), sv::inkFaint());
        }
    }
    // what the pointer or the selection says
    NSString* info = @"";
    if (seq && !_sel.empty()) {
        if (_sel.size() == 1U) {
            if (const MusicalMidiNote* n = KeyEditing::find(*seq, *_sel.begin()))
                info = [NSString stringWithFormat:@"%s   start %@   length %@   velocity %d%s",
                        KeyEditing::noteName(n->pitch).c_str(), positionText(n->startQuarterNotes + offset, barQ), lengthText(n->durationQuarterNotes),
                        static_cast<int>(n->velocity), n->muted ? "   muted" : ""];
        } else {
            info = [NSString stringWithFormat:@"%lu notes selected", static_cast<unsigned long>(_sel.size())];
        }
    } else if (_mouseIn && [self inGrid:_mouse]) {
        info = [NSString stringWithFormat:@"%s   %@", KeyEditing::noteName([self pitchForY:_mouse.y]).c_str(),
                positionText([self quarterForX:_mouse.x] + offset, barQ)];
    }
    if (info.length) sv::textIn(info, NSMakeRect(b.size.width - 470, 7, 462, 16), sv::mono(11, true), sv::amber(), NSTextAlignmentRight);
}

- (void)drawLaneFrames {
    const NSRect b = self.bounds;
    for (std::size_t i = 0U; i < _lanes.size(); ++i) {
        const NSRect r = [self laneRect:i];
        sv::fill(r, sv::panel());
        sv::line(NSMakePoint(0, r.origin.y + 0.5), NSMakePoint(b.size.width, r.origin.y + 0.5), sv::hairline());
        if (i == _activeLane && _lanes.size() > 1U) sv::fill(NSMakeRect(0, r.origin.y + 1, 3, r.size.height - 1), sv::copper());
        sv::text(laneTitle(_lanes[i]), NSMakePoint(8, r.origin.y + 8), sv::ui(10, true), sv::inkDim());
        NSString* sub = laneSubtitle(_lanes[i]);
        if (sub.length) sv::text(sub, NSMakePoint(8, r.origin.y + 22), sv::mono(10), sv::inkFaint());
        sv::text(@"▾", NSMakePoint(kKeysW - 16, r.origin.y + 8), sv::ui(11, true), sv::inkFaint());
    }
}

- (void)drawLane:(std::size_t)i seq:(MidiSequence*)seq {
    const NSRect b = self.bounds;
    const NSRect plot = [self plotRect:i];
    const KeyLane lane = _lanes[i];
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(NSMakeRect(kKeysW, [self laneRect:i].origin.y + 1, b.size.width - kKeysW, [self laneRect:i].size.height - 1));
    // quarter lines
    double step = 1.0;
    while (step * self.quarterWidth < 12.0) step *= 2.0;
    for (long k = static_cast<long>(std::floor(self.scrollQuarters / step));; ++k) {
        const double q = static_cast<double>(k) * step;
        if (q > [self quarterForX:b.size.width]) break;
        const CGFloat x = std::floor([self xForQuarter:q]) + 0.5;
        if (x >= kKeysW) sv::line(NSMakePoint(x, plot.origin.y - 5), NSMakePoint(x, NSMaxY(plot) + 5), sv::hex(0x1C1D22));
    }
    for (int t = 0; t <= 2; ++t) {
        const CGFloat y = std::floor(plot.origin.y + plot.size.height * t / 2.0) + 0.5;
        sv::line(NSMakePoint(kKeysW, y), NSMakePoint(b.size.width, y), lane.kind == KeyLane::Kind::PitchBend && t == 1 ? sv::hex(0x3A3D45) : sv::hex(0x1C1D22));
    }

    if (lane.kind == KeyLane::Kind::Velocity) {
        for (const auto& n : seq->notes()) {
            const CGFloat x = [self xForQuarter:n.startQuarterNotes];
            if (x < kKeysW - 6 || x > b.size.width) continue;
            const CGFloat h = plot.size.height * n.velocity / 127.0;
            const BOOL sel = _sel.count(n.id) != 0U;
            sv::fill(NSMakeRect(x, NSMaxY(plot) - h, 3, h), n.muted ? sv::inkFaint() : (sel ? sv::ink() : sv::copper()));
            sv::roundFill(NSMakeRect(x - 2, NSMaxY(plot) - h - 3, 7, 6), 2, n.muted ? sv::inkFaint() : (sel ? sv::ink() : sv::amber()));
        }
    } else {
        const std::vector<MusicalMidiMessage> msgs = KeyEditing::laneMessages(*seq, lane);
        if (!msgs.empty()) {
            NSBezierPath* path = [NSBezierPath bezierPath];
            CGFloat lastY = 0.0;
            BOOL started = NO;
            for (const auto& m : msgs) {
                const CGFloat x = std::floor([self xForQuarter:m.quarterNotes]) + 0.5;
                const CGFloat y = [self yForValue:lane.valueOf(m) lane:i];
                if (!started) { [path moveToPoint:NSMakePoint(x, y)]; started = YES; }
                else { [path lineToPoint:NSMakePoint(x, lastY)]; [path lineToPoint:NSMakePoint(x, y)]; }
                lastY = y;
            }
            [path lineToPoint:NSMakePoint(b.size.width + 4, lastY)];
            [[sv::copper() colorWithAlphaComponent:0.9] setStroke];
            path.lineWidth = 1.5;
            [path stroke];
            const BOOL dots = msgs.size() < 4000U;
            if (dots) {
                for (const auto& m : msgs) {
                    const CGFloat x = [self xForQuarter:m.quarterNotes];
                    if (x < kKeysW - 4 || x > b.size.width + 4) continue;
                    const CGFloat y = [self yForValue:lane.valueOf(m) lane:i];
                    const BOOL sel = _selMsg.count(m.id) != 0U;
                    sv::fill(NSMakeRect(x - 3, y - 3, 6, 6), sel ? sv::ink() : sv::amber());
                }
            }
        }
    }

    // shape being drawn with the Line tool
    if (_g == Gesture::LaneLine && i == _activeLane) {
        SVKeyState* st = [self state];
        const std::vector<LanePoint> pts = KeyEditing::shapePoints(st->shape, _lineQ0, _lineV0, _lineQ1, _lineV1, [self gridStep] * 0.5, st->period, lane.maxValue());
        NSBezierPath* path = [NSBezierPath bezierPath];
        BOOL started = NO;
        for (const auto& p : pts) {
            const NSPoint pt = NSMakePoint([self xForQuarter:p.quarterNotes], [self yForValue:p.value lane:i]);
            if (!started) { [path moveToPoint:pt]; started = YES; } else [path lineToPoint:pt];
        }
        [[sv::ink() colorWithAlphaComponent:0.9] setStroke];
        path.lineWidth = 1.5;
        [path stroke];
    }
    if ((_g == Gesture::LaneRubber || (_g == Gesture::Rubber && _down.y >= [self gridBottom])) && i == _activeLane && !NSIsEmptyRect(_rubber)) {
        sv::fill(_rubber, [sv::copper() colorWithAlphaComponent:0.12]);
        sv::roundStroke(_rubber, 0, sv::copper(), 1.0);
    }
    [NSGraphicsContext restoreGraphicsState];
}

- (void)drawPlayhead:(CGFloat)gridBottom {
    (void)gridBottom;
    const CGFloat x = [self xForQuarter:[self.controller keyPlayheadQuarter]];
    _lastPlayX = x;
    if (x < kKeysW || x > self.bounds.size.width) return;
    const CGFloat px = std::floor(x) + 0.5;
    sv::line(NSMakePoint(px, 0), NSMakePoint(px, self.bounds.size.height), sv::copper(), 1.0);
    NSBezierPath* tri = [NSBezierPath bezierPath];
    [tri moveToPoint:NSMakePoint(px - 5, 0)];
    [tri lineToPoint:NSMakePoint(px + 5, 0)];
    [tri lineToPoint:NSMakePoint(px, 8)];
    [tri closePath];
    [sv::copper() setFill];
    [tri fill];
}

// ===================================================================== tick ==
- (void)tick {
    SilvetonController* c = self.controller;
    if (!c || ![c keyEditorShown]) return;
    if (_auditionPitch >= 0 && _g == Gesture::None) [self stopAudition];   // never leave a note hanging
    const double q = [c keyPlayheadQuarter];
    const CGFloat x = [self xForQuarter:q];
    SVKeyState* st = [self state];
    const BOOL playing = [c core] && [c core]->ready() && [c core]->engine().transport().isPlaying();
    if (playing && st && st->follow && _g == Gesture::None && q >= 0.0) {
        if (x > self.bounds.size.width - 30.0 || x < kKeysW) {
            self.scrollQuarters = std::max(0.0, q - 40.0 / self.quarterWidth);
            [self setNeedsDisplay:YES];
            return;
        }
    }
    if (std::abs(x - _lastPlayX) >= 0.5) {
        const CGFloat h = self.bounds.size.height;
        [self setNeedsDisplayInRect:NSMakeRect(_lastPlayX - 6, 0, 13, h)];
        [self setNeedsDisplayInRect:NSMakeRect(x - 6, 0, 13, h)];
        _lastPlayX = x;
    }
    if (_g != Gesture::None && _g != Gesture::Seek) [self autoScrollWhileDragging];
}

- (void)autoScrollWhileDragging {
    if (!_moved) return;
    const NSPoint mouse = [self convertPoint:[self.window mouseLocationOutsideOfEventStream] fromView:nil];
    const CGFloat gridBottom = [self gridBottom];
    CGFloat dx = 0.0, dy = 0.0;
    if (mouse.x > self.bounds.size.width - 14.0) dx = std::min<CGFloat>(40.0, 3.0 + (mouse.x - (self.bounds.size.width - 14.0)) / 3.0);
    else if (mouse.x < kKeysW + 8.0 && _g != Gesture::Keyboard) dx = -std::min<CGFloat>(40.0, 3.0 + (kKeysW + 8.0 - mouse.x) / 3.0);
    const BOOL vertical = (_g == Gesture::Move || _g == Gesture::Rubber || _g == Gesture::Keyboard || _g == Gesture::Create);
    if (vertical && _down.y < gridBottom) {
        if (mouse.y < kRulerH + 6.0) dy = -std::min<CGFloat>(18.0, 2.0 + (kRulerH + 6.0 - mouse.y) / 3.0);
        else if (mouse.y > gridBottom - 6.0) dy = std::min<CGFloat>(18.0, 2.0 + (mouse.y - (gridBottom - 6.0)) / 3.0);
    }
    if (dx == 0.0 && dy == 0.0) return;
    self.scrollQuarters = std::max(0.0, self.scrollQuarters + dx / self.quarterWidth);
    [self clampPitchScroll:self.scrollPitch - dy / self.rowHeight];
    NSPoint p = mouse;
    p.x = std::clamp(p.x, kKeysW, self.bounds.size.width - 1.0);
    p.y = std::clamp(p.y, kRulerH, std::max(kRulerH, gridBottom - 1.0));
    if (_down.y >= gridBottom) p.y = mouse.y;
    [self dragToPoint:p flags:_lastFlags];
    [self setNeedsDisplay:YES];
}

- (void)clampPitchScroll:(double)top {
    const double rows = ([self gridBottom] - kRulerH) / self.rowHeight;
    const double lowest = std::min(127.0, std::max(0.0, rows - 1.0));
    self.scrollPitch = std::clamp(top, lowest, 128.0);
}

// ================================================================== zooming ==
- (void)zoomBy:(double)factor {
    const double centre = [self quarterForX:kKeysW + (self.bounds.size.width - kKeysW) * 0.5];
    self.quarterWidth = std::clamp(self.quarterWidth / factor, 8.0, 900.0);
    self.scrollQuarters = std::max(0.0, centre - (self.bounds.size.width - kKeysW) * 0.5 / self.quarterWidth);
    [self setNeedsDisplay:YES];
}
- (void)zoomToQuarters:(double)a end:(double)e pitches:(int)low high:(int)high {
    const CGFloat width = self.bounds.size.width - kKeysW - 24.0;
    const double span = std::max(0.5, e - a);
    self.quarterWidth = std::clamp(width / span, 8.0, 900.0);
    self.scrollQuarters = std::max(0.0, a - 8.0 / self.quarterWidth);
    const double rows = std::max(6.0, static_cast<double>(high - low) + 4.0);
    self.rowHeight = std::clamp(([self gridBottom] - kRulerH) / rows, kMinRow, 22.0);
    [self clampPitchScroll:high + 2.0];
    [self setNeedsDisplay:YES];
}
- (void)zoomFit {
    MidiSequence* seq = [self seq];
    if (!seq || seq->notes().empty()) { [self setNeedsDisplay:YES]; return; }
    double a = 1.0e9, e = 0.0;
    int low = 127, high = 0;
    for (const auto& n : seq->notes()) {
        a = std::min(a, n.startQuarterNotes);
        e = std::max(e, n.startQuarterNotes + n.durationQuarterNotes);
        low = std::min<int>(low, n.pitch);
        high = std::max<int>(high, n.pitch);
    }
    [self zoomToQuarters:a end:e pitches:low high:high];
}
- (void)zoomToSelection {
    MidiSequence* seq = [self seq];
    if (!seq || _sel.empty()) { [self zoomFit]; return; }
    double a = 1.0e9, e = 0.0;
    int low = 127, high = 0;
    for (const auto& n : seq->notes()) {
        if (!_sel.count(n.id)) continue;
        a = std::min(a, n.startQuarterNotes);
        e = std::max(e, n.startQuarterNotes + n.durationQuarterNotes);
        low = std::min<int>(low, n.pitch);
        high = std::max<int>(high, n.pitch);
    }
    if (e > a) [self zoomToQuarters:a end:e pitches:low high:high];
}

- (void)scrollWheel:(NSEvent*)event {
    const NSEventModifierFlags mods = event.modifierFlags & NSEventModifierFlagDeviceIndependentFlagsMask;
    double dx = event.scrollingDeltaX, dy = event.scrollingDeltaY;
    if (!event.hasPreciseScrollingDeltas) { dx *= 12; dy *= 12; }
    if (mods & (NSEventModifierFlagOption | NSEventModifierFlagControl)) {
        const double anchor = [self quarterForX:std::clamp([self convertPoint:event.locationInWindow fromView:nil].x, kKeysW, self.bounds.size.width)];
        const CGFloat anchorX = std::clamp([self convertPoint:event.locationInWindow fromView:nil].x, kKeysW, self.bounds.size.width);
        self.quarterWidth = std::clamp(self.quarterWidth * std::pow(1.08, dy / 4.0), 8.0, 900.0);
        self.scrollQuarters = std::max(0.0, anchor - (anchorX - kKeysW) / self.quarterWidth);
    } else if (mods & NSEventModifierFlagCommand) {
        self.rowHeight = std::clamp(self.rowHeight * std::pow(1.06, dy / 4.0), kMinRow, kMaxRow);
        [self clampPitchScroll:self.scrollPitch];
    } else {
        if (mods & NSEventModifierFlagShift) { dx = dy; dy = 0; }
        self.scrollQuarters = std::max(0.0, self.scrollQuarters - dx / self.quarterWidth);
        [self clampPitchScroll:self.scrollPitch + dy / self.rowHeight];
    }
    [self setNeedsDisplay:YES];
}

- (void)magnifyWithEvent:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const CGFloat ax = std::clamp(p.x, kKeysW, self.bounds.size.width);
    const double anchor = [self quarterForX:ax];
    self.quarterWidth = std::clamp(self.quarterWidth * (1.0 + event.magnification), 8.0, 900.0);
    self.scrollQuarters = std::max(0.0, anchor - (ax - kKeysW) / self.quarterWidth);
    [self setNeedsDisplay:YES];
}

// ===================================================================== mouse ==
- (void)mouseMoved:(NSEvent*)event {
    _mouse = [self convertPoint:event.locationInWindow fromView:nil];
    _mouseIn = YES;
    const int hover = [self inGrid:_mouse] ? [self pitchForY:_mouse.y] : -1;
    SVKeyState* st = [self state];
    NSCursor* cursor = [NSCursor arrowCursor];
    if ([self inGrid:_mouse] && st) {
        const MusicalMidiNote* hit = [self noteAt:_mouse];
        switch (st->tool) {
            case SVKeyTool::Draw: cursor = hit ? [NSCursor arrowCursor] : [NSCursor crosshairCursor]; break;
            case SVKeyTool::Erase: cursor = hit ? [NSCursor disappearingItemCursor] : [NSCursor arrowCursor]; break;
            case SVKeyTool::Cut: cursor = hit ? [NSCursor crosshairCursor] : [NSCursor arrowCursor]; break;
            default:
                if (hit && [self xForQuarter:hit->startQuarterNotes + hit->durationQuarterNotes] - _mouse.x < kEdgeGrab) cursor = [NSCursor resizeLeftRightCursor];
                break;
        }
    }
    [cursor set];
    if (hover != _hoverPitch || (st && st->tool == SVKeyTool::Draw)) { _hoverPitch = hover; [self setNeedsDisplay:YES]; }
    else [self setNeedsDisplayInRect:NSMakeRect(self.bounds.size.width - 480, 0, 480, kRulerH)];
}
- (void)mouseExited:(NSEvent*)event { (void)event; _mouseIn = NO; _hoverPitch = -1; [self setNeedsDisplay:YES]; }

- (void)beginUndo:(NSString*)label {
    if (!_gestureOpen) { [self.controller beginGesture:label]; _gestureOpen = YES; }
}
- (void)endUndo {
    if (_gestureOpen) { [self.controller endGesture]; _gestureOpen = NO; }
}

- (void)mouseDown:(NSEvent*)event {
    [self.window makeFirstResponder:self];
    SilvetonController* c = self.controller;
    _down = [self convertPoint:event.locationInWindow fromView:nil];
    _last = _down; _mouse = _down;
    _downFlags = event.modifierFlags; _lastFlags = _downFlags;
    _moved = NO; _g = Gesture::None; _grab = 0U; _collapseTo = 0U; _copyOnDrag = NO; _rubber = NSZeroRect;
    _orig.clear(); _origMsgs.clear();
    MidiSequence* seq = [self seq];
    if (!seq) return;
    SVKeyState* st = [c keyState];
    const BOOL extend = (_downFlags & (NSEventModifierFlagShift | NSEventModifierFlagCommand)) != 0;

    if (_down.y < kRulerH) {   // the ruler moves the playhead
        _g = Gesture::Seek;
        [c keySeekToQuarter:[self snap:[self quarterForX:std::max(kKeysW, _down.x)]]];
        return;
    }
    if (_down.y >= [self gridBottom]) { [self laneMouseDown:event extend:extend]; return; }
    if (_down.x < kKeysW) {   // the keyboard
        _g = Gesture::Keyboard;
        _downPitch = [self pitchForY:_down.y];
        [self auditionPitch:_downPitch velocity:st->insertVelocity];
        [self setNeedsDisplay:YES];
        return;
    }

    const double q = [self quarterForX:_down.x];
    const int pitch = [self pitchForY:_down.y];
    _downQ = q; _downPitch = pitch;
    const MusicalMidiNote* hit = [self noteAt:_down];
    const SVKeyTool tool = st->tool;

    if (tool == SVKeyTool::Erase) {
        _g = Gesture::Sweep;
        if (hit) { const std::uint64_t id = hit->id; _sel.erase(id); [self beginUndo:@"Erase Notes"]; [c noteEdit:@"Erase Notes" op:^(MidiSequence& s) { (void)s.removeNote(id); }]; }
        [self setNeedsDisplay:YES];
        return;
    }
    if (tool == SVKeyTool::Cut) {
        if (hit) {
            const std::uint64_t id = hit->id;
            const double at = [self snap:q];
            const std::vector<std::uint64_t> targets = _sel.count(id) ? [self selection] : std::vector<std::uint64_t> {id};
            __block std::vector<std::uint64_t> rights;
            [c noteEdit:@"Cut Notes" op:^(MidiSequence& s) { rights = KeyEditing::splitNotes(s, targets, at); }];
            if (rights.empty()) [c keyStatus:@"Nothing to cut there — move the cut away from the edge of the note"];
        }
        [self setNeedsDisplay:YES];
        return;
    }
    if (tool == SVKeyTool::Glue) {
        if (hit) {
            const std::uint64_t id = hit->id;
            __block std::uint64_t joined = 0U;
            [c noteEdit:@"Glue Notes" op:^(MidiSequence& s) { joined = KeyEditing::glueToNext(s, id); }];
            if (!joined) [c keyStatus:@"There is no later note of the same pitch to glue to"];
            [self selectionChanged];
        }
        return;
    }
    if (tool == SVKeyTool::Mute) {
        if (hit) {
            const std::uint64_t id = hit->id;
            _sweepMute = hit->muted ? 0 : 1;
            const int target = _sweepMute;
            const std::vector<std::uint64_t> targets = _sel.count(id) ? [self selection] : std::vector<std::uint64_t> {id};
            [self beginUndo:@"Mute Notes"];
            [c noteEdit:@"Mute Notes" op:^(MidiSequence& s) { (void)KeyEditing::muteNotes(s, targets, target); }];
            _g = Gesture::SweepMute;
        }
        [self setNeedsDisplay:YES];
        return;
    }

    // Select, Line and Draw (on a note) all pick notes
    if (hit) {
        const std::uint64_t id = hit->id;
        if (extend) {   // add or take away, no drag
            if (_sel.count(id)) _sel.erase(id); else _sel.insert(id);
            _selMsg.clear();
            [self setNeedsDisplay:YES];
            return;
        }
        if (event.clickCount >= 2) {
            _sel.erase(id);
            [c noteEdit:@"Delete Note" op:^(MidiSequence& s) { (void)s.removeNote(id); }];
            [self setNeedsDisplay:YES];
            return;
        }
        if (!_sel.count(id)) { _sel.clear(); _sel.insert(id); }
        else if (_sel.size() > 1U) _collapseTo = id;     // a plain click inside a group leaves only that note, unless it was a drag
        _selMsg.clear();
        _grab = id;
        _grabOffsetQ = q - hit->startQuarterNotes;
        [self auditionPitch:hit->pitch velocity:hit->velocity];
        const CGFloat x1 = [self xForQuarter:hit->startQuarterNotes + hit->durationQuarterNotes];
        const CGFloat x0 = [self xForQuarter:hit->startQuarterNotes];
        _g = (x1 - _down.x < kEdgeGrab && x1 - x0 > 12.0) ? Gesture::Resize : Gesture::Move;
        _orig = KeyEditing::snapshot(*seq, [self selection]);
        _copyOnDrag = (_downFlags & NSEventModifierFlagOption) != 0 && _g == Gesture::Move;
        [self setNeedsDisplay:YES];
        return;
    }

    // empty space
    if (tool == SVKeyTool::Draw || event.clickCount >= 2) {
        [self createNoteAtQuarter:[self snapDown:q] pitch:pitch];
        return;
    }
    _g = Gesture::Rubber;
    _rubberAdd = extend;
    _rubberBase = extend ? _sel : std::unordered_set<std::uint64_t> {};
    if (!extend) { _sel.clear(); _selMsg.clear(); }
    [self setNeedsDisplay:YES];
}

- (void)createNoteAtQuarter:(double)start pitch:(int)pitch {
    SilvetonController* c = self.controller;
    SVKeyState* st = [c keyState];
    if (st->scaleSnap) pitch = KeyEditing::pitchInScale(pitch, st->scale);
    MusicalMidiNote n;
    n.startQuarterNotes = std::max(0.0, start);
    n.durationQuarterNotes = [c keyInsertLength];
    n.pitch = static_cast<std::uint8_t>(std::clamp(pitch, 0, 127));
    n.velocity = static_cast<std::uint8_t>(std::clamp(st->insertVelocity, 1, 127));
    const ChordKind chord = static_cast<ChordKind>(std::clamp(st->chord, 0, static_cast<int>(ChordKind::Count) - 1));
    __block std::vector<std::uint64_t> made;
    [self beginUndo:@"Add Note"];
    [c noteEdit:@"Add Note" op:^(MidiSequence& s) { made = KeyEditing::addChord(s, n, chord); }];
    if (made.empty()) { [self endUndo]; return; }
    _sel = std::unordered_set<std::uint64_t>(made.begin(), made.end());
    _selMsg.clear();
    _grab = made[0];
    MidiSequence* seq = [self seq];
    _orig = seq ? KeyEditing::snapshot(*seq, made) : std::vector<MusicalMidiNote> {};
    _g = Gesture::Create;
    [self auditionPitch:n.pitch velocity:n.velocity];
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent*)event {
    [self dragToPoint:[self convertPoint:event.locationInWindow fromView:nil] flags:event.modifierFlags];
}

- (void)dragToPoint:(NSPoint)p flags:(NSEventModifierFlags)flags {
    if (_g == Gesture::None) return;
    SilvetonController* c = self.controller;
    MidiSequence* seq = [self seq];
    if (!seq) return;
    if (!_moved && std::hypot(p.x - _down.x, p.y - _down.y) < kDragStart) return;
    _moved = YES;
    _lastFlags = flags;
    _mouse = p;
    SVKeyState* st = [c keyState];

    switch (_g) {
        case Gesture::Seek:
            [c keySeekToQuarter:[self snap:[self quarterForX:std::max(kKeysW, p.x)]]];
            break;
        case Gesture::Keyboard: {
            const int pitch = [self pitchForY:p.y];
            if (pitch != _downPitch) { _downPitch = pitch; [self auditionPitch:pitch velocity:st->insertVelocity]; [self setNeedsDisplay:YES]; }
            break;
        }
        case Gesture::Move: {
            const MusicalMidiNote* grabbed = nullptr;
            for (const auto& n : _orig) if (n.id == _grab) { grabbed = &n; break; }
            if (!grabbed) break;
            [self beginUndo:@"Move Notes"];
            if (_copyOnDrag) {   // Option-drag: the copies are what moves
                _copyOnDrag = NO;
                const std::vector<MusicalMidiNote> source = _orig;
                const std::uint64_t oldGrab = _grab;
                __block std::vector<std::uint64_t> fresh;
                __block std::uint64_t newGrab = 0U;
                [c noteEdit:@"Copy Notes" op:^(MidiSequence& s) {
                    for (MusicalMidiNote n : source) {
                        const std::uint64_t old = n.id;
                        n.id = 0U;
                        const std::uint64_t id = s.addNote(n);
                        fresh.push_back(id);
                        if (old == oldGrab) newGrab = id;
                    }
                }];
                _sel = std::unordered_set<std::uint64_t>(fresh.begin(), fresh.end());
                _grab = newGrab;
                _orig = KeyEditing::snapshot(*seq, fresh);
                grabbed = nullptr;
                for (const auto& n : _orig) if (n.id == _grab) { grabbed = &n; break; }
                if (!grabbed) break;
            }
            const double start0 = grabbed->startQuarterNotes;
            const int pitch0 = grabbed->pitch;
            const double newStart = [self snap:[self quarterForX:p.x] - _grabOffsetQ];
            int newPitch = [self pitchForY:p.y];
            if (st->scaleSnap) newPitch = KeyEditing::pitchInScale(newPitch, st->scale);
            const double dq = newStart - start0;
            const int dp = newPitch - pitch0;
            const std::vector<MusicalMidiNote> original = _orig;
            __block int appliedPitch = 0;
            [c noteEdit:@"Move Notes" op:^(MidiSequence& s) { KeyEditing::moveFrom(s, original, dq, dp, nullptr, &appliedPitch); }];
            [self auditionPitch:pitch0 + appliedPitch velocity:grabbed->velocity];
            break;
        }
        case Gesture::Resize:
        case Gesture::Create: {
            const MusicalMidiNote* grabbed = nullptr;
            for (const auto& n : _orig) if (n.id == _grab) { grabbed = &n; break; }
            if (!grabbed) break;
            [self beginUndo:@"Resize Notes"];
            const double end = [self snap:[self quarterForX:p.x]];
            const double minLen = [self gridStep];
            double delta;
            if (_g == Gesture::Create) delta = std::max(minLen, end - grabbed->startQuarterNotes) - grabbed->durationQuarterNotes;
            else delta = end - (grabbed->startQuarterNotes + grabbed->durationQuarterNotes);
            const std::vector<MusicalMidiNote> original = _orig;
            [c noteEdit:@"Resize Notes" op:^(MidiSequence& s) { KeyEditing::resizeFrom(s, original, delta); }];
            break;
        }
        case Gesture::Rubber: {
            _rubber = NSMakeRect(std::min(_down.x, p.x), std::min(_down.y, p.y), std::abs(p.x - _down.x), std::abs(p.y - _down.y));
            const double qa = [self quarterForX:_rubber.origin.x], qb = [self quarterForX:NSMaxX(_rubber)];
            const BOOL inLane = _down.y >= [self gridBottom];   // a band over the velocity bars picks by time only
            const int pa = inLane ? 0 : [self pitchForY:NSMaxY(_rubber)], pb = inLane ? 127 : [self pitchForY:_rubber.origin.y];
            std::unordered_set<std::uint64_t> now = _rubberBase;
            for (const std::uint64_t id : KeyEditing::selectInside(*seq, qa, qb, pa, pb)) now.insert(id);
            _sel = std::move(now);
            [self setNeedsDisplay:YES];
            break;
        }
        case Gesture::Sweep:
        case Gesture::SweepMute: {
            const double dist = std::hypot(p.x - _last.x, p.y - _last.y);
            const int steps = std::max(1, static_cast<int>(std::ceil(dist / 3.0)));
            std::vector<std::uint64_t> hits;
            for (int i = 1; i <= steps; ++i) {
                const NSPoint s = NSMakePoint(_last.x + (p.x - _last.x) * i / steps, _last.y + (p.y - _last.y) * i / steps);
                if (const MusicalMidiNote* n = [self noteAt:s]) {
                    if (_g == Gesture::SweepMute && (n->muted ? 1 : 0) == _sweepMute) continue;   // already in the wanted state
                    if (std::find(hits.begin(), hits.end(), n->id) == hits.end()) hits.push_back(n->id);
                }
            }
            if (!hits.empty()) {
                if (_g == Gesture::Sweep) {
                    for (const std::uint64_t id : hits) _sel.erase(id);
                    [c noteEdit:@"Erase Notes" op:^(MidiSequence& s) { (void)KeyEditing::removeNotes(s, hits); }];
                } else {
                    const int target = _sweepMute;
                    [c noteEdit:@"Mute Notes" op:^(MidiSequence& s) { (void)KeyEditing::muteNotes(s, hits, target); }];
                }
            }
            _last = p;
            [self setNeedsDisplay:YES];
            break;
        }
        default:
            [self laneDragToPoint:p];
            break;
    }
    if (_g != Gesture::Sweep && _g != Gesture::SweepMute) _last = p;
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    SilvetonController* c = self.controller;
    SVKeyState* st = [c keyState];
    if (_g == Gesture::LaneLine && _moved) [self finishLine];
    if (_collapseTo && !_moved && (_g == Gesture::Move || _g == Gesture::Resize)) { _sel.clear(); _sel.insert(_collapseTo); }
    if ((_g == Gesture::Create || _g == Gesture::Resize) && _grab && st) {
        if (MidiSequence* seq = [self seq]) if (const MusicalMidiNote* n = KeyEditing::find(*seq, _grab)) st->lastLength = n->durationQuarterNotes;
    }
    [self stopAudition];
    [self endUndo];
    _g = Gesture::None;
    _rubber = NSZeroRect;
    _collapseTo = 0U;
    _orig.clear(); _origMsgs.clear();
    [self setNeedsDisplay:YES];
}

// ===================================================================== lanes ==
- (void)laneMouseDown:(NSEvent*)event extend:(BOOL)extend {
    SilvetonController* c = self.controller;
    MidiSequence* seq = [self seq];
    SVKeyState* st = [c keyState];
    const long li = [self laneAtY:_down.y];
    if (li < 0) return;
    const auto lane_i = static_cast<std::size_t>(li);
    _activeLane = lane_i;
    if (_down.x < kKeysW) { [self showLaneMenu:lane_i at:_down]; return; }
    const KeyLane lane = _lanes[lane_i];
    const double q = [self quarterForX:_down.x];
    const int value = [self valueForY:_down.y lane:lane_i];
    _downQ = q;
    const SVKeyTool tool = st->tool;

    if (lane.kind == KeyLane::Kind::Velocity) {
        if (tool == SVKeyTool::Line) { _g = Gesture::LaneLine; _lineQ0 = _lineQ1 = q; _lineV0 = _lineV1 = value; return; }
        if (tool == SVKeyTool::Draw) { _g = Gesture::VelPaint; _last = _down; [self paintVelocityTo:_down]; return; }
        // pick the note whose start is nearest
        std::uint64_t best = 0U;
        CGFloat bestD = 1.0e9;
        for (const auto& n : seq->notes()) {
            const CGFloat d = std::abs([self xForQuarter:n.startQuarterNotes] + 1.0 - _down.x);
            if (d < bestD && d < kPointGrab) { bestD = d; best = n.id; }
        }
        if (best) {
            if (extend) { if (_sel.count(best)) _sel.erase(best); else _sel.insert(best); }
            else if (!_sel.count(best)) { _sel.clear(); _sel.insert(best); }
            _selMsg.clear();
            _grab = best;
            _orig = KeyEditing::snapshot(*seq, [self selection]);
            _grabVelocity = 0;
            for (const auto& n : _orig) if (n.id == best) _grabVelocity = n.velocity;
            _g = Gesture::VelBar;
            _moved = YES;
            [self laneDragToPoint:_down];
        } else {
            _g = Gesture::Rubber;   // a rubber band over the velocity bars picks notes
            _rubberAdd = extend;
            _rubberBase = extend ? _sel : std::unordered_set<std::uint64_t> {};
            if (!extend) _sel.clear();
        }
        [self setNeedsDisplay:YES];
        return;
    }

    // controller lanes
    switch (tool) {
        case SVKeyTool::Line:
            _g = Gesture::LaneLine; _lineQ0 = _lineQ1 = q; _lineV0 = _lineV1 = value;
            return;
        case SVKeyTool::Draw: {
            const double qs = [self snap:q];
            _g = Gesture::LanePaint; _paintQ = qs; _paintV = value;
            const std::vector<LanePoint> one = {{qs, value}};
            [self beginUndo:@"Draw Controller"];
            [c noteEdit:@"Draw Controller" op:^(MidiSequence& s) { (void)KeyEditing::writePoints(s, lane, one); }];
            return;
        }
        case SVKeyTool::Erase: {
            _g = Gesture::LaneSweep; _last = _down;
            const double reach = 6.0 / self.quarterWidth;
            [self beginUndo:@"Erase Controller"];
            [c noteEdit:@"Erase Controller" op:^(MidiSequence& s) { (void)KeyEditing::eraseRange(s, lane, q - reach, q + reach); }];
            return;
        }
        default: break;
    }
    // Select: pick a point, or begin a rubber band
    std::uint64_t best = 0U;
    CGFloat bestD = 1.0e9;
    for (const auto& m : KeyEditing::laneMessages(*seq, lane)) {
        const CGFloat dx = [self xForQuarter:m.quarterNotes] - _down.x, dy = [self yForValue:lane.valueOf(m) lane:lane_i] - _down.y;
        const CGFloat d = std::hypot(dx, dy);
        if (d < bestD && d <= kPointGrab) { bestD = d; best = m.id; }
    }
    if (best) {
        if (extend) { if (_selMsg.count(best)) _selMsg.erase(best); else _selMsg.insert(best); }
        else if (!_selMsg.count(best)) { _selMsg.clear(); _selMsg.insert(best); }
        _sel.clear();
        _grab = best;
        _origMsgs.clear();
        for (const auto& m : seq->messages()) if (_selMsg.count(m.id)) _origMsgs.push_back(m);
        const MusicalMidiMessage* g = KeyEditing::findMessage(*seq, best);
        _grabValue = g ? lane.valueOf(*g) : 0;
        _grabOffsetQ = g ? q - g->quarterNotes : 0.0;
        _g = Gesture::LanePoints;
    } else {
        _g = Gesture::LaneRubber;
        _rubberAdd = extend;
        if (!extend) _selMsg.clear();
        _rubberBase.clear();
        for (const std::uint64_t id : _selMsg) _rubberBase.insert(id);
    }
    (void)event;
    [self setNeedsDisplay:YES];
}

- (void)paintVelocityTo:(NSPoint)p {
    MidiSequence* seq = [self seq];
    if (!seq) return;
    const std::size_t li = _activeLane;
    const CGFloat xa = std::min(_last.x, p.x) - 2.0, xb = std::max(_last.x, p.x) + 2.0;
    std::vector<std::pair<std::uint64_t, int>> changes;
    for (const auto& n : seq->notes()) {
        const CGFloat nx = [self xForQuarter:n.startQuarterNotes];
        if (nx < xa || nx > xb) continue;
        const CGFloat span = p.x - _last.x;
        const CGFloat t = std::abs(span) < 0.5 ? 1.0 : std::clamp((nx - _last.x) / span, 0.0, 1.0);
        const CGFloat y = _last.y + (p.y - _last.y) * t;
        changes.push_back({n.id, [self valueForY:y lane:li]});
    }
    if (changes.empty()) return;
    [self beginUndo:@"Draw Velocity"];
    [self.controller noteEdit:@"Draw Velocity" op:^(MidiSequence& s) {
        for (const auto& ch : changes) (void)s.setNoteVelocity(ch.first, static_cast<std::uint8_t>(std::clamp(ch.second, 1, 127)));
    }];
}

- (void)laneDragToPoint:(NSPoint)p {
    SilvetonController* c = self.controller;
    MidiSequence* seq = [self seq];
    if (!seq || _activeLane >= _lanes.size()) return;
    const KeyLane lane = _lanes[_activeLane];
    const std::size_t li = _activeLane;
    switch (_g) {
        case Gesture::VelBar: {
            const int target = [self valueForY:p.y lane:li];
            const int delta = target - _grabVelocity;
            const std::vector<MusicalMidiNote> original = _orig;
            [self beginUndo:@"Note Velocity"];
            [c noteEdit:@"Note Velocity" op:^(MidiSequence& s) { KeyEditing::shiftVelocityFrom(s, original, delta); }];
            break;
        }
        case Gesture::VelPaint:
            [self paintVelocityTo:p];
            _last = p;
            break;
        case Gesture::LanePoints: {
            const double newQ = [self snap:[self quarterForX:p.x] - _grabOffsetQ];
            const MusicalMidiMessage* grabbed = nullptr;
            for (const auto& m : _origMsgs) if (m.id == _grab) { grabbed = &m; break; }
            if (!grabbed) break;
            double dq = newQ - grabbed->quarterNotes;
            for (const auto& m : _origMsgs) dq = std::max(dq, -m.quarterNotes);
            const int dv = [self valueForY:p.y lane:li] - _grabValue;
            const std::vector<MusicalMidiMessage> original = _origMsgs;
            [self beginUndo:@"Move Controller Points"];
            [c noteEdit:@"Move Controller Points" op:^(MidiSequence& s) {
                for (const auto& m : original) {
                    (void)s.moveMessage(m.id, std::max(0.0, m.quarterNotes + dq));
                    (void)KeyEditing::setValue(s, lane, m.id, std::clamp(lane.valueOf(m) + dv, 0, lane.maxValue()));
                }
            }];
            break;
        }
        case Gesture::LanePaint: {
            const double q1 = [self snap:[self quarterForX:p.x]];
            const int v1 = [self valueForY:p.y lane:li];
            if (std::abs(q1 - _paintQ) < 1.0e-9 && v1 == _paintV) break;
            const std::vector<LanePoint> pts = KeyEditing::shapePoints(LaneShape::Line, _paintQ, _paintV, q1, v1, [self gridStep], 1.0, lane.maxValue());
            [c noteEdit:@"Draw Controller" op:^(MidiSequence& s) { (void)KeyEditing::writePoints(s, lane, pts); }];
            _paintQ = q1; _paintV = v1;
            break;
        }
        case Gesture::LaneLine:
            _lineQ1 = [self snap:[self quarterForX:p.x]];
            _lineV1 = [self valueForY:p.y lane:li];
            break;
        case Gesture::LaneSweep: {
            const double a = [self quarterForX:std::min(_last.x, p.x) - 6.0], b = [self quarterForX:std::max(_last.x, p.x) + 6.0];
            [c noteEdit:@"Erase Controller" op:^(MidiSequence& s) { (void)KeyEditing::eraseRange(s, lane, a, b); }];
            _last = p;
            break;
        }
        case Gesture::LaneRubber: {
            _rubber = NSMakeRect(std::min(_down.x, p.x), std::min(_down.y, p.y), std::abs(p.x - _down.x), std::abs(p.y - _down.y));
            std::unordered_set<std::uint64_t> now = _rubberAdd ? _rubberBase : std::unordered_set<std::uint64_t> {};
            for (const auto& m : KeyEditing::laneMessages(*seq, lane)) {
                const NSPoint pt = NSMakePoint([self xForQuarter:m.quarterNotes], [self yForValue:lane.valueOf(m) lane:li]);
                if (NSPointInRect(pt, _rubber)) now.insert(m.id);
            }
            _selMsg = std::move(now);
            break;
        }
        default: break;
    }
}

- (void)finishLine {
    SilvetonController* c = self.controller;
    MidiSequence* seq = [self seq];
    if (!seq || _activeLane >= _lanes.size()) return;
    SVKeyState* st = [c keyState];
    const KeyLane lane = _lanes[_activeLane];
    const double step = [self gridStep] * (lane.kind == KeyLane::Kind::Velocity ? 0.25 : 0.5);
    const std::vector<LanePoint> pts = KeyEditing::shapePoints(st->shape, _lineQ0, _lineV0, _lineQ1, _lineV1, step, st->period, lane.maxValue());
    if (pts.empty()) return;
    if (lane.kind == KeyLane::Kind::Velocity) {
        std::vector<std::pair<std::uint64_t, int>> changes;
        const double lo = std::min(_lineQ0, _lineQ1), hi = std::max(_lineQ0, _lineQ1);
        for (const auto& n : seq->notes()) {
            if (n.startQuarterNotes < lo - 1.0e-9 || n.startQuarterNotes > hi + 1.0e-9) continue;
            int value = pts.front().value;
            for (const auto& p : pts) { if (p.quarterNotes <= n.startQuarterNotes + 1.0e-9) value = p.value; else break; }
            changes.push_back({n.id, value});
        }
        [c noteEdit:@"Velocity Line" op:^(MidiSequence& s) {
            for (const auto& ch : changes) (void)s.setNoteVelocity(ch.first, static_cast<std::uint8_t>(std::clamp(ch.second, 1, 127)));
        }];
    } else {
        [c noteEdit:@"Controller Line" op:^(MidiSequence& s) { (void)KeyEditing::writePoints(s, lane, pts); }];
    }
}

- (void)thinActiveLane {
    SilvetonController* c = self.controller;
    if (_activeLane >= _lanes.size() || ![self seq]) return;
    const KeyLane lane = _lanes[_activeLane];
    if (!lane.isMessageLane()) { [c keyStatus:@"Thin Out works on controller lanes, not on the velocity lane"]; return; }
    __block std::size_t removed = 0U;
    [c noteEdit:@"Thin Out Controller" op:^(MidiSequence& s) { removed = KeyEditing::reduceLane(s, lane, lane.kind == KeyLane::Kind::PitchBend ? 64 : 1); }];
    [c keyStatus:[NSString stringWithFormat:@"%lu controller points removed", static_cast<unsigned long>(removed)]];
    [self selectionChanged];
}

- (void)clearActiveLane {
    SilvetonController* c = self.controller;
    if (_activeLane >= _lanes.size() || ![self seq]) return;
    const KeyLane lane = _lanes[_activeLane];
    if (!lane.isMessageLane()) { [c keyStatus:@"The velocity lane belongs to the notes — select them and press Delete to remove them"]; return; }
    [c noteEdit:@"Clear Controller Lane" op:^(MidiSequence& s) { (void)KeyEditing::eraseRange(s, lane, 0.0, 1.0e9); }];
    _selMsg.clear();
    [self setNeedsDisplay:YES];
}

- (void)deleteSelected {
    SilvetonController* c = self.controller;
    MidiSequence* seq = [self seq];
    if (!seq) return;
    if (!_selMsg.empty()) {
        const std::vector<std::uint64_t> ids(_selMsg.begin(), _selMsg.end());
        [c noteEdit:@"Delete Controller Points" op:^(MidiSequence& s) { (void)KeyEditing::removeMessages(s, ids); }];
        _selMsg.clear();
    } else if (!_sel.empty()) {
        const std::vector<std::uint64_t> ids = [self selection];
        [c noteEdit:@"Delete Notes" op:^(MidiSequence& s) { (void)KeyEditing::removeNotes(s, ids); }];
        _sel.clear();
    }
    [self setNeedsDisplay:YES];
}

// ================================================================ lane menu ==
- (void)showLaneMenu:(std::size_t)i at:(NSPoint)p {
    NSMenu* menu = [[NSMenu alloc] initWithTitle:@"Lane"];
    const KeyLane current = _lanes[i];
    auto add = [&](const KeyLane& lane) {
        NSMenuItem* it = [[NSMenuItem alloc] initWithTitle:[NSString stringWithUTF8String:lane.name().c_str()] action:@selector(laneMenuPicked:) keyEquivalent:@""];
        it.target = self;
        it.tag = static_cast<NSInteger>(i);
        it.representedObject = @(static_cast<int>(lane.kind) * 1000 + lane.number);
        it.state = lane == current ? NSControlStateValueOn : NSControlStateValueOff;
        [menu addItem:it];
    };
    add(KeyLane::velocity());
    add(KeyLane::controller(1)); add(KeyLane::controller(7)); add(KeyLane::controller(10)); add(KeyLane::controller(11));
    add(KeyLane::controller(64)); add(KeyLane::controller(74)); add(KeyLane::controller(91));
    add(KeyLane::pitchBend()); add(KeyLane::aftertouch());
    if (current.kind == KeyLane::Kind::Controller && current.number != 1 && current.number != 7 && current.number != 10 && current.number != 11 &&
        current.number != 64 && current.number != 74 && current.number != 91) add(current);
    NSMenuItem* other = [[NSMenuItem alloc] initWithTitle:@"Other Controller…" action:@selector(laneOtherPicked:) keyEquivalent:@""];
    other.target = self; other.tag = static_cast<NSInteger>(i);
    [menu addItem:other];
    [menu addItem:[NSMenuItem separatorItem]];
    NSMenuItem* addLane = [[NSMenuItem alloc] initWithTitle:@"Add Lane" action:@selector(laneAdd:) keyEquivalent:@""];
    addLane.target = self; addLane.enabled = _lanes.size() < kMaxLanes;
    [menu addItem:addLane];
    NSMenuItem* removeLane = [[NSMenuItem alloc] initWithTitle:@"Remove This Lane" action:@selector(laneRemove:) keyEquivalent:@""];
    removeLane.target = self; removeLane.tag = static_cast<NSInteger>(i); removeLane.enabled = _lanes.size() > 1U;
    [menu addItem:removeLane];
    NSMenuItem* thin = [[NSMenuItem alloc] initWithTitle:@"Thin Out This Lane" action:@selector(laneThin:) keyEquivalent:@""];
    thin.target = self; thin.tag = static_cast<NSInteger>(i); thin.enabled = current.isMessageLane();
    [menu addItem:thin];
    NSMenuItem* clear = [[NSMenuItem alloc] initWithTitle:@"Clear This Lane" action:@selector(laneClear:) keyEquivalent:@""];
    clear.target = self; clear.tag = static_cast<NSInteger>(i); clear.enabled = current.isMessageLane();
    [menu addItem:clear];
    [menu popUpMenuPositioningItem:nil atLocation:p inView:self];
}
- (void)laneMenuPicked:(NSMenuItem*)item {
    const auto i = static_cast<std::size_t>(item.tag);
    if (i >= _lanes.size()) return;
    const int code = [item.representedObject intValue];
    KeyLane lane;
    lane.kind = static_cast<KeyLane::Kind>(code / 1000);
    lane.number = static_cast<std::uint8_t>(code % 1000);
    _lanes[i] = lane;
    _selMsg.clear();
    [self setNeedsDisplay:YES];
}
- (void)laneOtherPicked:(NSMenuItem*)item {
    const auto i = static_cast<std::size_t>(item.tag);
    NSNumber* n = [self.controller keyAskControllerNumber];
    if (!n || i >= _lanes.size()) return;
    _lanes[i] = KeyLane::controller(static_cast<std::uint8_t>(std::clamp([n intValue], 0, 127)));
    _selMsg.clear();
    [self setNeedsDisplay:YES];
}
- (void)laneAdd:(id)sender {
    (void)sender;
    if (_lanes.size() >= kMaxLanes) return;
    static const KeyLane choices[] = {KeyLane::controller(1), KeyLane::controller(11), KeyLane::pitchBend(), KeyLane::controller(7), KeyLane::controller(64)};
    for (const auto& ch : choices) {
        if (std::find(_lanes.begin(), _lanes.end(), ch) == _lanes.end()) { _lanes.push_back(ch); break; }
    }
    _activeLane = _lanes.size() - 1U;
    [self setNeedsDisplay:YES];
}
- (void)laneRemove:(NSMenuItem*)item {
    const auto i = static_cast<std::size_t>(item.tag);
    if (_lanes.size() <= 1U || i >= _lanes.size()) return;
    _lanes.erase(_lanes.begin() + static_cast<std::ptrdiff_t>(i));
    _activeLane = std::min(_activeLane, _lanes.size() - 1U);
    _selMsg.clear();
    [self setNeedsDisplay:YES];
}
- (void)laneThin:(NSMenuItem*)item { _activeLane = std::min(static_cast<std::size_t>(item.tag), _lanes.size() - 1U); [self thinActiveLane]; }
- (void)laneClear:(NSMenuItem*)item { _activeLane = std::min(static_cast<std::size_t>(item.tag), _lanes.size() - 1U); [self clearActiveLane]; }

// =============================================================== right mouse ==
- (NSMenu*)menuForEvent:(NSEvent*)event {
    SilvetonController* c = self.controller;
    if (![self seq]) return nil;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (p.y >= [self gridBottom]) {
        const long li = [self laneAtY:p.y];
        if (li >= 0) { _activeLane = static_cast<std::size_t>(li); [self showLaneMenu:static_cast<std::size_t>(li) at:NSMakePoint(std::max(p.x, kKeysW * 0.5), p.y)]; }
        return nil;
    }
    if (const MusicalMidiNote* hit = [self noteAt:p]) {
        if (!_sel.count(hit->id)) { _sel.clear(); _sel.insert(hit->id); [self setNeedsDisplay:YES]; }
    }
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Notes"];
    auto add = [&](NSString* title, NSString* sel) {
        NSMenuItem* it = [[NSMenuItem alloc] initWithTitle:title action:NSSelectorFromString(sel) keyEquivalent:@""];
        it.target = c;
        [m addItem:it];
    };
    auto sub = [&](NSString* title, NSArray<NSArray<NSString*>*>* items) {
        NSMenuItem* parent = [[NSMenuItem alloc] initWithTitle:title action:nil keyEquivalent:@""];
        NSMenu* s = [[NSMenu alloc] initWithTitle:title];
        for (NSArray<NSString*>* pair in items) {
            NSMenuItem* it = [[NSMenuItem alloc] initWithTitle:pair[0] action:NSSelectorFromString(pair[1]) keyEquivalent:@""];
            it.target = c;
            [s addItem:it];
        }
        parent.submenu = s;
        [m addItem:parent];
    };
    add(@"Cut", @"cutClip:"); add(@"Copy", @"copyClip:"); add(@"Paste at Cursor", @"pasteClip:"); add(@"Duplicate", @"duplicateClip:"); add(@"Delete", @"deleteSelection:");
    [m addItem:[NSMenuItem separatorItem]];
    sub(@"Select", @[@[@"All", @"sampleSelectAll:"], @[@"Invert", @"keySelectInvert:"], @[@"Same Pitch", @"keySelectSamePitch:"],
                     @[@"From Cursor to End", @"keySelectFromCursor:"], @[@"None", @"keySelectNone:"]]);
    sub(@"Transpose", @[@[@"Up 1 Semitone", @"midiUp:"], @[@"Down 1 Semitone", @"midiDown:"], @[@"Up an Octave", @"midiOctaveUp:"], @[@"Down an Octave", @"midiOctaveDown:"]]);
    [m addItem:[NSMenuItem separatorItem]];
    add(@"Mute / Unmute Notes", @"keyMuteNotes:"); add(@"Cut at Cursor", @"keySplitAtCursor:"); add(@"Glue Notes", @"keyGlueSelected:");
    add(@"Fit Notes to Scale", @"keyFitToScale:");
    [m addItem:[NSMenuItem separatorItem]];
    add(@"Quantize", @"midiQuantize:"); add(@"Legato", @"midiLegato:"); add(@"Delete Doubles", @"midiDeleteDoubles:");
    return m;
}

// ===================================================================== keys ==
- (void)keyDown:(NSEvent*)event {
    SilvetonController* c = self.controller;
    NSString* chars = event.charactersIgnoringModifiers;
    const unichar ch = chars.length ? [chars characterAtIndex:0] : 0;
    const NSEventModifierFlags mods = event.modifierFlags;
    const BOOL cmd = (mods & NSEventModifierFlagCommand) != 0;
    if (![self seq]) { [super keyDown:event]; return; }
    if (event.keyCode == 53) { _sel.clear(); _selMsg.clear(); [self setNeedsDisplay:YES]; return; }   // Esc
    if (!cmd && ch >= '1' && ch <= '7') { [c setKeyTool:static_cast<SVKeyTool>(ch - '1')]; return; }
    if (ch == 127 || ch == NSDeleteFunctionKey) { if (_sel.empty() && _selMsg.empty()) { [super keyDown:event]; return; } [self deleteSelected]; return; }
    if (!_sel.empty() && !cmd) {
        const std::vector<std::uint64_t> ids = [self selection];
        const double step = (mods & NSEventModifierFlagOption) ? 1.0 : [self gridStep];
        if (ch == NSLeftArrowFunctionKey || ch == NSRightArrowFunctionKey) {
            const double dq = ch == NSLeftArrowFunctionKey ? -step : step;
            [c noteEdit:@"Nudge Notes" op:^(MidiSequence& s) { KeyEditing::moveFrom(s, KeyEditing::snapshot(s, ids), dq, 0); }];
            [self setNeedsDisplay:YES];
            return;
        }
        if (ch == NSUpArrowFunctionKey || ch == NSDownArrowFunctionKey) {
            const int dp = (ch == NSUpArrowFunctionKey ? 1 : -1) * ((mods & NSEventModifierFlagShift) ? 12 : 1);
            [c noteEdit:@"Transpose Notes" op:^(MidiSequence& s) { KeyEditing::moveFrom(s, KeyEditing::snapshot(s, ids), 0.0, dp); }];
            [self setNeedsDisplay:YES];
            return;
        }
    }
    if (ch == '+' || ch == '=') { [self zoomBy:0.7]; return; }
    if (ch == '-') { [self zoomBy:1.0 / 0.7]; return; }
    if (ch == '0') { [self zoomFit]; return; }
    [super keyDown:event];
}

- (void)viewDidHide { [super viewDidHide]; [self stopAudition]; }

@end
