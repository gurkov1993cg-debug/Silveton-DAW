# Silveton ↔ Cubase terminology

Taken from the Steinberg operation manuals (Project window overview; VariAudio Inspector section; MixConsole in the
Lower Zone). Left: the Cubase term. Right: what Silveton calls it, and where it is. "—" = not in Silveton yet.

## Project window

| Cubase | Silveton |
|---|---|
| Left Zone → Inspector, tabs **Track** / **Editor** (+ Visibility) | Inspector, tabs **TRACK** / **EDITOR** (no Visibility tab yet) |
| Project Zone: Toolbar, Track List, Event Display, Ruler | tool row, track headers, the clips area, ruler (+ markers and arranger rows) |
| Toolbar › Tool Buttons: Object Selection (1), Range Selection (2), Split (3), Glue (4), Erase (5), Zoom (6), Mute (7), Draw (8); Comp, Time Warp, Line, Play, Color | the same eight tools with the same keys; — Comp, Time Warp, Line, Play, Color |
| Edit › Range: Global Copy, Cut Time, Delete Time, Paste Time, Paste Time at Origin, Split, Crop, Insert Silence | Edit › Range: Cut Time, Delete Time, Insert Silence, Split at Range Edges, Crop to Range, Set Cycle to Range, Zoom to Range; Edit › Cut / Copy / Paste / Delete work on the range; — Global Copy, Paste Time, Paste Time at Origin |
| Set Locators to Selection Range (P) | Set Cycle to Range (P) |
| Zoom Full (Shift+F), Zoom to Selection (Alt+S) | FIT key / View › Zoom to Project; Zoom to Range |
| Status Line / Info Line / Overview Line / Transport Bar (toolbar switches) | status line (bottom), info line (under the tool row), — , transport deck (top) |
| Lower Zone: Chord Pads, **Editor**, Sampler Control, **MixConsole**, MIDI Remote | Lower zone: **EDITOR**, **MIXER** (no Chord Pads, Sampler Control, MIDI Remote) |
| Right Zone: VSTi rack, Media rack, Control Room rack, Meter rack | level panel ≈ Meter rack; LIBRARY page ≈ Media rack + Pool; — Control Room, — VSTi rack |
| MixConsole window (F3) | MIX page |
| Editor in a separate window | FULL PAGE / F4 (Editor on a full page) |

## Sample Editor → VariAudio Inspector section ↔ Tone Editor (EDITOR tab)

| Cubase | Silveton |
|---|---|
| Edit VariAudio (analysis, segments) | opens with TONE / T / "Open in Tone Editor"; **Analyze Again** = fresh analysis |
| Segments | Segments (the coloured blocks per note) |
| Bypass VariAudio Changes | Bypass / Use Segments |
| Smart Controls (Default / All) | — (drag the segment: up/down = pitch, edges = length; Time Bend tool = warp) |
| Pitch Snap Mode | — (Option while dragging = free, otherwise semitones; Snap Pitch Editing = to the scale) |
| MIDI Input / Step | — |
| Correct Pitch | Correct Pitch (0–100 %) |
| Straighten Curve | Straighten (0–100 %) |
| Shift Formant | Shift Formant (cents) |
| Volume | Volume (dB) |
| Scale Assistant: Use Editor Scale, Editor Scale, Scale Suggestions, Use Chord Track, Chord Track Mode, Show Scale Note Guides, Snap Pitch Editing, Quantize Pitches | SCALE: root + mode, Scale Suggestions, Show scale rows, Snap Pitch Editing, Fit to scale; — Chord Track |
| MIDI Reference Track | — |
| Functions › Extract MIDI, Generate Harmony Voices, … | Extract MIDI to a New Track; — Generate Harmony Voices |
| (no equivalent) | Vibrato, Tilt, Move, Glide, Time Bend points, Snap Timing to Grid |

## MixConsole ↔ MIXER

| Cubase | Silveton |
|---|---|
| Fader Section (channels in the track list order) | the strips |
| Inserts rack | INSERTS slots on the strip |
| Sends rack | SENDS slots on the strip |
| Channel name, colour | name plate + colour bar |
| Mute / Solo / Listen / Record Enable / Monitor | MUTE / SOLO (I and ● are on the track header) |
| Page selector (faders / inserts / sends) in the Lower Zone MixConsole | — (the compact mixer shows all three) |
| Linking channels, Channel visibility filters, MixConsole undo | — |

## Key Editor

| Cubase | Silveton |
|---|---|
| Key Editor (note display, controller lanes, Inspector sections) | Key Editor: note grid, up to 4 controller lanes, EDITOR tab sections |
| Object Selection, Draw, Erase, Split, Glue, Mute, Line tools | Select, Draw, Erase, Cut, Glue, Mute, Line |
| Quantize panel | Quantize Setup |
| Edit Active Part Only / multiple parts | — (one part at a time) |
