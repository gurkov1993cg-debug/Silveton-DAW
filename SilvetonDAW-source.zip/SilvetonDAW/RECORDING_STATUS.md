# Silveton DAW recording status — 0.5.3

## Fixed defect
The previous `Recorder::push()` allocated a new `AudioBuffer`, copied the entire previous recording, appended the new block, and moved the new buffer on every call. That path was not real-time safe and scaled O(total recorded length) per callback.

## Current architecture
`AudioDevice input -> AudioEngine::processAudio() -> Recorder::push() -> preallocated SPSC ring -> background writer thread -> WAV/RF64 file`

### Audio-thread contract
`Recorder::push()`:
- no heap allocation
- no file I/O
- no filesystem calls
- no seek/flush
- no mutex/condition-variable lock
- no vector resize
- atomics + bounded sample copy only

### Writer contract
- file open/header creation occurs on the control thread
- sample data is written only by the writer thread
- stop first closes the producer gate, waits for an in-flight push, drains the ring, joins the writer, then finalizes sizes
- writer failure is sticky and marks the take faulted
- ring overflow is sticky, counts dropped frames, and marks the take faulted

### Long recordings
The file layout reserves a 28-byte `JUNK` chunk. Normal takes finalize as RIFF/WAVE. If data exceeds the 32-bit RIFF limit, the same header is converted in-place to RF64 with `ds64`; no audio payload relocation is required. `WavFile::read()` supports the resulting RF64 files.

## Portable verification on 2026-09-20
Release: 7/7 tests PASS.
UBSan-only: 7/7 tests PASS.

Dedicated recording checks PASS:
- zero heap allocations on the producer thread
- exact sample/frame preservation to Float32 WAV
- SPSC physical wrap-around ordering
- AudioEngine device-input wiring
- safe stop against an in-flight producer push
- deterministic overflow/fault reporting
- RF64 `ds64` parsing

ASan+UBSan binaries compile in the current Linux sandbox, but the sandbox cannot reserve ASan shadow memory (runtime abort before `main()`). The Intel macOS GitHub workflow therefore performs the combined ASan+UBSan test on the target-class runner.

## Still requiring target validation
- Intel macOS/Xcode 16.4 compile of the new recording code
- CoreAudio enumeration on `macos-15-intel`
- real iMac 2011 CoreAudio open/start/record/stop/playback test with the intended interface
