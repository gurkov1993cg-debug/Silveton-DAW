# CoreAudio backend validation status

Implemented in `src/CoreAudioDevice.cpp` / `include/silveton/CoreAudioDevice.h`:

- native AUHAL (`kAudioUnitSubType_HALOutput`) duplex input/output
- planar Float32 client format, no DSP or hidden gain in the device backend
- device enumeration and stable CoreAudio UID selection
- default-output following and control-thread reopen contract
- requested sample-rate and buffer-size negotiation
- callback-aligned CoreAudio sample/host timestamps
- device/stream/safety-offset latency reporting plus AudioUnit latency
- processor-overload counter
- sample-rate, buffer-size, device-alive and default-device change notifications
- preallocated input buffers; no allocation/logging/file I/O/device queries in render callback
- macOS smoke executable with enumeration and opt-in `--stream` open/start/stop test

Current 0.10.0 local regression status: Release **12/12 PASS** and ASan+UBSan **12/12 PASS**.

GitHub Actions Run #19 SUCCESS confirms the CoreAudio compile/enumeration smoke boundary through the official 0.9.0 baseline on `macos-15-intel + Xcode 16.4 + x86_64 + deployment target 10.13`. The new 0.10.0 mixer-automation changes still require a fresh GitHub run before they inherit that target validation. A green CI run does not replace the final real iMac 2011 open/play/record hardware test.
