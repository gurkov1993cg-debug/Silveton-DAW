# CoreAudio backend validation status

Implemented in `src/CoreAudioDevice.cpp` / `include/silveton/CoreAudioDevice.h`:

- native AUHAL (`kAudioUnitSubType_HALOutput`) duplex input/output
- planar Float32 client format, no DSP or hidden gain in the device backend
- device enumeration and stable CoreAudio UID selection
- default-output following and control-thread reopen contract
- requested sample-rate and buffer-size negotiation
- callback-aligned CoreAudio sample/host timestamps
- device/stream/safety-offset latency reporting plus AudioUnit latency
- processor-overload counter
- sample-rate, buffer-size, device-alive and default-device change notifications
- preallocated input buffers; no allocation/logging/file I/O/device queries in render callback
- macOS smoke executable with enumeration and opt-in `--stream` open/start/stop test

Portable Release and UBSan regression are currently 9/9 PASS.
Combined ASan+UBSan is run in the Intel macOS workflow because the current sandbox cannot
reserve ASan shadow memory reliably.

Native CoreAudio compile/runtime is intentionally **not** marked passed until the
`macos-15-intel + Xcode 16.4 + x86_64 + deployment target 10.13` workflow succeeds.
A green CI run still does not replace the final real iMac 2011 open/play hardware test.
