# CoreAudio backend validation status

Implemented in `src/CoreAudioDevice.cpp` / `include/silveton/CoreAudioDevice.h`:

- native AUHAL (`kAudioUnitSubType_HALOutput`) duplex input/output
- planar Float32 client format, no DSP or hidden gain in the device backend
- device enumeration and stable CoreAudio UID selection
- default-output following and control-thread reopen contract
- requested sample-rate and buffer-size negotiation
- callback-aligned CoreAudio sample/host timestamps
- device/stream/safety-offset latency reporting plus AudioUnit latency
- processor-overload counter
- sample-rate, buffer-size, device-alive and default-device change notifications
- preallocated input buffers; no allocation/logging/file I/O/device queries in the render callback
- macOS smoke executable with enumeration and opt-in `--stream` open/start/stop test

Portable code is validated on Linux with Release and ASan/UBSan tests. Native CoreAudio
compile/runtime is intentionally **not** marked as passed until the Intel macOS validation
workflow below succeeds.
