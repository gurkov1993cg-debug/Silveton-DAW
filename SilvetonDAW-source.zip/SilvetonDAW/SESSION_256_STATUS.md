# Silveton DAW 256-track session status — Core 0.6.0

## Locked session capacity

The user-facing Silveton session contract is **256 audio tracks**. The lower-level
`AudioEngine` retains a 512-track ceiling so the existing 512-voice stress test remains
available as headroom verification, but project/session creation rejects track 257.

## Implemented and tested for the 256-track path

- 256 simultaneous stereo timeline voices in the real `AudioEngine` mix callback.
- Track audio can be memory-backed (`AudioBuffer`) or disk-backed (`DiskAudioSource`).
- Disk-backed playback uses a shared background `DiskStreamManager`; the callback performs
  no file open/read/seek/close, no sleep and no heap allocation.
- Three preallocated cache pages per disk source with guarded page handoff and look-ahead
  prefetch across cache boundaries.
- A control-thread LRU handle pool; on POSIX/macOS the manager attempts to raise the soft
  `RLIMIT_NOFILE` safely and auto-sizes the pool with descriptor headroom.
- Float32 RIFF/WAVE playback.
- PCM16 RIFF/WAVE playback with background conversion to Float32 cache samples.
- RF64/ds64 Float32 playback, matching the long-take format produced by the recorder.
- Existing per-track gain, pan/stereo balance, dual-panner and mute all alter the actual
  samples entering the mix bus.
- Real per-track peak/RMS meters are derived from each track's post-gain/post-pan contribution,
  including Track 1 and Track 256.
- Project format V4 persists 256 tracks plus timeline start, source offset, voice-enabled
  state and voice priority; V1/V2/V3 loading remains supported.
- Track 257 is rejected by both `Project::addTrack()` and `DiskStreamManager::addSource()`.

## Dedicated verification

`silveton_256_track_tests` proves:

- all 256 disk-backed stereo sources are created and voiced;
- 256-track callback playback performs zero heap allocations on the measured audio thread;
- the summed L/R samples equal the mathematically expected 256-track result;
- all 256 sources complete the tested playback window with zero cache underflow;
- Track 1 and Track 256 meters report the real track signal;
- small cache pages cross multiple boundaries without underflow when serviced at realtime cadence;
- project V4 round-trips Track 256 identity/timeline/source/voice state;
- track 257 is rejected.

`silveton_disk_format_tests` separately verifies PCM16 and RF64 disk-cache decoding.

## What this status does NOT claim

This closes the **256-track session/audio playback capacity** feature. It does not claim that
unrelated later DAW milestones are complete. Production VST3 hosting, full routing/PDC graph
execution, multicore plugin scheduling, complete automation editing, take-lane/comp UI,
production elastic-audio quality and the full AppKit DAW GUI remain separate milestones.

Native Intel CoreAudio compilation/runtime is also not called passed until the macOS Intel
GitHub workflow and then a real iMac 2011 open/play test succeed.
