# Changelog

## 0.15.0 candidate — 2026-09-22
- consolidated post-0.10 development into one physical source tree
- added nondestructive clip timeline/editor with move, split, trim, gain, mute, fades and overlap/crossfade
- added cycle workflow, take lanes/comp infrastructure and recording workflow
- added Tempo Map with BPM/time-signature changes, musical position conversion and VST3 context propagation
- added MIDI timeline, MIDI input routing and sample-accurate scheduled VST3 MIDI delivery
- added metronome/count-in and sample-accurate punch in/out recording
- added offline master bounce with selected range, preroll, automatic/fixed tails and VST3 offline processing mode
- portable Release 22/22 PASS
- portable ASan+UBSan 22/22 PASS
- Clang Release 22/22 PASS
- exact Intel macOS/Xcode 16.4 validation is pending the next GitHub run
- StemBounce source exists but is not counted as verified until dedicated regression/CI coverage is added

## 0.10.0 — 2026-09-21
- added real pre/post-fader send taps for tracks and buses
- moved project track/bus volume+mute to the post-insert graph fader stage
- kept track pan in AudioEngine where mono/stereo source layout is known exactly
- added track volume/pan/mute automation
- added send gain and send on/off automation
- added bus gain/mute automation and Master Fader automation
- added stepped switch automation for mute/on-off and continuous interpolation for gain/pan
- extended AutomationWriter Write/Touch/Latch support to natural-unit mixer automation lanes
- automation data is snapshotted into immutable graph/voice-plan state before publication
- advanced project writer to `SILVETON_PROJECT_V16` with V15 backward-compatibility coverage
- existing VST3 sample-accurate parameter automation remains wired through the same runtime rack
- added numeric real-audio tests for pre/post sends plus track/bus/send/master automation
- added zero-allocation automated graph-path test and immutable-snapshot edit test
- portable Release 12/12 PASS
- portable ASan+UBSan 12/12 PASS
- Clang 17 Release 12/12 PASS
- targeted ThreadSanitizer routing + VST3 infrastructure 2/2 PASS
- Intel macOS validation for this exact 0.10.0 source is pending the next GitHub run

## 0.9.0 — 2026-09-21
- added project-level mixer routing model for track outputs, Group/FX buses and real post-fader sends
- added bus type, gain, mute and bus-to-bus/master output routing
- added Master VST3 insert chain before the existing Master Fader
- added `MixerRoutingBuilder` to convert Project + VST3 runtime state into the immutable ProcessorGraph
- added `MixerRuntimeCoordinator` to connect VST3 latency/I/O/reload requests to safe live graph publication and retirement
- added topology-preserving `publishProcessorGraphLatencyRefresh()` for dynamic PDC updates without resetting reused processors
- advanced project writer to `SILVETON_PROJECT_V15` while retaining V1/V2/V3/V4/V14 loading
- added V14 backward-compatibility regression coverage
- added real AudioEngine test for Track -> Group + FX Send -> Master and live bus-mute replacement
- portable Release 12/12 PASS
- portable ASan+UBSan 12/12 PASS
- Clang Release 12/12 PASS
- GitHub Actions Run #19 SUCCESS confirms the 0.9.0 Intel macOS/Xcode 16.4/x86_64/macOS 10.13 baseline


## 0.8.0 — 2026-09-21
- added live immutable `ProcessorGraph` publication while the audio device is running
- added triple-buffered graph plan states: Free/Writing/Pending/Live/Retired
- graph routing/PDC/source/master scratch memory is fully prepared on the control thread before publication
- audio callback adopts a pending graph only at a block boundary and never destroys graph memory
- publication acknowledgement is emitted only after Live/Retired state transition is complete
- added graph generation tracking and explicit control-thread retired-graph reclamation
- preserved the 0.7.0 pre-prepare external graph API as the initial graph path
- reused live processors are not re-prepared or reset during topology-only rebuilds
- newly introduced processors are prepared/reset before their first live block
- publishing a null graph safely restores the transparent direct-mix path
- added callback-allocation test for graph adoption
- added 200-publication concurrent control/audio graph stress test
- added lock-free `RealtimeLifecycleGate` around VST3 realtime process vs control-side lifecycle service
- audio callback never blocks on lifecycle service; suspended blocks use the existing safe bypass/silence path
- dynamic latency service and I/O reconfiguration now wait for an in-flight process block to exit before `setProcessing`/`setActive`/reconfigure calls
- queued `IComponentHandlerBusActivation::requestBusActivation()` requests are now applied under the same lifecycle suspension instead of directly racing `process()`
- removed the now-unused raw component pointer from `HostComponentHandler`
- added deterministic hand-off plus 2000-cycle concurrent lifecycle-gate stress coverage
- portable Release 12/12 PASS
- portable ASan+UBSan 12/12 PASS
- dedicated VST3 infrastructure + live graph tests PASS under GCC ThreadSanitizer
- the 0.8.0 live-graph/lifecycle work is included in the later Run #19 SUCCESS baseline

## 0.7.0 — 2026-09-21
- integrated `ProcessorGraph` into the real `AudioEngine::processAudio()` path
- timeline Track N now feeds graph node N through preallocated callback-safe source buffers
- graph processor chains, routed buses and PDC now execute before the real Master Fader/device output
- graph processing continues while transport is stopped for instrument/tail behavior
- added session tempo/project-sample/play/record propagation through `ProcessorContext`
- raised ProcessorGraph capacity from 256 to 1024 nodes for 256-track + bus/master headroom
- preserved the legacy transparent direct-mix path when no graph is attached
- added `silveton_routing_execution_tests` covering real-engine PDC, stopped-transport instruments, context and zero callback allocation
- portable Release 12/12 PASS
- portable ASan+UBSan 12/12 PASS
- live immutable graph publication/rebuild remains the next routing milestone


## 0.6.2 — 2026-09-20
- fixed Intel macOS AppleClang 17 `-Werror,-Wunused-private-field` build failure in `DiskStream.h`
- removed dead private `DiskAudioSource::dataBytes_` storage while preserving constructor `dataBytes` use for `totalFrames_` calculation
- no DSP, cache, streaming, voice-plan, automation, or phase-vocoder behavior changed
- portable Release 10/10 PASS
- portable ASan+UBSan 10/10 PASS
- Clang 17 `-Wunused-private-field -Werror` compilation check PASS for `DiskStream.cpp`

## 0.6.1 — 2026-09-20
- replaced the earlier deterministic OLA stretch prototype with an original FFT/STFT phase vocoder
- pitch shift now uses resample + phase-vocoder stretch and preserves source duration
- added triple-buffered immutable Live/Pending/Free voice-plan publication
- removed transport-stop requirement from track graph, voice-limit and pan-depth plan rebuilds
- audio callback no longer reads the mutable control-thread `tracks_` vector
- added optional sample-domain gain-dB and pan automation reads in the callback
- `voicedTrackCount()` now reports immediately published control-thread state
- added concurrent control/audio voice-plan publication stress test
- added phase-vocoder pitch preservation and octave-shift regression tests
- portable Release 10/10 PASS
- portable ASan+UBSan 10/10 PASS
- dedicated advanced-audio test PASS under ThreadSanitizer

## 0.5.4
- Fixed Intel macOS 10.13 build failure from Apple libc++ `std::filesystem` availability.
- Replaced project/WAV/recorder public path types with UTF-8 `std::string`.
- Recorder parent-directory creation now uses deployment-compatible C/POSIX calls.
- Tests no longer depend on `std::filesystem`.

## 0.5.3 — 2026-09-20
- replaced RAM-growing recording callback with preallocated SPSC disk-streaming recorder
- added background Float32 WAV writer
- wired live device input through AudioEngine into Recorder
- added sticky recorder fault/overflow/dropped-frame status
- made stop safe against an in-flight producer callback
- added RIFF-to-RF64 in-place header finalization for >4 GiB takes
- added RF64 `ds64` support to WavFile reader
- added dedicated recording regression suite
- portable Release 7/7 PASS
- portable UBSan 7/7 PASS
- combined ASan+UBSan moved into Intel macOS validation workflow because current sandbox cannot reserve ASan shadow memory

## 0.6.0 — 2026-09-20
- completed the user-facing 256-audio-track session capacity layer
- added real background disk playback/cache (`DiskStreamManager` / `DiskAudioSource`)
- added 3-page preallocated cache with realtime-safe acquire/release and look-ahead prefetch
- added POSIX/macOS open-file soft-limit handling plus bounded LRU handle pool
- AudioEngine now renders memory-backed or disk-backed tracks without callback file I/O
- added real per-track post-gain/post-pan peak/RMS meters
- added project format V4 timeline/source/voice state and hard 256-track session limit
- preserved lower-level 512-track engine stress headroom
- added PCM16 disk streaming and RF64/ds64 long-take streaming
- added dedicated 256-track and disk-format regression suites
- portable Release 9/9 PASS
- portable UBSan 9/9 PASS
