# Changelog

## 0.7.0 — 2026-09-21
- integrated `ProcessorGraph` into the real `AudioEngine::processAudio()` path
- timeline Track N now feeds graph node N through preallocated callback-safe source buffers
- graph processor chains, routed buses and PDC now execute before the real Master Fader/device output
- graph processing continues while transport is stopped for instrument/tail behavior
- added session tempo/project-sample/play/record propagation through `ProcessorContext`
- raised ProcessorGraph capacity from 256 to 1024 nodes for 256-track + bus/master headroom
- preserved the legacy transparent direct-mix path when no graph is attached
- added `silveton_routing_execution_tests` covering real-engine PDC, stopped-transport instruments, context and zero callback allocation
- portable Release 12/12 PASS
- portable ASan+UBSan 12/12 PASS
- live immutable graph publication/rebuild remains the next routing milestone


## 0.6.2 — 2026-09-20
- fixed Intel macOS AppleClang 17 `-Werror,-Wunused-private-field` build failure in `DiskStream.h`
- removed dead private `DiskAudioSource::dataBytes_` storage while preserving constructor `dataBytes` use for `totalFrames_` calculation
- no DSP, cache, streaming, voice-plan, automation, or phase-vocoder behavior changed
- portable Release 10/10 PASS
- portable ASan+UBSan 10/10 PASS
- Clang 17 `-Wunused-private-field -Werror` compilation check PASS for `DiskStream.cpp`

## 0.6.1 — 2026-09-20
- replaced the earlier deterministic OLA stretch prototype with an original FFT/STFT phase vocoder
- pitch shift now uses resample + phase-vocoder stretch and preserves source duration
- added triple-buffered immutable Live/Pending/Free voice-plan publication
- removed transport-stop requirement from track graph, voice-limit and pan-depth plan rebuilds
- audio callback no longer reads the mutable control-thread `tracks_` vector
- added optional sample-domain gain-dB and pan automation reads in the callback
- `voicedTrackCount()` now reports immediately published control-thread state
- added concurrent control/audio voice-plan publication stress test
- added phase-vocoder pitch preservation and octave-shift regression tests
- portable Release 10/10 PASS
- portable ASan+UBSan 10/10 PASS
- dedicated advanced-audio test PASS under ThreadSanitizer

## 0.5.4
- Fixed Intel macOS 10.13 build failure from Apple libc++ `std::filesystem` availability.
- Replaced project/WAV/recorder public path types with UTF-8 `std::string`.
- Recorder parent-directory creation now uses deployment-compatible C/POSIX calls.
- Tests no longer depend on `std::filesystem`.

## 0.5.3 — 2026-09-20
- replaced RAM-growing recording callback with preallocated SPSC disk-streaming recorder
- added background Float32 WAV writer
- wired live device input through AudioEngine into Recorder
- added sticky recorder fault/overflow/dropped-frame status
- made stop safe against an in-flight producer callback
- added RIFF-to-RF64 in-place header finalization for >4 GiB takes
- added RF64 `ds64` support to WavFile reader
- added dedicated recording regression suite
- portable Release 7/7 PASS
- portable UBSan 7/7 PASS
- combined ASan+UBSan moved into Intel macOS validation workflow because current sandbox cannot reserve ASan shadow memory

## 0.6.0 — 2026-09-20
- completed the user-facing 256-audio-track session capacity layer
- added real background disk playback/cache (`DiskStreamManager` / `DiskAudioSource`)
- added 3-page preallocated cache with realtime-safe acquire/release and look-ahead prefetch
- added POSIX/macOS open-file soft-limit handling plus bounded LRU handle pool
- AudioEngine now renders memory-backed or disk-backed tracks without callback file I/O
- added real per-track post-gain/post-pan peak/RMS meters
- added project format V4 timeline/source/voice state and hard 256-track session limit
- preserved lower-level 512-track engine stress headroom
- added PCM16 disk streaming and RF64/ds64 long-take streaming
- added dedicated 256-track and disk-format regression suites
- portable Release 9/9 PASS
- portable UBSan 9/9 PASS
