# Changelog

## 0.5.3 — 2026-09-20
- replaced RAM-growing recording callback with preallocated SPSC disk-streaming recorder
- added background Float32 WAV writer
- wired live device input through AudioEngine into Recorder
- added sticky recorder fault/overflow/dropped-frame status
- made stop safe against an in-flight producer callback
- added RIFF-to-RF64 in-place header finalization for >4 GiB takes
- added RF64 `ds64` support to WavFile reader
- added dedicated recording regression suite
- portable Release 7/7 PASS
- portable UBSan 7/7 PASS
- combined ASan+UBSan moved into Intel macOS validation workflow because current sandbox cannot reserve ASan shadow memory
