# Silveton DAW — where everything is

One home for every function. The names below are the ones in the program.

## Pages (keys on the wooden side bar)

| Key | What it is | Cubase equivalent |
|---|---|---|
| **PROJECT** | The working window: Inspector, tool row, info line, tracks, lower zone | Project window |
| **MIX** | The full mixer (all channels, inserts, sends) | MixConsole |
| **LIBRARY** | Plug-ins, the pool of sounds in the project, markers, arranger sections and chain | Media rack / Pool / Markers / Arranger |
| **SETUP** | Audio system (device, rate, buffer) | Studio Setup |

## The PROJECT page

- **Transport deck** (top): position, tempo & signature, the transport keys, CYCLE, CLICK, locators, master meter.
- **Inspector** (left) with two tabs: **TRACK** (the selected track: name, colour, fader, routing, inserts, sends, notepad) and **EDITOR** (the settings of the open editor). The tab follows the click: in the tracks → TRACK, in the editor → EDITOR. Sections fold on a click.
- **Tool row**: the eight tools (keys 1–8, as in Cubase): Object Selection, Range Selection, Split, Glue, Erase, Zoom, Mute, Draw; then SNAP, GRID, track HEIGHT (a popup), the ZOOM slider and FIT (the whole project); on the right the zone keys INSPECTOR | LOWER ZONE | LEVEL.
- **Range selection** (tool 2): drag over one or more tracks to mark a span of time. The info line shows it; Delete, ⌘X, ⌘C, ⌘V (at the cursor) and Edit › Range (Cut Time, Delete Time, Insert Silence, Split at Range Edges, Crop, Set Cycle, Zoom) work on it. Esc drops it, Shift-drag extends it, a double-click on a clip takes the clip as the range, ⌘A marks the whole project.
- **Info line**: the facts of the selected clip / part (file, start, end, length, fades, gain, mute, file rate). Double-click fades / gain / mute to change them.
- **Tracks**: ruler, markers, arranger, the tracks with their clips.
- **Lower zone** (hidden until needed): tabs MIXER | EDITOR along its bottom edge, FULL PAGE and HIDE on the right, a splitter above it for the height. Double-click on a clip / part opens the editor here.
- **Level panel** (right, hidden until needed): master peak, big stereo meter, the selected clip.
- **Status line** (bottom): messages, project name, sample rate, DSP load.

## The editors (under the tracks; FULL PAGE or F4 shows the same editor on a full page)

| Editor | Opens for | Switch | Its settings (Inspector › EDITOR) |
|---|---|---|---|
| **Sample Editor** | an audio clip | WAVE | selection, process, time / pitch, clip, quantize |
| **Tone Editor** (the VariAudio of Silveton) | an audio clip with one voice | TONE, or T, or "Open in Tone Editor" | tools, pitch, scale, colour & loudness, time, blocks, MIDI, listening |
| **Key Editor** | a MIDI part | double-click the part | tools, new notes, scale, controller lanes, select & edit, quantize, functions, transpose, view |

Commands such as Delete, Cut, Copy, Paste, Duplicate, Mute and Select All go to the area that was clicked last: the editor, or the tracks.

## Menus

- **File** — new, open, save; import audio / MIDI; export mixdown, stems, MIDI.
- **Edit** — undo / redo; cut, copy, paste, duplicate, delete; split, mute, Tool › (1–8), Range › (cut / delete time, insert silence, split, crop, cycle, zoom), Nudge ›, Select ›; rename, lock.
- **Project** — add tracks, groups, FX, folders; duplicate / remove / move track; notes, arranger, project setup, plug-in scan.
- **Audio** — Process › (normalize … pitch shift), Clip › (gain, fades, render in place), audio quantize; Sample Editor ›; Tone Editor ›.
- **MIDI** — quantize, quantize setup, More Quantize ›, Functions ›, Transpose ›; open Key Editor, Key Editor ›.
- **Transport** — play, stop, record, cycle, click; go to start, bars, markers; locate, tempo, time signature.
- **View** — the pages; Inspector, Lower Zone, editor / mixer under the tracks, level panel; snap, zoom, track height.
- **Window** — minimize.

Context menus (right-click) repeat the commands that fit what is under the mouse: a clip, a part, a track header, a marker, a section, a mixer strip, a block in the Tone Editor, a note in the Key Editor.
