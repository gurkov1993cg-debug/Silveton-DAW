# Silveton DAW 0.8.0 — Live Immutable ProcessorGraph status

## Milestone closed locally

Silveton can now replace its processor/routing graph while the audio callback is running without mutating or destroying the graph currently used by the realtime thread.

Publication path:

`Control build -> Free -> Writing -> Pending -> callback boundary -> Live -> predecessor Retired -> control reclaim`

## Realtime contract

The audio callback:
- never allocates graph memory;
- never destroys a `ProcessorGraph`;
- never resizes graph buffers;
- never locks around publication;
- adopts at most one fully prepared pending generation at a block boundary;
- uses the same immutable graph plan for the rest of that callback.

The control thread:
- configures the replacement graph;
- allocates source/master/routing/PDC scratch buffers;
- prepares newly introduced processors;
- does not re-prepare/reset processors already present in the live predecessor;
- publishes the prepared slot atomically;
- destroys retired owned graphs only through `reclaimRetiredProcessorGraphs()`.

## Processor/VST3 lifetime boundary

`ProcessorGraph` still stores processor pointers; the graph plan owns the graph and its scratch memory, not the plug-in processor instances themselves.

Therefore a removed/reloaded VST3 instance must stay alive while a predecessor graph can reference it. The safe sequence is:

1. create/restore replacement instance on control thread;
2. build and `publishProcessorGraph()` with the replacement;
3. allow one audio callback to adopt the pending generation;
4. call `reclaimRetiredProcessorGraphs()` on the control thread;
5. only after reclamation, call `Vst3RuntimeRack::releaseRetiredInstances()`.

This matches the existing transactional VST3 reload ownership contract and avoids dangling processor pointers in the realtime graph.

## Regression coverage

`silveton_routing_execution_tests` now verifies:
- publication remains pending until a callback boundary;
- graph generation changes only after adoption;
- predecessor is not reclaimable before adoption;
- predecessor becomes reclaimable after adoption;
- a second publication is rejected while another generation is pending;
- a reused processor is not `prepare()`d or `reset()` during rebuild;
- a new processor is prepared/reset before first live processing;
- graph adoption performs zero measured heap allocations;
- live graph detach restores direct transparent mixing;
- 200 graph generations can be published from a control thread while a separate audio thread continuously renders valid output.

## VST3 lifecycle concurrency hardening

Live graph publication alone is not enough if the host can call VST3 lifecycle methods while the same instance is inside `IAudioProcessor::process()`. The 0.8.0 host therefore includes a lock-free realtime/control lifecycle gate:

- realtime entry is a non-blocking atomic attempt;
- control suspension waits only on the control thread for the current process block to finish;
- `serviceLatencyChange()` and `reconfigureAfterIoChange()` own the suspended lifecycle region;
- queued bus-activation requests are also serviced only while the instance is suspended;
- a suspended realtime call returns failure immediately, allowing ProcessorGraph's existing safe bypass/silence behavior;
- resume publishes the lifecycle state before a later audio block may enter.

The infrastructure regression performs a deterministic hand-off test plus 2000 concurrent suspend/resume cycles and checks that audio/control protected regions never overlap.

Local verification:
- Release 12/12 PASS
- ASan + UBSan 12/12 PASS
- Clang 17 Release 12/12 PASS
- GCC ThreadSanitizer VST3-infrastructure + routing/live-publication tests 2/2 PASS

## Target validation boundary

The previous 0.7.0 base is confirmed by GitHub Actions Run #18 SUCCESS. This exact 0.8.0 source is not declared target-green until the next `macos-15-intel` / Xcode 16.4 / x86_64 / macOS 10.13 workflow passes.
