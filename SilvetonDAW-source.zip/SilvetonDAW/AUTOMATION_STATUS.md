# Silveton DAW 0.10.0 — mixer automation status

## Implemented

The mixer now has real sample-domain automation for:
- track volume;
- track pan;
- track mute;
- send level;
- send on/off;
- bus gain;
- bus mute;
- Master Fader;
- VST3 parameters through the existing sample-accurate VST3 automation queue.

Continuous controls (dB and pan) interpolate between points. Switch controls (mute and send on/off) are stepped: a switch changes exactly at its automation point instead of halfway between two points.

`AutomationWriter` supports Write/Touch/Latch semantics for both normalized VST3 lanes and natural-unit mixer lanes.

## Pre/post-fader sends

Track and bus insert chains execute before the fader. Each send stores an explicit pre/post setting:

`source -> inserts -> PRE SEND TAP -> fader/mute -> POST SEND TAP -> main output`

Track pan is evaluated before these taps because AudioEngine has the exact mono/stereo source layout there. Pre-fader therefore means pre-volume/mute, post-insert and post-pan in this milestone.

Bus sends follow the same insert -> pre tap -> bus fader/mute -> post tap order.

## Realtime safety

The live ProcessorGraph owns immutable copies of mixer automation lanes. Editing the Project after graph publication cannot mutate the currently running graph. Track pan automation is copied into the immutable AudioEngine voice plan for the same reason.

The audio path performs no heap allocation while evaluating mixer automation. A dedicated regression test measures zero allocations while processing automated pre/post-fader routes.

## Project format

Writer format: `SILVETON_PROJECT_V16`.

V16 adds persisted automation for track, send, bus and master mixer controls plus the send pre/post-fader flag. V15 and the previously supported older formats remain readable.

## Local verification

- portable Release: 12/12 PASS;
- ASan + UBSan: 12/12 PASS;
- Clang 17 Release: 12/12 PASS;
- routing + VST3 infrastructure targeted ThreadSanitizer: 2/2 PASS.

## Not claimed yet

This milestone does not claim the full automation editor/GUI, lane drawing tools, trim automation, automation thinning, or the finished DAW application. Intel macOS validation for this exact 0.10.0 source requires the next GitHub run.
